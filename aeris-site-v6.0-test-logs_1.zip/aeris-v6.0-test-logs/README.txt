AERIS v6.0 - raw test logs and verification evidence
=====================================================

Everything below was produced by running the code on one build machine (Linux x86-64, Ubuntu 24.04; backend
Python 3.12.3 with the locked environment; Node 22.22.2; ESP-IDF v6.0.3; Espressif QEMU 9.2.2). Only synthetic
devices, fixtures and emulators were used: no physical board, sensor, driver, motor or cube was involved.

Except for release-validation/aeris-site-v6.0.*, every file here is a byte-identical copy of a file in the tag
aeris-v6.0 (commit 5278d1108656e4a781084881b550e2924eeacc4b), taken with `git archive`.

definitive-run-91f78f3/   = test-logs/ of the tag, plus console.log (= evidence/v6.0-verification/
                            definitive-run-91f78f3-console.log). `python3 scripts/run_tests.py` at commit 91f78f3:
                            26 suites, 1105 passed, 0 failed, 0 skipped, 0 not run (SUMMARY.md, summary.json).
                            91f78f3 -> aeris-v6.0 changes only test-logs/, evidence/, SOFTWARE_COMPLETION_REPORT.md
                            and ACCEPTANCE_MATRIX_V6.md (39 paths; no product, test or tooling change).

verification/             = evidence/v6.0-verification/ of the tag (its README.md is the index):
                            reproduction-v5.2/  V52-1..4 reproduced on the unmodified v5.2
                            after-v6/           the same probes on v6.0, V52-1d negative control
                            firmware-build/     ESP-IDF build logs of the three ESP32-S3 variants (sizes, SHA-256)
                            firmware-fault-tests/, firmware-timing/ (host CPU only), numerical/ (32 campaign rows)
                            full-run-1-56dd89e/ first complete run (1095 passed); superseded because filling the
                                                acceptance matrix showed coverage gaps that were then closed
                            ci-local/           the CI workflow's run: steps executed locally in fresh clones
                                                (not a hosted CI run)
                            environment.json    machine, tools, installed packages

release-validation/       README.md, candidate-archive-*  (from the tag: the candidate archive of commit b5a2967,
                            21 / 21 steps)
                          aeris-site-v6.0.release-validation.json / .log  - the DELIVERED archive
                            (aeris-site-v6.0.zip, 13 018 624 bytes, 1 183 files, SHA-256
                            bbdb7c87426b24b246d61c2f98b24de0336c08def435745234c1747c5b0b4488) validated by
                            scripts/validate_release.py in a new temporary directory on 2026-10-13 (15:02-15:10 UTC):
                            21 / 21 steps passed, exit code 0 (browser-v6 51 / 51, browser_v52 45 / 45,
                            browser_v3 49 / 49, drift 12 / 12, firmware-host 38 / 38, device-journey with the
                            synthetic device). Produced after tagging, so not inside the archive.
                          aeris-site-v6.0.archive-bundle-check.json - the delivered archive equals the tagged commit
                            (1 183 = 1 183 files, no byte difference) against aeris-site-v6.0-git.bundle
                            (SHA-256 62cf7a2d8a1dc155324e0e9095d0a51e4b9709082c74423a622b7947c95ed0f0; verifies in an
                            empty repository; 67 commits).

These logs show software behaviour against synthetic devices and emulators. They are not hardware tests and do not
show that any physical cube balances: see hardware/COMMISSIONING.md in the archive.

"""F1 probe (extends the review's probe to both source orders, a reconnect and a second generation), using only
interfaces that exist in v5 and v5.1 (TelemetryHub, recording_to_ndjson, hello_message, dumps, validate_recording).

    AERIS_ROOT=<repository> python f1_mixed_source_probe.py > result.json     (the backend's Python)

For each scenario a recording is made over the listed source segments, exported as NDJSON, replayed through a fresh
hub as a file replay, recorded again, and that re-recording exported and replayed again. The failure condition of
review finding F1: a recording that contains synthetic data produces, anywhere downstream, a hello or a recording
that is not synthetic. Every "physical" source is an ARTIFICIAL TEST FIXTURE; nothing comes from hardware.
Exit code 0 when no scenario fails, 1 otherwise."""
import json
import os
import sys
from pathlib import Path

ROOT = Path(os.environ["AERIS_ROOT"]).resolve()
sys.path.insert(0, str(ROOT / "backend"))
from aeris_backend.hardware.ingest import validate_recording          # noqa: E402
from aeris_backend.telemetry.protocol import dumps, hello_message      # noqa: E402
from aeris_backend.telemetry.stream import TelemetryHub, recording_to_ndjson   # noqa: E402

PHYS = hello_message("test-fixture-physical-declaration", "physical", "test-only", False, "corner", 100)
EMU = hello_message("test-emulator", "emulator", "test-only", True, "corner", 100)


def feed(h, n0, count, t0, now):
    for k in range(count):
        r = h.feed_message({"type": "frame", "seq": n0 + k, "t": t0 + 0.01 * k, "q": [1, 0, 0, 0], "w": [0, 0, 0]}, now + 0.01 * k)
        assert r == "frame", r


def record(hellos):
    h = TelemetryHub()
    h.on_connect({"kind": "tcp", "address": "test-only"}, 0)
    h.feed_line(dumps(hellos[0]), 0)
    feed(h, 0, 2, 0.0, 0.0)
    h.start_recording("F1 probe fixture, not a measurement", 0)
    feed(h, 2, 2, 0.02, 0.02)
    for k, hel in enumerate(hellos[1:], 1):
        h.on_disconnect("source replaced (probe)", k)
        h.on_connect({"kind": "tcp", "address": "test-only"}, k + 0.1)
        h.feed_line(dumps(hel), k + 0.1)
        feed(h, 0, 2, 0.0, k + 0.2)
    return h.stop_recording(10)


def replay(nd):
    h = TelemetryHub()
    h.on_connect({"kind": "file", "address": "probe-export"}, 100)
    lines = nd.splitlines()
    h.feed_line(lines[0], 100)
    labels = [h.provenance()["label"]]
    h.start_recording("re-recorded replay (probe)", 100)
    for ln in lines[1:]:
        if h.feed_line(ln, 100.5) == "hello":
            labels.append(h.provenance()["label"])
    return labels, h.stop_recording(101)


def hellos_of(nd):
    return [json.loads(ln) for ln in nd.splitlines() if json.loads(ln).get("type") == "hello"]


out, failed = {"root": str(ROOT), "scenarios": {}}, 0
for name, seq in (("physical-then-synthetic", [PHYS, EMU]), ("synthetic-then-physical", [EMU, PHYS]),
                  ("physical-reconnect-then-synthetic", [PHYS, PHYS, EMU])):
    doc = record(seq)
    nd = recording_to_ndjson(doc)
    labels, redoc = replay(nd)
    nd2 = recording_to_ndjson(redoc)
    labels2, redoc2 = replay(nd2)
    exported = [(h["device"]["kind"], h["synthetic"]) for h in hellos_of(nd)] + [(h["device"]["kind"], h["synthetic"]) for h in hellos_of(nd2)]
    fail = [x for x in exported if x[1] is not True] + ([("rerecorded", redoc["synthetic"])] if redoc["synthetic"] is not True else []) \
        + ([("rerecorded-2", redoc2["synthetic"])] if redoc2["synthetic"] is not True else [])
    failed += bool(fail)
    out["scenarios"][name] = {"original_synthetic": doc["synthetic"], "original_valid": validate_recording(doc)["ok"],
                              "exported_hellos": exported, "replay_labels": labels + labels2,
                              "rerecorded_synthetic": redoc["synthetic"], "rerecorded_valid": validate_recording(redoc)["ok"],
                              "second_generation_synthetic": redoc2["synthetic"], "fails_F1": fail}
out["scenarios_failing_F1"] = failed
print(json.dumps(out, indent=1))
sys.exit(1 if failed else 0)

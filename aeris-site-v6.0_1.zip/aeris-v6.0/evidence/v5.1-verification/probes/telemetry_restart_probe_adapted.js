// Independent test of the production telemetry adapter's deduplication across backend restarts.
const path=require('path');
// ADAPTED (paths only): the repository to probe comes from AERIS_ROOT; the probe logic is unchanged.
const root=path.resolve(process.env.AERIS_ROOT);
const adapter=require(root+'/site/js/adapters/hardware-telemetry.js');
const sockets=[], pending=[], seen=[];
class Socket { constructor(url) { sockets.push(this); } close() {} }
const api={ configured:()=>true, available:()=>({ok:true}), capabilities:()=>({reported:true,telemetry:{available:true}}), wsUrl:'ws://test-only', request:async(method,path)=>path.includes('/frames')?{frames:[],last_n:2,missed:0}:{last_n:2} };
adapter.bind(api);
(async()=>{
const live=adapter.live(e=>seen.push(e),{WebSocket:Socket,wait:(ms,fn)=>{pending.push(fn);return 0;}});
sockets[0].onopen();
sockets[0].onmessage({data:JSON.stringify({type:'frames',frames:[{n:1000,t:10}],dropped:0})});
sockets[0].onclose({code:1006});
await new Promise(resolve=>setImmediate(resolve));
pending.shift()();
sockets[1].onopen();
sockets[1].onmessage({data:JSON.stringify({type:'status',status:{last_n:0}})});
sockets[1].onmessage({data:JSON.stringify({type:'frames',frames:[{n:1,t:0},{n:2,t:0.01}],dropped:0})});
const out={before_restart_lastN:1000,after_restart_server_n:2,after_restart_adapter_lastN:live.lastN(),delivered_frame_indices:seen.filter(e=>e.type==='frames').flatMap(e=>e.frames.map(f=>f.n)),note:'transport fixture only; production adapter unchanged'};
live.close();console.log(JSON.stringify(out,null,2));
})();

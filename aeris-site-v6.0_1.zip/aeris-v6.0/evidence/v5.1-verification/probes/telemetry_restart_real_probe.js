/* F2 probe with REAL processes: the backend is stopped and started again on the same port and database while the
   site's real adapters (research-api.js + hardware-telemetry.js, loaded in Node ≥ 22 with its global WebSocket) keep
   running, like a browser tab that stays open. Two consumers run at the same time: one on the WebSocket, one forced
   to poll (its WebSocket constructor always throws). The source is the SYNTHETIC emulator; nothing is physical.

     AERIS_ROOT=<repository> AERIS_PYTHON=<backend python> node telemetry_restart_real_probe.js > result.json

   Measured after the restart (the failure conditions of review finding F2):
     replay   a short replay (a recording of ~0.5 s stored before the restart) is connected on the new backend; its
              frames (hub index n = 1…~50) must reach both consumers within 8 s
     live     the emulator is connected on the new backend; new frames must reach both consumers within 3 s
   Exit code 0 when both consumers got both, 1 otherwise, 2 when the processes could not be started. */
"use strict";
var path = require("path"), fs = require("fs"), os = require("os"), cp = require("child_process");
var ROOT = path.resolve(process.env.AERIS_ROOT || path.join(__dirname, "..", "..")), SITE = path.join(ROOT, "site"), BACKEND = path.join(ROOT, "backend");
global.window = { AERIS_CONFIG: { researchApi: { baseUrl: null } } };
var J = function (p) { return require(path.join(SITE, "js", p)); };
global.AERIS_SCHEMA = J("platform/schema.js");
global.AERIS_JOBS = J("platform/jobs.js");
global.AERIS_IDS = J("platform/ids.js");
global.AERIS_TWIN = J("core.js");
global.AERIS_EVENTS = J("platform/events.js");
global.AERIS_CFG = J("platform/config.js");
global.AERIS_RUNS = J("runs.js");
var RA = J("adapters/research-api.js"), H = J("adapters/hardware-telemetry.js");
var PY = process.env.AERIS_PYTHON || "python3";
var PORT = 21000 + Math.floor(Math.random() * 2000), EPORT = PORT + 2500, BASE = "http://127.0.0.1:" + PORT;
var DB = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "aeris-f2-")), "f2.sqlite3");
var procs = [];
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
function spawn(args, marker) {
  var p = cp.spawn(PY, args, { cwd: BACKEND, env: Object.assign({}, process.env, { PYTHONUNBUFFERED: "1" }) }), out = "";
  p.stdout.on("data", function (d) { out += d; }); p.stderr.on("data", function (d) { out += d; });
  procs.push(p); p.outText = function () { return out; };
  return p;
}
function waitHealth(ms) {
  var t0 = Date.now();
  return new Promise(function (res, rej) { (function w() { fetch(BASE + "/api/v1/health").then(function (r) { return r.json(); }).then(function (h) { if (h.status === "ok") res(h); else throw 0; })
    .catch(function () { if (Date.now() - t0 > (ms || 40000)) rej(new Error("backend not healthy")); else setTimeout(w, 150); }); })(); });
}
function startBackend() { var p = spawn(["-m", "aeris_backend.api.main", "--port", String(PORT), "--db", DB, "--workers", "1", "--log-level", "warning"]); return waitHealth().then(function () { return p; }); }
function stop(p) { return new Promise(function (res) { if (p.exitCode !== null || p.signalCode !== null) return res(); p.once("exit", function () { res(); }); p.kill("SIGTERM"); setTimeout(function () { if (p.exitCode === null && p.signalCode === null) p.kill("SIGKILL"); }, 8000); }); }
function waitFor(pred, ms) { var t0 = Date.now(); return new Promise(function (res) { (function w() { var v = pred(); if (v) return res(v); if (Date.now() - t0 > ms) return res(null); setTimeout(w, 50); })(); }); }

function consumer(label, opts) {
  var c = { label: label, frames: [], events: [], mark: 0 };
  c.live = H.live(function (ev) {
    if (ev.type === "frames") ev.frames.forEach(function (f) { c.frames.push({ n: f.n, t: f.t, at: Date.now() }); });
    else if (ev.type !== "status") c.events.push({ type: ev.type, kind: ev.kind || null, at: Date.now() });
  }, opts);
  c.since = function (t) { return c.frames.filter(function (f) { return f.at >= t; }); };
  return c;
}

var out = { root: ROOT, python: PY, note: "real backend processes, same port and database; SYNTHETIC emulator; no physical data" };
var em, A, B, api, ws, poll;
em = spawn(["-m", "aeris_backend.telemetry.emulator", "--port", String(EPORT), "--rate", "100"]);
waitFor(function () { return /telemetry emulator on/.test(em.outText()); }, 30000).then(function (ok) {
  if (!ok) throw new Error("emulator did not start: " + em.outText().slice(-300));
  return startBackend();
}).then(function (p) {
  A = p;
  api = RA.create({ baseUrl: BASE, wsUrl: BASE.replace(/^http/, "ws"), pollMs: 100, timeoutMs: 10000 });
  return api.probe();
}).then(function () {
  H.bind(api);
  return H.connect({ source: "tcp", host: "127.0.0.1", port: EPORT });
}).then(function () {
  ws = consumer("websocket", { pollMs: 100 });
  poll = consumer("polling", { pollMs: 100, WebSocket: function () { throw new Error("WebSocket disabled for this consumer"); } });
  return waitFor(function () { return ws.live.lastN() >= 400 && poll.live.lastN() >= 400; }, 30000);
}).then(function (ok) {
  if (!ok) throw new Error("consumers did not reach 400 frames before the restart");
  return H.startRecording("F2 probe: short synthetic recording").then(function () { return sleep(500); }).then(function () { return H.stopRecording(); });
}).then(function (rec) {
  out.recording = { id: rec.id, samples: rec.quality.n, synthetic: rec.synthetic };
  out.before_restart = { websocket_lastN: ws.live.lastN(), polling_lastN: poll.live.lastN() };
  return stop(A);
}).then(function () {
  return startBackend();
}).then(function (p) {
  B = p;
  var t0 = Date.now();
  out.restart_ready_at = t0;
  return H.connect({ source: "recording", recording_id: out.recording.id, speed: 1 }).then(function () {
    return waitFor(function () { return ws.since(t0).length >= out.recording.samples && poll.since(t0).length >= out.recording.samples; }, 8000);
  }).then(function () {
    var f = function (c) { var s = c.since(t0); return { delivered: s.length, first_n: s.length ? s[0].n : null, last_n: s.length ? s[s.length - 1].n : null, first_after_ms: s.length ? s[0].at - t0 : null, adapter_lastN: c.live.lastN() }; };
    out.after_restart_replay = { expected_frames: out.recording.samples, websocket: f(ws), polling: f(poll) };
    var t1 = Date.now();
    return H.connect({ source: "tcp", host: "127.0.0.1", port: EPORT }).then(function () { return waitFor(function () { return ws.since(t1).length >= 20 && poll.since(t1).length >= 20; }, 3000); })
      .then(function () { var g = function (c) { var s = c.since(t1); return { delivered_within_3s: s.length, first_n: s.length ? s[0].n : null, first_after_ms: s.length ? s[0].at - t1 : null, adapter_lastN: c.live.lastN() }; };
        out.after_restart_live = { websocket: g(ws), polling: g(poll) }; });
  });
}).then(function () {
  var r = out.after_restart_replay, l = out.after_restart_live;
  out.ok = r.websocket.delivered >= r.expected_frames && r.polling.delivered >= r.expected_frames && l.websocket.delivered_within_3s > 0 && l.polling.delivered_within_3s > 0;
  out.events = { websocket: ws.events, polling: poll.events.slice(0, 12) };
  return finish(out.ok ? 0 : 1);
}).catch(function (e) { out.error = String(e && e.stack || e); return finish(2); });

function finish(code) {
  try { if (ws) ws.live.close(); if (poll) poll.live.close(); } catch (e) { /* ignore */ }
  return Promise.all(procs.map(stop)).then(function () { console.log(JSON.stringify(out, null, 1)); process.exit(code); });
}

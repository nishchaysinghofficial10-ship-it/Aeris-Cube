"""F4 probe: what a cross-platform last-digit difference does to the reproduction test.

    AERIS_ROOT=<repository> python f4_cross_platform_emulation.py      (run with the backend's Python)

The review measured, on macOS arm64, a largest sample difference of 2.053914e-15 between the Linux-generated
fixture 'corner_custom' and its reproduction (same outcome, 31 rows, 39 columns within tolerance). This machine
reproduces that fixture bit for bit, so the difference is EMULATED here: one sample of a copy of the fixture is
moved by exactly 2.053914e-15, and the repository's own test function for that fixture is run against the copy.
A second copy moved by a meaningful amount (relative 1e-3) and a third with a changed outcome are the controls.
Prints one JSON object: the verdict of the application and whether the test function passed or raised."""
import copy
import importlib.util
import json
import os
import sys
import traceback
from pathlib import Path

ROOT = Path(os.environ["AERIS_ROOT"]).resolve()
sys.path.insert(0, str(ROOT / "backend"))
os.chdir(ROOT / "backend")
from aeris_backend.experiments.records import build_record            # noqa: E402
from aeris_backend.experiments.reproduce import compare_reproduction, reproduction_config   # noqa: E402
from aeris_backend.simulation import simulate                          # noqa: E402

spec = importlib.util.spec_from_file_location("test_reproduction_under_probe", ROOT / "backend" / "tests" / "test_reproduction.py")
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
NAME = "corner_custom"
orig = T.RECS[NAME]
col = next(k for k in orig["samples"]["cols"] if k != "t" and any(isinstance(x, float) and x != 0 for x in orig["samples"]["cols"][k]))
i = next(j for j, x in enumerate(orig["samples"]["cols"][col]) if isinstance(x, float) and x != 0)


def variant(kind):
    r = copy.deepcopy(orig)
    if kind == "mac_like_2e-15":
        r["samples"]["cols"][col][i] += 2.053914e-15
    elif kind == "meaningful_rel_1e-3":
        r["samples"]["cols"][col][i] *= 1 + 1e-3
    elif kind == "outcome_changed":
        r["outcome"] = dict(r["outcome"], code="fallen" if r["outcome"]["code"] != "fallen" else "recovered")
    return r


def run_test_function(rec):
    """The repository's test function for this fixture, with the fixture replaced by `rec`."""
    saved = T.RECS[NAME]
    T.RECS[NAME] = rec
    try:
        fn = getattr(T, "test_v4_records_reproduce_or_explain_why_not", None) or getattr(T, "test_v4_fixtures_reproduce_within_the_documented_tolerance")
        fn(NAME)
        return {"passed": True}
    except AssertionError as e:
        return {"passed": False, "assertion": (str(e) or traceback.format_exc().strip().splitlines()[-1])[:300]}
    finally:
        T.RECS[NAME] = saved


cfg, _ = reproduction_config(orig)
out = {"root": str(ROOT), "fixture": NAME, "perturbed_sample": {"column": col, "row": i}, "cases": {}}
for kind in ("unchanged", "mac_like_2e-15", "meaningful_rel_1e-3", "outcome_changed"):
    rec = orig if kind == "unchanged" else variant(kind)
    new = build_record(simulate(cfg), {}, experiment_id="AERIS-EXP-199999")
    v = compare_reproduction(rec, new, rec["id"])
    out["cases"][kind] = {"application_verdict": v["verdict"], "max_abs_diff": v["max_abs_diff"], "same_outcome": v["same_outcome"],
                          "test_function": run_test_function(rec)}
print(json.dumps(out, indent=1))

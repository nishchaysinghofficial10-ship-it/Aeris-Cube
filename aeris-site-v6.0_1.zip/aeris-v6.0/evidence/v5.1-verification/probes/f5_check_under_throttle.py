"""F5 evidence: the v5 COM-preview check and the v5.1 check side by side under Chrome DevTools CPU throttling.

    AERIS_ROOT=<repository> python f5_check_under_throttle.py [rate ...]      (default rates 1 4 8 16 24; Playwright)

The v5.1 check's JavaScript (COM_STATE, com_agree, RUN_COM, COM_ZERO) is taken verbatim from AERIS_ROOT's
site/tests/browser_v3.py, so this measures the code under test. DEMO mode, reduced motion, one short DEMO run first
(for the replay transition). For each rate and value (4 mm, then 5 mm):
  v5 check    after a fixed 500 ms: the label contains "<v>.00 mm" and SOME Δr arrow exists (v5's assertion);
              'false_pass' marks a v5 pass while the view still showed another vector
  v5.1 check  bounded wait (15 s) until input, draft, validated draft, label and the view's COM vector agree
Then replay → setup and back to 0 mm with the v5.1 checks. Prints one JSON object. Synthetic UI state only."""
import asyncio
import json
import os
import re
import socket
import subprocess
import sys
import time
from pathlib import Path

from playwright.async_api import async_playwright

ROOT = Path(os.environ["AERIS_ROOT"]).resolve()
SRC = (ROOT / "site" / "tests" / "browser_v3.py").read_text()
block = SRC[SRC.index("COM_STATE = "):SRC.index("async def main():")]
NS = {}
exec(block, NS)                                   # COM_STATE, com_agree, RUN_COM, COM_ZERO exactly as the suite has them
COM_STATE, com_agree, RUN_COM, COM_ZERO = NS["COM_STATE"], NS["com_agree"], NS["RUN_COM"], NS["COM_ZERO"]
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


async def wait_for(page, js, timeout, step=50):
    t0 = time.time()
    while (time.time() - t0) * 1000 < timeout:
        try:
            if await page.evaluate(js):
                return round(time.time() - t0, 3)
        except Exception:
            pass
        await page.wait_for_timeout(step)
    return None


async def one(br, origin, rate):
    ctx = await br.new_context(viewport={"width": 1440, "height": 900}, reduced_motion="reduce")
    await ctx.add_init_script("window.AERIS_CONFIG = {researchApi: {baseUrl: null}};")
    page = await ctx.new_page()
    await page.goto(origin + "/index.html#lab", wait_until="load")
    await wait_for(page, "!!(window.AERIS_DEBUG && AERIS_DEBUG.W && AERIS_DEBUG.W.viewer && window.Workspace)", 30000)
    await page.evaluate("Workspace.openConfig((()=>{const c=AERIS_TWIN.defaultConfig('corner'); c.duration_s=1; return c})(), {run:true})")
    await wait_for(page, "!!AERIS_DEBUG.W.run && !AERIS_DEBUG.W.busy", 30000)
    await page.click("#lt-create")
    await page.evaluate("document.getElementById('grpAsym') && (document.getElementById('grpAsym').open = true)")
    await page.click("#vmSetup")
    await wait_for(page, "AERIS_DEBUG.W.viewMode === 'setup' && !!document.querySelector('[data-path=\"comShift_m.1\"]')", 10000)
    cdp = await ctx.new_cdp_session(page)
    await cdp.send("Emulation.setCPUThrottlingRate", {"rate": rate})
    res = {"rate": rate}
    for mm in (4, 5):
        t0 = time.time()
        await page.fill('[data-path="comShift_m.1"]', str(mm))
        await page.wait_for_timeout(500)                                   # the v5 check's fixed pause (reproduced on purpose)
        at500 = await page.evaluate(COM_STATE)
        v5 = ("%.2f mm" % mm) in at500["label"] and at500["com"] is not None
        stale = v5 and abs((at500["com"] or {}).get("dr_mm", [0, 0, 0])[1] - mm) > 1e-6
        rest = await wait_for(page, com_agree(mm), 15000)
        res[f"{mm}mm"] = {"v5_check_passes": v5, "v5_false_pass_on_a_stale_vector": stale, "v51_check_passes": rest is not None,
                          "v51_agree_after_s": None if rest is None else round(time.time() - t0, 3), "state_at_500ms": at500, "final": await page.evaluate(COM_STATE)}
    await page.click("#vmReplay")
    r1 = await wait_for(page, RUN_COM, 15000)
    await page.click("#vmSetup")
    r2 = await wait_for(page, com_agree(5), 15000)
    await page.fill('[data-path="comShift_m.1"]', "0")
    r3 = await wait_for(page, COM_ZERO, 15000)
    res["replay_then_setup_then_zero_v51_checks_pass"] = [r1 is not None, r2 is not None, r3 is not None]
    await cdp.send("Emulation.setCPUThrottlingRate", {"rate": 1})
    await ctx.close()
    return res


async def main():
    rates = [float(x) for x in sys.argv[1:]] or [1, 4, 8, 16, 24]
    port = free_port()
    web = subprocess.Popen([sys.executable, "-m", "http.server", str(port), "--bind", "127.0.0.1", "--directory", str(ROOT / "site")],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    out = {"root": str(ROOT), "check_source": "site/tests/browser_v3.py (COM_STATE, com_agree, RUN_COM, COM_ZERO)", "runs": []}
    try:
        time.sleep(0.8)
        async with async_playwright() as p:
            br = await p.chromium.launch(args=ARGS)
            for r in rates:
                out["runs"].append(await one(br, f"http://127.0.0.1:{port}", r))
            await br.close()
    finally:
        web.terminate()
    out["summary"] = [{"rate": x["rate"], **{f"{mm}mm": {"v5": x[f"{mm}mm"]["v5_check_passes"], "v5_false_pass": x[f"{mm}mm"]["v5_false_pass_on_a_stale_vector"],
                                                      "v51": x[f"{mm}mm"]["v51_check_passes"], "agree_s": x[f"{mm}mm"]["v51_agree_after_s"]} for mm in (4, 5)},
                       "transitions_v51": x["replay_then_setup_then_zero_v51_checks_pass"]} for x in out["runs"]]
    print(json.dumps(out, indent=1))


asyncio.run(main())

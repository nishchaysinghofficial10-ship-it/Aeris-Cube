"""Independent v5 review probes; synthetic fixtures only, no real hardware."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

# ADAPTED (paths only): the reviewer's checkout lived under work/v5-review/aeris-v5 on the Mac; here the repository
# to probe is given by AERIS_ROOT, and the JSON result goes to AERIS_PROBE_OUT. The probe logic is unchanged.
ROOT = Path(os.environ['AERIS_ROOT']).resolve()
sys.path.insert(0, str(ROOT / 'backend'))
from aeris_backend.telemetry.stream import TelemetryHub, recording_to_ndjson
from aeris_backend.telemetry.protocol import hello_message, dumps
from aeris_backend.hardware.ingest import validate_recording

# A recording spans a source change, supported by the hub/bridge.
# The first hello declares physical only to test labels; every fixture is synthetic.
h = TelemetryHub()
h.on_connect({'kind':'tcp', 'address':'test-only'}, 0)
h.feed_line(dumps(hello_message('test-fixture-physical-declaration','physical','test-only',False,'corner',100)),0)
h.start_recording('independent test fixture, not physical measurements',0)
for n in range(2):
    assert h.feed_message({'type':'frame','seq':n,'t':n*.01,'q':[1,0,0,0],'w':[0,0,0]},n*.01)=='frame'
h.on_disconnect('test source switch',.02)
h.on_connect({'kind':'tcp','address':'test-emulator'},.03)
h.feed_line(dumps(hello_message('test-emulator','emulator','test-only',True,'corner',100)),.03)
for n in range(2):
    assert h.feed_message({'type':'frame','seq':n,'t':n*.01,'q':[1,0,0,0],'w':[0,0,0]},.03+n*.01)=='frame'
doc=h.stop_recording(.05)
nd=recording_to_ndjson(doc)
replay=TelemetryHub()
replay.on_connect({'kind':'file','address':'test-round-trip'},1)
lines=nd.splitlines()
assert replay.feed_line(lines[0],1)=='hello'
replay.start_recording('re-recorded synthetic fixture',1)
for line in lines[1:-1]: replay.feed_line(line,1)
redoc=replay.stop_recording(2)
result={'telemetry_mixed_source':{
    'original_synthetic':doc['synthetic'],
    'original_validation_ok':validate_recording(doc)['ok'],
    'exported_hello':json.loads(lines[0]),
    'replay_provenance':replay.provenance(),
    'rerecorded_synthetic':redoc['synthetic'],
    'rerecorded_validation_ok':validate_recording(redoc)['ok'],
    'note':'all fixtures fabricated strictly for this software probe; no real physical data involved'}}
# CI invokes --browser-python backend/.venv/bin/python relative to repository root.
# It passes the runner import check then cannot be found under the site's cwd.
with tempfile.TemporaryDirectory(prefix='aeris-v5-ci-probe-') as td:
    r=Path(td)
    (r/'scripts').mkdir(); (r/'site/tests').mkdir(parents=True); (r/'backend').mkdir()
    (r/'scripts/run_tests.py').write_bytes((ROOT/'scripts/run_tests.py').read_bytes())
    (r/'site/tests/browser_probe.py').write_text('print("1 / 1 checks passed")\n')
    (r/'backend/.venv').symlink_to(sys.prefix, target_is_directory=True)
    p=subprocess.run([sys.executable,'scripts/run_tests.py','--skip','backend,js,live','--browser-python','backend/.venv/bin/python'],cwd=r,text=True,capture_output=True)
    result['ci_relative_browser_path']={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(OUT:=Path(os.environ.get('AERIS_PROBE_OUT', str(Path(__file__).parent/'review-probes.json')))).write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))

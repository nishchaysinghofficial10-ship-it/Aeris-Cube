"""F2 diagnostic: one tab at a time (polling, then WebSocket), a 5 Hz file replay connected from the Telemetry tab;
logs the telemetry requests and the displayed frame (latest n, 3-D view n) with wall-clock ms after the Connect click.
    AERIS_ROOT=<repository> AERIS_PYTHON=<backend python> python f2_display_latency_diagnostic.py    (needs Playwright)
"""
import asyncio, json, sys, time, pathlib, subprocess, tempfile
sys.path.insert(0, str(pathlib.Path(__import__("os").environ.get("AERIS_ROOT", ".")) / "site" / "tests"))
import browser_v51 as B
from playwright.async_api import async_playwright

async def main():
    tmp = pathlib.Path(tempfile.mkdtemp()); (tmp / "telemetry").mkdir()
    st = {"py": B.backend_python(), "bport": B.free_port(), "sport": B.free_port(), "db": str(tmp / "d.sqlite3"), "teldir": str(tmp / "telemetry")}
    st["base"], st["origin"] = f"http://127.0.0.1:{st['bport']}", f"http://127.0.0.1:{st['sport']}"
    subprocess.run([st["py"], "-m", "aeris_backend.telemetry.emulator", "--write", str(tmp / "telemetry" / "session-low.ndjson"), "--frames", "12", "--rate", "5"], cwd=str(B.BACKEND), stdout=subprocess.DEVNULL)
    st["be"] = B.start_backend(st)
    web = subprocess.Popen([sys.executable, "-m", "http.server", str(st["sport"]), "--bind", "127.0.0.1", "--directory", str(B.SITE)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    B.wait_http(st["origin"] + "/index.html"); B.wait_http(st["base"] + "/api/v1/health")
    async with async_playwright() as p:
        br = await p.chromium.launch(args=B.ARGS)
        for init, label in ((B.NO_WS, "polling"), (B.TRACK_WS, "websocket")):
            ctx, page, errs, ok = await B.open_tab(br, st, init)
            await page.wait_for_timeout(1500)
            log = []
            t0 = time.time()
            page.on("request", lambda r: log.append((round((time.time()-t0)*1000), "req", r.url.split("/api/v1")[-1][:60])) if "/telemetry/" in r.url else None)
            page.on("response", lambda r: log.append((round((time.time()-t0)*1000), "resp", r.url.split("/api/v1")[-1][:60])) if "/telemetry/" in r.url else None)
            await page.click('input[name="tmKind"][value="file"]')
            await B.wait_for(page, "!!document.querySelector('#tmFile option[value=\"session-low.ndjson\"]')", 10000)
            await page.select_option("#tmFile", "session-low.ndjson"); await page.fill("#tmSpeed", "1")
            t0 = time.time(); log.clear()
            await page.click("#tmConnect")
            tc = round((time.time()-t0)*1000)
            prev = None
            while time.time() - t0 < 4:
                s = await page.evaluate("(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return [s.latest && s.latest.n, s.viewer && s.viewer.n, s.transport, document.visibilityState]; })()")
                if s != prev: log.append((round((time.time()-t0)*1000), "snap", s)); prev = s
                await page.wait_for_timeout(20)
            print(label, "click returned after", tc, "ms")
            for x in sorted(log, key=lambda x: x[0])[:40]: print("  ", x)
            await page.click("#tmDisconnect"); await ctx.close()
        await br.close()
    st["be"].terminate(); web.terminate()
asyncio.run(main())

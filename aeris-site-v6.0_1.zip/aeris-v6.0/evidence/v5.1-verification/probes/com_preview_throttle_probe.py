"""F5 probe: the COM-shift preview under a slow main thread (Chrome DevTools CPU throttling), DEMO mode, reduced motion.

    AERIS_SITE=<site directory> python3 com_preview_throttle_probe.py [rate ...]   (default rates: 1 4 8 16)

For each CPU slow-down rate, the setup preview is shown, a 4 mm COM shift is typed into comShift_m.1 and the page is
read (a) after the fixed 500 ms pause of the v5 check and (b) as soon as the input, the draft, the mass-asymmetry
label and the 3-D view's COM vector agree (bounded at 60 s), then the same for 5 mm. The v5 check passes only when
(a) already shows "4.00 mm" and a COM arrow. Prints one JSON object. Synthetic UI state only.
"""
import asyncio
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

from playwright.async_api import async_playwright

SITE = Path(os.environ["AERIS_SITE"]).resolve()
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
STATE = """(() => { const W = AERIS_DEBUG.W, v = W.viewer && W.viewer.snapshot(), el = document.querySelector('[data-path="comShift_m.1"]');
  return { input: el ? el.value : null, draft: W.draft.comShift_m, validated: W.draftVal && W.draftVal.config.comShift_m,
           label: (document.getElementById('asymCnt') || {}).textContent || '', com: v && v.comShift, viewMode: W.viewMode }; })()"""


def agree_js(mm):
    return ("(() => { const s = %s; const want = %r; if (!s.com || !s.draft || !s.validated) return false;"
            " return Number(s.input) === want && Math.abs(s.draft[1] - want / 1000) < 1e-12 && Math.abs(s.validated[1] - want / 1000) < 1e-12"
            " && s.label === '|\\u0394r| ' + want.toFixed(2) + ' mm' && Math.abs(s.com.dr_mm[1] - want) < 1e-6"
            " && Math.abs(s.com.dr_mm[0]) < 1e-6 && Math.abs(s.com.dr_mm[2]) < 1e-6 && s.viewMode === 'setup'; })()") % (STATE, float(mm))


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


async def one(br, origin, rate):
    ctx = await br.new_context(viewport={"width": 1440, "height": 900}, reduced_motion="reduce")
    await ctx.add_init_script("window.AERIS_CONFIG = {researchApi: {baseUrl: null}};")
    page = await ctx.new_page()
    await page.goto(origin + "/index.html#lab", wait_until="load")
    for _ in range(200):
        if await page.evaluate("!!(window.AERIS_DEBUG && AERIS_DEBUG.W && AERIS_DEBUG.W.viewer)"):
            break
        await page.wait_for_timeout(100)
    await page.click("#lt-create")
    await page.evaluate("document.getElementById('grpAsym') && (document.getElementById('grpAsym').open = true)")
    await page.click("#vmSetup")
    await page.wait_for_timeout(300)
    cdp = await ctx.new_cdp_session(page)
    await cdp.send("Emulation.setCPUThrottlingRate", {"rate": rate})
    res = {"rate": rate}
    for mm in (4, 5):
        t0 = time.time()
        await page.fill('[data-path="comShift_m.1"]', str(mm))
        await page.wait_for_timeout(500)                                   # the v5 check's fixed pause (reproduced on purpose)
        at500 = await page.evaluate(STATE)
        v5_check = ("%.2f mm" % mm) in at500["label"] and at500["com"] is not None
        agreed = None
        while time.time() - t0 < 60:
            if await page.evaluate(agree_js(mm)):
                agreed = round(time.time() - t0, 3)
                break
            await page.wait_for_timeout(50)
        res[f"{mm}mm"] = {"at_500ms": at500, "v5_fixed_pause_check_passes": v5_check, "all_agree_after_s": agreed,
                          "final": await page.evaluate(STATE)}
    await cdp.send("Emulation.setCPUThrottlingRate", {"rate": 1})
    await ctx.close()
    return res


async def main():
    rates = [float(x) for x in sys.argv[1:]] or [1, 4, 8, 16]
    port = free_port()
    web = subprocess.Popen([sys.executable, "-m", "http.server", str(port), "--bind", "127.0.0.1", "--directory", str(SITE)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        time.sleep(0.8)
        async with async_playwright() as p:
            br = await p.chromium.launch(args=ARGS)
            out = {"site": str(SITE), "runs": []}
            for r in rates:
                out["runs"].append(await one(br, f"http://127.0.0.1:{port}", r))
            await br.close()
    finally:
        web.terminate()
    print(json.dumps(out, indent=1))


asyncio.run(main())

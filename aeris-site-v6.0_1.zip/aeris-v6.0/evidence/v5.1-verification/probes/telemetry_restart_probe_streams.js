// The review's F2 transport-fixture probe (telemetry_restart_probe.js), extended to the v5.1 contract: the same
// sequence — 1000 frames seen, the socket drops, the backend comes back with its counter at 0 and sends n = 1, 2 —
// but every message now names its stream (status.stream_id, the "stream" of a frames batch, stream_id of a poll
// answer), as a v5.1 backend sends it. The failure condition of finding F2 is kept: the frames of the new backend
// process must be delivered. Two further conditions: a late message from the stream the client has left is ignored,
// and a reconnect to the SAME stream still delivers each frame once, in order.
//
//     AERIS_ROOT=<repository> node telemetry_restart_probe_streams.js      exit 0 = all conditions hold, 1 = F2 reproduced
//
// Transport fixture only (no backend, no device); the production adapter is loaded unchanged from AERIS_ROOT.
"use strict";
const path = require("path");
const root = path.resolve(process.env.AERIS_ROOT);
const adapter = require(root + "/site/js/adapters/hardware-telemetry.js");
const sockets = [], pending = [], seen = [];
let pollAnswer = { frames: [], last_n: 1000, missed: 0, stream_id: "A" };
class Socket { constructor(url) { sockets.push(this); } close() {} }
const api = { configured: () => true, available: () => ({ ok: true }), capabilities: () => ({ reported: true, telemetry: { available: true } }), wsUrl: "ws://test-only",
  request: async (method, p) => p.includes("/frames") ? pollAnswer : { last_n: pollAnswer.last_n, stream_id: pollAnswer.stream_id } };
adapter.bind(api);
const tick = () => new Promise((resolve) => setImmediate(resolve));
const msg = (s, o) => s.onmessage({ data: JSON.stringify(o) });
(async () => {
  const live = adapter.live((e) => seen.push(e), { WebSocket: Socket, wait: (ms, fn) => { pending.push(fn); return 0; } });
  // stream A: the old backend process
  sockets[0].onopen();
  msg(sockets[0], { type: "status", status: { stream_id: "A", last_n: 999 } });
  msg(sockets[0], { type: "frames", stream: "A", frames: [{ n: 1000, t: 10 }], dropped: 0 });
  sockets[0].onclose({ code: 1006 });                       // the backend process stops
  pollAnswer = { frames: [], last_n: 2, missed: 0, stream_id: "B" }; // ... and a new one answers on the same port
  await tick(); await tick();
  pending.shift()();                                          // the adapter tries the WebSocket again
  sockets[1].onopen();
  msg(sockets[1], { type: "status", status: { stream_id: "B", last_n: 0 } });
  msg(sockets[1], { type: "frames", stream: "B", frames: [{ n: 1, t: 0 }, { n: 2, t: 0.01 }], dropped: 0 });
  msg(sockets[1], { type: "frames", stream: "A", frames: [{ n: 1001, t: 10.01 }], dropped: 0 });   // late message of the old stream
  sockets[1].onclose({ code: 1006 });                         // a drop WITHOUT a restart: stream B continues
  pollAnswer = { frames: [{ n: 2, t: 0.01 }, { n: 3, t: 0.02 }], last_n: 3, missed: 0, stream_id: "B" };
  await tick(); await tick();
  pending.shift()();
  sockets[2].onopen();
  msg(sockets[2], { type: "status", status: { stream_id: "B", last_n: 3 } });
  msg(sockets[2], { type: "frames", stream: "B", frames: [{ n: 3, t: 0.02 }, { n: 4, t: 0.03 }], dropped: 0 });
  const delivered = seen.filter((e) => e.type === "frames").flatMap((e) => e.frames.map((f) => f.n));
  const streamEvents = seen.filter((e) => e.type === "stream").map((e) => ({ stream: e.stream, previous: e.previous }));
  const firstNew = seen.findIndex((e) => e.type === "frames" && e.frames.some((f) => f.n === 1));
  const streamAt = seen.findIndex((e) => e.type === "stream");
  const checks = {
    new_process_frames_delivered: delivered.includes(1) && delivered.includes(2),
    display_told_to_reset_before_new_frames: streamAt >= 0 && firstNew > streamAt,
    late_old_stream_frame_ignored: !delivered.includes(1001),
    same_stream_reconnect_each_frame_once_in_order: JSON.stringify(delivered) === JSON.stringify([1000, 1, 2, 3, 4]),
  };
  const out = { before_restart_lastN: 1000, after_restart_server_n: 2, adapter_lastN: live.lastN(), adapter_stream: typeof live.streamId === "function" ? live.streamId() : "(no stream support)",
    delivered_frame_indices: delivered, stream_events: streamEvents, checks, ok: Object.values(checks).every(Boolean),
    note: "transport fixture only; production adapter unchanged; stream ids as a v5.1 backend sends them" };
  live.close();
  console.log(JSON.stringify(out, null, 2));
  process.exit(out.ok ? 0 : 1);
})();

#!/usr/bin/env python3
"""Run the v5.1 verification probes against one checkout and keep their outputs (review findings F1–F5 of v5).

    python3 evidence/v5.1-verification/run_probes.py --root <checkout> --label v5|v51 --python <backend python> [--only f1,f2,f3,f4,f5]

<checkout> is a repository or unpacked release (the unmodified v5 for the "before" evidence, this one for "after").
<backend python> must be able to import that checkout's backend dependencies (and Playwright for the browser probes).
Every probe keeps the failure condition of its finding (each probe's docstring states it); review_probes_adapted.py and
telemetry_restart_probe_adapted.js are the independent reviewer's probes with only their paths adapted. A probe that
cannot run (no Node, no Playwright, a check that does not exist in that version) is recorded as NOT RUN with the reason,
never as passed. Synthetic data and artificial test fixtures only. Writes results/<label>/<probe>.out and
results/<label>/index.json (exit code and the finding's condition per probe).
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
P = HERE / "probes"


def jload(text):
    try:
        i = text.index("{")
        return json.loads(text[i:])
    except (ValueError, json.JSONDecodeError):
        return None


def condition(name, code, out):
    """The finding's condition, read from the probe's own output: (holds, summary). holds=True means the defect is NOT present."""
    d = jload(out)
    if name == "review_probes":
        t = (d or {}).get("telemetry_mixed_source") or {}
        c = (d or {}).get("ci_relative_browser_path") or {}
        f1 = bool(t) and t.get("exported_hello", {}).get("synthetic") is True and t.get("rerecorded_synthetic") is True
        f3 = bool(c) and "Traceback" not in (c.get("stderr") or "") and "summary.json" in (c.get("stdout") or "")
        return f1 and f3, {"F1_export_and_rerecording_synthetic": f1, "F3_runner_completes_with_a_summary": f3, "F3_runner_exit": c.get("exit_code"),
                           "F3_runner_last_line": ((c.get("stdout") or "").strip().splitlines() or [""])[-1][:200], "F3_stderr_tail": (c.get("stderr") or "")[-200:]}
    if name == "f1_mixed_source":
        return code == 0, {"scenarios_failing_F1": (d or {}).get("scenarios_failing_F1"), "per_scenario": {k: v.get("fails_F1") for k, v in ((d or {}).get("scenarios") or {}).items()}}
    if name == "restart_reviewer_fixture":
        idx = (d or {}).get("delivered_frame_indices") or []
        return 1 in idx and 2 in idx, {"delivered_frame_indices": idx, "adapter_lastN_after_restart": (d or {}).get("after_restart_adapter_lastN")}
    if name == "restart_stream_ids":
        return code == 0, {"checks": (d or {}).get("checks"), "delivered": (d or {}).get("delivered_frame_indices")}
    if name == "restart_real_processes":
        r, l = (d or {}).get("after_restart_replay") or {}, (d or {}).get("after_restart_live") or {}
        return code == 0, {"replay": {k: (r.get(k) or {}).get("delivered") for k in ("websocket", "polling")}, "expected_replay_frames": r.get("expected_frames"),
                           "live_within_3s": {k: (l.get(k) or {}).get("delivered_within_3s") for k in ("websocket", "polling")}, "error": (d or {}).get("error")}
    if name == "f4_cross_platform":
        cs = (d or {}).get("cases") or {}
        summ = {k: {"verdict": v.get("application_verdict"), "test_passes": (v.get("test_function") or {}).get("passed")} for k, v in cs.items()}
        holds = bool(cs) and summ["unchanged"]["test_passes"] and summ["mac_like_2e-15"]["test_passes"] and not summ["meaningful_rel_1e-3"]["test_passes"] and not summ["outcome_changed"]["test_passes"]
        return holds, summ
    if name == "com_preview_throttle":
        runs = (d or {}).get("runs") or []
        summ = [{"rate": r["rate"], **{mm: {"v5_check": r[mm]["v5_fixed_pause_check_passes"], "agree_s": r[mm]["all_agree_after_s"]} for mm in ("4mm", "5mm")}} for r in runs]
        return None, {"note": "product behaviour under CPU throttling (identical code in v5 and v5.1); the v5 check's result per rate", "runs": summ}
    if name == "f5_check_under_throttle":
        s = (d or {}).get("summary") or []
        holds = bool(s) and all(x[mm]["v51"] for x in s for mm in ("4mm", "5mm")) and all(all(x["transitions_v51"]) for x in s)
        return holds, {"summary": s}
    if name == "f2_display_latency":
        return None, {"note": "diagnostic (timings); see the .out file"}
    return None, {}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--label", required=True)
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--only", default="f1,f2,f3,f4,f5")
    a = ap.parse_args()
    root = Path(a.root).resolve()
    py = os.path.abspath(a.python) if os.sep in a.python else shutil.which(a.python)
    node = shutil.which("node")
    out = HERE / "results" / a.label
    out.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, AERIS_ROOT=str(root), AERIS_PYTHON=py, AERIS_SITE=str(root / "site"), PYTHONUNBUFFERED="1",
               AERIS_PROBE_OUT=str(out / "review_probes.json"))
    has_pw = subprocess.run([py, "-c", "import playwright"], capture_output=True).returncode == 0
    has_v51_checks = "COM_STATE = " in (root / "site" / "tests" / "browser_v3.py").read_text() if (root / "site" / "tests" / "browser_v3.py").exists() else False
    has_v51_browser = (root / "site" / "tests" / "browser_v51.py").exists()
    probes = [  # (finding, name, command, needs)
        ("f1", "review_probes", [py, str(P / "review_probes_adapted.py")], []),
        ("f1", "f1_mixed_source", [py, str(P / "f1_mixed_source_probe.py")], []),
        ("f2", "restart_reviewer_fixture", [node, str(P / "telemetry_restart_probe_adapted.js")], ["node"]),
        ("f2", "restart_stream_ids", [node, str(P / "telemetry_restart_probe_streams.js")], ["node"]),
        ("f2", "restart_real_processes", [node, str(P / "telemetry_restart_real_probe.js")], ["node"]),
        ("f2", "f2_display_latency", [py, str(P / "f2_display_latency_diagnostic.py")], ["playwright", "v51-browser"]),
        ("f4", "f4_cross_platform", [py, str(P / "f4_cross_platform_emulation.py")], []),
        ("f5", "com_preview_throttle", [py, str(P / "com_preview_throttle_probe.py"), "1", "4", "8", "16"], ["playwright"]),
        ("f5", "f5_check_under_throttle", [py, str(P / "f5_check_under_throttle.py")], ["playwright", "v51-checks"]),
    ]
    want = {x.strip() for x in a.only.split(",") if x.strip()}
    if "f3" in want:
        want.add("f1")          # the reviewer's CI probe is part of review_probes_adapted.py
    index = {"root": str(root), "label": a.label, "python": py, "node": node, "when": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "probes": {}}
    for finding, name, cmd, needs in probes:
        if finding not in want:
            continue
        missing = [n for n, ok in (("node", bool(node)), ("playwright", has_pw), ("v51-checks", has_v51_checks), ("v51-browser", has_v51_browser)) if n in needs and not ok]
        if missing:
            index["probes"][name] = {"finding": finding, "status": "not run", "reason": "not available for this checkout/interpreter: " + ", ".join(missing)}
            print(f"{name:26s} NOT RUN ({', '.join(missing)})", flush=True)
            continue
        t0 = time.time()
        p = subprocess.run(cmd, cwd=str(root), env=env, capture_output=True, text=True, timeout=1800)
        text = p.stdout + ("\n--- stderr ---\n" + p.stderr if p.stderr.strip() else "")
        (out / f"{name}.out").write_text(text)
        holds, summary = condition(name, p.returncode, p.stdout)
        index["probes"][name] = {"finding": finding, "status": "ran", "exit_code": p.returncode, "seconds": round(time.time() - t0, 1),
                                 "defect_absent": holds, "summary": summary, "output": f"results/{a.label}/{name}.out"}
        print(f"{name:26s} exit {p.returncode}  defect absent: {holds}", flush=True)
    (out / "index.json").write_text(json.dumps(index, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

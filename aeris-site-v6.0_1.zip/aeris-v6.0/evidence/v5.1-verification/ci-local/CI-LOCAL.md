# Local execution of the CI workflow (not a CI service run)

2026-10-01T02:02:12+00:00 · commit `c8b1967a88d47ef59de3566bface0d74abeeaf9d` · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 · setup-python → `/usr/bin/python3.12` (3.12.3) · setup-node → `/opt/node22/bin/node` (v22.22.2)

## backend — all steps succeeded

| # | Step | Result | Seconds | Log |
|---:|---|---|---:|---|
| 1 | actions/checkout@v4 | ok — clean clone of c8b1967a88d4 (working tree was clean) | 0.0 | — |
| 2 | actions/setup-python@v5 | ok — provided by this machine: /usr/bin/python3.12 (Python 3.12.3); workflow asks for 3.12 | 0.0 | — |
| 3 | Install | ok | 19.6 | backend/step3.log |
| 4 | pytest | ok | 186.6 | backend/step4.log |
| 5 | actions/upload-artifact@v4 | ok — artifacts copied locally: ['ci-test-logs/'] | 0.0 | — |

run_tests.py: **PASSED — selected suites only (1 of 18); not selected: js:assistant, js:engine, js:numerics, js:platform, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51. Not a full validation.** · totals {'passed': 391, 'failed': 0, 'skipped': 0, 'not_run': 0}

## javascript — all steps succeeded

| # | Step | Result | Seconds | Log |
|---:|---|---|---:|---|
| 1 | actions/checkout@v4 | ok — clean clone of c8b1967a88d4 (working tree was clean) | 0.0 | — |
| 2 | actions/setup-node@v4 | ok — provided by this machine: /opt/node22/bin/node (v22.22.2); workflow asks for 22 | 0.0 | — |
| 3 | actions/setup-python@v5 | ok — provided by this machine: /usr/bin/python3.12 (Python 3.12.3); workflow asks for 3.12 | 0.0 | — |
| 4 | Schemas are generated from the modules (no drift) | ok | 0.1 | javascript/step4.log |
| 5 | index.html is generated from the templates (no drift) | ok | 0.1 | javascript/step5.log |
| 6 | JavaScript suites | ok | 4.6 | javascript/step6.log |
| 7 | actions/upload-artifact@v4 | ok — artifacts copied locally: ['ci-test-logs/'] | 0.0 | — |

run_tests.py: **PASSED — selected suites only (11 of 18); not selected: backend, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51. Not a full validation.** · totals {'passed': 181, 'failed': 0, 'skipped': 0, 'not_run': 0}

## integration — all steps succeeded

| # | Step | Result | Seconds | Log |
|---:|---|---|---:|---|
| 1 | actions/checkout@v4 | ok — clean clone of c8b1967a88d4 (working tree was clean) | 0.0 | — |
| 2 | actions/setup-python@v5 | ok — provided by this machine: /usr/bin/python3.12 (Python 3.12.3); workflow asks for 3.12 | 0.0 | — |
| 3 | actions/setup-node@v4 | ok — provided by this machine: /opt/node22/bin/node (v22.22.2); workflow asks for 22 | 0.0 | — |
| 4 | scripts/install.sh --python python | ok | 20.5 | integration/step4.log |
| 5 | python3 scripts/run_tests.py --out ci-test-logs --only live --backend-python "$GITHUB_WORK | ok | 14.3 | integration/step5.log |
| 6 | actions/upload-artifact@v4 | ok — artifacts copied locally: ['ci-test-logs/'] | 0.0 | — |

run_tests.py: **PASSED — selected suites only (1 of 18); not selected: backend, js:assistant, js:engine, js:numerics, js:platform, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51. Not a full validation.** · totals {'passed': 14, 'failed': 0, 'skipped': 0, 'not_run': 0}

## browser — all steps succeeded

| # | Step | Result | Seconds | Log |
|---:|---|---|---:|---|
| 1 | actions/checkout@v4 | ok — clean clone of c8b1967a88d4 (working tree was clean) | 0.0 | — |
| 2 | actions/setup-python@v5 | ok — provided by this machine: /usr/bin/python3.12 (Python 3.12.3); workflow asks for 3.12 | 0.0 | — |
| 3 | scripts/install.sh --python python | ok | 18.8 | browser/step3.log |
| 4 | Playwright | ok | 13.6 | browser/step4.log |
| 5 | python3 scripts/run_tests.py --out ci-test-logs --only browser --backend-python "$GITHUB_W | ok | 322.2 | browser/step5.log |
| 6 | actions/upload-artifact@v4 | ok — artifacts copied locally: ['ci-test-logs/'] | 0.0 | — |

run_tests.py: **PASSED — selected suites only (5 of 18); not selected: backend, js:assistant, js:engine, js:numerics, js:platform, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, live. Not a full validation.** · totals {'passed': 171, 'failed': 0, 'skipped': 0, 'not_run': 0}

**All steps succeeded:** yes.

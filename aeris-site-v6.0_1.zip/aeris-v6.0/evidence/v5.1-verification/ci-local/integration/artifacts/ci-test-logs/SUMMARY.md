# Test run — PASSED — selected suites only (1 of 18); not selected: backend, js:assistant, js:engine, js:numerics, js:platform, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51. Not a full validation.

2026-10-01T02:06:21+00:00 · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 · backend Python `/tmp/aeris-ci-integration-qszbcunm/work/backend/.venv/bin/python` · Node v22.22.2

- backend python: `/tmp/aeris-ci-integration-qszbcunm/work/backend/.venv/bin/python` (--backend-python, given as `/tmp/aeris-ci-integration-qszbcunm/work/backend/.venv/bin/python`)
- node: `/tmp/aeris-ci-bin-_3ctohq2/node` (default: node on PATH)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| live | passed | 14 | 0 | 0 | 0 | 14.2 | live.log |
| backend | not selected | — | — | — | — | — | — |
| js:assistant | not selected | — | — | — | — | — | — |
| js:engine | not selected | — | — | — | — | — | — |
| js:numerics | not selected | — | — | — | — | — | — |
| js:platform | not selected | — | — | — | — | — | — |
| js:runs | not selected | — | — | — | — | — | — |
| js:schema | not selected | — | — | — | — | — | — |
| js:service | not selected | — | — | — | — | — | — |
| js:ui | not selected | — | — | — | — | — | — |
| js:v4 | not selected | — | — | — | — | — | — |
| js:v5 | not selected | — | — | — | — | — | — |
| js:v51 | not selected | — | — | — | — | — | — |
| browser:browser_check | not selected | — | — | — | — | — | — |
| browser:browser_v3 | not selected | — | — | — | — | — | — |
| browser:browser_v4 | not selected | — | — | — | — | — | — |
| browser:browser_v5 | not selected | — | — | — | — | — | — |
| browser:browser_v51 | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 14 passed, 0 failed, 0 skipped, 0 not run.
**Suites:** 1 passed, 0 failed, 0 not run, 0 skipped, 17 not selected.
**Full validation:** no (exit code 0).

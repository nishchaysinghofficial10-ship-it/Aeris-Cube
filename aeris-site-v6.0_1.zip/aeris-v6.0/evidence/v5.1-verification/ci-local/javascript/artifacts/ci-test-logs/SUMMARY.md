# Test run — PASSED — selected suites only (11 of 18); not selected: backend, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51. Not a full validation.

2026-10-01T02:05:45+00:00 · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 · backend Python `None` · Node v22.22.2

- node: `/tmp/aeris-ci-bin-6oo5w0xm/node` (default: node on PATH)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| js:assistant | passed | 9 | 0 | 0 | 0 | 0.2 | js-assistant.log |
| js:engine | passed | 9 | 0 | 0 | 0 | 0.7 | js-engine.log |
| js:numerics | passed | 38 | 0 | 0 | 0 | 0.6 | js-numerics.log |
| js:platform | passed | 16 | 0 | 0 | 0 | 0.3 | js-platform.log |
| js:runs | passed | 14 | 0 | 0 | 0 | 0.3 | js-runs.log |
| js:schema | passed | 7 | 0 | 0 | 0 | 0.3 | js-schema.log |
| js:service | passed | 19 | 0 | 0 | 0 | 0.4 | js-service.log |
| js:ui | passed | 16 | 0 | 0 | 0 | 0.3 | js-ui.log |
| js:v4 | passed | 27 | 0 | 0 | 0 | 0.6 | js-v4.log |
| js:v5 | passed | 17 | 0 | 0 | 0 | 0.6 | js-v5.log |
| js:v51 | passed | 9 | 0 | 0 | 0 | 0.2 | js-v51.log |
| backend | not selected | — | — | — | — | — | — |
| live | not selected | — | — | — | — | — | — |
| browser:browser_check | not selected | — | — | — | — | — | — |
| browser:browser_v3 | not selected | — | — | — | — | — | — |
| browser:browser_v4 | not selected | — | — | — | — | — | — |
| browser:browser_v5 | not selected | — | — | — | — | — | — |
| browser:browser_v51 | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 181 passed, 0 failed, 0 skipped, 0 not run.
**Suites:** 11 passed, 0 failed, 0 not run, 0 skipped, 7 not selected.
**Full validation:** no (exit code 0).

"$GITHUB_WORKSPACE/backend/.venv/bin/python" -m pip install playwright==1.56.0
"$GITHUB_WORKSPACE/backend/.venv/bin/python" -m playwright install --with-deps chromium

# Test run — PASSED — selected suites only (5 of 18); not selected: backend, js:assistant, js:engine, js:numerics, js:platform, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, live. Not a full validation.

2026-10-01T02:12:16+00:00 · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 · backend Python `/tmp/aeris-ci-browser-1_ia6nyb/work/backend/.venv/bin/python` · Node None

- backend python: `/tmp/aeris-ci-browser-1_ia6nyb/work/backend/.venv/bin/python` (--backend-python, given as `/tmp/aeris-ci-browser-1_ia6nyb/work/backend/.venv/bin/python`)
- browser python: `/tmp/aeris-ci-browser-1_ia6nyb/work/backend/.venv/bin/python` (--browser-python, given as `/tmp/aeris-ci-browser-1_ia6nyb/work/backend/.venv/bin/python`)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| browser:browser_check | passed | 50 | 0 | 0 | 0 | 72.2 | browser-browser_check.log |
| browser:browser_v3 | passed | 49 | 0 | 0 | 0 | 52.7 | browser-browser_v3.log |
| browser:browser_v4 | passed | 24 | 0 | 0 | 0 | 69.3 | browser-browser_v4.log |
| browser:browser_v5 | passed | 36 | 0 | 0 | 0 | 52.1 | browser-browser_v5.log |
| browser:browser_v51 | passed | 12 | 0 | 0 | 0 | 75.7 | browser-browser_v51.log |
| backend | not selected | — | — | — | — | — | — |
| js:assistant | not selected | — | — | — | — | — | — |
| js:engine | not selected | — | — | — | — | — | — |
| js:numerics | not selected | — | — | — | — | — | — |
| js:platform | not selected | — | — | — | — | — | — |
| js:runs | not selected | — | — | — | — | — | — |
| js:schema | not selected | — | — | — | — | — | — |
| js:service | not selected | — | — | — | — | — | — |
| js:ui | not selected | — | — | — | — | — | — |
| js:v4 | not selected | — | — | — | — | — | — |
| js:v5 | not selected | — | — | — | — | — | — |
| js:v51 | not selected | — | — | — | — | — | — |
| live | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 171 passed, 0 failed, 0 skipped, 0 not run.
**Suites:** 5 passed, 0 failed, 0 not run, 0 skipped, 13 not selected.
**Full validation:** no (exit code 0).

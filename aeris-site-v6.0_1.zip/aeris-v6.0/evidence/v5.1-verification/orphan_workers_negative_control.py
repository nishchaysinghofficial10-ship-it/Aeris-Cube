"""Negative control for BOTH orphaned-worker checks (v5.1): the Linux /proc test of v5 and the portable ps test added
in v5.1 (the one that also runs on macOS).

Copies the backend to a temporary directory, removes the parent watch of the worker processes in that copy only (the
pool is created as in v4, without the backend's process id) and runs both tests there, then on the unchanged
repository. In the copy both must FAIL (the killed backend's workers keep running); in the repository both must pass
(on macOS the /proc test is skipped, which is reported as skipped, never as a pass). The tests kill anything they
started, so nothing is left behind.

    backend/.venv/bin/python evidence/v5.1-verification/orphan_workers_negative_control.py

Exit code 0 when every available test fails on the copy and passes on the repository.
"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TESTS = {"proc (Linux)": "tests/test_process_restart.py::test_worker_processes_exit_when_the_backend_process_is_killed",
         "ps (portable)": "tests/test_process_restart.py::test_worker_processes_exit_when_the_backend_process_is_killed_portable_ps"}
FIX = "initargs=(self.flags, os.getpid()))"
REVERT = "initargs=(self.flags,))   # NEGATIVE CONTROL: no parent watch (v4)"


def run(backend, test):
    p = subprocess.run([sys.executable, "-m", "pytest", "-q", "-rA", "-p", "no:cacheprovider", test], cwd=backend, capture_output=True, text=True, timeout=300)
    out = p.stdout + p.stderr
    state = "skipped" if " skipped" in out and " passed" not in out and " failed" not in out else "passed" if p.returncode == 0 else "failed"
    return state, out


def main():
    tmp = Path(tempfile.mkdtemp(prefix="aeris-orphan-control-"))
    ok = True
    try:
        copy = tmp / "backend"
        shutil.copytree(ROOT / "backend", copy, ignore=shutil.ignore_patterns(".venv", "__pycache__", "*.egg-info"))
        mgr = copy / "aeris_backend" / "jobs" / "manager.py"
        src = mgr.read_text(encoding="utf-8")
        if src.count(FIX) != 1:
            print("the fix was not found where expected; this control no longer matches the code")
            return 2
        mgr.write_text(src.replace(FIX, REVERT), encoding="utf-8")
        for name, test in TESTS.items():
            s_copy, out_copy = run(copy, test)
            s_repo, out_repo = run(ROOT / "backend", test)
            print(f"=== {name}: copy WITHOUT the parent watch (expected: failed) → {s_copy}\n{out_copy[-1500:]}")
            print(f"=== {name}: repository WITH the parent watch (expected: passed) → {s_repo}\n{out_repo[-600:]}")
            if s_copy == "skipped" and s_repo == "skipped":
                print(f"{name}: not available on this platform (skipped both times): NOT a pass")
                continue
            good = s_copy == "failed" and "still running" in out_copy and s_repo == "passed"
            ok = ok and good
            print(f"{name}: {'as expected' if good else 'NOT as expected'}\n")
        print(f"platform: {sys.platform} · negative control {'as expected' if ok else 'NOT as expected'}")
        return 0 if ok else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())

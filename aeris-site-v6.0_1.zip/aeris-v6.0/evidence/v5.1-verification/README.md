# v5.1 verification: the v5 review findings reproduced on v5, then re-checked on v5.1

Every probe in `probes/` was run against the **unmodified v5** (git `1023e09`, a clean worktree) and against
**v5.1** with the same failure condition; the outputs are in `results/v5/` and `results/v51/` (`index.json` per
version: exit code, the finding's condition read from the output, and the output file). Run them yourself:

```bash
# from the repository root; <python> needs the backend's dependencies (and Playwright for the browser probes)
python3 evidence/v5.1-verification/run_probes.py --root <path to an unpacked v5> --label v5  --python <python>
python3 evidence/v5.1-verification/run_probes.py --root .                         --label v51 --python <python>
```

All data is synthetic; every "physical" source is an artificial test fixture. Executed on Linux x86-64 only
(Python 3.12.3, Node 22.22.2, Chromium 1194 via Playwright 1.56.0); nothing here was executed on macOS.

| Finding | Probe (failure condition) | v5 (before) | v5.1 (after) | Regression tests |
|---|---|---|---|---|
| **F1** synthetic provenance lost across mixed-source export/replay (P1) | `review_probes_adapted.py` — the reviewer's probe, paths adapted: physical fixture → emulator in one recording; the exported first hello, the replay and the re-recording must be synthetic | exported hello `physical`, `synthetic: false`; replay labelled "REPLAY of a recording declared from a physical device"; re-recording `synthetic: false` | exported hellos `file-replay` + `emulator`, all `synthetic: true`; replay SYNTHETIC; re-recording synthetic | `backend/tests/test_provenance.py` (11), `test_schemas.py` (recorder output), `site/tests/v51.test.js` P1, `browser_v51.py` (provenance checks) |
| | `f1_mixed_source_probe.py` — both source orders and a reconnect, two generations of export → replay → re-recording; any non-synthetic hello or recording downstream fails | 2 of 3 scenarios fail (physical-then-synthetic, physical-reconnect-then-synthetic) | 0 of 3 fail | as above |
| **F2** telemetry freezes after a backend restart (P2) | `telemetry_restart_probe_adapted.js` — the reviewer's transport fixture (no stream ids, as v5 sends): frames n = 1, 2 of the new process must be delivered | delivered `[1000]`; cursor stays 1000 | delivered `[1000, 1, 2]` (v5-backend fallback: the counter fell below the cursor) | `site/tests/v51.test.js` W1–W8 |
| | `telemetry_restart_probe_streams.js` — the same with v5.1 stream ids; plus a late old-stream batch ignored and a same-stream reconnect each frame once | all four conditions fail | all four hold | `v51.test.js` W1–W3, W6 |
| | `telemetry_restart_real_probe.js` — REAL backend processes (stop, start on the same port and database) with a WebSocket consumer and a forced-polling consumer in one Node process; a short replay (~50 frames) and live frames after the restart must arrive | 0 / 50 replay frames and 0 live frames for both consumers | 50 / 50 replay frames for both; live frames for both within 3 s | `test_stream_identity.py` (6), `live_backend.test.js` L14, `browser_v51.py` (two tabs, real restart) |
| | `f2_display_latency_diagnostic.py` (v5.1 only) — wall-clock ms from the Connect click to the frame shown, one tab at a time | — | see `results/v51/f2_display_latency.out` | — |
| **F3** CI browser interpreter path (P2) | `review_probes_adapted.py` CI part — the reviewer's layout and the CI's `--browser-python backend/.venv/bin/python` | `FileNotFoundError: 'backend/.venv/bin/python'`, no summary (exit 1) | the browser suite runs with the resolved absolute path; summary written; verdict INCOMPLETE because the probe itself skips suites (exit 2) | `backend/tests/test_run_tests.py` (15); release validation step `test-runner`; `ci-local/` |
| **F4** cross-platform reproduction assertion (P2) | `f4_cross_platform_emulation.py` — the review's macOS difference (2.053914e-15 on one sample of corner_custom) emulated on a copy of the fixture; controls: relative 1e-3, changed outcome | Mac-sized difference: application `within_tolerance`, **test fails** (demands identical) | Mac-sized difference passes; relative 1e-3 and outcome change still fail | `backend/tests/test_reproduction.py` (21: same-environment exactness, cross-environment rule, 8 negative controls) |
| **F5** COM-preview browser check (P2) | `com_preview_throttle_probe.py` — product behaviour under CPU throttling (1×–16×) and whether v5's fixed-500-ms check passes | the v5 check's result at 16× depends on timing: it passed in `results/v5` and failed (4 mm) in `results/v51`, whose product code is identical | product unchanged (same behaviour); see next row | — |
| | `f5_check_under_throttle.py` (v5.1 only; uses the suite's own check code) — v5 check vs v5.1 check, 1×–24× | — | v5 check: fails for 4 mm at 16× and 24× and **passes on a stale 4 mm vector** for 5 mm at 16× and 24×; v5.1 check passes at every rate, plus replay → setup → 0 mm | `site/tests/browser_v3.py` (3 COM checks) |

Found while completing v5.1 (not in the review):

| Issue | Before | After | Test / evidence |
|---|---|---|---|
| exporting or replaying an uploaded recording without a `seq` column | HTTP 500 (`KeyError: 'seq'`) | the row index stands in | `test_provenance.py::test_api_an_uploaded_recording_without_a_seq_column_exports_and_replays` |
| the published dataset schema lacked `provenance.source: "synthetic-telemetry"` (written since v5) | a backend dataset of synthetic recordings failed the v5 schema | conforms | `results/dataset-schema-drift.txt`; `test_schemas.py::test_telemetry_recordings_and_datasets_of_them_match_the_schemas` |
| the orphan-worker check could only run on Linux (`/proc`) | skipped on macOS | portable `ps` test (also macOS) | `orphan_workers_negative_control.py` → `.out`: both tests fail without the parent watch and pass with it (Linux; not executed on macOS) |
| a WebSocket attempt that reports only `error` (Node's WebSocket) stalled the live stream | the WebSocket consumer of the real-process probe never recovered | falls back to polling; an attempt that never opens is given up after 8 s | `v51.test.js` W7; `restart_real_processes` (v5.1) |

`ci-local/` (when present): the CI workflow's `run:` steps executed on this machine from clean clones with
`scripts/ci_local.py`. That is **not** a CI service run.

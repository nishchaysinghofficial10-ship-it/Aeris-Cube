# Test run — FAILED — 1 suite(s) failed: browser:browser_v51. Not a full validation.

2026-10-01T11:58:33+00:00 · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 (`linux`) · backend Python `/home/claude/aeris-v52/.venv/bin/python` · Node v22.22.2

- backend python: `/home/claude/aeris-v52/.venv/bin/python` (--backend-python, given as `/home/claude/aeris-v52/.venv/bin/python`)
- browser python: `/home/claude/aeris-v52/.venv/bin/python` (--browser-python, given as `/home/claude/aeris-v52/.venv/bin/python`)
- node: `/opt/node22/bin/node` (default: node on PATH)
- platform-exclusion policy: `/home/claude/aeris-v52/repo/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| backend | passed | 453 | 0 | 0 | 0 | 266.1 | backend.log |
| js:assistant | passed | 9 | 0 | 0 | 0 | 0.3 | js-assistant.log |
| js:engine | passed | 9 | 0 | 0 | 0 | 1.0 | js-engine.log |
| js:numerics | passed | 38 | 0 | 0 | 0 | 0.7 | js-numerics.log |
| js:platform | passed | 16 | 0 | 0 | 0 | 0.5 | js-platform.log |
| js:runs | passed | 14 | 0 | 0 | 0 | 0.4 | js-runs.log |
| js:schema | passed | 7 | 0 | 0 | 0 | 0.4 | js-schema.log |
| js:service | passed | 19 | 0 | 0 | 0 | 0.4 | js-service.log |
| js:ui | passed | 16 | 0 | 0 | 0 | 0.4 | js-ui.log |
| js:v4 | passed | 27 | 0 | 0 | 0 | 0.7 | js-v4.log |
| js:v5 | passed | 17 | 0 | 0 | 0 | 0.7 | js-v5.log |
| js:v51 | passed | 9 | 0 | 0 | 0 | 0.2 | js-v51.log |
| live | passed | 14 | 0 | 0 | 0 | 15.7 | live.log |
| browser:browser_check | passed | 50 | 0 | 0 | 0 | 82.3 | browser-browser_check.log |
| browser:browser_v3 | passed | 49 | 0 | 0 | 0 | 60.7 | browser-browser_v3.log |
| browser:browser_v4 | passed | 24 | 0 | 0 | 0 | 96.4 | browser-browser_v4.log |
| browser:browser_v5 | passed | 36 | 0 | 0 | 0 | 63.0 | browser-browser_v5.log |
| browser:browser_v51 | failed | 11 | 1 | 0 | 0 | 93.6 | browser-browser_v51.log |
| browser:browser_v52 | passed | 45 | 0 | 0 | 0 | 77.4 | browser-browser_v52.log |

**Totals (tests in the suites that ran):** 863 passed, 1 failed, 0 skipped, 0 not run (864 executed).
**Suites:** 18 passed, 0 passed with exclusions, 0 incomplete, 1 failed, 0 not run, 0 skipped, 0 not selected.
**Complete execution:** yes · **all applicable tests passed:** no · **all tests executed:** yes.
**Full validation:** no (exit code 1: a suite or test case failed, timed out or reported no counts).

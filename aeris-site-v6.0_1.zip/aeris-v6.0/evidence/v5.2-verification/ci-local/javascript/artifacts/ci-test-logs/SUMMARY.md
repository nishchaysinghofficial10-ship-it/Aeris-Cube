# Test run — PASSED — selected suites only (11 of 19); every test case in them executed and passed; not selected: backend, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52. Not a full validation.

2026-10-01T12:43:42+00:00 · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 (`linux`) · backend Python `None` · Node v22.22.2

- node: `/tmp/aeris-ci-bin-4a1q48p1/node` (default: node on PATH)
- platform-exclusion policy: `/tmp/aeris-ci-javascript-ubu9qqr4/work/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| js:assistant | passed | 9 | 0 | 0 | 0 | 0.2 | js-assistant.log |
| js:engine | passed | 9 | 0 | 0 | 0 | 0.9 | js-engine.log |
| js:numerics | passed | 38 | 0 | 0 | 0 | 0.7 | js-numerics.log |
| js:platform | passed | 16 | 0 | 0 | 0 | 0.4 | js-platform.log |
| js:runs | passed | 14 | 0 | 0 | 0 | 0.3 | js-runs.log |
| js:schema | passed | 7 | 0 | 0 | 0 | 0.3 | js-schema.log |
| js:service | passed | 19 | 0 | 0 | 0 | 0.4 | js-service.log |
| js:ui | passed | 16 | 0 | 0 | 0 | 0.3 | js-ui.log |
| js:v4 | passed | 27 | 0 | 0 | 0 | 0.7 | js-v4.log |
| js:v5 | passed | 17 | 0 | 0 | 0 | 0.6 | js-v5.log |
| js:v51 | passed | 9 | 0 | 0 | 0 | 0.3 | js-v51.log |
| backend | not selected | — | — | — | — | — | — |
| live | not selected | — | — | — | — | — | — |
| browser:browser_check | not selected | — | — | — | — | — | — |
| browser:browser_v3 | not selected | — | — | — | — | — | — |
| browser:browser_v4 | not selected | — | — | — | — | — | — |
| browser:browser_v5 | not selected | — | — | — | — | — | — |
| browser:browser_v51 | not selected | — | — | — | — | — | — |
| browser:browser_v52 | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 181 passed, 0 failed, 0 skipped, 0 not run (181 executed).
**Suites:** 11 passed, 0 passed with exclusions, 0 incomplete, 0 failed, 0 not run, 0 skipped, 8 not selected.
**Complete execution:** yes · **all applicable tests passed:** yes · **all tests executed:** no.
**Full validation:** no (exit code 0: every selected suite ran and every test case in it executed and passed).

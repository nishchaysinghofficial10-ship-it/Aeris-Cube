# Test run — PASSED — selected suites only (1 of 19); every test case in them executed and passed; not selected: js:assistant, js:engine, js:numerics, js:platform, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52. Not a full validation.

2026-10-01T12:43:35+00:00 · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 (`linux`) · backend Python `/tmp/aeris-ci-backend-wpogue7n/work/backend/.venv/bin/python` · Node None

- backend python: `/tmp/aeris-ci-backend-wpogue7n/work/backend/.venv/bin/python` (--backend-python, given as `/tmp/aeris-ci-backend-wpogue7n/work/backend/.venv/bin/python`)
- platform-exclusion policy: `/tmp/aeris-ci-backend-wpogue7n/work/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| backend | passed | 453 | 0 | 0 | 0 | 248.0 | backend.log |
| js:assistant | not selected | — | — | — | — | — | — |
| js:engine | not selected | — | — | — | — | — | — |
| js:numerics | not selected | — | — | — | — | — | — |
| js:platform | not selected | — | — | — | — | — | — |
| js:runs | not selected | — | — | — | — | — | — |
| js:schema | not selected | — | — | — | — | — | — |
| js:service | not selected | — | — | — | — | — | — |
| js:ui | not selected | — | — | — | — | — | — |
| js:v4 | not selected | — | — | — | — | — | — |
| js:v5 | not selected | — | — | — | — | — | — |
| js:v51 | not selected | — | — | — | — | — | — |
| live | not selected | — | — | — | — | — | — |
| browser:browser_check | not selected | — | — | — | — | — | — |
| browser:browser_v3 | not selected | — | — | — | — | — | — |
| browser:browser_v4 | not selected | — | — | — | — | — | — |
| browser:browser_v5 | not selected | — | — | — | — | — | — |
| browser:browser_v51 | not selected | — | — | — | — | — | — |
| browser:browser_v52 | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 453 passed, 0 failed, 0 skipped, 0 not run (453 executed).
**Suites:** 1 passed, 0 passed with exclusions, 0 incomplete, 0 failed, 0 not run, 0 skipped, 18 not selected.
**Complete execution:** yes · **all applicable tests passed:** yes · **all tests executed:** no.
**Full validation:** no (exit code 0: every selected suite ran and every test case in it executed and passed).

# Test run — PASSED — selected suites only (6 of 19); every test case in them executed and passed; not selected: backend, js:assistant, js:engine, js:numerics, js:platform, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, live. Not a full validation.

2026-10-01T12:52:06+00:00 · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 (`linux`) · backend Python `/tmp/aeris-ci-browser-99t9tziz/work/backend/.venv/bin/python` · Node None

- backend python: `/tmp/aeris-ci-browser-99t9tziz/work/backend/.venv/bin/python` (--backend-python, given as `/tmp/aeris-ci-browser-99t9tziz/work/backend/.venv/bin/python`)
- browser python: `/tmp/aeris-ci-browser-99t9tziz/work/backend/.venv/bin/python` (--browser-python, given as `/tmp/aeris-ci-browser-99t9tziz/work/backend/.venv/bin/python`)
- platform-exclusion policy: `/tmp/aeris-ci-browser-99t9tziz/work/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| browser:browser_check | passed | 50 | 0 | 0 | 0 | 75.3 | browser-browser_check.log |
| browser:browser_v3 | passed | 49 | 0 | 0 | 0 | 54.8 | browser-browser_v3.log |
| browser:browser_v4 | passed | 24 | 0 | 0 | 0 | 83.9 | browser-browser_v4.log |
| browser:browser_v5 | passed | 36 | 0 | 0 | 0 | 56.2 | browser-browser_v5.log |
| browser:browser_v51 | passed | 12 | 0 | 0 | 0 | 78.6 | browser-browser_v51.log |
| browser:browser_v52 | passed | 45 | 0 | 0 | 0 | 75.9 | browser-browser_v52.log |
| backend | not selected | — | — | — | — | — | — |
| js:assistant | not selected | — | — | — | — | — | — |
| js:engine | not selected | — | — | — | — | — | — |
| js:numerics | not selected | — | — | — | — | — | — |
| js:platform | not selected | — | — | — | — | — | — |
| js:runs | not selected | — | — | — | — | — | — |
| js:schema | not selected | — | — | — | — | — | — |
| js:service | not selected | — | — | — | — | — | — |
| js:ui | not selected | — | — | — | — | — | — |
| js:v4 | not selected | — | — | — | — | — | — |
| js:v5 | not selected | — | — | — | — | — | — |
| js:v51 | not selected | — | — | — | — | — | — |
| live | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 216 passed, 0 failed, 0 skipped, 0 not run (216 executed).
**Suites:** 6 passed, 0 passed with exclusions, 0 incomplete, 0 failed, 0 not run, 0 skipped, 13 not selected.
**Complete execution:** yes · **all applicable tests passed:** yes · **all tests executed:** no.
**Full validation:** no (exit code 0: every selected suite ran and every test case in it executed and passed).

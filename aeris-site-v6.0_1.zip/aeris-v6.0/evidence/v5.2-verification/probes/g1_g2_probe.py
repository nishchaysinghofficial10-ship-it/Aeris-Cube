"""G1/G2 before-and-after probe (v5.2 work). Runs the SAME scenarios against any checkout through interfaces that exist
in both v5.1 and v5.2 (the HTTP API via TestClient, telemetry.stream.recording_to_ndjson, TelemetryHub,
FileReplaySource, lineage.classify).

    python g1_g2_probe.py CHECKOUT_ROOT OUT.json

G1: for every accepted unit family, import a SYNTHETIC recording through the API, export NDJSON, compare the frame
values with the physical truth in wire units; then replay the export through the actual FileReplaySource into a
recording hub and compare the re-recorded SI values (importer conversion) with the original. Inputs the stream cannot
carry: the HTTP status of the export (v5.1: 500 or 200 with silent omission / relabelling).
G2: 24 export → replay → re-record generations of four chains (reviewer's mixed two-segment recording, four reconnect
segments, a declared-physical fixture, an unknown upload); the first generation that fails, and lineage sizes.
"""
import asyncio
import copy
import json
import math
import sys
import tempfile
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
sys.path.insert(0, str(ROOT / "backend"))

from fastapi.testclient import TestClient  # noqa: E402

from aeris_backend.api.app import create_app  # noqa: E402
from aeris_backend.hardware.ingest import UNITS as F, validate_recording  # noqa: E402
from aeris_backend.telemetry.lineage import classify  # noqa: E402
from aeris_backend.telemetry.protocol import UNITS as WIRE, dumps, hello_message, validate_hello  # noqa: E402
from aeris_backend.telemetry.stream import STATUS_CODES, TelemetryHub, recording_to_ndjson  # noqa: E402
from aeris_backend.telemetry.transport import FileReplaySource  # noqa: E402

N, RATE = 30, 50.0
FAM = {"t": "time", "theta": "angle", "q": "unitless", "w": "rate", "imu.gyro": "rate", "imu.accel": "accel", "wheel_rpm": "wheel", "torque_cmd": "torque", "torque_meas": "torque"}
COLS = {"w": ["w_x", "w_y", "w_z"], "imu.gyro": ["gyro_x", "gyro_y", "gyro_z"], "imu.accel": ["accel_x", "accel_y", "accel_z"], "torque_cmd": ["torque_cmd_x", "torque_cmd_y", "torque_cmd_z"],
        "torque_meas": ["torque_meas_x", "torque_meas_y", "torque_meas_z"], "wheel_rpm": ["wheel_rpm_x", "wheel_rpm_y", "wheel_rpm_z"], "omega": ["omega_x", "omega_y", "omega_z"], "q": ["q0", "q1", "q2", "q3"]}


def truth(i):
    a = 0.1 * math.sin(i / 11)
    return {"t": i / RATE, "theta": 0.05 * math.sin(i / 9), "q": [math.cos(a / 2), math.sin(a / 2), 0.0, 0.0],
            "w": [0.3 * math.sin(i / 7), -0.2, 0.1 * math.sin(i / 3)], "imu.gyro": [0.3 * math.sin(i / 7) + 0.001, -0.199, 0.1],
            "imu.accel": [0.1, 0.05, 9.80665], "wheel_rpm": [1500.0 + 10 * i, -800.0, 300.0], "torque_cmd": [0.02, 0.01 * math.cos(i / 6), -0.015],
            "torque_meas": [0.019, 0.011, -0.014]}


def doc_for(units, mode, wheel="wheel_rpm"):
    cols, u = {}, {}
    for field, unit in units.items():
        names = [field] if field in ("t", "theta") else COLS["omega" if field == "wheel_rpm" and wheel == "omega" else field]
        for j, c in enumerate(names):
            fam = FAM[field]
            vals = [truth(i)[field] if len(names) == 1 else truth(i)[field][j] for i in range(N)]
            cols[c] = [x * F[fam][WIRE[field]] / F[fam][unit] if F[fam][unit] != F[fam][WIRE[field]] else x for x in vals]
            u[c] = unit
    cols["seq"], u["seq"] = list(range(N)), "count"
    return {"schema": "aeris-hardware-run/1", "synthetic": True, "device": {"id": "probe-fixture", "firmware": "test"},
            "recording": {"started": "2026-10-01T00:00:00Z", "notes": "SYNTHETIC unit probe"}, "mode": mode, "samples": {"rate_hz": RATE, "cols": cols, "units": u}}


PROFILES = {
    "wire units (identity)": ({"t": "s", "q": "–", "w": "rad/s", "wheel_rpm": "rpm", "torque_cmd": "N·m", "imu.accel": "m/s²"}, "corner", "wheel_rpm"),
    "ms / deg / deg/s": ({"t": "ms", "theta": "deg", "w": "deg/s", "imu.gyro": "deg/s"}, "edge", "wheel_rpm"),
    "omega_* in rad/s": ({"t": "s", "q": "–", "wheel_rpm": "rad/s"}, "corner", "omega"),
    "wheel_rpm_* in rad/s": ({"t": "s", "q": "–", "wheel_rpm": "rad/s"}, "corner", "wheel_rpm"),
    "mN·m, mNm, g": ({"t": "s", "q": "–", "torque_cmd": "mN·m", "torque_meas": "mNm", "imu.accel": "g"}, "corner", "wheel_rpm"),
}


class RecordingHub(TelemetryHub):
    def feed_line(self, raw, now):
        r = super().feed_line(raw, now)
        if r == "hello" and self.recording is None:
            self.start_recording("probe re-recording", now)
        return r


def actual_replay(nd):
    hub = RecordingHub()
    asyncio.run(FileReplaySource(hub, text=nd, label="recording:probe", speed=0).run())
    if hub.recording is None:                      # no hello was accepted: nothing could be recorded
        return hub, None
    try:
        return hub, hub.stop_recording(99.0)
    except RuntimeError:                           # fewer than two frames accepted
        return hub, None


def rel(a, b):
    return abs(a - b) / max(abs(b), 1e-300)


def frame_errors(nd, units, wheel):
    """largest relative error of each exported field against the truth in wire units"""
    frames = [json.loads(x) for x in nd.splitlines() if '"type":"frame"' in x]
    worst = {}
    for i, f in enumerate(frames):
        tr = truth(i)
        for field in units:
            key = field.split(".")[-1]
            got = f.get(field) if "." not in field else (f.get("imu") or {}).get(key)
            if got is None:
                worst[field] = "missing from the frames"
                continue
            want = tr[field]
            errs = [rel(g, w) for g, w in zip(got if isinstance(got, list) else [got], want if isinstance(want, list) else [want]) if w != 0]
            if isinstance(worst.get(field), str):
                continue
            worst[field] = max([worst.get(field, 0.0)] + errs)
    return {"frames": len(frames), "max_rel_error_vs_truth": worst}


def g1(client):
    out = {}
    for name, (units, mode, wheel) in PROFILES.items():
        d = doc_for(units, mode, wheel)
        up = client.post("/api/v1/hardware/recordings", json=d)
        r = client.get(f"/api/v1/hardware/recordings/{up.json()['id']}/export?format=ndjson")
        res = {"import": up.status_code, "export": r.status_code, "input_units": sorted(set(d["samples"]["units"].values()))}
        if r.status_code == 200:
            res.update(frame_errors(r.text, units, wheel))
            _, new = actual_replay(r.text)
            a, b = validate_recording(d)["si"], validate_recording(new)["si"]
            cmp_ = {}
            for c in a:
                cc = c.replace("omega_", "wheel_rpm_")
                if cc in b and c != "seq":
                    cmp_[c] = max(rel(x, y) for x, y in zip(b[cc], a[c]) if y != 0) if any(a[c]) else 0.0
                elif c != "seq":
                    cmp_[c] = "not in the re-recording"
            res["rerecorded_units"] = new["samples"]["units"]
            res["rerecorded_si_max_rel_error_vs_original"] = cmp_
            ok_frames = all(isinstance(v, float) and v < 1e-12 for v in res["max_rel_error_vs_truth"].values())
            ok_rerec = all(isinstance(v, float) and v < 1e-12 for v in cmp_.values())
            res["physical_values_preserved"] = ok_frames and ok_rerec
        out[name] = res
    bad = {}
    base = doc_for({"t": "s", "q": "–", "w": "rad/s"}, "corner")
    cases = {
        "incomplete vector (w_z missing)": lambda d: (d["samples"]["cols"].pop("w_z"), d["samples"]["units"].pop("w_z")),
        "unmapped column (thetadot)": lambda d: (d["samples"]["cols"].__setitem__("thetadot", [0.0] * N), d["samples"]["units"].__setitem__("thetadot", "rad/s")),
        "status code 9 (no declared meaning)": lambda d: (d["samples"]["cols"].__setitem__("status", [0] * (N - 1) + [9]), d["samples"]["units"].__setitem__("status", "count")),
    }
    for name, mutate in cases.items():
        d = copy.deepcopy(base)
        mutate(d)
        up = client.post("/api/v1/hardware/recordings", json=d)
        r = client.get(f"/api/v1/hardware/recordings/{up.json()['id']}/export?format=ndjson")
        row = {"import": up.status_code, "export": r.status_code}
        if r.status_code == 200:
            fr = [json.loads(x) for x in r.text.splitlines() if '"type":"frame"' in x]
            row["last_frame"] = fr[-1]
        else:
            try:
                row["error"] = r.json()
            except ValueError:
                row["error"] = r.text[:200]
        bad[name] = row
    return {"profiles": out, "inputs_the_stream_cannot_carry": bad}


PHYS = hello_message("test-fixture-physical-declaration", "physical", "test-only", False, "corner", 100)
EMU = hello_message("test-emulator", "emulator", "test-only", True, "corner", 100)


def record_segments(*hellos, n=4, restart=True):
    h = TelemetryHub()
    h.on_connect({"kind": "tcp", "address": "probe"}, 0.0)
    h.feed_line(dumps(hellos[0]), 0.0)
    h.start_recording("probe fixture, not a measurement", 0.0)
    for k, hel in enumerate(hellos):
        if k:
            h.on_disconnect("reconnect", float(k))
            h.on_connect({"kind": "tcp", "address": "probe"}, k + 0.05)
            h.feed_line(dumps(hel), k + 0.1)
        for j in range(n):
            s = j if restart else k * n + j
            h.feed_message({"type": "frame", "seq": s, "t": 0.01 * s, "q": [1, 0, 0, 0], "w": [0.01 * j, 0, 0]}, k + 0.2 + 0.01 * j)
    return h.stop_recording(50.0)


def chain(doc, gens=24):
    rows = []
    for g in range(1, gens + 1):
        try:
            nd = recording_to_ndjson(doc, f"AERIS-HW-{g:06d}")
        except Exception as e:  # noqa: BLE001  (v5.2 refuses with ExportError; anything else is recorded as is)
            rows.append({"generation": g, "export": f"{type(e).__name__}: {str(e)[:160]}"})
            break
        hellos = [json.loads(x) for x in nd.splitlines() if '"type":"hello"' in x]
        sizes = [len(json.dumps(h.get("lineage"), default=str)) for h in hellos]
        errs = [validate_hello(h)["errors"] for h in hellos]
        hub, new = actual_replay(nd)
        row = {"generation": g, "lineage_bytes": sizes, "hello_errors": [e for e in errs if e], "rejected": dict(hub.rejected_by_reason),
               "rows_in": len(doc["samples"]["cols"]["t"]), "rows_out": len(new["samples"]["cols"]["t"]) if new else 0, "trust": classify(new)["trust"] if new else None}
        rows.append(row)
        if row["hello_errors"] or row["rejected"] or row["rows_out"] != row["rows_in"]:
            break
        doc = new
    return {"generations_completed": sum(1 for r in rows if "lineage_bytes" in r and not r["hello_errors"] and not r["rejected"] and r["rows_out"] == r["rows_in"]),
            "first_failure": next((r for r in rows if "export" in r or r.get("hello_errors") or r.get("rejected") or r.get("rows_out") != r.get("rows_in")), None),
            "max_lineage_bytes": max((max(r["lineage_bytes"]) for r in rows if r.get("lineage_bytes")), default=None),
            "trusts": sorted({r.get("trust") for r in rows if r.get("trust")}), "rows": rows}


def g2():
    unknown = record_segments(PHYS)
    unknown.pop("synthetic")
    unknown["provenance"] = {}
    return {"mixed two-segment synthetic (reviewer)": chain(record_segments(PHYS, EMU)),
            "four reconnect segments (emulator, clock restarts)": chain(record_segments(EMU, EMU, EMU, EMU)),
            "declared-physical fixture, two reconnect segments": chain(record_segments(PHYS, PHYS, restart=False)),
            "unknown upload (no declarations)": chain(unknown)}


def main():
    with tempfile.TemporaryDirectory() as tmp:
        app = create_app({"db": str(Path(tmp) / "p.sqlite3"), "workers": 1, "max_jobs": 1, "telemetry_dir": str(Path(tmp) / "telemetry")})
        with TestClient(app, raise_server_exceptions=False) as client:
            res = {"checkout": str(ROOT), "G1": g1(client)}
    res["G2"] = g2()
    OUT.write_text(json.dumps(res, indent=1, default=str) + "\n")
    summary = {"G1": {k: (v.get("export"), v.get("physical_values_preserved")) for k, v in res["G1"]["profiles"].items()},
               "G1 refusals": {k: v["export"] for k, v in res["G1"]["inputs_the_stream_cannot_carry"].items()},
               "G2": {k: (v["generations_completed"], v["max_lineage_bytes"], v["trusts"], (v["first_failure"] or {}).get("generation")) for k, v in res["G2"].items()}}
    print(json.dumps(summary, indent=1))


main()

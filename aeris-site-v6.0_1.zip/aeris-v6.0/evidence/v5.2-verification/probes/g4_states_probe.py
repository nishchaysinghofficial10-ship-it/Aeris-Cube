"""G4 focused probe (v5.2 work): browser sweep cancellation in every job state, driven by the job's own progress events.

    python g4_states_probe.py SITE_ROOT OUT.json [--throttle RATE]

SITE_ROOT is a checkout's root (the folder holding site/index.html). Real LocalSimulatorAdapter sweeps in Chromium; the
actual Cancel button is clicked from inside an AERIS_JOBS.subscribe callback at a chosen state, so the moment of the
click does not depend on a timer. --throttle applies CDP CPU throttling (e.g. 4 = four times slower).

Scenarios
  before-start        Run then Cancel in the same task (job still QUEUED)
  during-execution    Cancel at the first progress event with 0 < done < total
  in-analyzing        Cancel when the job enters ANALYZING (every run finished)
  after-completion    Cancel (programmatic click; the button is hidden) after COMPLETE
  next-run-button     after a cancelled sweep, run another: is the Cancel button usable (visible, enabled, labelled)?
"""
import asyncio
import json
import sys
from pathlib import Path

from playwright.async_api import async_playwright

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
THROTTLE = float(sys.argv[sys.argv.index("--throttle") + 1]) if "--throttle" in sys.argv else 1.0
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]

DEF_390 = "d.mode='grid'; d.variables=[{key:'tilt_deg',min:-6,max:6,steps:13},{key:'rate_dps',min:-60,max:60,steps:10}]; d.duration_s=10; d.controllers=['pid','lqr','adp']; d.mass_configs=['base'];"
DEF_12 = "d.mode='grid'; d.variables=[{key:'tilt_deg',min:-6,max:6,steps:2},{key:'rate_dps',min:-60,max:60,steps:2}]; d.duration_s=2; d.controllers=['pid','lqr','adp']; d.mass_configs=['base'];"

BUTTON = "(() => { const b = document.getElementById('swCancel'); return b ? { hidden: b.hidden, disabled: b.disabled, text: b.textContent } : null; })()"
FINAL = """(() => { const s = AERIS_SWEEP_UI._state, j = s.job, r = s.result, out = document.getElementById('swOut').innerText;
  return { state: j.state, done: j.progress.done, total: j.progress.total, message: j.message,
           rows: r ? r.rows.length : null, partial: r ? r.partial : null, analysis: r ? !!r.analysis : null,
           analysis_cancelled: r ? !!r.analysis_cancelled : null, row_index_ok: r ? r.rows.every((x, i) => x.index === i) : null,
           partial_banner: out.includes('PARTIAL sweep'), button: %s }; })()""" % BUTTON


def arm(state_test):
    """subscribe to the job just submitted; click the real Cancel button once, inside the callback, when state_test holds"""
    return """(() => { const job = AERIS_SWEEP_UI._state.job; window.g4 = null;
      AERIS_JOBS.subscribe(job, j => { if (!window.g4 && (%s)) { const b = document.getElementById('swCancel');
        window.g4 = { state: j.state, done: j.progress.done, total: j.progress.total, button: { hidden: b.hidden, disabled: b.disabled, text: b.textContent } };
        b.click(); } }); return job.state; })()""" % state_test


async def fresh(browser):
    page = await browser.new_page(viewport={"width": 1440, "height": 900})
    if THROTTLE != 1.0:
        cdp = await page.context.new_cdp_session(page)
        await cdp.send("Emulation.setCPUThrottlingRate", {"rate": THROTTLE})
    page.errs = []
    page.on("pageerror", lambda e: page.errs.append(str(e)))
    await page.goto((ROOT / "site" / "index.html").as_uri() + "#lab/sweep", wait_until="load")
    await page.wait_for_function("typeof AERIS_SWEEP_UI !== 'undefined' && !!document.getElementById('swRun')")
    await page.click('[data-preset="sat"]')
    await page.wait_for_function("!document.getElementById('swRun').disabled")
    return page


async def start(page, definition, then=""):
    return await page.evaluate("(() => { const d = AERIS_SWEEP_UI._state.def; %s document.getElementById('swRun').click(); %s return AERIS_SWEEP_UI._state.job.state; })()" % (definition, then))


async def terminal(page, timeout=60000):
    await page.wait_for_function("AERIS_SWEEP_UI._state.job && ['complete','cancelled','failed'].includes(AERIS_SWEEP_UI._state.job.state)", timeout=timeout)


async def main():
    res = {"site_root": str(ROOT), "cpu_throttle": THROTTLE, "scenarios": {}}
    async with async_playwright() as p:
        browser = await p.chromium.launch(args=ARGS)
        res["browser"] = browser.version

        page = await fresh(browser)                                   # before start: Run then Cancel in one task
        st = await page.evaluate("(() => { const d = AERIS_SWEEP_UI._state.def; %s document.getElementById('swRun').click(); const s0 = AERIS_SWEEP_UI._state.job.state, b0 = %s; document.getElementById('swCancel').click(); return { state_at_click: s0, button: b0 }; })()" % (DEF_390, BUTTON))
        await terminal(page)
        res["scenarios"]["before-start"] = dict(st, final=await page.evaluate(FINAL), page_errors=page.errs)
        await page.close()

        page = await fresh(browser)                                   # during execution
        await start(page, DEF_390)
        await page.evaluate(arm("j.state === 'running' && j.progress.done > 0 && j.progress.done < j.progress.total"))
        await terminal(page)
        res["scenarios"]["during-execution"] = {"at_click": await page.evaluate("window.g4"), "final": await page.evaluate(FINAL), "page_errors": page.errs}
        # next run in the same page, after that cancellation: is its Cancel button usable?
        await start(page, DEF_390)
        await page.evaluate(arm("j.state === 'running' && j.progress.done > 0 && j.progress.done < j.progress.total"))
        await terminal(page)
        res["scenarios"]["next-run-button"] = {"at_click": await page.evaluate("window.g4"), "final": await page.evaluate(FINAL), "page_errors": page.errs}
        await page.close()

        page = await fresh(browser)                                   # in ANALYZING
        await start(page, DEF_390)
        await page.evaluate(arm("j.state === 'analyzing'"))
        await terminal(page)
        res["scenarios"]["in-analyzing"] = {"at_click": await page.evaluate("window.g4"), "final": await page.evaluate(FINAL), "page_errors": page.errs}
        await page.close()

        page = await fresh(browser)                                   # after completion
        await start(page, DEF_12)
        await terminal(page)
        before = await page.evaluate("JSON.stringify(AERIS_SWEEP_UI._state.result)")
        btn = await page.evaluate(BUTTON)
        await page.evaluate("document.getElementById('swCancel').click()")
        await page.wait_for_timeout(200)
        after = await page.evaluate("JSON.stringify(AERIS_SWEEP_UI._state.result)")
        res["scenarios"]["after-completion"] = {"button_before_click": btn, "final": await page.evaluate(FINAL), "result_unchanged": before == after, "page_errors": page.errs}
        await page.close()
        await browser.close()
    OUT.write_text(json.dumps(res, indent=1) + "\n")
    print(json.dumps(res, indent=1))


asyncio.run(main())

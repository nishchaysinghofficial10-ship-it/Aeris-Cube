# Test run — INCOMPLETE — test cases not executed in backend: 1 skipped — backend::tests.test_skip::test_skipped (controlled review skip). Nothing failed in the 2 suite(s) that ran. Not a full validation.

2026-10-01T12:25:09+00:00 · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 (`linux`) · backend Python `/home/claude/aeris-v52/.venv/bin/python` · Node v22.22.2

- backend python: `/home/claude/aeris-v52/.venv/bin/python` (--backend-python, given as `/home/claude/aeris-v52/.venv/bin/python`)
- node: `/opt/node22/bin/node` (default: node on PATH)
- platform-exclusion policy: `/tmp/claude-0/-home-claude/4f90be2f-2cae-52cb-8030-275a7b847bc2/scratchpad/g3fx52/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| backend | incomplete — 1 test(s) skipped: tests.test_skip::test_skipped (controlled review skip) | 1 | 0 | 1 | 0 | 0.4 | backend.log |
| live | passed | 1 | 0 | 0 | 0 | 0.1 | live.log |

**Skipped test cases (not executed; never counted as passed):**

| Suite | Test | Reason | Platform-exclusion policy |
|---|---|---|---|
| backend | `tests.test_skip::test_skipped` | controlled review skip | not covered |

**Totals (tests in the suites that ran):** 2 passed, 0 failed, 1 skipped, 0 not run (2 executed).
**Suites:** 1 passed, 0 passed with exclusions, 1 incomplete, 0 failed, 0 not run, 0 skipped, 0 not selected.
**Complete execution:** no · **all applicable tests passed:** no · **all tests executed:** no.
**Full validation:** no (exit code 2: incomplete: a suite was not run or skipped, or test cases were skipped / not run outside the platform-exclusion policy).

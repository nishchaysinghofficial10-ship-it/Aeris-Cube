# v5.2 verification: the v5.1 review findings G1–G4, before and after

Every finding was first reproduced on the **unmodified v5.1** (a separate checkout of tag `aeris-v5.1` =
`f76d632efac6e4e0148fc69c3099651b146bdad1`), then re-checked on v5.2 with the same conditions. All runs here are ours,
on Linux x86-64 (kernel 6.18.44, Python 3.12.3, NumPy 2.5.3, SciPy 1.18.1, Node 22.22.2, Playwright 1.56.0 with
Chromium 141.0.7390.37). Nothing here was run on macOS; the reviewer's macOS results are theirs
(`../v5.1-independent-review/`). All data in these probes is SYNTHETIC or an artificial test fixture; nothing is a
measurement.

`probes/edge_case_probes.py` and `probes/cancel_probe.py` are the reviewer's probes, byte-identical to the supplied
files (they take the checkout and the output path as arguments, so nothing had to be adapted). `probes/g1_g2_probe.py`
and `probes/g4_states_probe.py` are ours; they use only interfaces that exist in both versions. Outputs:
`results/v5.1/` (unmodified v5.1) and `results/v5.2/` (v5.2 at commit `020d8bf`, the product commit of this release).

| Finding | v5.1 (reproduced) | v5.2 (same probe / fixture) | Regression tests |
|---|---|---|---|
| **G1** imported units changed by the NDJSON export | reviewer's probe: API import 201, export 200; second frame `t 100, theta 11, w [180, 0, 0]` (ms, deg, deg/s streamed as s, rad, rad/s); re-recorded labelled s/rad with the raw numbers (`edge-case-probes.json`). Our probe (`g1-g2-probe.json`): relative errors 999 (t in ms, mN·m), 56.3 (deg, deg/s), 0.895 (`wheel_rpm_*` in rad/s), 0.898 (g); `omega_*` missing from the frames; an incomplete vector HTTP **500** (`KeyError: 'w_z'`); an unmapped column 200 (dropped silently); status code 9 streamed as **"ok"** | frame `t 0.1, theta 0.19198621771937624, w [π, 0, 0]`; every profile within 2e-16 of the truth after export AND after replay and re-recording; incomplete vector, unmapped column, undeclared status code: HTTP **422** `export_not_possible` | `backend/tests/test_export_units.py` (38): every accepted unit, API import → export → actual replay (`/telemetry/connect` file source and the FileReplaySource transport) → new recording, physical values and time intervals row by row, identity controls, mixed units, missing `seq`, refusals, `dbtool export-audit` |
| **G2** repeated export/replay → invalid hello | reviewer's probe: lineage 511 → 996 → 2 239 → 4 725 → **9 697** bytes; generation 5 `rejected:invalid_hello`. Our probe (24 generations): the two-segment mixed chain fails at generation 5 (9 769 bytes), four reconnect segments at generation 4 (19 183), a declared-physical two-segment chain at generation 6 (16 276) | all four chains complete 24 generations with every row replayed; largest lineage 3 086 bytes (bound 6 144); synthetic stays synthetic, declared stays declared-physical and derived | `backend/tests/test_lineage_bounded.py` (10): 24 generations through FileReplaySource for mixed, reconnecting, declared-physical and unknown chains, near-limit v5.1 lineage, synthetic and unknown ancestors hidden in v5.1 nesting, truncation counted, a lineage that cannot fit is refused, descendants never evidence (API) |
| **G3** a skipped case gave `full_validation: true` | the reviewer's fixture with the v5.1 runner: exit **0**, "PASSED — all 2 suites ran and passed", `full_validation: true` with one skipped case (`results/v5.1/g3-runner-fixture/`). Our G3 tests against the v5.1 runner (`AERIS_RUNNER_UNDER_TEST`): **13 failed**, 16 passed — every interpreter-path test still passes (`test_run_tests-with-the-v5.1-runner.log`) | the same fixture with the v5.2 runner: exit **2**, INCOMPLETE, the skipped case named with its reason, `complete`/`full_validation` false (`results/v5.2/g3-runner-fixture/`) | `backend/tests/test_run_tests.py` (29): mixed pass/skip, all skipped, failure + skip, selected-only + skip, declared exclusion (exit 3) and four ways it does not apply, missing tools, a tool that cannot start, a suite without counts, a timeout, the committed policy, the macOS `/proc` decision |
| **G4** browser cancellation tested by a 300 ms race | the old `browser_v3.py` passed **3/3** here (this machine had done 83 of 390 runs at 300 ms; the reviewer's Mac had finished all 390, `browser_v3-unmodified-3-runs/`) — so the race is shown by the reviewer's log and probe, not by our run. The deterministic probe (`g4-states-probe*.json`, full speed and 4× CPU throttling) found three product defects: in ANALYZING the Cancel button was **visible** and the request was **silently ignored** (390 rows, COMPLETE); after one cancellation the button stayed **disabled "Cancelling…"**, so the next sweep could not be cancelled (it ran to 390); and a cancel in the update of the last run labelled the complete set **PARTIAL** ("Cancelled after 390 of 390 runs"). `browser_v52.py` against the v5.1 site code: **24 / 45** | ANALYZING: button hidden, a request sent anyway reported, complete result kept; the next sweep cancels; the last-run request is too late and said so. `browser_v52.py`: 45 / 45 in each of 5 runs; `browser_v3.py` (deterministic check): 49 / 49 in each of 5 runs (`results/v5.2/browser-repeats/`) | `site/tests/browser_v52.py` (45 checks: before start, during execution with the rows recomputed independently, last run, analysing, after completion, next sweep; full speed and CPU 4× slower, 3 attempts each, no retries), `site/tests/browser_v3.py` |

## Found while verifying v5.2 (not in the review)

**H1 — a race in an existing v5.1 browser check.** The first full v5.2 run (commit `6ca58fa`,
`full-run-1-6ca58fa/`) failed one check of `browser_v51.py`: "Recording a replay of the declared-physical recording
…" — `only 1 frame(s) were recorded; a recording needs at least two` (863 passed, 1 failed, exit code 1). The check
replayed a ~2 s recording at 1× and recorded until "replay finished"; when the page learned of the replay late, the
recording began just before the end. It is a test-design race present in v5.1: six isolated runs (three of v5.2,
three of the unmodified v5.1) all passed (`results/v5.2/browser_v51-investigation/`); they do not replace the failed
run. Corrected in commit `020d8bf` without a product change and without a longer wait: the same replay starts from
the connect form at 0.1× (at least 20 s, longer than every bounded wait before the recording starts) and the
recording stops after six replayed frames while the replay is still running — the check now asserts that
precondition. The second full run (`020d8bf`, the repository's `test-logs/`) passed.

## Full runs, repeats and checks

| Run | Commit | Result |
|---|---|---|
| full run 1 (`full-run-1-6ca58fa/`) | `6ca58fa` | FAILED — 863 passed, **1 failed** (H1), 0 skipped, 0 not run, 19 suites, exit code 1 |
| full run 2 (`../../test-logs/`, console: `full-run-2-020d8bf-console.log`) | `020d8bf` | PASSED — **864 passed**, 0 failed, 0 skipped, 0 not run, 19 suites, every test case executed (full validation on Linux), exit code 0 |
| `browser_v52.py` × 5, `browser_v3.py` × 5 | `020d8bf` | 45 / 45 and 49 / 49 every time; one further attempt of run 5 was cut by our shell's 10-minute command limit (no failure up to that point) and is kept as such (`results/v5.2/browser-repeats/SUMMARY.txt`) |
| campaign reproduction, 32 sampled rows (`numerical/`) | `020d8bf` | 32 / 32 **identical** to the stored campaign rows (seed 2026, 4 per study; backend 1.1.2, engine 1.1.0 unchanged) |
| CI workflow steps, locally from clean clones (`ci-local/`) | `020d8bf` | every step of the four jobs succeeded — backend 453, javascript 181 (after the schema and `index.html` drift checks), integration 14, browser 216 (= the 864 of the full run); each job's runner verdict "selected suites only … Not a full validation", exit code 0. A local execution of the workflow's run steps, **not a hosted CI run** (`ci-local/CI-LOCAL.md`) |

Release checks of the packaged archive: `../v5.2-release/`.

## Re-running

```bash
# probes (any checkout; the second argument is where the result goes)
backend/.venv/bin/python evidence/v5.2-verification/probes/edge_case_probes.py . /tmp/edge.json
backend/.venv/bin/python evidence/v5.2-verification/probes/g1_g2_probe.py . /tmp/g1g2.json
backend/.venv/bin/python evidence/v5.2-verification/probes/cancel_probe.py . /tmp/cancel.json          # Playwright
backend/.venv/bin/python evidence/v5.2-verification/probes/g4_states_probe.py . /tmp/g4.json [--throttle 4]
# the G3 tests against another runner
AERIS_RUNNER_UNDER_TEST=/path/to/other/scripts/run_tests.py backend/.venv/bin/python -m pytest backend/tests/test_run_tests.py
# the 32-row campaign check
cd studies && ../backend/.venv/bin/python verify_campaign.py --out /tmp/campaign-verification.json
```

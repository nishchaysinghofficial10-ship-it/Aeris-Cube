#!/usr/bin/env python3
"""Negative control of the firmware's allocation and injected-fault tests (v6.0, acceptance FW-5 and FW-6): each limit,
saturation count and protection check of the core is disabled in a TEMPORARY copy of firmware/ and the matching test
must then fail naming that check; without a change every one of those tests passes. The repository is never modified.

    python3 evidence/v6.0-verification/firmware-fault-tests/fault_tests_negative_control.py . [output.json]

Prints one line per mutation and writes the results (test output tails included) as JSON.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile

TESTS = {"alloc": "allocation: torque and speed limits, non-finite requests, saturation flags",
         "satreport": "allocation: saturation reported with the experiment result",
         "injected": "safety: injected faults (temperature, current, voltage, driver, encoder, IMU) stop the motors and latch",
         "overrun": "safety: late control steps latch LOOP_OVERRUN",
         "ready": "safety: a failed check leaves READY; re-test needs the cause gone"}
# (name, file, [exact text to remove or replace, ...], test, the failure lines must mention)
MUTATIONS = [
    ("allocation torque limit removed", "core/src/control.c",
     [("if (T > tmax) { T = tmax; sat = true; }\n        else if (T < -tmax) { T = -tmax; sat = true; }", "(void)tmax;")], "alloc", "torque clipped"),
    ("allocation speed limit removed", "core/src/control.c",
     [("if (T * om[i] > 0 && (om[i] >= c->w[i].speed_max_rads || om[i] <= -c->w[i].speed_max_rads)) { T = 0; sat = true; }", "(void)om;")], "alloc", "speed limit"),
    ("saturation count removed", "core/src/device.c",
     [("for (i = 0; i < AERIS_NW; i++) if (a.saturated[i]) d->exp_sat_steps[i]++;", "for (i = 0; i < AERIS_NW; i++) (void)a.saturated[i];")], "satreport", "torque limit"),
    ("over-temperature check removed", "core/src/device.c", [("f |= F_OVERTEMP;", "(void)0;")], "injected", "over-temperature"),
    ("over-current check removed", "core/src/device.c", [("f |= F_OVERCURRENT;", "(void)0;")], "injected", "over-current"),
    ("under-voltage check removed", "core/src/device.c", [("if (d->vbus > 0 && d->vbus < c->vbus_min_V) f |= F_UNDERVOLT;", "")], "injected", "under-voltage"),
    ("over-voltage check removed", "core/src/device.c", [("if (d->vbus > c->vbus_max_V) f |= F_OVERVOLT;", "")], "injected", "over-voltage"),
    ("driver error check removed", "core/src/device.c", [("if (m->seen && now - m->t_heartbeat_us <= DRV_STALE_US && m->axis_error) f |= F_DRV_ERROR;", "(void)m;")], "injected", "driver error"),
    ("encoder staleness check removed", "core/src/device.c", [("if (!m->t_encoder_us || now - m->t_encoder_us > ENC_STALE_US) f |= F_ENC_STALE;", "")], "injected", "encoder estimates stale"),
    ("driver heartbeat and encoder staleness checks removed", "core/src/device.c",
     [("else if (now - m->t_heartbeat_us > DRV_STALE_US) f |= F_DRV_STALE;", ""), ("if (!m->t_encoder_us || now - m->t_encoder_us > ENC_STALE_US) f |= F_ENC_STALE;", "")], "injected", "driver lost"),
    ("IMU staleness and estimator validity checks removed", "core/src/device.c",
     [("if (++d->imu_bad_reads >= IMU_BAD_LIMIT) d->faults |= F_IMU_STALE;", "++d->imu_bad_reads;"), ("if (!d->est_valid && d->state != ST_COMMISSIONING) f |= F_EST_INVALID;", "")], "injected", "IMU lost"),
    ("loop overrun check removed", "core/src/device.c", [("if (d->overrun_run >= OVERRUN_LIMIT) f |= F_LOOP_OVERRUN;", "")], "overrun", "LOOP_OVERRUN"),
    ("READY re-check removed", "core/src/device.c", [('if (bad) dev_set_state(d, ST_DISARMED, "no longer ready: a check failed");', "(void)bad;")], "ready", "READY → DISARMED"),
]


def number_of(test_name, src):
    names = [ln.split('run("', 1)[1].split('"', 1)[0] for ln in src.splitlines() if ln.strip().startswith('run("')]
    return names.index(test_name) + 1


def run_test(fw, build, num):
    env = dict(os.environ, AERIS_TEST_ONLY=str(num))
    b = subprocess.run(["make", "-s", "-C", fw, f"BUILD={build}", f"{build}/test_core"], capture_output=True, text=True, timeout=600)
    if b.returncode != 0:
        return None, "build failed: " + (b.stdout + b.stderr)[-600:]
    r = subprocess.run([f"{build}/test_core", "tests/fixtures"], cwd=fw, env=env, capture_output=True, text=True, timeout=600)
    return r.returncode, r.stdout


def main():
    repo = os.path.abspath(sys.argv[1])
    out = sys.argv[2] if len(sys.argv) > 2 else None
    results = {"repository_firmware": os.path.join(repo, "firmware"), "baseline": {}, "mutations": []}
    ok_all = True
    with tempfile.TemporaryDirectory(prefix="aeris-fw-mut-") as tmp:
        fw = os.path.join(tmp, "firmware")
        shutil.copytree(os.path.join(repo, "firmware"), fw, ignore=shutil.ignore_patterns("build", "__pycache__"))
        src_test = open(os.path.join(fw, "tests", "test_core.c"), encoding="utf-8").read()
        nums = {k: number_of(v, src_test) for k, v in TESTS.items()}
        for k, n in nums.items():
            code, text = run_test(fw, os.path.join(tmp, "build-base"), n)
            passed = code == 0 and "# firmware core tests: 1 passed, 0 failed" in text
            results["baseline"][k] = {"test": n, "name": TESTS[k], "exit": code, "passed": passed}
            ok_all &= passed
            print(f"baseline   test {n:2d} {'passes' if passed else 'DOES NOT PASS'}: {TESTS[k]}", flush=True)
        for i, (name, rel, edits, test, mention) in enumerate(MUTATIONS):
            path = os.path.join(fw, rel)
            original = open(path, encoding="utf-8").read()
            src = original
            missing = [a for a, _ in edits if a not in src]
            for a, b in edits:
                src = src.replace(a, b)
            open(path, "w", encoding="utf-8").write(src)
            code, text = run_test(fw, os.path.join(tmp, f"build-m{i}"), nums[test])
            open(path, "w", encoding="utf-8").write(original)
            fails = [ln for ln in (text or "").splitlines() if ln.startswith("#   ")]
            detected = code not in (0, None) and any(mention in ln for ln in fails)
            ok_all &= detected and not missing
            results["mutations"].append({"mutation": name, "file": "firmware/" + rel, "edits": [a for a, _ in edits], "edit_text_found": not missing,
                                         "test": nums[test], "exit": code, "detected": detected, "failure_lines": fails[:8]})
            print(f"mutation   {'DETECTED' if detected else 'NOT DETECTED'}: {name} → test {nums[test]} exit {code}"
                  + (f"  [edit text not found: {missing}]" if missing else "") + (f"  e.g. {fails[0][4:160]}" if fails else ""), flush=True)
    results["all_detected_and_baseline_passes"] = ok_all
    if out:
        with open(out, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=1)
    print(("every mutation detected; the unmodified tests pass" if ok_all else "NEGATIVE CONTROL INCOMPLETE"))
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())

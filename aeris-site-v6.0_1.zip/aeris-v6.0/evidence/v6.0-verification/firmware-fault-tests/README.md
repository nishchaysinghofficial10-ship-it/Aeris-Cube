# Firmware allocation and protection tests, and their negative control (v6.0, acceptance FW-5 and FW-6)

Added while filling the acceptance matrix, when it showed that several protection paths of the firmware core were
implemented but not exercised by any test, and that the allocation's saturation flags were computed but not reported.

**Product change** (firmware core): the experiment's result (`cmd_result` of `start_experiment`, completed or failed)
now reports `balancing_steps` and `saturated_steps` — per wheel, the number of balancing control steps in which the
allocation limited the requested torque (torque limit, speed limit or a non-finite request). Nothing else in the
core changed. **Test-only change** (synthetic device models): each wheel-driver model gained two fault-injection
values, `temp_inject_C` and `iq_inject_A` (zero unless a test sets them).

**New host tests** (`firmware/tests/test_core.c`, in the suite `firmware:host`):

| Test | What it checks |
|---|---|
| allocation: torque and speed limits, non-finite requests, saturation flags | `alloc_clip` on the edge configuration: requests within the limits unchanged; ±torque_max per wheel with the sign kept; no accelerating torque at the speed limit, braking allowed; non-finite requests become zero; the saturation flags |
| allocation: saturation reported with the experiment result | a 3 s edge experiment with and without a 0.16 N·m push: `balancing_steps` ≈ 1500, the push adds saturated steps on the drive wheel, the other wheels are never limited |
| safety: injected faults stop the motors and latch | during balancing, one fault at a time is injected into the models — motor over-temperature, over-current, under- and over-voltage, a driver that stops answering, a driver error in its heartbeat, encoder estimates that stop, an IMU that stops answering — and each must latch FAULT with its bit, name the protection, remove driver power, leave no driver in closed loop and fail the experiment command |
| safety: late control steps latch LOOP_OVERRUN | control steps that start three periods apart stop the experiment after the configured number of consecutive late steps |
| safety: a failed check leaves READY; re-test needs the cause gone | a bus-voltage drop in READY returns the device to DISARMED; an experiment request is refused; the self-test fails while the voltage is low and passes once it is back |

Plus one more configuration mutation (an unsupported wheel-driver kind is refused at `config.wheels[].driver`).

**Negative control** (`fault_tests_negative_control.py`): in a temporary copy of `firmware/`, each limit, the
saturation count and each protection check is removed in turn, and the matching test must then fail naming that
check; without a change every one of those tests passes. Result (`negative-control.log`, `negative-control.json`):
**13 of 13 mutations detected**, the five unmodified tests pass. The repository is never modified by the script.

Observation from the saturation test: with the reference profile's nominal model, the edge controller's request
already exceeds the candidate driver's torque limit for ≈ 53 control steps (≈ 0.1 s) after a 1° start — consistent with
the sizing result (`hardware/SIZING.md`: the candidate driver's continuous current holds the nominal cube only to
≈ 1.7° from balance). It is a property of the nominal model, not a measurement.

Not exercised, because the models cannot produce it: a non-finite IMU value (the register model produces integers;
`read_imu` refuses non-finite values before they are used).

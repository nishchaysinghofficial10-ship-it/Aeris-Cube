# Test run — PASSED — all 26 suites ran and passed; every test case executed (full validation)

2026-10-13T10:28:04+00:00 · Linux-6.18.44-fc-v114-x86_64-with-glibc2.39 (`linux`) · backend Python `/home/claude/aeris-v6/.venv/bin/python` · Node v22.22.2

- backend python: `/home/claude/aeris-v6/.venv/bin/python` (--backend-python, given as `/home/claude/aeris-v6/.venv/bin/python`)
- browser python: `/home/claude/aeris-v6/.venv/bin/python` (--browser-python, given as `/home/claude/aeris-v6/.venv/bin/python`)
- node: `/opt/node22/bin/node` (default: node on PATH)
- make: `/usr/bin/make` (default: make on PATH)
- c compiler: `/usr/bin/cc` (default: cc on PATH)
- qemu: `/home/claude/aeris-v6/toolchain/qemu/qemu/bin/qemu-system-xtensa` (--qemu, given as `/home/claude/aeris-v6/toolchain/qemu/qemu/bin/qemu-system-xtensa`)
- qemu build: `/home/claude/aeris-v6/repo/firmware/esp32s3/build/qemutest` (default)
- esptool python: `/home/claude/aeris-v6/toolchain/idf-venv/bin/python` (--esptool-python, given as `/home/claude/aeris-v6/toolchain/idf-venv/bin/python`)
- tool versions: make `GNU Make 4.3`; c compiler `cc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0`; qemu `QEMU emulator version 9.2.2 (esp_develop_9.2.2_20260417)`
- platform-exclusion policy: `/home/claude/aeris-v6/repo/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| drift | passed | 12 | 0 | 0 | 0 | 17.8 | drift.log |
| backend | passed | 535 | 0 | 0 | 0 | 331.8 | backend.log |
| firmware:host | passed | 33 | 0 | 0 | 0 | 0.7 | firmware-host.log |
| firmware:qemu | passed | 22 | 0 | 0 | 0 | 13.3 | firmware-qemu.log |
| js:assistant | passed | 9 | 0 | 0 | 0 | 0.5 | js-assistant.log |
| js:connect | passed | 9 | 0 | 0 | 0 | 0.5 | js-connect.log |
| js:engine | passed | 9 | 0 | 0 | 0 | 1.2 | js-engine.log |
| js:numerics | passed | 38 | 0 | 0 | 0 | 1.0 | js-numerics.log |
| js:platform | passed | 16 | 0 | 0 | 0 | 0.4 | js-platform.log |
| js:procs | passed | 7 | 0 | 0 | 0 | 2.0 | js-procs.log |
| js:resume | passed | 14 | 0 | 0 | 0 | 0.1 | js-resume.log |
| js:runs | passed | 14 | 0 | 0 | 0 | 0.4 | js-runs.log |
| js:schema | passed | 7 | 0 | 0 | 0 | 0.7 | js-schema.log |
| js:service | passed | 19 | 0 | 0 | 0 | 0.6 | js-service.log |
| js:ui | passed | 16 | 0 | 0 | 0 | 0.5 | js-ui.log |
| js:v4 | passed | 27 | 0 | 0 | 0 | 1.0 | js-v4.log |
| js:v5 | passed | 17 | 0 | 0 | 0 | 0.7 | js-v5.log |
| js:v51 | passed | 9 | 0 | 0 | 0 | 0.3 | js-v51.log |
| live | passed | 15 | 0 | 0 | 0 | 21.1 | live.log |
| browser:browser_check | passed | 50 | 0 | 0 | 0 | 109.3 | browser-browser_check.log |
| browser:browser_v3 | passed | 49 | 0 | 0 | 0 | 59.5 | browser-browser_v3.log |
| browser:browser_v4 | passed | 24 | 0 | 0 | 0 | 107.0 | browser-browser_v4.log |
| browser:browser_v5 | passed | 36 | 0 | 0 | 0 | 71.7 | browser-browser_v5.log |
| browser:browser_v51 | passed | 12 | 0 | 0 | 0 | 64.0 | browser-browser_v51.log |
| browser:browser_v52 | passed | 45 | 0 | 0 | 0 | 68.5 | browser-browser_v52.log |
| browser:browser_v6 | passed | 51 | 0 | 0 | 0 | 195.6 | browser-browser_v6.log |

**Totals (tests in the suites that ran):** 1095 passed, 0 failed, 0 skipped, 0 not run (1095 executed).
**Suites:** 26 passed, 0 passed with exclusions, 0 incomplete, 0 failed, 0 not run, 0 skipped, 0 not selected.
**Complete execution:** yes · **all applicable tests passed:** yes · **all tests executed:** yes.
**Full validation:** yes (exit code 0: every selected suite ran and every test case in it executed and passed).

# Test run — PASSED — selected suites only (1 of 26); every test case in them executed and passed; not selected: drift, backend, firmware:qemu, js:assistant, js:connect, js:engine, js:numerics, js:platform, js:procs, js:resume, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52, browser:browser_v6. Not a full validation.

2026-10-13T11:03:47+00:00 · Linux-6.18.44-fc-v114-x86_64-with-glibc2.39 (`linux`) · backend Python `None` · Node None

- make: `/usr/bin/make` (default: make on PATH)
- c compiler: `/usr/bin/cc` (default: cc on PATH)
- tool versions: make `GNU Make 4.3`; c compiler `cc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0`
- platform-exclusion policy: `/tmp/aeris-ci-firmware-6hux0jqp/work/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| firmware:host | passed | 38 | 0 | 0 | 0 | 6.1 | firmware-host.log |
| drift | not selected | — | — | — | — | — | — |
| backend | not selected | — | — | — | — | — | — |
| firmware:qemu | not selected | — | — | — | — | — | — |
| js:assistant | not selected | — | — | — | — | — | — |
| js:connect | not selected | — | — | — | — | — | — |
| js:engine | not selected | — | — | — | — | — | — |
| js:numerics | not selected | — | — | — | — | — | — |
| js:platform | not selected | — | — | — | — | — | — |
| js:procs | not selected | — | — | — | — | — | — |
| js:resume | not selected | — | — | — | — | — | — |
| js:runs | not selected | — | — | — | — | — | — |
| js:schema | not selected | — | — | — | — | — | — |
| js:service | not selected | — | — | — | — | — | — |
| js:ui | not selected | — | — | — | — | — | — |
| js:v4 | not selected | — | — | — | — | — | — |
| js:v5 | not selected | — | — | — | — | — | — |
| js:v51 | not selected | — | — | — | — | — | — |
| live | not selected | — | — | — | — | — | — |
| browser:browser_check | not selected | — | — | — | — | — | — |
| browser:browser_v3 | not selected | — | — | — | — | — | — |
| browser:browser_v4 | not selected | — | — | — | — | — | — |
| browser:browser_v5 | not selected | — | — | — | — | — | — |
| browser:browser_v51 | not selected | — | — | — | — | — | — |
| browser:browser_v52 | not selected | — | — | — | — | — | — |
| browser:browser_v6 | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 38 passed, 0 failed, 0 skipped, 0 not run (38 executed).
**Suites:** 1 passed, 0 passed with exclusions, 0 incomplete, 0 failed, 0 not run, 0 skipped, 25 not selected.
**Complete execution:** yes · **all applicable tests passed:** yes · **all tests executed:** no.
**Full validation:** no (exit code 0: every selected suite ran and every test case in it executed and passed).

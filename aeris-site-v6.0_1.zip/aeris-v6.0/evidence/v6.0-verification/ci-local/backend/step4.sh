if ! dpkg -s libssl-dev >/dev/null 2>&1; then
  sudo apt-get update && sudo apt-get install -y libssl-dev
fi

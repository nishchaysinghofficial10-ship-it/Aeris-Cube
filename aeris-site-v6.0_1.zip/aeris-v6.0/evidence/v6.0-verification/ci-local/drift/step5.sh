if ! command -v clang-18 >/dev/null || ! command -v wasm-ld-18 >/dev/null; then
  sudo apt-get update && sudo apt-get install -y clang-18 lld-18
fi

# The CI workflow's steps, executed locally (not a hosted CI run)

`python3 scripts/ci_local.py --python /usr/bin/python3.12 --node node --jobs drift,firmware,backend,javascript,integration`
ran every `run:` step of `.github/workflows/ci.yml` verbatim, each job in its own fresh clone of commit `c607e66`
(the product code of the release; the commits after it add the report, test logs and evidence), with GitHub's
default shell. `actions/setup-python` was provided by this machine's Python 3.12.3, `actions/setup-node` by Node
22.22.2; the guarded `apt-get` steps found clang 18, lld 18 and the OpenSSL headers installed and did nothing.
**Every step of the five jobs succeeded** (`CI-LOCAL.md`, `ci-local.json`, each step's log, each job's
`ci-test-logs/` artifact): drift 12 checks, firmware 38 host tests, backend 540, the 14 JavaScript suites 211, the live
integration 15 — each job's verdict "selected suites only … Not a full validation", exit code 0.

**Not executed here: the `browser` job.** Its install step runs `python -m playwright install --with-deps chromium`,
which downloads a browser; this build environment provides a preinstalled Chromium and must not download one. The
browser suites themselves ran in the definitive test run (`test-logs/`) and in the release validation, with the
preinstalled Chromium. No hosted CI service was used (this project has no repository configured for this session).

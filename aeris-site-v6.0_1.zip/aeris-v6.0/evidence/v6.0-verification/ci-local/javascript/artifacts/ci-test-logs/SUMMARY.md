# Test run — PASSED — selected suites only (14 of 26); every test case in them executed and passed; not selected: drift, backend, firmware:host, firmware:qemu, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52, browser:browser_v6. Not a full validation.

2026-10-13T11:09:23+00:00 · Linux-6.18.44-fc-v114-x86_64-with-glibc2.39 (`linux`) · backend Python `None` · Node v22.22.2

- node: `/tmp/aeris-ci-bin-peam3i45/node` (default: node on PATH)
- platform-exclusion policy: `/tmp/aeris-ci-javascript-sez3frkm/work/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| js:assistant | passed | 9 | 0 | 0 | 0 | 0.3 | js-assistant.log |
| js:connect | passed | 9 | 0 | 0 | 0 | 0.4 | js-connect.log |
| js:engine | passed | 9 | 0 | 0 | 0 | 0.9 | js-engine.log |
| js:numerics | passed | 38 | 0 | 0 | 0 | 0.7 | js-numerics.log |
| js:platform | passed | 16 | 0 | 0 | 0 | 0.4 | js-platform.log |
| js:procs | passed | 7 | 0 | 0 | 0 | 2.0 | js-procs.log |
| js:resume | passed | 14 | 0 | 0 | 0 | 0.1 | js-resume.log |
| js:runs | passed | 14 | 0 | 0 | 0 | 0.3 | js-runs.log |
| js:schema | passed | 7 | 0 | 0 | 0 | 0.5 | js-schema.log |
| js:service | passed | 19 | 0 | 0 | 0 | 0.4 | js-service.log |
| js:ui | passed | 16 | 0 | 0 | 0 | 0.4 | js-ui.log |
| js:v4 | passed | 27 | 0 | 0 | 0 | 0.8 | js-v4.log |
| js:v5 | passed | 17 | 0 | 0 | 0 | 0.7 | js-v5.log |
| js:v51 | passed | 9 | 0 | 0 | 0 | 0.3 | js-v51.log |
| drift | not selected | — | — | — | — | — | — |
| backend | not selected | — | — | — | — | — | — |
| firmware:host | not selected | — | — | — | — | — | — |
| firmware:qemu | not selected | — | — | — | — | — | — |
| live | not selected | — | — | — | — | — | — |
| browser:browser_check | not selected | — | — | — | — | — | — |
| browser:browser_v3 | not selected | — | — | — | — | — | — |
| browser:browser_v4 | not selected | — | — | — | — | — | — |
| browser:browser_v5 | not selected | — | — | — | — | — | — |
| browser:browser_v51 | not selected | — | — | — | — | — | — |
| browser:browser_v52 | not selected | — | — | — | — | — | — |
| browser:browser_v6 | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 211 passed, 0 failed, 0 skipped, 0 not run (211 executed).
**Suites:** 14 passed, 0 passed with exclusions, 0 incomplete, 0 failed, 0 not run, 0 skipped, 12 not selected.
**Complete execution:** yes · **all applicable tests passed:** yes · **all tests executed:** no.
**Full validation:** no (exit code 0: every selected suite ran and every test case in it executed and passed).

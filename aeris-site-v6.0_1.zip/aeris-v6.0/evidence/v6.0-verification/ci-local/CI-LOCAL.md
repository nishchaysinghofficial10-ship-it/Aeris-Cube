# Local execution of the CI workflow (not a CI service run)

2026-10-13T11:03:00+00:00 · commit `c607e66655911fc69490cd49339fc5df5ae4d08f` · Linux-6.18.44-fc-v114-x86_64-with-glibc2.39 · setup-python → `/usr/bin/python3.12` (3.12.3) · setup-node → `/opt/node22/bin/node` (v22.22.2)

## drift — all steps succeeded

| # | Step | Result | Seconds | Log |
|---:|---|---|---:|---|
| 1 | actions/checkout@v4 | ok — clean clone of c607e6665591 (working tree was clean) | 0.0 | — |
| 2 | actions/setup-python@v5 | ok — provided by this machine: /usr/bin/python3.12 (Python 3.12.3); workflow asks for 3.12 | 0.0 | — |
| 3 | actions/setup-node@v4 | ok — provided by this machine: /opt/node22/bin/node (v22.22.2); workflow asks for 22 | 0.0 | — |
| 4 | Install | ok | 34.0 | drift/step4.log |
| 5 | clang 18 and lld 18 (WebAssembly rebuild) | ok | 0.0 | drift/step5.log |
| 6 | Drift checks (index.html, schemas, kit, site data, sizing, fixtures, firmware release, Web | ok | 4.3 | drift/step6.log |
| 7 | actions/upload-artifact@v4 | ok — artifacts copied locally: ['ci-test-logs/'] | 0.0 | — |

run_tests.py: **PASSED — selected suites only (1 of 26); every test case in them executed and passed; not selected: backend, firmware:host, firmware:qemu, js:assistant, js:connect, js:engine, js:numerics, js:platform, js:procs, js:resume, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52, browser:browser_v6. Not a full validation.** · exit code 0 · totals {'passed': 12, 'failed': 0, 'skipped': 0, 'not_run': 0}

## firmware — all steps succeeded

| # | Step | Result | Seconds | Log |
|---:|---|---|---:|---|
| 1 | actions/checkout@v4 | ok — clean clone of c607e6665591 (working tree was clean) | 0.0 | — |
| 2 | actions/setup-python@v5 | ok — provided by this machine: /usr/bin/python3.12 (Python 3.12.3); workflow asks for 3.12 | 0.0 | — |
| 3 | OpenSSL headers (host crypto of the tests) | ok | 0.3 | firmware/step3.log |
| 4 | make -C firmware test | ok | 6.2 | firmware/step4.log |
| 5 | actions/upload-artifact@v4 | ok — artifacts copied locally: ['ci-test-logs/'] | 0.0 | — |

run_tests.py: **PASSED — selected suites only (1 of 26); every test case in them executed and passed; not selected: drift, backend, firmware:qemu, js:assistant, js:connect, js:engine, js:numerics, js:platform, js:procs, js:resume, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52, browser:browser_v6. Not a full validation.** · exit code 0 · totals {'passed': 38, 'failed': 0, 'skipped': 0, 'not_run': 0}

## backend — all steps succeeded

| # | Step | Result | Seconds | Log |
|---:|---|---|---:|---|
| 1 | actions/checkout@v4 | ok — clean clone of c607e6665591 (working tree was clean) | 0.0 | — |
| 2 | actions/setup-python@v5 | ok — provided by this machine: /usr/bin/python3.12 (Python 3.12.3); workflow asks for 3.12 | 0.0 | — |
| 3 | Install | ok | 22.5 | backend/step3.log |
| 4 | OpenSSL headers (the synthetic device process of the device end-to-end tests is built from | ok | 0.0 | backend/step4.log |
| 5 | pytest | ok | 302.7 | backend/step5.log |
| 6 | actions/upload-artifact@v4 | ok — artifacts copied locally: ['ci-test-logs/'] | 0.0 | — |

run_tests.py: **PASSED — selected suites only (1 of 26); every test case in them executed and passed; not selected: drift, firmware:host, firmware:qemu, js:assistant, js:connect, js:engine, js:numerics, js:platform, js:procs, js:resume, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52, browser:browser_v6. Not a full validation.** · exit code 0 · totals {'passed': 540, 'failed': 0, 'skipped': 0, 'not_run': 0}

## javascript — all steps succeeded

| # | Step | Result | Seconds | Log |
|---:|---|---|---:|---|
| 1 | actions/checkout@v4 | ok — clean clone of c607e6665591 (working tree was clean) | 0.0 | — |
| 2 | actions/setup-node@v4 | ok — provided by this machine: /opt/node22/bin/node (v22.22.2); workflow asks for 22 | 0.0 | — |
| 3 | actions/setup-python@v5 | ok — provided by this machine: /usr/bin/python3.12 (Python 3.12.3); workflow asks for 3.12 | 0.0 | — |
| 4 | JavaScript suites | ok | 8.2 | javascript/step4.log |
| 5 | actions/upload-artifact@v4 | ok — artifacts copied locally: ['ci-test-logs/'] | 0.0 | — |

run_tests.py: **PASSED — selected suites only (14 of 26); every test case in them executed and passed; not selected: drift, backend, firmware:host, firmware:qemu, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52, browser:browser_v6. Not a full validation.** · exit code 0 · totals {'passed': 211, 'failed': 0, 'skipped': 0, 'not_run': 0}

## integration — all steps succeeded

| # | Step | Result | Seconds | Log |
|---:|---|---|---:|---|
| 1 | actions/checkout@v4 | ok — clean clone of c607e6665591 (working tree was clean) | 0.0 | — |
| 2 | actions/setup-python@v5 | ok — provided by this machine: /usr/bin/python3.12 (Python 3.12.3); workflow asks for 3.12 | 0.0 | — |
| 3 | actions/setup-node@v4 | ok — provided by this machine: /opt/node22/bin/node (v22.22.2); workflow asks for 22 | 0.0 | — |
| 4 | scripts/install.sh --python python | ok | 25.2 | integration/step4.log |
| 5 | python3 scripts/run_tests.py --out ci-test-logs --only live --backend-python "$GITHUB_WORK | ok | 21.1 | integration/step5.log |
| 6 | actions/upload-artifact@v4 | ok — artifacts copied locally: ['ci-test-logs/'] | 0.0 | — |

run_tests.py: **PASSED — selected suites only (1 of 26); every test case in them executed and passed; not selected: drift, backend, firmware:host, firmware:qemu, js:assistant, js:connect, js:engine, js:numerics, js:platform, js:procs, js:resume, js:runs, js:schema, js:service, js:ui, js:v4, js:v5, js:v51, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52, browser:browser_v6. Not a full validation.** · exit code 0 · totals {'passed': 15, 'failed': 0, 'skipped': 0, 'not_run': 0}

**All steps succeeded:** yes.

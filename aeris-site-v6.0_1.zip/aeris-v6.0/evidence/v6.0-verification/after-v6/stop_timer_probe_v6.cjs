/* The review's stop_timer_probe.cjs scenario applied to v6's shared helper (site/tests/lib/procs.js), because the code
   that probe extracts from live_backend.test.js (v5.2's inline exited()/stopBackend()) no longer exists there.
   Same fixture: the old child exits on SIGTERM; a replacement child is then started; afterwards EVERY timer the stop
   created is fired by hand (as the original probe does with timers[0]()), whether or not it was cleared.
   Usage: node stop_timer_probe_v6.cjs <repository> [output.json]. No real process is started or killed. */
const fs = require("fs"), path = require("path");
const procs = require(path.join(path.resolve(process.argv[2]), "site/tests/lib/procs.js"));
const kills = [], timers = [], cleared = [];
function child(name) {
  const l = {};
  return { name, exitCode: null, signalCode: null,
    once(ev, f) { (l[ev] = l[ev] || []).push(f); }, on(ev, f) { (l[ev] = l[ev] || []).push(f); },
    removeListener(ev, f) { l[ev] = (l[ev] || []).filter((g) => g !== f); },
    listeners: () => Object.values(l).reduce((n, a) => n + a.length, 0),
    kill(signal) { kills.push({ name, signal }); if (signal === "SIGTERM") { this.signalCode = signal; (l.exit || []).slice().forEach((f) => f(null, signal)); } } };
}
(async () => {
  let proc = child("old backend");
  const old = proc;
  const res = await procs.stop(proc, { setTimeout: (fn, ms) => { timers.push({ fn, ms }); return timers.length; }, clearTimeout: (id) => cleared.push(id) });
  proc = child("replacement backend");                // the suite starts a new backend in the same variable
  timers.forEach((t) => t.fn());                       // fire every timer the stop created, even the cleared ones
  const again = await procs.stop(old);                 // a repeated stop of the old child is idempotent
  const result = { kills, stop_result: res, timers_created: timers.map((t) => t.ms), timers_cleared: cleared,
    listeners_left_on_old_child: old.listeners(), repeated_stop_same_result: again === res,
    replacement_killed: kills.some((k) => k.name === "replacement backend") };
  console.log(JSON.stringify(result, null, 2));
  if (process.argv[3]) fs.writeFileSync(process.argv[3], JSON.stringify(result, null, 2) + "\n");
  if (result.replacement_killed) { console.log("DEFECT PRESENT: the old child's timer killed the replacement"); process.exitCode = 1; }
  else console.log("Fixed: the old child's timers never kill the replacement (bound to the old child, cleared when it exited).");
})();

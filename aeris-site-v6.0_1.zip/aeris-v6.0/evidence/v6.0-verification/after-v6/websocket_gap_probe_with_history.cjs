// MODIFIED COPY of the review's websocket_gap_probe.cjs (evidence/v5.2-independent-review/supplied/…): the same
// deterministic poll -> WebSocket transition, but the fixture's history endpoint RETURNS frame 1 of the new stream, as
// the original fixture's description says it should ("frame 1 remains available through /telemetry/frames in the new
// stream"; the original stub answers every history request with an empty list). Changes: the request stub and the
// final assertions (expects [1, 2], once each, in order, no gap). Usage: node <this> REPO OUTPUT.json
const path=require('path'),fs=require('fs'),assert=require('assert');
const root=path.resolve(process.argv[2]);
const A=require(path.join(root,'site/js/adapters/hardware-telemetry.js'));
const sockets=[],timers=[],requests=[],events=[];
class Socket { constructor(url){this.url=url;sockets.push(this);} close(){} }
let stream='old',lastN=1;
const history={new:[{n:1,t:0.1}]};                                   // CHANGED: the new process's retained history
A.bind({configured:()=>true,available:()=>({ok:true}),capabilities:()=>({reported:true,telemetry:{available:true}}),wsUrl:'ws://fixture',
 request:(method,url)=>{requests.push(url);
   if(url.startsWith('/telemetry/frames')){const q=new URLSearchParams(url.split('?')[1]);const s=q.get('stream')||stream;const after=+q.get('after');
     return Promise.resolve({stream_id:stream,last_n:lastN,frames:s===stream?(history[s]||[]).filter(f=>f.n>after):[],missed:0});}
   return Promise.resolve({stream_id:stream,last_n:lastN});}});
function message(sock,data){sock.onmessage({data:JSON.stringify(data)});}
const client=A.live(e=>events.push(e),{WebSocket:Socket,stream:'old',after:1,wait:(ms,fn)=>{timers.push(fn);return null;}});
(async()=>{
  sockets[0].onopen();message(sockets[0],{type:'status',status:{stream_id:'old',last_n:1}});
  sockets[0].onclose({code:1006});
  await new Promise(r=>setImmediate(r));
  stream='new';lastN=1;
  assert.equal(timers.length,1);timers.shift()();
  sockets[1].onopen();message(sockets[1],{type:'status',status:{stream_id:'new',last_n:1}});
  lastN=2;history.new.push({n:2,t:0.2});message(sockets[1],{type:'frames',stream:'new',frames:[{n:2,t:0.2}],dropped:0});
  for(let i=0;i<5;i++) await new Promise(r=>setImmediate(r));
  const frames=events.filter(e=>e.type==='frames').flatMap(e=>e.frames.map(f=>f.n));
  const result={fixture:'MODIFIED copy of the review fixture: the new stream\'s history returns frame 1 (and 2 once received).',requests,events,delivered:frames,cursor:client.lastN(),gap_events:events.filter(e=>e.type==='gap').length};
  client.close();fs.writeFileSync(process.argv[3],JSON.stringify(result,null,2));
  assert.deepEqual(frames,[1,2]);assert.equal(result.gap_events,0);assert.equal(result.cursor,2);
  console.log('Recovered: the new stream delivered [1, 2] once each and in order; frame 1 came from the history; no gap event.');
})().catch(e=>{client.close();console.error(e);process.exitCode=1;});

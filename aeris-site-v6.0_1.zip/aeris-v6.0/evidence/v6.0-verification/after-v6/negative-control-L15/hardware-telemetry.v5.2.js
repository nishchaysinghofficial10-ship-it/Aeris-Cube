/* =====================================================================
   AERIS · HardwareTelemetryAdapter — live telemetry through the research backend
   (docs/TELEMETRY.md). The browser never talks to a device: the backend's telemetry
   bridge connects to ONE source (NDJSON over TCP on this computer, a replayed file,
   or a stored recording), validates every line strictly and streams the accepted
   frames here over the WebSocket /telemetry/live, with polling (/telemetry/frames)
   as the fallback. Everything is READ-ONLY: nothing is sent to a device.

   A source DECLARES what it is. The synthetic emulator (and any test source) says
   synthetic: true and is always shown as "SYNTHETIC … not the physical cube"; a source
   that declares itself physical is shown as declared, never as verified. No
   telemetry makes a model VALIDATED.

   Without a reachable research backend that reports telemetry, HARDWARE mode is
   unavailable and says why. Offline import of recorded logs (aeris-hardware-run/1)
   and the frame checker below work without a backend.
   ===================================================================== */
var HardwareTelemetryAdapter = (function () {
  "use strict";
  var SCHEMA = typeof AERIS_SCHEMA !== "undefined" ? AERIS_SCHEMA : require("../platform/schema.js");
  var name = "hardware-telemetry", api = null;
  var API = "/api/v1";
  var NO_BACKEND = "Telemetry reaches this site through the AERIS research backend (it connects to the source, validates every frame and records). No research backend is configured.";
  function bind(a) { api = a || null; return adapter; }
  function bound() { return api; }
  function caps() { var c = api && api.capabilities ? api.capabilities() : null; return c && c.reported ? c : null; }
  function available() {
    if (!api || !api.configured || !api.configured()) return { ok: false, reason: NO_BACKEND };
    var a = api.available();
    if (!a.ok) return { ok: false, reason: "Telemetry needs the research backend. " + a.reason };
    var c = caps(), t = c && c.telemetry;
    if (!t) return { ok: false, reason: "The research backend did not report a telemetry path (backend older than v5)." };
    if (!t.available) return { ok: false, reason: "Telemetry is switched off on the research backend (AERIS_TELEMETRY_BRIDGE=none)." };
    return { ok: true, reason: null };
  }
  function capabilities() {
    var c = caps(), t = c && c.telemetry;
    return { kind: "hardware", implemented: true, live: !!(t && t.available), readOnly: true, transports: t ? t.transports : [], protocol: t ? t.protocol : "aeris-telemetry-ndjson/1", frame: "aeris-telemetry-frame/1",
      physicalDevice: "declared by the source; never verified by the software" };
  }
  function req(method, path, body) {
    if (!api) return Promise.reject({ code: "unavailable", message: NO_BACKEND });
    var av = available(); if (!av.ok) return Promise.reject({ code: "unavailable", message: av.reason });
    return api.request(method, path, body);
  }
  function status() { return req("GET", "/telemetry/status"); }
  function connect(spec) { return req("POST", "/telemetry/connect", spec || { source: "tcp", host: "127.0.0.1", port: 47100 }); }
  function disconnect() { return req("POST", "/telemetry/disconnect"); }
  function files() { return req("GET", "/telemetry/files"); }
  function recordings() { return req("GET", "/hardware/recordings"); }
  function recording(id) { return req("GET", "/hardware/recordings/" + encodeURIComponent(id)); }
  function startRecording(n) { return req("POST", "/telemetry/recordings/start", { name: n || "telemetry recording" }); }
  function stopRecording() { return req("POST", "/telemetry/recordings/stop"); }
  function runs() { return req("GET", "/runs?limit=50"); }
  function compare(runId, recId, protocolId) { var b = { run_id: runId, recording_id: recId }; if (protocolId) b.protocol_id = protocolId; return req("POST", "/hardware/compare", b); }
  function exportUrl(id, fmt) { return api && api.baseUrl ? api.baseUrl + API + "/hardware/recordings/" + encodeURIComponent(id) + "/export?format=" + (fmt === "ndjson" ? "ndjson" : "json") : null; }

  /* ---------------- live stream: WebSocket first, polling as the fallback ----------------
     onEvent receives {type:"frames", frames, dropped} (frames de-duplicated by the hub index n, in order),
     {type:"status", status}, {type:"transport", kind:"websocket"|"polling"|"closed", reason}, {type:"gap", missed}
     and, since v5.1, {type:"stream", stream, previous, reason} when the backend's stream changed.

     Stream identity (v5.1, review finding F2; docs/TELEMETRY.md §7). A frame index n only means something within
     one stream: every backend process has a new stream_id (sent with every status, live batch and poll answer) and
     its n starts again at 1. The cursor and the de-duplication are kept per stream: when a new stream_id appears the
     cursor starts again at 0 and the caller is told to reset its display ("stream" event) before the new stream's
     frames are delivered; anything that still arrives from a stream this client has left is ignored ("stale").
     Within one stream nothing changes: each frame once, in order, across WebSocket drops and polling.
     opts.stream / opts.after: the stream and the last index the caller already shows (a panel that was hidden and
     shown again), so a new live() continues that stream or reports that it changed.
     Backward compatibility: a v5 backend sends no stream_id. Then the client falls back to the one restart sign it
     can trust — the backend's frame counter (last_n of a poll answer, or of the first status on a new WebSocket) is
     BELOW the cursor — and starts again from 0. A restart after which the new process has already counted past the
     old cursor cannot be seen without a stream_id (it looks like a gap); v5.1 backends always send one. */
  function live(onEvent, opts) {
    opts = opts || {};
    var closed = false, ws = null, pollTimer = null, wsFailures = 0, mode = null, polls = 0, retired = {}, changes = 0, openGuard = null;
    var streamId = typeof opts.stream === "string" && opts.stream ? opts.stream : null;
    var lastN = typeof opts.after === "number" && opts.after > 0 ? opts.after : 0;
    var WS = opts.WebSocket || (api && api.WS) || (typeof WebSocket !== "undefined" ? WebSocket : null);
    var wait = opts.wait || function (ms, fn) { return setTimeout(fn, ms); };
    function emit(e) { if (!closed) { try { onEvent(e); } catch (x) { /* a display error never stops the stream */ } } }
    /* a new stream: forget the old one's cursor and tell the caller (it resets its display) */
    function restart(sid, reason) {
      var prev = streamId; if (prev) retired[prev] = true;
      streamId = sid; lastN = 0; changes++;
      emit({ type: "stream", stream: sid, previous: prev, reason: reason });
    }
    /* the stream a message comes from: "ok" (the current one, or a backend without stream ids) or "stale" (a stream this
       client has left: its answer is ignored). The first id seen is adopted silently unless frames of an unnamed
       stream (a v5 backend) were delivered before it. */
    function adopt(sid) {
      if (typeof sid !== "string" || !sid) return "ok";
      if (sid === streamId) return "ok";
      if (retired[sid]) return "stale";
      if (streamId === null && lastN === 0) { streamId = sid; return "ok"; }
      restart(sid, "The research backend's telemetry stream changed (the backend was restarted): the display starts again.");
      return "ok";
    }
    /* v5 backends only (no stream id): the backend's counter below the cursor can only mean a new process */
    function regressed(sid, serverLastN) {
      if ((typeof sid === "string" && sid) || typeof serverLastN !== "number" || !(serverLastN < lastN)) return false;
      restart(null, "The research backend's frame counter went back (a backend without stream ids was restarted): the display starts again.");
      return true;
    }
    function deliver(frames, dropped) {
      var fresh = (frames || []).filter(function (f) { return typeof f.n === "number" && f.n > lastN; });
      fresh.sort(function (a, b) { return a.n - b.n; });
      if (fresh.length) { lastN = fresh[fresh.length - 1].n; emit({ type: "frames", frames: fresh, dropped: dropped || 0 }); }
    }
    function setMode(k, reason) { if (mode !== k) { mode = k; emit({ type: "transport", kind: k, reason: reason || null }); } }
    function poll() {
      if (closed) return;
      req("GET", "/telemetry/frames?after=" + lastN + "&limit=500" + (streamId ? "&stream=" + encodeURIComponent(streamId) : "")).then(function (d) {
        if (closed || !d) return;
        if (adopt(d.stream_id) === "stale") return;
        if (regressed(d.stream_id, d.last_n)) return;               // the next poll starts at 0
        if (d.missed) emit({ type: "gap", missed: d.missed });
        deliver(d.frames, 0);
      }, function (e) { emit({ type: "error", error: e }); }).then(function () {
        if (closed) return;
        status().then(function (s) { if (adopt(s && s.stream_id) !== "stale") emit({ type: "status", status: s }); }, function () { /* reported by the frames call */ });
        polls++;
        if (wsFailures >= 3 && polls % 40 === 0) wsFailures = 2;        // about every 10 s of polling, try the WebSocket once more
        pollTimer = wait(opts.pollMs || 250, function () { if (wsFailures < 3 && WS && api && api.wsUrl) openWs(); else poll(); });
      });
    }
    function openWs() {
      if (closed) return;
      var url = api && api.wsUrl ? api.wsUrl + API + "/telemetry/live" : null;
      if (!WS || !url) { setMode("polling", !WS ? "This browser has no WebSocket." : "No WebSocket URL is configured for the research backend."); poll(); return; }
      var opened = false, first = true, done = false, sock, guard = null;
      try { sock = ws = new WS(url); } catch (e) { wsFailures++; setMode("polling", "WebSocket failed: " + (e && e.message || e)); poll(); return; }
      /* the end of this socket, handled once: browsers report a connection that could not be made with error and then
         close, Node's WebSocket (used by the integration tests) only with error, and a connection attempt that never
         settles is given up after wsOpenTimeoutMs. Polling takes over at once in every case. */
      function ended(ev, why) {
        if (done) return; done = true;
        if (guard !== null) { clearTimeout(guard); guard = null; }
        if (ws === sock) ws = null;
        if (closed) return;
        if (!opened) wsFailures++;
        if (ev && ev.code === 4429) wsFailures = 3;
        setMode("polling", ev && ev.code === 4429 ? "The backend's live-client limit is reached." : why || (opened ? "The live connection closed; polling until it reconnects." : "The WebSocket could not be opened."));
        poll();
      }
      sock.onopen = function () { if (done) return; opened = true; wsFailures = 0; if (guard !== null) { clearTimeout(guard); guard = null; } setMode("websocket"); };
      sock.onmessage = function (m) {
        if (closed || done) return;
        var d; try { d = JSON.parse(m.data); } catch (e) { return; }
        if (d.type === "frames") { first = false; if (adopt(d.stream) !== "stale") deliver(d.frames, d.dropped); }
        else if (d.type === "status") {
          var s = d.status || {};
          if (adopt(s.stream_id) === "stale") return;
          if (first) regressed(s.stream_id, s.last_n);                // the first message of a socket: sent before any of its frames
          first = false;
          emit({ type: "status", status: d.status });
        }
        else if (d.type === "error") emit({ type: "error", error: d.error });
      };
      sock.onclose = function (ev) { ended(ev); };
      sock.onerror = function () { if (!opened) ended(null); };          // an open socket that fails is closed next (onclose)
      // a safety net, not a schedule: a plain timer (opts.wait stays the poll scheduler), unref'd where the host allows it
      guard = setTimeout(function () { guard = null; if (!opened && !done) { try { sock.close(); } catch (e) { /* ignore */ } ended(null, "The WebSocket did not open in time."); } }, opts.wsOpenTimeoutMs || 8000);
      if (guard && typeof guard.unref === "function") guard.unref();
      openGuard = function () { if (guard !== null) { clearTimeout(guard); guard = null; } };
    }
    openWs();
    return { close: function () { closed = true; if (openGuard) openGuard(); if (ws) try { ws.close(); } catch (e) { /* ignore */ } if (pollTimer) clearTimeout(pollTimer); mode = "closed"; }, lastN: function () { return lastN; }, mode: function () { return mode; },
      streamId: function () { return streamId; }, streamChanges: function () { return changes; },
      /* a status the caller fetched itself (not through this stream): "stale" when it comes from a stream this client
         has left; a new stream id is adopted exactly as if it had arrived here (the "stream" event comes first) */
      observe: function (sid) { return closed ? "stale" : adopt(sid); } };
  }

  /* the provenance banner text for a status/provenance object (the same wording everywhere) */
  function provenanceLabel(p) {
    if (!p || !p.source_kind) return { cls: "none", text: "No telemetry source" };
    if (p.synthetic) return { cls: "synthetic", text: (p.replay ? "REPLAY · " : "") + (p.label || "SYNTHETIC — not the physical cube") };
    if (p.declared_physical) return { cls: "declared", text: (p.replay ? "REPLAY · " : "") + "Declared physical device " + (p.device_id || "") + " — not verified by the software" };
    return { cls: "unknown", text: "Source of undeclared kind (" + p.source_kind + ")" };
  }

  /* one telemetry frame (aeris-telemetry-frame/1), checked strictly — nothing is coerced:
     { t [s, ≥ 0], seq (integer ≥ 0), mode edge|corner|free, q[4] (unit, w x y z) | theta [rad], w[3] [rad/s],
       wheel_rpm[3] [rpm], torque_cmd[3] [N·m], torque_meas[3] [N·m], imu: { gyro[3] [rad/s], accel[3] [m/s²] },
       status ok|idle|calibrating|fault|estop }  (the same rules as backend/aeris_backend/hardware/ingest.py) */
  var MODES = ["edge", "corner", "free"], STATUS = ["ok", "idle", "calibrating", "fault", "estop"];
  var KNOWN = ["schema", "t", "seq", "mode", "q", "theta", "w", "wheel_rpm", "torque_cmd", "torque_meas", "imu", "status"];
  function num(x) { return typeof x === "number" && isFinite(x); }
  function parseFrame(f) {
    var E = [], W = [];
    if (!f || typeof f !== "object" || Array.isArray(f)) return { ok: false, errors: ["frame is not an object"], warnings: W };
    function vec(o, k, n, path) { if (!(k in o)) return null; var v = o[k]; if (!Array.isArray(v) || v.length !== n || !v.every(num)) { E.push((path || k) + ": must be " + n + " finite numbers"); return null; } return v; }
    if (f.schema != null && f.schema !== "aeris-telemetry-frame/1") E.push("schema: expected 'aeris-telemetry-frame/1'");
    if (!num(f.t)) E.push("t: required finite number (seconds since the start of the recording)"); else if (f.t < 0) E.push("t: must be ≥ 0");
    if ("seq" in f && !(Number.isInteger(f.seq) && f.seq >= 0)) E.push("seq: must be a non-negative integer");
    if ("mode" in f && MODES.indexOf(f.mode) < 0) E.push("mode: must be one of " + MODES.join(", "));   // optional in the published schema; checked when present
    var q = vec(f, "q", 4), hasTh = "theta" in f;
    if (hasTh && !num(f.theta)) E.push("theta: must be a finite number [rad]");
    if (!("q" in f) && !hasTh) E.push("attitude: q[4] (w, x, y, z) or theta [rad] is required");
    if (q) { var n = Math.hypot(q[0], q[1], q[2], q[3]); if (Math.abs(n - 1) > 1e-3) E.push("q: not a unit quaternion (|q| = " + n.toFixed(5) + "; tolerance 1e-3)"); }
    ["w", "wheel_rpm", "torque_cmd", "torque_meas"].forEach(function (k) { vec(f, k, 3); });
    if ("imu" in f) { if (!f.imu || typeof f.imu !== "object" || Array.isArray(f.imu)) E.push("imu: must be an object { gyro[3], accel[3] }"); else { vec(f.imu, "gyro", 3, "imu.gyro"); vec(f.imu, "accel", 3, "imu.accel"); } }
    if ("status" in f && STATUS.indexOf(f.status) < 0) E.push("status: must be one of " + STATUS.join(", "));
    Object.keys(f).forEach(function (k) { if (KNOWN.indexOf(k) < 0 && ["n", "session", "segment", "stream", "rx", "type", "units"].indexOf(k) < 0) W.push("unknown field '" + k + "' ignored"); });
    return { ok: E.length === 0, errors: E, warnings: W };
  }
  /* sequence numbers of consecutive frames: dropouts, duplicates and reordering (for a live stream or a log) */
  function streamQuality(frames) {
    var drops = 0, dup = 0, back = 0, prev = null, prevT = null, nonMono = 0;
    frames.forEach(function (f) {
      if (Number.isInteger(f.seq) && prev !== null) { var d = f.seq - prev; if (d > 1) drops += d - 1; else if (d === 0) dup++; else if (d < 0) back++; }
      if (num(f.t) && prevT !== null && !(f.t > prevT)) nonMono++;
      if (Number.isInteger(f.seq)) prev = f.seq; if (num(f.t)) prevT = f.t;
    });
    return { frames: frames.length, dropped: drops, duplicates: dup, reordered: back, nonMonotonicTime: nonMono };
  }
  /* offline import of a recorded hardware run (real data supplied by the user) */
  function importRecording(obj) { var v = SCHEMA.validateHardwareRun(obj); return { ok: v.ok, errors: v.errors, warnings: v.warnings, recording: v.ok ? obj : null }; }
  var adapter = { name: name, kind: "hardware", label: "Telemetry via the research backend (read-only)", bind: bind, bound: bound, available: available, capabilities: capabilities,
    status: status, connect: connect, disconnect: disconnect, files: files, recordings: recordings, recording: recording, startRecording: startRecording, stopRecording: stopRecording,
    runs: runs, compare: compare, exportUrl: exportUrl, live: live, provenanceLabel: provenanceLabel,
    parseFrame: parseFrame, streamQuality: streamQuality, importRecording: importRecording, REASON: NO_BACKEND };
  return adapter;
})();
if (typeof module !== "undefined") module.exports = HardwareTelemetryAdapter;

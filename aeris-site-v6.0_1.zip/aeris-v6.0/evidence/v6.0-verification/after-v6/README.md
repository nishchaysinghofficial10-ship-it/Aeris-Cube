# The v5.2 review findings re-checked on v6.0 (same probes), and the V52-1d negative control

`run_after_probes.sh` runs the reviewer's probes **unchanged** from `evidence/v5.2-independent-review/supplied/`
against this tree, two probes of ours where the reviewer's cannot answer the question on v6 (each says so in its
header), and the negative control of the live regression L15. Run at commit `ff3d2f8` (the tree whose firmware,
backend and site code is final for v6.0 except release metadata), Linux x86-64, Node 22.22.2, Python 3.12.3 with the
backend's locked environment. The outputs here are that run's. Synthetic fixtures only; no hardware.

| Finding | v5.2 (reproduction-v5.2/) | v6.0 (this folder) |
|---|---|---|
| **V52-1** reconnect gap | reviewer's `websocket_gap_probe.cjs`: delivered `[2]`, frame 1 of the new stream never requested, cursor 2, no gap event | same probe (it asserts the defect, so it exits 1 after writing its JSON): v6 **requests the new stream's history from n = 0** (`/telemetry/frames?after=0&…&stream=new`); the reviewer's stub answers every history request with an empty list, so frame 1 cannot be recovered and v6 reports it as an explicit **gap** (`from 1, to 1, missed 1`) instead of advancing silently (`websocket-gap-probe.*`) |
| V52-1 with a history that has frame 1 | — | `websocket_gap_probe_with_history.cjs` (a marked copy of the reviewer's probe whose stub returns the new stream's frames, as the fixture's own description says): v6 delivers **`[1, 2]`, once each, in order, no gap**, exit 0; the same probe on **v5.2's adapter fails** (delivers `[2]` and never requests the new stream's history), exit 1 (`websocket-gap-probe-with-history*.{json,log}`) |
| **V52-1d** real backend | L14 depends on timing (passed 14/14 three times here; failed on the reviewer's Mac) | live test **L15** (a gated socket makes the race deterministic against a real backend process): **fails with v5.2's adapter**, **passes with v6's** (`negative-control-L15/`, run with `AERIS_LIVE_ONLY=L1,L15`; L1 creates the API client; a selection is a diagnosis, the suite result is the full run) |
| **V52-2** live provenance | reviewer's `provenance_probe.py`: all four artificial lineage cases `live: true`, `synthetic: false` | same probe: the three synthetic-ancestry cases are `live: false`, `synthetic: true`, trust `synthetic`, label SYNTHETIC DATA; the unknown case is `live: false`, trust **`unknown`** (distinct from synthetic), label UNKNOWN ORIGIN; the control stays declared-physical, `physical_verified: false` (`provenance-*`) |
| **V52-3** stop timer | reviewer's `stop_timer_probe.cjs`: the old child's 5 s timer kills the replacement | the reviewer's probe extracts v5.2's inline stop code from `live_backend.test.js`, which is gone (exit 1, `stop-timer-probe.log`); `stop_timer_probe_v6.cjs` applies the same scenario to the shared helper `site/tests/lib/procs.js` and fires every timer by hand: **replacement never killed**, both timers cleared when the old child exited, no listeners left, a repeated stop returns the same result (`stop-timer-probe-v6.*`) |
| **V52-4** audit depth | reviewer's `export_probe.py current`: audit lists ORIGINAL and COPY_1, not COPY_2 | same probe: COPY_2 **confirmed** with its chain `COPY_2 → COPY_1 → ORIGINAL`, `audit_missing_corrupt_descendant: false` (`export-probe.log`, `export-probe/export-probe-results.json`; the probe's database is not kept) |

Regression tests independent of these probes: `site/tests/resume.test.js` (adapter catch-up cases),
`site/tests/live_backend.test.js` L14–L15, `backend/tests/test_live_provenance.py`, `site/tests/procs.test.js`,
`backend/tests/test_export_audit.py` — all in the definitive run (`test-logs/`).

#!/usr/bin/env bash
# Re-run the v5.2 review's probes (unchanged, from evidence/v5.2-independent-review/supplied/) against THIS tree, and
# the V52-1d negative control. Writes its outputs next to this script. Needs Node, backend/.venv and git (for the
# v5.2 adapter of the negative control, read from the tag aeris-v5.2).
#   evidence/v6.0-verification/after-v6/run_after_probes.sh
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="$(cd "$HERE/../../.." && pwd)"
PROBES="$REPO/evidence/v5.2-independent-review/supplied/aeris-v5.2-review-evidence"
PY="${AERIS_PYTHON:-$REPO/backend/.venv/bin/python}"
cd "$REPO"
echo "# after-v6 probes at $(git rev-parse HEAD 2>/dev/null || echo 'no git') — $(date -u +%Y-%m-%dT%H:%M:%SZ); node $(node -v); $("$PY" -V)"

# V52-1: the review's deterministic poll → WebSocket replay. The probe ASSERTS THE DEFECT (delivered [2]); on v6 its
# assertion fails after it has written its JSON, which is the expected outcome here.
node "$PROBES/websocket_gap_probe.cjs" "$REPO" "$HERE/websocket-gap-probe.json" > "$HERE/websocket-gap-probe.log" 2>&1
echo "websocket_gap_probe.cjs exit $? (non-zero expected: the defect it asserts is gone)" | tee -a "$HERE/websocket-gap-probe.log"
node -e 'const r=require(process.argv[1]);console.log("delivered",JSON.stringify(r.delivered),"cursor",r.cursor,"gap events",r.gap_events,"missing frame 1",r.missing_frame_1,"history requests",JSON.stringify(r.requests))' "$HERE/websocket-gap-probe.json" | tee -a "$HERE/websocket-gap-probe.log"
# the same transition with a history that returns frame 1 (a modified copy of the probe), on v6 and on v5.2's adapter
node "$HERE/websocket_gap_probe_with_history.cjs" "$REPO" "$HERE/websocket-gap-probe-with-history.json" > "$HERE/websocket-gap-probe-with-history.log" 2>&1
echo "websocket_gap_probe_with_history.cjs on v6: exit $? (0 expected)" | tee -a "$HERE/websocket-gap-probe-with-history.log"
V52="$(mktemp -d)"; git archive aeris-v5.2 site/js | tar -x -C "$V52"          # v5.2's site scripts (the adapter and what it requires)
node "$HERE/websocket_gap_probe_with_history.cjs" "$V52" "$HERE/websocket-gap-probe-with-history.v5.2-adapter.json" > "$HERE/websocket-gap-probe-with-history.v5.2-adapter.log" 2>&1
echo "websocket_gap_probe_with_history.cjs on v5.2's adapter: exit $? (non-zero expected)" | tee -a "$HERE/websocket-gap-probe-with-history.v5.2-adapter.log"
rm -rf "$V52"

# V52-2: the review's provenance probe (live status, /capabilities, a recording) on artificial lineage cases
"$PY" "$PROBES/provenance_probe.py" "$REPO" "$HERE/provenance-api-probe.json" > "$HERE/provenance-probe.log" 2>&1
echo "provenance_probe.py exit $?" | tee -a "$HERE/provenance-probe.log"

# V52-3: the review's probe extracts v5.2's inline stop code from live_backend.test.js, which no longer exists (the
# suites use site/tests/lib/procs.js); it is run unchanged (it fails to find the code) and the same scenario is then
# applied to the shared helper by stop_timer_probe_v6.cjs.
node "$PROBES/stop_timer_probe.cjs" "$REPO" "$HERE/stop-timer-probe.json" > "$HERE/stop-timer-probe.log" 2>&1
echo "stop_timer_probe.cjs (unchanged) exit $? (expected non-zero: v5.2's inline stop code is gone)" | tee -a "$HERE/stop-timer-probe.log"
node "$HERE/stop_timer_probe_v6.cjs" "$REPO" "$HERE/stop-timer-probe-v6.json" > "$HERE/stop-timer-probe-v6.log" 2>&1
echo "stop_timer_probe_v6.cjs exit $?" | tee -a "$HERE/stop-timer-probe-v6.log"

# V52-4: the review's export probe in 'current' mode, with the supplied v5.1-generated chain, in a copy of its folder
mkdir -p "$HERE/export-probe"
cp "$PROBES/export_probe.py" "$PROBES/export-audit-v51-generated-chain.json" "$HERE/export-probe/"
(cd "$REPO/backend" && PYTHONPATH="$REPO/backend" "$PY" "$HERE/export-probe/export_probe.py" current) > "$HERE/export-probe.log" 2>&1
echo "export_probe.py current exit $?" | tee -a "$HERE/export-probe.log"
rm -f "$HERE"/export-probe/*.sqlite3-shm "$HERE"/export-probe/*.sqlite3-wal

# V52-1d negative control: live test L15 (the gated-socket reconnect race against a REAL backend) with v5.2's
# telemetry adapter must fail; with v6's adapter it must pass (L1 runs first: it creates the API client). A selection
# is a diagnosis, never the suite result.
NC="$HERE/negative-control-L15"
mkdir -p "$NC"
git show aeris-v5.2:site/js/adapters/hardware-telemetry.js > "$NC/hardware-telemetry.v5.2.js"
(cd site && AERIS_PYTHON="$PY" AERIS_LIVE_ONLY=L1,L15 AERIS_TELEMETRY_ADAPTER_UNDER_TEST="$NC/hardware-telemetry.v5.2.js" node tests/live_backend.test.js) > "$NC/L15-with-v5.2-adapter.log" 2>&1
echo "L15 with the v5.2 adapter: exit $? (non-zero expected)" | tee -a "$NC/L15-with-v5.2-adapter.log"
(cd site && AERIS_PYTHON="$PY" AERIS_LIVE_ONLY=L1,L15 node tests/live_backend.test.js) > "$NC/L15-with-v6-adapter.log" 2>&1
echo "L15 with the v6 adapter: exit $? (0 expected)" | tee -a "$NC/L15-with-v6-adapter.log"

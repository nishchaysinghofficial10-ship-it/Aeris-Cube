# v6.0 verification evidence

Everything here was produced by running code in the build environment (Linux x86-64, Ubuntu 24.04; Python 3.12.3 with
the backend's locked environment; Node 22.22.2; ESP-IDF v6.0.3). Synthetic devices and fixtures only: **no physical
board, sensor, driver, motor or cube was involved in any of it.**

| Folder | What it holds |
|---|---|
| [`reproduction-v5.2/`](reproduction-v5.2/README.md) | the four findings of the v5.2 review (V52-1 … V52-4) reproduced on the **unmodified v5.2** with the reviewer's probes, before any v6 change; the unmodified live suite three times |
| [`after-v6/`](after-v6/README.md) | the same probes re-run on v6.0, two marked probes of ours where the originals cannot answer on v6, and the V52-1d negative control (live test L15 fails with v5.2's telemetry adapter, passes with v6's) |
| [`firmware-build/`](firmware-build/README.md) | clean ESP-IDF v6.0.3 builds of the three ESP32-S3 variants (logs, sizes, SHA-256, the source hash they were built from); only the release image is distributed |
| `firmware-timing/` | `make -C firmware timing`: the control step's duration on the HOST CPU (balancing: mean ≈ 2.1 µs, p99 ≈ 13 µs, max 0.55 ms in one of 4000 steps on a shared 2-CPU virtual machine; period 2000 µs) — a statement about a desktop CPU and the synthetic device's models, **not** about the ESP32-S3 |
| `numerical/` | `studies/verify_campaign.py`: the 32 sampled rows of the v5 nominal campaign re-run from their stored configurations — 32 identical, 32 within the unchanged tolerances, 0 outcome changes (the research engine is unchanged in v6.0) |
| [`firmware-fault-tests/`](firmware-fault-tests/README.md) | the firmware's allocation and injected-fault tests and their negative control: removing each limit, the saturation count or a protection check makes the matching test fail (13 of 13) |
| `full-run-1-56dd89e/` | the first complete run of every suite (commit `56dd89e`: 26 suites, 1095 passed, 0 failed, 0 skipped, 0 not run). It is not the release's run: filling the acceptance matrix afterwards showed coverage gaps that were closed before the definitive run (`test-logs/`; SOFTWARE_COMPLETION_REPORT.md §12) |
| `definitive-run-91f78f3-console.log` | the console of the definitive run (`test-logs/` holds its logs, `summary.json` and `SUMMARY.md`) |
| `environment.json` | the machine, tools and every installed Python package of the backend environment, as recorded at the definitive run |
| `ci-local/` | `scripts/ci_local.py`: the `run:` steps of `.github/workflows/ci.yml` executed verbatim in fresh clones on this machine — not a hosted CI run |

The definitive test run of the release is `test-logs/` at the repository root (`SUMMARY.md` starts with the verdict;
`summary.json` is machine-readable). The release checks of the archive (fresh-directory validation, archive ↔ bundle
comparison) are in `evidence/v6.0-release/` and next to the delivered archive.

# The v5.2 review findings reproduced on the unmodified v5.2 (before any v6 change)

Checkout: a separate worktree of tag `aeris-v5.2` (`c28500044bab1ea73e82dff81f46fea8fccbf9f4`), verified against the
supplied ZIP and bundle (781 files equal). Linux x86-64, Python 3.12.3 (the v5.2 lock file), Node 22.22.2. The
reviewer's probes were run unchanged (only their command-line paths are ours):

| Finding | Probe | Result here |
|---|---|---|
| V52-1 | `websocket_gap_probe.cjs` | reproduced: delivered `[2]`, frame 1 never requested from the new stream, cursor 2, no gap event (`websocket-gap-probe.*`) |
| V52-2 | `provenance_probe.py` | reproduced: all four artificial lineage cases `live: true`, live `synthetic: false`, label DECLARED PHYSICAL, while the recording of the same frames is synthetic (`provenance-*`) |
| V52-3 | `stop_timer_probe.cjs` | reproduced: the old child's 5 s timer sends SIGKILL to the replacement (`stop-timer-probe.*`) |
| V52-4 | `export_probe.py current` | reproduced: the audit lists ORIGINAL and COPY_1, not COPY_2 (`export-probe-results.json`) |

The unmodified live suite (`live_backend.test.js`) passed 14/14 in three consecutive runs here
(`live-unmodified-run{1,2,3}.log`): the L14 race depends on timing and did not occur on this machine; the reviewer's
macOS runs show it (13/14 twice). The deterministic probe above reproduces the client defect independently of timing.

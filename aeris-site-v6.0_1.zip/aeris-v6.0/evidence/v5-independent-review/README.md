# The independent review of v5 (supplied; not produced by this project's tooling)

`supplied/` is the review pack **as it was supplied** for the v5.1 work (`AERIS-v5-review-pack.zip`, SHA-256
`b91411ef44ce4bf3a41ecdeb550266f11f2d76e072e0851ea5141a7ffd6f07b1`), copied unchanged: the report
(`AERIS-v5-review.md`), its machine-readable summary (`aeris-v5-review-evidence.json`) and the reviewer's probes,
logs and results (`aeris-v5-review-evidence/`). Absolute file links in the report point to the reviewer's Mac;
their repository-relative parts map onto this repository (for example `…/aeris-v5/backend/tests/test_reproduction.py`
→ `backend/tests/test_reproduction.py`).

These are the reviewer's results on macOS arm64 (Python 3.12.14) for the delivered v5 (archive SHA-256
`11312c94…9deb33`, git head `1023e09`): 682 passed, 2 failed, 1 skipped of 685 tests; the 11-step fresh-install
release validation passed; 32 sampled campaign rows reran within the documented tolerance with unchanged outcomes;
findings F1 (P1) and F2–F5 (P2). **Nothing in `supplied/` was executed by us**, and none of it describes v5.1.

What we did with it (our own executions, separately): `evidence/v5.1-verification/` — every finding reproduced on
the unmodified v5 first, then fixed and re-checked on v5.1 with the same failure conditions. Two of the reviewer's
probes are reused there with only their paths adapted (`probes/review_probes_adapted.py`,
`probes/telemetry_restart_probe_adapted.js`).

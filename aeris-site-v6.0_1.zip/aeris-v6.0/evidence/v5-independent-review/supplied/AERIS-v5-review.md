# AERIS v5 independent review

Reviewed 30 September 2026 on the user's Mac. Source review and executed checks; no project source changes. Original release files are unchanged.

**Verdict:** V5 is a substantial, working local research platform. The five specific v4 defects are addressed, the delivered backend installs and runs on this Mac, and the simulation studies are supported by reproducible evidence. Final software acceptance should wait for **three confirmed software/release fixes and two test corrections** below. This is a targeted completion pass. Physical hardware integration and model validation remain a separate stage.

## 1. Confirmed remaining findings

### F1 — P1: Mixed-source telemetry loses its synthetic provenance on NDJSON export/replay

Location: [telemetry/stream.py](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v5-review/aeris-v5/backend/aeris_backend/telemetry/stream.py:389>).

A recording may span a reconnect/source replacement. `recording_document` correctly marks the whole recording synthetic when **any** recorded hello is synthetic. However, `recording_to_ndjson` emits only the first hello, ignoring that aggregate flag. If the first source declared physical and a later source is synthetic, exporting/replaying the recording reports `synthetic: false`, `device.kind: physical`. Recording that replay again produces a valid non-synthetic recording. The synthetic lineage has been lost.

Independent reproduction, using only artificial software fixtures:

- Original mixed recording: `synthetic = true`, passes the recording validator.
- Exported hello: `synthetic = false`, kind `physical`.
- Replay: `declared_physical = true`, label “REPLAY of a recording declared from a physical device”.
- Re-recorded replay: `synthetic = false`, passes the recording validator.

No real hardware data was used. This does **not** automatically mark a model validated, but it removes the synthetic-data exclusion and mislabels the data, violating a core research requirement.

Fix: preserve conservative provenance across JSON, NDJSON, replay, re-recording, comparison and datasets. Either prevent/split incompatible source identities while recording, or export a protocol-valid synthetic replay identity whenever any segment is synthetic. Simply setting `synthetic: true` on a `physical` hello would itself violate the protocol. Add mixed-source regression tests, including source changes and reconnects.

Evidence: [review-probes.json](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/review-probes.json>), [reproduction script](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/review_probes.py>).

### F2 — P2: Live telemetry stops delivering new frames after a backend restart

Location: [hardware-telemetry.js](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v5-review/aeris-v5/site/js/adapters/hardware-telemetry.js:63>).

The live adapter keeps `lastN` across WebSocket reconnects. The backend's new `TelemetryHub` starts its counter at zero. The adapter therefore drops every new frame whose counter is below the previous backend's counter; polling requests also retain the old `after` value. Status updates do not reset it. The Telemetry UI only takes `status.latest` when it has no previous frame, so it can continue displaying the old pose.

A controlled transport reproduction using the unchanged production adapter delivered frame 1000, reconnected with a fresh backend counter, then offered frames 1 and 2. Only frame 1000 was delivered; the cursor remained 1000. The counter reset follows directly from the backend constructor. This targeted probe used controlled transport events; the general live-integration and restart smoke checks used real processes, but do not cover this combination.

Fix: include a backend/stream instance identifier in status, frames and polling responses, and scope deduplication cursors to it. Reset display/cursor state when the instance changes, while retaining deduplication within one instance. Test a real backend restart with the same browser tab, for both WebSocket and polling.

Evidence: [telemetry-restart-probe.json](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/telemetry-restart-probe.json>), [adapter reproduction](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/telemetry_restart_probe.js>).

### F3 — P2: The supplied browser CI command fails before running browser tests

Locations: [CI workflow](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v5-review/aeris-v5/.github/workflows/ci.yml:85>), [run_tests.py](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v5-review/aeris-v5/scripts/run_tests.py:44>).

CI passes `--browser-python backend/.venv/bin/python`. The runner tests this relative path from the repository root and returns it unchanged. It then launches browser scripts with the working directory set to `site/`, where that executable path does not exist. Reproducing this directory layout and the same arguments raises `FileNotFoundError: backend/.venv/bin/python` before any browser assertion or summary. The supplied completion report correctly says the workflow was not run on a CI service.

Fix: resolve interpreter paths before changing child working directories, including explicit arguments and environment variables; use absolute paths in CI. Report process-launch failures in the summary instead of aborting without one. Run the actual CI workflow before claiming that gate complete.

Evidence: `ci_relative_browser_path` in [review-probes.json](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/review-probes.json>).

### F4 — P2: Reproduction test wrongly demands bit equality across platforms

Location: [test_reproduction.py](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v5-review/aeris-v5/backend/tests/test_reproduction.py:30>).

`test_v4_records_reproduce_or_explain_why_not[corner_custom]` fails on this Mac because it requires `identical` against a Linux-generated fixture. The actual maximum sample difference is **2.053914e-15**, with the same outcome, 31 rows on each side and all 39 columns within tolerance. The application correctly returns `within_tolerance`.

Fix the test's platform expectations: enforce exact equality for a rerun generated in the same environment, and the documented numerical tolerance plus equal outcomes/schema for cross-platform fixtures. Keep meaningful numerical assertions. This finding is a test portability problem, not evidence that the dynamics are wrong.

Evidence: [exact comparison](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/corner-custom-reproduction.json>), [backend test log](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/full-tests/backend.log>).

### F5 — P2: COM-preview browser test observes an unfinished update

Location: [browser_v3.py](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v5-review/aeris-v5/site/tests/browser_v3.py:138>).

The test fills a 4 mm COM shift and waits a fixed 500 ms. It failed in the complete run and again when that suite ran alone: the mass label still read 0 mm and the arrow was absent. An instrumented repeat showed the input and draft were correctly 4 mm, then the label and 3-D arrow finished updating. At three seconds both correctly showed 4 mm; a subsequent 5 mm edit also worked.

This is a repeatable timing-sensitive test failure on this environment; a persistent wrong COM result was not reproduced. Replace the fixed delay with a bounded wait for the draft, label and viewer COM state to agree. Keep the assertion on the actual vector, rather than only the existence of an arrow.

Evidence: [instrumented observations](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/com-preview-probe.json>), [suite rerun log](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/browser-v3-recheck.log>), [probe source](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/com_preview_probe.py>).

## 2. Actual test results on this Mac

These are this review's results, separate from the supplied Linux report of 685 passes. Counts below are the original complete invocation; diagnostic reruns are not added to its total.

| Suite | Passed | Failed | Skipped |
|---|---:|---:|---:|
| Backend pytest | 341 | 1 | 1 |
| JavaScript, 10 suites | 172 | 0 | 0 |
| Live frontend/backend integration | 13 | 0 | 0 |
| Browser: original behavior suite | 50 | 0 | 0 |
| Browser: v3 | 46 | 1 | 0 |
| Browser: v4 | 24 | 0 | 0 |
| Browser: v5 | 36 | 0 | 0 |
| **Total** | **682** | **2** | **1** |

No suite was unrun. The one skipped test discovers orphan workers through Linux `/proc`, which macOS lacks. Other process-restart tests ran. The two failures are F4 and F5 above. The isolated v3 rerun also returned 46/47; the original counts remain unchanged. One third-party Starlette/httpx deprecation warning was emitted.

Environment: macOS 26.6.2 arm64, Python 3.12.14, Node 26.9.0, NumPy 2.5.3, SciPy 1.18.1, FastAPI 0.141.1, Pydantic 2.13.5, pytest 9.1.1, Playwright 1.63.0 with cached Chromium. Tests used an existing environment with **v5 explicitly on PYTHONPATH**; the recorded import path confirms v5 was exercised. Separately, the fresh release validation installed its own venv and matched all pinned dependencies.

Logs and exact suite durations: [test summary](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/full-tests/SUMMARY.md>). Full machine-readable evidence: [combined review evidence](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence.json>).

## 3. The five previous v4 defects

| Previous finding | V5 assessment |
|---|---|
| Angular ISE units and integration endpoint weights | Fixed in research metrics v2: trapezoidal weighting and squared unit conversion; constant-one-degree regression passes; old records retain their version. |
| Single jobs stuck in ANALYZING after restart | Fixed: atomic save/link state, legal finalization and visible inconsistent-state failure; recovery/process-restart tests pass on this Mac except the separate Linux-only orphan check. |
| Quaternion estimator freezing between IMU arrivals | Fixed: timestamped update state and controller-time prediction, age/stale metadata, covariance prediction/reset; timing regression suite passes. |
| Requested 60 Hz secretly executed as 62.5 Hz | Fixed by explicitly refusing non-divisor rates and saving the realized schedule. This is a rate restriction, not arbitrary-rate resampling. |
| Pending setup preview overwrites replay | Fixed with cancellation, generation and view-mode guards. Both v5 race checks and the previously failing v4 replay-label check pass. |

The `LocalSimulatorAdapter` file is unchanged from the v4 baseline. The frontend architecture is retained with additive research and telemetry controls. Generated schemas and `index.html` regenerate with no Git diff.

## 4. Release and research evidence checked independently

- ZIP SHA-256 matches: `11312c94ada527b6d14bdbd50bf6a9e66730e2a0c99fc050a849e328399deb33`.
- Archive contains 392 files. Git bundle verifies as complete history at `1023e09005dd5271a7cae7602222e5c9088902a1`.
- All **372 tracked files** in the bundle match the ZIP byte for byte. The ZIP adds 20 logs/validation files as documented.
- The two supplied release-validation JSON files are byte-identical copies, not independent runs.
- This review ran the supplied fresh-directory release validator on macOS: **11/11 steps passed** — archive, extraction, pinned installation, start, advanced experiment, reproduction, sweep restart, cancellation with finalized partial dataset, synthetic telemetry record/replay, backup/restore and stop.
- Campaign: **8 studies / 1,668 stored rows**; all 48 manifest file hashes match. I reran a fixed sample of **32 rows: 32 within tolerance, 0 outcome changes, 32 matching configuration hashes**. None were bit-identical across these platforms; largest reported relative difference was `3.652067526791042e-6`, below the campaign's `2e-5` threshold. The full campaign and its claimed three complete Linux reruns were not repeated here.
- Independent rerun of supplied solver verification: observed quaternion convergence orders **3.99 and 4.04** for the first two step halvings, followed by roundoff at the finest steps. Torque-free momentum relative drift was **2.56e-12** at 500 Hz and **1.11e-14** at 2000 Hz. These verify numerical behavior of the stated model, not agreement with a physical cube.

Evidence: [macOS release validation](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/release-validation-macos.json>), [campaign rerun](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/campaign-sample/verification.json>), [solver check](</Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/outputs/aeris-v5-review-evidence/solver-verification/solver_verification.md>).

## 5. What remains to finish

**Software acceptance:** fix F1–F3, correct F4–F5, add the missing provenance/restart regressions, execute the actual CI workflow, then regenerate the release and rerun its fresh-install validation. The main backend, estimators/controllers, sweeps, persistence, advanced configuration, recording and local UI integration are implemented; current evidence supports continuing local simulation work.

**Hardware stage later:** identify and map the actual firmware protocol/transport; verify cube/IMU/wheel axes, quaternion and torque conventions; calibrate timing and sensors; measure mass, COM, full inertia and motor parameters with provenance; implement and verify firmware motor control/watchdogs; collect real recordings with an independent reference and evaluate predeclared validation protocols. The current bridge is read-only and its emulator is synthetic.

**Model/operational limits remain:** ideal fixed edge/corner support, no contact/sliding/impact model; gravity-only attitude correction cannot observe absolute heading; finite wheel speed/torque and conserved momentum limit recoverability; controller tests are not global stability guarantees. Windows, other browsers, remote/multi-user hosting, long soak tests and physical validation were not reviewed. The Linux-specific worker-orphan check remains unverified on this Mac.

## 6. Run instructions

From a clean extracted repository or a clone of the supplied bundle, with Python 3.12+ installed:

```bash
bash scripts/install.sh --python python3.12
bash scripts/start.sh --emulator
# Open http://127.0.0.1:8750/#lab
bash scripts/stop.sh
```

Use the absolute path to a Python 3.12+ interpreter if `python3.12` is not on PATH. SIMULATION uses the backend; DEMO remains offline. The emulator is optional synthetic telemetry.

To run tests with an explicit interpreter, use an absolute path until F3 is fixed:

```bash
backend/.venv/bin/python -m pip install playwright
backend/.venv/bin/python -m playwright install chromium
python3 scripts/run_tests.py --browser-python "$PWD/backend/.venv/bin/python"
```

The full test suite currently produces the caveats above. This review changes no project source and does not constitute a fixed v5 release.

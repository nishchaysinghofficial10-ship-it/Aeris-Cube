"""Run the original browser sequence to its failing COM check, then observe and trigger events."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]/'work/v5-review/aeris-v5/site'
src=(ROOT/'tests/browser_v3.py').read_text()
src=src.replace('ROOT = pathlib.Path(__file__).resolve().parent.parent','ROOT = pathlib.Path('+repr(str(ROOT))+')')
needle='        check("COM shift updates the mass-asymmetry panel'
pos=src.index(needle); end=src.index('\n',pos)
extra='''
        state_js = "({input:document.querySelector('[data-path=\\\"comShift_m.1\\\"]').value, draft:AERIS_DEBUG.W.draft.comShift_m, validated:AERIS_DEBUG.W.draftVal.config.comShift_m, count:document.getElementById('asymCnt').textContent, scene:AERIS_DEBUG.W.viewer.snapshot().comShift, viewMode:AERIS_DEBUG.W.viewMode})"
        observations = [{"when":"original 500ms check", "state":await page.evaluate(state_js)}]
        await page.wait_for_timeout(2500)
        observations.append({"when":"3 seconds after fill", "state":await page.evaluate(state_js)})
        await page.locator('[data-path="comShift_m.1"]').dispatch_event('input')
        await page.wait_for_timeout(500)
        observations.append({"when":"after explicit input event", "state":await page.evaluate(state_js)})
        await page.locator('[data-path="comShift_m.1"]').fill('5')
        await page.wait_for_timeout(500)
        observations.append({"when":"after filling different value 5", "state":await page.evaluate(state_js)})
        print("COM_PROBE " + json.dumps(observations), flush=True)
        await br.close()
        return
'''
src=src[:end]+extra+src[end:]
exec(compile(src,str(ROOT/'tests/browser_v3.py'),'exec'),{'__file__':str(ROOT/'tests/browser_v3.py'),'__name__':'__main__'})

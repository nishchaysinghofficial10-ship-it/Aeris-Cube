# Solver verification (model integration, not hardware validation)

Engine aeris-research-engine 1.1.0

| Integration rate [Hz] | Δt [ms] | ‖q − q_ref‖ at t = 0.25 s | ‖ω − ω_ref‖ [rad/s] | observed order |
|---:|---:|---:|---:|---:|
| 500 | 2 | 4.802e-11 | 6.469e-10 | — |
| 1000 | 1 | 3.015e-12 | 4.061e-11 | 3.99 |
| 2000 | 0.5 | 1.834e-13 | 2.476e-12 | 4.04 |
| 4000 | 0.25 | 9.097e-15 | 1.209e-13 | 4.33 |
| 8000 | 0.125 | 1.754e-14 | 2.133e-13 | -0.95 |

RK4 is fourth order: halving the step divides the error by about 16 (order ≈ 4) until round-off (~1e-13) is reached.

| Conserved quantity | Rate [Hz] | Largest relative drift over 0.5 s |
|---|---:|---:|
| torque-free, g = 0: world angular momentum | 500 | 2.56e-12 |
| torque-free, g = 0: world angular momentum | 2000 | 1.11e-14 |

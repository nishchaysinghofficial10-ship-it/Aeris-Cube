"""Independent diagnostic fixtures for review; no hardware data or source changes."""
import json
import math
from pathlib import Path
from unittest.mock import patch

from aeris_backend.config.validate import validate_config
from aeris_backend.constants import DEG
from aeris_backend.metrics.research import research_metrics
from aeris_backend.sensors import Imu3D
from aeris_backend.simulation import simulate
from aeris_backend.simulation.engine import Engine


def main():
    base = simulate({'mode': 'edge', 'duration_s': 1}, keep_full=True)
    full = base['full']
    full['nSteps'] = 10
    full['e'] = [DEG] * 11
    ctx = {'mode': 'edge', 'dt': .1, 'wheel_names': ['x', 'y', 'z'],
           'recovery': base['config']['recovery'], 'window_s': 1, 'fellAt': None,
           'wmax_list': [w['wmax'] for w in base['wheels']], 'termination': base['termination']}
    actual = research_metrics(full, ctx)['attitude_error']
    recording = simulate({'mode': 'edge', 'duration_s': 1, 'record_hz': 60})
    times = recording['samples']['cols']['t']
    timing = {'ok': recording['ok'], 'requested_hz': 60,
              'reported_samples_hz': recording['samples']['rate_hz'],
              'reported_executed_hz': recording['executed']['rates']['record_hz'],
              'actual_interior_hz': 1 / (times[2] - times[1]),
              'sample_count': len(times), 'times_first_8': times[:8]}
    summary = {'constant_one_degree_for_one_second': {
        'expected': {'rms_deg': 1, 'iae_deg_s': 1, 'ise_deg2_s': 1}, 'actual': actual},
        'recording_rate': timing}
    Path(__file__).with_name('root-metrics-probes.json').write_text(json.dumps(summary, indent=2) + '\n')

    raw = {'mode': 'corner', 'duration_s': .5, 'controller': {'type': 'none'},
           'estimator': {'type': 'mekf'}, 'initial': {'tilt_deg': 0, 'rate_dps': 10},
           'sensor': {'rate_hz': 100, 'dropout': .5, 'gyro_noise_dps': 0,
                      'gyro_bias_dps': 0, 'gyro_bias_walk_dps': 0,
                      'accel_noise_mps2': 0, 'accel_dynamic': False}, 'seed': 17}
    v = validate_config(raw)
    assert v.ok, v.errors
    engine = Engine(v.config, v.mp)
    original = Imu3D.deliver
    delivery = {}
    rows = []
    def deliver(self, t):
        samples = original(self, t)
        if samples:
            delivery['last_measurement_t'] = samples[-1].t
        delivery['count'] = len(samples)
        return samples
    request = engine.controller.request
    def spy(t, est, ww, failed):
        rows.append({'t': t, 'delivered': delivery['count'],
                     'last_measurement_t': delivery.get('last_measurement_t'),
                     'estimate_t': est.t, 'estimate_age': est.age, 'estimate_valid': est.valid,
                     'q': list(est.q), 'rate_norm': math.sqrt(sum(x*x for x in est.w))})
        return request(t, est, ww, failed)
    engine.controller.request = spy
    with patch.object(Imu3D, 'deliver', deliver):
        engine.run()
    frozen = [{'previous': a, 'current': b} for a, b in zip(rows, rows[1:])
              if a['rate_norm'] > .1 and not b['delivered'] and a['q'] == b['q']]
    stale = {'config': raw, 'valid_config': v.ok,
             'frozen_estimate_intervals_with_nonzero_rate': len(frozen),
             'examples': frozen[:3]}
    Path(__file__).with_name('estimator-staleness-probe.json').write_text(json.dumps(stale, indent=2) + '\n')
    print(json.dumps({'metrics': summary, 'frozen_estimate_intervals': len(frozen)}, indent=2))


if __name__ == '__main__':
    main()

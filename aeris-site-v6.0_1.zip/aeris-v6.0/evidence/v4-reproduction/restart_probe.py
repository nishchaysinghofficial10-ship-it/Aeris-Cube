"""Review-only reproduction of resuming a single job in persisted analyzing state."""
import asyncio
import json
import tempfile
from pathlib import Path

from aeris_backend.jobs.manager import JobManager
from aeris_backend.storage.sqlite import SqliteRepository


async def main():
    with tempfile.TemporaryDirectory(prefix="aeris-review-restart-") as td:
        repo = SqliteRepository(str(Path(td) / "probe.sqlite3"))
        manager = JobManager(repo, workers=1, restart_policy="resume")
        job = manager.submit_simulation({"mode": "edge", "duration_s": 1})
        jid = job["id"]
        repo.update_job(jid, state="initializing")
        repo.update_job(jid, state="running")
        repo.update_job(jid, state="analyzing", progress={"done": 1})
        manager.recover()
        before = repo.get_job(jid)
        try:
            await manager._run_single(before, 0)
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
        else:
            error = None
        states = []
        for _ in range(5):
            await manager._execute(jid)
            after = repo.get_job(jid)
            states.append({k: after.get(k) for k in ("state", "seq", "error", "progress", "result_ref")})
        out = {"trigger": "Single job persisted at analyzing when backend restarts with default resume policy",
               "raw_error": error, "restarts": before["restarts"], "after_each_execute": states,
               "still_pending": [j["id"] for j in repo.list_jobs(states=["queued", "initializing", "running", "analyzing"])]}
        Path(__file__).with_name("restart-probe.json").write_text(json.dumps(out, indent=2) + "\n")
        print(json.dumps(out, indent=2))


if __name__ == "__main__":
    asyncio.run(main())

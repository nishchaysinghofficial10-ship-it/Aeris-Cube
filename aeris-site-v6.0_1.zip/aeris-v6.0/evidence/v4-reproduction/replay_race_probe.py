"""Reproduce review finding E (delayed setup preview overwrites the replay) in DEMO mode with
reduced motion (no autoplay). Prints JSON; exit code 0 when the replay is intact, 1 when overwritten."""
import asyncio, json, subprocess, sys, time
from pathlib import Path
from playwright.async_api import async_playwright

SITE = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()

async def main():
    web = subprocess.Popen([sys.executable, "-m", "http.server", "8797"], cwd=SITE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.0)
    out = {}
    try:
        async with async_playwright() as p:
            br = await p.chromium.launch()
            ctx = await br.new_context(viewport={"width": 1440, "height": 900}, reduced_motion="reduce")
            page = await ctx.new_page()
            await page.goto("http://127.0.0.1:8797/#lab")
            await page.wait_for_function("!!(window.Workspace && window.AERIS_DEBUG)", timeout=20000)
            await page.evaluate("Workspace.openConfig((()=>{const c=AERIS_TWIN.defaultConfig('edge'); c.duration_s=2; c.initial.tilt_deg=3; return c})())")
            await page.wait_for_timeout(300)
            await page.click("#btnRun")
            await page.wait_for_function("AERIS_DEBUG.W.run && !AERIS_DEBUG.W.busy", timeout=30000)
            for ms in (0, 500, 2000):
                if ms: await page.wait_for_timeout(ms if ms == 500 else 1500)
                snap = await page.evaluate("(()=>{const s=AERIS_DEBUG.snapshot(); return {runId:s.runId, viewMode:s.viewMode, viewerRunId:s.viewer&&s.viewer.runId, viewerIdx:s.viewer&&s.viewer.idx, viewerT:s.viewer&&s.viewer.t, tag:(document.getElementById('vwTag')||{}).innerText}})()")
                out["after_%dms" % (ms if ms != 2000 else 2000)] = snap
            await br.close()
    finally:
        web.terminate()
    final = out.get("after_2000ms", {})
    intact = final.get("viewMode") == "replay" and final.get("viewerRunId") == final.get("runId") and "PREVIEW" not in (final.get("tag") or "").upper()
    out["replay_intact"] = intact
    print(json.dumps(out, indent=2))
    return 0 if intact else 1

sys.exit(asyncio.run(main()))

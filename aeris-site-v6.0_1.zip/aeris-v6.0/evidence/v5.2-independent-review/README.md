# The independent review of v5.2 (supplied; not produced by this project's tooling)

`AERIS-v5.2-review-pack.zip` (SHA-256 `8ddb9aea0c40286fac92e9497e81266fa8ddd6ab9b063c2aa1c16e36574f499d`) is the
review pack as supplied with the v6.0 implementation request; `supplied/` is the same pack unpacked unchanged (its
own `aeris-v5.2-review-evidence/MANIFEST.sha256` verifies all 61 files). It contains the report
(`AERIS-v5.2-review.md`), the reviewer's logs, results and probes.

These are the reviewer's results on macOS 26.6.2 arm64 for the delivered v5.2 (tag `aeris-v5.2` =
`c28500044bab1ea73e82dff81f46fea8fccbf9f4`): backend 451 passed, 1 failed (a sandbox-blocked `ps`), 1 skipped (the
Linux `/proc` test); JavaScript 181/181; live 13/14 (L14, finding V52-1); the six browser suites could not launch
Chromium in their sandbox; fresh-install validation 16/17 (browser-cancel blocked); 32/32 sampled campaign rows within
tolerance; findings V52-1 to V52-4. **Nothing in `supplied/` was executed by us** unless stated in
`evidence/v6.0-verification/` (where the reviewer's probes were run, unchanged, against an unmodified v5.2 checkout).

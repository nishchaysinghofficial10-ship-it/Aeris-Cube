"""Independent synthetic checks. Writes only review-owned evidence artifacts."""
import copy, json, math, sys
from pathlib import Path
from aeris_backend.telemetry.stream import TelemetryHub, recording_to_ndjson
from aeris_backend.hardware.ingest import validate_recording
OUT = Path(__file__).resolve().parent

def replay(txt, name):
    hub=TelemetryHub()
    hub.on_connect({'kind':'file','address':name+'.ndjson'},0.)
    accepted=[]
    for i,line in enumerate(txt.splitlines()):
        r=hub.feed_line(line, i*.01)
        accepted.append(r)
        if r == 'hello' and hub.recording is None:
            hub.start_recording('SYNTHETIC independent review '+name,0.)
    doc=hub.stop_recording(2.)
    assert validate_recording(doc)['ok']
    return doc,accepted

def base():
    return {'schema':'aeris-hardware-run/1','synthetic':True,'device':{'id':'SYNTHETIC-review','firmware':'review-only'},'recording':{'started':'2026-10-09T00:00:00Z','notes':'SYNTHETIC independent export review'},'mode':'edge','samples':{'cols':{'t':[0,100,200],'theta':[10,11,12]},'units':{'t':'ms','theta':'deg'}}}

if sys.argv[1]=='old':
    docs={'ORIGINAL':base()}
    for old,new in [('ORIGINAL','COPY_1'),('COPY_1','COPY_2')]:
        docs[new],accepts=replay(recording_to_ndjson(docs[old],old),new)
        assert all(r in ('hello','frame','bye') for r in accepts)
    (OUT/'export-audit-v51-generated-chain.json').write_text(json.dumps(docs,indent=2))
    print(json.dumps({k:{'t':v['samples']['cols']['t'],'theta':v['samples']['cols']['theta'],'units':v['samples']['units']} for k,v in docs.items()},indent=2))
else:
    from aeris_backend.telemetry.export import ExportError
    from aeris_backend.tools.dbtool import export_audit
    from aeris_backend.storage.sqlite import SqliteRepository
    d=base()
    for prefix,unit,values in [('w_','deg/s',[180.,90.,-180.]),('gyro_','°/s',[90.,180.,-90.]),('omega_','rad/s',[2*math.pi,4*math.pi,-2*math.pi]),('torque_cmd_','mNm',[1.,2.,-3.]),('torque_meas_','mN·m',[4.,5.,6.]),('accel_','g',[1.,0.,-1.])]:
        for ax,v in zip('xyz',values):
            d['samples']['cols'][prefix+ax]=[v]*3
            d['samples']['units'][prefix+ax]=unit
    before=copy.deepcopy(d)
    txt=recording_to_ndjson(d,'ALL_FAMILIES')
    lines=[json.loads(x) for x in txt.splitlines()]
    f=[x for x in lines if x['type']=='frame'][1]
    expected={'t':.1,'theta':11*math.pi/180.,'w':[math.pi,math.pi/2.,-math.pi],'wheel_rpm':[60.,120.,-60.],'torque_cmd':[.001,.002,-.003],'torque_meas':[.004,.005,.006],'imu':{'gyro':[math.pi/2.,math.pi,-math.pi/2.],'accel':[9.80665,0.,-9.80665]}}
    def eq(g,w):
        if isinstance(w,dict): return all(eq(g[k],v) for k,v in w.items())
        if isinstance(w,list): return len(g)==len(w) and all(eq(a,b) for a,b in zip(g,w))
        return math.isclose(g,w,rel_tol=1e-12,abs_tol=1e-14)
    assert eq(f,expected),(f,expected)
    rd,accepted=replay(txt,'fixed')
    assert all(r in ('hello','frame','bye') for r in accepted)
    assert d==before
    refuse=copy.deepcopy(d);del refuse['samples']['cols']['w_z'];del refuse['samples']['units']['w_z']
    try: recording_to_ndjson(refuse,'PARTIAL')
    except ExportError as e: partial={'type':'ExportError','details':e.details}
    else: raise AssertionError('partial vector silently accepted')
    omit=recording_to_ndjson(refuse,'PARTIAL',omit_unmapped=True)
    omithello=json.loads(omit.splitlines()[0]); assert 'omitted' in omithello['lineage']['export']
    docs=json.loads((OUT/'export-audit-v51-generated-chain.json').read_text())
    db=OUT/'export-audit-probe.sqlite3'
    assert not db.exists(), 'review file already exists; choose new name'
    repo=SqliteRepository(str(db),exclusive=False)
    try:
        for rid,doc in docs.items(): repo.put_new('recordings',rid,{'document':doc},name=rid)
    finally:repo.close()
    beforedb=db.read_bytes();audit=export_audit(str(db));assert db.read_bytes()==beforedb
    result={'unit_families':{'passed':True,'sample':f,'original_unchanged':True,'replay_accepted':accepted,'recorded_units':rd['samples']['units'],'synthetic_preserved':rd['synthetic']},'partial_vector_refusal':partial,'explicit_omission':omithello['lineage']['export']['omitted'],'audit_two_v51_generations':audit,'audit_missing_corrupt_descendant':'COPY_2' not in [r['id'] for r in audit['copies_recorded_from_such_an_export']]}
    (OUT/'export-probe-results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

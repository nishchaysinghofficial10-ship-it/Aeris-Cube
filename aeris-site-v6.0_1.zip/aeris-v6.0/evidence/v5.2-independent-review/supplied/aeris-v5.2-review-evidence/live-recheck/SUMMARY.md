# Test run — INCOMPLETE — 1 suite(s) not run (live). No suite ran. Not a full validation.

2026-10-09T09:03:33+00:00 · macOS-26.6.2-arm64-arm-64bit (`darwin`) · backend Python `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python` · Node v26.9.0

- backend python: `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python` (--backend-python, given as `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python`)
- node: `/Users/nishchaysingh/.local/bin/node` (default: node on PATH)
- platform-exclusion policy: `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v52-review/aeris-v5.2/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| live | not run — NOT RUN: the research backend could not be started (backend exited (3): ERROR:    [Errno 1] error while attempting to bind on address ('127.0.0.1', 18651): operation not permitted | 0 | 0 | 0 | 14 | 1.0 | live.log |
| backend | not selected | — | — | — | — | — | — |
| js:assistant | not selected | — | — | — | — | — | — |
| js:engine | not selected | — | — | — | — | — | — |
| js:numerics | not selected | — | — | — | — | — | — |
| js:platform | not selected | — | — | — | — | — | — |
| js:runs | not selected | — | — | — | — | — | — |
| js:schema | not selected | — | — | — | — | — | — |
| js:service | not selected | — | — | — | — | — | — |
| js:ui | not selected | — | — | — | — | — | — |
| js:v4 | not selected | — | — | — | — | — | — |
| js:v5 | not selected | — | — | — | — | — | — |
| js:v51 | not selected | — | — | — | — | — | — |
| browser:browser_check | not selected | — | — | — | — | — | — |
| browser:browser_v3 | not selected | — | — | — | — | — | — |
| browser:browser_v4 | not selected | — | — | — | — | — | — |
| browser:browser_v5 | not selected | — | — | — | — | — | — |
| browser:browser_v51 | not selected | — | — | — | — | — | — |
| browser:browser_v52 | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 0 passed, 0 failed, 0 skipped, 14 not run (0 executed).
**Suites:** 0 passed, 0 passed with exclusions, 0 incomplete, 0 failed, 1 not run, 0 skipped, 18 not selected.
**Complete execution:** no · **all applicable tests passed:** no · **all tests executed:** no.
**Full validation:** no (exit code 2: incomplete: a suite was not run or skipped, or test cases were skipped / not run outside the platform-exclusion policy).

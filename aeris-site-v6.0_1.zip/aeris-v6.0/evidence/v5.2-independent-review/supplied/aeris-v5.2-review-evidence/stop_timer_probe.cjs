/* Deterministic reproduction of the original live-test cleanup timer. No real process is killed. */
const fs=require('fs'),vm=require('vm'),path=require('path');
const source=fs.readFileSync(path.join(path.resolve(process.argv[2]),'site/tests/live_backend.test.js'),'utf8');
const code=source.match(/function exited\(\)[^\n]+\nfunction stopBackend\(\)[^\n]+/)[0];
const kills=[],timers=[];
function child(name){return {exitCode:null,signalCode:null,once(_,f){this.onexit=f;},kill(signal){kills.push({name,signal});if(signal==='SIGTERM'){this.signalCode=signal;this.onexit();}}};}
const c={proc:child('old backend'),setTimeout:fn=>timers.push(fn)};vm.createContext(c);vm.runInContext(code,c);
(async()=>{await c.stopBackend();c.proc=child('replacement backend');timers[0]();const result={kills,replacement_killed:kills.some(k=>k.name==='replacement backend')};console.log(JSON.stringify(result,null,2));if(process.argv[3])fs.writeFileSync(process.argv[3],JSON.stringify(result,null,2));})();

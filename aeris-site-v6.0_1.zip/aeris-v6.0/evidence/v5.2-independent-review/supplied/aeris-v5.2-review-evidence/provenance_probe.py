"""Independent synthetic fixtures; no physical hardware. Usage: python probe.py REPO OUTPUT."""
import json
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]).resolve() / 'backend'))
from aeris_backend.telemetry.protocol import hello_message, validate_hello
from aeris_backend.api.app import create_app
from fastapi.testclient import TestClient

cases = {
    'control': None,
    'summary_synthetic': {'trust': 'declared-physical', 'original_synthetic': False, 'ancestry_trust': 'synthetic'},
    'reference_synthetic': {'trust': 'declared-physical', 'original_synthetic': False,
                            'ancestry': [{'trust': 'synthetic', 'original_synthetic': True, 'derived_from': 'synthetic-fixture'}]},
    'original_synthetic': {'original_synthetic': True},
    'unknown': {'trust': 'unknown'},
}
results = {}
with tempfile.TemporaryDirectory(prefix='aeris-v52-provenance-review-') as tmp:
    app = create_app({'db': str(Path(tmp)/'test.sqlite3'), 'workers': 1})
    with TestClient(app) as api:
        bridge = app.state.bridge
        for name, lin in cases.items():
            now = bridge.clock()
            hub = bridge.hub
            hub.on_connect({'kind':'tcp', 'address':'ARTIFICIAL REVIEW FIXTURE'}, now)
            hello = hello_message('ARTIFICIAL-FIXTURE','physical','test-only',False,'corner',100)
            if lin is not None:
                hello['lineage'] = lin
            accepted = hub.feed_message(hello, now)
            start = api.post('/api/v1/telemetry/recordings/start', json={'name':'ARTIFICIAL FIXTURE - NO HARDWARE'})
            assert start.status_code == 201, start.text
            for i in range(3):
                assert hub.feed_message({'type':'frame','t':i*.01,'seq':i,'q':[1,0,0,0]}, bridge.clock()) == 'frame'
            status = api.get('/api/v1/telemetry/status').json()
            capabilities = api.get('/api/v1/capabilities').json()
            stop = api.post('/api/v1/telemetry/recordings/stop')
            assert stop.status_code == 201, stop.text
            recorded = stop.json()
            results[name] = {'hello_validation':validate_hello(hello), 'hello_accepted':accepted,
                'status_live':status['live'], 'status_provenance':status['provenance'],
                'hardware_capabilities':capabilities.get('hardware'),
                'recorded_synthetic':recorded['synthetic'], 'recorded_provenance':recorded['provenance']}
            hub.on_disconnect('fixture complete', bridge.clock())
Path(sys.argv[2]).write_text(json.dumps(results, indent=2))
print(json.dumps({k:{'live':v['status_live'],'live_synthetic':v['status_provenance']['synthetic'],
    'recorded_synthetic':v['recorded_synthetic']} for k,v in results.items()},indent=2))

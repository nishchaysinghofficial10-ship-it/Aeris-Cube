# Test run — FAILED — 8 suite(s) failed: backend, live, browser:browser_check, browser:browser_v3, browser:browser_v4, browser:browser_v5, browser:browser_v51, browser:browser_v52; also 1 test case(s) skipped. Not a full validation.

2026-10-09T09:01:57+00:00 · macOS-26.6.2-arm64-arm-64bit (`darwin`) · backend Python `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python` · Node v26.9.0

- backend python: `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python` (--backend-python, given as `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python`)
- browser python: `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python` (--browser-python, given as `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python`)
- node: `/Users/nishchaysingh/.local/bin/node` (default: node on PATH)
- platform-exclusion policy: `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v52-review/aeris-v5.2/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| backend | failed | 451 | 1 | 1 | 0 | 152.5 | backend.log |
| js:assistant | passed | 9 | 0 | 0 | 0 | 0.4 | js-assistant.log |
| js:engine | passed | 9 | 0 | 0 | 0 | 0.2 | js-engine.log |
| js:numerics | passed | 38 | 0 | 0 | 0 | 0.2 | js-numerics.log |
| js:platform | passed | 16 | 0 | 0 | 0 | 0.1 | js-platform.log |
| js:runs | passed | 14 | 0 | 0 | 0 | 0.1 | js-runs.log |
| js:schema | passed | 7 | 0 | 0 | 0 | 0.1 | js-schema.log |
| js:service | passed | 19 | 0 | 0 | 0 | 0.2 | js-service.log |
| js:ui | passed | 16 | 0 | 0 | 0 | 0.1 | js-ui.log |
| js:v4 | passed | 27 | 0 | 0 | 0 | 0.3 | js-v4.log |
| js:v5 | passed | 17 | 0 | 0 | 0 | 0.5 | js-v5.log |
| js:v51 | passed | 9 | 0 | 0 | 0 | 0.2 | js-v51.log |
| live | failed | 13 | 1 | 0 | 0 | 23.5 | live.log |
| browser:browser_check | failed — exit code 1; no counts reported | 0 | 0 | 0 | 0 | 1.1 | browser-browser_check.log |
| browser:browser_v3 | failed — exit code 1; no counts reported | 0 | 0 | 0 | 0 | 0.7 | browser-browser_v3.log |
| browser:browser_v4 | failed — exit code 1; no counts reported | 0 | 0 | 0 | 0 | 1.7 | browser-browser_v4.log |
| browser:browser_v5 | failed — exit code 1; no counts reported | 0 | 0 | 0 | 0 | 1.7 | browser-browser_v5.log |
| browser:browser_v51 | failed — exit code 1; no counts reported | 0 | 0 | 0 | 0 | 2.1 | browser-browser_v51.log |
| browser:browser_v52 | failed — exit code 1; no counts reported | 0 | 0 | 0 | 0 | 1.1 | browser-browser_v52.log |

**Skipped test cases (not executed; never counted as passed):**

| Suite | Test | Reason | Platform-exclusion policy |
|---|---|---|---|
| backend | `tests.test_process_restart::test_worker_processes_exit_when_the_backend_process_is_killed` | finds the worker processes through /proc (Linux) | not covered: excluded only when its portable counterpart tests.test_process_restart::test_worker_processes_exit_when_the_backend_process_is_killed_portable_ps passes in the same run; it did not |

**Failed test cases:**

- backend: `tests.test_process_restart::test_worker_processes_exit_when_the_backend_process_is_killed_portable_ps` — PermissionError: [Errno 1] Operation not permitted: 'ps'

**Totals (tests in the suites that ran):** 645 passed, 2 failed, 1 skipped, 0 not run (647 executed).
**Suites:** 11 passed, 0 passed with exclusions, 0 incomplete, 8 failed, 0 not run, 0 skipped, 0 not selected.
**Complete execution:** no · **all applicable tests passed:** no · **all tests executed:** no.
**Full validation:** no (exit code 1: a suite or test case failed, timed out or reported no counts).

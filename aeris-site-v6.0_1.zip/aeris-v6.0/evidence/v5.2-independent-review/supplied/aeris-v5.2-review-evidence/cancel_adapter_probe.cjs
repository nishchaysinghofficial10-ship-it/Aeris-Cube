// Supplemental adapter checks; no DOM/browser coverage and no product edits.
const path = require('path'), fs = require('fs'), assert = require('assert');
const root = path.resolve(process.argv[2]);
global.window = { AERIS_CONFIG: { researchApi: { baseUrl: null } } };
const J = p => require(path.join(root, 'site/js', p));
const TWIN = J('core.js'), JOBS = J('platform/jobs.js'), LOCAL = J('adapters/local-simulator.js');
const def = {base:TWIN.defaultConfig('edge'),mode:'grid',controllers:['lqr'],variables:[{key:'tilt_deg',min:0,max:10,steps:30}],duration_s:2};
const results = [];
async function scenario(name, when) {
  const job = LOCAL.submitSweep(def, {budgetMs:1});
  let requested = false, cancellableAtRequest;
  await new Promise((resolve,reject) => {
    const timer=setTimeout(()=>reject(new Error(name+' timed out')),10000);
    function update(j) {
      if (!requested && when(j)) {
        requested=true; cancellableAtRequest=LOCAL.cancellable(j); LOCAL.cancelJob(j);
      }
      if (JOBS.isTerminal(j)) { clearTimeout(timer); resolve(); }
    }
    JOBS.subscribe(job, update); update(job);
  });
  return {name,requested,cancellableAtRequest,state:job.state,partial:job.result.partial,rows:job.result.rows.length,total:job.progress.total,message:job.message};
}
(async()=>{
  results.push(await scenario('queued',j=>j.state==='queued'));
  results.push(await scenario('running',j=>j.state==='running'&&j.progress.done>0&&j.progress.done<j.progress.total));
  results.push(await scenario('last row',j=>j.state==='running'&&j.progress.done===j.progress.total));
  results.push(await scenario('analyzing',j=>j.state==='analyzing'));
  results.push(await scenario('next sweep after cancellation',()=>false));
  assert.equal(results[0].state,'cancelled'); assert.equal(results[0].rows,0); assert(results[0].partial);
  assert.equal(results[1].state,'cancelled'); assert(results[1].rows>0&&results[1].rows<30&&results[1].partial);
  for(const r of results.slice(2)) {assert.equal(r.state,'complete');assert.equal(r.rows,30);assert.equal(r.partial,false);}
  assert.equal(results[3].cancellableAtRequest,false);
  fs.writeFileSync(process.argv[3],JSON.stringify({scope:'Five supplemental Node adapter scenarios; does not verify button behavior or replace browser tests.',passed:true,results},null,2));
  console.log('5 / 5 supplemental adapter scenarios passed (no browser/DOM).');
})().catch(e=>{console.error(e);process.exitCode=1;});

# Test run — FAILED — 1 suite(s) failed: live. Not a full validation.

2026-10-09T09:06:10+00:00 · macOS-26.6.2-arm64-arm-64bit (`darwin`) · backend Python `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python` · Node v26.9.0

- backend python: `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python` (--backend-python, given as `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v4-venv/bin/python`)
- node: `/Users/nishchaysingh/.local/bin/node` (default: node on PATH)
- platform-exclusion policy: `/Users/nishchaysingh/Documents/Codex/2026-09-26/referenced-chatgpt-conversation-this-is-an/work/v52-review/aeris-v5.2/scripts/platform_exclusions.json` (1 entry; sha256 b74cd3c2be24)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| live | failed | 13 | 1 | 0 | 0 | 23.3 | live.log |
| backend | not selected | — | — | — | — | — | — |
| js:assistant | not selected | — | — | — | — | — | — |
| js:engine | not selected | — | — | — | — | — | — |
| js:numerics | not selected | — | — | — | — | — | — |
| js:platform | not selected | — | — | — | — | — | — |
| js:runs | not selected | — | — | — | — | — | — |
| js:schema | not selected | — | — | — | — | — | — |
| js:service | not selected | — | — | — | — | — | — |
| js:ui | not selected | — | — | — | — | — | — |
| js:v4 | not selected | — | — | — | — | — | — |
| js:v5 | not selected | — | — | — | — | — | — |
| js:v51 | not selected | — | — | — | — | — | — |
| browser:browser_check | not selected | — | — | — | — | — | — |
| browser:browser_v3 | not selected | — | — | — | — | — | — |
| browser:browser_v4 | not selected | — | — | — | — | — | — |
| browser:browser_v5 | not selected | — | — | — | — | — | — |
| browser:browser_v51 | not selected | — | — | — | — | — | — |
| browser:browser_v52 | not selected | — | — | — | — | — | — |

**Totals (tests in the suites that ran):** 13 passed, 1 failed, 0 skipped, 0 not run (14 executed).
**Suites:** 0 passed, 0 passed with exclusions, 0 incomplete, 1 failed, 0 not run, 0 skipped, 18 not selected.
**Complete execution:** yes · **all applicable tests passed:** no · **all tests executed:** no.
**Full validation:** no (exit code 1: a suite or test case failed, timed out or reported no counts).

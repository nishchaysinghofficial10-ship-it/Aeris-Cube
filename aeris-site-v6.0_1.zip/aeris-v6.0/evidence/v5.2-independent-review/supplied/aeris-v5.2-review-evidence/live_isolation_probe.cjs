/* Investigation only: run original L1 and L14 with the stop timer scoped to the old child.
   Product source is unchanged. This is NOT a replacement full-suite result. */
const fs=require('fs'), path=require('path'), Module=require('module');
const root=path.resolve(process.argv[2]);
const filename=path.join(root,'site/tests/live_backend.test.js');
let source=fs.readFileSync(filename,'utf8');
const old='function stopBackend() { return new Promise(function (res) { if (exited()) return res(); proc.once("exit", function () { res(); }); proc.kill("SIGTERM"); setTimeout(function () { if (!exited()) proc.kill("SIGKILL"); }, 5000); }); }';
const fix='function stopBackend() { return new Promise(function (res) { if (exited()) return res(); const target=proc; const timer=setTimeout(function () { if (target.exitCode === null && target.signalCode === null) target.kill("SIGKILL"); }, 5000); target.once("exit", function () { clearTimeout(timer); res(); }); target.kill("SIGTERM"); }); }';
if(!source.includes(old))throw Error('Expected stop helper not found');
source=source.replace(old,fix).replace('queue.push({ n: n, f: f });','if (/^L1 Probe|^L14 /.test(n)) queue.push({ n: n, f: f });');
console.log('DIAGNOSTIC: only L1 and L14; shutdown timer fixed in memory; all product code unchanged.');
const m=new Module(filename,module);m.filename=filename;m.paths=Module._nodeModulePaths(path.dirname(filename));m._compile(source,filename);

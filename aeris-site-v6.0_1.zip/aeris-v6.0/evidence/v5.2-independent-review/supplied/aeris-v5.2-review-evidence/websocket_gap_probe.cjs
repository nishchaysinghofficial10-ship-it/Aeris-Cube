// Deterministic replay of poll -> WebSocket transition using the unmodified adapter.
const path=require('path'),fs=require('fs'),assert=require('assert');
const root=path.resolve(process.argv[2]);
const A=require(path.join(root,'site/js/adapters/hardware-telemetry.js'));
const sockets=[],timers=[],requests=[],events=[];
class Socket { constructor(url){this.url=url;sockets.push(this);} close(){} }
let stream='old',lastN=1;
A.bind({configured:()=>true,available:()=>({ok:true}),capabilities:()=>({reported:true,telemetry:{available:true}}),wsUrl:'ws://fixture',
 request:(method,url)=>{requests.push(url);return Promise.resolve(url.startsWith('/telemetry/frames')?{stream_id:stream,last_n:lastN,frames:[],missed:0}:{stream_id:stream,last_n:lastN});}});
function message(sock,data){sock.onmessage({data:JSON.stringify(data)});}
const client=A.live(e=>events.push(e),{WebSocket:Socket,stream:'old',after:1,wait:(ms,fn)=>{timers.push(fn);return null;}});
(async()=>{
  sockets[0].onopen();message(sockets[0],{type:'status',status:{stream_id:'old',last_n:1}});
  sockets[0].onclose({code:1006}); // fallback polls old stream; its buffer is up to date
  await new Promise(r=>setImmediate(r));
  // Backend restarts after that poll. Frame 1 is already in the new backend's recent buffer before subscription.
  stream='new';lastN=1;
  assert.equal(timers.length,1);timers.shift()();
  sockets[1].onopen();message(sockets[1],{type:'status',status:{stream_id:'new',last_n:1}});
  lastN=2;message(sockets[1],{type:'frames',stream:'new',frames:[{n:2,t:0.2}],dropped:0});
  await new Promise(r=>setImmediate(r));
  const frames=events.filter(e=>e.type==='frames').flatMap(e=>e.frames.map(f=>f.n));
  const result={fixture:'Artificial deterministic transport; frame 1 remains available through /telemetry/frames in the new stream.',requests,events,delivered:frames,cursor:client.lastN(),missing_frame_1:!frames.includes(1),gap_events:events.filter(e=>e.type==='gap').length};
  client.close();fs.writeFileSync(process.argv[3],JSON.stringify(result,null,2));
  assert.deepEqual(frames,[2]);assert.equal(result.gap_events,0);
  console.log('Reproduced: new stream delivered [2], frame 1 never fetched, cursor advanced to 2, no gap event.');
})().catch(e=>{client.close();console.error(e);process.exitCode=1;});

# AERIS v5.2 independent release review

Reviewed 9 October 2026. **Verdict: substantial progress, with four actionable issues remaining before an unqualified software-complete claim.** The previous unit-conversion, bounded-lineage and test-accounting fixes are supported by independent results. The cancellation changes also pass five supplemental adapter scenarios, although browser verification was blocked here. This review found a telemetry reconnect gap, inconsistent live provenance, a restart-test cleanup bug, and an incomplete legacy-export audit.

The ZIP, Git bundle, extracted directory, migration notes, completion report and supplied test logs were inspected. Product files were not edited. Tests used temporary data and artificial telemetry; no physical cube or hardware measurement was involved. This is a release/correction review, not a new certification of every scientific model or every original project requirement.

**Package integrity — passed.**

- Tag `aeris-v5.2` resolves to commit `c28500044bab1ea73e82dff81f46fea8fccbf9f4`; the bundle verifies and contains 46 commits.
- All **781 ZIP files match all 781 tracked files byte for byte**. The supplied extracted directory also matches, apart from four `.DS_Store` files.
- ZIP SHA-256: `5301331fb5cede605a4c6a202fc0a0c8f302d327b68883530ce860db2931e370`.
- Bundle SHA-256: `7a86470c9633e9c2c73efb382ebd25055c92c27a66e0b27507777b786834f444`.
- The external completion report and migration document match the archived documents. All 22 archived definitive-run logs match their counterparts in the external test-log folder.
- Changes after supplied full-test commit `020d8bf` are documentation/evidence/logs. The research engine, physics/controllers/estimators, frozen `site/index.html`, schemas and historical studies are unchanged from v5.1. Cancellation behavior was deliberately corrected in the existing local adapter/service/UI.
- Every archived file in the review extraction was still unchanged after testing.

**What was independently executed.**

Environment: macOS 26.6.2 arm64; Python 3.12.14; NumPy 2.5.3; SciPy 1.18.1; FastAPI 0.141.1; pytest 9.1.1; Node 26.9.0. Existing Python dependencies were used for the full suite with the v5.2 source explicitly selected. Separately, the release validator extracted the supplied ZIP, created a fresh environment, installed the locked dependencies successfully, and ran its checks.

| Check | Independent result | Interpretation |
|---|---:|---|
| Backend suite | **451 passed, 1 failed, 1 skipped / 453** | Failure: sandbox denied the portable orphan-worker test's `ps` invocation. Skip: Linux `/proc` test on macOS. Worker-cleanup verification remains incomplete here. |
| JavaScript, 11 suites | **181 / 181 passed** | All selected JS cases passed. |
| Live integration | **13 / 14 passed** | L14 missed the new stream's first frame. The permitted isolated rerun also produced 13/14. See V52-1 and V52-3. |
| Browser, 6 suites | **No browser cases executed** | Chromium could not launch: macOS sandbox denied Mach bootstrap registration. The supplied suite total is 216 checks; these were not independently verified here. |
| Fresh-install release validator | **16 / 17 steps passed** | `browser-cancel` was blocked before its assertions by the same Chromium launch restriction. |
| Numerical campaign sample | **32 / 32 within existing tolerance** | 0 outcome changes; all configuration hashes match; 0 bit-identical on this Mac. Maximum relative difference `3.652067526791042e-6`, below the existing `2e-5` relative tolerance. |
| Supplemental cancellation adapter probe | **5 / 5 scenarios passed** | Queued, running, last row, analyzing, and a following sweep. No DOM/button coverage. |

The full runner reported **645 passed, 2 failed, 1 skipped**, with **647 executed cases**, and correctly set `full_validation: false`. Its numerical totals do not include the 216 browser checks whose suites failed before reporting case counts. Do not describe this as 864 tests independently passing, or add isolated reruns and probes to that total.

The supplied Linux logs report **864 passed, 0 failed, 0 skipped** and the external exact-archive validator reports **17/17**. Those are retained as supplied evidence, distinct from this review's reproduction. The earlier supplied failed full run is also preserved. A local execution of CI workflow commands is documented; no hosted CI run was supplied.

The first isolated live retry after a turn boundary could not bind its server because its network grant had expired: **0 executed, 14 not run**. After permission was restored, the next isolated retry reproduced the real L14 failure. That environment-only attempt is retained separately.

**Previous findings G1–G4.**

| Previous finding | Assessment |
|---|---|
| G1: NDJSON exports changed imported units | Core fix verified. All 38 export-unit tests passed. The original independent probe and an additional all-family probe confirmed time, angles, rates, wheel speeds, torque and acceleration conversions; original documents remained unchanged. Incomplete vectors are refused, or omitted explicitly with an omission record. V52-4 concerns the separate migration audit. |
| G2: recursive lineage eventually broke replay | Normal export/replay chains verified. All 10 bounded-lineage tests passed; the fresh release validator completed 20 generations within the lineage budget, retaining synthetic classification. The old independent repeated-replay probe also passes. V52-2 concerns a separate live-status classification path. |
| G3: skipped tests counted as full validation | Fix verified. All 29 runner tests passed. This review's actual skipped/blocked checks were not certified as full validation. These 29 tests are included in the backend count above. |
| G4: cancellation relied on a 300 ms timing race | The test now uses progress/state. Source review and five direct adapter scenarios support the corrections. The 45 browser_v52 checks are supported by supplied logs, but actual button behavior and CPU-throttled browser runs remain unverified in this session. |

**V52-1 · P2 · WebSocket reconnection can silently lose buffered frames.**

Location: [site/js/adapters/hardware-telemetry.js:147](/Users/nishchaysingh/aeris_cube/aeris-v5.2/site/js/adapters/hardware-telemetry.js:147); related server behavior at [backend/aeris_backend/api/app.py:743](/Users/nishchaysingh/aeris_cube/aeris-v5.2/backend/aeris_backend/api/app.py:743) and [telemetry/stream.py:274](/Users/nishchaysingh/aeris_cube/aeris-v5.2/backend/aeris_backend/telemetry/stream.py:274).

After a fallback poll, frames may arrive before the new WebSocket subscribes. The server sends future queued frames, while the client's initial status handler adopts the stream without fetching the missing backlog. A later frame advances `lastN` past the missing frame, and no gap event is emitted for this transition.

Observed twice in the unmodified live suite: after backend restart, the WebSocket consumer received **11 of 12 frames, starting at n=2**. Fixing only the test cleanup timer in memory still left this same missing-frame failure, without the later fetch error. A deterministic transport fixture independently reproduced delivery `[2]`, cursor `2`, no backlog request and no gap event while frame 1 remained available in the new stream's recent buffer. This is client display continuity, not demonstrated loss of the server's saved recording.

Required correction: implement a race-safe resume/backfill path using stream identity and cursor. Buffer or coordinate concurrent WebSocket frames until catch-up completes; deduplicate and preserve order. If retained history is insufficient, emit an explicit gap. Test same-process reconnect, backend restart, frames arriving during handshake/catch-up, duplicate delivery, stale responses, and buffer overflow. Keep the existing L14 assertions. The relevant adapter/test behavior already existed in v5.1.

Evidence: `full-tests/live.log`, `live-permitted-recheck/live.log`, `live-isolation-probe.log`, `websocket-gap-probe.json` and their probe scripts.

**V52-2 · P2 · Live status can promote synthetic ancestry to declared physical.**

Location: [backend/aeris_backend/telemetry/stream.py:303](/Users/nishchaysingh/aeris_cube/aeris-v5.2/backend/aeris_backend/telemetry/stream.py:303); [backend/aeris_backend/hardware/bridge.py:99](/Users/nishchaysingh/aeris_cube/aeris-v5.2/backend/aeris_backend/hardware/bridge.py:99).

`TelemetryHub.provenance()` only lowers trust for a top-level `lineage.trust == "synthetic"`. It does not apply the recording classifier's complete ancestry rules. Protocol-valid artificial fixtures declaring physical/`synthetic:false` but carrying `ancestry_trust:synthetic`, a synthetic ancestry reference, `original_synthetic:true`, or unknown lineage produced **live=true**, **synthetic=false** and **DECLARED PHYSICAL DEVICE** in `/telemetry/status`; `/capabilities` also reported hardware live. Recording the same fixtures produced a conservatively synthetic saved recording.

Normal backend-generated exports have consistent top-level trust and are not all affected. Saved-recording classification was conservative in these probes, and `physical_verified` remained false throughout. The defect is the disagreement in the live presentation/capabilities, not evidence that the software verified a physical device.

Required correction: share the conservative classifier across live status, capabilities, WebSocket provenance and recording paths. Add positive declared-physical controls plus synthetic, unknown, legacy nested and flattened ancestry cases. Synthetic/unknown ancestry must not enable physical-live status.

Evidence: `provenance-api-probe.json` and `provenance_probe.py`. These are artificial fixtures injected into the bridge and exercised through real API routes, not hardware recordings.

**V52-3 · P2 · The live-test shutdown timer can kill the replacement backend.**

Location: [site/tests/live_backend.test.js:57](/Users/nishchaysingh/aeris_cube/aeris-v5.2/site/tests/live_backend.test.js:57).

`stopBackend()` schedules a five-second kill callback against the mutable global `proc` and does not clear it after the old process exits. Once `startBackend()` replaces `proc`, that callback can send SIGKILL to the new backend. The deterministic probe executes the original helper against two fake child processes and observes exactly that sequence. No real process is killed by that probe.

In the live run, this explains the later `fetch failed` after the missing-frame wait. An investigation-only in-memory correction of this helper removed that error while leaving V52-1 reproducible. That diagnostic is not a replacement full-suite pass.

Required correction: capture the specific child being stopped, clear its fallback timer on exit, and make shutdown idempotent. Verify that a replacement child survives an old timer and that fallback termination still works for a genuinely stuck old child. This helper is unchanged from v5.1.

Evidence: `stop-timer-probe.json`, `stop_timer_probe.cjs`, `live_isolation_probe.cjs` and its log.

**V52-4 · P2 · Legacy export audit misses corrupted descendants.**

Location: [backend/aeris_backend/tools/dbtool.py:158](/Users/nishchaysingh/aeris_cube/aeris-v5.2/backend/aeris_backend/tools/dbtool.py:158).

The new audit only checks an immediate `derived_from` or recording transport against originals stored in non-wire units. A synthetic original with time `[0,100,200] ms` and tilt `[10,11,12] deg` was exported/re-recorded twice with the actual v5.1 implementation. Both copies therefore carry those raw values under incorrect `s`/`rad` labels. With the original and both copies stored in an isolated database, v5.2 `export-audit` reports **ORIGINAL and COPY_1 but misses COPY_2**. It does not follow the affected-copy chain/nested lineage. The database remained unchanged by the audit.

Required correction: traverse available parent/ancestry relationships transitively, with cycle protection and clear handling of missing parents. Include descendants made with v5.2 from an already-corrupted legacy copy: correct current export code cannot infer or repair previously lost units. Distinguish confirmed affected lineage from unresolved risk; retain the originals and avoid automatic numeric repair. Test at least two legacy generations, missing ancestors, cycles and an unaffected control. Update migration documentation to state any remaining detection limits.

Evidence: `export-audit-v51-generated-chain.json`, `export-probe-results.json`, `export_probe.py`. This finding does not undo the verified conversion fix for fresh v5.2 exports of correctly labelled originals.

**What is left to finish the software release.**

Apply these four targeted corrections, add focused regression coverage, and rerun the full suite plus exact-archive validator in an environment that can launch Chromium and inspect child processes. Preserve failures and distinguish platform exclusions. On macOS, the Linux `/proc` exclusion should only be accepted if its portable counterpart passes, as the current runner requires. Repackage the ZIP/bundle with matching hashes, source commit and logs. Another backend architecture or frontend redesign is not indicated by this review.

The fresh-install checks already exercised a seeded single run, exact repeat reproduction on the same install, a restarted 72-row job without duplicate rows, partial cancellation, telemetry, repeated exports, backup and shutdown. That supports continuing local simulation/research use while the issues are corrected. It does not establish public multi-user deployment readiness, a long-duration soak result, a full 1,668-row campaign rerun, Windows/non-Chromium support, or physical validation.

Hardware remains a separate phase: actual firmware and device mapping, on-board control, measured mass/COM/inertia and actuator/sensor parameters, axis/sign and timing checks, real telemetry and validation experiments. The proposed beginner cube-building page also needs a tested reference build, BOM, assembly/firmware instructions and a successful beginner build trial. Those cannot be certified from software fixtures.

**Run locally after installing Python 3.12+.** From `/Users/nishchaysingh/aeris_cube/aeris-v5.2`:

```bash
scripts/install.sh --python python3.12
scripts/start.sh
```

Open `http://127.0.0.1:8750/`. Stop with `scripts/stop.sh`. Optional `scripts/start.sh --emulator` starts synthetic telemetry; it is not a physical cube. The review did not start or install into this user-owned directory; it used isolated review/fresh-install copies.

For verification, use the repository's full `scripts/run_tests.py` and `scripts/validate_release.py` with an explicitly selected backend/browser Python and installed Playwright/Chromium. Probe commands and raw results are in the accompanying evidence pack. **No revised product release is included: this deliverable is a review.**

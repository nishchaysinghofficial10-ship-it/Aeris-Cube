# v6.0 release checks of the candidate archive

The candidate archive was built from commit `b5a2967` (`python3 scripts/package_release.py --top aeris-v6.0`: exactly
the 1 179 files tracked at that commit; 13 009 829 bytes; SHA-256
`eb2608c870dd3bbf64da8a066ee0753596db80062a5e8a97c534dd6bc89141bf`). `b5a2967` differs from the tested product commit
`91f78f3` only by the definitive test logs (`test-logs/`), evidence and the two report files
(`SOFTWARE_COMPLETION_REPORT.md`, `ACCEPTANCE_MATRIX_V6.md`).

* `candidate-archive-validation.json` (and its console log) — `scripts/validate_release.py --expect-top aeris-v6.0
  --python python3.12 --browser-python <a Python with Playwright 1.56.0>` in a new temporary directory (Linux x86-64; the
  install used Python 3.12.3 and matched the lock file; the validator itself is standard-library Python 3.11.15):
  **21 of 21 steps passed**, exit code 0 — the 17 steps of v5.2 plus **device-journey** (the native synthetic device
  built from the package's firmware sources, against the package's running backend: pairing only after the local press,
  measurements, calibration from the command log, an approved configuration, self-test, an experiment that waited for
  the local enable and ended at its duration, a synthetic recording, Simulate My Cube, a comparison that is not
  evidence, export/reimport with the same content hash, the gateway route continuing the telemetry session without a
  missing frame, a revoked credential refused 4401), **drift** (12 / 12 in the fresh install, including the signed
  release's source hash and the byte-identical WebAssembly rebuild), **firmware-host** (38 / 38) and **browser-v6**
  (51 / 51 from the extracted package); browser-cancel: browser_v52 45 / 45, browser_v3 49 / 49.
* `candidate-archive-bundle-check.json` — `scripts/compare_archive_bundle.py` against a git bundle of the repository: the
  bundle verifies in an empty repository (complete history, 66 commits), and the archive and the commit hold the same
  1 179 files with the same bytes.

The delivered archive is built from the commit tagged `aeris-v6.0`. The commit after the candidate adds this folder and
completes §11 of the report (no product, test or tooling change: `git diff b5a2967 aeris-v6.0` touches only
`SOFTWARE_COMPLETION_REPORT.md`, `ACCEPTANCE_MATRIX_V6.md` and `evidence/v6.0-release/`). Its own fresh-directory
validation and its own archive ↔ bundle check are delivered next to it — they cannot be inside the archive they check:
`aeris-site-v6.0.release-validation.json`, `aeris-site-v6.0.archive-bundle-check.json`.

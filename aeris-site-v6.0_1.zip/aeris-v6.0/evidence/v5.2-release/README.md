# v5.2 release checks of the candidate archive

The candidate archive was built from commit `9c17aac` (`python3 scripts/package_release.py --top aeris-v5.2`, top
folder `aeris-v5.2`, 777 files, 10 750 000 bytes, SHA-256
`5814ee069f84274e1b6d8202be9bdb39e2b1881449950457f97e3197a950386d`).

* `candidate-archive-validation.json` (and its console log) — `scripts/validate_release.py --expect-top aeris-v5.2
  --browser-python <a Python with Playwright 1.56.0>` in a new temporary directory (Linux x86-64; the install used
  Python 3.12.3 and matched the lock file; the validator itself is standard-library Python 3.11.15): **17 of 17 steps
  passed**, exit code 0 — the 14 steps of v5.1 plus telemetry-units (G1: 80 frames in wire units, 79 rows of the
  backend's replay matched by seq with every physical value and interval, an incomplete vector HTTP 422),
  telemetry-generations (G2: 20 generations, largest lineage 3 068 bytes of a 6 144 budget, the 20th copy imported
  as synthetic, exported as generation 21, not evidence), the extended test-runner (G3: exit 2 for the skipped case,
  exit 3 under a declared exclusion) and browser-cancel (G4: browser_v52 45 / 45 and browser_v3 49 / 49 from the
  extracted package).
* `candidate-archive-bundle-check.json` — `scripts/compare_archive_bundle.py` against a git bundle of that commit:
  the bundle verifies in an empty repository (complete history, 43 commits), and the archive and the commit hold the
  same 777 files with the same bytes.

The delivered archive is built from the commit tagged `aeris-v5.2`. The commits after the candidate add these files
and complete the report (no product, test or tooling change: `git diff 9c17aac aeris-v5.2` touches only
`SOFTWARE_COMPLETION_REPORT.md` and `evidence/v5.2-release/`). Its own fresh-directory validation and
its own archive ↔ bundle check are delivered next to it — they cannot be inside the archive they check:
`aeris-site-v5.2.release-validation.json`, `aeris-site-v5.2.archive-bundle-check.json`.

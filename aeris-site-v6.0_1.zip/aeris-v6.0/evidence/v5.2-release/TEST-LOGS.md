# The v5.2 test run (historical, preserved for v6.0)

`test-logs/` here is a byte-for-byte copy of the repository's `test-logs/` at the commit tagged `aeris-v5.2`: the
definitive v5.2 run on Linux x86-64 (864 passed, 0 failed, 0 skipped, 0 not run in 19 suites, as counted by the v5.2
runner; verdict "PASSED — all 19 suites ran and passed; every test case executed (full validation)"), cited as
`test-logs/` in `V5_2_SOFTWARE_COMPLETION_REPORT.md`. The repository's own `test-logs/` now holds the v6.0 run. These
files describe v5.2, not v6.0.

# Test run — PASSED — all 18 suites ran and passed

2026-10-01T01:49:40+00:00 · Linux-6.18.44-fc-v50-x86_64-with-glibc2.39 · backend Python `/home/claude/aeris-v51/.venv/bin/python` · Node v22.22.2

- backend python: `/home/claude/aeris-v51/.venv/bin/python` (--backend-python, given as `/home/claude/aeris-v51/.venv/bin/python`)
- browser python: `/home/claude/aeris-v51/.venv/bin/python` (--browser-python, given as `/home/claude/aeris-v51/.venv/bin/python`)
- node: `/opt/node22/bin/node` (default: node on PATH)

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| backend | passed | 391 | 0 | 0 | 0 | 183.7 | backend.log |
| js:assistant | passed | 9 | 0 | 0 | 0 | 0.3 | js-assistant.log |
| js:engine | passed | 9 | 0 | 0 | 0 | 0.8 | js-engine.log |
| js:numerics | passed | 38 | 0 | 0 | 0 | 0.6 | js-numerics.log |
| js:platform | passed | 16 | 0 | 0 | 0 | 0.3 | js-platform.log |
| js:runs | passed | 14 | 0 | 0 | 0 | 0.3 | js-runs.log |
| js:schema | passed | 7 | 0 | 0 | 0 | 0.3 | js-schema.log |
| js:service | passed | 19 | 0 | 0 | 0 | 0.4 | js-service.log |
| js:ui | passed | 16 | 0 | 0 | 0 | 0.3 | js-ui.log |
| js:v4 | passed | 27 | 0 | 0 | 0 | 0.6 | js-v4.log |
| js:v5 | passed | 17 | 0 | 0 | 0 | 0.6 | js-v5.log |
| js:v51 | passed | 9 | 0 | 0 | 0 | 0.3 | js-v51.log |
| live | passed | 14 | 0 | 0 | 0 | 13.7 | live.log |
| browser:browser_check | passed | 50 | 0 | 0 | 0 | 71.1 | browser-browser_check.log |
| browser:browser_v3 | passed | 49 | 0 | 0 | 0 | 52.5 | browser-browser_v3.log |
| browser:browser_v4 | passed | 24 | 0 | 0 | 0 | 66.8 | browser-browser_v4.log |
| browser:browser_v5 | passed | 36 | 0 | 0 | 0 | 50.2 | browser-browser_v5.log |
| browser:browser_v51 | passed | 12 | 0 | 0 | 0 | 55.9 | browser-browser_v51.log |

**Totals (tests in the suites that ran):** 757 passed, 0 failed, 0 skipped, 0 not run.
**Suites:** 18 passed, 0 failed, 0 not run, 0 skipped, 0 not selected.
**Full validation:** yes (exit code 0).

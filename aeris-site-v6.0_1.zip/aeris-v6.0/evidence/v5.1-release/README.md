# v5.1 release checks of the candidate archive

The candidate archive was built from commit `2ed4e66` (`python3 scripts/package_release.py`, top folder
`aeris-v5.1`, 552 files, 10 388 209 bytes, SHA-256 `481b146fd2d7291a883a9bd1664258de12c49de4ee336ab6167ff4e53c704777`).

* `candidate-archive-validation.json` — `scripts/validate_release.py --expect-top aeris-v5.1` in a new temporary
  directory (Linux x86-64, Python 3.12.3 for the install): **14 of 14 steps passed**.
* `candidate-archive-bundle-check.json` — `scripts/compare_archive_bundle.py` against a git bundle of that commit:
  the bundle verifies (complete history, 35 commits), and the archive and the commit hold the same 552 files with the
  same bytes.

The delivered archive is built from the commit tagged `aeris-v5.1`. The commits after the candidate add these files
and complete the report (no product, test or tooling change other than the bundle check's verification in an empty
repository). Its own fresh-directory
validation and its own archive ↔ bundle check are delivered next to it — they cannot be inside the archive they
check: `aeris-site-v5.1.release-validation.json`, `aeris-site-v5.1.archive-bundle-check.json`.

# The v5.1 test run (historical, preserved for v5.2)

`test-logs/` here is a byte-for-byte copy of the repository's `test-logs/` at the commit tagged `aeris-v5.1`: the
definitive v5.1 run on Linux x86-64 (757 passed, 0 failed, 0 skipped, 0 not run in 18 suites; verdict
"PASSED — all 18 suites ran and passed"), cited as `test-logs/` in `V5_1_SOFTWARE_COMPLETION_REPORT.md`. The
repository's own `test-logs/` now holds the v5.2 run. These files describe v5.1, not v5.2; the v5.1 runner that
wrote them did not yet count skipped test cases (review finding G3 of v5.1), which this run did not have.

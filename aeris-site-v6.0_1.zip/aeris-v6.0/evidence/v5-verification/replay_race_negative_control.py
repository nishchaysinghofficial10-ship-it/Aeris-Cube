"""Negative control for the replay-race checks (review finding E).

Copies the repository (without .git, data, virtual environments) to a temporary directory, puts back the v4
behaviour of the setup preview in that copy only (no cancel on a view change, no generation check, no mode guard
in previewSetup), and runs site/tests/browser_v5.py there. The two race checks (DEMO and SIMULATION) must FAIL
on the copy, with the v4 symptom (the 3-D view shows "Setup preview" and no run), while the unchanged repository
passes them. This shows the checks detect the defect rather than passing vacuously.

    AERIS_PYTHON=backend/.venv/bin/python python3 evidence/v5-verification/replay_race_negative_control.py

Needs Playwright + Chromium (like browser_v5.py). Exit code 0 when both race checks fail on the reverted copy.
"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REVERTS = [
    ('var previewTimer = U.debounce(function (gen) { if (gen === W.viewGen && W.viewMode === "setup") previewSetup(); }, 90);',
     'var previewTimer = U.debounce(function (gen) { previewSetup(); }, 90);   /* NEGATIVE CONTROL: v4 behaviour */'),
    ('W.viewGen++; previewTimer.cancel();', 'W.viewGen++;   /* NEGATIVE CONTROL: no cancel */'),
    ('    if (!W.viewer || W.viewMode !== "setup") return;\n    var v = W.draftVal', '    if (!W.viewer) return;   /* NEGATIVE CONTROL: v4 guard */\n    var v = W.draftVal'),
]


def main():
    tmp = Path(tempfile.mkdtemp(prefix="aeris-race-control-"))
    try:
        copy = tmp / "repo"
        skip_any = shutil.ignore_patterns(".git", ".venv", "__pycache__", "*.egg-info")

        def ignore(d, names):                    # the top-level data/ and test-logs/ only (package data stays)
            out = set(skip_any(d, names))
            if Path(d) == ROOT:
                out |= {n for n in names if n in ("data", "test-logs")}
            return out
        shutil.copytree(ROOT, copy, ignore=ignore)
        ws = copy / "site" / "js" / "workspace.js"
        src = ws.read_text(encoding="utf-8")
        for old, new in REVERTS:
            if src.count(old) != 1:
                print("the fix was not found where expected; this control no longer matches the code:", old[:80])
                return 2
            src = src.replace(old, new)
        ws.write_text(src, encoding="utf-8")
        env = dict(os.environ)
        if "AERIS_PYTHON" not in env and (ROOT / "backend" / ".venv" / "bin" / "python").exists():
            env["AERIS_PYTHON"] = str(ROOT / "backend" / ".venv" / "bin" / "python")
        p = subprocess.run([sys.executable, "tests/browser_v5.py"], cwd=copy / "site", env=env, capture_output=True, text=True, timeout=900)
        out = p.stdout + p.stderr
        print(out)
        race = [l for l in out.splitlines() if "replay race (E)" in l]
        failed = [l for l in race if l.startswith("FAIL")]
        others_failed = [l for l in out.splitlines() if l.startswith("FAIL") and "replay race (E)" not in l]
        print(f"negative control: {len(failed)} of {len(race)} race checks failed on the reverted copy (expected: all); "
              f"other checks failed: {len(others_failed)}")
        return 0 if race and len(failed) == len(race) else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())

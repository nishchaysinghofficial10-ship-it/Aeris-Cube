"""Negative control for the orphaned-worker check (found while completing v5; docs/JOBS_AND_RECOVERY.md).

Copies the backend to a temporary directory, removes the parent watch of the worker processes in that copy only
(the pool is created as in v4, without the backend's process id), and runs
test_process_restart.py::test_worker_processes_exit_when_the_backend_process_is_killed there, then the same test on
the unchanged repository. The copy must FAIL (the killed backend's workers keep running) and the repository must
pass. The test itself kills anything it started, so nothing is left behind.

    backend/.venv/bin/python evidence/v5-verification/orphan_workers_negative_control.py

Linux (the test finds the processes through /proc). Exit code 0 when the copy fails and the repository passes.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TEST = "tests/test_process_restart.py::test_worker_processes_exit_when_the_backend_process_is_killed"
FIX = "initargs=(self.flags, os.getpid()))"
REVERT = "initargs=(self.flags,))   # NEGATIVE CONTROL: no parent watch (v4)"


def run(backend):
    p = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", TEST], cwd=backend, capture_output=True, text=True, timeout=300)
    return p.returncode, p.stdout + p.stderr


def main():
    tmp = Path(tempfile.mkdtemp(prefix="aeris-orphan-control-"))
    try:
        copy = tmp / "backend"
        shutil.copytree(ROOT / "backend", copy, ignore=shutil.ignore_patterns(".venv", "__pycache__", "*.egg-info"))
        mgr = copy / "aeris_backend" / "jobs" / "manager.py"
        src = mgr.read_text(encoding="utf-8")
        if src.count(FIX) != 1:
            print("the fix was not found where expected; this control no longer matches the code")
            return 2
        mgr.write_text(src.replace(FIX, REVERT), encoding="utf-8")
        code_copy, out_copy = run(copy)
        print("=== copy WITHOUT the parent watch (expected: FAIL)\n" + out_copy)
        code_repo, out_repo = run(ROOT / "backend")
        print("=== repository WITH the parent watch (expected: pass)\n" + out_repo)
        ok = code_copy != 0 and "still running" in out_copy and code_repo == 0
        print(f"negative control: copy exit {code_copy}, repository exit {code_repo} → {'as expected' if ok else 'NOT as expected'}")
        return 0 if ok else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())

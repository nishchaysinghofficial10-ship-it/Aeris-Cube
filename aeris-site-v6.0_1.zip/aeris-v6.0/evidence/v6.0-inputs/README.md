# AERIS implementation handoff

Prepared 9 October 2026 for the user's requested Claude implementation task.

Read AERIS-Claude-Implementation-Prompt.md first. It is the complete requested scope: optional Build & Connect with the virtual cube remaining the default, plus all four V52 review fixes. The blueprint supplies design context; the independent review and its nested evidence ZIP supply reproductions. baseline/ holds the exact v5.2 source ZIP, Git bundle and supplied validation sidecars. Extract these into a separate checkout; preserve original archives.

The review's independently executed results differ from the supplied Linux results. Keep their attribution. No physical cube was supplied or tested. Candidate hardware is not a validated kit. The source needs implementation; this pack does not claim to contain the completed new feature.

MANIFEST.json contains SHA-256 values for each input. Nested ZIPs are intentional. The Git bundle contains the source history and aeris-v5.2 tag.

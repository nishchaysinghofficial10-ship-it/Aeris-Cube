# AERIS Build and Connect — proposed hardware/software expansion

9 October 2026. Design proposal based on the reviewed v5.2 repository. This is a development specification, not a tested shopping list, completed firmware, manufacturing release or hardware validation result. Product source has not been changed.

**Recommended product promise**

“Build the supported AERIS reference cube, connect it to the website, calibrate it, run approved experiments, and compare its real motion with a simulation.”

Start with one versioned three-wheel reference design. Support custom cubes through documented device profiles and conformance checks. Worldwide location does not prevent connection; arbitrary motor, mechanical and firmware choices do prevent a universal balance guarantee. Unknown hardware can initially receive telemetry-only support.

The beginner experience should require assembly and guided checks, not control-theory knowledge or editing source code. That requires a preassembled controller board, labelled keyed wiring, protected wheel assemblies, ready-to-install firmware and a reference build that someone other than its designer has successfully assembled.

**Existing software and the required change**

The current [hardware handoff](/Users/nishchaysingh/aeris_cube/aeris-v5.2/site/docs/HARDWARE_HANDOFF.md) explicitly makes the telemetry path read-only. It includes TCP NDJSON, mapping adapters, file/recording replay, parameter sets and simulation comparisons. It does not include device control firmware or a serial/BLE companion bridge. The backend creates one bridge at `backend/aeris_backend/api/app.py:190`; a new source replaces the previous one at `hardware/bridge.py:159`.

Public multi-device support therefore requires new capabilities, not just enabling remote TCP. Preserve the existing research backend and old telemetry contracts. Implement command handling as a separate, explicitly negotiated capability; old devices and replay sources stay read-only.

**Connection and control architecture**

```mermaid
flowchart LR
  U[Owner's browser] <-->|USB during setup| D[Cube firmware]
  U <-->|HTTPS and WSS| C[AERIS accounts and device gateway]
  D <-->|Optional outbound WSS over Wi-Fi| C
  C --> R[Existing Python research engine]
  C --> S[Profiles, recordings and comparisons]
  D <-->|Local control and feedback| M[IMU, encoders and motor drivers]
```

USB commissioning is the first supported path. The HTTPS page uses a user-approved serial connection; Espressif's browser flasher can install a prebuilt ESP firmware image. Browser/OS support must be detected and tested; publish desktop Chrome/Edge support first and provide a packaged companion/local UI for unsupported combinations. Do not promise every phone/browser. [Web Serial documentation](https://developer.chrome.com/docs/capabilities/serial), [Espressif esptool-js](https://github.com/espressif/esptool-js).

For untethered trials, provision Wi-Fi during setup and let the cube initiate an authenticated outbound connection to the gateway. No visitor should need a public IP address or router port forwarding. A USB/power tether adds external forces not represented by the current model, so commissioning on a fixture and untethered balance experiments need separate instructions and labels.

The cube executes sensing, estimation, balance control, allocation and protection locally. The website sends bounded requests such as “start the approved edge trial”; the server stores data and runs simulations. Internet round trips and browser rendering must never be required for the next stabilizing motor update. Candidate balance-loop targets can be evaluated around 500–1,000 Hz, but no rate is promised until timing, bus load and stability are measured. Motor current control belongs in the motor controllers. Telemetry can be sampled/downsampled independently.

**Hardware development baseline**

Use three orthogonal wheel assemblies and manual placement near the edge/corner equilibrium for the first release. A practical programme is to commission the same electronics on a restrained one-axis rig, then assemble all three axes. Self-righting, jumping and movement across the floor are later capabilities. The present AERIS model assumes an ideal fixed pivot/hinge and ends at loss of support; it does not simulate general impacts or jumping. See [PHYSICS.md](/Users/nishchaysingh/aeris_cube/aeris-v5.2/site/docs/PHYSICS.md:95). ETH's Cubli work also treats jump-up as a distinct mechanism/control problem. [ETH Cubli](https://idsc.ethz.ch/research-dandrea/research-projects/archive/cubli.html).

The following quantities define what a future builder orders. Proposed AERIS assemblies below do not yet exist as validated products.

| Quantity | Item for the final reference kit | Development candidate / information still needed |
|---:|---|---|
| 1 | Preassembled AERIS controller board | ESP32-S3-based controller is a candidate; start development with ESP32-S3-DevKitC-1-N8R8. Final board incorporates regulated logic power, sensor connectors, communication interface and local arm/stop inputs. Timing under radio load must be verified. |
| 1 | Rigidly mounted six-axis IMU, potentially on the controller board | LSM6DSOX is a candidate; Adafruit breakout product 4438 is a concrete development option, not a tested AERIS selection. Manufacturer listing was out of stock when checked. |
| 3 | Identical BLDC motors | Exact part number awaits the mass/COM, wheel inertia, torque, RPM, voltage, thermal and bearing-load calculations and a one-axis test. A generic “brushless motor” listing is insufficient. |
| 3 | Current-controlled motor drivers | Must support the required bidirectional torque and encoder feedback. ODrive Micro is one development candidate, not a mandatory or proven kit choice. Confirm continuous/peak current, electrical speed, firmware, packaging and power limits. |
| 3 | Rotor position/speed feedback assemblies | Encoder and magnet/shaft mounting matched to the selected driver and motor. May be integrated into the driver; do not buy three additional boards unnecessarily. |
| 3 | Captive reaction-wheel/rotor assemblies | Manufacturer-ready drawing, material, inertia, retention, balance tolerance and tested maximum RPM required. Supply as matched assemblies for beginners. |
| 1 set | Cube frame, mounts, guards, feet/pivot pieces | Downloadable STEP/STL and manufacturing drawings with one revision shared by BOM and firmware profile. Printing service should be an option. |
| 1 set | Labelled wiring and fasteners | Keyed, precrimped harness; final screw counts and lengths must come from released CAD. Include sensor/bus wiring and motor-power wiring separately. |
| 1 | Power system matched to the kit | Fused pack, suitable charger, switch, logic regulator, current/voltage monitoring and a designed regenerative-energy path. Voltage, capacity and ratings remain to be selected. Do not ask a beginner to assemble battery cells. |
| 1 set | Local arm control, physical emergency stop and indicators | Hardware disable path plus tested firmware fault handling; remote UI stop is supplementary. |
| 1 | Catch/commissioning fixture | Supports a stalled/falling cube and keeps users clear of rotating components during first tests. |
| 1 | USB data cable | Correct connector and data-capable cable; used for firmware/setup. |
| 1 set | Basic tools | Correct hex keys/screwdriver, small scale and ruler/caliper; electrical checks need a multimeter or a pretested harness/test fixture. |

Official component references: [Espressif development boards](https://www.espressif.com/en/products/devkits/esp32), [Adafruit LSM6DSOX](https://www.adafruit.com/product/4438), [ODrive Micro datasheet](https://docs.odriverobotics.com/v/latest/hardware/micro-datasheet.html). An ESP32-S3 CAN/TWAI design also needs an external transceiver and proper bus termination; this belongs in the controller/harness design. [Espressif TWAI documentation](https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/api-reference/peripherals/twai.html).

These named parts are candidates, not a compatibility guarantee. The motor, driver, rotor and power subsystem must be selected together. Braking wheels regenerate electrical energy; ODrive documents that Micro lacks a built-in brake-resistor feature and needs a suitable energy-absorption arrangement. A battery must itself permit the charging/regeneration conditions; a generic power adapter is not automatically sufficient. [ODrive power-system guidance](https://docs.odriverobotics.com/v/latest/encoders.html).

An existing hobby design such as [remrc's Self-Balancing-Cube](https://github.com/remrc/Self-Balancing-Cube) can inform an inexpensive demonstration branch. Its published ESP32/MPU6050/Nidec arrangement is not already an AERIS-compatible kit or a validated torque-controlled research platform. Retaining the frozen AERIS design and comparing scientific controllers still requires an explicit firmware/model integration.

Do not publish “buy these and it will balance” until the combined system has been built and measured. No defensible final price follows from this provisional BOM; obtain regional supplier quotes after the motor/mechanical selection. Publish tested substitutes with their own profile revisions and stock-check dates.

**What must exist before visitors can order**

1. A released CAD package and assembly drawing with no interference between rotors, guards, frame and wiring.
2. A BOM with exact manufacturer part numbers, quantities, connector pinouts, screw lengths, supplier links and tested alternatives.
3. A schematic, preassembled PCB ordering package, wiring harness drawing and power/regen design.
4. Firmware source, pinned build environment, prebuilt board-specific binary, release manifest, recovery procedure and revision compatibility table.
5. Bench evidence for torque/current response, encoder direction, rotor balance/retention, RPM/temperature limits, regenerative voltage and local stop/watchdog behavior.
6. Measured reference parameters, calibration fixtures/procedure and a conservative initial controller.
7. Actual assembly photos/videos and troubleshooting at each checkpoint.
8. An independent beginner build trial using only the published materials. Record where assistance was needed and fix the instructions/kit.

Engineering must establish sufficient control torque and usable wheel momentum for the chosen recovery region. Nominal spin speed alone does not establish this. Include wheel saturation and a tested recovery/stop policy. A six-axis IMU supplies gravity direction and body rates but no independent long-term absolute yaw reference; avoid promising exact sustained compass heading from it. Any extra heading sensor or external reference needs integration and testing around motor magnetic interference.

**Software work packages**

| Area | Concrete work |
|---|---|
| Build page | Revision-based stepper; BOM/downloads; real photos; progress; diagnostics; each step has expected result and repair guidance. Link directly to Connect and Lab. |
| Firmware installer | Detect supported board, select matching signed release manifest/image, verify download and post-flash version, retain calibration where compatible, recover interrupted updates. Motor outputs remain disabled during update. |
| Device firmware | IMU/encoder drivers, deterministic estimator/controller loop, current-control interface, bounded allocation, limits, telemetry, local storage for gaps, fault reporting, self-tests and a local protection state machine. |
| Connection adapters | USB serial first; authenticated outbound Wi-Fi gateway second; companion fallback. Preserve read-only adapters and do not turn replay traffic into command authority. |
| Device registry | Pairing requires local possession, then owner/device credentials, revocation, roles and one active control lease. Support multiple users/devices with isolated streams and storage. |
| Versioned device profile | Hardware/BOM/firmware versions, wheel axes/order/signs, units/frames, allowed modes/controllers, geometry/mass/COM/inertia, motor/sensor parameters, calibrated limits and evidence. Attach a profile hash to experiments. |
| Command service | Separate proposed command contract with device/session/command IDs, supported action, bounds, expiry, acknowledgement/result and observed resulting state. Deduplicate retries; reject stale, unauthorized, incompatible and out-of-state commands. |
| Digital twin | Create simulation config from the device's selected profile and experiment recipe; reuse current Python engine and parameter-set APIs. Preserve uncertainty, data origin and model limitations. |
| Public deployment | HTTPS/WSS, tenant-scoped authorization on every record and stream, worker quotas, bounded upload/telemetry queues, retention, backups and audit trails. A source flag is not device authentication. |
| Verification | Device/firmware conformance tests, multi-user isolation, reconnect/backfill, command expiry/retry, competing controllers, firmware mismatch, loss of network, driver/IMU faults, browser support, real bench trials. |

Research controllers implemented in Python do not automatically execute on the microcontroller. Port and verify only selected controllers first. Match coordinate conventions, discrete timing, gains, filters and actuator behavior; include firmware/controller hashes in comparisons. Reject unsupported algorithms instead of silently replacing them.

Suggested local firmware states are BOOT → DISARMED → SELF_TEST → READY → LOCALLY_ARMED → BALANCING, plus a latched FAULT state. Calibration and firmware update are disarmed-only. A browser cannot arm a cube without the prescribed local enable action. Network loss triggers a tested local policy, rather than waiting for a cloud response or blindly switching off a balancing cube; the fixture must accommodate a fall. An emergency stop removes motor drive, but it does not instantly stop wheel inertia or keep the cube upright.

Commands can initially include identify, read diagnostics, disarmed calibration, apply an approved configuration, start an approved balance trial, normal stop and recording. Raw unrestricted motor writes and autonomous jump-up are outside the beginner interface. “Accepted” must not be displayed as “executed”; verify the resulting device state. A simulated disturbance command must never imply that a physical disturbance was applied.

**How a visitor builds and uses it**

| Step | Visitor action | Website/device checkpoint |
|---:|---|---|
| 1 | Select the supported kit revision and country | Show exact BOM, compatible firmware and supported computer/browser. |
| 2 | Order parts/printed frame/preassembled board | Checklist ties each delivered part to the same revision. |
| 3 | Assemble frame and protected wheel modules | Photos show orientation, fasteners and clearance checks. |
| 4 | Mount IMU/controller and plug labelled cables | No soldering in the beginner path; verify motor-power isolation before powering logic. |
| 5 | Connect USB and install firmware | Detect board, flash matching release, verify identity; motors disabled. |
| 6 | Pair “My Cube” to the owner | Local possession check, unique device identity, compatibility report. |
| 7 | Run guided setup in the fixture | IMU bias/axis check, encoder direction, low-energy individual wheel check, local stop/fault checks. Failures block balance. |
| 8 | Save this cube's profile | Load nominal kit parameters; enter measured mass/dimensions and supported calibration results. Unknown values stay nominal. |
| 9 | Run the matching simulation | Website shows predicted recovery and saturation for the approved initial test, with the profile/version recorded. |
| 10 | Place cube near the tested edge equilibrium and locally enable | Firmware admits only the approved operating region, limits and controller. Site requests the trial. |
| 11 | Record and compare | Live animation follows telemetry; separate simulated trajectory/metrics compare against the actual recording. |
| 12 | Unlock corner trials when qualified | Three-axis commissioning and appropriate fixture checks must pass; retain a clear stop/recovery procedure. |

Calibration cannot discover every inertia/COM parameter from a stationary IMU. Factory/reference values remain nominal until measured or identified with sufficient evidence. The physical cube has estimated attitude, not simulator ground truth. Assess estimator accuracy only with an independent reference.

**Recommended delivery order and completion evidence**

1. Correct the four v5.2 review findings, especially reconnect continuity and provenance, before building command features on top.
2. Freeze a single reference hardware architecture and build the restrained one-axis rig. Select the exact motor/rotor/driver/power combination using measurements.
3. Implement USB firmware installation, telemetry, profile loading and a guided setup flow. Demonstrate the firmware's local stop/fault behavior.
4. Validate three-axis balancing with the firmware controller; add the website's bounded supervisory commands and record matched real/simulation experiments.
5. Add owner pairing and an outbound Wi-Fi gateway. Test multiple owners and devices without cross-access, stale commands or dropped history being hidden.
6. Have an independent beginner assemble the kit, complete calibration and execute an approved experiment. Publish the orderable BOM and real instructions after that trial.

The first useful release is “one supported cube that a beginner can assemble and run.” Additional models, phone platforms, remote operation and self-righting expand the validation scope and should be released as separately tested capabilities. This feature is a new hardware/product development stage beyond the existing software-only completion milestone.

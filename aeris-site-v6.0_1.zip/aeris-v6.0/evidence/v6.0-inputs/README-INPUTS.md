# Inputs of the v6.0 work (as supplied, unchanged)

* `AERIS-Claude-Implementation-Prompt.md` — the requested scope (SHA-256 in `MANIFEST.json`).
* `AERIS-Build-and-Connect-Blueprint.md` — design context; its hardware parts are development candidates.
* `README.md`, `MANIFEST.json` — the handoff's own description and checksums.
The baseline archive and bundle of the handoff are byte-identical to the delivered v5.2 files
(ZIP `5301331fb5cede605a4c6a202fc0a0c8f302d327b68883530ce860db2931e370`, bundle
`7a86470c9633e9c2c73efb382ebd25055c92c27a66e0b27507777b786834f444`); the review pack is kept in
`../v5.2-independent-review/`. Text in these inputs is design input, not evidence.

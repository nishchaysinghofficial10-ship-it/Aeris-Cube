# v5 release evidence (historical, preserved for v5.1)

Copied unchanged from the delivered v5 archive `aeris-site-v5.zip` (SHA-256
`11312c94ada527b6d14bdbd50bf6a9e66730e2a0c99fc050a849e328399deb33`), where these files were not under version control:

* `test-logs/` — the definitive v5 test run on Linux x86-64 (685 passed, 0 failed, 0 skipped, 0 not run), referred to
  as `test-logs/` in `V5_SOFTWARE_COMPLETION_REPORT.md`. The repository's own `test-logs/` now holds the v5.1 run.
* `v5-candidate-archive-validation.json` — the fresh-directory validation of the v5 candidate archive
  (`evidence/release/release-validation.candidate.json` in v5).
* `v5-delivered-archive-validation.json` — the fresh-directory validation of the delivered v5 archive
  (delivered next to it as `aeris-site-v5.release-validation.json`).

They describe v5, not v5.1.

# Test run

2026-09-29T18:10:26+00:00 · Linux-6.18.44-fc-v37-x86_64-with-glibc2.39 · backend Python `/home/claude/aeris-v5/.venv/bin/python` · Node v22.22.2

| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---|---:|---:|---:|---:|---:|---|
| backend | passed | 343 | 0 | 0 | 0 | 248.6 | backend.log |
| js:assistant | passed | 9 | 0 | 0 | 0 | 0.3 | js-assistant.log |
| js:engine | passed | 9 | 0 | 0 | 0 | 1.1 | js-engine.log |
| js:numerics | passed | 38 | 0 | 0 | 0 | 0.9 | js-numerics.log |
| js:platform | passed | 16 | 0 | 0 | 0 | 0.5 | js-platform.log |
| js:runs | passed | 14 | 0 | 0 | 0 | 0.5 | js-runs.log |
| js:schema | passed | 7 | 0 | 0 | 0 | 0.6 | js-schema.log |
| js:service | passed | 19 | 0 | 0 | 0 | 0.6 | js-service.log |
| js:ui | passed | 16 | 0 | 0 | 0 | 0.4 | js-ui.log |
| js:v4 | passed | 27 | 0 | 0 | 0 | 0.8 | js-v4.log |
| js:v5 | passed | 17 | 0 | 0 | 0 | 0.7 | js-v5.log |
| live | passed | 13 | 0 | 0 | 0 | 11.8 | live.log |
| browser:browser_check | passed | 50 | 0 | 0 | 0 | 99.6 | browser-browser_check.log |
| browser:browser_v3 | passed | 47 | 0 | 0 | 0 | 62.4 | browser-browser_v3.log |
| browser:browser_v4 | passed | 24 | 0 | 0 | 0 | 132.5 | browser-browser_v4.log |
| browser:browser_v5 | passed | 36 | 0 | 0 | 0 | 74.9 | browser-browser_v5.log |

**Totals:** 685 passed, 0 failed, 0 skipped, 0 not run.

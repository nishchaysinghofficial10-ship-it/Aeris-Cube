# Independent AERIS v5.1 review

Reviewed on 1 October 2026, on the user's Mac. **The v5.1 fixes are substantive and the research backend is working, but the software still needs four targeted corrections before an unconditional completion claim.** Two are telemetry export defects, one concerns the validation verdict, and one is a browser-test timing assumption. This review did not change product source or user data.

## What was verified

- The delivered ZIP is intact: SHA-256 `c1e4138dedb3bb030e8aa14eb93cb196265eea2e5b18d2934dcfeb686c638ad4`.
- Git bundle verifies with complete history, 39 commits. Tag `aeris-v5.1` resolves to `f76d632efac6e4e0148fc69c3099651b146bdad1`.
- All **555 archive files exactly match the Git commit**. The separately supplied extracted folder also matches; its only extras are four Finder `.DS_Store` files. External reports and test logs match their archived copies.
- `LocalSimulatorAdapter`, the generated site HTML, simulation core, and historical campaign results are unchanged from v5. Changes to the backend core outside API/hardware/telemetry are version metadata only.
- Regenerating schemas and HTML produces no differences.
- **14/14 fresh-install release checks passed on macOS**, using the actual delivered ZIP in a new temporary directory and a new environment installed from the lock file. These include startup, advanced run, exact reproduction, persisted sweep restart, cancellation and dataset integrity, synthetic telemetry, mixed provenance, telemetry restart, runner path handling, backup/restore, and stop.
- **32/32 sampled historical campaign rows reproduce within the existing tolerance**, with unchanged outcomes and configuration hashes. None are bit-identical across platforms. Maximum relative difference: `3.652067526791042e-6`, below `2e-5`. The complete 1,668-row campaign was not rerun.

Evidence: [archive check](aeris-v5.1-review-evidence/archive-bundle-check.json), [source integrity](aeris-v5.1-review-evidence/source-integrity.json), [diff and drift](aeris-v5.1-review-evidence/diff-and-drift.json), [Mac release validation](aeris-v5.1-review-evidence/release-validation-macos.json), [campaign sample](aeris-v5.1-review-evidence/campaign-verification.json).

## Exact independent test results

| Suite | Passed | Failed | Skipped |
|---|---:|---:|---:|
| Backend | 390 | 0 | 1 |
| JavaScript, all 11 suites | 181 | 0 | 0 |
| Live adapter/backend integration | 14 | 0 | 0 |
| Original browser suite | 50 | 0 | 0 |
| v3 browser suite | 48 | 1 | 0 |
| v4 browser suite | 24 | 0 | 0 |
| v5 browser suite | 36 | 0 | 0 |
| v5.1 browser suite | 12 | 0 | 0 |
| **Full run: 757 tests, all 18 suites executed** | **755** | **1** | **1** |

The sole skip is the Linux `/proc` orphan-worker test; its new portable `ps` counterpart **passed on macOS**. The sole failure is G4 below. An isolated rerun of v3 passed **49/49**. This rerun does not replace the original full-run result or justify calling it 757/757.

The three COM checks all passed in both runs. The new v5.1 browser tests exercised a real backend process restart with two browser tabs, one WebSocket and one forced polling. Both adopted the new stream, cleared stale displays, received a 12-frame 5 Hz replay, and continued receiving live synthetic frames. First replay frames arrived in 108 ms and 221 ms respectively in the full run.

Environment: macOS 26.6.2 arm64; Python 3.12.14; NumPy 2.5.3; SciPy 1.18.1; FastAPI 0.141.1; Pydantic 2.13.5; pytest 9.1.1; Node 26.9.0; Playwright 1.63.0 with Chromium. This differs from Claude's Linux/Node 22/Playwright 1.56 environment. The shared review Python environment was explicitly directed to the v5.1 backend; its imported source path and versions were recorded. Fresh-install validation used a separate fresh environment.

Evidence: [full summary](aeris-v5.1-review-evidence/full-tests/SUMMARY.md), [isolated rerun](aeris-v5.1-review-evidence/browser-v3-recheck/SUMMARY.md), [environment](aeris-v5.1-review-evidence/environment.json). An earlier sandbox-blocked attempt could not bind loopback or inspect processes and was stopped; its partial logs are retained separately and are not included in these counts.

## Remaining findings

### G1 — P1: Imported units are silently changed by NDJSON export

[telemetry/stream.py:469](/Users/nishchaysingh/aeris_cube/aeris-v5.1/backend/aeris_backend/telemetry/stream.py:469) copies raw sample values into the fixed-unit wire format without consulting `samples.units`. The import validator explicitly accepts milliseconds, degrees, degrees/second, and other convertible units, so this affects valid accepted inputs.

A synthetic fixture imported through the actual API returns HTTP 201, and NDJSON export returns HTTP 200. Its second sample is exported as:

| Signal | Imported value | Required wire value | Actual wire value |
|---|---|---|---|
| Time | 100 ms | 0.1 s | 100 s |
| Tilt | 11 degrees | 0.1919862177 rad | 11 rad |
| Body rate x | 180 degrees/s | 3.1415926536 rad/s | 180 rad/s |

The hub accepts this export and re-records it with seconds/radians labels. Replay timing, pose and any subsequent analysis of that copy are wrong. Native recorder outputs already use the wire units and are unaffected. This defect is **also present in v5**, verified against the old source with a valid sequence column; it was not introduced by the v5.1 fixes.

**Required correction:** normalize every recognized exported signal to the wire contract before constructing frames, including wheel speed conversion to rpm. Preserve the original stored document. Explicitly handle partial vector columns and unsupported mappings instead of silently changing units. Test API import → export → replay → re-record for every supported unit family and compare physical values, timing, and provenance with the original. Document that existing faulty exported copies must be regenerated from original JSON recordings.

Evidence: [independent probe](aeris-v5.1-review-evidence/edge_case_probes.py), [actual and expected values](aeris-v5.1-review-evidence/edge-case-probes.json), [v5 baseline](aeris-v5.1-review-evidence/unit-export-v5-baseline.json).

### G2 — P2: Repeated replay/export eventually creates an invalid hello

[telemetry/lineage.py:117](/Users/nishchaysingh/aeris_cube/aeris-v5.1/backend/aeris_backend/telemetry/lineage.py:117) takes the last four lineage objects, but each object contains its own full nested ancestry. Limiting the number of objects does not bound the size of those trees. A replay records every source segment's lineage, then the next export nests those objects again.

A two-segment mixed synthetic fixture succeeds for four export/re-record generations. The fifth export creates lineage objects of **9,697 and 9,687 characters** as measured by the protocol's JSON size check, above its 8,192 limit. `validate_hello` rejects both; the actual hub returns `rejected:invalid_hello`. Each input document was valid and synthetic. This is a new v5.1 export/replay regression; the ordinary two-generation tests do not reach it.

**Required correction:** flatten and deduplicate bounded ancestor references, retaining conservative synthetic/unknown/derived status separately from descriptive history. Validate every generated hello before returning an export. Test many replay generations, multiple reconnect segments, and near-limit input ancestry. Do not solve it by dropping the synthetic flag, raising trust, or merely increasing the maximum size.

Evidence: [generation results and actual hub rejection](aeris-v5.1-review-evidence/edge-case-probes.json). The original F1 mixed-source trust-loss defect is fixed for the tested ordinary paths; this finding concerns export validity after repeated copying.

### G3 — P2: Skipped test cases can still produce `full_validation: true`

[scripts/run_tests.py:200](/Users/nishchaysingh/aeris_cube/aeris-v5.1/scripts/run_tests.py:200) marks a suite passed when its failure and not-run counts are zero, even if cases were skipped. [Lines 289–291](/Users/nishchaysingh/aeris_cube/aeris-v5.1/scripts/run_tests.py:289) then compute completeness from suite-level exclusions only. A controlled fixture using the unchanged runner, a real pytest pass and a real pytest skip produced exit 0, `complete: true`, `all_passed: true`, and `full_validation: true` while explicitly reporting one skipped case.

The fixture's tiny JavaScript companion exists only to satisfy the runner's discovery layout; these fixture counts are **not product test counts**. The full product run has a failure, so its own full-validation flag is correctly false. This probe shows the remaining reporting error when the other tests pass.

**Required correction:** distinguish “all applicable tests passed” from complete execution. Any skipped/not-run case must prevent an unqualified full-validation claim, or a documented explicit platform-exclusion policy must enumerate the exclusions in the verdict. Preserve exact counts and test an all-skipped backend as well as mixed pass/skip cases. Missing executables, explicit skipped suites and selected-only suites are already handled substantially better in v5.1.

Evidence: [fixture output](aeris-v5.1-review-evidence/runner-skip-probe/skipped-case-output.log), [fixture JSON](aeris-v5.1-review-evidence/runner-skip-probe/skipped-case-logs/summary.json).

### G4 — P2: Browser cancellation assertion depends on a 300 ms race

[site/tests/browser_v3.py:217](/Users/nishchaysingh/aeris_cube/aeris-v5.1/site/tests/browser_v3.py:217) waits 300 ms after starting a 390-row browser sweep, clicks Cancel, and requires fewer than 390 rows with state `cancelled`. In the full Mac run it saw `complete`, 390 rows, and `partial: false`. The isolated rerun passed 49/49, confirming that the test outcome varies.

A focused real-browser probe found all 390 rows already computed by the timer check. A second scenario subscribed to progress and clicked the actual Cancel button while the job was still running with work remaining: it finished `cancelled`, **66/390 rows**, `partial: true`. This is evidence that cancellation during execution works; it does not establish all possible cancellation races or cancellation during analysis. The previously fixed COM check passed.

**Required correction:** deterministically exercise cancellation while the real job has progress and work remaining, with a bounded wait for the terminal state. Keep separate tests for cancellation before execution, during execution, and after completion; handle the analyzing state explicitly if it is intended to be cancellable. Do not merely lengthen a sleep or accept completed jobs as proof of successful cancellation.

Evidence: [original failure](aeris-v5.1-review-evidence/full-tests/browser-browser_v3.log), [isolated passing rerun](aeris-v5.1-review-evidence/browser-v3-recheck/browser-browser_v3.log), [focused browser probe](aeris-v5.1-review-evidence/cancel_probe.py), [captured states](aeris-v5.1-review-evidence/cancel-probe.json).

## Status of the previous five findings

| Previous finding | Independent v5.1 result |
|---|---|
| F1 mixed-source synthetic provenance | Original trust-loss path fixed in tested API, export, replay, dataset and browser scenarios. G2 is a new repeated-copy size defect. |
| F2 telemetry freezes after backend restart | Fixed in real-process live integration and two-tab browser tests, including forced polling and short low-rate replay. |
| F3 relative browser interpreter path | Fixed; fresh-install validator, runner tests and source/workflow review confirm resolution before changing directories. G3 remains in verdict reporting. Hosted CI still unexecuted. |
| F4 cross-platform exactness assertion | Fixed without widening the documented tolerance; backend reproduction tests and 32 sampled campaign reruns pass on Mac. |
| F5 COM browser timing | Fixed; 4 mm, 5 mm, replay/setup, and zero checks pass. G4 is a separate older cancellation-test race. |

## What is left

The next software release should address G1–G4, add the regression cases described above, rerun the full suites, validate the newly packaged ZIP, and keep its bundle/checksum/report consistent. This is a focused correction pass rather than another backend architecture project. The current package supports local simulation and exploratory research, but its telemetry export paths should be corrected before relying on imported recordings and derived copies.

Hosted CI, Windows/non-Chromium coverage if those platforms are required, long-duration reliability tests, and remote/multi-user deployment remain unverified. Remote hosting is outside the declared local-workstation scope, so its absence alone is not an unfinished local backend.

The later hardware stage still requires firmware/device mapping, axis and sign checks, time/latency characterization, measured mass/COM/inertia and actuator/sensor parameters, real recordings, and predeclared validation experiments. Passing software tests cannot complete those physical validation steps. No hardware or research measurement has been fabricated by this review.

## Reproduction and evidence

The compact machine-readable review is [aeris-v5.1-review-evidence.json](aeris-v5.1-review-evidence.json). The review pack includes that file, this report, actual logs, and independent probes. Product tests and focused review probes are reported separately.

The unchanged package was tested using `scripts/run_tests.py` with explicit absolute backend/browser interpreter paths and an output directory outside the release. The unit and repeated-lineage probe accepts the repository path and output JSON path as arguments; `cancel_probe.py` does likewise. Both generate artificial data only. The source checksum comparison after testing found **zero changed archive files**.

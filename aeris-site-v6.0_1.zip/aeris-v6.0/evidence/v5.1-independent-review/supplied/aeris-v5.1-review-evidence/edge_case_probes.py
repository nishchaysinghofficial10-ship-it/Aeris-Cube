"""Independent synthetic-only v5.1 review probes. Usage: python this.py REPO OUTPUT."""
import json
import math
import sys
import tempfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / 'backend'))
from aeris_backend.telemetry.stream import TelemetryHub, recording_to_ndjson
from aeris_backend.telemetry.protocol import hello_message, validate_hello
from aeris_backend.hardware.ingest import validate_recording


def frame(h, seq, t, now):
    assert h.feed_message({'type': 'frame', 'seq': seq, 't': t,
                           'q': [1, 0, 0, 0], 'w': [0, 0, 0]}, now) == 'frame'


def original():
    h = TelemetryHub()
    for j, (kind, syn) in enumerate([('physical', False), ('emulator', True)]):
        h.on_connect({'kind': 'tcp', 'address': 'artificial-fixture'}, j)
        assert h.feed_message(hello_message('fixture-' + kind, kind, 'test-only', syn, 'corner', 100), j) == 'hello'
        if j == 0:
            h.start_recording('Artificial mixed-source fixture; no hardware', 0)
        for i in range(3):
            frame(h, i, i * .01, j + i * .01)
        h.on_disconnect('fixture source change', j + .5)
    return h.stop_recording(3)


doc = original()
generations = []
for gen in range(1, 9):
    nd = recording_to_ndjson(doc, f'fixture-generation-{gen}')
    messages = [json.loads(x) for x in nd.splitlines()]
    hellos = [m for m in messages if m['type'] == 'hello']
    validations = [validate_hello(h) for h in hellos]
    hub = TelemetryHub()
    hub.on_connect({'kind': 'file', 'address': 'synthetic-review-export.ndjson'}, 10)
    first = hub.feed_message(messages[0], 10)
    item = {'generation': gen, 'lineage_json_lengths': [len(json.dumps(h['lineage'])) for h in hellos],
            'validation_errors': [v['errors'] for v in validations], 'first_replay_result': first,
            'input_document_valid': validate_recording(doc)['ok'], 'input_synthetic': doc['synthetic']}
    generations.append(item)
    if first != 'hello':
        break
    hub.start_recording('synthetic review replay', 10)
    for m in messages[1:]:
        result = hub.feed_message(m, 11)
        assert not result.startswith('rejected'), result
    doc = hub.stop_recording(12)

# A valid imported recording may use non-SI units; NDJSON requires fixed wire units.
units_doc = {'schema': 'aeris-hardware-run/1', 'synthetic': True,
             'device': {'id': 'unit-fixture', 'firmware': 'test-only'},
             'recording': {'started': '2026-10-01T00:00:00Z', 'notes': 'Artificial unit fixture'},
             'mode': 'edge', 'samples': {'rate_hz': 10,
                 'cols': {'t': [0, 100, 200], 'theta': [10, 11, 12],
                          'w_x': [180]*3, 'w_y': [0]*3, 'w_z': [0]*3},
                 'units': {'t': 'ms', 'theta': 'deg', 'w_x': 'deg/s', 'w_y': 'deg/s', 'w_z': 'deg/s'}}}
v = validate_recording(units_doc)
assert v['ok'], v
exported = [json.loads(x) for x in recording_to_ndjson(units_doc).splitlines()]
wire = [x for x in exported if x['type'] == 'frame']
hub = TelemetryHub()
hub.on_connect({'kind': 'file', 'address': 'synthetic-units.ndjson'}, 0)
assert hub.feed_message(exported[0], 0) == 'hello'
hub.start_recording('synthetic unit replay', 0)
for m in exported[1:]:
    assert not hub.feed_message(m, 1).startswith('rejected')
rerecorded = hub.stop_recording(2)
from fastapi.testclient import TestClient
from aeris_backend.api.app import create_app
with tempfile.TemporaryDirectory(prefix='aeris-review-unit-') as tmp:
    with TestClient(create_app({'db': str(Path(tmp) / 'a.sqlite3'), 'workers': 1,
                               'telemetry_dir': str(Path(tmp) / 'telemetry')})) as client:
        imported = client.post('/api/v1/hardware/recordings', json=units_doc)
        assert imported.status_code == 201, imported.text
        rid = imported.json()['id']
        response = client.get(f'/api/v1/hardware/recordings/{rid}/export?format=ndjson')
        assert response.status_code == 200, response.text
        api_frames = [json.loads(x) for x in response.text.splitlines() if json.loads(x)['type'] == 'frame']
        assert api_frames == wire
        api_statuses = {'import': imported.status_code, 'export': response.status_code,
                        'export_matches_direct_probe': api_frames == wire}
result = {'replay_generations': generations,
          'unit_export': {'input_valid': v['ok'], 'api_statuses': api_statuses, 'input_units': units_doc['samples']['units'],
                          'wire_frame_1': wire[1],
                          'expected_wire_frame_1': {'t': .1, 'theta': 11 * math.pi / 180, 'w': [math.pi, 0, 0]},
                          'rerecorded_units': rerecorded['samples']['units'],
                          'rerecorded_t': rerecorded['samples']['cols']['t'],
                          'rerecorded_theta': rerecorded['samples']['cols']['theta']}}
Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

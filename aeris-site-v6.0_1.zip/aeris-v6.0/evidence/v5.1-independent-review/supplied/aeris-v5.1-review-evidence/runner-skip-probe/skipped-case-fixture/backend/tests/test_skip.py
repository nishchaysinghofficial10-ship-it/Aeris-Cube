import pytest
def test_ok():
    assert True
@pytest.mark.skip(reason="controlled review skip")
def test_skipped():
    assert False

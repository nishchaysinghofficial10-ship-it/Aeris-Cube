#!/usr/bin/env python3
"""Run the AERIS test suites and write logs with exact counts.

    python3 scripts/run_tests.py [--out test-logs] [--only SUITES] [--skip SUITES]
                                 [--backend-python P] [--browser-python P] [--node N]

Suites (each is run for real; nothing is mocked here):
  backend        pytest, backend/tests (numerical, engine, API, persistence, recovery, telemetry)   — the backend Python
  js:<name>      node site/tests/<name>.test.js (schemas, numerics, platform, runs, service, ui, v4, v5, v51, …)
  live           node site/tests/live_backend.test.js: the site's real adapters against a started backend
  browser:<name> site/tests/browser_*.py (Playwright + Chromium)                                     — the browser Python
SUITES is a comma-separated list of suite names or of the groups backend, js, live, browser.

Interpreters (v5.1, review finding F3). An interpreter chosen explicitly — --backend-python or $AERIS_PYTHON,
--browser-python or $PLAYWRIGHT_PYTHON, --node — is resolved ONCE, before any suite runs in another working
directory: a path (anything with a directory separator, or starting with . or ~) is made absolute against the
directory the runner was started from, keeping symlinks (a virtual environment's python is a link to its base
interpreter; resolving the link would leave the environment); a bare name (python3) is looked up on PATH. An explicit
interpreter is never replaced by another one: if it does not exist, cannot be started or — for the browser suites —
has no Playwright, the suites that need it are NOT RUN with that reason. Without an explicit choice the defaults are
searched (backend/.venv, then the interpreter running this script) and the choice is recorded in the summary.

Every suite in scope ends in one status:
  passed    it ran, exited 0 and reported counts with no failure and nothing not run
  failed    it ran and reported a failure, exited non-zero, timed out or reported no counts
  not run   it could not run: a missing tool or interpreter, a process that could not be started, or a backend
            the suite could not start (the suite itself reports NOT RUN)
  skipped   excluded with --skip
Suites outside --only are listed as not selected. Writes <out>/<suite>.log, <out>/summary.json (machine-readable)
and <out>/SUMMARY.md, which starts with the verdict. A run in which anything was not run, skipped or not selected is
never reported as a full validation.
Exit code: 0 when every selected suite ran and passed; 1 when a suite failed; 2 when nothing failed but a selected
suite was not run or skipped (the run is INCOMPLETE); 64 for a usage error (e.g. an unknown suite name).
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# Suites are discovered from the files present, so the script also runs an older package's own suites.
JS = sorted(p.name[:-len(".test.js")] for p in (ROOT / "site" / "tests").glob("*.test.js") if p.name != "live_backend.test.js")
BROWSER = sorted(p.stem for p in (ROOT / "site" / "tests").glob("browser_*.py"))
ALL = ["backend"] + [f"js:{n}" for n in JS] + ["live"] + [f"browser:{n}" for n in BROWSER]
GROUPS = {"backend": ["backend"], "js": [f"js:{n}" for n in JS], "live": ["live"], "browser": [f"browser:{n}" for n in BROWSER]}
USAGE_ERROR = 64


def expand(spec: str) -> list:
    """'backend,js:v5,browser' → suite names, in the order of ALL. Unknown names are an error, never ignored."""
    want = []
    for s in (x.strip() for x in (spec or "").split(",")):
        if not s:
            continue
        if s in GROUPS:
            want += GROUPS[s]
        elif s in ALL:
            want.append(s)
        else:
            raise ValueError(f"unknown suite '{s}' (suites: {', '.join(ALL)}; groups: {', '.join(GROUPS)})")
    return [s for s in ALL if s in set(want)]


def is_path(v: str) -> bool:
    return os.sep in v or bool(os.altsep and os.altsep in v) or v.startswith(".") or v.startswith("~")


def resolve_program(value, start_dir: str):
    """(absolute path, None) or (None, reason). A path is made absolute against start_dir (the runner's working
    directory when it started) WITHOUT resolving symlinks; a bare name is looked up on PATH."""
    raw = str(value)
    v = os.path.expanduser(raw)
    if is_path(v):
        p = os.path.abspath(os.path.join(start_dir, v))
        if not os.path.lexists(p):
            return None, f"'{raw}' → {p}: no such file"
        if not os.path.exists(p):
            return None, f"'{raw}' → {p}: a broken link"
        if os.path.isdir(p) or not os.access(p, os.X_OK):
            return None, f"'{raw}' → {p}: not an executable file"
        return p, None
    w = shutil.which(v)
    if not w:
        return None, f"'{raw}': not found on PATH"
    return os.path.abspath(w), None


def probe(cmd, timeout=120):
    """Start a program once to see that it runs: (True, stdout) or (False, reason)."""
    try:
        r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return False, f"did not answer within {timeout} s"
    except (OSError, ValueError) as e:
        return False, f"could not be started: {e.__class__.__name__}: {e}"
    if r.returncode != 0:
        tail = (r.stderr or r.stdout or "").strip().splitlines()
        return False, (tail[-1] if tail else f"exit code {r.returncode}")[:300]
    return True, r.stdout.strip()


def choose_backend_python(given, start):
    explicit = [(given, "--backend-python"), (os.environ.get("AERIS_PYTHON"), "$AERIS_PYTHON")]
    for raw, source in explicit:
        if raw:
            p, why = resolve_program(raw, start)
            if p:
                ok, out = probe([p, "-c", "import sys; print(sys.version.split()[0])"])
                if not ok:
                    p, why = None, f"'{raw}' → {p}: {out}"
            return {"path": p, "source": source, "given": raw, "problem": why}
    for c, source in ((ROOT / "backend" / ".venv" / "bin" / "python", "default: backend/.venv"), (ROOT / "backend" / ".venv" / "Scripts" / "python.exe", "default: backend/.venv")):
        if c.exists():
            return {"path": str(c), "source": source, "given": None, "problem": None}
    return {"path": sys.executable, "source": "default: the interpreter running this script", "given": None, "problem": None}


def choose_browser_python(given, start, backend_py):
    for raw, source in ((given, "--browser-python"), (os.environ.get("PLAYWRIGHT_PYTHON"), "$PLAYWRIGHT_PYTHON")):
        if raw:
            p, why = resolve_program(raw, start)
            if p:
                ok, out = probe([p, "-c", "import playwright"])
                if not ok:
                    why = f"'{raw}' → {p}: Playwright is not importable ({out}); install it for this interpreter (pip install playwright; python -m playwright install chromium)"
                    p = None
            return {"path": p, "source": source, "given": raw, "problem": why}
    tried = []
    for c, source in ((backend_py, "default: the backend Python"), (sys.executable, "default: the interpreter running this script"), (shutil.which("python3"), "default: python3 on PATH")):
        if not c or c in tried:
            continue
        tried.append(c)
        if probe([c, "-c", "import playwright"])[0]:
            return {"path": c, "source": source, "given": None, "problem": None}
    return {"path": None, "source": "default", "given": None,
            "problem": "Playwright is not installed for any Python found (" + ", ".join(tried) + "): pip install playwright; python -m playwright install chromium"}


def choose_node(given, start):
    if given:
        p, why = resolve_program(given, start)
        if p:
            ok, out = probe([p, "-v"])
            if not ok:
                p, why = None, f"'{given}' → {p}: {out}"
        return {"path": p, "source": "--node", "given": given, "problem": why}
    w = shutil.which("node")
    return {"path": os.path.abspath(w) if w else None, "source": "default: node on PATH", "given": None, "problem": None if w else "Node.js not found on PATH"}


def run(cmd, log, cwd, env=None, timeout=3600):
    """Run one suite with its output in `log`. Returns (exit code or None, seconds, log text, launch problem or None)."""
    t0 = time.time()
    with open(log, "w", encoding="utf-8") as fh:
        fh.write("$ " + " ".join(shlex.quote(str(c)) for c in cmd) + f"\n(working directory: {cwd})\n\n")
        fh.flush()
        launch = None
        try:
            p = subprocess.run([str(c) for c in cmd], cwd=cwd, env=env, stdout=fh, stderr=subprocess.STDOUT, timeout=timeout)
            code = p.returncode
        except subprocess.TimeoutExpired:
            fh.write(f"\nTIMEOUT after {timeout} s\n")
            code = -9
        except (OSError, ValueError) as e:
            launch = f"could not be started: {e.__class__.__name__}: {e}"
            fh.write("\nNOT RUN: " + launch + "\n")
            code = None
    return code, round(time.time() - t0, 1), Path(log).read_text(encoding="utf-8", errors="replace"), launch


def counts_js(text):
    m = re.findall(r"^(\d+) / (\d+) [^\n]*?(passed|run)", text, re.M)
    if not m:
        return None
    n, tot, word = m[-1]
    n, tot = int(n), int(tot)
    nr = re.search(r"\((\d+) not run\)", text)
    if word == "run" and nr:
        return {"passed": 0, "failed": 0, "skipped": 0, "not_run": int(nr.group(1)), "total": tot}
    return {"passed": n, "failed": tot - n, "skipped": 0, "not_run": 0, "total": tot}


def status_of(code, counts, launch, text):
    if launch:
        return "not run", launch
    if code == 2 and ("NOT RUN" in text or (counts and counts.get("not_run"))):
        line = next((ln for ln in text.splitlines() if "NOT RUN" in ln), "the suite reported NOT RUN")
        return "not run", line.strip()[:300]
    if code == 0 and counts and counts["failed"] == 0 and counts.get("not_run", 0) == 0 and counts.get("total", 0) > 0:
        return "passed", None
    if code == -9:
        return "failed", "timed out"
    if not counts:
        return "failed", f"exit code {code}; no counts reported"
    if not counts.get("total"):
        return "failed", f"exit code {code}; the suite counted no tests"
    if counts.get("not_run"):
        return "not run" if not counts["failed"] and not counts["passed"] else "failed", f"{counts['not_run']} test(s) not run (exit code {code})"
    return "failed", None if counts["failed"] else f"exit code {code}"


def main(argv=None):
    start = os.getcwd()          # every path given to the runner is relative to where it was started
    ap = argparse.ArgumentParser(description="Run the AERIS test suites (see the module docstring).")
    ap.add_argument("--out", default=str(ROOT / "test-logs"))
    ap.add_argument("--only", default="", help="comma-separated suites or groups to run (default: all)")
    ap.add_argument("--skip", default="", help="comma-separated suites or groups to exclude (the run is then INCOMPLETE)")
    ap.add_argument("--backend-python")
    ap.add_argument("--browser-python")
    ap.add_argument("--node")
    a = ap.parse_args(argv)
    try:
        selected = expand(a.only) if a.only.strip() else list(ALL)
        skip = set(expand(a.skip))
    except ValueError as e:
        print("usage error: " + str(e), file=sys.stderr)
        return USAGE_ERROR
    out = Path(os.path.abspath(os.path.join(start, a.out)))       # absolute: suites run in other working directories
    out.mkdir(parents=True, exist_ok=True)
    need = set(selected) - skip
    bpy = choose_backend_python(a.backend_python, start) if need & ({"backend", "live"} | set(GROUPS["browser"])) else None
    node = choose_node(a.node, start) if need & (set(GROUPS["js"]) | {"live"}) else None
    brpy = choose_browser_python(a.browser_python, start, bpy and bpy["path"]) if need & set(GROUPS["browser"]) else None
    env = dict(os.environ, PYTHONUNBUFFERED="1")
    if bpy and bpy["path"]:
        env["AERIS_PYTHON"] = bpy["path"]
    suites = []

    def record(name, status, code=None, secs=0.0, counts=None, reason=None, log=None):
        suites.append({"suite": name, "status": status, "exit_code": code, "seconds": secs, "counts": counts, "log": log, "reason": reason})
        c = counts or {}
        print(f"{name:22s} {status:8s} passed {c.get('passed', 0):4d} failed {c.get('failed', 0):3d} skipped {c.get('skipped', 0):3d} not run {c.get('not_run', 0):3d}  ({secs} s)"
              + (f"  — {reason}" if reason else ""), flush=True)

    def suite(name, cmd, cwd, needs):
        log = f"{name.replace(':', '-')}.log"
        if name in skip:
            return record(name, "skipped", reason="excluded with --skip")
        for what, choice in needs:
            if not choice or not choice["path"]:
                return record(name, "not run", reason=f"{what}: " + ((choice or {}).get("problem") or "not available"))
        code, secs, text, launch = run(cmd(), out / log, cwd, env)
        counts = None
        if name == "backend":
            junit = out / "pytest-junit.xml"
            if junit.exists() and junit.stat().st_mtime >= time.time() - secs - 5:
                ts = ET.parse(junit).getroot()
                ts = ts if ts.tag == "testsuite" else ts.find("testsuite")
                tot, fl, er, sk = (int(ts.get(k, 0)) for k in ("tests", "failures", "errors", "skipped"))
                counts = {"passed": tot - fl - er - sk, "failed": fl + er, "skipped": sk, "not_run": 0, "total": tot}
        else:
            counts = counts_js(text)
        status, reason = status_of(code, counts, launch, text)
        if name == "backend" and status == "passed" and counts and counts["skipped"]:
            reason = f"{counts['skipped']} test(s) skipped inside the suite (see the log)"
        record(name, status, code, secs, counts, reason, log)

    for name in selected:
        if name == "backend":
            junit = out / "pytest-junit.xml"
            if junit.exists() and "backend" not in skip:
                junit.unlink()
            suite(name, lambda: [bpy["path"], "-m", "pytest", "-q", "-p", "no:cacheprovider", f"--junitxml={out / 'pytest-junit.xml'}"], ROOT / "backend", [("backend Python", bpy)])
        elif name.startswith("js:"):
            n = name[3:]
            suite(name, lambda n=n: [node["path"], f"tests/{n}.test.js"], ROOT / "site", [("Node.js", node)])
        elif name == "live":
            suite(name, lambda: [node["path"], "tests/live_backend.test.js"], ROOT / "site", [("Node.js", node), ("backend Python", bpy)])
        else:
            n = name[len("browser:"):]
            suite(name, lambda n=n: [brpy["path"], f"tests/{n}.py"], ROOT / "site", [("backend Python", bpy), ("browser Python", brpy)])

    not_selected = [s for s in ALL if s not in selected]
    total = {k: sum((s["counts"] or {}).get(k, 0) for s in suites) for k in ("passed", "failed", "skipped", "not_run")}
    failed = [s["suite"] for s in suites if s["status"] == "failed"]
    notrun = [s["suite"] for s in suites if s["status"] == "not run"]
    skipped = [s["suite"] for s in suites if s["status"] == "skipped"]
    complete = bool(suites) and not notrun and not skipped
    all_passed = complete and not failed and all(s["status"] == "passed" for s in suites)
    full = all_passed and not not_selected
    if failed:
        verdict = f"FAILED — {len(failed)} suite(s) failed: {', '.join(failed)}" + (f"; also {len(notrun)} not run, {len(skipped)} skipped" if notrun or skipped else "")
    elif not complete:
        ran = len(suites) - len(notrun) - len(skipped)
        verdict = (f"INCOMPLETE — {len(notrun)} suite(s) not run" + (f" ({', '.join(notrun)})" if notrun else "") + f", {len(skipped)} skipped"
                   + (f" ({', '.join(skipped)})" if skipped else "") + (f"; the {ran} suite(s) that ran passed" if ran else "; no suite ran") + ". Not a full validation.")
    elif not_selected:
        verdict = f"PASSED — selected suites only ({len(suites)} of {len(ALL)}); not selected: {', '.join(not_selected)}. Not a full validation."
    else:
        verdict = f"PASSED — all {len(suites)} suites ran and passed"
    code = 1 if failed else 2 if not complete else 0
    interp = {"backend_python": bpy, "browser_python": brpy, "node": node}
    summary = {"when": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"), "verdict": verdict, "exit_code": code,
               "complete": complete, "all_passed": all_passed, "full_validation": full,
               "machine": {"platform": platform.platform(), "python_orchestrator": sys.version.split()[0]},
               "runner": {"started_in": start, "argv": list(sys.argv[1:] if argv is None else argv)},
               "backend_python": bpy and bpy["path"], "node": (subprocess.run([node["path"], "-v"], capture_output=True, text=True).stdout.strip() if node and node["path"] else None),
               "interpreters": interp, "selected": selected, "not_selected": not_selected,
               "suites": suites, "totals": total,
               "suite_status_counts": {k: sum(1 for s in suites if s["status"] == k) for k in ("passed", "failed", "not run", "skipped")}}
    (out / "summary.json").write_text(json.dumps(summary, indent=1))
    md = [f"# Test run — {verdict}", "",
          f"{summary['when']} · {summary['machine']['platform']} · backend Python `{summary['backend_python']}` · Node {summary['node']}", ""]
    for k, v in interp.items():
        if v:
            md.append(f"- {k.replace('_', ' ')}: `{v['path']}` ({v['source']}" + (f", given as `{v['given']}`" if v.get("given") else "") + ")" + (f" — **{v['problem']}**" if v.get("problem") else ""))
    md += ["", "| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |", "|---|---|---:|---:|---:|---:|---:|---|"]
    for s in suites:
        c = s["counts"] or {}
        md.append(f"| {s['suite']} | {s['status']}{(' — ' + s['reason']) if s['reason'] else ''} | {c.get('passed', 0)} | {c.get('failed', 0)} | {c.get('skipped', 0)} | {c.get('not_run', 0)} | {s['seconds']} | {s['log'] or '—'} |")
    for n in not_selected:
        md.append(f"| {n} | not selected | — | — | — | — | — | — |")
    md += ["", f"**Totals (tests in the suites that ran):** {total['passed']} passed, {total['failed']} failed, {total['skipped']} skipped, {total['not_run']} not run.",
           f"**Suites:** {summary['suite_status_counts']['passed']} passed, {len(failed)} failed, {len(notrun)} not run, {len(skipped)} skipped, {len(not_selected)} not selected.",
           f"**Full validation:** {'yes' if full else 'no'} (exit code {code})."]
    (out / "SUMMARY.md").write_text("\n".join(md) + "\n")
    print(f"\n{verdict}\ntotals: {total}  → {out / 'summary.json'}")
    return code


if __name__ == "__main__":
    sys.exit(main())

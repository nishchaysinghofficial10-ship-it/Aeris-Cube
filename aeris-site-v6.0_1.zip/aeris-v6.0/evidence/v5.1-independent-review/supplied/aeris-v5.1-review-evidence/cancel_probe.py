"""Real browser sweep cancellation: timer-based test versus state-triggered cancellation."""
import asyncio
import json
import sys
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
SETUP = """(() => {
 const d=AERIS_SWEEP_UI._state.def;
 d.mode='grid'; d.variables=[{key:'tilt_deg',min:-6,max:6,steps:13},{key:'rate_dps',min:-60,max:60,steps:10}];
 d.duration_s=10; d.controllers=['pid','lqr','adp']; d.mass_configs=['base'];
 document.getElementById('swRun').click();
 return {state:AERIS_SWEEP_UI._state.job.state, progress:AERIS_SWEEP_UI._state.job.progress};
})()"""
STATE = """(() => {const s=AERIS_SWEEP_UI._state;return {state:s.job.state,progress:s.job.progress,
rows:s.result && s.result.rows.length,partial:s.result && s.result.partial,cancelHidden:document.getElementById('swCancel').hidden};})()"""

async def main():
    results = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
        for kind in ['timer-300ms', 'cancel-at-progress']:
            page = await browser.new_page(viewport={'width':1440,'height':900})
            await page.goto((ROOT/'site/index.html').as_uri()+'#lab/sweep',wait_until='load')
            await page.wait_for_function("typeof AERIS_SWEEP_UI !== 'undefined' && !!document.getElementById('swRun')")
            await page.click('[data-preset="sat"]')
            await page.wait_for_timeout(300)
            started = await page.evaluate(SETUP)
            if kind == 'cancel-at-progress':
                await page.evaluate("""(() => {const job=AERIS_SWEEP_UI._state.job; window.reviewCancel=null;
                  AERIS_JOBS.subscribe(job,j=>{if(j.state==='running' && j.progress.done>0 && j.progress.done<j.progress.total && !window.reviewCancel){
                    window.reviewCancel={state:j.state,done:j.progress.done,total:j.progress.total};
                    document.getElementById('swCancel').click();}});})()""")
                before = None
            else:
                await page.wait_for_timeout(300)
                before = await page.evaluate(STATE)
                await page.evaluate("document.getElementById('swCancel').click()")
            await page.wait_for_function("['complete','cancelled','failed'].includes(AERIS_SWEEP_UI._state.job.state)",timeout=30000)
            results.append({'mode':kind,'started':started,'before_timer_click':before,
                            'cancel_at':await page.evaluate('window.reviewCancel || null'),
                            'final':await page.evaluate(STATE)})
            await page.close()
        await browser.close()
    OUT.write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))

asyncio.run(main())

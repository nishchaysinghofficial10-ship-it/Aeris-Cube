# The independent review of v5.1 (supplied; not produced by this project's tooling)

`supplied/` is the review pack **as it was supplied** for the v5.2 work (`AERIS-v5.1-review-pack.zip`, SHA-256
`1a944b1c6b771ad72f2946dd31e0a564b3497b8247ff7949a1e849adf3be6c29`), unpacked unchanged: the report
(`AERIS-v5.1-review.md`), its machine-readable summary (`aeris-v5.1-review-evidence.json`) and the reviewer's probes,
logs and results (`aeris-v5.1-review-evidence/`). Absolute file links in the report point to the reviewer's Mac; their
repository-relative parts map onto this repository (for example `…/aeris-v5.1/backend/aeris_backend/telemetry/stream.py`
→ `backend/aeris_backend/telemetry/stream.py`).

These are the reviewer's results on macOS 26.6.2 arm64 (Python 3.12.14, Playwright 1.63.0, Node 26.9.0) for the
delivered v5.1 (tag `aeris-v5.1` = `f76d632efac6e4e0148fc69c3099651b146bdad1`, archive SHA-256
`c1e4138dedb3bb030e8aa14eb93cb196265eea2e5b18d2934dcfeb686c638ad4`): **755 passed, 1 failed, 1 skipped of 757** in the
full run (the failure: the browser_v3 sweep-cancellation check, G4; the skip: the Linux `/proc` orphan-worker test,
whose portable `ps` counterpart passed); an isolated rerun of browser_v3 passed 49/49, which does not replace the
full-run result; the fresh-install release validation passed 14/14; 32 sampled campaign rows reran within tolerance;
findings G1 (P1) and G2–G4 (P2). **Nothing in `supplied/` was executed by us**, and none of it describes v5.2. The
runner fixture under `runner-skip-probe/` is a summary test of the runner, not product or research evidence.

What we did with it (our own executions, separately): `evidence/v5.2-verification/` — every finding reproduced on the
unmodified v5.1 first (the reviewer's `edge_case_probes.py` and `cancel_probe.py` used with only their command-line
paths changed, the runner fixture as supplied), then fixed and re-checked on v5.2 with the same conditions.

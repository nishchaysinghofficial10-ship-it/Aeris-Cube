# Evidence

* **v6.0** — the four findings of the independent review of v5.2 (V52-1 … V52-4), reproduced on the unmodified v5.2
  and re-checked on v6.0, the firmware builds, the host timing of the control step and the numerical reproduction
  check: [`v6.0-verification/`](v6.0-verification/README.md). The specification and blueprint as supplied:
  [`v6.0-inputs/`](v6.0-inputs/README.md). The review of v5.2, as supplied and not executed by us except where
  `v6.0-verification/` says so: [`v5.2-independent-review/`](v5.2-independent-review/README.md). The v5.2 test run:
  `v5.2-release/test-logs/`. The release checks of the v6.0 archive: `v6.0-release/`.
* **v5.2** — the four findings of the independent review of v5.1 (G1–G4), reproduced on the unmodified v5.1 and
  re-checked on v5.2 with the same conditions: [`v5.2-verification/`](v5.2-verification/README.md) (probes, outputs for
  both versions, the runner fixture, repeated full-speed and throttled browser runs, the local execution of the CI
  steps, the numerical reproduction check). The review itself, as supplied and not executed by us:
  [`v5.1-independent-review/`](v5.1-independent-review/README.md). The v5.1 test run: `v5.1-release/test-logs/`.
* **v5.1** — the five findings of the independent review of v5, reproduced on the unmodified v5 and re-checked on
  v5.1 with the same failure conditions: [`v5.1-verification/`](v5.1-verification/README.md) (probes, outputs for both
  versions, negative controls, the local execution of the CI steps). The review itself, as supplied and not executed
  by us: [`v5-independent-review/`](v5-independent-review/README.md).
* **v5** — the v4 review findings, reproduced on v4 and re-run on v5 (below; unchanged since v5).

# Evidence: the v4 review findings, reproduced on v4 and re-run on v5

`v4-reproduction/` holds the review's own diagnostic scripts and their outputs on the **unchanged v4 package**
(`aeris-site-v4.zip`); `v5-verification/` the same scripts (adapted only where v5 now refuses the probed input)
and their outputs on v5. Regression tests in the suites cover each finding independently of these probes.

| Finding | v4 (reproduced) | v5 (same probe) | Regression tests |
|---|---|---|---|
| **A** research metrics: a constant 1° for 1 s | RMS 1.0, IAE **1.1** °·s, ISE **0.0192** °²·s (`review_probes.out`) | RMS 1.0, IAE 1.0, ISE 1.0 (`review_probes.v5.out`, `root-metrics-probes.v5.json`); old records keep version 1 and are never relabelled | `backend/tests/test_metrics.py`, `site/tests/v5.test.js` M1–M2 |
| **B** a single job persisted at ANALYZING, restart with `resume` | `TransitionError analyzing → running`, swallowed; the job stays ANALYZING and is re-dispatched forever (`restart_probe.out`) | recovery fails the job visibly once: `inconsistent_state`, terminal, never re-dispatched (`restart_probe.v5.out`; the probe's forced second execution is refused because terminal states never change) | `backend/tests/test_recovery.py`, `test_process_restart.py` (real SIGKILL/restart) |
| **C** estimator timing: MEKF at 100 Hz with 50 % dropout, controller at 500 Hz | **216** control intervals with a non-zero rate but a frozen attitude estimate | **0** (`estimator-staleness-probe.v5.json`): the controller gets the estimate predicted to the control time, with its age and validity | `backend/tests/test_estimator_timing.py` |
| **D** recording rate 60 Hz with 500 Hz integration | labelled 60 Hz, actually 62.5 Hz (samples every 8 steps) | refused with a `record_hz` error naming the nearest valid rates (55.5556 or 62.5 Hz); a divisor rate (50 Hz) records exactly 50 Hz plus the final state, with the schedule saved in the record | `backend/tests/test_recording.py`, `site/tests/v5.test.js` D1–D2 |
| **E** a pending setup preview overwrites a replay (DEMO, reduced motion) | viewer shows "SETUP PREVIEW", `viewerRunId null` (`replay_race_probe.v4.out`) | replay intact: viewer, tag and run agree after 0, 0.5 and 2 s (`replay_race_probe.v5.out`) | `site/tests/browser_v5.py` (edits 0–150 ms before opening a replay, in DEMO and with a stored SIMULATION run; 3-D view, telemetry, timeline, plots and record must agree), `site/tests/v5.test.js` E1; **negative control**: with the fix reverted in a temporary copy both race checks fail with the v4 symptom and no other check fails (`replay_race_negative_control.py` → `.out`) |

Found while completing v5 (not in the review):

| Finding | Before | After | Tests and control |
|---|---|---|---|
| worker processes of a killed backend keep running (orphans computing work nobody collects) | after SIGKILL of the server, its two workers and the multiprocessing helper were still running 15 s later | each worker exits within about 0.5 s of its backend process's death (POSIX) | `backend/tests/test_process_restart.py::test_worker_processes_exit_when_the_backend_process_is_killed`; **negative control**: `v5-verification/orphan_workers_negative_control.py` → `.out` (fails without the watch, passes with it) |

Run a probe (from `backend/`, with the backend's virtual environment):

```bash
../backend/.venv/bin/python ../evidence/v5-verification/review_probes_v5.py
../backend/.venv/bin/python ../evidence/v5-verification/restart_probe.py
python3 ../evidence/v4-reproduction/replay_race_probe.py ../site      # needs Playwright
cd .. && AERIS_PYTHON=backend/.venv/bin/python python3 evidence/v5-verification/replay_race_negative_control.py
backend/.venv/bin/python evidence/v5-verification/orphan_workers_negative_control.py
```

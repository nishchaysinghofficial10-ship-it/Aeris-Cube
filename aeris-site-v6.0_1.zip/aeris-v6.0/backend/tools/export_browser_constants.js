#!/usr/bin/env node
/* Export the browser engine's constants (AERIS_TWIN 0.3.0) to JSON so the Python backend
   uses exactly the same nominal parameters, ranges, assessment rules and definition texts.
   Run from the repository root:  node backend/tools/export_browser_constants.js  */
"use strict";
var path = require("path"), fs = require("fs");
global.window = {};
var TWIN = require(path.join(__dirname, "..", "..", "site", "js", "core.js"));
var out = {
  generated_from: "site/js/core.js", model: TWIN.VERSION.model, version: TWIN.VERSION,
  NOMINAL: TWIN.NOMINAL, PARAM_SPEC: TWIN.PARAM_SPEC, WEIGHTS: TWIN.WEIGHTS, SENSOR: TWIN.SENSOR,
  SENSOR_DEFAULTS: TWIN.SENSOR_DEFAULTS, SENSOR_SPEC: TWIN.SENSOR_SPEC, ACTUATOR_DEFAULTS: TWIN.ACTUATOR_DEFAULTS,
  ASSESS: TWIN.ASSESS, OUTCOMES: TWIN.OUTCOMES, METRIC_DEFS: TWIN.METRIC_DEFS, EVENT_RULES: TWIN.EVENT_RULES, EVENT_DEFS: TWIN.EVENT_DEFS,
  QEQ: TWIN.QEQ, E1: TWIN.E1, E2: TWIN.E2, CH: TWIN.CH, D_EDGE: TWIN.D_EDGE, N_EDGE: TWIN.N_EDGE
};
var dest = path.join(__dirname, "..", "aeris_backend", "data", "browser_constants.json");
fs.writeFileSync(dest, JSON.stringify(out, null, 1) + "\n");
console.log("wrote " + dest);

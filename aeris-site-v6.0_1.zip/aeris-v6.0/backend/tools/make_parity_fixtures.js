#!/usr/bin/env node
/* Generate browser-engine reference outputs (AERIS_TWIN 0.3.0) for the Python parity tests.
   Run from the repository root:  node backend/tools/make_parity_fixtures.js
   Writes backend/tests/fixtures/js_parity.json: for each case the configuration, the design
   gains, the recorded samples, the metrics, the outcome and the timeline event types/times. */
"use strict";
var path = require("path"), fs = require("fs");
global.window = {};
var TWIN = require(path.join(__dirname, "..", "..", "site", "js", "core.js"));
var a = TWIN.NOMINAL.a;
var C = [
  ["edge-pid", { mode: "edge", controller: { type: "pid" }, duration_s: 5 }],
  ["edge-lqr", { mode: "edge", controller: { type: "lqr" }, duration_s: 5 }],
  ["edge-adp-offset", { mode: "edge", controller: { type: "adp" }, comOffset_m: 0.004, duration_s: 8 }],
  ["edge-none", { mode: "edge", controller: { type: "none" }, duration_s: 2 }],
  ["edge-lqr-mass-knows", { mode: "edge", controller: { type: "lqr", knowsAttachments: true }, attachments: [{ id: "m1", label: "M", mass_kg: 0.08, pos_m: [a / 2, a, 0.6 * a] }], initial: { tilt_deg: 3, rate_dps: 0, azimuth_deg: 0, reference: "balance" }, duration_s: 5 }],
  ["edge-kf-noisy", { mode: "edge", controller: { type: "lqr" }, estimator: { type: "kf" }, sensor: { gyro_noise_dps: 0.3, gyro_bias_dps: 0.8, gyro_bias_walk_dps: 0.01, accel_noise_mps2: 0.08, gyro_quant_dps: 0.01, accel_quant_deg: 0.02, latency_ms: 6, dropout: 0.05, rate_hz: null }, seed: 11, duration_s: 5 }],
  ["edge-cf", { mode: "edge", controller: { type: "pid" }, estimator: { type: "cf" }, seed: 3, duration_s: 4 }],
  ["edge-accel", { mode: "edge", controller: { type: "lqr" }, estimator: { type: "accel" }, seed: 5, duration_s: 4 }],
  ["edge-gyro", { mode: "edge", controller: { type: "lqr" }, estimator: { type: "gyro" }, seed: 9, duration_s: 4 }],
  ["edge-lag-health", { mode: "edge", controller: { type: "lqr" }, actuator: { motor_lag_ms: 20, wheel_health: { x: 0.7, y: 1, z: 1 } }, initial: { tilt_deg: 5, rate_dps: 10, azimuth_deg: 0, reference: "geometric" }, duration_s: 5 }],
  ["edge-pid-failure", { mode: "edge", controller: { type: "pid" }, events: [{ id: "E1", type: "wheel_failure", wheel: "x", t_s: 2 }], duration_s: 5 }],
  ["edge-lqr-push", { mode: "edge", controller: { type: "lqr" }, disturbances: [{ id: "F1", type: "force", magnitude_N: 1.5, point_m: [a / 2, a, a], direction: [0, 1, 0], frame: "world", t_start_s: 1, duration_s: 0.2 }], duration_s: 5 }],
  ["edge-lqr-torque", { mode: "edge", controller: { type: "lqr" }, disturbances: [{ id: "T1", type: "torque", magnitude_Nm: 0.05, direction: [1, 0, 0], frame: "body", t_start_s: 0.5, duration_s: 1.0 }], duration_s: 5 }],
  ["edge-adp-mismatch", { mode: "edge", controller: { type: "adp" }, uncertainty: { inertiaScale: 1.3 }, torqueScale: 0.6, initial: { tilt_deg: 10, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, duration_s: 6 }],
  ["edge-lqr-fall", { mode: "edge", controller: { type: "lqr" }, initial: { tilt_deg: 25, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, duration_s: 4 }],
  ["corner-pid", { mode: "corner", controller: { type: "pid" }, duration_s: 5 }],
  ["corner-lqr-az", { mode: "corner", controller: { type: "lqr" }, initial: { tilt_deg: 4, rate_dps: 20, azimuth_deg: 45, reference: "geometric" }, duration_s: 5 }],
  ["corner-adp-shift", { mode: "corner", controller: { type: "adp" }, comShift_m: [0.004, -0.002, 0.001], duration_s: 8 }],
  ["corner-lqr-yaw", { mode: "corner", controller: { type: "lqr" }, commands: [{ id: "C1", type: "yaw_step", t_s: 1, angle_deg: 45 }], duration_s: 6 }],
  ["corner-lqr-fail-reconf", { mode: "corner", controller: { type: "lqr", reconfigureOnFailure: true }, events: [{ id: "E1", type: "wheel_failure", wheel: "z", t_s: 2 }], duration_s: 6 }],
  ["corner-pid-fail-noreconf", { mode: "corner", controller: { type: "pid", reconfigureOnFailure: false }, events: [{ id: "E1", type: "wheel_failure", wheel: "y", t_s: 1.5 }], duration_s: 4 }],
  ["corner-lqr-mass-knows", { mode: "corner", controller: { type: "lqr", knowsAttachments: true }, attachments: [{ id: "m1", label: "M", mass_kg: 0.1, pos_m: [a, 0.5 * a, a] }], initial: { tilt_deg: 3, rate_dps: 0, azimuth_deg: 30, reference: "balance" }, duration_s: 5 }],
  ["corner-lqr-push", { mode: "corner", controller: { type: "lqr" }, disturbances: [{ id: "F1", type: "force", magnitude_N: 1.2, point_m: [a, a, a], direction: [1, 0.4, 0], frame: "world", t_start_s: 1, duration_s: 0.2 }], duration_s: 5 }],
  ["corner-lqr-lag-health", { mode: "corner", controller: { type: "lqr" }, actuator: { motor_lag_ms: 15, wheel_health: { x: 0.8, y: 0.6, z: 1 } }, duration_s: 5 }],
  ["corner-lqr-fall", { mode: "corner", controller: { type: "lqr" }, initial: { tilt_deg: 14, rate_dps: 60, azimuth_deg: 10, reference: "geometric" }, duration_s: 4 }]
];
var out = { generated_from: "site/js/core.js", model: TWIN.VERSION.model, note: "Browser engine outputs used by backend/tests/test_parity.py. Regenerate with node backend/tools/make_parity_fixtures.js.", cases: [] };
C.forEach(function (c) {
  var cfg = c[1]; cfg.record_hz = 25;
  var r = TWIN.simulate(cfg);
  if (!r.ok) throw new Error(c[0] + ": " + JSON.stringify(r.errors));
  var dz = r.design;
  out.cases.push({ name: c[0], config: cfg, outcome: r.outcome.code, reason: r.outcome.reason, metrics: r.metrics,
    design: { K: dz.tilt.K, pid: dz.tilt.pid, yawK: dz.yaw ? dz.yaw.K : null },
    samples: r.samples.cols, timeline: r.timeline.events.map(function (e) { return { t: e.t, type: e.type, wheel: e.wheel || null }; }) });
});
var dest = path.join(__dirname, "..", "tests", "fixtures", "js_parity.json");
fs.writeFileSync(dest, JSON.stringify(out));
console.log("wrote " + out.cases.length + " cases to " + dest + " (" + Math.round(fs.statSync(dest).size / 1024) + " kB)");

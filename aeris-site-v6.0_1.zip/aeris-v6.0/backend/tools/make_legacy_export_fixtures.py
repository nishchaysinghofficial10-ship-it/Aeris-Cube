"""Generate the legacy export chains used by tests/test_export_audit.py with the ACTUAL v5.1 implementation.

    PYTHONPATH=<a checkout of tag aeris-v5.1>/backend python backend/tools/make_legacy_export_fixtures.py OUT.json

v5 and v5.1 streamed stored sample values without reading samples.units, so an NDJSON export of a recording kept in
ms/deg (or with omega_* wheel speeds) produced copies with raw numbers under the wire-unit labels s/rad (review finding
G1 of v5.1). The audit in v6 must find those copies and everything copied from them (finding V52-4 of v5.2). The test
fixtures are therefore produced by the v5.1 code itself — exactly as the reviewer produced
export-audit-v51-generated-chain.json — never imitated by hand. The script refuses to run against another backend.

All documents are SYNTHETIC fixtures (no hardware)."""
from __future__ import annotations

import json
import sys

from aeris_backend.version import BACKEND_VERSION
from aeris_backend.telemetry.stream import TelemetryHub, recording_to_ndjson

if BACKEND_VERSION != "1.1.1":
    sys.exit(f"this generator needs the v5.1 backend (1.1.1) on PYTHONPATH, found {BACKEND_VERSION}")


def replay(txt: str, name: str) -> dict:
    """Replay an NDJSON text through the v5.1 hub as the backend's file replay would, recording it."""
    hub = TelemetryHub()
    hub.on_connect({"kind": "file", "address": name + ".ndjson"}, 0.0)
    for i, line in enumerate(txt.splitlines()):
        r = hub.feed_line(line, i * 0.01)
        assert r in ("hello", "frame", "bye"), (name, r, line[:120])
        if r == "hello" and hub.recording is None:
            hub.start_recording("SYNTHETIC legacy export fixture " + name, 0.0)
    return hub.stop_recording(5.0)


def original(dev: str, cols: dict, units: dict, mode="edge") -> dict:
    return {"schema": "aeris-hardware-run/1", "synthetic": True, "device": {"id": dev, "firmware": "fixture"},
            "recording": {"started": "2026-10-09T00:00:00Z", "notes": "SYNTHETIC legacy export fixture " + dev}, "mode": mode,
            "samples": {"cols": cols, "units": units}}


def chain(start_id: str, doc: dict, generations: int) -> dict:
    docs, prev = {start_id: doc}, start_id
    for g in range(1, generations + 1):
        cid = f"{start_id}-V51-COPY-{g}"
        docs[cid] = replay(recording_to_ndjson(docs[prev], prev), cid)
        prev = cid
    return docs


def main(out: str) -> None:
    fx = {"generated_by": "aeris-backend " + BACKEND_VERSION + " (v5.1) recording_to_ndjson + TelemetryHub replay/record",
          "note": "SYNTHETIC fixtures. Copies made by the actual v5.1 export carry raw numbers under wire-unit labels.", "chains": {}}
    # a recording stored in ms and degrees: every legacy copy is corrupt (three generations)
    fx["chains"]["ms-deg"] = chain("ORIG-MS-DEG", original("SYNTHETIC-ms-deg", {"t": [0, 100, 200, 300], "theta": [10, 11, 12, 13]}, {"t": "ms", "theta": "deg"}), 3)
    # a recording already in the wire units: legacy copies are correct (the unaffected control)
    fx["chains"]["wire"] = chain("ORIG-WIRE", original("SYNTHETIC-wire", {"t": [0, 0.1, 0.2, 0.3], "theta": [0.1, 0.11, 0.12, 0.13]}, {"t": "s", "theta": "rad"}), 2)
    # corner recording with wheel speeds as omega_* [rad/s]: v5.1 left them out of the stream
    fx["chains"]["omega"] = chain("ORIG-OMEGA", original("SYNTHETIC-omega", {"t": [0, 0.01, 0.02], "q0": [1, 1, 1], "q1": [0, 0, 0], "q2": [0, 0, 0], "q3": [0, 0, 0],
                                                                            "omega_x": [1, 2, 3], "omega_y": [0, 0, 0], "omega_z": [0, 0, 0]},
                                                                  {"t": "s", "q0": "1", "q1": "1", "q2": "1", "q3": "1", "omega_x": "rad/s", "omega_y": "rad/s", "omega_z": "rad/s"}, "corner"), 1)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(fx, fh, indent=1, sort_keys=True)
    print(json.dumps({k: {i: d["samples"]["units"] for i, d in v.items()} for k, v in fx["chains"].items()}, indent=1))


if __name__ == "__main__":
    main(sys.argv[1])

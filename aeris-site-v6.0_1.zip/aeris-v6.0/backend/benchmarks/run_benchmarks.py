"""Reproducible SOFTWARE benchmarks of the AERIS research backend (not physical performance of the cube).

    cd backend && python benchmarks/run_benchmarks.py [--quick] [--out benchmarks/results]

Measures, on the machine it runs on:
  1. single-run cost of the engine (wall time, integration steps per second, real-time factor) for fixed,
     seeded configurations: legacy edge/corner LQR, coupled MIMO LQR, nonlinear PD + MEKF, custom plant;
  2. the effect of the integration rate (500 / 1000 / 2000 Hz);
  3. end-to-end sweep throughput through the job manager (process pool + SQLite), per worker count;
  4. the browser engine (site/js/core.js under Node) on the same legacy configurations, for comparison.

Every configuration, seed, repeat count and software version is written next to the numbers
(results/benchmarks-<date>.json and .md). Wall times depend on the machine and its load; medians of
repeated runs are reported with their spread. These numbers describe software speed only."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import platform
import shutil
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from aeris_backend.simulation import simulate  # noqa: E402
from aeris_backend.version import software_versions  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]

SINGLE = {
    "edge_lqr_legacy": {"mode": "edge", "controller": {"type": "lqr"}, "initial": {"tilt_deg": 2}, "duration_s": 10, "seed": 1},
    "edge_kf_lqr_legacy": {"mode": "edge", "controller": {"type": "lqr"}, "estimator": {"type": "kf"}, "initial": {"tilt_deg": 2}, "duration_s": 10, "seed": 1},
    "corner_lqr_legacy": {"mode": "corner", "controller": {"type": "lqr"}, "initial": {"tilt_deg": 2, "rate_dps": 5, "azimuth_deg": 30}, "duration_s": 10, "seed": 1},
    "corner_mimo_lqr": {"mode": "corner", "controller": {"type": "lqr", "structure": "mimo-lqr"}, "initial": {"tilt_deg": 2, "rate_dps": 5, "azimuth_deg": 30}, "duration_s": 10, "seed": 1},
    "corner_nlpd_mekf": {"mode": "corner", "controller": {"type": "nlpd"}, "estimator": {"type": "mekf"}, "initial": {"tilt_deg": 2, "rate_dps": 5, "azimuth_deg": 30}, "duration_s": 10, "seed": 1},
    "corner_custom_plant_4_wheels": {"mode": "corner", "controller": {"type": "lqr", "structure": "mimo-lqr"},
                                     "plant": {"base_inertia_kgm2": [[0.0118, 0.0002, 0], [0.0002, 0.0121, 0.0001], [0, 0.0001, 0.0119]]},
                                     "wheels": [{"id": "a", "axis": [1, 0, 0]}, {"id": "b", "axis": [0, 1, 0]}, {"id": "c", "axis": [0, 0, 1]}, {"id": "d", "axis": [0.57735, 0.57735, 0.57735]}],
                                     "initial": {"tilt_deg": 2}, "duration_s": 10, "seed": 1},
}
RATES = [500, 1000, 2000]


def machine():
    cpu = platform.processor() or ""
    try:
        for line in Path("/proc/cpuinfo").read_text().splitlines():
            if line.startswith("model name"):
                cpu = line.split(":", 1)[1].strip()
                break
    except OSError:
        pass
    node = shutil.which("node")
    return {"platform": platform.platform(), "machine": platform.machine(), "cpu": cpu, "logical_cpus": os.cpu_count(),
            "python": sys.version.split()[0], "node": subprocess.run([node, "--version"], capture_output=True, text=True).stdout.strip() if node else None,
            "software": software_versions(), "date": time.strftime("%Y-%m-%dT%H:%M:%S%z")}


def time_single(cfg, repeats):
    walls = []
    res = None
    for _ in range(repeats):
        t0 = time.perf_counter()
        res = simulate(cfg)
        walls.append(time.perf_counter() - t0)
    assert res.get("ok", True) and "executed" in res, res.get("errors")
    hz = res["executed"]["rates"]["integration_hz"]
    steps = res["executed"]["steps"]                 # integration steps actually executed (a fall ends a run early)
    med = statistics.median(walls)
    return {"repeats": repeats, "wall_s_median": med, "wall_s_min": min(walls), "wall_s_max": max(walls), "integration_hz": hz, "steps": steps,
            "simulated_s": res["executed"]["simulated_s"], "steps_per_s": steps / med, "realtime_factor": res["executed"]["simulated_s"] / med, "outcome": res["outcome"]["code"],
            "executed": {"controller": res["executed"]["controller"]["type"] + "/" + res["executed"]["controller"]["structure"], "estimator": res["executed"]["estimator"]["type"]}}


async def sweep_throughput(workers, runs, duration_s):
    from aeris_backend.jobs.manager import JobManager
    from aeris_backend.storage.sqlite import SqliteRepository
    d = tempfile.mkdtemp(prefix="aeris-bench-")
    repo = SqliteRepository(os.path.join(d, "bench.sqlite3"))
    m = JobManager(repo, workers=workers, max_jobs=1)
    await m.start()
    try:
        steps = int(round(runs ** 0.5))
        other = max(1, runs // steps)
        definition = {"revision": "1.1", "seed_strategy": "paired", "base": {"mode": "corner"}, "mode": "grid", "controllers": ["lqr"],
                      "variables": [{"key": "tilt_deg", "min": 0.2, "max": 2.0, "steps": steps}, {"key": "rate_dps", "min": -5, "max": 5, "steps": other}], "duration_s": duration_s}
        # warm-up (process pool start, imports) is excluded from the timing
        warm = m.submit_sweep(dict(definition, variables=[{"key": "tilt_deg", "min": 1, "max": 2, "steps": 2}], duration_s=1))
        while repo.get_job(warm["id"])["state"] not in ("complete", "failed", "cancelled"):
            await asyncio.sleep(0.05)
        t0 = time.perf_counter()
        job = m.submit_sweep(definition)
        while True:
            j = repo.get_job(job["id"])
            if j["state"] in ("complete", "failed", "cancelled"):
                break
            await asyncio.sleep(0.05)
        wall = time.perf_counter() - t0
        n = j["progress"]["done"]
        rows = repo.sweep_rows(job["result_ref"]["id"])
        outcomes = {}
        for r in rows:
            outcomes[r["outcome"]] = outcomes.get(r["outcome"], 0) + 1
        full_window = sum(1 for r in rows if (r.get("termination") or {}).get("reason") == "duration")
        return {"workers": workers, "runs": n, "state": j["state"], "sim_s_per_run": duration_s, "wall_s": wall, "runs_per_s": n / wall,
                "runs_simulated_to_the_end": full_window, "outcomes": outcomes,
                "integration_steps_per_s_upper_bound": n * duration_s * 500 / wall, "definition": definition}
    finally:
        await m.stop()
        repo.close()
        shutil.rmtree(d, ignore_errors=True)


def browser_engine(repeats):
    node = shutil.which("node")
    if not node:
        return {"note": "node not found; browser engine not measured"}
    script = r"""
var path = require("path"); global.window = {};
var TWIN = require(path.join(process.argv[1], "site", "js", "core.js"));
var cases = JSON.parse(process.argv[2]), reps = +process.argv[3], out = {};
Object.keys(cases).forEach(function (k) {
  var cfg = TWIN.defaultConfig(cases[k].mode); var src = cases[k];
  if (src.controller) Object.assign(cfg.controller, src.controller); if (src.estimator) Object.assign(cfg.estimator, src.estimator);
  Object.assign(cfg.initial, src.initial || {}); cfg.duration_s = src.duration_s; cfg.seed = src.seed;
  var w = [], r; for (var i = 0; i < reps; i++) { var t0 = process.hrtime.bigint(); r = TWIN.simulate(cfg); w.push(Number(process.hrtime.bigint() - t0) / 1e9); }
  w.sort(function (a, b) { return a - b; }); var med = w[Math.floor(w.length / 2)], steps = Math.round(cfg.duration_s * cfg.params.fs);
  out[k] = { repeats: reps, wall_s_median: med, steps: steps, steps_per_s: steps / med, realtime_factor: cfg.duration_s / med, outcome: r.outcome.code };
});
console.log(JSON.stringify(out));
"""
    legacy = {k: v for k, v in SINGLE.items() if k.endswith("_legacy")}   # the browser engine runs only the legacy model
    p = subprocess.run([node, "-e", script, str(ROOT), json.dumps(legacy), str(repeats)], capture_output=True, text=True, timeout=600)
    if p.returncode != 0:
        return {"error": p.stderr[-500:]}
    return json.loads(p.stdout.strip().splitlines()[-1])


def markdown(r):
    L = ["# AERIS research backend · software benchmarks", "",
         "Software speed only (how fast the simulator runs on this machine), not physical performance of the cube. "
         "Medians of repeated runs; wall times depend on the machine and its load.", "",
         f"- Machine: {r['machine']['cpu']} · {r['machine']['logical_cpus']} logical CPUs · {r['machine']['platform']}",
         f"- Software: Python {r['machine']['python']} · NumPy {r['machine']['software'].get('numpy')} · SciPy {r['machine']['software'].get('scipy')} · "
         f"{r['machine']['software'].get('engine')} · Node {r['machine']['node']}",
         f"- Date: {r['machine']['date']} · repeats per single-run case: {r['repeats']}", "",
         "## 1 · Single runs (engine only, 10 s simulated, fixed seeds)", "",
         "| Case | Executed | Integration | Steps | Wall (median) | Steps/s | Real-time factor | Outcome |", "|---|---|---|---:|---:|---:|---:|---|"]
    for k, v in r["single"].items():
        L.append(f"| {k} | {v['executed']['controller']} · {v['executed']['estimator']} | {v['integration_hz']:g} Hz | {v['steps']} | {v['wall_s_median'] * 1000:.0f} ms | {v['steps_per_s']:,.0f} | {v['realtime_factor']:.1f}× | {v['outcome']} |")
    L += ["", "## 2 · Integration rate (corner LQR, 10 s, control at 500 Hz)", "", "| Integration | Steps | Wall (median) | Steps/s | Real-time factor | Outcome |", "|---:|---:|---:|---:|---:|---|"]
    for v in r["rates"]:
        L.append(f"| {v['integration_hz']:g} Hz | {v['steps']} | {v['wall_s_median'] * 1000:.0f} ms | {v['steps_per_s']:,.0f} | {v['realtime_factor']:.1f}× | {v['outcome']} |")
    L += ["", "## 3 · Sweep throughput through the job manager (process pool + SQLite, corner LQR, small tilts)", "", "| Workers | Runs | Runs to the end of the window | Simulated per run | Wall | Runs/s |", "|---:|---:|---:|---:|---:|---:|"]
    for v in r["sweeps"]:
        L.append(f"| {v['workers']} | {v['runs']} | {v['runs_simulated_to_the_end']} | {v['sim_s_per_run']} s | {v['wall_s']:.1f} s | {v['runs_per_s']:.2f} |")
    L += ["", "## 4 · Browser engine (site/js/core.js under Node) on the legacy cases", ""]
    b = r["browser"]
    if "error" in b or "note" in b:
        L.append(str(b))
    else:
        L += ["| Case | Steps | Wall (median) | Steps/s | Real-time factor | Outcome |", "|---|---:|---:|---:|---:|---|"]
        for k, v in b.items():
            L.append(f"| {k} | {v['steps']} | {v['wall_s_median'] * 1000:.1f} ms | {v['steps_per_s']:,.0f} | {v['realtime_factor']:.0f}× | {v['outcome']} |")
    L += ["", "Configurations, seeds and the raw numbers are in the JSON file next to this one."]
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="fewer repeats and smaller sweeps")
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent / "results"))
    a = ap.parse_args()
    repeats = 3 if a.quick else 5
    r = {"kind": "software benchmark", "machine": machine(), "repeats": repeats, "configs": SINGLE, "single": {}, "rates": [], "sweeps": [], "browser": None}
    for k, cfg in SINGLE.items():
        r["single"][k] = time_single(cfg, repeats)
        print(f"single {k}: {r['single'][k]['wall_s_median'] * 1000:.0f} ms, {r['single'][k]['steps_per_s']:,.0f} steps/s", flush=True)
    for hz in RATES:
        cfg = dict(SINGLE["corner_lqr_legacy"], solver={"integration_hz": hz})
        v = time_single(cfg, repeats)
        r["rates"].append(v)
        print(f"rate {hz} Hz: {v['wall_s_median'] * 1000:.0f} ms", flush=True)
    worker_counts = sorted({1, min(2, os.cpu_count() or 1), min(4, os.cpu_count() or 1)})
    for w in worker_counts:
        v = asyncio.run(sweep_throughput(w, 36 if a.quick else 100, 5))
        r["sweeps"].append(v)
        print(f"sweep workers={w}: {v['runs']} runs in {v['wall_s']:.1f} s ({v['runs_per_s']:.2f} runs/s)", flush=True)
    r["browser"] = browser_engine(repeats)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    (out / f"benchmarks-{stamp}.json").write_text(json.dumps(r, indent=1, default=str))
    (out / f"benchmarks-{stamp}.md").write_text(markdown(r))
    print(markdown(r))


if __name__ == "__main__":
    main()

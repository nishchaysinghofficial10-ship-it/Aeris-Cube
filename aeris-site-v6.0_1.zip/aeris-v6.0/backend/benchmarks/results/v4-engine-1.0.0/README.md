# v4 benchmark results (historical, superseded)

These two runs were produced on 2026-09-27 by the **v4** backend (aeris-research-engine 1.0.0) with
`benchmarks/run_benchmarks.py`; their configurations and raw numbers are in the JSON files. They are kept for
traceability only. The current results are the v5 run in the parent directory (engine 1.1.0, same script,
same machine type). Wall times depend on the machine and its load; they describe software speed, never the
physical cube.

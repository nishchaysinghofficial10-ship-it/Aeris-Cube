#!/usr/bin/env python3
"""Minimal command-line client for the AERIS research backend (Python standard library only).

    python examples/aeris_client.py [--url http://127.0.0.1:8750] COMMAND ...

Commands
  health | capabilities
  validate FILE                    POST /validate (a configuration or a sweep definition)
  run FILE [--parameter-set ID]    submit a simulation, wait for it, print the record summary
  sweep FILE [--parameter-set ID] [--no-wait]
  job ID | cancel ID
  get-run ID [--csv OUT]           a stored run (summary) or its CSV export
  get-sweep ID                     summary of a stored sweep
  row SWEEP_ID INDEX               one sweep row with the exact configuration simulated for it
  reproduce RUN_ID                 re-run a stored run on the backend and report whether it is identical
  demo [--json OUT]                the v4 end-to-end demonstration (examples/README.md)

Every number printed comes from the backend's responses; the client computes nothing itself
except equality checks. The backend uses nominal (unvalidated) parameters unless a measured
parameter set is named.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
API = "/api/v1"
TERMINAL = ("complete", "failed", "cancelled")


class BackendError(Exception):
    def __init__(self, status, body):
        err = (body or {}).get("error") or {}
        super().__init__(f"HTTP {status} {err.get('code')}: {err.get('message')}")
        self.status, self.code, self.details = status, err.get("code"), err.get("details")


class Client:
    def __init__(self, url: str, timeout: float = 60.0):
        self.url = url.rstrip("/")
        self.timeout = timeout

    def call(self, method: str, path: str, body=None, raw: bool = False):
        data = None if body is None else json.dumps(body).encode("utf-8")
        req = urllib.request.Request(self.url + API + path, data=data, method=method,
                                     headers={"Accept": "application/json", "Content-Type": "application/json", "X-AERIS-Client": "aeris-cli/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as res:
                txt = res.read().decode("utf-8")
                return txt if raw else (json.loads(txt) if txt else None)
        except urllib.error.HTTPError as e:
            txt = e.read().decode("utf-8")
            try:
                body = json.loads(txt)
            except ValueError:
                body = {"error": {"code": "bad_response", "message": txt[:200]}}
            raise BackendError(e.code, body) from None

    def wait(self, job_id: str, timeout: float = 900.0, poll: float = 0.5, until=None) -> dict:
        t0 = time.time()
        while True:
            j = self.call("GET", f"/jobs/{job_id}")
            if j["state"] in TERMINAL or (until is not None and until(j)):
                return j
            if time.time() - t0 > timeout:
                raise TimeoutError(f"job {job_id} still {j['state']} after {timeout:.0f} s")
            time.sleep(poll)

    def run(self, config: dict, parameter_set: str | None = None, meta: dict | None = None) -> tuple[dict, dict]:
        body = {"config": config, "meta": meta or {}, "client": {"site": "aeris-cli"}}
        if parameter_set:
            body["parameter_set"] = parameter_set
        job = self.wait(self.call("POST", "/simulations", body)["job"]["id"])
        if job["state"] != "complete":
            raise RuntimeError(f"job {job['id']} ended {job['state']}: {job.get('error') or job.get('message')}")
        return job, self.call("GET", f"/runs/{job['result_ref']['id']}")


def load(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        p = HERE / path
    return json.loads(p.read_text(encoding="utf-8"))


def canonical(obj) -> str:
    return "sha256:" + hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def run_summary(rec: dict) -> dict:
    ex = rec["executed"]
    rr = rec["research"]["recovery"]
    est = rec["research"].get("estimator")
    return {
        "experiment_id": rec["experiment_id"], "id": rec["id"], "name": rec["name"],
        "origin": f"{rec['origin']['engine']} ({rec['origin']['engine_version']})", "schema": f"{rec['schema']} rev {rec['schema_revision']}",
        "validation": f"{rec['validation']['status']} · {rec['validation']['parameter_set']}",
        "outcome": f"{rec['outcome']['code']} — {rec['outcome']['reason']}",
        "research_recovery": {"recovered": rr["recovered"], "t_s": rr.get("t_s"), "criteria": rr["summary"]},
        "termination": f"{rec['termination']['reason']} at t = {rec['termination']['t']}",
        "executed_controller": {k: ex["controller"].get(k) for k in ("type", "structure", "law", "name")},
        "executed_estimator": {k: ex["estimator"].get(k) for k in ("type", "name", "truth_access", "stats")},
        "rates": ex["rates"], "steps": ex["steps"], "impulses_applied": ex.get("impulses_applied"),
        "estimator_accuracy": {k: est[k] for k in ("tilt_rmse_deg", "attitude_rmse_deg", "bias_error_final_dps") if k in est} if est else None,
        "samples": f"{len(rec['samples']['cols']['t'])} rows × {len(rec['samples']['cols'])} columns at {rec['samples']['rate_hz']} Hz",
        "config_hash": rec["reproduction"]["config_hash"],
    }


def sweep_summary(sw: dict) -> dict:
    a = sw.get("analysis") or {}
    ctl = {k: {"runs": v["n"], "valid": v["valid"], "invalid": v["invalid"], "recovered": v["recovered"],
               "rate": None if v["rate"] is None else round(v["rate"], 4), "ci95": [round(x, 4) for x in v["ci95"]] if v.get("ci95") else None,
               "research_recovered": v["research_recovered"]} for k, v in (a.get("controllers") or {}).items()}
    paired = [{k: p[k] for k in ("a", "b", "pairs", "both", "only_a", "only_b", "neither", "mcnemar_exact_p", "paired_seeds")} for p in a.get("paired") or []]
    return {"id": sw["id"], "status": sw.get("status"), "partial": sw.get("partial"), "rows": len(sw.get("rows") or []), "total": sw.get("total"),
            "seed_strategy": (sw.get("definition") or {}).get("seed_strategy"), "controllers": ctl, "paired": paired,
            "analysis": (a.get("computed_from") + (" (PARTIAL)" if a.get("partial") else "")) if a else None, "notes": a.get("notes"),
            "sampling_notes": sw.get("sampling_notes")}


def show(title: str, obj) -> None:
    print(f"\n=== {title}")
    print(json.dumps(obj, indent=2, ensure_ascii=False, default=str))


def demo(c: Client, out: str | None) -> int:
    log = {"started": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "backend": c.url, "steps": []}
    checks = []

    def check(name, ok, detail=None):
        checks.append({"check": name, "ok": bool(ok), "detail": detail})
        print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else f"  ({detail})"))

    def step(name, obj):
        log["steps"].append({"step": name, "result": obj})
        show(name, obj)

    h = c.call("GET", "/health")
    caps = c.call("GET", "/capabilities")
    step("1. Backend health and reported capabilities", {"health": {k: h[k] for k in ("status", "backend", "version", "engine_version", "workers", "max_jobs", "restart_policy")},
                                                         "controllers": caps["controllers"], "structures": caps["structures"], "estimators": caps["estimators"],
                                                         "parity_target": caps["parity_target"], "hardware": caps["hardware"]["bridge"]})
    check("health ok and capabilities reported", h["status"] == "ok" and caps.get("reported") is True)

    job1, rec1 = c.run(load("configs/edge_lqr_legacy.json"), meta={"name": "Demo 1: edge LQR (legacy configuration)"})
    step("2. Real backend single run (edge, LQR, revision-1.0 configuration)", dict(run_summary(rec1), job={k: job1[k] for k in ("id", "state", "progress", "seq")}))
    check("single run complete and labelled with the backend origin", rec1["origin"]["engine"] == "aeris-research-backend" and rec1["validation"]["status"] == "nominal")

    job2, rec2 = c.run(load("configs/corner_nlpd_mekf_disturbances.json"), meta={"name": "Demo 2: nonlinear PD + MEKF, impulse, wheel degradation"})
    s2 = run_summary(rec2)
    step("3. Advanced controller and estimator run (corner, nonlinear PD, MEKF, impulse, wheel degradation)", s2)
    check("executed method is the requested one (nlpd, full tensor; MEKF without truth access)",
          s2["executed_controller"]["type"] == "nlpd" and s2["executed_controller"]["structure"] == "nonlinear-full-tensor"
          and s2["executed_estimator"]["type"] == "mekf" and s2["executed_estimator"]["truth_access"] is False)

    listed = c.call("GET", "/runs?limit=500")["runs"]
    again = c.call("GET", f"/runs/{rec2['id']}")
    csv = c.call("GET", f"/runs/{rec2['id']}/export?format=csv", raw=True).splitlines()
    step("4. Persisted result retrieval", {"listed": [r for r in listed if r["id"] in (rec1["id"], rec2["id"])],
                                           "refetched_identical": canonical(again) == canonical(rec2), "csv_header": csv[:3], "csv_lines": len(csv)})
    check("both runs listed and the stored record is returned unchanged", {rec1["id"], rec2["id"]} <= {r["id"] for r in listed} and canonical(again) == canonical(rec2))

    rj = c.wait(c.call("POST", f"/runs/{rec2['id']}/reproduce")["job"]["id"])
    rep_rec = c.call("GET", f"/runs/{rj['result_ref']['id']}")
    rep = rep_rec["reproduction"].get("reproduces") or {}
    step("5. Reproduction of the advanced run", {"reproduction_run": rep_rec["experiment_id"], "report": rep})
    check("reproduction identical", rep.get("identical") is True, f"max |Δ| = {rep.get('max_abs_diff')}")

    sdef = load("sweeps/corner_controllers_paired.json")
    sj = c.wait(c.call("POST", "/sweeps", {"sweep": sdef})["job"]["id"])
    sw = c.call("GET", f"/sweeps/{sj['result_ref']['id']}")
    row0 = c.call("GET", f"/sweeps/{sw['id']}/rows/0")
    step("6. Sweep (corner, 3 controllers × 12 points, MEKF, paired seeds)", dict(sweep_summary(sw), job={k: sj[k] for k in ("id", "state", "progress")},
                                                                                row_0={k: row0.get(k) for k in ("index", "controller", "values", "seed", "config_hash", "outcome")}))
    check("sweep complete with every row and a paired analysis", sj["state"] == "complete" and len(sw["rows"]) == sw["total"] and bool(sw["analysis"]["paired"]))

    big = dict(load("sweeps/edge_uncertainty_montecarlo.json"), samples=3000, name="Demo 7: large Monte Carlo sweep, cancelled while running")
    bj = c.call("POST", "/sweeps", {"sweep": big})["job"]
    c.wait(bj["id"], timeout=600, poll=0.2, until=lambda j: j["state"] == "running" and j["progress"]["done"] >= 40)
    cj = c.call("POST", f"/jobs/{bj['id']}/cancel")
    bsw = c.call("GET", f"/sweeps/{cj['result_ref']['id']}")
    step("7. Cancellation during execution (partial results kept)", {"job": {k: cj[k] for k in ("id", "state", "progress", "message")}, "sweep": sweep_summary(bsw)})
    check("cancelled sweep keeps exactly the finished runs, labelled partial",
          cj["state"] == "cancelled" and bsw["partial"] is True and 0 < len(bsw["rows"]) == cj["progress"]["done"] < bsw["total"]
          and (bsw.get("analysis") or {}).get("partial") is True,
          f"{len(bsw['rows'])} of {bsw['total']} rows")

    log["checks"] = checks
    log["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    print("\nFrontend replay of these records is exercised in the browser by site/tests/browser_v4.py.")
    print(f"\n{sum(1 for x in checks if x['ok'])} / {len(checks)} demonstration checks passed")
    if out:
        Path(out).write_text(json.dumps(log, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
    return 0 if all(x["ok"] for x in checks) else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--url", default="http://127.0.0.1:8750")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("health")
    sub.add_parser("capabilities")
    p = sub.add_parser("validate"); p.add_argument("file")
    p = sub.add_parser("run"); p.add_argument("file"); p.add_argument("--parameter-set")
    p = sub.add_parser("sweep"); p.add_argument("file"); p.add_argument("--parameter-set"); p.add_argument("--no-wait", action="store_true")
    p = sub.add_parser("job"); p.add_argument("id")
    p = sub.add_parser("cancel"); p.add_argument("id")
    p = sub.add_parser("get-run"); p.add_argument("id"); p.add_argument("--csv")
    p = sub.add_parser("get-sweep"); p.add_argument("id")
    p = sub.add_parser("row"); p.add_argument("sweep_id"); p.add_argument("index", type=int)
    p = sub.add_parser("reproduce"); p.add_argument("run_id")
    p = sub.add_parser("demo"); p.add_argument("--json")
    a = ap.parse_args(argv)
    c = Client(a.url)
    try:
        if a.cmd in ("health", "capabilities"):
            show(a.cmd, c.call("GET", "/" + a.cmd))
        elif a.cmd == "validate":
            d = load(a.file)
            show("validate", c.call("POST", "/validate", {"sweep": d} if d.get("schema") == "aeris-sweep/1" else {"config": d}))
        elif a.cmd == "run":
            job, rec = c.run(load(a.file), a.parameter_set)
            show("run", run_summary(rec))
        elif a.cmd == "sweep":
            body = {"sweep": load(a.file)}
            if a.parameter_set:
                body["parameter_set"] = a.parameter_set
            job = c.call("POST", "/sweeps", body)["job"]
            if a.no_wait:
                show("job", job)
            else:
                job = c.wait(job["id"])
                show("sweep", dict(sweep_summary(c.call("GET", f"/sweeps/{job['result_ref']['id']}")), job_state=job["state"]))
        elif a.cmd == "job":
            show("job", c.call("GET", f"/jobs/{a.id}"))
        elif a.cmd == "cancel":
            show("job", c.call("POST", f"/jobs/{a.id}/cancel"))
        elif a.cmd == "get-run":
            if a.csv:
                Path(a.csv).write_text(c.call("GET", f"/runs/{a.id}/export?format=csv", raw=True), encoding="utf-8")
                print(f"wrote {a.csv}")
            else:
                show("run", run_summary(c.call("GET", f"/runs/{a.id}")))
        elif a.cmd == "get-sweep":
            show("sweep", sweep_summary(c.call("GET", f"/sweeps/{a.id}")))
        elif a.cmd == "row":
            show("row", c.call("GET", f"/sweeps/{a.sweep_id}/rows/{a.index}"))
        elif a.cmd == "reproduce":
            j = c.wait(c.call("POST", f"/runs/{a.run_id}/reproduce")["job"]["id"])
            rec = c.call("GET", f"/runs/{j['result_ref']['id']}")
            show("reproduction", rec["reproduction"].get("reproduces"))
        elif a.cmd == "demo":
            return demo(c, a.json)
    except BackendError as e:
        print(f"error: {e}", file=sys.stderr)
        for d in e.details or []:
            print(f"  {d.get('path')}: {d.get('message')}", file=sys.stderr)
        return 2
    except urllib.error.URLError as e:
        print(f"error: the backend at {c.url} is not reachable ({e.reason})", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())

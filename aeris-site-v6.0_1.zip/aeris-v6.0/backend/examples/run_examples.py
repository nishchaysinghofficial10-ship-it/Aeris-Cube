#!/usr/bin/env python3
"""Run every example configuration with the engine directly (no server) and validate every example
sweep definition; print a Markdown table of what actually happened.

    cd backend && python examples/run_examples.py

Simulation results with nominal (unvalidated) parameters; not hardware measurements."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from aeris_backend.config.validate import validate_config  # noqa: E402
from aeris_backend.experiments import sweeps as SW  # noqa: E402
from aeris_backend.simulation import simulate  # noqa: E402
from aeris_backend.version import ENGINE_VERSION  # noqa: E402


def main() -> int:
    bad = 0
    print(f"Engine: {ENGINE_VERSION}\n")
    print("| Configuration | Executed controller | Estimator | Legacy outcome | Research recovery | Termination | Wall |")
    print("|---|---|---|---|---|---|---:|")
    for p in sorted((HERE / "configs").glob("*.json")):
        cfg = json.loads(p.read_text(encoding="utf-8"))
        v = validate_config(cfg)
        if not v.ok:
            bad += 1
            print(f"| {p.name} | INVALID: {'; '.join(e['path'] + ' ' + e['message'] for e in v.errors)} | | | | | |")
            continue
        t0 = time.perf_counter()
        r = simulate(cfg)
        wall = time.perf_counter() - t0
        ex, rr = r["executed"], r["research"]["recovery"]
        rec = f"yes, t = {rr['t_s']:.3f} s" if rr["recovered"] else "no"
        print(f"| {p.name} | {ex['controller']['type']} / {ex['controller']['structure']} | {ex['estimator']['type']} | {r['outcome']['code']} | {rec} "
              f"({rr['criteria']['yaw_objective'] if r['config']['mode'] == 'corner' else 'edge'}) | {r['termination']['reason']} | {wall:.2f} s |")
    print("\n| Sweep definition | Valid | Runs | Warnings |")
    print("|---|---|---:|---|")
    for p in sorted((HERE / "sweeps").glob("*.json")):
        d = json.loads(p.read_text(encoding="utf-8"))
        r = SW.validate_def(d)
        bad += 0 if r["ok"] else 1
        warns = "; ".join((w["message"] if isinstance(w, dict) else str(w)) for w in r["warnings"]) or "—"
        print(f"| {p.name} | {'yes' if r['ok'] else 'NO: ' + '; '.join(e['message'] for e in r['errors'])} | {r['total']} | {warns} |")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())

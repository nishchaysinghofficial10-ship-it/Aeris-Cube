# AERIS research backend · examples

Example inputs for the backend and two small scripts. All values are **examples** with the nominal
(unvalidated) model parameters; none of them is a hardware measurement.

| File | What it shows |
|---|---|
| `configs/edge_lqr_legacy.json` | a revision-1.0 configuration (the browser's format): runs identically in DEMO and SIMULATION |
| `configs/corner_mimo_lqr.json` | coupled MIMO LQR on the full inertia tensor, research recovery criteria with `yaw_objective: hold` |
| `configs/corner_nlpd_mekf_disturbances.json` | nonlinear PD + quaternion MEKF, IMU at 1 kHz, RK4 at 2 kHz, an angular impulse, a temporary wheel degradation |
| `configs/corner_custom_plant_4_wheels.json` | explicit base inertia tensor, an extra component (illustrative), four wheels (one diagonal), bounded least-squares allocation, a wheel failure |
| `configs/edge_pid_kf_torque_limit.json` | PID with conditional anti-windup and integrator reset on events, Kalman estimator, a temporary torque limit, an overspeed safety limit |
| `sweeps/corner_controllers_paired.json` | grid sweep, three controllers (LQR, MIMO LQR, nonlinear PD) with the MEKF, paired seeds → McNemar comparison |
| `sweeps/edge_uncertainty_montecarlo.json` | Monte Carlo: untruncated `normal` (out-of-range samples become invalid rows), `bounded-normal`, a `path` variable, a `categorical` variable |
| `parameter_set.TEMPLATE.json` | the format of a measured parameter set; its values are `null`, so it is rejected until real measurements are filled in |
| `validation_protocol.DRAFT.json` | the format of acceptance thresholds; a DRAFT to confirm or change before any recording (HARDWARE_NEXT_STEPS.md) |
| `aeris_client.py` | command-line client (standard library only) and the end-to-end demonstration |
| `run_examples.py` | runs every example configuration with the engine directly and validates the sweeps |
| `demo_output/` | the verbatim log (`.txt`) and JSON of `aeris_client.py demo` run against a fresh backend on 2026-09-27 (7 / 7 checks) |

## Run the examples without a server

```bash
cd backend
python examples/run_examples.py
```

Output on 2026-09-27 (aeris-research-engine 1.0.0, Python 3.12.3, 2-CPU Xeon 2.1 GHz):

| Configuration | Executed controller | Estimator | Legacy outcome | Research recovery | Termination |
|---|---|---|---|---|---|
| corner_custom_plant_4_wheels.json | lqr / mimo-lqr | ideal | recovered | yes, t = 0.546 s (hold) | duration |
| corner_mimo_lqr.json | lqr / mimo-lqr | ideal | recovered | yes, t = 0.752 s (hold) | duration |
| corner_nlpd_mekf_disturbances.json | nlpd / nonlinear-full-tensor | mekf | recovered | yes, t = 0.833 s (free) | duration |
| edge_lqr_legacy.json | lqr / decoupled | ideal | recovered | yes, t = 0.308 s | duration |
| edge_pid_kf_torque_limit.json | pid / decoupled | kf | recovered | yes, t = 0.796 s | duration |

Both sweep definitions validate (36 and 600 runs); the Monte Carlo sweep warns that about 9.56 % of
its normal tilt samples fall outside [0, 10]° and will be recorded as invalid rows, not clipped.

## Against a running backend

Start the server (`backend/README.md`), then:

```bash
# health and the capabilities the backend reports
curl -s http://127.0.0.1:8750/api/v1/health
curl -s http://127.0.0.1:8750/api/v1/capabilities | python -m json.tool | head -40

# authoritative validation
curl -s -X POST http://127.0.0.1:8750/api/v1/validate -H 'Content-Type: application/json' \
     -d "{\"config\": $(cat examples/configs/corner_mimo_lqr.json)}"

# a simulation job → poll → fetch the run record (revision 1.2)
JOB=$(curl -s -X POST http://127.0.0.1:8750/api/v1/simulations -H 'Content-Type: application/json' \
      -d "{\"config\": $(cat examples/configs/corner_nlpd_mekf_disturbances.json)}" | python -c 'import sys,json; print(json.load(sys.stdin)["job"]["id"])')
curl -s http://127.0.0.1:8750/api/v1/jobs/$JOB            # repeat until state is complete
RUN=$(curl -s http://127.0.0.1:8750/api/v1/jobs/$JOB | python -c 'import sys,json; print(json.load(sys.stdin)["result_ref"]["id"])')
curl -s "http://127.0.0.1:8750/api/v1/runs/$RUN/export?format=csv" | head -12

# reproduction (the new record's reproduction.reproduces says whether it is identical)
curl -s -X POST http://127.0.0.1:8750/api/v1/runs/$RUN/reproduce

# a sweep, and cancelling a job
curl -s -X POST http://127.0.0.1:8750/api/v1/sweeps -H 'Content-Type: application/json' \
     -d "{\"sweep\": $(cat examples/sweeps/edge_uncertainty_montecarlo.json)}"
curl -s -X POST http://127.0.0.1:8750/api/v1/jobs/<job id>/cancel
```

The same with the client:

```bash
python examples/aeris_client.py --url http://127.0.0.1:8750 run examples/configs/corner_mimo_lqr.json
python examples/aeris_client.py sweep examples/sweeps/corner_controllers_paired.json
python examples/aeris_client.py get-sweep AERIS-SWP-100000
python examples/aeris_client.py row AERIS-SWP-100000 0
python examples/aeris_client.py reproduce <run id>
python examples/aeris_client.py demo --json demo.json
```

`demo` performs, against the running server: health and capability discovery; a single run; an
advanced run (nonlinear PD + MEKF with an impulse and a wheel degradation); persisted retrieval (list,
re-fetch unchanged, CSV export); reproduction (identical); a paired sweep with per-row configuration
retrieval; and a large sweep cancelled while running (finished rows kept, analysis labelled PARTIAL).
It prints every response it relies on and seven pass/fail checks. Frontend replay of backend records
is exercised in the browser by `site/tests/browser_v4.py`.

"""End to end with the SYNTHETIC device process (firmware core + device models, firmware/host/aeris-hostsim): a real
backend server, the companion relaying the device's USB link, and the gateway route (the synthetic stand-in for the
board's own WebSocket client, firmware/tools/synthetic_net_bridge.py).

Pairing with the local ARM press → leases → bounded commands → calibration from the command log → approved
configuration bound by hash → self-test → an experiment that starts only after the local enable → recording →
the twin of the same profile → comparison; then the network route: device authentication, observer role while the
USB host is attached, supervisor after it leaves, revocation closing the connection.

Everything measured here is SYNTHETIC (the device declares itself an emulator); nothing here touches hardware.
"""
from __future__ import annotations

import json
import os
import queue
import socket
import subprocess
import sys
import threading
import time

import httpx
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(os.path.dirname(HERE))
FW = os.path.join(REPO, "firmware")
HOSTSIM = os.path.join(FW, "build", "host", "aeris-hostsim")
PLANT_EDGE = os.path.join(FW, "tests", "fixtures", "plant_edge.json")
PY = sys.executable


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


@pytest.fixture(scope="module")
def hostsim_bin():
    # always through make: it rebuilds the binary when a firmware source changed (a stale binary is never tested)
    try:
        r = subprocess.run(["make", "-C", FW, "build/host/aeris-hostsim"], capture_output=True, text=True)
        problem = None if r.returncode == 0 and os.path.exists(HOSTSIM) else r.stderr[-300:]
    except OSError as e:
        problem = f"make could not be started: {e}"
    if problem is not None:
        pytest.skip("the synthetic device could not be built here (needs make, a C compiler and libcrypto): " + problem)
    return HOSTSIM


class Server:
    def __init__(self, app, port, **tls):
        import uvicorn
        self.server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", **tls))
        self.thread = threading.Thread(target=self.server.run, daemon=True)

    def __enter__(self):
        self.thread.start()
        t0 = time.time()
        while not self.server.started:
            if time.time() - t0 > 30:
                raise RuntimeError("server did not start")
            time.sleep(0.05)
        return self

    def __exit__(self, *a):
        self.server.should_exit = True
        self.thread.join(20)


class Lines:
    """A subprocess whose stdout lines are collected by a thread."""

    def __init__(self, args, **kw):
        self.p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, **kw)
        self.q = queue.Queue()
        self.all = []
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        for line in self.p.stdout:
            self.all.append(line.rstrip("\n"))
            self.q.put(line.rstrip("\n"))

    def wait_for(self, pred, timeout=20.0, what="line"):
        t0 = time.time()
        while time.time() - t0 < timeout:
            try:
                line = self.q.get(timeout=0.1)
            except queue.Empty:
                if self.p.poll() is not None and self.q.empty():
                    break
                continue
            if pred(line):
                return line
        raise AssertionError(f"timed out waiting for {what}; output so far:\n" + "\n".join(self.all[-30:]))

    def json_wait(self, pred, timeout=20.0, what="message"):
        def ok(line):
            try:
                m = json.loads(line)
            except ValueError:
                return False
            return isinstance(m, dict) and pred(m)
        return json.loads(self.wait_for(ok, timeout, what))

    def stop(self):
        if self.p.poll() is None:
            self.p.terminate()
            try:
                self.p.wait(5)
            except subprocess.TimeoutExpired:
                self.p.kill()


class HostSim(Lines):
    def __init__(self, binary, tmp, usb, net, ctl):
        super().__init__([binary, "--plant", PLANT_EDGE, "--usb-tcp", str(usb), "--net-tcp", str(net), "--ctl-tcp", str(ctl),
                          "--device-id", "synthetic-e2e-0001", "--key-file", os.path.join(tmp, "device-key.pem"),
                          "--nvs-file", os.path.join(tmp, "device-nvs.bin")])
        self.wait_for(lambda l: l.startswith("READY"), 10, "READY")
        self.ctl_sock = socket.create_connection(("127.0.0.1", ctl), timeout=5)
        self.ctl_file = self.ctl_sock.makefile("r")

    def ctl(self, line: str) -> str:
        self.ctl_sock.sendall((line + "\n").encode())
        return self.ctl_file.readline().strip()

    def stop(self):
        try:
            self.ctl("quit")
        except OSError:
            pass
        super().stop()


def wait_cmd(api, cid, statuses=("completed", "failed", "rejected", "expired", "cancelled"), timeout=20.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        c = api.get(f"/api/v6/commands/{cid}").json()
        if c["status"] in statuses:
            return c
        time.sleep(0.05)
    raise AssertionError(f"command {cid} still {c['status']}: {c['history'][-3:]}")


def wait_view(api, did, pred, timeout=15.0, what="device view"):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = api.get(f"/api/v6/devices/{did}").json()
        if pred(v):
            return v
        time.sleep(0.05)
    raise AssertionError(f"timed out waiting for {what}: {json.dumps(v)[:600]}")


def seq_continuity(api, base, after_n, min_boundaries):
    """The device's frame numbers continue by exactly one wherever the hub's source segment changed after hub index
    after_n (route changes and reconnections within ONE device telemetry session): nothing lost, nothing fed twice."""
    t0 = time.time()
    while True:
        fr = [f for f in api.get(base + "/frames", params={"after": max(0, after_n - 50), "limit": 2000}).json()["frames"]]
        pairs = [(a, b) for a, b in zip(fr, fr[1:]) if a["segment"] != b["segment"] and b["n"] > after_n]
        if len(pairs) >= min_boundaries and fr and fr[-1]["segment"] == max(f["segment"] for f in fr) and len([f for f in fr if f["segment"] == fr[-1]["segment"]]) > 5:
            break
        assert time.time() - t0 < 10, f"segments {sorted({f['segment'] for f in fr})}"
        time.sleep(0.1)
    assert all(b["n"] == a["n"] + 1 for a, b in zip(fr, fr[1:])), "the hub's index is contiguous"
    bad = [(a["seq"], b["seq"]) for a, b in pairs if b["seq"] != a["seq"] + 1]
    assert not bad, f"device frame numbers jump at a route change: {bad}"


def test_synthetic_device_end_to_end(tmp_path, hostsim_bin):
    from aeris_backend.api.app import create_app
    port, usb, net, ctl = free_port(), free_port(), free_port(), free_port()
    app = create_app({"db": str(tmp_path / "aeris.sqlite3"), "workers": 1, "max_jobs": 1, "origins": ["http://localhost:8000"],
                      "telemetry_dir": str(tmp_path / "tel")})
    origin = f"http://127.0.0.1:{port}"
    sim = comp = bridge = None
    with Server(app, port):
        try:
            sim = HostSim(hostsim_bin, str(tmp_path), usb, net, ctl)
            api = httpx.Client(base_url=origin, timeout=30)
            # ---------------------------------------------------------------- pairing over the companion (USB) route
            comp = Lines([PY, "-m", "aeris_backend.companion", "--backend", origin, "--tcp", f"127.0.0.1:{usb}", "--pair", "--name", "synthetic e2e"],
                         cwd=os.path.dirname(HERE))
            dev = comp.json_wait(lambda m: m.get("type") == "device", 15, "the device on the relay")
            assert dev["device_id"] == "synthetic-e2e-0001" and dev["paired_to_you"] is False and dev["synthetic"] is True
            comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") == "waiting_for_local_confirmation", 10, "local confirmation request")
            assert api.get("/api/v6/devices").json()["devices"] == []          # nothing is registered before the local press
            assert sim.ctl("arm-press").startswith("ok")
            paired = comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") in ("paired", "failed"), 10, "pairing outcome")
            assert paired["status"] == "paired", paired
            comp.json_wait(lambda m: m.get("type") == "device" and m.get("paired_to_you") is True, 10, "device paired on the relay")
            did = "synthetic-e2e-0001"
            v = wait_view(api, did, lambda v: v["connected"] and v["state"] is not None, what="session and state")
            assert v["routes"] == ["companion"] and v["synthetic"] is True and v["dev_hello"]["board"]["kind"] == "emulator"
            base = f"/api/v6/devices/{did}"

            def cmd(action, params=None, ttl=5000, config_hash=None, holder="e2e-holder-1", route=None, final=True):
                r = api.post(base + "/commands", json={"action": action, "params": params, "ttl_ms": ttl, "holder": holder, "config_hash": config_hash,
                                                       "route": route})
                assert r.status_code == 201, r.text
                return wait_cmd(api, r.json()["id"]) if final else r.json()

            # ---------------------------------------------------------------- leases and measurements
            r = api.post(base + "/commands", json={"action": "identify", "holder": "e2e-holder-1"})
            assert r.status_code == 409 and r.json()["error"]["code"] == "lease_required"
            assert api.post(base + "/lease", json={"holder": "e2e-holder-1"}).json()["epoch"] == 1
            assert cmd("identify")["status"] == "completed"
            diag = cmd("diagnostics")
            assert diag["status"] == "completed" and diag["result"]
            imu = cmd("calibrate_imu", {"seconds": 2})
            assert imu["status"] == "completed", imu["history"][-2:]
            axes = []
            for face in ("+z", "+x"):
                assert sim.ctl(f"face {face}").startswith("ok")
                time.sleep(0.3)
                a = cmd("calibrate_axes", {"seconds": 1, "face": face})
                assert a["status"] == "completed" and a["result"]["face"] == face, a["history"][-2:]
                axes.append(a)
            assert sim.ctl("hold").startswith("ok")
            enc = cmd("check_encoders", {"seconds": 3}, final=False)
            time.sleep(0.6)
            for i in range(3):
                sim.ctl(f"spin {i} 20")
            enc = wait_cmd(api, enc["id"])
            assert enc["status"] == "completed", enc["history"][-2:]
            cal = api.post(base + "/calibrations", json={"commands": {"imu": imu["id"], "axes": [a["id"] for a in axes], "encoders": enc["id"]}})
            assert cal.status_code == 201, cal.text
            cal = cal.json()
            assert cal["document"]["imu"]["to_body"] == [1, 0, 0, 0, 1, 0, 0, 0, 1] and cal["document"]["wheel_directions_confirmed"] is True
            assert {e["origin"] for e in cal["document"]["evidence"]} == {"backend-command-log"}
            # ---------------------------------------------------------------- approved configuration, self-test
            cfg = api.post(base + "/configs", json={"recipe": "edge-hold-10s", "calibration": cal["id"]}).json()
            H = cfg["id"]
            r = api.post(base + "/commands", json={"action": "start_experiment", "holder": "e2e-holder-1", "config_hash": H, "params": {"duration_s": 3}})
            assert r.status_code == 409 and r.json()["error"]["code"] == "config_not_applied"
            ap = cmd("apply_config", config_hash=H)
            assert ap["status"] == "completed", ap["history"][-2:]
            wait_view(api, did, lambda v: (v["state"] or {}).get("config_hash") == H, what="config applied")
            st = cmd("self_test", ttl=8000)
            assert st["status"] == "completed", st["history"][-3:]
            wait_view(api, did, lambda v: (v["state"] or {}).get("state") == "READY", what="READY")
            # ---------------------------------------------------------------- experiment: only after the local enable
            assert api.post(base + "/recordings/start", json={"name": "e2e edge"}).status_code == 201
            ex = cmd("start_experiment", {"duration_s": 3}, ttl=10000, config_hash=H, final=False)
            c = wait_cmd(api, ex["id"], statuses=("executing", "failed", "rejected", "expired"))
            assert c["status"] == "executing" and "local enable" in (c["history"][-1].get("reason") or "")
            time.sleep(1.0)
            assert (api.get(base).json()["state"] or {}).get("state") == "READY"      # nothing moves without the press
            assert sim.ctl("arm-press").startswith("ok")
            done = wait_cmd(api, ex["id"], timeout=15)
            assert done["status"] == "completed" and done["result"]["ended"] == "duration reached", done["history"][-3:]
            time.sleep(0.5)
            rec = api.post(base + "/recordings/stop")
            assert rec.status_code == 201, rec.text
            rec = rec.json()
            assert rec["synthetic"] is True and rec["device_link"]["device_id"] == did and rec["device_link"]["config_hash"] == H
            assert rec["quality"]["n"] > 50
            # ---------------------------------------------------------------- the twin and the comparison
            tw = api.post("/api/v6/twin/simulate", json={"device_id": did, "recipe": "edge-hold-10s", "calibration": cal["id"]})
            assert tw.status_code == 202, tw.text
            jid = tw.json()["job"]["id"]
            t0 = time.time()
            while time.time() - t0 < 120:
                j = api.get(f"/api/v1/jobs/{jid}").json()
                if j["state"] in ("complete", "failed", "cancelled"):
                    break
                time.sleep(0.2)
            assert j["state"] == "complete", j
            cmpr = api.post("/api/v6/twin/compare", json={"run_id": j["result_ref"]["id"], "recording_id": rec["id"]})
            assert cmpr.status_code == 200, cmpr.text
            cmpr = cmpr.json()
            assert cmpr["synthetic"] is True and cmpr["evidence"]["admissible_as_validation_evidence"] is False
            # the recording's clock is moved to the start of the experiment (its first balancing frame), so the twin's
            # t = 0 and the device's start coincide: the comparison computes the attitude error over the overlap
            al = cmpr["result"]["alignment"]
            assert cmpr["result"]["errors"] == [] and "status ok" in al["recording_t0_rule"] and al["recording_t0_s"] > 0, cmpr["result"]
            assert "attitude" in cmpr["result"]["signals"] and cmpr["result"]["signals"]["attitude"]["n"] > 50, cmpr["result"]["signals"].keys()
            assert cmpr["run_config_hash"] and cmpr["recording_hash"] == rec["content_hash"]
            run = api.get(f"/api/v1/runs/{j['result_ref']['id']}").json()
            assert run["twin"]["calibration"]["id"] == cal["id"] and run["twin"]["profile"]["id"] == "aeris-ref-a1"
            # nothing promoted itself: the profile's value sources are untouched and the twin run stays NOMINAL (PRF-4)
            prof_now = api.get("/api/v6/profiles/aeris-ref-a1").json()["document"]
            assert set(prof_now["value_sources"].values()) == {"nominal-model"} and prof_now["qualification"]["status"] == "experimental"
            assert run["validation"]["status"] == "nominal" and run["validation"]["parameter_set"].startswith("profile:aeris-ref-a1:r")
            # export → reimport keeps the provenance and the units
            doc = api.get(f"/api/v1/hardware/recordings/{rec['id']}/export?format=json").json()
            assert doc["synthetic"] is True and doc["device"]["id"] == did
            back = api.post("/api/v1/hardware/recordings", json=doc)
            assert back.status_code == 201, back.text
            back = back.json()
            assert back["content_hash"] == rec["content_hash"] and back["synthetic"] is True and back["provenance"]["trust"] == "synthetic"
            nd = api.get(f"/api/v1/hardware/recordings/{rec['id']}/export?format=ndjson")
            assert nd.status_code == 200, nd.text
            hello = json.loads(nd.text.splitlines()[0])
            assert hello["type"] == "hello" and hello["device"]["kind"] == "emulator" and hello["synthetic"] is True
            # ---------------------------------------------------------------- the network route (gateway)
            bridge = Lines([PY, os.path.join(FW, "tools", "synthetic_net_bridge.py"), "--device", f"127.0.0.1:{net}", "--backend", f"ws://127.0.0.1:{port}"])
            wait_view(api, did, lambda v: v["routes"] == ["companion", "gateway"], what="gateway route authenticated")
            obs = cmd("identify", route="gateway")
            assert obs["status"] == "rejected", obs["history"]                   # observer while the USB host is attached
            assert cmd("stop", route="gateway", holder=None)["status"] == "completed"   # stop: always, no lease needed
            n_before = api.get(base + "/frames", params={"after": 0, "limit": 1}).json()["last_n"]
            comp.stop()
            comp = None
            wait_view(api, did, lambda v: v["routes"] == ["gateway"], what="companion gone")
            time.sleep(0.5)
            assert cmd("identify", route="gateway")["status"] == "completed"    # the network session supervises now
            # ---------------------------------------------------------------- telemetry continuity across routes
            # the companion carried the stream; the gateway continues the SAME device telemetry session: what the device
            # produced in between is resent from its ring (tlm_resume), so its frame numbers continue without a hole
            v = wait_view(api, did, lambda v: v.get("telemetry_route") == "gateway" and len(v.get("telemetry_catchups") or []) >= 1,
                          what="telemetry continued on the gateway route")
            cu = v["telemetry_catchups"][-1]
            assert cu["route"] == "gateway" and cu["ended"] == "complete" and cu["missing"] == 0, cu
            seq_continuity(api, base, n_before, min_boundaries=1)
            # the gateway connection drops and comes back: the frames produced while no route carried the stream are
            # resent, each fed once and in order
            bridge.stop()
            wait_view(api, did, lambda v: v["routes"] == [] and v.get("telemetry_route") is None, what="gateway gone")
            time.sleep(1.5)                                                       # ≈ 75 frames at 50 Hz into the device's ring
            bridge = Lines([PY, os.path.join(FW, "tools", "synthetic_net_bridge.py"), "--device", f"127.0.0.1:{net}", "--backend", f"ws://127.0.0.1:{port}"])
            v = wait_view(api, did, lambda v: v["routes"] == ["gateway"] and len(v.get("telemetry_catchups") or []) >= 2, what="gateway reconnected and caught up")
            cu = v["telemetry_catchups"][-1]
            assert cu["ended"] == "complete" and cu["missing"] == 0 and cu["recovered"] >= 50, cu
            seq_continuity(api, base, n_before, min_boundaries=2)
            # ---------------------------------------------------------------- lease takeover, revocation
            assert api.post(base + "/lease", json={"holder": "e2e-holder-2", "takeover": True}).json()["epoch"] == 2
            r = api.post(base + "/commands", json={"action": "identify", "holder": "e2e-holder-1"})
            assert r.status_code == 409 and r.json()["error"]["code"] == "lease_required"
            assert cmd("identify", holder="e2e-holder-2", route="gateway")["status"] == "completed"
            assert api.post(base + "/revoke").status_code == 200
            bridge.wait_for(lambda l: l.startswith("bridge ended"), 10, "revoked connection closed")
            bridge.stop()
            bridge = Lines([PY, os.path.join(FW, "tools", "synthetic_net_bridge.py"), "--device", f"127.0.0.1:{net}", "--backend", f"ws://127.0.0.1:{port}"])
            line = bridge.wait_for(lambda l: l.startswith("bridge ended"), 15, "refused authentication")
            assert "4401" in line, line                                          # a revoked credential is refused
            assert api.get(base).status_code == 404
        finally:
            for p in (bridge, comp, sim):
                if p is not None:
                    p.stop()


def test_two_owners_two_concurrent_synthetic_devices(tmp_path, hostsim_bin):
    """jwt mode: alice and bob each pair their own synthetic device through their own companion. Both stay connected;
    each sees only their own device, telemetry and recordings; cross-owner REST, WebSocket, command and pairing attempts
    are refused."""
    import asyncio
    from websockets.asyncio.client import connect
    from websockets.exceptions import ConnectionClosed
    from aeris_backend.api.app import create_app
    from aeris_backend.tools import devauth
    d = str(tmp_path / "dev-auth")
    devauth.init(d)
    tok = {who: devauth.token(d, who) for who in ("alice", "bob")}
    hdr = {who: {"Authorization": "Bearer " + t} for who, t in tok.items()}
    port = free_port()
    app = create_app({"db": str(tmp_path / "aeris.sqlite3"), "workers": 1, "max_jobs": 1, "origins": ["http://localhost:8000"],
                      "telemetry_dir": str(tmp_path / "tel"), "auth_env": devauth.env(d)})
    origin = f"http://127.0.0.1:{port}"
    procs = []
    with Server(app, port):
        try:
            sims, comps, ids = {}, {}, {}
            for who in ("alice", "bob"):
                usb, net, ctl = free_port(), free_port(), free_port()
                sdir = tmp_path / who
                sdir.mkdir()
                sim = Lines([hostsim_bin, "--plant", PLANT_EDGE, "--usb-tcp", str(usb), "--net-tcp", str(net), "--ctl-tcp", str(ctl),
                             "--device-id", f"synthetic-{who}-0001", "--key-file", str(sdir / "key.pem"), "--nvs-file", str(sdir / "nvs.bin")])
                procs.append(sim)
                sim.wait_for(lambda l: l.startswith("READY"), 10, "READY")
                sim.ctl_sock = socket.create_connection(("127.0.0.1", ctl), timeout=5)
                sim.ctl_file = sim.ctl_sock.makefile("r")
                sim.usb = usb
                sims[who] = sim
                ids[who] = f"synthetic-{who}-0001"
            api = httpx.Client(base_url=origin, timeout=30)
            # without a token the relay refuses the companion
            nobody = Lines([PY, "-m", "aeris_backend.companion", "--backend", origin, "--tcp", f"127.0.0.1:{sims['alice'].usb}"], cwd=os.path.dirname(HERE),
                           env={k: v for k, v in os.environ.items() if k != "AERIS_TOKEN"})
            procs.append(nobody)
            assert nobody.p.wait(15) != 0
            assert any('"code": 4401' in l for l in nobody.all), nobody.all[-5:]
            for who in ("alice", "bob"):
                env = dict(os.environ, AERIS_TOKEN=tok[who])
                comp = Lines([PY, "-m", "aeris_backend.companion", "--backend", origin, "--tcp", f"127.0.0.1:{sims[who].usb}", "--pair", "--name", f"{who}'s cube"],
                             cwd=os.path.dirname(HERE), env=env)
                procs.append(comp)
                comps[who] = comp
                comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") == "waiting_for_local_confirmation", 15, f"{who}: confirmation")
                sims[who].ctl_sock.sendall(b"arm-press\n")
                sims[who].ctl_file.readline()
                assert comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") in ("paired", "failed"), 10)["status"] == "paired"
            # both connected at once; each owner sees exactly their own device
            for who in ("alice", "bob"):
                devs = api.get("/api/v6/devices", headers=hdr[who]).json()["devices"]
                assert [x["id"] for x in devs] == [ids[who]] and devs[0]["connected"] is True and devs[0]["owner"] == f"aeris-dev-issuer|{who}"
            other = {"alice": "bob", "bob": "alice"}
            for who in ("alice", "bob"):
                b = f"/api/v6/devices/{ids[other[who]]}"
                assert api.get(b, headers=hdr[who]).status_code == 404
                assert api.post(b + "/commands", json={"action": "stop"}, headers=hdr[who]).status_code == 404
                assert api.post(b + "/lease", json={"holder": "intruder-0001"}, headers=hdr[who]).status_code == 404
                assert api.get(b + "/frames", headers=hdr[who]).status_code == 404
            # each owner applies an approved configuration: telemetry flows per device
            for who in ("alice", "bob"):
                b = f"/api/v6/devices/{ids[who]}"
                h = hdr[who]
                wait_view_h = lambda pred, what: _wait(lambda: api.get(b, headers=h).json(), pred, what)
                wait_view_h(lambda v: v["state"] is not None, f"{who}: session")
                assert api.post(b + "/lease", json={"holder": f"{who}-holder-1"}, headers=h).status_code == 200
                cfg = api.post(b + "/configs", json={"recipe": "edge-hold-10s"}, headers=h).json()
                r = api.post(b + "/commands", json={"action": "apply_config", "holder": f"{who}-holder-1", "config_hash": cfg["id"]}, headers=h).json()
                assert _wait(lambda: api.get(f"/api/v6/commands/{r['id']}", headers=h).json(), lambda c: c["status"] in ("completed", "failed", "rejected"),
                             f"{who}: apply")["status"] == "completed"
                assert api.get(f"/api/v6/commands/{r['id']}", headers=hdr[other[who]]).status_code == 404     # another owner's command id
                assert api.post(b + "/recordings/start", json={"name": f"{who} rec"}, headers=h).status_code == 201

            async def live_frames(who, device_id):
                t = api.post("/api/v6/tickets", json={"purpose": "live"}, headers=hdr[who]).json()["ticket"]
                devs_seen, frames = set(), 0
                async with connect(f"ws://127.0.0.1:{port}/api/v6/devices/{device_id}/live?ticket={t}") as ws:
                    t0 = time.time()
                    while time.time() - t0 < 4 and frames < 50:
                        m = json.loads(await asyncio.wait_for(ws.recv(), 5))
                        if m["type"] == "frames":
                            frames += len(m["frames"])
                            devs_seen.add((m.get("provenance") or {}).get("device_id"))
                            assert (m.get("provenance") or {}).get("synthetic") is True
                return frames, devs_seen

            async def refused(who, device_id):
                t = api.post("/api/v6/tickets", json={"purpose": "live"}, headers=hdr[who]).json()["ticket"]
                try:
                    async with connect(f"ws://127.0.0.1:{port}/api/v6/devices/{device_id}/live?ticket={t}") as ws:
                        await asyncio.wait_for(ws.recv(), 5)
                except ConnectionClosed as e:
                    return e.rcvd.code if e.rcvd else None
                return None

            for who in ("alice", "bob"):
                n, seen = asyncio.run(live_frames(who, ids[who]))
                assert n >= 20 and seen == {ids[who]}, (who, n, seen)
                assert asyncio.run(refused(who, ids[other[who]])) == 4404
            for who in ("alice", "bob"):
                rec = api.post(f"/api/v6/devices/{ids[who]}/recordings/stop", headers=hdr[who])
                assert rec.status_code == 201, rec.text
                rid = rec.json()["id"]
                assert api.get(f"/api/v1/hardware/recordings/{rid}", headers=hdr[who]).json()["owner"] == f"aeris-dev-issuer|{who}"
                assert api.get(f"/api/v1/hardware/recordings/{rid}", headers=hdr[other[who]]).status_code == 404
                listed = [x["id"] for x in api.get("/api/v1/hardware/recordings", headers=hdr[other[who]]).json()["recordings"]]
                assert rid not in listed
            # bob's companion attached to alice's cube cannot pair it: it belongs to alice
            comps["alice"].stop()
            _wait(lambda: api.get(f"/api/v6/devices/{ids['alice']}", headers=hdr["alice"]).json(), lambda v: not v["connected"], "alice's companion gone")
            env = dict(os.environ, AERIS_TOKEN=tok["bob"])
            steal = Lines([PY, "-m", "aeris_backend.companion", "--backend", origin, "--tcp", f"127.0.0.1:{sims['alice'].usb}", "--pair"],
                          cwd=os.path.dirname(HERE), env=env)
            procs.append(steal)
            m = steal.json_wait(lambda m: m.get("type") == "device", 15)
            assert m["paired_to_you"] is False
            steal.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") == "waiting_for_local_confirmation", 10)
            sims["alice"].ctl_sock.sendall(b"arm-press\n")
            sims["alice"].ctl_file.readline()
            out = steal.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") in ("paired", "failed"), 10)
            assert out["status"] == "failed" and "another account" in out["reason"]
            assert api.get(f"/api/v6/devices/{ids['alice']}", headers=hdr["alice"]).status_code == 200
            assert [x["id"] for x in api.get("/api/v6/devices", headers=hdr["bob"]).json()["devices"]] == [ids["bob"]]
            assert api.get(f"/api/v6/devices/{ids['bob']}", headers=hdr["bob"]).json()["connected"] is True     # B never disturbed
        finally:
            for p in procs:
                try:
                    if getattr(p, "ctl_sock", None):
                        p.ctl_sock.sendall(b"quit\n")
                except OSError:
                    pass
                p.stop()


def _wait(get, pred, what, timeout=15.0):
    t0 = time.time()
    v = None
    while time.time() - t0 < timeout:
        v = get()
        if pred(v):
            return v
        time.sleep(0.05)
    raise AssertionError(f"timed out waiting for {what}: {json.dumps(v)[:500]}")


def test_companion_over_a_real_serial_device(tmp_path, hostsim_bin):
    """CON-2: the companion relays a REAL operating-system serial device — the native synthetic device's pseudo-terminal,
    opened by pyserial exactly as a board's /dev/ttyACM0 would be — to the backend: pairing after the local press,
    the lease, commands with results over the serial line. (A pseudo-terminal, not a USB-serial adapter: the port's
    driver and cable are not exercised.)"""
    from aeris_backend.api.app import create_app
    port, net, ctl = free_port(), free_port(), free_port()
    app = create_app({"db": str(tmp_path / "aeris.sqlite3"), "workers": 1, "max_jobs": 1, "telemetry_dir": str(tmp_path / "tel")})
    origin = f"http://127.0.0.1:{port}"
    did = "synthetic-pty-0001"
    sim = comp = None
    with Server(app, port):
        try:
            sim = Lines([hostsim_bin, "--plant", PLANT_EDGE, "--pty", "--net-tcp", str(net), "--ctl-tcp", str(ctl), "--device-id", did,
                         "--key-file", str(tmp_path / "device-key.pem"), "--nvs-file", str(tmp_path / "device-nvs.bin")])
            pty_path = sim.wait_for(lambda l: l.startswith("PTY "), 10, "the pseudo-terminal").split(" ", 1)[1].strip()
            sim.wait_for(lambda l: l.startswith("READY"), 10, "READY")
            fd = os.open(pty_path, os.O_RDWR | os.O_NOCTTY)
            try:
                assert os.isatty(fd)                                                  # a terminal device, like a USB CDC port
            finally:
                os.close(fd)
            cs = socket.create_connection(("127.0.0.1", ctl), timeout=5)
            cf = cs.makefile("r")

            def ctl_(line):
                cs.sendall((line + "\n").encode())
                return cf.readline().strip()

            api = httpx.Client(base_url=origin, timeout=30)
            comp = Lines([PY, "-m", "aeris_backend.companion", "--backend", origin, "--serial", pty_path, "--pair", "--name", "pty cube"],
                         cwd=os.path.dirname(HERE))
            dev = comp.json_wait(lambda m: m.get("type") == "device", 15, "the device on the relay")
            assert dev["device_id"] == did and dev["synthetic"] is True and dev["paired_to_you"] is False
            comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") == "waiting_for_local_confirmation", 10, "local confirmation request")
            assert api.get("/api/v6/devices").json()["devices"] == []
            assert ctl_("arm-press").startswith("ok")
            paired = comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") in ("paired", "failed"), 10, "pairing outcome")
            assert paired["status"] == "paired", paired
            v = wait_view(api, did, lambda v: v["connected"] and v["state"] is not None, what="session over the serial device")
            assert v["routes"] == ["companion"] and v["dev_hello"]["board"]["kind"] == "emulator"
            base = f"/api/v6/devices/{did}"
            assert api.post(base + "/lease", json={"holder": "pty-holder-1"}).json()["epoch"] == 1
            for action in ("identify", "diagnostics"):
                r = api.post(base + "/commands", json={"action": action, "holder": "pty-holder-1"})
                assert r.status_code == 201, r.text
                c = wait_cmd(api, r.json()["id"])
                assert c["status"] == "completed" and c["route"] == "companion", c["history"][-2:]
            st = api.post(base + "/commands", json={"action": "stop"})
            assert wait_cmd(api, st.json()["id"])["status"] == "completed"           # stop: no lease needed
            cs.close()
        finally:
            for p in (comp, sim):
                if p is not None:
                    p.stop()


def tls_files(d):
    """A throw-away CA and a server certificate for 127.0.0.1 (ECDSA P-256), generated for this test in its temporary
    directory; nothing is kept."""
    import datetime
    import ipaddress
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
    now = datetime.datetime.now(datetime.timezone.utc)
    ca_key, key = ec.generate_private_key(ec.SECP256R1()), ec.generate_private_key(ec.SECP256R1())
    ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "AERIS test CA (loopback only, generated by the test)")])
    ku = dict(content_commitment=False, key_encipherment=False, data_encipherment=False, key_agreement=False, encipher_only=False, decipher_only=False)
    ca = (x509.CertificateBuilder().subject_name(ca_name).issuer_name(ca_name).public_key(ca_key.public_key())
          .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(minutes=5)).not_valid_after(now + datetime.timedelta(days=1))
          .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
          .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True, **ku), critical=True)
          .add_extension(x509.SubjectKeyIdentifier.from_public_key(ca_key.public_key()), critical=False)
          .sign(ca_key, hashes.SHA256()))
    cert = (x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "127.0.0.1")])).issuer_name(ca_name)
            .public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now - datetime.timedelta(minutes=5)).not_valid_after(now + datetime.timedelta(days=1))
            .add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=False, crl_sign=False, **ku), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
            .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
            .sign(ca_key, hashes.SHA256()))
    paths = {k: os.path.join(d, k) for k in ("ca.crt", "server.crt", "server.key")}
    with open(paths["ca.crt"], "wb") as f:
        f.write(ca.public_bytes(serialization.Encoding.PEM))
    with open(paths["server.crt"], "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    with open(paths["server.key"], "wb") as f:
        f.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    return paths


def test_gateway_and_companion_over_tls(tmp_path, hostsim_bin):
    """CON-3 over TLS on loopback: the backend serves https/wss with a certificate from a test CA; the companion (wss
    relay) and the device's gateway connection (the bridge standing in for the board's TLS client) verify it; a client
    without that CA is refused by certificate verification before anything is sent; the device authenticates on the
    gateway with its key and supervises once the USB host has left. The board's own TLS client (ESP-IDF esp-tls with
    the CA bundle) is not exercised here."""
    import ssl
    from aeris_backend.api.app import create_app
    tls = tls_files(str(tmp_path))
    port, usb, net, ctl = free_port(), free_port(), free_port(), free_port()
    app = create_app({"db": str(tmp_path / "aeris.sqlite3"), "workers": 1, "max_jobs": 1, "telemetry_dir": str(tmp_path / "tel")})
    origin = f"https://127.0.0.1:{port}"
    did = "synthetic-e2e-0001"
    bridge_py = os.path.join(FW, "tools", "synthetic_net_bridge.py")
    env_ca = dict(os.environ, SSL_CERT_FILE=tls["ca.crt"])
    env_plain = {k: v for k, v in os.environ.items() if k not in ("SSL_CERT_FILE", "SSL_CERT_DIR")}
    sim = comp = br = bad = None
    with Server(app, port, ssl_certfile=tls["server.crt"], ssl_keyfile=tls["server.key"]):
        try:
            api = httpx.Client(base_url=origin, timeout=30, verify=ssl.create_default_context(cafile=tls["ca.crt"]))
            assert api.get("/api/v1/health").status_code == 200
            sim = HostSim(hostsim_bin, str(tmp_path), usb, net, ctl)
            comp = Lines([PY, "-m", "aeris_backend.companion", "--backend", origin, "--tcp", f"127.0.0.1:{usb}", "--pair", "--name", "tls cube"],
                         cwd=os.path.dirname(HERE), env=env_ca)
            comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") == "waiting_for_local_confirmation", 15, "local confirmation over wss")
            assert sim.ctl("arm-press").startswith("ok")
            assert comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") in ("paired", "failed"), 10, "pairing")["status"] == "paired"
            wait_view(api, did, lambda v: v["connected"] and v["routes"] == ["companion"], what="companion route over wss")
            # a gateway client that does not trust the test CA is refused by certificate verification
            bad = Lines([PY, bridge_py, "--device", f"127.0.0.1:{net}", "--backend", f"wss://127.0.0.1:{port}"], env=env_plain)
            line = bad.wait_for(lambda l: l.startswith("bridge ended"), 15, "the refused TLS handshake")
            assert "CERTIFICATE_VERIFY_FAILED" in line or "certificate verify failed" in line, line
            assert api.get(f"/api/v6/devices/{did}").json()["routes"] == ["companion"]
            # with the CA: the device authenticates on the gateway over TLS
            br = Lines([PY, bridge_py, "--device", f"127.0.0.1:{net}", "--backend", f"wss://127.0.0.1:{port}", "--cafile", tls["ca.crt"]], env=env_plain)
            wait_view(api, did, lambda v: v["routes"] == ["companion", "gateway"], what="gateway route over wss")
            comp.stop()
            comp = None
            wait_view(api, did, lambda v: v["routes"] == ["gateway"], what="companion gone")
            time.sleep(0.5)
            base = f"/api/v6/devices/{did}"
            assert api.post(base + "/lease", json={"holder": "tls-holder-1"}).json()["epoch"] >= 1
            r = api.post(base + "/commands", json={"action": "identify", "holder": "tls-holder-1", "route": "gateway"})
            assert r.status_code == 201, r.text
            c = wait_cmd(api, r.json()["id"])
            assert c["status"] == "completed" and c["route"] == "gateway", c["history"][-2:]
        finally:
            for p in (br, bad, comp, sim):
                if p is not None:
                    p.stop()


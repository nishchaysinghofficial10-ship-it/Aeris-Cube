"""Wheel limits, friction, lag, failure, events and allocation; sensors and estimators
(truth isolation, bias, latency, dropout, normalisation, covariance, seeded noise)."""
import math

import numpy as np
import pytest

from aeris_backend.actuators import Wheel, WheelSet, allocate_bounded, least_squares_plane
from aeris_backend.config.normalize import default_wheels, normalize
from aeris_backend.constants import CH, DEG, NOMINAL, QEQ, RPM
from aeris_backend.estimation import ComplementaryAttitude, Mekf
from aeris_backend.physics.quaternion import angle_between, axis_angle, qmul, qnorm, up_in_body
from aeris_backend.rng import Rng, derive_seed
from aeris_backend.sensors import Imu3D
from aeris_backend.simulation import simulate
from conftest import engine_for

W0 = default_wheels(NOMINAL)[0]


def test_current_back_emf_and_speed_limits():
    w = Wheel(W0, 1.0)
    assert w.avail(10, 0) == pytest.approx(w.taumax)                      # current limit
    assert w.avail(-10, 100) == pytest.approx(-w.taumax)                  # braking: current limit only
    om = 0.9 * w.wnl
    lim = w.kt * (w.Vs - w.ke * om) / w.R
    assert w.avail(10, om) == pytest.approx(min(w.taumax, lim))           # back-EMF limit when accelerating
    assert w.avail(1e-3, w.wmax) == 0.0                                   # speed cut-off: no torque further
    assert w.avail(-1e-3, w.wmax) == pytest.approx(-1e-3)                 # braking still allowed at the limit


def test_health_degradation_and_event_caps():
    w = Wheel(dict(W0, health=0.5), 1.0)
    assert w.avail(10, 0) == pytest.approx(0.5 * w.taumax)
    w.deg_health = 0.4
    assert w.avail(10, 0) == pytest.approx(0.2 * w.taumax)
    w.deg_health = None
    w.torque_cap = 0.01
    assert w.avail(10, 0) == pytest.approx(0.01)
    w.torque_cap = None
    w.speed_cap = 1000 * RPM
    assert w.avail(1e-3, 1000 * RPM) == 0.0


def test_friction_model():
    w = Wheel(W0, 1.0)
    assert w.friction(100.0) == pytest.approx(W0["cv"] * 100 + W0["cc"] * math.tanh(100))
    assert w.friction(0.0) == 0.0


def test_speed_saturation_is_loss_of_authority_not_clipping():
    """A wheel pushed to its limit stops receiving accelerating torque; its speed is never clamped
    by the integrator (it may exceed the limit only through the dynamics, e.g. body coupling)."""
    r = simulate({"mode": "edge", "controller": {"type": "pid"}, "comOffset_m": 0.004, "params": {"wmaxRpm": 1500}, "duration_s": 12, "record_hz": 50})
    m = r["metrics"]
    assert m["speedLimited_s"] > 0
    assert r["outcome"]["code"] in ("fallen", "drifting")
    assert any(e["type"] == "speed_limit" for e in r["timeline"]["events"])


def test_motor_lag_first_order_response():
    from conftest import const_torque
    raw = {"mode": "edge", "controller": {"type": "none"}, "actuator": {"motor_lag_ms": 50}, "initial": {"tilt_deg": 0}, "duration_s": 0.3, "record_hz": 500}
    eng = engine_for(raw, g=0.0, controller=const_torque((0.05, 0, 0)))
    S = eng.run()["samples"]["cols"]
    i = min(range(len(S["t"])), key=lambda k: abs(S["t"][k] - 0.05))
    assert S["T_x"][i] == pytest.approx(0.05 * (1 - math.exp(-(0.05 + 0.002) / 0.05)), rel=2e-3)   # applied after the update at t


def test_failure_zero_motor_torque_friction_remains():
    r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "events": [{"type": "wheel_failure", "wheel": "x", "t_s": 1.0}], "duration_s": 3, "record_hz": 50})
    S = r["samples"]["cols"]
    after = [T for t, T in zip(S["t"], S["T_x"]) if t >= 1.0]
    assert all(T == 0.0 for T in after)
    assert "x" in r["failedWheels"]


def test_failure_with_duration_clears():
    r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "events": [{"type": "wheel_failure", "wheel": "y", "t_s": 1.0, "duration_s": 0.5}], "duration_s": 3, "record_hz": 50})
    types = [e["type"] for e in r["timeline"]["events"]]
    assert "wheel_clearance" in types
    S = r["samples"]["cols"]
    assert any(abs(T) > 0 for t, T in zip(S["t"], S["T_y"]) if t >= 1.6)


def test_legacy_reallocation_least_squares_on_tilt_plane():
    u = CH
    cols = [(1.0, 0, 0), (0, 1.0, 0)]
    target = (0.02, -0.01, 0.005)
    T = least_squares_plane(cols, target, u)
    from aeris_backend.physics.quaternion import proj_on
    P = [proj_on(c, u) for c in cols]
    got = np.array(P).T @ np.array(T)
    want = np.array(proj_on(target, u))
    # the residual is orthogonal to the span of the projected columns (least-squares optimality)
    res = want - got
    for c in P:
        assert abs(np.dot(res, c)) < 1e-15


def test_bounded_allocation_respects_bounds_and_reports_residual():
    A = np.array([[1, 0, 0, 1 / math.sqrt(3)], [0, 1, 0, 1 / math.sqrt(3)], [0, 0, 1, 1 / math.sqrt(3)]])
    lo, hi = [-0.1] * 4, [0.1] * 4
    T = allocate_bounded(A, [0.25, 0.0, 0.0], lo, hi)
    assert all(-0.1 - 1e-12 <= x <= 0.1 + 1e-12 for x in T)
    assert np.linalg.norm(A @ T - [0.25, 0, 0]) > 0            # infeasible request: the residual is not hidden
    T2 = allocate_bounded(A, [0.05, -0.02, 0.01], lo, hi)
    assert np.allclose(A @ T2, [0.05, -0.02, 0.01], atol=1e-10)


# ---------------------------------------------------------------- sensors and estimators
def cfg_corner(**kw):
    c, _ = normalize(dict({"mode": "corner"}, **kw))
    return c


def test_seeded_noise_reproducible_and_seed_dependent():
    a, b, c = Rng(5), Rng(5), Rng(6)
    xa = [a.n() for _ in range(100)]
    assert xa == [b.n() for _ in range(100)]
    assert xa != [c.n() for _ in range(100)]
    assert derive_seed(1, 2, "noise") == derive_seed(1, 2, "noise") != derive_seed(1, 3, "noise")


def test_latency_delays_delivery_and_keeps_timestamps():
    cfg = cfg_corner(sensor={"latency_ms": 10})
    imu = Imu3D(cfg, Rng(1), 0.002)
    for k in range(10):
        imu.measure(k * 0.002, QEQ, (0, 0, 0), (0, 0, 0))
    got = imu.deliver(0.012)
    assert [round(s.t, 6) for s in got] == [0.0, 0.002]
    assert len(imu.deliver(0.018)) == 3


def test_dropout_fraction():
    cfg = cfg_corner(sensor={"dropout": 0.3})
    imu = Imu3D(cfg, Rng(2), 0.002)
    for k in range(5000):
        imu.measure(k * 0.002, QEQ, (0, 0, 0), (0, 0, 0))
    frac = imu.dropped / 5000
    assert abs(frac - 0.3) < 4 * math.sqrt(0.3 * 0.7 / 5000)


def static_run(E, cfg, qt, n=3000, seed=7):
    imu = Imu3D(cfg, Rng(seed), 0.002)
    est = E(cfg, QEQ)
    norms = []
    for k in range(n):
        imu.measure(k * 0.002, qt, (0, 0, 0), (0, 0, 0))
        for s in imu.deliver(k * 0.002):
            est.process(s)
        norms.append(math.sqrt(sum(x * x for x in est.q)))
    return est, imu, norms


def test_mekf_tilt_converges_bias_estimated_on_observable_axes_quaternion_normalised():
    # bias vector with a horizontal component (observable through gravity at this attitude)
    cfg = cfg_corner(estimator={"type": "mekf"}, sensor={"gyro_bias_dps": 0.0})
    qt = qnorm(qmul(QEQ, axis_angle((1, -1, 0), 3 * DEG)))
    imu_bias = np.array([0.6, -0.4, 0.1]) * DEG
    import aeris_backend.sensors as SN
    orig = SN.Imu3D.__init__

    def init(self, *a, **k):
        orig(self, *a, **k)
        self.b = list(imu_bias)
    SN.Imu3D.__init__ = init
    try:
        est, imu, norms = static_run(Mekf, cfg, qt, n=6000)
    finally:
        SN.Imu3D.__init__ = orig
    up_t, up_e = up_in_body(qt), up_in_body(est.q)
    tilt_err = math.degrees(math.acos(min(1, sum(a * b for a, b in zip(up_t, up_e)))))
    assert tilt_err < 0.05
    assert max(abs(n - 1) for n in norms) < 1e-12
    # the bias component perpendicular to the vertical is estimated; the vertical one is not observable
    v = np.array(up_t)
    b_perp_true = imu_bias - v * (v @ imu_bias)
    b_perp_est = est.b - v * (v @ est.b)
    assert np.linalg.norm(b_perp_est - b_perp_true) < 0.1 * DEG
    P = est.P
    assert np.allclose(P, P.T) and np.min(np.linalg.eigvalsh(P)) > 0
    # covariance: the heading direction keeps its uncertainty, the tilt directions shrink
    Pa = P[:3, :3]
    var_up = v @ Pa @ v
    var_tilt = np.trace(Pa) - var_up
    assert var_up > 10 * var_tilt / 2


def test_complementary_filter_converges_in_tilt():
    cfg = cfg_corner(estimator={"type": "cf3d"})
    qt = qnorm(qmul(QEQ, axis_angle((0, 1, -1), 2 * DEG)))
    est, imu, _ = static_run(ComplementaryAttitude, cfg, qt)
    up_t, up_e = up_in_body(qt), up_in_body(est.q)
    tilt = math.degrees(math.acos(min(1, sum(a * b for a, b in zip(up_t, up_e)))))
    assert tilt < 0.4   # steady error ≈ gyro bias × τ for a filter without bias estimation


def test_estimator_based_controller_does_not_read_truth():
    """With an estimator, the controller's inputs are the estimate: the recorded estimate differs
    from the truth, and replacing the true state after sensing does not change the command."""
    from aeris_backend.control.controllers import Controller
    seen = []

    class Spy(Controller):
        type = "spy"

        def request(self, t, est, ww, failed):
            seen.append((t, est.q, est.w))
            from aeris_backend.control.controllers import Request
            return Request(per_wheel=[0.0, 0.0, 0.0])
    raw = {"mode": "corner", "controller": {"type": "none"}, "estimator": {"type": "mekf"}, "duration_s": 0.4, "record_hz": 50, "initial": {"tilt_deg": 0.5}}
    eng = engine_for(raw, controller=Spy)
    res = eng.run()
    S = res["samples"]["cols"]
    # the spy saw the estimated quaternion (the recorded qh columns), not the true one
    i = S["t"].index(0.2)
    t_seen = {round(t, 9): q for t, q, _ in seen}
    q_seen = t_seen[0.2]
    q_est = [S[f"qh{j}"][i] for j in range(4)]
    q_true = [S[f"q{j}"][i] for j in range(4)]
    assert np.allclose(q_seen, q_est, atol=1e-12)
    assert not np.allclose(q_seen, q_true, atol=1e-6)


def test_perfect_state_baseline_is_labelled():
    r = simulate({"mode": "corner", "duration_s": 1})
    assert r["executed"]["estimator"]["truth_access"] is True
    assert "perfect-state" in r["executed"]["estimator"]["name"]
    r2 = simulate({"mode": "corner", "estimator": {"type": "mekf"}, "duration_s": 1})
    assert r2["executed"]["estimator"]["truth_access"] is False


def test_mekf_heading_is_unobservable_from_gravity_tilt_is_not():
    """Gravity-only correction fixes tilt, not heading: the MEKF's heading uncertainty grows with time while
    its tilt uncertainty converges (no absolute yaw reference; docs/ESTIMATION.md)."""
    from aeris_backend.simulation import simulate
    st = [simulate({"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": "mekf"}, "initial": {"tilt_deg": 2}, "duration_s": d, "seed": 3})
          ["executed"]["estimator"]["stats"] for d in (2, 8)]
    assert st[1]["final_heading_sd_deg"] > st[0]["final_heading_sd_deg"] > 1.0
    assert st[1]["final_tilt_sd_deg"] < st[0]["final_tilt_sd_deg"] < 0.2

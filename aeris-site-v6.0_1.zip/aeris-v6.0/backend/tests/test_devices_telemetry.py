"""Telemetry continuity of a device across routes and reconnections (v6; DEVICE_LINK.md §7, CONNECT.md).

The device keeps one telemetry session and a ring of its last frames; the backend takes one copy of the stream (the
preferred route). When the carrier changes — the companion leaves and the gateway continues, or the gateway reconnects —
the backend asks the device to resend what followed the last frame it accepted (tlm_resume), holds the live frames
until the resent ones are in, and records what the device no longer holds as a gap (tlm_gap). Each frame reaches the
hub once and in order; nothing is invented.

Service level with scripted device messages (the device's own ring and tlm_resume are tested in firmware/tests; the
whole path with the synthetic device process in test_devices_e2e.py). Nothing here touches hardware."""
from __future__ import annotations

import json

from aeris_backend.devices import service as SVC
from aeris_backend.devices.auth import AuthConfig, Authenticator
from aeris_backend.devices.linkhost import frame
from aeris_backend.storage.sqlite import SqliteRepository
from aeris_backend.telemetry.protocol import hello_message

DID = "synthetic-continuity"
DEV_HELLO = {"kind": "dev_hello", "link": "aeris-device-link/1", "versions": [1], "device_id": DID, "boot_id": "b-1",
             "fw": {"version": "0.1.0", "actuation_build": False}, "board": {"id": "aeris-synthetic", "kind": "emulator", "synthetic": True},
             "caps": {"actions": ["identify", "diagnostics", "stop"], "controllers": ["edge-lqr"], "estimators": ["cf3d"], "imu": "lsm6dsox",
                      "motor": "odrive-cansimple", "config_schema": "aeris-device-config/1", "max_control_hz": 1000}, "limits": {}}


def tlm_hello(session):
    return hello_message(DID, "emulator", "aeris-fw 0.1.0 (test)", True, "edge", 50, session=session)


def tlm_frame(seq):
    return {"type": "frame", "t": round(seq * 0.02, 6), "seq": seq, "mode": "edge", "q": [1.0, 0.0, 0.0, 0.0], "theta": 0.0, "w": [0.0, 0.0, 0.0],
            "torque_cmd": [0.0, 0.0, 0.0], "imu": {"gyro": [0.0, 0.0, 0.0], "accel": [0.0, 0.0, 9.81]}, "status": "idle"}


def device_says(c, *msgs):
    for m in msgs:
        c.host.receive(frame(m))


def sent_to_device(c):
    out = []
    while not c.out.empty():
        for line in c.out.get_nowait().split(b"\n"):
            if line:
                out.append(json.loads(line[:-9]))
    return out


def setup(tmp_path):
    repo = SqliteRepository(str(tmp_path / "continuity.sqlite3"))
    svc = SVC.DeviceService(repo, Authenticator(AuthConfig({})))
    repo.device_register({"id": DID, "owner": "local", "pubkey": "key", "board": "aeris-synthetic", "firmware": "0.1.0", "synthetic": True,
                          "name": DID, "profile_id": "aeris-ref-a1", "profile_revision": 1, "extra": {}})
    return repo, svc


def gateway(svc, *, hello_session=None):
    """A gateway connection whose device authenticated (the challenge-response is tested in test_devices_e2e.py)."""
    c = svc.connection_open("gateway", None)
    device_says(c, DEV_HELLO)
    if hello_session:
        device_says(c, tlm_hello(hello_session))       # sent by the device at host_hello, i.e. BEFORE it authenticated
    c.owner = "local"
    c.host.accept_auth(DID)
    svc._runtime_for(c, DID, "local")
    return c


def seqs(rt):
    return [f["seq"] for f in rt.hub.recent]


def test_failover_reconnection_and_ring_gaps(tmp_path):
    repo, svc = setup(tmp_path)
    usb = svc.connection_open("companion", "local")
    device_says(usb, DEV_HELLO)
    rt = svc.runtimes[DID]
    device_says(usb, tlm_hello("b-1-1"), *[tlm_frame(i) for i in range(1, 11)])
    assert seqs(rt) == list(range(1, 11)) and rt.feeder is usb and rt.hub.connected

    # a second route attaches (its device hello and telemetry hello arrive before it authenticated): the stream stays
    # on the companion and is NOT restarted by the attachment; the gateway's copy of the same frames is not taken
    gw = gateway(svc, hello_session="b-1-1")
    for i in (11, 12):
        device_says(usb, tlm_frame(i))
        device_says(gw, tlm_frame(i))
    assert seqs(rt) == list(range(1, 13)) and rt.feeder is usb and rt.hub.counters["duplicates"] == 0

    # failover: the companion leaves; the gateway carries on with the telemetry hello it kept from before its
    # authentication and asks the device for everything after the last frame the hub accepted
    svc.connection_closed(usb, "companion stopped")
    assert rt.feeder is None and not rt.hub.connected
    sent_to_device(gw)
    device_says(gw, tlm_frame(14))                     # frame 13 was lost in transit on this route
    assert rt.feeder is gw and rt.hub.connected and rt.hub.transport["route"] == "gateway"
    req = [m for m in sent_to_device(gw) if m.get("kind") == "tlm_resume"]
    assert req == [{"kind": "tlm_resume", "session": "b-1-1", "after": 12}], req
    assert seqs(rt)[-1] == 12                          # 14 waits for 13
    device_says(gw, tlm_frame(13), tlm_frame(14), {"kind": "tlm_resumed", "session": "b-1-1", "through": 14}, tlm_frame(15))
    assert seqs(rt) == list(range(1, 16)), seqs(rt)
    assert rt.catchup is None and rt.catchups[-1]["recovered"] == 2 and rt.catchups[-1]["late"] == 1 and rt.catchups[-1]["missing"] == 0

    # the gateway reconnects; frames 16…20 were produced while no route carried them; the new connection's hello comes
    # first, live frames 21, 22 wait until the device has resent 16…22, each is fed once and in order
    svc.connection_closed(gw, "network lost")
    gw2 = gateway(svc)
    device_says(gw2, tlm_hello("b-1-1"))
    assert [m for m in sent_to_device(gw2) if m.get("kind") == "tlm_resume"] == [{"kind": "tlm_resume", "session": "b-1-1", "after": 15}]
    device_says(gw2, tlm_frame(21), tlm_frame(22))
    assert seqs(rt)[-1] == 15
    device_says(gw2, *[tlm_frame(i) for i in range(16, 23)], {"kind": "tlm_resumed", "session": "b-1-1", "through": 22}, tlm_frame(23))
    assert seqs(rt) == list(range(1, 24)), seqs(rt)
    assert rt.hub.counters["duplicates"] == 0 and rt.hub.counters["out_of_order"] == 0 and rt.hub.counters["gaps"] == 0
    assert rt.catchups[-1]["recovered"] == 7 and rt.catchups[-1]["late"] == 2

    # a longer outage: the device's ring no longer holds 24…30. It says so (tlm_gap); the hub counts the 7 frames as
    # dropped by the source and records a gap event; nothing is filled in
    svc.connection_closed(gw2, "network lost again")
    gw3 = gateway(svc)
    device_says(gw3, tlm_hello("b-1-1"), {"kind": "tlm_gap", "session": "b-1-1", "from": 24, "to": 30, "reason": "no longer kept on the device (ring overwritten)"},
                *[tlm_frame(i) for i in range(31, 36)], {"kind": "tlm_resumed", "session": "b-1-1", "through": 35})
    assert seqs(rt)[-5:] == [31, 32, 33, 34, 35] and 24 not in seqs(rt)
    assert rt.hub.counters["gaps"] == 1 and rt.hub.counters["dropped_by_source"] == 7
    assert any(e["type"] == "gap" and "24…30" in (e["detail"] or "") for e in rt.hub.events)
    assert rt.catchups[-1]["missing"] == 7 and rt.catchups[-1]["recovered"] == 5
    sent_to_device(gw3)

    # a NEW telemetry session (e.g. a configuration was applied): nothing is requested, seq starts again
    device_says(gw3, {"type": "bye", "session": "b-1-1", "reason": "new telemetry session"}, tlm_hello("b-1-2"), tlm_frame(1), tlm_frame(2))
    assert not [m for m in sent_to_device(gw3) if m.get("kind") == "tlm_resume"]
    assert seqs(rt)[-2:] == [1, 2] and rt.last_tlm == {"session": "b-1-2", "seq": 2}
    view = svc.device_view("local", DID)
    assert view["telemetry_route"] == "gateway" and len(view["telemetry_catchups"]) == 3
    repo.close()


def test_a_catch_up_never_waits_forever(tmp_path):
    """The device does not answer the resume (an older firmware, a lost line): after CATCHUP_S the waiting live frames
    are fed in order and the hole is counted by the hub as a gap; the catch-up is reported as ended, not complete."""
    repo, svc = setup(tmp_path)
    usb = svc.connection_open("companion", "local")
    device_says(usb, DEV_HELLO, tlm_hello("b-2-1"), *[tlm_frame(i) for i in range(1, 6)])
    rt = svc.runtimes[DID]
    svc.connection_closed(usb, "unplugged")
    usb2 = svc.connection_open("companion", "local")
    device_says(usb2, DEV_HELLO, tlm_hello("b-2-1"), tlm_frame(9), tlm_frame(10))
    assert seqs(rt) == [1, 2, 3, 4, 5] and rt.catchup is not None
    svc.tick(rt.catchup["deadline"] + 0.01)
    assert rt.catchup is None and seqs(rt) == [1, 2, 3, 4, 5, 9, 10]
    assert rt.hub.counters["gaps"] == 1 and rt.hub.counters["dropped_by_source"] == 3
    assert any(e["type"] == "gap" and "6…8" in (e["detail"] or "") and "did not finish resending" in e["detail"] for e in rt.hub.events)
    assert rt.catchups[-1]["ended"].startswith("the device did not finish resending") and rt.catchups[-1]["through"] is None
    repo.close()


def test_a_hello_from_a_session_the_device_ended_requests_nothing_stale(tmp_path):
    """tlm_gap with reason session-ended (the session asked for is no longer the device's) ends the catch-up at once."""
    repo, svc = setup(tmp_path)
    usb = svc.connection_open("companion", "local")
    device_says(usb, DEV_HELLO, tlm_hello("b-3-1"), *[tlm_frame(i) for i in range(1, 4)])
    rt = svc.runtimes[DID]
    svc.connection_closed(usb, "unplugged")
    usb2 = svc.connection_open("companion", "local")
    device_says(usb2, DEV_HELLO, tlm_hello("b-3-1"))
    assert rt.catchup is not None
    device_says(usb2, {"kind": "tlm_gap", "session": "b-3-1", "reason": "session-ended", "current": "b-3-2"})
    assert rt.catchup is None and rt.catchups[-1]["ended"] == "the device's telemetry session had ended"
    repo.close()

"""Engine audit (docs/ENGINE_AUDIT.md): identities and consistency checks added in v5 next to test_physics.py
(momentum and energy of the torque-free body, motor reaction, gravity sign, gyroscopic coupling, RK4 against an
independent DOP853 solution) and test_control_metrics.py (designs, MIMO linearisation, nonlinear PD).

Each test states the tolerance it uses and why; none of them is a claim of global stability or robustness."""
from __future__ import annotations

import asyncio
import math

import numpy as np
import pytest
from scipy.linalg import expm

from aeris_backend.jobs.manager import JobManager
from aeris_backend.physics.quaternion import rot
from aeris_backend.simulation import simulate
from aeris_backend.storage.sqlite import SqliteRepository

from conftest import const_torque, engine_for

RPM = math.pi / 30
LOSSLESS = {"cv": 0, "cc": 0}


def mechanical_energy_corner(S, i, eng):
    """T + V for the corner model: body (about the pivot, wheels locked) + wheel spin + gravity."""
    w = np.array([S["wx"][i], S["wy"][i], S["wz"][i]])
    Thh = np.array(eng.design["plant"]["Thh"])
    T = 0.5 * w @ Thh @ w + 0.5 * sum(wh.Jw * (np.dot(wh.axis, w) + S[f"omega_{'xyz'[k]}"][i]) ** 2 for k, wh in enumerate(eng.wheels.wheels))
    R = np.array(rot((S["q0"][i], S["q1"][i], S["q2"][i], S["q3"][i])))
    M, rc, g = eng.design["plant"]["M"], np.array(eng.design["plant"]["rc"]), eng.cfg["params"]["g"]
    return T + M * g * (R @ rc)[2]


def test_corner_mechanical_energy_is_conserved_with_gravity_and_no_losses():
    """No friction, no control, gravity on: T + V is constant. RK4 at 4 kHz over 0.6 s of a falling, spinning
    cube: relative drift < 1e-9 (the integrator's truncation error; 4th order, see test_physics)."""
    raw = {"mode": "corner", "controller": {"type": "none"}, "params": LOSSLESS, "duration_s": 0.6, "record_hz": 500,
           "initial": {"tilt_deg": 5, "rate_dps": 30, "azimuth_deg": 70, "wheel_speeds_rpm": [2000, -900, 400]},
           "solver": {"integration_hz": 4000}, "termination": {"check_lift_off": False, "max_tilt_deg": 180}}
    eng = engine_for(raw)
    S = eng.run()["samples"]["cols"]
    E = [mechanical_energy_corner(S, i, eng) for i in range(len(S["t"]))]
    scale = max(abs(e) for e in E)
    assert max(abs(e - E[0]) for e in E) / scale < 1e-9
    assert max(S["e"]) > math.radians(20)                            # it really fell (e in rad): potential turned into motion


def test_edge_mechanical_energy_is_conserved_with_gravity_and_no_losses():
    raw = {"mode": "edge", "controller": {"type": "none"}, "params": LOSSLESS, "duration_s": 0.4, "record_hz": 500, "initial": {"tilt_deg": 2, "rate_dps": 10},
           "solver": {"integration_hz": 4000}, "termination": {"check_lift_off": False}}
    eng = engine_for(raw)
    S = eng.run()["samples"]["cols"]
    P = eng.design["plant"]
    Thh, mgl, Jw, beta = P["Thh"], P["mgl"], eng.wheels.wheels[0].Jw, P["beta"]

    def energy(i):
        # hinge coordinates: body (wheel locked) ½Θ̂θ̇², wheel ½J(θ̇ + Ω)², potential mgl·cos(θ + β) of the COM
        th, thd, Om = S["theta"][i], S["thetadot"][i], S["omega_x"][i]
        return 0.5 * Thh * thd ** 2 + 0.5 * Jw * (thd + Om) ** 2 + mgl * math.cos(th + beta)
    E = [energy(i) for i in range(len(S["t"]))]
    assert max(abs(e - E[0]) for e in E) / abs(E[0]) < 1e-9
    assert abs(S["theta"][-1]) > abs(S["theta"][0])


def test_quaternion_is_renormalised_every_step_and_drift_is_monitored(monkeypatch):
    """|q| is renormalised after every RK4 step, and the drift BEFORE renormalisation is compared with
    termination.max_quaternion_drift: a step whose norm error exceeds it ends the run as a numerical failure instead
    of being renormalised away. For a rigid rotation the RK4 norm error per step is O((|ω|Δt)⁶) — about 1e-14 at
    200 °/s and 500 Hz — so the monitor is a guard against blow-ups, exercised here by injecting a norm error."""
    raw = {"mode": "corner", "controller": {"type": "none"}, "params": LOSSLESS, "duration_s": 2.0, "record_hz": 100,
           "initial": {"tilt_deg": 0, "rate_dps": 0, "wheel_speeds_rpm": [4000, 3000, -2500]}, "termination": {"check_lift_off": False}}
    eng = engine_for(raw, g=0.0, controller=const_torque((0.01, -0.02, 0.015)))
    S = eng.run()["samples"]["cols"]
    assert eng.termination["reason"] == "duration"
    dev = max(abs(math.sqrt(sum(S[f"q{j}"][i] ** 2 for j in range(4))) - 1) for i in range(len(S["t"])))
    assert dev < 1e-14
    import aeris_backend.simulation.engine as E
    real = E.qlen
    calls = {"n": 0}

    def faulty(q):
        calls["n"] += 1
        return real(q) + (2e-4 if calls["n"] == 50 else 0.0)            # one step with a norm error above the 1e-4 default
    monkeypatch.setattr(E, "qlen", faulty)
    eng2 = engine_for(dict(raw, duration_s=0.5), g=0.0)
    eng2.run()
    assert eng2.termination["reason"] == "numerical_failure" and "quaternion norm drifted" in eng2.termination["detail"]


def test_off_diagonal_inertia_couples_the_axes_exactly_as_the_tensor_says():
    """A full base inertia tensor with products of inertia: a motor torque on wheel x alone accelerates the body
    about y and z as well. At rest the body acceleration is ω̇ = Θ̂⁻¹(−A·τ) (the motor reaction), with Θ̂ the
    body tensor about the pivot with the wheel spin inertia removed (docs/PHYSICS.md)."""
    I = [[0.0118, 0.0009, -0.0006], [0.0009, 0.0121, 0.0004], [-0.0006, 0.0004, 0.0119]]
    raw = {"mode": "corner", "controller": {"type": "none"}, "params": LOSSLESS, "duration_s": 0.02, "record_hz": 1000, "solver": {"integration_hz": 20000},
           "plant": {"base_inertia_kgm2": I, "base_com_m": [0.05, 0.05, 0.05]}, "initial": {"tilt_deg": 0, "rate_dps": 0},
           "termination": {"check_lift_off": False}}
    eng = engine_for(raw, g=0.0, controller=const_torque((0.02, 0.0, 0.0)))
    S = eng.run()["samples"]["cols"]
    Thh = np.array(eng.design["plant"]["Thh"])
    assert abs(Thh[0][1]) > 1e-4 and abs(Thh[0][2]) > 1e-4               # the products of inertia reached the model
    A = np.array([w.axis for w in eng.wheels.wheels]).T
    wd_expected = np.linalg.solve(Thh, -A @ np.array([0.02, 0.0, 0.0]))
    dt = S["t"][1] - S["t"][0]
    wd = np.array([S["wx"][1], S["wy"][1], S["wz"][1]]) / dt
    assert np.allclose(wd, wd_expected, rtol=2e-3, atol=1e-9), (wd, wd_expected)
    assert abs(wd[1]) > 0.02 * abs(wd[0]) and abs(wd[2]) > 0.02 * abs(wd[0])   # coupling is not negligible here
    diag = dict(raw, plant={"base_inertia_kgm2": [[0.0118, 0, 0], [0, 0.0121, 0], [0, 0, 0.0119]], "base_com_m": [0.05, 0.05, 0.05]})
    S0 = engine_for(diag, g=0.0, controller=const_torque((0.02, 0.0, 0.0))).run()["samples"]["cols"]
    assert S0["wy"][1] != pytest.approx(S["wy"][1], rel=0.1)             # removing the products of inertia changes the response


def test_edge_lqr_simulation_follows_its_own_linear_design_model():
    """Controller/model consistency: with the losses the design ignores switched off (friction) and ideal sensing,
    a small-tilt LQR run follows x(t) = exp((A − BK)t)·x₀ of the design model. The remaining difference comes from
    the 500 Hz zero-order-hold control (the design is continuous) and sin e ≈ e; measured ≈ 0.8 % of the peak;
    tolerance 2 % for the tilt error and 3 % for the wheel speed."""
    raw = {"mode": "edge", "controller": {"type": "lqr"}, "params": LOSSLESS, "initial": {"tilt_deg": 0.3}, "duration_s": 1.5, "record_hz": 500}
    eng = engine_for(raw)
    T = eng.design["tilt"]
    A, B, K = np.array(T["M"]["A"]), np.array(T["M"]["B"]), np.array(T["K"]).reshape(1, 3)
    cl = sorted(np.linalg.eigvals(A - B @ K), key=lambda z: (z.real, z.imag))
    assert np.allclose(cl, sorted((complex(a, b) for a, b in T["cl"]), key=lambda z: (z.real, z.imag)), atol=1e-9)
    assert all(z.real < 0 for z in cl)
    S = eng.run()["samples"]["cols"]
    x0 = np.array([S["e"][0], S["thetadot"][0], S["omega_x"][0]])
    pe, po = max(abs(v) for v in S["e"]), max(abs(v) for v in S["omega_x"])
    err_e = err_o = 0.0
    for i in range(0, len(S["t"]), 5):
        x = expm((A - B @ K) * S["t"][i]) @ x0
        err_e = max(err_e, abs(S["e"][i] - x[0]) / pe)
        err_o = max(err_o, abs(S["omega_x"][i] - x[2]) / po)
    assert err_e < 0.02 and err_o < 0.03, (err_e, err_o)


def test_motor_speed_limit_and_torque_limit_are_respected():
    """Actuator limits: the applied torque never exceeds the torque limit and the wheel never exceeds the
    no-load speed implied by the supply (back-EMF), even under a saturating command."""
    raw = {"mode": "edge", "controller": {"type": "none"}, "initial": {"tilt_deg": 0}, "duration_s": 2.0, "record_hz": 500,
           "termination": {"check_lift_off": False, "max_tilt_deg": 180}}
    eng = engine_for(raw, g=0.0, controller=const_torque((5.0, 0, 0)))                  # 5 N·m: far above the limit
    S = eng.run()["samples"]["cols"]
    act = eng.design["actuator"]
    assert max(abs(v) for v in S["T_x"]) <= act["taumax"] * (1 + 1e-12)
    assert max(abs(v) for v in S["omega_x"]) <= act["wnl"] * (1 + 1e-9)
    assert max(S["sat"]) == 1


# ---------------------------------------------------------------- sweep execution: seeds, parallelism, restarts
SWEEP = {"name": "audit", "revision": "1.2", "mode": "montecarlo", "samples": 6, "seed": 77, "seed_strategy": "paired",
         "base": {"mode": "edge", "sensor": {"gyro_noise_dps": 0.2}, "estimator": {"type": "kf"}}, "controllers": ["lqr", "pid"],
         "variables": [{"key": "tilt_deg", "min": 0.5, "max": 5.0, "dist": "uniform"}, {"key": "com_y_mm", "min": -6, "max": 6, "dist": "normal", "mean": 0, "sd": 3}],
         "duration_s": 3, "record_hz": 10}


def run_sweep(db, workers, crash_after=None):
    """Run SWEEP to completion; with crash_after=n the process 'dies' after the n-th saved row (the fault hook of
    test_recovery.py: dispatcher cancelled, pool shut down, no clean stop) and a new manager resumes it."""
    from test_recovery import Crash, restart, run_until, shutdown

    async def go():
        if crash_after:
            jid, crashed, _ = await run_until(db, lambda m: m.submit_sweep(SWEEP), Crash("sweep.row_saved", crash_after), timeout=120)
            assert crashed
            repo, m = await restart(db, "resume", timeout=180, jid=jid)
        else:
            repo = SqliteRepository(db)
            m = JobManager(repo, workers=workers, max_jobs=1)
            await m.start()
            jid = m.submit_sweep(SWEEP)["id"]
            for _ in range(9000):
                if repo.get_job(jid)["state"] in ("complete", "failed", "cancelled"):
                    break
                await asyncio.sleep(0.02)
        sw = repo.get_sweep(repo.get_job(jid)["result_ref"]["id"])
        await shutdown(repo, m)
        return sw
    return asyncio.run(go())


def row_key(r):
    return {k: r.get(k) for k in ("index", "controller", "values", "seed", "status", "outcome", "metrics", "research", "config_hash")}


def test_sweep_rows_are_identical_serial_parallel_and_after_a_restart(tmp_path):
    """Seeds are derived from (sweep seed, strategy, point, controller), not from the order of execution, so the
    same sweep gives the same rows with 1 or 3 worker processes and after a crash-and-resume. On one platform the
    rows are bit-identical; across platforms/versions docs/REPRODUCIBILITY.md sets the tolerance."""
    a = run_sweep(str(tmp_path / "serial.sqlite3"), 1)
    b = run_sweep(str(tmp_path / "parallel.sqlite3"), 3)
    c = run_sweep(str(tmp_path / "restart.sqlite3"), 2, crash_after=4)
    for sw in (a, b, c):
        assert sw["status"] == "complete" and len(sw["rows"]) == 12
    ka = sorted((row_key(r) for r in a["rows"]), key=lambda r: r["index"])
    kb = sorted((row_key(r) for r in b["rows"]), key=lambda r: r["index"])
    kc = sorted((row_key(r) for r in c["rows"]), key=lambda r: r["index"])
    assert ka == kb == kc
    seeds = {(r["values"]["tilt_deg"], r["values"]["com_y_mm"]): set() for r in ka}
    for r in ka:
        seeds[(r["values"]["tilt_deg"], r["values"]["com_y_mm"])].add(r["seed"])
    assert all(len(s) == 1 for s in seeds.values())                    # paired: both controllers see the same noise
    assert len({next(iter(s)) for s in seeds.values()}) == 6            # different points, different seeds
    assert a["analysis"] == b["analysis"] == c["analysis"]


def test_same_seed_same_run_different_seed_different_noise():
    base = {"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": "mekf"}, "sensor": {"gyro_noise_dps": 0.3}, "initial": {"tilt_deg": 2}, "duration_s": 1.5}
    a, b, c = simulate(dict(base, seed=5)), simulate(dict(base, seed=5)), simulate(dict(base, seed=6))
    assert a["samples"]["cols"] == b["samples"]["cols"] and a["metrics"] == b["metrics"]
    assert a["samples"]["cols"]["qh0"] != c["samples"]["cols"]["qh0"]

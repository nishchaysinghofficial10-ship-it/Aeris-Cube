"""Telemetry stream identity (v5.1, review finding F2; docs/TELEMETRY.md §7).

A hub frame index n is only meaningful within one hub — one backend process. v5 clients kept their cursor across a
backend restart, so every frame of the new process (n starting again at 1) was taken for a duplicate and the live
view froze. Every hub now has a stream_id, reported with the status, every poll answer and every live batch; a poll
that names another stream is answered from the beginning of this one (stream_changed: true). A client that names no
stream (v5) is answered exactly as before. Every source here is SYNTHETIC (test hellos or the emulator)."""
from __future__ import annotations

import json
import re
import time

import pytest
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app
from aeris_backend.telemetry.emulator import Emulator
from aeris_backend.telemetry.protocol import dumps, hello_message
from aeris_backend.telemetry.stream import TelemetryHub

HELLO = hello_message("unit-test", "test", "none", True, "corner", 100)
STREAM_ID = re.compile(r"^\d{8}T\d{6}-[0-9a-f]{12}$")


def hub(frames: int) -> TelemetryHub:
    h = TelemetryHub()
    h.on_connect({"kind": "test", "address": "memory"}, 0.0)
    assert h.feed_line(dumps(HELLO), 0.0) == "hello"
    for k in range(frames):
        assert h.feed_message({"type": "frame", "seq": k, "t": 0.01 * k, "q": [1, 0, 0, 0], "w": [0, 0, 0]}, 0.01 * k) == "frame"
    return h


def ns(d):
    return [f["n"] for f in d["frames"]]


def test_every_hub_has_its_own_stream_identity():
    a, b = TelemetryHub(), TelemetryHub()
    assert STREAM_ID.match(a.stream_id) and STREAM_ID.match(b.stream_id) and a.stream_id != b.stream_id
    st = a.status(0.0)
    assert st["stream_id"] == a.stream_id and st["stream_started"] and st["segment"] == 0 and st["last_n"] == 0
    assert a.frames_after(0)["stream_id"] == a.stream_id


def test_the_polling_cursor_belongs_to_a_stream():
    h = hub(5)
    same = h.frames_after(3, stream=h.stream_id)
    assert ns(same) == [4, 5] and same["stream_changed"] is False and same["stream_id"] == h.stream_id
    other = h.frames_after(3, stream="20000101T000000-000000000000")
    assert ns(other) == [1, 2, 3, 4, 5] and other["stream_changed"] is True and other["missed"] == 0
    v5 = h.frames_after(3)                                   # a client that names no stream: the v5 answer, unchanged
    assert ns(v5) == [4, 5] and v5["stream_changed"] is False and v5["last_n"] == 5


def test_a_restarted_backend_answers_the_old_cursor_from_its_beginning():
    old = hub(500)                                           # the process before the restart: the client is at n = 500
    cursor, stream = old.status(5.0)["last_n"], old.stream_id
    new = hub(3)                                             # the process after it: n starts again at 1
    d = new.frames_after(cursor, stream=stream)
    assert d["stream_changed"] is True and ns(d) == [1, 2, 3] and d["stream_id"] == new.stream_id != stream
    v5 = new.frames_after(cursor)                            # what a v5 client asked for: nothing (the frozen view of F2) ...
    assert ns(v5) == [] and v5["last_n"] == 3 < cursor       # ... but the counter below its cursor is visible (client fallback)


def test_within_a_stream_indices_keep_increasing_across_source_reconnects():
    h = hub(3)
    sid = h.stream_id
    h.on_disconnect("source dropped", 1.0)
    h.on_connect({"kind": "test", "address": "memory"}, 1.1)
    assert h.feed_line(dumps(HELLO), 1.1) == "hello"
    for k in range(3):                                       # the source restarts its seq and t: a new segment, same stream
        assert h.feed_message({"type": "frame", "seq": k, "t": 0.01 * k, "q": [1, 0, 0, 0], "w": [0, 0, 0]}, 1.2 + 0.01 * k) == "frame"
    all_frames = h.frames_after(0, stream=sid)
    assert ns(all_frames) == [1, 2, 3, 4, 5, 6] and h.stream_id == sid and all_frames["stream_changed"] is False
    assert [f["segment"] for f in all_frames["frames"]] == [1, 1, 1, 2, 2, 2]


# ---------------------------------------------------------------- the API of two backend processes, one after the other
def make_app(d):
    return create_app({"db": str(d / "api.sqlite3"), "workers": 1, "max_jobs": 1, "origins": ["http://localhost:8000"],
                       "telemetry_dir": str(d / "telemetry"), "telemetry_max_live": 2})


def until(fn, timeout=30, step=0.05):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v
        time.sleep(step)
    raise AssertionError("condition not reached within %ss" % timeout)


def replay_file(c, frames_expected):
    assert c.post("/api/v1/telemetry/connect", json={"source": "file", "path": "session.ndjson", "speed": 0}).status_code == 200
    return until(lambda: (lambda s: s if s["source"]["state"] == "finished" and s["last_n"] >= frames_expected else None)(c.get("/api/v1/telemetry/status").json()))


@pytest.fixture()
def data_dir(tmp_path):
    (tmp_path / "telemetry").mkdir()
    Emulator(mode="corner", rate_hz=50, seed=21).write_session(str(tmp_path / "telemetry" / "session.ndjson"), 40)
    return tmp_path


def test_api_names_the_stream_in_status_poll_and_live_batches(data_dir):
    with TestClient(make_app(data_dir)) as c:
        with c.websocket_connect("/api/v1/telemetry/live") as ws:
            first = ws.receive_json()
            sid = first["status"]["stream_id"]
            assert first["type"] == "status" and STREAM_ID.match(sid)
            assert c.post("/api/v1/telemetry/connect", json={"source": "file", "path": "session.ndjson", "speed": 0}).status_code == 200
            batch = None
            while batch is None:
                m = ws.receive_json()
                if m["type"] == "frames":
                    batch = m
            assert batch["stream"] == sid and batch["frames"] and batch["provenance"]["synthetic"] is True
        st = until(lambda: (lambda s: s if s["source"]["state"] == "finished" else None)(c.get("/api/v1/telemetry/status").json()))
        assert st["stream_id"] == sid
        p = c.get(f"/api/v1/telemetry/frames?after=0&stream={sid}").json()
        assert p["stream_id"] == sid and p["stream_changed"] is False and p["frames"][0]["n"] == 1
        # the stream parameter is checked (an id is letters, digits and . _ : -)
        assert c.get("/api/v1/telemetry/frames?after=0&stream=a%20b").status_code == 422
        assert c.get("/api/v1/telemetry/frames?after=0&stream=" + "x" * 65).status_code == 422


def test_api_restart_new_process_new_stream_old_cursor_answered_from_the_start(data_dir):
    with TestClient(make_app(data_dir)) as c:                # backend process 1
        st1 = replay_file(c, 40)
        replay_file(c, 80)                                   # a second replay: the cursor is far ahead of what process 2 will have
        st1 = c.get("/api/v1/telemetry/status").json()
        old_stream, cursor = st1["stream_id"], st1["last_n"]
        assert cursor >= 80
    with TestClient(make_app(data_dir)) as c:                # backend process 2, same database and port configuration
        st2 = replay_file(c, 40)
        assert st2["stream_id"] != old_stream and st2["last_n"] < cursor
        d = c.get(f"/api/v1/telemetry/frames?after={cursor}&stream={old_stream}").json()
        assert d["stream_changed"] is True and d["stream_id"] == st2["stream_id"] and d["frames"] and d["frames"][0]["n"] == 1
        assert [f["n"] for f in d["frames"]] == list(range(1, len(d["frames"]) + 1))
        v5 = c.get(f"/api/v1/telemetry/frames?after={cursor}").json()   # a v5 client naming no stream: unchanged v5 answer
        assert v5["frames"] == [] and v5["stream_changed"] is False and v5["last_n"] < cursor
        with c.websocket_connect("/api/v1/telemetry/live") as ws:
            first = ws.receive_json()
            assert first["type"] == "status" and first["status"]["stream_id"] == st2["stream_id"] and first["status"]["last_n"] < cursor
        json.dumps(d)                                        # the answer is plain JSON (no stream objects leak)

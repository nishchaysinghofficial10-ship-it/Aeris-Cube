"""Strict hardware ingestion and the extended sim ↔ hardware comparison.

All recordings here are SYNTHETIC (generated from a simulation inside the test and marked
`synthetic: true`); they exercise the code path and can never count as validation evidence."""
import copy
import math

import pytest

from aeris_backend.hardware.compare import compare, evaluate
from aeris_backend.hardware.ingest import parse_frame, validate_recording
from aeris_backend.simulation import simulate

GOOD_FRAME = {"t": 0.01, "seq": 3, "mode": "corner", "q": [1, 0, 0, 0], "w": [0.1, 0, 0], "wheel_rpm": [100, -20, 5],
              "torque_cmd": [0.01, 0, 0], "torque_meas": [0.009, 0, 0], "imu": {"gyro": [0.1, 0, 0], "accel": [0, 0, 9.81]}, "status": "ok"}


def test_frame_parser_is_strict():
    assert parse_frame(GOOD_FRAME)["ok"]
    bad = [dict(GOOD_FRAME, t="0.01"), dict(GOOD_FRAME, q=[1, 0, 0]), dict(GOOD_FRAME, q=[0.9, 0, 0, 0]),
           dict(GOOD_FRAME, mode="flying"), dict(GOOD_FRAME, t=-1), dict(GOOD_FRAME, w=[0.1, float("nan"), 0]), dict(GOOD_FRAME, seq=-1),
           dict(GOOD_FRAME, wheel_rpm=[1, 2, True]), dict(GOOD_FRAME, status="great"), dict(GOOD_FRAME, imu={"gyro": [0, 0], "accel": [0, 0, 9.8]}),
           {k: v for k, v in GOOD_FRAME.items() if k != "q"}]
    for f in bad:
        r = parse_frame(f)
        assert not r["ok"], f


def synthetic_recording(sim, noise=0.0, lag=0.0):
    S = sim["samples"]["cols"]
    n = len(S["t"])
    cols = {"t": [t + lag for t in S["t"]], "seq": list(range(n))}
    for j in range(4):
        cols[f"q{j}"] = list(S[f"q{j}"])
    for ax in "xyz":
        cols[f"w_{ax}"] = [v * 180 / math.pi for v in S["w" + ax]]
        cols[f"wheel_rpm_{ax}"] = [v * 30 / math.pi + noise * ((i * 7919) % 13 - 6) for i, v in enumerate(S["omega_" + ax])]
        cols[f"torque_meas_{ax}"] = list(S["T_" + ax])
        cols[f"torque_cmd_{ax}"] = list(S["T_" + ax])
    units = {"t": "s", "seq": "count", **{f"q{j}": "–" for j in range(4)}, **{f"w_{a}": "deg/s" for a in "xyz"},
             **{f"wheel_rpm_{a}": "rpm" for a in "xyz"}, **{f"torque_meas_{a}": "N·m" for a in "xyz"}, **{f"torque_cmd_{a}": "N·m" for a in "xyz"}}
    return {"schema": "aeris-hardware-run/1", "synthetic": True, "device": {"id": "SYNTHETIC-TEST", "firmware": "none"},
            "recording": {"started": "2026-09-01T10:00:00Z"}, "mode": "corner", "parameters": {"parameter_set": "nominal-design-v1"},
            "samples": {"rate_hz": 50, "cols": cols, "units": units}}


@pytest.fixture(scope="module")
def sim():
    return simulate({"mode": "corner", "controller": {"type": "lqr"}, "initial": {"tilt_deg": 3, "rate_dps": 10}, "duration_s": 3, "record_hz": 50})


def test_recording_validation_strict(sim):
    h = synthetic_recording(sim)
    v = validate_recording(h)
    assert v["ok"] and v["synthetic"] and v["quality"]["dropouts"] == 0
    assert any("SYNTHETIC" in w for w in v["warnings"])
    cases = []
    h1 = copy.deepcopy(h); h1["samples"]["cols"]["w_x"][3] = "12"; cases.append(h1)                     # string
    h2 = copy.deepcopy(h); h2["samples"]["units"]["w_x"] = "furlongs"; cases.append(h2)                  # unit
    h3 = copy.deepcopy(h); h3["samples"]["cols"]["q0"] = [2.0] * len(h3["samples"]["cols"]["q0"]); cases.append(h3)   # not unit quaternions
    h4 = copy.deepcopy(h); h4["samples"]["cols"]["t"][5] = h4["samples"]["cols"]["t"][4]; cases.append(h4)            # time not increasing
    h5 = copy.deepcopy(h); del h5["samples"]["units"]["wheel_rpm_x"]; cases.append(h5)                   # missing unit
    h6 = copy.deepcopy(h); h6["recording"]["started"] = "yesterday"; cases.append(h6)
    h7 = copy.deepcopy(h); h7["samples"]["cols"]["seq"][10] = 9; cases.append(h7)                        # duplicate sequence number
    for bad in cases:
        assert not validate_recording(bad)["ok"]


def test_dropouts_and_gaps_reported(sim):
    h = synthetic_recording(sim)
    keep = [i for i in range(len(h["samples"]["cols"]["t"])) if i not in (20, 21, 22)]
    for k in h["samples"]["cols"]:
        h["samples"]["cols"][k] = [h["samples"]["cols"][k][i] for i in keep]
    v = validate_recording(h)
    assert v["ok"] and v["quality"]["dropouts"] == 3 and v["quality"]["gaps"] == 1


def test_comparison_quaternion_rates_wheels_torque_and_alignment(sim):
    h = synthetic_recording(sim, noise=2.0, lag=0.04)
    v = validate_recording(h)
    res = compare(sim, h, v["si"], max_lag_s=0.1)
    assert res["ok"]
    assert res["alignment"]["lag_s"] == pytest.approx(0.04, abs=0.021)
    assert res["signals"]["attitude"]["rmse"] < res["signals"]["attitude"]["before_alignment"]["rmse"]
    for k in ("rate_w_x", "wheel_x", "torque_sim_vs_meas_x", "torque_cmd_vs_meas_x"):
        assert k in res["signals"], k
    assert res["signals"]["torque_cmd_vs_meas_x"]["rmse"] == 0.0
    assert any("independent attitude reference" in w for w in res["warnings"])


def test_acceptance_requires_prior_protocol_and_real_data(sim):
    h = synthetic_recording(sim)
    v = validate_recording(h)
    res = compare(sim, h, v["si"])
    proto = {"id": "AERIS-VP-0001", "created": "2026-09-01T00:00:00Z", "thresholds": {"attitude.rmse": 0.5, "wheel_x.rmse": 50}}
    acc = evaluate(res, proto, {"created": "2026-09-02T00:00:00Z", "synthetic": True})
    assert acc["all_pass"] and not acc["admissible_as_evidence"]           # synthetic data is never evidence
    late = evaluate(res, dict(proto, created="2026-09-03T00:00:00Z"), {"created": "2026-09-02T00:00:00Z", "synthetic": False})
    assert not late["admissible_as_evidence"] and any("after the recording" in n for n in late["notes"])
    ok = evaluate(res, proto, {"created": "2026-09-02T00:00:00Z", "synthetic": False})
    assert ok["admissible_as_evidence"] and "never marks a model VALIDATED" in ok["status_change"]

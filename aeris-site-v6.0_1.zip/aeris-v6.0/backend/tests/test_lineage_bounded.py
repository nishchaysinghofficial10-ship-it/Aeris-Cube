"""Bounded lineage across repeated export → replay → re-record generations (v5.2, review finding G2 of v5.1;
docs/TELEMETRY.md §6).

v5.1 nested each previous lineage object (with its own nested ancestors) into the next export: the fifth generation of
a two-segment synthetic recording produced 9.7 kB lineages and the hub refused the hello. Now the lineage is flat and
bounded, every export is checked line by line against the protocol before it is returned, and the conservative status
(synthetic / unknown / declared-physical, derived) never depends on the descriptive history. Each test runs 20 or more
generations through the actual FileReplaySource transport and the TelemetryHub recorder. Every "physical" source is an
ARTIFICIAL TEST FIXTURE that only declares kind physical; all data is SYNTHETIC test data."""
from __future__ import annotations

import asyncio
import copy
import json

import pytest
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app
from aeris_backend.hardware.ingest import validate_recording
from aeris_backend.telemetry import lineage as L
from aeris_backend.telemetry.export import ExportError, recording_to_ndjson
from aeris_backend.telemetry.lineage import LINEAGE_BUDGET, MAX_ANCESTRY, classify, collect
from aeris_backend.telemetry.protocol import MAX_LINE, MAX_LINEAGE, dumps, hello_message, parse_line, validate_frame, validate_hello
from aeris_backend.telemetry.stream import TelemetryHub
from aeris_backend.telemetry.transport import FileReplaySource

PHYS = hello_message("test-fixture-physical-declaration", "physical", "test-only", False, "corner", 100)
EMU = hello_message("test-emulator", "emulator", "test-only", True, "corner", 100)
GENERATIONS = 24


def feed_frames(hub, n0, count, t0, now):
    for k in range(count):
        assert hub.feed_message({"type": "frame", "seq": n0 + k, "t": t0 + 0.01 * k, "q": [1, 0, 0, 0], "w": [0.01 * k, 0, 0]}, now + 0.01 * k) == "frame"


def record_segments(*hellos, n=4, restart_clock=True):
    """A recording over one source segment per hello (each a new connection: a reconnect or a replaced source)."""
    h = TelemetryHub()
    h.on_connect({"kind": "tcp", "address": "test-only"}, 0.0)
    assert h.feed_line(dumps(hellos[0]), 0.0) == "hello"
    h.start_recording("lineage test fixture, not a measurement", 0.0)
    feed_frames(h, 0, n, 0.0, 0.0)
    for k, hel in enumerate(hellos[1:], 1):
        h.on_disconnect("reconnect (test)", float(k))
        h.on_connect({"kind": "tcp", "address": "test-only"}, k + 0.05)
        assert h.feed_line(dumps(hel), k + 0.1) == "hello"
        feed_frames(h, 0 if restart_clock else k * n, n, 0.0 if restart_clock else k * n * 0.01, k + 0.1)
    return h.stop_recording(50.0)


class RecordingHub(TelemetryHub):
    """The real hub; it starts recording as soon as the replay's first hello is accepted (an operator would press
    Record), so that every replayed frame is in the new recording."""

    def feed_line(self, raw, now):
        r = super().feed_line(raw, now)
        if r == "hello" and self.recording is None:
            self.start_recording("re-recorded replay (test)", now)
        return r


def actual_replay(nd):
    """The NDJSON text through the FileReplaySource transport (line splitter, pacing off) into a recording hub."""
    hub = RecordingHub()
    asyncio.run(FileReplaySource(hub, text=nd, label="recording:test", speed=0).run())
    assert hub.counters["rejected"] == 0 and hub.counters["duplicates"] == 0 and hub.counters["out_of_order"] == 0, (hub.rejected_by_reason, list(hub.last_errors)[-3:])
    return hub, hub.stop_recording(99.0)


def protocol_check(nd):
    """Every line within MAX_LINE and valid; every lineage within the budget. Returns the hellos."""
    hellos, hello = [], None
    for ln in nd.splitlines():
        assert len(ln.encode()) <= MAX_LINE
        m, err = parse_line(ln)
        assert err is None, err
        if m["type"] == "hello":
            assert validate_hello(m)["ok"], validate_hello(m)["errors"]
            lin = m["lineage"]
            assert len(json.dumps(lin, default=str)) <= LINEAGE_BUDGET < MAX_LINEAGE
            assert set(lin) <= set(L.LINEAGE_KEYS) and "ancestors" not in lin              # flat: no nested history is written
            assert all("ancestors" not in r and "ancestry" not in r for r in lin.get("ancestry", []))
            hello = m
            hellos.append(m)
        elif m["type"] == "frame":
            assert validate_frame(m, hello)["ok"]
    return hellos


def run_chain(doc, generations=GENERATIONS, expect_trust=None, check=None):
    """export → protocol check → actual replay → re-record, `generations` times; returns per-generation facts."""
    facts, n0, segs0 = [], len(doc["samples"]["cols"]["t"]), len(L.segments_of(doc))
    vals0 = doc["samples"]["cols"]["w_x"]
    base = collect((doc.get("provenance") or {}).get("lineage") or [])["generation"]      # 0 for an original recording
    for g in range(1, generations + 1):
        rid = f"AERIS-HW-{g:06d}"
        nd = recording_to_ndjson(doc, rid)
        hellos = protocol_check(nd)
        hub, new = actual_replay(nd)
        assert validate_recording(new)["ok"]
        assert len(new["samples"]["cols"]["t"]) == n0 and len(L.segments_of(new)) == segs0 and new["samples"]["cols"]["w_x"] == vals0   # every row, every segment
        c = classify(new)
        lins = [h["lineage"] for h in hellos]
        assert all(l["generation"] == base + g and l["derived_from"] == rid for l in lins)
        if g > 1:
            assert all(any(r["derived_from"] == f"AERIS-HW-{g - 1:06d}" and r["generation"] == base + g - 1 for r in l["ancestry"]) for l in lins)   # the parent
        if expect_trust:
            assert c["trust"] == expect_trust and all(l["trust"] == expect_trust for l in lins), (g, c, [l["trust"] for l in lins])
        assert c["derived"] is True
        if check:
            check(g, hellos, new, c)
        facts.append({"generation": g, "lineage_bytes": [len(json.dumps(l, default=str)) for l in lins], "refs": [len(l.get("ancestry", [])) for l in lins],
                      "omitted": [l.get("ancestry_omitted", 0) for l in lins], "trust": c["trust"]})
        doc = new
    return facts, doc


def test_reviewer_scenario_two_segment_mixed_synthetic_stays_valid_for_24_generations():
    """The v5.1 failure: physical fixture then emulator, two segments; generation 5 broke the 8 kB limit."""
    doc = record_segments(PHYS, EMU)
    assert doc["synthetic"] is True and classify(doc)["trust"] == "synthetic"

    def check(g, hellos, new, c):
        assert new["synthetic"] is True and all(h["synthetic"] is True for h in hellos)
        for l in (h["lineage"] for h in hellos):
            if g > 1:     # the original sources stay listed however long the chain: the physical fixture and the emulator
                assert l["ancestry_trust"] == "synthetic"
                origins = [r for r in l["ancestry"] if r["generation"] == 1]
                assert {(r["original_device"]["kind"], r["original_synthetic"]) for r in origins} == {("physical", False), ("emulator", True)}
    facts, last = run_chain(doc, expect_trust="synthetic", check=check)
    sizes = [max(f["lineage_bytes"]) for f in facts]
    assert max(sizes) <= LINEAGE_BUDGET and sizes[-1] == pytest.approx(sizes[-8], abs=64)          # bounded: no growth once the list is full
    assert all(x <= MAX_ANCESTRY for f in facts for x in f["refs"])
    om = [f["omitted"][0] for f in facts]
    assert om[-1] == 2 * (GENERATIONS - 1) - MAX_ANCESTRY and om == sorted(om)                      # truncation is counted, explicitly


def test_reconnect_segments_of_one_source_with_clock_restarts_stay_valid_and_synthetic():
    doc = record_segments(EMU, EMU, EMU, EMU, n=5)
    assert len(L.segments_of(doc)) == 4 and any(e["type"] == "time_base_reset" for e in doc["provenance"]["events"])
    facts, last = run_chain(doc, expect_trust="synthetic")
    assert len(L.segments_of(last)) == 4 and max(max(f["lineage_bytes"]) for f in facts) <= LINEAGE_BUDGET


def test_declared_physical_original_stays_declared_but_derived_and_never_gains_trust():
    doc = record_segments(PHYS, PHYS, restart_clock=False)
    c0 = classify(doc)
    assert c0["trust"] == "declared-physical" and c0["derived"] is False

    def check(g, hellos, new, c):
        assert [(h["device"]["kind"], h["synthetic"]) for h in hellos] == [("physical", False)] * 2          # its own declaration, kept
        assert new["synthetic"] is False and c["declared_physical"] is True and c["derived"] is True       # a copy: derived, never original
        for h in hellos:
            assert h["lineage"].get("ancestry_trust", "declared-physical") == "declared-physical"
    run_chain(doc, expect_trust="declared-physical", check=check)


def test_an_unknown_upload_replays_as_synthetic_and_stays_synthetic():
    doc = record_segments(PHYS)
    doc.pop("synthetic")
    doc["provenance"] = {}
    assert classify(doc)["trust"] == "unknown"
    first = protocol_check(recording_to_ndjson(doc, "AERIS-HW-000900"))
    assert [(h["device"]["kind"], h["synthetic"], h["lineage"]["trust"]) for h in first] == [("file-replay", True, "unknown")]
    _, new = actual_replay(recording_to_ndjson(doc, "AERIS-HW-000900"))
    assert classify(new)["trust"] == "synthetic"                          # what replayed as synthetic is recorded as synthetic
    run_chain(new, generations=20, expect_trust="synthetic")


# ---------------------------------------------------------------- v5.1 documents (nested ancestors), near the limit
def v51_lineage(depth, trust="synthetic", pad=0, nested_trust=None):
    """A lineage object as v5.1 wrote it: each generation nests the previous lineage objects ("ancestors")."""
    lin = None
    for g in range(1, depth + 1):
        cur = {"derived_from": f"AERIS-HW-{g:06d}", "exported_by": "AERIS backend NDJSON export",
               "original_device": {"id": "test-emulator" + "-" * pad, "kind": "emulator", "firmware": "test-only"},
               "original_synthetic": True if trust == "synthetic" else False, "trust": (nested_trust if (nested_trust and g < depth) else trust)}
        if lin is not None:
            cur["ancestors"] = [lin, copy.deepcopy(lin)]
        lin = cur
    return lin


def legacy_doc(lin, hello):
    doc = record_segments(hello)
    h = dict(doc["provenance"]["segments"][0]["hello"], lineage=lin)
    doc["provenance"]["segments"][0]["hello"] = h
    doc["provenance"]["hellos"] = [h]
    doc["provenance"]["lineage"] = [lin]
    return doc


def test_near_limit_v51_lineage_is_flattened_within_the_budget():
    pad = 0
    lin = v51_lineage(4, pad=pad)                                        # v5.1's shape: two segments → two nested copies per generation
    while len(json.dumps(lin, default=str)) < MAX_LINEAGE - 300:
        pad += 1
        lin = v51_lineage(4, pad=pad)
    size = len(json.dumps(lin, default=str))
    assert MAX_LINEAGE - 300 <= size <= MAX_LINEAGE                          # a v5.1 hello that was still (just) valid
    assert validate_hello(dict(EMU, lineage=lin))["ok"]
    doc = legacy_doc(lin, EMU)
    assert classify(doc)["trust"] == "synthetic"
    hellos = protocol_check(recording_to_ndjson(doc, "AERIS-HW-000777"))
    out = hellos[0]["lineage"]
    assert out["generation"] == 5 and out["ancestry_trust"] == "synthetic" and len(out["ancestry"]) <= MAX_ANCESTRY
    assert [r["generation"] for r in out["ancestry"]] == sorted((r["generation"] for r in out["ancestry"]), reverse=True)
    assert sorted(r["derived_from"] for r in out["ancestry"]) == [f"AERIS-HW-{g:06d}" for g in range(1, 5)]      # every v5.1 ancestor, once
    assert all(len(r["original_device"]["id"]) <= L.MAX_TEXT + 40 for r in out["ancestry"])                     # long fields cut, visibly
    assert any("more characters" in r["original_device"]["id"] for r in out["ancestry"])
    _, new = actual_replay(recording_to_ndjson(doc, "AERIS-HW-000777"))
    run_chain(new, generations=20, expect_trust="synthetic")


def test_a_synthetic_ancestor_nested_in_a_v51_lineage_is_never_lost():
    """Conservative: a declared-physical top level with a synthetic ancestor inside (v5.1 nesting) is synthetic;
    the same chain with only declared-physical ancestors stays declared-physical."""
    clean = legacy_doc(v51_lineage(4, trust="declared-physical"), PHYS)
    assert classify(clean)["trust"] == "declared-physical"
    mixed = legacy_doc(v51_lineage(4, trust="declared-physical", nested_trust="synthetic"), PHYS)
    c = classify(mixed)
    assert c["trust"] == "synthetic" and any("earlier generation" in r or "derives from synthetic" in r for r in c["reasons"]), c
    hellos = protocol_check(recording_to_ndjson(mixed, "AERIS-HW-000778"))
    assert all(h["synthetic"] is True and h["lineage"]["trust"] == "synthetic" and h["lineage"]["ancestry_trust"] == "synthetic" for h in hellos)
    unknown = legacy_doc(v51_lineage(3, trust="declared-physical", nested_trust="unknown"), PHYS)
    assert classify(unknown)["trust"] == "unknown"


def test_a_lineage_too_large_to_read_counts_as_unknown():
    lin = {"derived_from": "AERIS-HW-000001", "trust": "declared-physical", "original_synthetic": False}
    cur = lin
    for k in range(L.MAX_WALK + 5):                                   # a pathological chain (hand-made; v5.1 could not write it)
        nxt = {"derived_from": f"AERIS-HW-{k:06d}", "trust": "declared-physical", "original_synthetic": False}
        cur["ancestors"] = [nxt]
        cur = nxt
    h = collect([lin])
    assert h["cut"] is True and h["trust"] == "unknown"


def test_the_summary_survives_truncation_and_drops_middle_generations_first():
    refs = [{"derived_from": f"R{g}", "generation": g, "trust": "declared-physical", "original_synthetic": False} for g in range(30, 0, -1)]
    kept, dropped = L._select(refs, MAX_ANCESTRY)
    assert dropped == 30 - MAX_ANCESTRY and [r["generation"] for r in kept][:MAX_ANCESTRY - L.KEEP_ORIGINS] == list(range(30, 30 - (MAX_ANCESTRY - L.KEEP_ORIGINS), -1))
    assert [r["generation"] for r in kept][-L.KEEP_ORIGINS:] == list(range(L.KEEP_ORIGINS, 0, -1))
    # one synthetic generation in the dropped middle still makes the summary synthetic
    lin = {"derived_from": "X", "trust": "declared-physical", "original_synthetic": False, "generation": 31,
           "ancestry": refs, "ancestry_trust": "synthetic"}
    assert collect([lin])["trust"] == "synthetic"
    h = dict(PHYS, lineage=lin)
    assert L._hello_trust(h) == "synthetic"


def test_an_export_that_cannot_fit_its_lineage_is_refused_not_cut(monkeypatch):
    doc = record_segments(PHYS, EMU)
    monkeypatch.setattr(L, "LINEAGE_BUDGET", 200)
    with pytest.raises(ExportError) as ei:
        recording_to_ndjson(doc, "AERIS-HW-000001")
    assert ei.value.details[0]["path"] == "provenance.lineage" and "budget" in ei.value.details[0]["message"]


# ---------------------------------------------------------------- the API: descendants are never validation evidence
@pytest.fixture(scope="module")
def api(tmp_path_factory):
    d = tmp_path_factory.mktemp("lineage")
    app = create_app({"db": str(d / "l.sqlite3"), "workers": 1, "max_jobs": 1, "telemetry_dir": str(d / "telemetry")})
    with TestClient(app) as c:
        yield c


def test_api_twentieth_generation_descendants_are_never_validation_evidence(api):
    proto = api.post("/api/v1/validation/protocols", json={"name": "fixture thresholds", "thresholds": {"attitude.rmse": 90.0}}).json()["id"]
    job = api.post("/api/v1/simulations", json={"config": {"mode": "corner", "duration_s": 1}}).json()["job"]["id"]
    import time
    t0 = time.time()
    while api.get(f"/api/v1/jobs/{job}").json()["state"] not in ("complete", "failed") and time.time() - t0 < 120:
        time.sleep(0.1)
    run_id = api.get(f"/api/v1/jobs/{job}").json()["result_ref"]["id"]
    _, syn = run_chain(record_segments(PHYS, EMU), generations=20, expect_trust="synthetic")
    _, phys = run_chain(record_segments(PHYS), generations=20, expect_trust="declared-physical")
    for doc, label in ((syn, "synthetic"), (phys, "declared-physical")):
        up = api.post("/api/v1/hardware/recordings", json=doc)
        assert up.status_code == 201, up.text
        rid = up.json()["id"]
        assert up.json()["provenance"]["trust"] == label and up.json()["provenance"]["derived"] is True
        nd = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=ndjson")
        assert nd.status_code == 200 and all(h["lineage"]["generation"] == 21 for h in protocol_check(nd.text))
        ev = api.post("/api/v1/hardware/compare", json={"run_id": run_id, "recording_id": rid, "protocol_id": proto}).json()["evidence"]
        assert ev["admissible_as_validation_evidence"] is False, ev
        assert any(("SYNTHETIC" in x) if label == "synthetic" else ("captured from a replay" in x) for x in ev["reasons"]), ev["reasons"]
        ds = api.post("/api/v1/datasets", json={"title": f"generation 20 ({label})", "recording_ids": [rid]}).json()
        assert ds["members"][0]["trust"] == label and rid in ds["provenance"]["derived_members"]
        assert ds["provenance"]["source"] == ("synthetic-telemetry" if label == "synthetic" else "hardware")       # declared, and listed as a copy
        if label == "synthetic":
            r = api.post("/api/v1/hardware/recordings", json=dict(doc, synthetic=False))               # relabelling is refused
            assert r.status_code == 422 and any(d["path"] == "synthetic" for d in r.json()["error"]["details"])

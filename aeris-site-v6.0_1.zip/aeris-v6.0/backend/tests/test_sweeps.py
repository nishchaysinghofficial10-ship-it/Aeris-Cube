"""Sweep definitions, distribution semantics, seed strategies (paired conditions), workload
limits, row contents and the row-only analysis (Wilson intervals, McNemar)."""
import math

import numpy as np
import pytest
from scipy import stats

from aeris_backend.experiments import sweeps as SW
from aeris_backend.simulation import simulate


def D(**kw):
    base = {"schema": "aeris-sweep/1", "revision": "1.1", "base": {"mode": "edge"}, "mode": "random", "seed": 11, "samples": 20,
            "controllers": ["lqr"], "variables": [{"key": "tilt_deg", "min": 0, "max": 5}], "duration_s": 2, "record_hz": 10}
    base.update(kw)
    return base


def test_grid_points_and_totals():
    v = SW.validate_def(D(mode="grid", controllers=["pid", "lqr"], variables=[{"key": "tilt_deg", "min": 0, "max": 10, "steps": 3}, {"key": "rate_dps", "min": -20, "max": 20, "steps": 5}]))
    assert v["ok"] and v["points"] == 15 and v["total"] == 30
    specs = SW.expand(v["def"])
    assert [s["values"]["tilt_deg"] for s in specs[:6:2]] == [0.0, 0.0, 0.0]
    assert {s["controller"] for s in specs} == {"pid", "lqr"}


def test_uniform_random_matches_the_browser_stream():
    """Uniform random points use the browser's generator (mulberry32 with the sweep seed)."""
    from aeris_backend.rng import Rng
    v = SW.validate_def(D())
    R = Rng(11)
    want = [SW.js_prec10(0 + 5 * R.u()) for _ in range(20)]
    got = [s["values"]["tilt_deg"] for s in SW.expand(v["def"])]
    assert got == want


def test_bounded_normal_is_the_exact_truncated_normal():
    d = D(mode="montecarlo", samples=4000, variables=[{"key": "tilt_deg", "min": 1, "max": 6, "dist": "bounded-normal", "mean": 2, "sd": 2}])
    v = SW.validate_def(d)
    pts, _ = SW.sample_points(v["def"])
    x = np.array([p[0] for p in pts])
    assert x.min() >= 1 and x.max() <= 6                     # never outside, never clipped to a bound
    assert np.mean(np.isclose(x, 1)) == 0 and np.mean(np.isclose(x, 6)) == 0
    a, b = (1 - 2) / 2, (6 - 2) / 2
    ks = stats.kstest(x, stats.truncnorm(a, b, loc=2, scale=2).cdf)
    assert ks.pvalue > 1e-3


def test_normal_is_not_clipped_out_of_range_samples_become_invalid_rows():
    d = D(mode="montecarlo", samples=200, variables=[{"key": "tilt_deg", "min": -3, "max": 3, "dist": "normal", "mean": 0, "sd": 2}])
    v = SW.validate_def(d)
    assert any("not clipped" in w["message"] for w in v["warnings"])
    pts, notes = SW.sample_points(v["def"])
    x = np.array([p[0] for p in pts])
    outside = (x < -3) | (x > 3)
    assert outside.sum() > 0 and all(notes[i] for i in np.where(outside)[0])
    # the drawn values follow N(0, 2) — including the ones outside the range
    assert stats.kstest(x, stats.norm(0, 2).cdf).pvalue > 1e-3
    # an out-of-range tilt (beyond ±30° after the physics check? here beyond the sweep range) is still run
    # and the base engine rules decide validity; the value itself is stored unchanged
    specs = SW.expand(v["def"])
    assert sorted(s["values"]["tilt_deg"] for s in specs) == sorted(x.tolist())
    # the out-of-range draws are kept as visible invalid rows (not run, not clipped)
    rows = [SW.row_of(sp, None) for sp in specs if sp["out_of_range"]]
    assert rows and all(r["status"] == "invalid" and r["outcome"] == "invalid" and "not clipped" in r["reason"] for r in rows)


def test_pathological_truncation_rejected():
    v = SW.validate_def(D(mode="montecarlo", variables=[{"key": "tilt_deg", "min": 25, "max": 26, "dist": "bounded-normal", "mean": 0, "sd": 1}]))
    assert not v["ok"] and "numerically meaningless" in v["errors"][0]["message"]


def test_legacy_normal_maps_to_bounded_normal_with_a_note():
    d = D(mode="montecarlo", variables=[{"key": "tilt_deg", "min": 0, "max": 5, "dist": "normal", "mean": 2, "sd": 1}])
    d.pop("revision")
    v = SW.validate_def(d)
    assert v["def"]["variables"][0]["dist"] == "bounded-normal" and v["def"]["sampling_notes"]
    assert v["def"]["seed_strategy"] == "legacy"


def test_categorical_frequencies():
    d = D(mode="montecarlo", samples=3000, variables=[{"key": "torque_pct", "dist": "categorical", "values": [50, 100, 150], "probabilities": [0.2, 0.5, 0.3]}])
    v = SW.validate_def(d)
    assert v["ok"], v["errors"]
    pts, _ = SW.sample_points(v["def"])
    x = [p[0] for p in pts]
    for val, p in ((50, 0.2), (100, 0.5), (150, 0.3)):
        f = x.count(val) / len(x)
        assert abs(f - p) < 4 * math.sqrt(p * (1 - p) / len(x))


def test_paired_seed_strategy():
    d = D(mode="montecarlo", controllers=["lqr", "pid", "nlpd"], samples=5, seed_strategy="paired")
    specs = SW.expand(SW.validate_def(d)["def"])
    by_point = {}
    for s in specs:
        by_point.setdefault(s["point"], set()).add(s["seed"])
    assert all(len(v) == 1 for v in by_point.values())           # same noise seed for every controller at a point
    assert len({next(iter(v)) for v in by_point.values()}) == 5  # different points differ
    ind = SW.expand(SW.validate_def(dict(d, seed_strategy="independent"))["def"])
    assert len({s["seed"] for s in ind}) == len(ind)


def test_path_variables_and_inertia_uncertainty():
    d = D(mode="grid", base={"mode": "corner"}, variables=[{"path": "uncertainty.inertia_perturbation_kgm2.0.1", "min": -2e-4, "max": 2e-4, "steps": 3},
                                                             {"path": "wheels.1.Imax", "min": 4, "max": 8, "steps": 2}])
    v = SW.validate_def(d)
    assert v["ok"], v["errors"]
    specs = SW.expand(v["def"])
    c = specs[0]["config"]
    P = c["uncertainty"]["inertia_perturbation_kgm2"]
    assert P[0][1] == P[1][0] == -2e-4                          # kept symmetric
    assert c["wheels"][1]["Imax"] == 4
    assert SW.validate_def(D(variables=[{"path": "params.nope", "min": 0, "max": 1}]))["ok"] is False


def test_workload_limits_enforced_before_execution():
    v = SW.validate_def(D(mode="montecarlo", samples=50000, controllers=["pid", "lqr", "adp"]))
    assert not v["ok"] and "more than this backend accepts" in v["errors"][0]["message"]
    v2 = SW.validate_def(D(limits={"maxRuns_per_sweep": 10}))
    assert not v2["ok"]
    assert v2["workload"]["limits"]["maxRuns_per_sweep"] == 10


def test_rows_keep_values_seed_hash_and_invalid_runs():
    d = D(mode="grid", variables=[{"key": "tilt_deg", "min": 10, "max": 28, "steps": 2}], controllers=["lqr"])
    v = SW.validate_def(d)
    rows = [SW.row_of(sp, simulate(sp["config"])) for sp in SW.expand(v["def"])]
    assert all(r["config_hash"].startswith("sha256:") for r in rows)
    assert rows[1]["outcome"] == "fallen"
    bad = SW.row_of(SW.expand(v["def"])[0], None, error="boom")
    assert bad["status"] == "failed" and bad["reason"] == "boom"


def test_analysis_from_rows_only_wilson_and_mcnemar():
    assert SW.wilson(0, 0) == [0.0, 1.0]
    lo, hi = SW.wilson(8, 10)
    assert lo == pytest.approx(0.4902, abs=1e-3) and hi == pytest.approx(0.9433, abs=1e-3)
    rows = []
    idx = 0
    for p in range(10):
        for c, rec in (("a", p < 8), ("b", p < 3)):
            rows.append({"index": idx, "point": p, "controller": c, "mass_config": "base", "estimator": None, "values": {"tilt_deg": p}, "seed": 1,
                         "status": "ok", "outcome": "recovered" if rec else "fallen", "saturated": False, "metrics": None, "research": None})
            idx += 1
    d = SW.validate_def(D(controllers=["lqr", "pid"]))["def"]
    d["controllers"] = ["a", "b"]
    an = SW.analyze(d, rows)
    assert an["controllers"]["a"]["recovered"] == 8 and an["controllers"]["a"]["ci95"] == SW.wilson(8, 10)
    pr = an["paired"][0]
    assert (pr["only_a"], pr["only_b"], pr["both"]) == (5, 0, 3)
    assert pr["mcnemar_exact_p"] == pytest.approx(2 * 0.5 ** 5)
    assert any("not hardware reliability" in n for n in an["notes"])

"""scripts/run_tests.py: interpreter resolution, launch failures and honest summaries (v5.1, review finding F3), and
skipped / not-run TEST CASES (v5.2, review finding G3: a skipped case is never a pass or a full validation).

v5's CI passed `--browser-python backend/.venv/bin/python`; the runner checked that relative path from the repository
root, then started the browser suites in site/, where it does not exist, and died with FileNotFoundError before any
browser check or summary. Here the real runner script runs against a small FAKE repository (copied script, trivial
suites that print their counts) so each case is fast and exact: relative, absolute, PATH-name and space-containing
interpreter paths; a missing, non-executable or Playwright-less interpreter (never silently replaced); launch
failures; --skip and --only (never reported as a full validation); unknown suite names. POSIX only (the fake
interpreters are shell scripts)."""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.skipif(os.name == "nt", reason="the fake interpreters are POSIX shell scripts")
REPO = Path(__file__).resolve().parents[2]
RUNNER = Path(os.environ.get("AERIS_RUNNER_UNDER_TEST") or REPO / "scripts" / "run_tests.py")   # another runner for before/after evidence
PY = sys.executable                     # the backend's Python (it has pytest)
NODE = shutil.which("node")


def write_exec(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return path


def fake_python(path: Path, marker: str, playwright_dir: Path | None):
    """A python that says who it is (FAKE_PY) and has a Playwright package only when playwright_dir is given
    (-S keeps the real site-packages out)."""
    pp = f'PYTHONPATH="{playwright_dir}" ' if playwright_dir else 'PYTHONPATH= '
    return write_exec(path, f'#!/bin/sh\nFAKE_PY={marker} {pp}exec "{PY}" -S "$@"\n')


@pytest.fixture()
def fake(tmp_path):
    root = tmp_path / "fake repo"                                # a space in the repository path itself
    (root / "scripts").mkdir(parents=True)
    shutil.copy(RUNNER, root / "scripts" / "run_tests.py")
    (root / "backend" / "tests").mkdir(parents=True)
    (root / "backend" / "tests" / "test_ok.py").write_text("def test_ok():\n    assert True\n")
    t = root / "site" / "tests"
    t.mkdir(parents=True)
    (t / "alpha.test.js").write_text('console.log("PASS a");\nconsole.log("\\n1 / 1 alpha tests passed");\n')
    (t / "live_backend.test.js").write_text('console.log("AERIS_PYTHON=" + process.env.AERIS_PYTHON);\nconsole.log("\\n1 / 1 live backend tests passed");\n')
    (t / "browser_fake.py").write_text('import os\nprint("FAKE_PY=" + os.environ.get("FAKE_PY", "?"))\nprint("AERIS_PYTHON=" + os.environ.get("AERIS_PYTHON", ""))\n'
                                       'print("\\n1 / 1 fake browser checks passed")\n')
    pw = tmp_path / "pw"
    (pw / "playwright").mkdir(parents=True)
    (pw / "playwright" / "__init__.py").write_text("")
    fake_python(root / "backend" / ".venv" / "bin" / "python", "venv-with-playwright", pw)
    fake_python(tmp_path / "bin" / "aeris-py-with-pw", "on-path", pw)
    fake_python(tmp_path / "my env" / "bin" / "python", "spaced", pw)
    fake_python(tmp_path / "nopw" / "python", "no-playwright", None)
    (tmp_path / "not-exec").write_text("#!/bin/sh\n")
    return {"root": root, "tmp": tmp_path, "pw": pw}


def runner(f, *args, cwd=None, env=None):
    e = dict(os.environ)
    e.pop("AERIS_PYTHON", None)
    e.pop("PLAYWRIGHT_PYTHON", None)
    e.update(env or {})
    r = subprocess.run([PY, str(f["root"] / "scripts" / "run_tests.py"), *args], cwd=str(cwd or f["root"]), env=e, capture_output=True, text=True, timeout=300)
    out = Path(cwd or f["root"]) / "logs"
    summary = json.loads((out / "summary.json").read_text()) if (out / "summary.json").exists() else None
    md = (out / "SUMMARY.md").read_text() if (out / "SUMMARY.md").exists() else ""
    return r, summary, md, out


def by_name(summary):
    return {s["suite"]: s for s in summary["suites"]}


def test_relative_browser_python_from_the_repository_root_is_resolved_before_the_suites_change_directory(fake):
    """The exact v5 CI invocation shape (review F3), now run: the relative path is resolved from the root."""
    r, s, md, out = runner(fake, "--out", "logs", "--only", "browser", "--browser-python", "backend/.venv/bin/python")
    assert r.returncode == 0, r.stdout + r.stderr
    b = by_name(s)["browser:browser_fake"]
    want = os.path.join(str(fake["root"]), "backend", ".venv", "bin", "python")
    assert b["status"] == "passed" and s["interpreters"]["browser_python"]["path"] == want and s["interpreters"]["browser_python"]["source"] == "--browser-python"
    log = (out / b["log"]).read_text()
    assert "FAKE_PY=venv-with-playwright" in log and "Traceback" not in r.stderr
    assert s["verdict"].startswith("PASSED — selected suites only") and s["full_validation"] is False


def test_relative_path_from_another_working_directory(fake):
    site = fake["root"] / "site"
    r, s, md, out = runner(fake, "--out", "logs", "--only", "browser", "--browser-python", "../backend/.venv/bin/python", cwd=site)
    assert r.returncode == 0, r.stdout + r.stderr
    assert s["runner"]["started_in"] == str(site) and by_name(s)["browser:browser_fake"]["status"] == "passed"


def test_absolute_path_path_name_and_a_path_with_spaces(fake):
    for value, marker, env in ((str(fake["tmp"] / "my env" / "bin" / "python"), "spaced", None),
                               ("aeris-py-with-pw", "on-path", {"PATH": str(fake["tmp"] / "bin") + os.pathsep + os.environ["PATH"]})):
        r, s, md, out = runner(fake, "--out", "logs", "--only", "browser", "--browser-python", value, env=env)
        assert r.returncode == 0, (value, r.stdout, r.stderr)
        b = by_name(s)["browser:browser_fake"]
        assert b["status"] == "passed" and f"FAKE_PY={marker}" in (out / b["log"]).read_text()
        assert os.path.isabs(s["interpreters"]["browser_python"]["path"])
    r, s, md, out = runner(fake, "--out", "logs", "--only", "browser", "--browser-python", "my env/bin/python", cwd=fake["tmp"])    # relative, with a space
    assert r.returncode == 0 and "FAKE_PY=spaced" in (Path(fake["tmp"]) / "logs" / by_name(s)["browser:browser_fake"]["log"]).read_text()


@pytest.mark.parametrize("value,why", [("backend/.venv/bin/nope", "no such file"), ("NOT-EXEC", "not an executable file"),
                                       ("aeris-no-such-interpreter", "not found on PATH")])
def test_a_missing_or_unusable_browser_python_is_not_run_never_passed(fake, value, why):
    value = str(fake["tmp"] / "not-exec") if value == "NOT-EXEC" else value
    r, s, md, out = runner(fake, "--out", "logs", "--only", "js,browser", "--browser-python", value)
    assert r.returncode == 2, r.stdout + r.stderr                               # incomplete, not passed, not a crash
    assert "Traceback" not in r.stderr and "FileNotFoundError" not in r.stderr
    b = by_name(s)["browser:browser_fake"]
    assert b["status"] == "not run" and why in b["reason"] and b["log"] is None
    assert s["complete"] is False and s["all_passed"] is False and s["full_validation"] is False
    assert md.startswith("# Test run — INCOMPLETE") and "not run" in md and "Full validation:** no" in md
    if NODE:
        assert by_name(s)["js:alpha"]["status"] == "passed"                      # the rest of the run still ran


def test_an_explicit_python_without_playwright_is_not_replaced_by_another_one(fake):
    r, s, md, out = runner(fake, "--out", "logs", "--only", "browser", "--browser-python", str(fake["tmp"] / "nopw" / "python"))
    b = by_name(s)["browser:browser_fake"]
    assert r.returncode == 2 and b["status"] == "not run" and "Playwright is not importable" in b["reason"]
    assert not (out / "browser-browser_fake.log").exists()                     # nothing ran with a substitute interpreter


def test_default_browser_python_is_searched_and_recorded(fake):
    r, s, md, out = runner(fake, "--out", "logs", "--only", "browser")          # backend/.venv/bin/python (fake) has Playwright
    assert r.returncode == 0 and s["interpreters"]["browser_python"]["source"] == "default: the backend Python"


def test_environment_interpreters_are_resolved_like_arguments(fake):
    if not NODE:
        pytest.skip("Node.js is needed for the live suite")
    r, s, md, out = runner(fake, "--out", "logs", "--only", "live,browser", env={"AERIS_PYTHON": "backend/.venv/bin/python", "PLAYWRIGHT_PYTHON": "backend/.venv/bin/python"})
    assert r.returncode == 0, r.stdout + r.stderr
    want = os.path.join(str(fake["root"]), "backend", ".venv", "bin", "python")
    assert s["interpreters"]["backend_python"] == {"path": want, "source": "$AERIS_PYTHON", "given": "backend/.venv/bin/python", "problem": None}
    assert f"AERIS_PYTHON={want}" in (out / "live.log").read_text()             # suites get the absolute path
    assert s["interpreters"]["browser_python"]["source"] == "$PLAYWRIGHT_PYTHON"


def test_a_missing_backend_python_stops_the_suites_that_need_it(fake):
    r, s, md, out = runner(fake, "--out", "logs", "--only", "backend,browser", "--backend-python", "no/such/python")
    st = by_name(s)
    assert r.returncode == 2 and st["backend"]["status"] == "not run" and st["browser:browser_fake"]["status"] == "not run"
    assert "backend Python" in st["backend"]["reason"] and "no such file" in st["backend"]["reason"]


def test_skip_and_only_are_never_a_full_validation(fake):
    r, s, md, out = runner(fake, "--out", "logs", "--skip", "backend,js,live", "--browser-python", "backend/.venv/bin/python")
    st = by_name(s)
    assert r.returncode == 2 and st["backend"]["status"] == "skipped" and st["live"]["status"] == "skipped" and st["browser:browser_fake"]["status"] == "passed"
    assert s["verdict"].startswith("INCOMPLETE") and "skipped" in s["verdict"] and s["full_validation"] is False and s["complete"] is False
    r, s, md, out = runner(fake, "--out", "logs", "--only", "backend", "--backend-python", PY)
    assert r.returncode == 0 and s["verdict"].startswith("PASSED — selected suites only") and s["full_validation"] is False
    assert set(s["not_selected"]) == {"js:alpha", "live", "browser:browser_fake"} and "| live | not selected |" in md


def test_unknown_suite_names_are_a_usage_error(fake):
    r, s, md, out = runner(fake, "--out", "logs", "--skip", "browsr")
    assert r.returncode == 64 and "unknown suite 'browsr'" in r.stderr and s is None


def test_node_missing_means_not_run(fake):
    r, s, md, out = runner(fake, "--out", "logs", "--only", "js", env={"PATH": str(fake["tmp"] / "bin")})
    assert r.returncode == 2 and by_name(s)["js:alpha"]["status"] == "not run" and "Node.js not found" in by_name(s)["js:alpha"]["reason"]


def test_everything_selected_and_passing_is_a_full_validation(fake):
    if not NODE:
        pytest.skip("Node.js is needed for the JavaScript suites")
    r, s, md, out = runner(fake, "--out", "logs", "--backend-python", PY, "--browser-python", "backend/.venv/bin/python")
    assert r.returncode == 0, r.stdout + r.stderr
    assert s["verdict"] == "PASSED — all 4 suites ran and passed; every test case executed (full validation)" and s["full_validation"] is True and s["complete"] is True
    assert s["all_tests_executed"] is True and s["all_applicable_passed"] is True and s["skipped_tests"] == [] and s["platform_exclusions"] == []
    assert s["totals"] == {"passed": 4, "failed": 0, "skipped": 0, "not_run": 0} and s["executed"] == 4 and md.startswith("# Test run — PASSED — all 4 suites")


def test_a_process_that_cannot_be_started_is_reported_not_raised(tmp_path):
    spec = importlib.util.spec_from_file_location("aeris_run_tests_under_test", RUNNER)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    code, secs, text, launch = m.run([str(tmp_path / "missing-interpreter"), "x.py"], tmp_path / "x.log", tmp_path)
    assert code is None and launch.startswith("could not be started: FileNotFoundError") and "NOT RUN" in text
    assert m.status_of(code, None, launch, text)[0] == "not run"
    assert m.resolve_program("rel/python", str(tmp_path))[1].endswith(": no such file")
    link = tmp_path / "venv-python"
    link.symlink_to(PY)
    assert m.resolve_program("venv-python", str(tmp_path))[1] is not None                       # a bare name is a PATH lookup ...
    assert m.resolve_program("./venv-python", str(tmp_path)) == (str(link), None)               # ... a path keeps the link (venv)


# ---------------------------------------------------------------- v5.2 (review finding G3): test cases, not only suites
SKIP_TESTS = ("import pytest\n\ndef test_ok():\n    assert True\n\n"
              "@pytest.mark.skip(reason='controlled review skip')\ndef test_skipped():\n    pass\n")


def backend_tests(f, text, name="test_ok.py"):
    t = f["root"] / "backend" / "tests"
    for p in t.glob("test_*.py"):
        p.unlink()
    (t / name).write_text(text)


def test_a_skipped_case_makes_the_run_incomplete_never_a_full_validation(fake):
    """The review's G3 fixture (a real pytest pass and a real pytest skip): v5.1 said exit 0 and full_validation true."""
    if not NODE:
        pytest.skip("Node.js is needed for the JavaScript suites")
    backend_tests(fake, SKIP_TESTS)
    r, s, md, out = runner(fake, "--out", "logs", "--backend-python", PY, "--browser-python", "backend/.venv/bin/python")
    st = by_name(s)
    assert r.returncode == 2, r.stdout + r.stderr
    assert st["backend"]["status"] == "incomplete" and st["backend"]["executed"] == 1 and st["backend"]["counts"]["skipped"] == 1
    assert s["complete"] is False and s["all_passed"] is False and s["all_applicable_passed"] is False and s["all_tests_executed"] is False
    assert s["full_validation"] is False and s["suites_ran"] is True and s["verdict"].startswith("INCOMPLETE")
    sk = s["skipped_tests"]
    assert sk == [{"suite": "backend", "test": "tests.test_ok::test_skipped", "reason": "controlled review skip", "excluded_by_policy": False, "policy": None}]
    assert "test_skipped" in s["verdict"] and "controlled review skip" in s["verdict"]
    assert "controlled review skip" in md and "| backend | incomplete" in md and "Full validation:** no (exit code 2" in md
    assert "skipped: " in r.stdout and "test_skipped" in r.stdout and "NOT covered" in r.stdout and "exit code 2" in r.stdout


def test_an_all_skipped_backend_executed_nothing(fake):
    backend_tests(fake, "import pytest\n\n@pytest.mark.skip(reason='all off')\ndef test_a():\n    pass\n\n"
                        "@pytest.mark.skipif(True, reason='also off')\ndef test_b():\n    pass\n")
    r, s, md, out = runner(fake, "--out", "logs", "--only", "backend", "--backend-python", PY)
    b = by_name(s)["backend"]
    assert r.returncode == 2 and b["status"] == "incomplete" and "nothing was executed" in b["reason"] and b["executed"] == 0
    assert {x["reason"] for x in s["skipped_tests"]} == {"all off", "also off"} and s["full_validation"] is False


def test_a_failure_with_a_skip_is_failed_and_lists_both(fake):
    backend_tests(fake, SKIP_TESTS + "\ndef test_broken():\n    assert 1 == 2, 'deliberate fixture failure'\n")
    r, s, md, out = runner(fake, "--out", "logs", "--only", "backend", "--backend-python", PY)
    assert r.returncode == 1 and by_name(s)["backend"]["status"] == "failed" and s["verdict"].startswith("FAILED")
    assert "1 test case(s) skipped" in s["verdict"] and [x["test"].split("::")[1] for x in s["failed_tests"]] == ["test_broken"]
    assert [x["test"].split("::")[1] for x in s["skipped_tests"]] == ["test_skipped"] and "Failed test cases" in md and "Skipped test cases" in md


def test_selected_only_with_a_skip_is_incomplete(fake):
    backend_tests(fake, SKIP_TESTS)
    r, s, md, out = runner(fake, "--out", "logs", "--only", "backend", "--backend-python", PY)
    assert r.returncode == 2 and s["verdict"].startswith("INCOMPLETE") and s["full_validation"] is False


def policy_file(f, test_id, platforms, covered_by=None, schema="aeris-platform-exclusions/1"):
    p = f["tmp"] / "policy.json"
    e = {"suite": "backend", "test": test_id, "platforms": platforms, "why": "fixture: this platform cannot run it"}
    if covered_by:
        e["covered_by"] = covered_by
    p.write_text(json.dumps({"schema": schema, "exclusions": [e]}))
    return str(p)


def test_a_declared_platform_exclusion_is_named_and_exit_code_3_never_a_full_validation(fake):
    backend_tests(fake, SKIP_TESTS, name="test_skip.py")
    pol = policy_file(fake, "tests.test_skip::test_skipped", [sys.platform], covered_by="tests.test_skip::test_ok")
    r, s, md, out = runner(fake, "--out", "logs", "--only", "backend", "--backend-python", PY, "--exclusions", pol)
    b = by_name(s)["backend"]
    assert r.returncode == 3, r.stdout + r.stderr
    assert b["status"] == "passed with exclusions" and b["counts"]["skipped"] == 1 and b["counts"]["passed"] == 1      # counted as skipped, not passed
    assert s["verdict"].startswith("PASSED WITH DECLARED PLATFORM EXCLUSIONS") and "tests.test_skip::test_skipped" in s["verdict"] and "Not a full validation" in s["verdict"]
    assert s["full_validation"] is False and s["complete"] is False and s["all_passed"] is False and s["all_applicable_passed"] is True
    assert [x["test"] for x in s["platform_exclusions"]] == ["tests.test_skip::test_skipped"] and s["platform_exclusions"][0]["covered_by"] == "tests.test_skip::test_ok"
    assert s["platform_exclusion_policy"]["file"] == pol and len(s["platform_exclusion_policy"]["sha256"]) == 64
    assert "excluded on" in md and "exit code 3" in md and "excluded on this platform by the declared policy" in r.stdout


@pytest.mark.parametrize("variant", ["other platform", "counterpart failed", "counterpart missing", "malformed policy"])
def test_an_exclusion_that_does_not_apply_leaves_the_run_incomplete_or_failed(fake, variant):
    body = SKIP_TESTS + ("\ndef test_counterpart():\n    assert False, 'fixture counterpart fails'\n" if variant == "counterpart failed" else "")
    backend_tests(fake, body, name="test_skip.py")
    pol = policy_file(fake, "tests.test_skip::test_skipped",
                      ["no-such-platform"] if variant == "other platform" else [sys.platform],
                      covered_by={"counterpart failed": "tests.test_skip::test_counterpart", "counterpart missing": "tests.test_skip::test_absent"}.get(variant, "tests.test_skip::test_ok"),
                      schema="wrong/1" if variant == "malformed policy" else "aeris-platform-exclusions/1")
    r, s, md, out = runner(fake, "--out", "logs", "--only", "backend", "--backend-python", PY, "--exclusions", pol)
    assert r.returncode == (1 if variant == "counterpart failed" else 2), r.stdout
    assert s["platform_exclusions"] == [] and s["full_validation"] is False and s["skipped_tests"][0]["excluded_by_policy"] is False
    if variant == "malformed policy":
        assert s["platform_exclusion_policy"]["problem"] and "no platform exclusions apply" in s["platform_exclusion_policy"]["problem"]
    elif variant != "counterpart failed":
        assert s["skipped_tests"][0]["policy"]                                         # says why the exclusion did not apply


def test_a_suite_that_times_out_is_failed(fake):
    (fake["root"] / "site" / "tests" / "browser_fake.py").write_text("import time\ntime.sleep(60)\n")
    r, s, md, out = runner(fake, "--out", "logs", "--only", "browser", "--browser-python", "backend/.venv/bin/python", "--timeout", "2")
    b = by_name(s)["browser:browser_fake"]
    assert r.returncode == 1 and b["status"] == "failed" and b["reason"] == "timed out" and "TIMEOUT after 2.0 s" in (out / b["log"]).read_text()


def test_a_tool_that_cannot_be_started_or_a_suite_without_counts(fake):
    bad_node = write_exec(fake["tmp"] / "badnode" / "node", "#!/no/such/interpreter\n")
    r, s, md, out = runner(fake, "--out", "logs", "--only", "js", "--node", str(bad_node))
    assert r.returncode == 2 and by_name(s)["js:alpha"]["status"] == "not run" and "could not be started" in by_name(s)["js:alpha"]["reason"]
    (fake["root"] / "site" / "tests" / "browser_fake.py").write_text("print('started, then crashed before reporting counts')\nraise SystemExit(3)\n")
    r, s, md, out = runner(fake, "--out", "logs", "--only", "browser", "--browser-python", "backend/.venv/bin/python")
    b = by_name(s)["browser:browser_fake"]
    assert r.returncode == 1 and b["status"] == "failed" and "no counts reported" in b["reason"]


def test_suite_status_rules_for_case_counts():
    """status_of on its own: not-run and skipped cases are never 'passed'; failures win."""
    spec = importlib.util.spec_from_file_location("aeris_run_tests_status", RUNNER)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    c = lambda p, f=0, sk=0, nr=0: {"passed": p, "failed": f, "skipped": sk, "not_run": nr, "total": p + f + sk + nr}     # noqa: E731
    assert m.status_of(0, c(5), None, "") == ("passed", None)
    assert m.status_of(2, c(0, nr=4), None, "NOT RUN: backend")[0] == "not run"
    assert m.status_of(2, c(3, nr=1), None, "NOT RUN x")[0] == "incomplete"                   # some ran, some did not
    assert m.status_of(0, c(3, sk=1), None, "")[0] == "incomplete"                            # a skip without a policy entry
    assert m.status_of(0, c(0, sk=3), None, "") == ("incomplete", "all 3 test(s) skipped: nothing was executed")
    assert m.status_of(1, c(3, f=1, sk=1), None, "")[0] == "failed" and m.status_of(0, c(3, f=1), None, "")[0] == "failed"
    assert m.status_of(-9, c(3), None, "") == ("failed", "timed out") and m.status_of(0, None, None, "")[0] == "failed"
    # v6.0: a suite that ran some checks and could not run others (e.g. no backend) reports "P / T … passed (K not run)"
    part = m.counts_js("NOT RUN Backend (jwt): …\n46 / 46 v6 browser checks passed (5 not run)\n")
    assert part == {"passed": 46, "failed": 0, "skipped": 0, "not_run": 5, "total": 51}
    assert m.status_of(2, part, None, "NOT RUN Backend (jwt): …")[0] == "incomplete"
    assert m.counts_js("0 / 12 v5.1 browser checks run (12 not run)\n")["not_run"] == 12


def test_the_committed_policy_names_real_tests_and_excludes_nothing_on_linux():
    """The policy cannot go stale silently: every excluded test and every counterpart exists in backend/tests; the
    only exclusion is the /proc orphan check on macOS, whose portable ps counterpart runs everywhere."""
    pol = json.loads((REPO / "scripts" / "platform_exclusions.json").read_text())
    assert pol["schema"] == "aeris-platform-exclusions/1"
    for e in pol["exclusions"]:
        for tid in filter(None, (e["test"], e.get("covered_by"))):
            mod, name = tid.split("::")
            src = (REPO / "backend" / (mod.replace(".", "/") + ".py")).read_text()
            assert f"def {name}(" in src, tid
        assert "linux" not in e["platforms"] and e["why"]
    assert [(e["test"].split("::")[1], e["platforms"]) for e in pol["exclusions"]] == [("test_worker_processes_exit_when_the_backend_process_is_killed", ["darwin"])]


def test_the_macos_proc_skip_is_an_exclusion_only_with_its_passing_ps_counterpart():
    """The Mac review run: /proc test skipped, ps counterpart passed. Here the runner's own classification is applied to
    those two JUnit cases under each platform (the decision logic, without a Mac)."""
    spec = importlib.util.spec_from_file_location("aeris_run_tests_policy", RUNNER)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    pol = m.load_policy(REPO / "scripts" / "platform_exclusions.json")
    proc = "tests.test_process_restart::test_worker_processes_exit_when_the_backend_process_is_killed"
    ps = proc + "_portable_ps"
    counts = {"passed": 755, "failed": 0, "skipped": 1, "not_run": 0, "total": 756}
    for plat, ps_outcome, want in (("darwin", "passed", "passed with exclusions"), ("darwin", "failed", "incomplete"), ("linux", "passed", "incomplete")):
        m.PLATFORM = plat
        cases = [{"test": proc, "outcome": "skipped", "message": "finds the worker processes through /proc (Linux)"}, {"test": ps, "outcome": ps_outcome, "message": None}]
        skips = m.classify_skips("backend", cases, pol)
        st, why = m.status_of(0, counts, None, "", skips)
        assert st == want, (plat, ps_outcome, st, why)
        assert skips[0]["reason"].startswith("finds the worker processes through /proc")       # the skip stays visible either way


# ---------------------------------------------------------------- v6.0: drift and firmware suites
MAKE = shutil.which("make")
CC = shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")


def v6_suites(f, drift="PASS a\nPASS b\n2 / 2 drift checks passed", drift_code=0,
              fw="1..3\n# firmware core tests: 3 passed, 0 failed", fw_code=0,
              qemu="ok   a\nok   b\n# qemu target tests: 2 passed, 0 failed (emulated ESP32-S3, not a physical board)", qemu_code=0):
    """Fake v6 suites in the fake repository: a drift script, a firmware Makefile with a `test` target, a QEMU test
    script, a fake QEMU, a qemutest build directory and a Python with an `esptool` module."""
    root, tmp = f["root"], f["tmp"]
    (root / "scripts" / "check_drift.py").write_text(f"print({drift!r})\nraise SystemExit({drift_code})\n")
    (root / "firmware" / "tests").mkdir(parents=True, exist_ok=True)
    recipe = "".join(f"\t@printf '%s\\n' '{ln}'\n" for ln in fw.splitlines())
    (root / "firmware" / "Makefile").write_text(f"test:\n{recipe}\t@exit {fw_code}\n")
    (root / "firmware" / "tests" / "qemu_link_test.py").write_text(
        "import sys\nprint('ARGS ' + ' '.join(sys.argv[1:]))\n" f"print({qemu!r})\nraise SystemExit({qemu_code})\n")
    qemu_bin = write_exec(tmp / "qemu" / "qemu-system-xtensa", "#!/bin/sh\necho 'QEMU emulator version 9.2.2 (fake for the runner test)'\n")
    build = tmp / "qemutest build"
    build.mkdir(exist_ok=True)
    (build / "flash_args").write_text("--flash_mode dio\n")
    et = tmp / "esptool-pkg"
    (et / "esptool").mkdir(parents=True, exist_ok=True)
    (et / "esptool" / "__init__.py").write_text("")
    espy = fake_python(tmp / "idf" / "python", "idf", et)
    return {"qemu": str(qemu_bin), "build": str(build), "espy": str(espy)}


def test_v6_drift_and_firmware_suites_count_their_checks(fake):
    if not (MAKE and CC):
        pytest.skip("make and a C compiler are needed for the firmware:host suite")
    t = v6_suites(fake)
    r, s, md, out = runner(fake, "--out", "logs", "--only", "drift,firmware", "--backend-python", PY,
                           "--qemu", t["qemu"], "--qemu-build", t["build"], "--esptool-python", t["espy"])
    st = by_name(s)
    assert r.returncode == 0, r.stdout + r.stderr
    assert [x["suite"] for x in s["suites"]] == ["drift", "firmware:host", "firmware:qemu"]
    assert st["drift"]["status"] == "passed" and st["drift"]["counts"] == {"passed": 2, "failed": 0, "skipped": 0, "not_run": 0, "total": 2}
    assert st["firmware:host"]["status"] == "passed" and st["firmware:host"]["counts"]["passed"] == 3 and st["firmware:host"]["executed"] == 3
    assert st["firmware:qemu"]["status"] == "passed" and st["firmware:qemu"]["counts"] == {"passed": 2, "failed": 0, "skipped": 0, "not_run": 0, "total": 2}
    log = (out / st["firmware:qemu"]["log"]).read_text()
    assert f"--qemu {t['qemu']}" in log and "--esptool-python" in log and "qemutest build" in log           # the chosen tools are passed on
    assert s["interpreters"]["qemu"]["source"] == "--qemu" and "fake for the runner test" in s["tool_versions"]["qemu"]
    assert s["verdict"].startswith("PASSED — selected suites only") and s["full_validation"] is False


def test_v6_suites_are_part_of_the_full_set_and_groups(fake):
    if not (MAKE and CC and NODE):
        pytest.skip("make, a C compiler and Node.js are needed")
    t = v6_suites(fake)
    r, s, md, out = runner(fake, "--out", "logs", "--backend-python", PY, "--browser-python", "backend/.venv/bin/python",
                           env={"AERIS_QEMU": t["qemu"], "AERIS_QEMU_BUILD": t["build"], "AERIS_IDF_PYTHON": t["espy"]})
    assert r.returncode == 0, r.stdout + r.stderr
    assert [x["suite"] for x in s["suites"]] == ["drift", "backend", "firmware:host", "firmware:qemu", "js:alpha", "live", "browser:browser_fake"]
    assert s["verdict"] == "PASSED — all 7 suites ran and passed; every test case executed (full validation)" and s["full_validation"] is True
    assert s["interpreters"]["qemu"]["source"] == "$AERIS_QEMU" and s["interpreters"]["esptool_python"]["source"] == "$AERIS_IDF_PYTHON"


def test_a_drift_check_that_could_not_run_makes_the_run_incomplete(fake):
    v6_suites(fake, drift="PASS a\nNOT RUN  WebAssembly device rebuilds byte-identical — clang-18 not found\n1 / 1 drift checks passed (1 not run)", drift_code=2)
    r, s, md, out = runner(fake, "--out", "logs", "--only", "drift", "--backend-python", PY)
    d = by_name(s)["drift"]
    assert r.returncode == 2 and d["status"] == "incomplete" and d["counts"] == {"passed": 1, "failed": 0, "skipped": 0, "not_run": 1, "total": 2}
    assert s["verdict"].startswith("INCOMPLETE") and s["full_validation"] is False


def test_failing_drift_and_firmware_checks_fail_their_suites(fake):
    if not (MAKE and CC):
        pytest.skip("make and a C compiler are needed for the firmware:host suite")
    t = v6_suites(fake, drift="FAIL index.html — DIFFERS\n0 / 1 drift checks passed", drift_code=1,
                  fw="1..2\n# firmware core tests: 1 passed, 1 failed", fw_code=1,
                  qemu="FAIL test image built from the current firmware sources\n# qemu target tests: 20 passed, 1 failed", qemu_code=1)
    r, s, md, out = runner(fake, "--out", "logs", "--only", "drift,firmware", "--backend-python", PY,
                           "--qemu", t["qemu"], "--qemu-build", t["build"], "--esptool-python", t["espy"])
    st = by_name(s)
    assert r.returncode == 1 and {k: v["status"] for k, v in st.items()} == {"drift": "failed", "firmware:host": "failed", "firmware:qemu": "failed"}
    assert st["firmware:host"]["counts"]["failed"] == 1 and st["firmware:qemu"]["counts"] == {"passed": 20, "failed": 1, "skipped": 0, "not_run": 0, "total": 21}


def test_firmware_suites_without_their_tools_are_not_run_never_passed(fake):
    v6_suites(fake)
    only_python = fake["tmp"] / "only-python"
    write_exec(only_python / "python3", f'#!/bin/sh\nexec "{PY}" "$@"\n')
    r, s, md, out = runner(fake, "--out", "logs", "--only", "firmware", "--backend-python", PY, env={"PATH": str(only_python)})
    st = by_name(s)
    assert r.returncode == 2 and st["firmware:host"]["status"] == "not run" and "make not found on PATH" in st["firmware:host"]["reason"]
    assert st["firmware:qemu"]["status"] == "not run" and "qemu-system-xtensa not found on PATH" in st["firmware:qemu"]["reason"]
    r, s, md, out = runner(fake, "--out", "logs", "--only", "firmware:qemu", "--backend-python", PY,
                           "--qemu", write_exec(fake["tmp"] / "q2" / "qemu", "#!/bin/sh\necho QEMU\n"), "--qemu-build", str(fake["tmp"] / "no-such-build"))
    q = by_name(s)["firmware:qemu"]
    assert r.returncode == 2 and q["status"] == "not run" and "no ESP32-S3 qemutest build" in q["reason"]
    r, s, md, out = runner(fake, "--out", "logs", "--only", "firmware:qemu", "--backend-python", PY, "--qemu", str(fake["tmp"] / "missing-qemu"))
    assert r.returncode == 2 and "no such file" in by_name(s)["firmware:qemu"]["reason"]           # an explicit tool is never replaced


def test_firmware_count_lines_are_parsed_exactly():
    spec = importlib.util.spec_from_file_location("aeris_run_tests_fw", RUNNER)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    assert m.counts_fw("1..33\n# firmware core tests: 33 passed, 0 failed\n") == {"passed": 33, "failed": 0, "skipped": 0, "not_run": 0, "total": 33}
    assert m.counts_fw("# qemu target tests: 21 passed, 1 failed (emulated ESP32-S3, not a physical board)")["failed"] == 1
    assert m.counts_fw("compile error\n") is None

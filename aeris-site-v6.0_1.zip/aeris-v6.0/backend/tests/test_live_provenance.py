"""One conservative provenance rule for live telemetry, capabilities, the live WebSocket, recordings, exports and
comparison evidence (v6, review finding V52-2 of v5.2).

Artificial hellos (no hardware) are injected into the backend's telemetry hub and observed through the real API routes,
exactly as the reviewer's provenance_probe.py did: a hello that DECLARES physical / synthetic: false but carries a
synthetic or unknown ancestry must never be reported as a live physical device anywhere; the recording of the same
frames must agree; a genuinely declared-physical source stays declared (never verified)."""
from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app
from aeris_backend.telemetry.protocol import hello_message, validate_hello

SYN_REF = {"derived_from": "AERIS-HW-000001", "generation": 1, "trust": "synthetic", "original_synthetic": True}
CASES = {
    # name: (lineage or None, device kind, synthetic flag, expected trust, expected derived)
    "control-declared-physical": (None, "physical", False, "declared-physical", False),
    "ancestry_trust-synthetic": ({"trust": "declared-physical", "original_synthetic": False, "ancestry_trust": "synthetic", "generation": 2}, "physical", False, "synthetic", True),
    "ancestry-reference-synthetic": ({"trust": "declared-physical", "original_synthetic": False, "generation": 2, "ancestry": [SYN_REF]}, "physical", False, "synthetic", True),
    "original_synthetic-true": ({"original_synthetic": True}, "physical", False, "synthetic", True),
    "lineage-trust-unknown": ({"trust": "unknown"}, "physical", False, "unknown", True),
    "ancestry-reference-unknown": ({"trust": "declared-physical", "original_synthetic": False, "generation": 2,
                                    "ancestry": [{"derived_from": "x", "generation": 1, "trust": "unknown", "original_synthetic": None}]}, "physical", False, "unknown", True),
    "legacy-nested-synthetic": ({"trust": "declared-physical", "original_synthetic": False,
                                 "ancestors": [{"derived_from": "A", "trust": "synthetic", "original_synthetic": True}]}, "physical", False, "synthetic", True),
    "legacy-nested-deep-unknown": ({"trust": "declared-physical", "original_synthetic": False,
                                    "ancestors": [{"derived_from": "B", "trust": "declared-physical", "original_synthetic": False,
                                                   "ancestors": [{"derived_from": "C", "trust": "unknown"}]}]}, "physical", False, "unknown", True),
    "derived-copy-declared": ({"derived_from": "AERIS-HW-000009", "trust": "declared-physical", "original_synthetic": False, "generation": 1,
                               "ancestry_trust": "declared-physical"}, "physical", False, "declared-physical", True),
    "lineage-without-trust": ({"derived_from": "AERIS-HW-000010"}, "physical", False, "declared-physical", True),
    "emulator": (None, "emulator", True, "synthetic", False),
    "test-source": (None, "test", True, "synthetic", False),
}


@pytest.fixture()
def api(tmp_path):
    app = create_app({"db": str(tmp_path / "prov.sqlite3"), "workers": 1, "exclusive": False})
    with TestClient(app) as c:
        yield app, c


def inject(app, name, lineage, kind, synthetic, frames=3):
    bridge = app.state.bridge
    hub = bridge.hub
    hub.on_connect({"kind": "tcp", "address": "ARTIFICIAL FIXTURE " + name}, bridge.clock())
    hello = hello_message("ARTIFICIAL-" + name, kind, "test-only", synthetic, "corner", 100)
    if lineage is not None:
        hello["lineage"] = json.loads(json.dumps(lineage))
    assert validate_hello(hello)["ok"], validate_hello(hello)
    assert hub.feed_message(hello, bridge.clock()) == "hello"
    return hub, bridge


def feed(hub, bridge, start, k):
    for i in range(start, start + k):
        assert hub.feed_message({"type": "frame", "t": i * 0.01, "seq": i, "q": [1, 0, 0, 0]}, bridge.clock()) == "frame"


@pytest.mark.parametrize("name", list(CASES))
def test_live_status_capabilities_and_recording_agree(api, name):
    app, c = api
    lineage, kind, synthetic, trust, derived = CASES[name]
    hub, bridge = inject(app, name, lineage, kind, synthetic)
    start = c.post("/api/v1/telemetry/recordings/start", json={"name": "ARTIFICIAL FIXTURE - NO HARDWARE " + name})
    assert start.status_code == 201, start.text
    assert start.json()["provenance"]["trust"] == trust
    feed(hub, bridge, 0, 3)
    st = c.get("/api/v1/telemetry/status").json()
    p = st["provenance"]
    caps = c.get("/api/v1/capabilities").json()["hardware"]
    assert p["trust"] == trust, (name, p)
    assert p["physical_verified"] is False
    assert p["derived"] is derived
    physical_live = trust == "declared-physical" and kind == "physical" and not derived
    assert st["live"] is physical_live, (name, st["live"], p)
    assert caps["live"] is physical_live
    assert p["declared_physical"] is (trust == "declared-physical" and kind == "physical")
    assert p["synthetic"] is (trust == "synthetic")
    if trust == "synthetic":
        assert "SYNTHETIC" in p["label"] and "DECLARED PHYSICAL" not in p["label"]
    elif trust == "unknown":
        assert p["label"].startswith("UNKNOWN ORIGIN") and p["declared_physical"] is False
    elif derived:
        assert p["label"].startswith("REPLAY") and "copy" in p["label"]
    else:
        assert p["label"] == "DECLARED PHYSICAL DEVICE (not verified by the software)"
    rec = c.post("/api/v1/telemetry/recordings/stop")
    assert rec.status_code == 201, rec.text
    r = rec.json()
    assert r["provenance"]["trust"] == trust, (name, r["provenance"])
    assert r["provenance"]["physical_verified"] is False
    assert r["synthetic"] is (trust != "declared-physical")            # stored flag: never evidence unless declared physical
    assert r["provenance"]["declared_physical"] is (trust == "declared-physical")
    stored = c.get(f"/api/v1/hardware/recordings/{r['id']}").json()
    assert stored["provenance"]["trust"] == trust
    rows = {x["id"]: x for x in c.get("/api/v1/hardware/recordings").json()["recordings"]}
    assert rows[r["id"]]["trust"] == (trust if trust != "declared-physical" else "declared-physical")
    # the NDJSON export of that recording keeps the class (or lowers it), never raises it
    exp = c.get(f"/api/v1/hardware/recordings/{r['id']}/export?format=ndjson")
    assert exp.status_code == 200, exp.text
    hello = json.loads(exp.text.splitlines()[0])
    lin = hello["lineage"]
    assert lin["trust"] == trust
    if trust != "declared-physical":
        assert hello["synthetic"] is True                               # exported copies of anything not declared physical replay as synthetic
    hub.on_disconnect("fixture complete", bridge.clock())


def test_comparison_evidence_is_never_admissible_for_synthetic_or_unknown_live_sources(api):
    app, c = api
    run = c.post("/api/v1/simulations", json={"config": {"mode": "corner", "duration_s": 1}, "meta": {"name": "prov compare"}})
    assert run.status_code == 202, run.text
    import time
    job = run.json()["job"]
    for _ in range(600):
        j = c.get(f"/api/v1/jobs/{job['id']}").json()
        if j["state"] in ("complete", "failed", "cancelled"):
            break
        time.sleep(0.05)
    assert j["state"] == "complete", j
    run_id = j["result_ref"]["id"]
    for name in ("ancestry_trust-synthetic", "lineage-trust-unknown", "legacy-nested-synthetic"):
        lineage, kind, synthetic, trust, _ = CASES[name]
        hub, bridge = inject(app, name, lineage, kind, synthetic)
        assert c.post("/api/v1/telemetry/recordings/start", json={"name": "fixture " + name}).status_code == 201
        feed(hub, bridge, 0, 20)
        rid = c.post("/api/v1/telemetry/recordings/stop").json()["id"]
        cmp_ = c.post("/api/v1/hardware/compare", json={"run_id": run_id, "recording_id": rid})
        assert cmp_.status_code == 200, cmp_.text
        ev = cmp_.json()["evidence"]
        assert ev["admissible_as_validation_evidence"] is False
        assert ev["recording_provenance"]["trust"] == trust
        assert ev["recording_provenance"]["declared_physical"] is False
        hub.on_disconnect("fixture complete", bridge.clock())


def test_live_websocket_batches_carry_the_same_conservative_provenance(api):
    app, c = api
    for name in ("control-declared-physical", "ancestry-reference-synthetic", "lineage-trust-unknown"):
        lineage, kind, synthetic, trust, derived = CASES[name]
        hub, bridge = inject(app, name, lineage, kind, synthetic)
        with c.websocket_connect("/api/v1/telemetry/live") as ws:
            first = ws.receive_json()
            assert first["type"] == "status"
            assert first["status"]["provenance"]["trust"] == trust
            assert first["status"]["live"] is (trust == "declared-physical" and not derived)
            feed(hub, bridge, 100, 5)
            msg = ws.receive_json()
            while msg["type"] != "frames":
                msg = ws.receive_json()
            assert msg["provenance"]["trust"] == trust
            assert msg["provenance"]["synthetic"] is (trust == "synthetic")
            assert msg["provenance"]["declared_physical"] is (trust == "declared-physical")
            assert msg["provenance"]["physical_verified"] is False
        hub.on_disconnect("fixture complete", bridge.clock())


def test_no_source_reports_nothing_and_a_disconnected_source_keeps_its_class(api):
    app, c = api
    p = c.get("/api/v1/telemetry/status").json()["provenance"]
    assert p["label"] == "NO SOURCE" and p["synthetic"] is None and p["trust"] is None and p["declared_physical"] is False
    lineage, kind, synthetic, trust, _ = CASES["legacy-nested-synthetic"]
    hub, bridge = inject(app, "x", lineage, kind, synthetic)
    hub.on_disconnect("gone", bridge.clock())
    st = c.get("/api/v1/telemetry/status").json()
    assert st["provenance"]["trust"] == "synthetic" and st["live"] is False and st["provenance"]["active"] is False


def test_the_shared_rule_is_the_recorders_rule():
    """lineage.source_trust (live) and lineage._hello_trust (recordings, exports, datasets, comparisons) are one rule."""
    from aeris_backend.telemetry.lineage import _hello_trust, source_trust
    for name, (lineage, kind, synthetic, trust, derived) in CASES.items():
        h = hello_message("X", kind, "fw", synthetic, "edge", 100)
        if lineage is not None:
            h["lineage"] = lineage
        st = source_trust(h)
        assert st["trust"] == _hello_trust(h) == trust, name
        assert st["derived"] is derived
        assert st["reasons"] or trust == "declared-physical"

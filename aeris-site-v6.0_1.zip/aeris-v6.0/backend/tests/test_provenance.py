"""Conservative telemetry provenance end to end (v5.1, review finding F1; docs/TELEMETRY.md §6).

A recording can span several source segments (reconnects, a replaced source). One synthetic, test or undeclared
segment makes the whole recording — and every descendant: JSON and NDJSON exports, replays, recordings of replays,
imports, datasets, comparisons — non-evidence, and an export never writes a hello that claims more than the data
earned. Every "physical" source here is an ARTIFICIAL TEST FIXTURE that only declares kind physical to exercise the
labels (device id test-fixture-physical-declaration, firmware test-only); no data comes from hardware."""
from __future__ import annotations

import copy
import json
import threading
import time

import pytest
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app
from aeris_backend.experiments.records import canonical_hash
from aeris_backend.hardware.ingest import validate_recording
from aeris_backend.telemetry.emulator import Emulator
from aeris_backend.telemetry.lineage import classify
from aeris_backend.telemetry.protocol import dumps, hello_message, parse_line, validate_frame, validate_hello
from aeris_backend.telemetry.stream import TelemetryHub, recording_to_ndjson

PHYS = hello_message("test-fixture-physical-declaration", "physical", "test-only", False, "corner", 100)
EMU = hello_message("test-emulator", "emulator", "test-only", True, "corner", 100)
TST = hello_message("test-source-b", "test", "test-only", True, "corner", 100)


def frames(hub, n0, count, t0, now):
    for k in range(count):
        seq = n0 + k
        assert hub.feed_message({"type": "frame", "seq": seq, "t": t0 + 0.01 * k, "q": [1, 0, 0, 0], "w": [0, 0, 0]}, now + 0.01 * k) == "frame"


def segment(hub, hello, n=3, t0=0.0, now=0.0, address="test-only"):
    hub.on_connect({"kind": "tcp", "address": address}, now)
    assert hub.feed_line(dumps(hello), now) == "hello"
    frames(hub, 0, n, t0, now)


def record(*hellos, n=3):
    """A recording over one segment per hello (each a new connection, as a replaced source or a reconnect is)."""
    h = TelemetryHub()
    segment(h, hellos[0], n, 0.0, 0.0)
    h.start_recording("provenance test fixture, not a measurement", 0.0)
    frames(h, n, n, 0.5, 0.5)
    for k, hel in enumerate(hellos[1:], 1):
        h.on_disconnect("source replaced (test)", k)
        segment(h, hel, n, 0.0, k + 0.1)
    return h, h.stop_recording(10.0)


def replay(nd, rerecord=True):
    """Feed an NDJSON export through a fresh hub as a file replay; optionally record everything replayed."""
    h = TelemetryHub()
    h.on_connect({"kind": "file", "address": "recording:test"}, 100.0)
    lines = nd.splitlines()
    first = h.feed_line(lines[0], 100.0)
    assert first == "hello", first
    provs = [h.provenance()]
    if rerecord:
        h.start_recording("re-recorded replay (test)", 100.0)
    for ln in lines[1:]:
        r = h.feed_line(ln, 100.5)
        assert not r.startswith("rejected"), (r, ln[:200])
        if r == "hello":
            provs.append(h.provenance())
    return h, provs, (h.stop_recording(101.0) if rerecord else None)


def check_protocol(nd):
    """Every exported line is valid under the protocol; no hello says physical and synthetic: true."""
    hello, hellos = None, []
    for ln in nd.splitlines():
        m, err = parse_line(ln)
        assert err is None, err
        if m["type"] == "hello":
            v = validate_hello(m)
            assert v["ok"], v["errors"]
            assert not (m["device"]["kind"] == "physical" and m["synthetic"] is True)
            assert isinstance(m.get("lineage"), dict) and m["lineage"]["trust"] in ("synthetic", "declared-physical", "unknown")
            hello = m
            hellos.append(m)
        elif m["type"] == "frame":
            assert validate_frame(m, hello)["ok"]
    return hellos


# ---------------------------------------------------------------- mixed sources, both orders
@pytest.mark.parametrize("order", ["physical-then-synthetic", "synthetic-then-physical"])
def test_mixed_recording_stays_synthetic_through_export_replay_and_rerecording(order):
    hellos = (PHYS, EMU) if order == "physical-then-synthetic" else (EMU, PHYS)
    _, doc = record(*hellos)
    assert doc["synthetic"] is True and validate_recording(doc)["ok"]
    p = doc["provenance"]
    assert p["trust"] == "synthetic" and p["mixed_sources"] is True and p["source_kind"] == "mixed" and doc["device"]["kind"] == "mixed"
    assert [s["device"]["kind"] for s in p["segments"]] == [h["device"]["kind"] for h in hellos]          # segment identity is kept
    assert [s["rows"] for s in p["segments"]] == [[0, 3], [3, 6]]
    nd = recording_to_ndjson(doc, "AERIS-HW-000001")
    exported = check_protocol(nd)
    assert len(exported) == 2 and all(h["synthetic"] is True for h in exported)                            # every segment replays as synthetic
    phys_seg = [h for h, src in zip(exported, hellos) if src is PHYS][0]
    assert phys_seg["device"]["kind"] == "file-replay" and phys_seg["lineage"]["original_device"]["kind"] == "physical" \
        and phys_seg["lineage"]["original_synthetic"] is False and phys_seg["lineage"]["trust"] == "synthetic"
    assert all(h["lineage"]["derived_from"] == "AERIS-HW-000001" for h in exported)
    _, provs, redoc = replay(nd)
    assert all(pr["synthetic"] is True and pr["declared_physical"] is False and "SYNTHETIC" in pr["label"] for pr in provs)
    assert redoc["synthetic"] is True and redoc["provenance"]["trust"] == "synthetic" and validate_recording(redoc)["ok"]
    assert redoc["provenance"]["derived"] is True
    # and one generation further: an export of the re-recording is still synthetic everywhere
    nd2 = recording_to_ndjson(redoc, "AERIS-HW-000002")
    assert all(h["synthetic"] is True for h in check_protocol(nd2))
    _, provs2, redoc2 = replay(nd2)
    assert redoc2["synthetic"] is True and all(pr["synthetic"] is True for pr in provs2)


def test_reconnect_of_one_declared_physical_source_keeps_its_declaration_and_marks_copies_as_derived():
    _, doc = record(PHYS, PHYS)
    p = doc["provenance"]
    assert doc["synthetic"] is False and p["trust"] == "declared-physical" and p["mixed_sources"] is False and len(p["segments"]) == 2
    assert doc["device"] == {"id": "test-fixture-physical-declaration", "kind": "physical", "firmware": "test-only"} and p["derived"] is False
    nd = recording_to_ndjson(doc, "AERIS-HW-000010")
    exported = check_protocol(nd)
    assert [(h["device"]["kind"], h["synthetic"], h["lineage"]["trust"]) for h in exported] == [("physical", False, "declared-physical")] * 2
    _, provs, redoc = replay(nd)
    assert all(pr["declared_physical"] is True and pr["replay"] is True and "REPLAY" in pr["label"] for pr in provs)
    # a recording of a replay is a copy: still declared physical, but derived (never original evidence)
    assert redoc["synthetic"] is False and redoc["provenance"]["trust"] == "declared-physical" and redoc["provenance"]["derived"] is True
    assert classify(redoc)["derived"] is True


def test_emulator_reconnect_and_identity_change_keep_each_segment():
    _, doc = record(EMU, EMU)
    nd = recording_to_ndjson(doc, "AERIS-HW-000020")
    assert [h["device"]["kind"] for h in check_protocol(nd)] == ["emulator", "emulator"]                 # its own synthetic identity
    assert doc["device"]["kind"] == "emulator" and doc["provenance"]["mixed_sources"] is False
    _, doc2 = record(EMU, TST)
    assert doc2["provenance"]["mixed_sources"] is True and [s["device"]["id"] for s in doc2["provenance"]["segments"]] == ["test-emulator", "test-source-b"]
    ex = check_protocol(recording_to_ndjson(doc2, "AERIS-HW-000021"))
    assert [(h["device"]["id"], h["device"]["kind"], h["synthetic"]) for h in ex] == [("test-emulator", "emulator", True), ("test-source-b", "test", True)]
    _, provs, _ = replay(recording_to_ndjson(doc2), rerecord=False)
    assert [pr["label"] for pr in provs] == ["SYNTHETIC EMULATOR — not the physical cube", "SYNTHETIC TEST SOURCE — not the physical cube"]


def test_a_mode_change_closes_the_recording_instead_of_mixing_modes():
    h = TelemetryHub()
    segment(h, PHYS, 3)
    h.start_recording("mode change (test)", 0.0)
    frames(h, 3, 3, 0.5, 0.5)
    h.on_disconnect("source replaced (test)", 1.0)
    h.on_connect({"kind": "tcp", "address": "test-only"}, 1.1)
    edge = hello_message("test-edge-source", "test", "test-only", True, "edge", 100)
    assert h.feed_line(dumps(edge), 1.1) == "hello"
    assert "changed mode" in h.status(1.2)["recording"]["closed"]
    for k in range(3):
        assert h.feed_message({"type": "frame", "seq": k, "t": 0.01 * k, "theta": 0.01, "w": [0, 0, 0]}, 1.2) == "frame"
    doc = h.stop_recording(2.0)
    assert doc["mode"] == "corner" and len(doc["samples"]["cols"]["t"]) == 3 and "theta" not in doc["samples"]["cols"]         # the corner rows only
    assert "changed mode from corner to edge" in doc["provenance"]["recording_closed"]["reason"]
    assert doc["synthetic"] is False and doc["provenance"]["trust"] == "declared-physical"         # the edge test source never entered
    h.start_recording("the new mode", 2.1)                                                          # a new recording can start
    for k in range(3, 6):
        h.feed_message({"type": "frame", "seq": k, "t": 0.01 * k, "theta": 0.02, "w": [0, 0, 0]}, 2.2)
    doc2 = h.stop_recording(3.0)
    assert doc2["mode"] == "edge" and doc2["synthetic"] is True


def test_v5_documents_are_never_rewritten_and_their_mixed_exports_stay_synthetic():
    """A recording stored by v5 (no segments; hellos physical then emulator; synthetic true) is exported and
    replayed by the v5.1 rules without changing the stored document."""
    _, doc = record(PHYS, EMU)
    legacy = copy.deepcopy(doc)
    legacy["device"] = dict(PHYS["device"])
    p = legacy["provenance"]
    for k in ("segments", "trust", "trust_reasons", "mixed_sources", "derived", "derived_from", "lineage", "stream_id"):
        p.pop(k, None)
    p["source_kind"] = "physical"
    p["hellos"] = [{k: v for k, v in h.items() if k != "type"} for h in (PHYS, EMU)]
    before = json.dumps(legacy, sort_keys=True)
    nd = recording_to_ndjson(legacy, "AERIS-HW-000030")
    assert json.dumps(legacy, sort_keys=True) == before                                             # nothing rewritten
    exported = check_protocol(nd)
    assert len(exported) == 1 and exported[0]["synthetic"] is True and exported[0]["device"]["kind"] == "file-replay"
    _, provs, redoc = replay(nd)
    assert provs[0]["synthetic"] is True and redoc["synthetic"] is True
    # a v5 re-recording of a mixed export (the defect's output: physical hello, synthetic false, captured from a replay)
    bug = copy.deepcopy(legacy)
    bug["synthetic"] = False
    bug["provenance"] = {"protocol": p["protocol"], "transport": {"kind": "file", "address": "recording:AERIS-HW-000001"}, "source_kind": "physical",
                         "synthetic": False, "hellos": [{k: v for k, v in PHYS.items() if k != "type"}]}
    c = classify(bug)
    assert c["trust"] == "declared-physical" and c["derived"] is True                                # lineage lost in v5, but it is a replay copy


def test_unknown_and_missing_declarations_are_never_upgraded():
    _, doc = record(PHYS)
    assert classify(doc)["trust"] == "declared-physical"
    for mutate in (lambda d: d.pop("synthetic"),                                                   # flag missing
                   lambda d: d.update(provenance={}),                                              # synthetic: false, but no source declared anything
                   lambda d: (d.update(provenance={}), d.pop("synthetic")),                        # nothing at all
                   lambda d: d["provenance"]["segments"][0]["hello"].pop("synthetic")):            # a declaration without its flag
        d = copy.deepcopy(doc)
        mutate(d)
        c = classify(d)
        assert c["trust"] == "unknown" and c["synthetic"] is False and c["declared_physical"] is False, c
        hellos = check_protocol(recording_to_ndjson(d))
        assert [(h["device"]["kind"], h["synthetic"]) for h in hellos] == [("file-replay", True)]     # replays as synthetic, never physical


# ---------------------------------------------------------------- through the API (import, datasets, comparisons)
def serve(lines_fn, delay=0.01):
    """A tiny line server (artificial fixture): each connection gets lines_fn() once, then stays open."""
    import socket as _s
    srv = _s.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(4)
    port = srv.getsockname()[1]
    stop = threading.Event()

    def run():
        srv.settimeout(0.2)
        while not stop.is_set():
            try:
                c, _ = srv.accept()
            except OSError:
                continue

            def feed(conn):
                with conn:
                    for ln in lines_fn():
                        if stop.is_set():
                            return
                        try:
                            conn.sendall(ln)
                        except OSError:
                            return
                        time.sleep(delay)
                    while not stop.is_set():
                        time.sleep(0.05)
            threading.Thread(target=feed, args=(c,), daemon=True).start()
        srv.close()
    threading.Thread(target=run, daemon=True).start()
    return port, stop.set


def physical_fixture_lines():
    out = [dumps(PHYS)]
    for k in range(400):
        out.append(dumps({"type": "frame", "seq": k, "t": 0.01 * k, "q": [1, 0, 0, 0], "w": [0, 0, 0]}))
    return out


@pytest.fixture(scope="module")
def api(tmp_path_factory):
    d = tmp_path_factory.mktemp("prov")
    (d / "telemetry").mkdir()
    app = create_app({"db": str(d / "p.sqlite3"), "workers": 1, "max_jobs": 1, "telemetry_dir": str(d / "telemetry")})
    phys_port, stop_phys = serve(physical_fixture_lines)
    def emu_lines():
        emu = Emulator(mode="corner", rate_hz=100, seed=5)
        return [dumps(emu.hello())] + [dumps(emu.next_frame()) for _ in range(400)]
    emu_port, stop_emu = serve(emu_lines)
    with TestClient(app) as c:
        c.dir, c.phys, c.emu = d / "telemetry", phys_port, emu_port
        yield c
    stop_phys()
    stop_emu()


def until(fn, timeout=30, step=0.05):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v
        time.sleep(step)
    raise AssertionError("condition not reached within %ss" % timeout)


def live_frames(api, more=20):
    n0 = api.get("/api/v1/telemetry/status").json()["counters"]["frames_accepted"]
    until(lambda: api.get("/api/v1/telemetry/status").json()["counters"]["frames_accepted"] >= n0 + more)


def record_via_api(api, *sources, name="provenance API test"):
    api.post("/api/v1/telemetry/connect", json=sources[0])
    live_frames(api)
    assert api.post("/api/v1/telemetry/recordings/start", json={"name": name}).status_code == 201
    live_frames(api)
    for s in sources[1:]:
        assert api.post("/api/v1/telemetry/connect", json=s).status_code == 200        # the source is replaced while recording
        live_frames(api)
    r = api.post("/api/v1/telemetry/recordings/stop")
    assert r.status_code == 201, r.text
    return r.json()


def replay_and_record(api, spec, name):
    """Replay at real speed (so that the recording can start while the first segment plays) and record it all."""
    assert api.post("/api/v1/telemetry/connect", json=dict(spec, speed=1)).status_code == 200
    until(lambda: api.get("/api/v1/telemetry/status").json()["hello"] is not None)
    r = api.post("/api/v1/telemetry/recordings/start", json={"name": name})
    assert r.status_code == 201, r.text
    until(lambda: api.get("/api/v1/telemetry/status").json()["source"]["state"] == "finished")
    r = api.post("/api/v1/telemetry/recordings/stop")
    assert r.status_code == 201, r.text
    return r.json()


def protocol_before(api):
    return api.post("/api/v1/validation/protocols", json={"name": "fixture thresholds", "thresholds": {"attitude.rmse": 90.0}}).json()["id"]


_RUN = {}


def compare(api, rid, pid):
    if "id" not in _RUN:
        job = api.post("/api/v1/simulations", json={"config": {"mode": "corner", "duration_s": 1}}).json()["job"]["id"]
        j = until(lambda: (lambda j: j if j["state"] in ("complete", "failed") else None)(api.get(f"/api/v1/jobs/{job}").json()), 120)
        _RUN["id"] = j["result_ref"]["id"]
    return api.post("/api/v1/hardware/compare", json={"run_id": _RUN["id"], "recording_id": rid, "protocol_id": pid}).json()


def test_api_every_synthetic_descendant_stays_excluded_from_validation_evidence(api):
    pid = protocol_before(api)
    tcp = lambda port: {"source": "tcp", "host": "127.0.0.1", "port": port, "reconnect": False}         # noqa: E731
    mixed = record_via_api(api, tcp(api.phys), tcp(api.emu), name="mixed: physical fixture then emulator")
    assert mixed["synthetic"] is True and mixed["provenance"]["trust"] == "synthetic" and mixed["provenance"]["mixed_sources"] is True
    segs = api.get(f"/api/v1/hardware/recordings/{mixed['id']}").json()["document"]["provenance"]["segments"]
    assert [s["device"]["kind"] for s in segs] == ["physical", "emulator"] and all(s["rows"][1] - s["rows"][0] >= 15 for s in segs), segs
    chain = [mixed["id"]]
    # NDJSON export → file in the telemetry directory → replay → recording, twice
    for gen in (1, 2):
        nd = api.get(f"/api/v1/hardware/recordings/{chain[-1]}/export?format=ndjson").text
        assert all(h["synthetic"] is True for h in check_protocol(nd))
        (api.dir / f"gen{gen}.ndjson").write_text(nd)
        rec = replay_and_record(api, {"source": "file", "path": f"gen{gen}.ndjson"}, f"generation {gen}")
        assert rec["synthetic"] is True and rec["provenance"]["trust"] == "synthetic" and rec["provenance"]["derived"] is True and rec["quality"]["n"] >= 20, rec
        chain.append(rec["id"])
    # replay of the stored recording itself, recorded again
    rec = replay_and_record(api, {"source": "recording", "recording_id": mixed["id"]}, "replay of the stored mixed recording")
    assert rec["synthetic"] is True
    chain.append(rec["id"])
    # JSON export → import: stored synthetic; a relabelled import is refused
    js = api.get(f"/api/v1/hardware/recordings/{mixed['id']}/export?format=json").json()
    imp = api.post("/api/v1/hardware/recordings", json=js)
    assert imp.status_code in (200, 201) and imp.json()["synthetic"] is True
    chain.append(imp.json()["id"])
    for forged in (dict(js, synthetic=False), dict(js, synthetic=False, provenance=dict(js["provenance"], synthetic=False, source_kind="physical"))):
        r = api.post("/api/v1/hardware/recordings", json=forged)
        assert r.status_code == 422 and any(d["path"] == "synthetic" for d in r.json()["error"]["details"])
    for rid in chain:
        cmp_ = compare(api, rid, pid)
        ev = cmp_["evidence"]
        assert cmp_["synthetic"] is True and ev["admissible_as_validation_evidence"] is False and any("SYNTHETIC" in x for x in ev["reasons"]), (rid, ev)
        ds = api.post("/api/v1/datasets", json={"title": f"descendant {rid}", "recording_ids": [rid]}).json()
        assert ds["provenance"]["source"] == "synthetic-telemetry" and ds["provenance"]["contains_synthetic"] is True and ds["members"][0]["trust"] == "synthetic"
    listed = {r["id"]: r for r in api.get("/api/v1/hardware/recordings?limit=1000").json()["recordings"]}
    assert all(listed[rid]["synthetic"] is True and listed[rid]["trust"] == "synthetic" for rid in chain), [listed[r] for r in chain]


def test_api_declared_physical_fixture_original_vs_copy_and_unknown_upload(api):
    pid = protocol_before(api)
    time.sleep(0.01)
    tcp = {"source": "tcp", "host": "127.0.0.1", "port": api.phys, "reconnect": False}
    orig = record_via_api(api, tcp, name="declared-physical fixture (artificial)")
    assert orig["synthetic"] is False and orig["provenance"]["trust"] == "declared-physical" and orig["provenance"]["derived"] is False
    ev = compare(api, orig["id"], pid)["evidence"]
    assert ev["admissible_as_validation_evidence"] is True, ev["reasons"]           # positive control: nothing over-blocked
    nd = api.get(f"/api/v1/hardware/recordings/{orig['id']}/export?format=ndjson").text
    assert [(h["device"]["kind"], h["synthetic"]) for h in check_protocol(nd)] == [("physical", False)]
    (api.dir / "phys.ndjson").write_text(nd)
    copy_ = replay_and_record(api, {"source": "file", "path": "phys.ndjson"}, "copy of the declared-physical fixture")
    assert copy_["synthetic"] is False and copy_["provenance"]["derived"] is True
    ev = compare(api, copy_["id"], pid)["evidence"]
    assert ev["admissible_as_validation_evidence"] is False and any("captured from a replay" in x for x in ev["reasons"])
    # an upload that declares nothing: unknown, never physical, never evidence; its export replays as synthetic
    js = api.get(f"/api/v1/hardware/recordings/{orig['id']}/export?format=json").json()
    bare = {k: v for k, v in js.items() if k not in ("synthetic", "provenance")}
    up = api.post("/api/v1/hardware/recordings", json=bare).json()
    assert up["provenance"]["trust"] == "unknown" and up["provenance"]["declared_physical"] is False and "not declared" in up["provenance"]["label"]
    ev = compare(api, up["id"], pid)["evidence"]
    assert ev["admissible_as_validation_evidence"] is False and any("not declared" in x for x in ev["reasons"])
    ds = api.post("/api/v1/datasets", json={"title": "unknown origin", "recording_ids": [up["id"]]}).json()
    assert ds["provenance"]["source"] != "hardware" and ds["provenance"]["contains_unknown_origin"] is True
    hellos = check_protocol(api.get(f"/api/v1/hardware/recordings/{up['id']}/export?format=ndjson").text)
    assert [(h["device"]["kind"], h["synthetic"]) for h in hellos] == [("file-replay", True)]
    # the list the Telemetry tab shows says the same: declared (the original), a copy, unknown
    listed = {r["id"]: r for r in api.get("/api/v1/hardware/recordings?limit=1000").json()["recordings"]}
    assert (listed[orig["id"]]["trust"], listed[orig["id"]]["derived"]) == ("declared-physical", False)
    assert (listed[copy_["id"]]["trust"], listed[copy_["id"]]["derived"]) == ("declared-physical", True)
    assert listed[up["id"]]["trust"] == "unknown" and listed[up["id"]]["synthetic"] is False


def test_api_rows_stored_before_v5_1_are_listed_by_the_current_rules_without_rewriting(api):
    """A v5 database row has no trust class in its index. The list computes it from the immutable document (never
    higher than what was stored) and leaves the stored row and document exactly as they were."""
    repo = api.app.state.repo
    _, doc = record(PHYS, EMU)                                       # what v5 stored for a mixed recording: synthetic, no segments
    legacy = copy.deepcopy(doc)
    for k in ("segments", "trust", "trust_reasons", "mixed_sources", "derived", "derived_from", "lineage", "stream_id"):
        legacy["provenance"].pop(k, None)
    copy_v5 = copy.deepcopy(legacy)                                  # and the v5 defect's output: a replay copy labelled physical
    copy_v5["synthetic"] = False
    copy_v5["provenance"] = {"protocol": legacy["provenance"]["protocol"], "transport": {"kind": "file", "address": "recording:AERIS-HW-000001"},
                             "source_kind": "physical", "synthetic": False, "hellos": [{k: v for k, v in PHYS.items() if k != "type"}]}
    rows = {}
    for rid, d, syn in (("AERIS-HW-900001", legacy, True), ("AERIS-HW-900002", copy_v5, False)):
        stored = {"id": rid, "created": "2026-09-01T00:00:00+00:00", "document": d, "content_hash": canonical_hash(d), "quality": {"n": 6}, "warnings": [], "synthetic": syn, "source": "telemetry-recorder",
                  "provenance": {"synthetic": syn, "source_kind": d["provenance"]["source_kind"]}}
        assert repo.put_new("recordings", rid, stored, device=d["device"]["id"], mode=d["mode"], synthetic=syn, source="telemetry-recorder",
                            source_kind=d["provenance"]["source_kind"], name="v5 row", samples=6)
        rows[rid] = json.dumps(repo.get("recordings", rid), sort_keys=True)
    listed = {r["id"]: r for r in api.get("/api/v1/hardware/recordings?limit=1000").json()["recordings"]}
    assert listed["AERIS-HW-900001"]["trust"] == "synthetic" and listed["AERIS-HW-900001"]["synthetic"] is True
    assert (listed["AERIS-HW-900002"]["trust"], listed["AERIS-HW-900002"]["derived"]) == ("declared-physical", True)
    assert all(json.dumps(repo.get("recordings", rid), sort_keys=True) == before for rid, before in rows.items())   # nothing rewritten
    ev = compare(api, "AERIS-HW-900002", protocol_before(api))["evidence"]
    assert ev["admissible_as_validation_evidence"] is False and any("captured from a replay" in x for x in ev["reasons"])


def test_api_an_uploaded_recording_without_a_seq_column_exports_and_replays(api):
    """v5 answered HTTP 500 here (the NDJSON export required a seq column; uploads need not have one): the row index
    now stands in for seq. Found while testing the restart path with a short low-rate replay (v5.1)."""
    n = 12
    doc = {"schema": "aeris-hardware-run/1", "synthetic": True, "device": {"id": "low-rate-fixture", "firmware": "none"},
           "recording": {"started": "2026-10-01T00:00:00Z", "notes": "SYNTHETIC low-rate fixture without seq"}, "mode": "corner",
           "samples": {"rate_hz": 5, "cols": {"t": [0.2 * k for k in range(n)], "q0": [1.0] * n, "q1": [0.0] * n, "q2": [0.0] * n, "q3": [0.0] * n},
                       "units": {"t": "s", "q0": "1", "q1": "1", "q2": "1", "q3": "1"}}}
    up = api.post("/api/v1/hardware/recordings", json=doc)
    assert up.status_code == 201 and up.json()["synthetic"] is True
    nd = api.get(f"/api/v1/hardware/recordings/{up.json()['id']}/export?format=ndjson")
    assert nd.status_code == 200
    lines = [json.loads(x) for x in nd.text.splitlines()]
    assert [x["seq"] for x in lines if x["type"] == "frame"] == list(range(n))
    assert [(h["device"]["kind"], h["synthetic"]) for h in lines if h["type"] == "hello"] == [("file-replay", True)]
    rec = replay_and_record(api, {"source": "recording", "recording_id": up.json()["id"]}, "replay of the low-rate upload")
    assert rec["synthetic"] is True and rec["quality"]["n"] >= 5

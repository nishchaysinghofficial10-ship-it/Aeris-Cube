"""Fix B (v5): restart recovery with REAL backend processes on a temporary database.

1. The server process exits hard (os._exit, fault injection) right after a single run was saved; a
   new server process finishes the job from the saved run without recomputing it.
2. The server process is killed with SIGKILL in the middle of a sweep that stores its runs; a new
   server process resumes it: every row exactly once, one run per row, monotone progress.
3. A second server on the same database is refused while the first one runs.
4. When the server process is killed, its worker processes exit too (no orphans left computing).
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid

import pytest

pytestmark = pytest.mark.skipif(sys.platform.startswith("win"), reason="POSIX signals")
HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class Server:
    def __init__(self, db, env=None):
        self.port = free_port()
        e = dict(os.environ, PYTHONPATH=BACKEND, AERIS_WORKERS="1", AERIS_MAX_JOBS="1")
        e.pop("AERIS_FAULT_INJECT", None)
        e.update(env or {})
        self.log = open(db + f".{self.port}.log", "w")
        self.proc = subprocess.Popen([sys.executable, "-m", "aeris_backend.api.main", "--port", str(self.port), "--db", db, "--log-level", "warning"],
                                     cwd=BACKEND, env=e, stdout=self.log, stderr=subprocess.STDOUT)
        self.base = f"http://127.0.0.1:{self.port}/api/v1"

    def wait_ready(self, timeout=60):
        t0 = time.time()
        while time.time() - t0 < timeout:
            if self.proc.poll() is not None:
                raise AssertionError(f"server exited with {self.proc.returncode}: {open(self.log.name).read()[-2000:]}")
            try:
                return self.get("/health")
            except (urllib.error.URLError, ConnectionError, OSError):
                time.sleep(0.1)
        raise AssertionError("server did not start")

    def get(self, path):
        with urllib.request.urlopen(self.base + path, timeout=10) as r:
            return json.loads(r.read())

    def post(self, path, body):
        req = urllib.request.Request(self.base + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read())

    def wait_job(self, jid, states=("complete", "failed", "cancelled"), timeout=120):
        t0 = time.time()
        while time.time() - t0 < timeout:
            j = self.get(f"/jobs/{jid}")
            if j["state"] in states:
                return j
            time.sleep(0.05)
        raise AssertionError(f"job {jid} did not reach {states}: {j}")

    def stop(self):
        if self.proc.poll() is None:
            self.proc.send_signal(signal.SIGTERM)
            try:
                self.proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait()
        self.log.close()


def db_rows(db, q, args=()):
    c = sqlite3.connect(db)
    try:
        return c.execute(q, args).fetchall()
    finally:
        c.close()


def test_process_exit_after_saving_a_run_then_restart_finishes_it(tmp_path):
    db = str(tmp_path / "restart.sqlite3")
    a = Server(db, {"AERIS_ALLOW_FAULT_INJECTION": "1", "AERIS_FAULT_INJECT": "single.after_save:exit"})
    try:
        a.wait_ready()
        jid = a.post("/simulations", {"config": {"mode": "corner", "duration_s": 1, "estimator": {"type": "mekf"}}})["job"]["id"]
        assert a.proc.wait(timeout=120) == 86                      # the process died right after the transaction
    finally:
        a.stop()
    state, ref = db_rows(db, "SELECT state, result_ref FROM jobs WHERE id=?", (jid,))[0]
    runs = db_rows(db, "SELECT id, created FROM runs WHERE job_id=?", (jid,))
    assert state == "analyzing" and len(runs) == 1 and json.loads(ref) == {"kind": "run", "id": runs[0][0]}
    b = Server(db)
    try:
        h = b.wait_ready()
        j = b.wait_job(jid)
        assert j["state"] == "complete" and j["result_ref"] == {"kind": "run", "id": runs[0][0]} and "nothing was recomputed" in j["message"]
        assert any(r["job"] == jid and r["action"].startswith("finalized") for r in b.get("/health")["recovery"]["jobs"])
        assert h["schema_version"] == 3
        rec = b.get(f"/runs/{runs[0][0]}")
        assert rec["created"] == runs[0][1] and rec["experiment_id"] == j["extra"]["ids"]["experiment_id"]
    finally:
        b.stop()
    assert db_rows(db, "SELECT COUNT(*) FROM runs WHERE job_id=?", (jid,))[0][0] == 1


def test_sigkill_during_a_sweep_then_restart_resumes_without_duplicates(tmp_path):
    db = str(tmp_path / "sweep.sqlite3")
    sweep = {"name": "kill -9", "revision": "1.2", "mode": "grid", "base": {"mode": "edge"}, "controllers": ["lqr", "pid"],
             "variables": [{"key": "tilt_deg", "min": 0, "max": 3, "steps": 12}], "duration_s": 3, "record_hz": 10, "store_runs": True}
    a = Server(db)
    try:
        a.wait_ready()
        job = a.post("/sweeps", {"sweep": sweep})["job"]
        jid, sid = job["id"], job["result_ref"]["id"]
        t0 = time.time()
        done_seen = []
        while time.time() - t0 < 120:
            j = a.get(f"/jobs/{jid}")
            done_seen.append(j["progress"]["done"])
            if j["progress"]["done"] >= 5:
                break
            time.sleep(0.05)
        os.kill(a.proc.pid, signal.SIGKILL)
        a.proc.wait(timeout=30)
    finally:
        a.stop()
    stored = db_rows(db, "SELECT COUNT(*) FROM sweep_rows WHERE sweep_id=?", (sid,))[0][0]
    assert 5 <= stored < 24 and db_rows(db, "SELECT state FROM jobs WHERE id=?", (jid,))[0][0] == "running"
    assert db_rows(db, "SELECT COUNT(*) FROM runs WHERE sweep_id=?", (sid,))[0][0] == stored
    b = Server(db)
    try:
        b.wait_ready()
        seen = []
        t0 = time.time()
        while time.time() - t0 < 180:
            j = b.get(f"/jobs/{jid}")
            seen.append(j["progress"]["done"])
            if j["state"] in ("complete", "failed", "cancelled"):
                break
            time.sleep(0.05)
        assert j["state"] == "complete" and j["restarts"] == 1 and j["progress"]["done"] == 24
        assert seen == sorted(seen) and seen[0] >= stored                 # monotone across the restart
        sw = b.get(f"/sweeps/{sid}")
        assert sw["status"] == "complete" and len(sw["rows"]) == 24 and len({r["index"] for r in sw["rows"]}) == 24
    finally:
        b.stop()
    runs = db_rows(db, "SELECT row_index, COUNT(*) FROM runs WHERE sweep_id=? GROUP BY row_index", (sid,))
    assert len(runs) == 24 and all(n == 1 for _, n in runs)
    assert done_seen == sorted(done_seen)


def test_second_server_on_the_same_database_is_refused(tmp_path):
    db = str(tmp_path / "lock.sqlite3")
    a = Server(db)
    try:
        a.wait_ready()
        b = Server(db)
        try:
            assert b.proc.wait(timeout=60) != 0
        finally:
            b.stop()
        assert "in use by another AERIS backend process" in open(b.log.name).read()
        assert a.get("/health")["status"] == "ok"
    finally:
        a.stop()


def _marked_processes(mark):
    """Live processes whose environment carries this test's marker (Linux /proc): the server, its worker
    processes and the multiprocessing helper process all inherit it. Zombies do not count."""
    out = []
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        try:
            with open(f"/proc/{d}/environ", "rb") as f:
                if f"AERIS_TEST_MARK={mark}".encode() not in f.read().split(b"\0"):
                    continue
            with open(f"/proc/{d}/stat") as f:
                if f.read().rsplit(")", 1)[1].split()[0] == "Z":
                    continue
            out.append(int(d))
        except (OSError, IndexError):
            continue
    return out


@pytest.mark.skipif(not os.path.isdir("/proc"), reason="finds the worker processes through /proc (Linux)")
def test_worker_processes_exit_when_the_backend_process_is_killed(tmp_path):
    db = str(tmp_path / "orphans.sqlite3")
    mark = uuid.uuid4().hex
    sweep = {"name": "orphans", "revision": "1.2", "mode": "grid", "base": {"mode": "corner"}, "controllers": ["lqr"],
             "variables": [{"key": "tilt_deg", "min": 0.5, "max": 3, "steps": 40}], "duration_s": 4, "record_hz": 10}
    a = Server(db, {"AERIS_WORKERS": "2", "AERIS_TEST_MARK": mark})
    try:
        a.wait_ready()
        jid = a.post("/sweeps", {"sweep": sweep})["job"]["id"]
        t0 = time.time()
        while time.time() - t0 < 120 and a.get(f"/jobs/{jid}")["progress"]["done"] < 2:
            time.sleep(0.05)
        before = _marked_processes(mark)
        workers = [p for p in before if p != a.proc.pid]
        assert a.proc.pid in before and len(workers) >= 2          # the server, its two workers (and the helper process)
        os.kill(a.proc.pid, signal.SIGKILL)
        a.proc.wait(timeout=30)
        t0 = time.time()
        left = _marked_processes(mark)
        while left and time.time() - t0 < 15:                         # bounded wait for the workers to notice
            time.sleep(0.1)
            left = _marked_processes(mark)
        assert left == [], f"processes of the killed server still running after {time.time() - t0:.1f} s: {left}"
    finally:
        for p in _marked_processes(mark):                             # never leave anything behind, even on failure
            with __import__("contextlib").suppress(OSError):
                os.kill(p, signal.SIGKILL)
        a.stop()


def _ps_table():
    """{pid: (ppid, state, command)} of every process, from POSIX ps (the same options on macOS and Linux)."""
    out = subprocess.run(["ps", "-A", "-o", "pid=", "-o", "ppid=", "-o", "stat=", "-o", "command="], capture_output=True, text=True, check=True).stdout
    table = {}
    for line in out.splitlines():
        parts = line.split(None, 3)
        if len(parts) >= 3 and parts[0].isdigit() and parts[1].isdigit():
            table[int(parts[0])] = (int(parts[1]), parts[2], parts[3] if len(parts) > 3 else "")
    return table


def _descendants(pid, table):
    kids, todo = [], [pid]
    while todo:
        p = todo.pop()
        for c, (pp, _, _) in table.items():
            if pp == p and c not in kids:
                kids.append(c)
                todo.append(c)
    return kids


@pytest.mark.skipif(shutil.which("ps") is None, reason="needs the POSIX ps command")
def test_worker_processes_exit_when_the_backend_process_is_killed_portable_ps(tmp_path):
    """The same guarantee as the /proc test above, found with POSIX ps instead of /proc, so it also runs on macOS
    (v5.1): the backend's worker processes (every descendant, found before the kill) are gone within a bounded
    time after the backend process is killed with SIGKILL. Zombies (exited, not yet reaped) do not count."""
    db = str(tmp_path / "orphans-ps.sqlite3")
    sweep = {"name": "orphans (ps)", "revision": "1.2", "mode": "grid", "base": {"mode": "corner"}, "controllers": ["lqr"],
             "variables": [{"key": "tilt_deg", "min": 0.5, "max": 3, "steps": 40}], "duration_s": 4, "record_hz": 10}
    a = Server(db, {"AERIS_WORKERS": "2"})
    kids = []
    try:
        a.wait_ready()
        jid = a.post("/sweeps", {"sweep": sweep})["job"]["id"]
        t0 = time.time()
        while time.time() - t0 < 120 and a.get(f"/jobs/{jid}")["progress"]["done"] < 2:
            time.sleep(0.05)
        table = _ps_table()
        kids = _descendants(a.proc.pid, table)
        assert len([k for k in kids if "python" in table[k][2].lower()]) >= 2, [(k, table[k]) for k in kids]    # the two workers (and helpers)
        os.kill(a.proc.pid, signal.SIGKILL)
        a.proc.wait(timeout=30)

        def alive():
            t = _ps_table()
            return [(k, t[k][1], t[k][2][:80]) for k in kids if k in t and not t[k][1].startswith("Z")]
        t0 = time.time()
        left = alive()
        while left and time.time() - t0 < 15:                         # bounded wait for the workers to notice
            time.sleep(0.1)
            left = alive()
        assert left == [], f"processes of the killed server still running after {time.time() - t0:.1f} s: {left}"
    finally:
        t = _ps_table()
        for k in kids:                                                # never leave anything behind, even on failure
            if k in t and not t[k][1].startswith("Z"):
                with __import__("contextlib").suppress(OSError):
                    os.kill(k, signal.SIGKILL)
        a.stop()

"""Parameter provenance (docs/PARAMETERS.md): every measurable model input can be supplied by a versioned
parameter set, and each run reports exactly which of its inputs are measured, overridden or nominal.
All values here are test fixtures, not measurements."""
from __future__ import annotations

import pytest

from aeris_backend.config.normalize import normalize
from aeris_backend.experiments.provenance import (apply_parameter_set, canonical_path, check_value, coverage, model_inputs, set_status,
                                                  spec_of)
from aeris_backend.simulation import simulate

EV = {"method": "fixture", "date": "2026-09-01", "evidence": "tests (not a measurement)"}


def pv(value, unit):
    return dict(EV, value=value, unit=unit)


@pytest.mark.parametrize("path,value,unit,ok", [
    ("params.m", 1.9, "kg", True), ("params.m", 1.9, "g", False), ("params.m", 99.0, "kg", False),
    ("params.g", 9.81, "m/s²", False), ("params.nonsense", 1.0, "–", False),
    ("plant.base_inertia_kgm2", [[0.012, 0.0002, 0], [0.0002, 0.0121, 0.0001], [0, 0.0001, 0.0119]], "kg·m²", True),
    ("plant.base_inertia_kgm2", [[0.012, 0.0, 0], [0.0, 0.001, 0], [0, 0, 0.02]], "kg·m²", False),       # triangle inequality
    ("plant.base_inertia_kgm2", [[0.012, 0.001, 0], [0.0, 0.012, 0], [0, 0, 0.012]], "kg·m²", False),    # not symmetric
    ("plant.base_com_m", [0.05, 0.05, 0.051], "m", True), ("plant.base_com_m", [0.05, 0.05], "m", False),
    ("comShift_m", [0.001, 0, 0], "m", True), ("comOffset_m", 0.002, "m", True),
    ("wheels.x.Jw", 3.2e-4, "kg·m²", True), ("wheels.y.axis", [0, 1, 0], "–", True), ("wheels.z.KV", 400, "rpm/V", True),
    ("wheels.x.Jw", 3.2e-4, "kg*m^2", False),
    ("sensor.gyro_noise_dps", 0.1, "°/s", True), ("sensor.latency_ms", 4, "ms", True), ("sensor.rate_hz", 200, "Hz", True),
    ("sensor.imu_position_m", [0.02, 0.03, 0.04], "m", True), ("actuator.motor_lag_ms", 12, "ms", True),
    ("plant.components.bat.mass_kg", 0.12, "kg", True), ("plant.components.bat.inertia_kgm2", [[2e-5, 0, 0], [0, 3e-5, 0], [0, 0, 2e-5]], "kg·m²", True),
    ("attachments.m1.pos_m", [0.05, 0.1, 0.1], "m", True),
])
def test_every_measurable_input_has_a_unit_and_shape_check(path, value, unit, ok):
    errs = check_value(path, value, unit)
    assert (not errs) == ok, errs


def test_legacy_bare_names_are_params_paths():
    assert canonical_path("Jw") == "params.Jw" and canonical_path("plant.base_com_m") == "plant.base_com_m"
    assert spec_of("params.Jw") == ("kg·m²", "scalar")


def test_model_inputs_follow_what_the_run_uses():
    edge, _ = normalize({"mode": "edge"})
    base = set(model_inputs(edge))
    assert "params.kJ" in base and "params.g" not in base and "params.rImu" not in base and not any(p.startswith("sensor.") for p in base)
    assert {"comOffset_m", "comShift_m", "actuator.motor_lag_ms", "params.fs"} <= base
    est, _ = normalize({"mode": "edge", "estimator": {"type": "kf"}})
    e = set(model_inputs(est))
    assert "params.rImu" in e and "sensor.gyro_noise_dps" in e and "sensor.rate_hz" in e
    full, _ = normalize({"mode": "corner", "plant": {"base_inertia_kgm2": [[0.0118, 0.0002, 0.0], [0.0002, 0.0121, 0.0001], [0.0, 0.0001, 0.0119]], "base_com_m": [0.05, 0.05, 0.05],
                                                     "components": [{"id": "bat", "mass_kg": 0.1, "com_m": [0.05, 0.02, 0.02]}]},
                         "wheels": [{"id": "a", "axis": [1, 0, 0]}, {"id": "b", "axis": [0, 1, 0]}, {"id": "c", "axis": [0, 0, 1]}, {"id": "d", "axis": [0.57735, 0.57735, 0.57735]}],
                         "attachments": [{"id": "m1", "label": "m", "mass_kg": 0.02, "pos_m": [0.05, 0.1, 0.1]}]})
    f = set(model_inputs(full))
    assert "params.kJ" not in f and "plant.base_inertia_kgm2" in f and "plant.base_com_m" in f
    assert "plant.components.bat.mass_kg" in f and "attachments.m1.pos_m" in f
    assert {"wheels.d.Jw", "wheels.d.axis", "wheels.a.KV"} <= f and "params.Jw" not in f       # per-wheel inputs replace the shared ones


def test_coverage_measured_overridden_nominal():
    cfg, _ = normalize({"mode": "edge"})
    inputs = model_inputs(cfg)
    ps = {"id": "t", "values": {p: pv(v, spec_of(p)[0]) for p, v in inputs.items()}}
    c = coverage(cfg, ps)
    assert c["status"] == "measured" and c["nominal"] == [] and c["overridden"] == []
    cfg2, _ = normalize({"mode": "edge", "params": {"cv": 3.3e-5}})
    c2 = coverage(cfg2, ps)
    assert c2["status"] == "partially-measured" and c2["overridden"] == ["params.cv"]
    cfg3, _ = normalize({"mode": "edge", "estimator": {"type": "cf"}})
    c3 = coverage(cfg3, ps)
    assert c3["status"] == "partially-measured" and "sensor.dropout" in c3["nominal"]
    ps4 = dict(ps, values=dict(ps["values"], **{"plant.base_com_m": pv([0.05, 0.05, 0.05], "m")}))
    assert coverage(cfg, ps4)["unused_in_set"] == ["plant.base_com_m"]
    assert coverage(cfg, None)["status"] == "nominal"


def test_per_wheel_values_are_applied_and_change_the_run():
    base = {"mode": "corner", "duration_s": 1, "initial": {"tilt_deg": 3}}
    ps = {"id": "w", "values": {"wheels.z.Jw": pv(4.5e-4, "kg·m²"), "params.m": pv(1.85, "kg")}}
    cfg, replaced = apply_parameter_set(base, ps)
    assert cfg["wheels"][2]["Jw"] == 4.5e-4 and cfg["params"]["m"] == 1.85 and {r["param"] for r in replaced} == {"wheels.z.Jw", "params.m"}
    a, b = simulate(base), simulate(cfg)
    assert a["ok"] and b["ok"] and a["samples"]["cols"]["omega_z"] != b["samples"]["cols"]["omega_z"]
    cov = coverage(b["config"], ps)
    assert "wheels.z.Jw" in cov["measured"] and "wheels.x.Jw" in cov["nominal"] and cov["status"] == "partially-measured"


def test_set_status_needs_every_standard_input_including_the_sensor_model():
    cfg, _ = normalize({"mode": "corner", "estimator": {"type": "mekf"}})
    vals = {p: pv(v, spec_of(p)[0]) for p, v in model_inputs(cfg).items()}
    assert set_status(vals)["status"] == "measured"
    del vals["sensor.dropout"]
    st = set_status(vals)
    assert st["status"] == "partially-measured" and st["missing"] == ["sensor.dropout"]

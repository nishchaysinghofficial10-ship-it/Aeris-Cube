import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from aeris_backend.config.validate import validate_config  # noqa: E402
from aeris_backend.control.controllers import Controller, Request  # noqa: E402
from aeris_backend.physics.mass import mass_properties  # noqa: E402
from aeris_backend.simulation.engine import Engine  # noqa: E402

REPO = os.path.dirname(os.path.dirname(HERE))


def engine_for(raw, *, g=None, controller=None, precise=True):
    """An Engine for a validated configuration; g may be overridden AFTER validation (isolated
    physics tests use g = 0, which the configuration ranges do not allow)."""
    v = validate_config(raw, {"minDuration_s": 0.005})
    assert v.ok, v.errors
    cfg = v.config
    eng = Engine(cfg, mass_properties(cfg), precise=precise)
    if g is not None:
        cfg["params"]["g"] = g
        # without gravity the pivot carries no load, so the lift-off rule would end the run at once
        cfg["termination"]["check_lift_off"] = False
        if cfg["mode"] == "edge":
            eng.design["plant"]["mgl"] = eng.design["plant"]["mgl"] * (g / 9.81)
    if controller is not None:
        eng.controller = controller(eng.ctx)
    return eng


class ConstTorque(Controller):
    """Test controller: a fixed torque request per wheel (open loop)."""
    type = "test-const"
    T = (0.0, 0.0, 0.0)

    def request(self, t, est, ww, failed):
        return Request(per_wheel=list(self.T))


def const_torque(T):
    return type("C", (ConstTorque,), {"T": tuple(T)})


@pytest.fixture
def tmp_db(tmp_path):
    return str(tmp_path / "test.sqlite3")

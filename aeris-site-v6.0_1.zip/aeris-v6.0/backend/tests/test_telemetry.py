"""The telemetry path (docs/TELEMETRY.md): transport → strict validation → normalised stream → storage → live
clients → recorded replay → offline comparison. Every source here is SYNTHETIC — the standalone emulator or
hand-made test lines declaring kind 'emulator'/'test' — and the tests check that this label survives each
stage and that such data can never count as a physical connection or as validation evidence."""
from __future__ import annotations

import asyncio
import json
import math
import threading
import time

import pytest
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app
from aeris_backend.hardware.bridge import HubBridge, parse_bridge_setting
from aeris_backend.hardware.ingest import validate_recording
from aeris_backend.telemetry.device import AdapterError, MappedJsonAdapter, check_mapping
from aeris_backend.telemetry.emulator import Emulator, parse_faults
from aeris_backend.telemetry.protocol import CONVENTIONS, MAX_LINE, UNITS, dumps, hello_message, parse_line, validate_hello
from aeris_backend.telemetry.stream import TelemetryHub, recording_to_ndjson
from aeris_backend.telemetry.transport import TOO_LONG, FileReplaySource, LineSplitter, TcpNdjsonSource, check_host

HELLO = hello_message("unit-test", "test", "none", True, "corner", 100)


def frame(seq, t=None, **kw):
    f = {"type": "frame", "t": seq * 0.01 if t is None else t, "seq": seq, "q": [1, 0, 0, 0], "w": [0.0, 0.0, 0.0], "status": "ok"}
    f.update(kw)
    return json.dumps(f).encode()


def hub_with_hello(**kw):
    h = TelemetryHub(**kw)
    h.on_connect({"kind": "test", "address": "memory"}, 0.0)
    assert h.feed_line(dumps(HELLO), 0.0) == "hello"
    return h


# ---------------------------------------------------------------- protocol: lines, hello, frames
@pytest.mark.parametrize("raw,reason", [
    (b"{not json", "not_json"), (b"\xff\xfe{}", "not_utf8"), (b"   ", "empty_line"), (b"[1, 2]", "not_an_object"),
    (b'{"type": "sample"}', "unknown_type"), (b"{" + b" " * (MAX_LINE + 1) + b"}", "line_too_long"),
])
def test_malformed_lines_are_rejected_with_a_reason(raw, reason):
    assert parse_line(raw) == (None, reason)
    h = hub_with_hello()
    assert h.feed_line(raw, 0.1) == "rejected:" + reason
    assert h.rejected_by_reason[reason] == 1 and h.counters["frames_accepted"] == 0


def test_hello_rules_synthetic_and_conventions():
    assert validate_hello(HELLO)["ok"]
    emu_not_synth = hello_message("e", "emulator", "x", False, "corner")
    assert any("must declare synthetic: true" in e for e in validate_hello(emu_not_synth)["errors"])
    phys_synth = hello_message("p", "physical", "fw", True, "corner")
    assert any("'physical' source must declare synthetic: false" in e for e in validate_hello(phys_synth)["errors"])
    no_flag = {k: v for k, v in HELLO.items() if k != "synthetic"}
    assert any("never inferred" in e for e in validate_hello(no_flag)["errors"])
    ned = dict(HELLO, conventions=dict(CONVENTIONS, world_axes="z down (NED)"))
    assert any("conventions.world_axes" in e and "frame/axis mismatch" in e for e in validate_hello(ned)["errors"])
    xyzw = dict(HELLO, conventions=dict(CONVENTIONS, quaternion="x,y,z,w"))
    assert any("conventions.quaternion" in e for e in validate_hello(xyzw)["errors"])


def test_frames_need_a_valid_hello_first():
    h = TelemetryHub()
    h.on_connect({"kind": "test"}, 0.0)
    assert h.feed_line(frame(0), 0.0) == "rejected:no_valid_hello"
    bad = dict(HELLO, device={"id": "x", "kind": "emulator", "firmware": "f"}, synthetic=False)
    assert h.feed_line(dumps(bad), 0.0) == "rejected:invalid_hello"
    assert h.feed_line(frame(1), 0.0) == "rejected:no_valid_hello"
    assert h.feed_line(dumps(HELLO), 0.0) == "hello" and h.feed_line(frame(2), 0.0) == "frame"


def test_unit_and_frame_errors_are_rejected_never_converted():
    h = hub_with_hello()
    assert h.feed_line(frame(0, units=dict(UNITS, w="deg/s")), 0.0) == "rejected:unit_mismatch"
    assert h.feed_line(frame(1, units={"wheel_rpm": "rad/s"}), 0.0) == "rejected:unit_mismatch"
    assert h.feed_line(frame(2, units=dict(UNITS)), 0.0) == "frame"                           # declaring the contract units is fine
    assert h.feed_line(frame(3, q=[1.01, 0, 0, 0]), 0.0) == "rejected:non_unit_quaternion"   # |q| = 1.01 > 1 ± 1e-3
    assert h.feed_line(frame(4, q=[0.99999, 0.0, 0.0, 0.0]), 0.0) == "frame"                  # within tolerance
    assert h.feed_line(frame(5, w=[0, 0]), 0.0) == "rejected:invalid_frame"
    assert h.feed_line(frame(6, mode="edge"), 0.0) == "rejected:invalid_frame"                # the session hello says corner
    assert h.feed_line(json.dumps({"type": "frame", "t": 0.2, "q": [1, 0, 0, 0]}).encode(), 0.0) == "rejected:invalid_frame"   # no seq
    assert h.feed_line(frame(7, w=[0, "1", 0]), 0.0) == "rejected:invalid_frame"            # a string is never coerced
    edge = TelemetryHub()
    edge.on_connect({"kind": "test"}, 0)
    edge.feed_line(dumps(hello_message("e", "test", "none", True, "edge")), 0)
    assert edge.feed_line(frame(0), 0) == "rejected:invalid_frame"                            # edge frames need theta
    assert edge.feed_line(json.dumps({"type": "frame", "t": 0.0, "seq": 0, "theta": 0.01}).encode(), 0) == "frame"


def test_duplicates_gaps_out_of_order_and_time():
    h = hub_with_hello()
    res = [h.feed_line(frame(s), 0.0) for s in (0, 1, 1, 2, 5, 4, 6)]
    assert res == ["frame", "frame", "duplicate", "frame", "frame", "out_of_order", "frame"]
    c = h.counters
    assert c["duplicates"] == 1 and c["out_of_order"] == 1 and c["gaps"] == 1 and c["dropped_by_source"] == 2 and c["frames_accepted"] == 5
    assert h.feed_line(frame(7, t=0.06), 0.0) == "rejected:time_not_increasing"             # t must increase with seq
    assert [f["n"] for f in h.recent] == [1, 2, 3, 4, 5]                                    # hub index: strictly increasing


def test_stale_and_fresh_events():
    h = hub_with_hello(stale_after_s=0.5)
    h.feed_line(frame(0), 1.0)
    h.tick(1.4)
    assert not h.stale
    h.tick(1.6)
    assert h.stale and h.counters["stale_events"] == 1
    h.tick(3.0)
    assert h.counters["stale_events"] == 1                                                   # one event per stale period
    h.feed_line(frame(1), 3.1)
    assert not h.stale and [e["type"] for e in h.events][-2:] == ["stale", "fresh"]
    assert h.status(3.2)["stale"] is False


def test_disconnect_reconnect_starts_a_new_session():
    h = hub_with_hello()
    h.feed_line(frame(0), 0.0)
    h.feed_line(frame(1), 0.0)
    h.on_disconnect("test", 0.1)
    assert not h.connected and h.feed_line(frame(2), 0.2) == "rejected:no_valid_hello"      # after a disconnect: no frames without a new hello
    h.on_connect({"kind": "test"}, 0.3)
    assert h.counters["reconnects"] == 1 and h.hello is None
    h.feed_line(dumps(HELLO), 0.3)
    assert h.feed_line(frame(0, t=0.0), 0.3) == "frame"                                     # a restarted device may restart seq and t
    assert h.session == 2


def test_slow_consumer_is_bounded_and_never_blocks_the_reader():
    h = hub_with_hello()
    slow = h.subscribe(maxsize=10)
    fast = h.subscribe(maxsize=1000)
    for s in range(100):
        assert h.feed_line(frame(s), 0.0) == "frame"
    assert len(slow.queue) == 10 and slow.dropped == 90
    assert [f["seq"] for f in slow.drain()] == list(range(90, 100))                        # the newest frames survive
    assert len(fast.drain()) == 100 and fast.dropped == 0
    h.max_subscribers = 2
    with pytest.raises(OverflowError):
        h.subscribe()
    poll = h.frames_after(95)
    assert [f["seq"] for f in poll["frames"]] == [95, 96, 97, 98, 99] and poll["missed"] == 0


def test_polling_reports_frames_that_left_the_buffer():
    h = hub_with_hello(recent_frames=10)
    for s in range(30):
        h.feed_line(frame(s), 0.0)
    p = h.frames_after(5)
    assert p["missed"] == 15 and p["frames"][0]["n"] == 21 and p["last_n"] == 30


def test_line_splitter_limits_and_truncation():
    sp = LineSplitter(max_line=16)
    out = sp.feed(b'{"a":1}\n' + b"x" * 40)
    assert out == [b'{"a":1}', TOO_LONG]
    assert sp.feed(b"yyy\n" + b'{"b":2}\n') == [b'{"b":2}']                                # the tail of the long line is discarded
    assert sp.feed(b'{"c":') == [] and sp.tail() == b'{"c":'


def test_loopback_is_the_default():
    assert check_host("127.0.0.1", False) is None and check_host("localhost", False) is None and check_host("::1", False) is None
    assert "not a loopback address" in check_host("192.168.1.20", False)
    assert check_host("192.168.1.20", True) is None
    with pytest.raises(ValueError):
        TcpNdjsonSource(TelemetryHub(), "10.0.0.5", 47100)


# ---------------------------------------------------------------- the emulator over real TCP
def run_emulator_in_thread(emu, speed=4.0):
    ports, stop = [], {}

    def target():
        loop = asyncio.new_event_loop()
        stop["loop"] = loop
        task = loop.create_task(emu.serve("127.0.0.1", 0, speed=speed, ready=ports.append))
        stop["task"] = task
        try:
            loop.run_until_complete(task)
        except (asyncio.CancelledError, Exception):
            pass
    th = threading.Thread(target=target, daemon=True)
    th.start()
    t0 = time.time()
    while not ports and time.time() - t0 < 30:
        time.sleep(0.01)
    assert ports, "emulator did not start"

    def shutdown():
        stop["loop"].call_soon_threadsafe(stop["task"].cancel)
        th.join(5)
    return ports[0], shutdown


async def collect(hub, port, seconds, **kw):
    src = TcpNdjsonSource(hub, "127.0.0.1", port, backoff=(0.05, 0.2), **kw)
    src.start()
    t_end = time.monotonic() + seconds
    while time.monotonic() < t_end:
        hub.tick(time.monotonic())
        await asyncio.sleep(0.02)
    await src.stop()
    return src


def test_emulator_faults_are_detected_end_to_end_over_tcp():
    emu = Emulator(mode="corner", rate_hz=100, seed=5,
                   faults="drop=0.03,duplicate=0.03,reorder=0.03,malformed=0.02,bad_quaternion=0.02,wrong_units=0.02,disconnect_after=120")
    port, shutdown = run_emulator_in_thread(emu, speed=5.0)
    hub = TelemetryHub()
    try:
        asyncio.run(collect(hub, port, 2.5))
    finally:
        shutdown()
    c = hub.counters
    assert c["frames_accepted"] > 300
    assert c["duplicates"] > 0 and c["out_of_order"] > 0 and c["gaps"] > 0 and c["dropped_by_source"] >= c["gaps"]
    assert hub.rejected_by_reason.get("not_json", 0) > 0 and hub.rejected_by_reason.get("non_unit_quaternion", 0) > 0
    assert hub.rejected_by_reason.get("unit_mismatch", 0) > 0
    assert c["reconnects"] >= 2 and c["disconnects"] >= 2
    p = hub.provenance()
    assert p["synthetic"] is True and p["source_kind"] == "emulator" and p["declared_physical"] is False and p["physical_verified"] is False
    assert "SYNTHETIC EMULATOR" in p["label"] and "not the physical cube" in p["label"]
    seqs = [f["seq"] for f in hub.recent if f["session"] == hub.session]
    assert seqs == sorted(set(seqs))                                                         # delivered frames: strictly increasing per session


def test_recording_export_replay_round_trip_keeps_values_and_provenance():
    emu = Emulator(mode="corner", rate_hz=100, seed=2, faults="drop=0.02,disconnect_after=90")
    port, shutdown = run_emulator_in_thread(emu, speed=5.0)
    hub = TelemetryHub()

    async def go():
        src = TcpNdjsonSource(hub, "127.0.0.1", port, backoff=(0.05, 0.2))
        src.start()
        while hub.counters["frames_accepted"] < 20:
            await asyncio.sleep(0.01)
        hub.start_recording("round trip", time.monotonic())
        while hub.counters["reconnects"] < 2:
            await asyncio.sleep(0.02)
        await asyncio.sleep(0.2)
        doc = hub.stop_recording(time.monotonic())
        await src.stop()
        return doc
    try:
        doc = asyncio.run(go())
    finally:
        shutdown()
    v = validate_recording(doc)
    assert v["ok"], v["errors"]
    assert doc["synthetic"] is True and v["synthetic"] is True
    prov = doc["provenance"]
    assert prov["source_kind"] == "emulator" and prov["synthetic"] and "SYNTHETIC" in prov["note"] and prov["stream_quality"]["reconnects"] >= 1
    assert {"disconnect", "connect", "hello"} <= {e["type"] for e in prov["events"]}
    t = doc["samples"]["cols"]["t"]
    assert all(b > a for a, b in zip(t, t[1:])) and v["quality"]["dropouts"] > 0            # the gaps stay visible
    nd = recording_to_ndjson(doc)
    first = json.loads(nd.splitlines()[0])
    assert first["type"] == "hello" and first["synthetic"] is True and first["device"]["kind"] == "emulator"
    hub2 = TelemetryHub()
    asyncio.run(FileReplaySource(hub2, text=nd, label="round-trip", speed=0).run())
    assert hub2.counters["frames_accepted"] == len(t) and hub2.counters["rejected"] == 0
    got = list(hub2.recent)[-len(t):]
    cols = doc["samples"]["cols"]
    for i in (0, len(t) // 2, len(t) - 1):
        assert got[i]["t"] == cols["t"][i] and got[i]["q"] == [cols[f"q{j}"][i] for j in range(4)]
        assert got[i]["wheel_rpm"] == [cols[f"wheel_rpm_{a}"][i] for a in "xyz"]
    p2 = hub2.provenance()
    assert p2["replay"] is True and p2["synthetic"] is True and "SYNTHETIC" in p2["label"]


def test_device_restarting_its_clock_is_rebased_and_marked():
    emu = Emulator(mode="edge", rate_hz=100, seed=4, faults="disconnect_after=60,restart_clock=1")
    port, shutdown = run_emulator_in_thread(emu, speed=5.0)
    hub = TelemetryHub()

    async def go():
        src = TcpNdjsonSource(hub, "127.0.0.1", port, backoff=(0.05, 0.2))
        src.start()
        while hub.counters["frames_accepted"] < 5:
            await asyncio.sleep(0.01)
        hub.start_recording("restart", time.monotonic())
        while hub.counters["reconnects"] < 2:
            await asyncio.sleep(0.02)
        await asyncio.sleep(0.2)
        doc = hub.stop_recording(time.monotonic())
        await src.stop()
        return doc
    try:
        doc = asyncio.run(go())
    finally:
        shutdown()
    assert validate_recording(doc)["ok"]
    assert "theta" in doc["samples"]["cols"] and "q0" not in doc["samples"]["cols"]
    assert any(e["type"] == "time_base_reset" for e in doc["provenance"]["events"])


def test_stalled_stream_is_flagged_stale_then_fresh():
    emu = Emulator(mode="corner", rate_hz=100, seed=6, faults="stall_after=40,stall_s=1.0")
    port, shutdown = run_emulator_in_thread(emu, speed=2.0)
    hub = TelemetryHub(stale_after_s=0.3)
    try:
        asyncio.run(collect(hub, port, 2.2))
    finally:
        shutdown()
    kinds = [e["type"] for e in hub.events]
    assert "stale" in kinds and "fresh" in kinds and kinds.index("stale") < kinds.index("fresh")


def test_emulator_rejects_bad_options_with_field_names():
    with pytest.raises(ValueError, match="faults.teleport"):
        parse_faults("teleport=1")
    with pytest.raises(ValueError, match="faults.drop"):
        parse_faults("drop=2")
    with pytest.raises(ValueError, match="mode"):
        Emulator(mode="free")
    with pytest.raises(ValueError, match="record"):
        Emulator(rate_hz=60)                                        # 60 Hz does not divide the 500 Hz integration rate
    with pytest.raises(ValueError, match="loopback"):
        asyncio.run(Emulator(rate_hz=50).serve("0.0.0.0", 0))


def test_emulator_file_session_and_hello(tmp_path):
    emu = Emulator(mode="corner", rate_hz=50, seed=1)
    info = emu.write_session(str(tmp_path / "s.ndjson"), 120)
    lines = (tmp_path / "s.ndjson").read_bytes().splitlines()
    assert info["frames"] == 120 and json.loads(lines[-1]) == {"type": "bye"}
    h = json.loads(lines[0])
    assert h["device"]["kind"] == "emulator" and h["synthetic"] is True and h["emulator"]["parameters"] == "nominal-design-v1"
    fr = json.loads(lines[1])
    assert abs(math.sqrt(sum(x * x for x in fr["q"])) - 1) < 1e-12
    g = fr["imu"]["accel"]                                               # gravity in body axes: |a| ≈ g at rest
    assert abs(math.sqrt(sum(x * x for x in g)) - 9.80665) < 0.2


# ---------------------------------------------------------------- device adapter (mapping to the contract)
MAP = {"device": {"id": "bench-01", "kind": "test", "firmware": "fw-test"}, "mode": "corner", "rate_hz": 200,
       "time": {"field": "ts_us", "scale": 1e-6, "wrap": 1000000}, "seq": {"field": "n"},
       "quaternion": {"field": "quat", "order": "xyzw"}, "vectors": {"w": {"field": "gyr", "scale": math.pi / 180}},
       "imu": {"gyro": {"field": "gyr", "scale": math.pi / 180}, "accel": {"field": "acc", "scale": 9.80665}},
       "wheels": {"wheel_rpm": {"field": "rpm", "index": [2, 0, 1], "sign": [1, -1, 1]}},
       "axes": [[0, 1, 0], [1, 0, 0], [0, 0, -1]],                      # device x→contract y, y→x, z→−z (a proper rotation)
       "world": [[1, 0, 0], [0, -1, 0], [0, 0, -1]],                     # device world NED-like (z down) → contract z up
       "status": {"field": "st", "map": {"0": "ok", "3": "fault"}}}


def test_mapped_adapter_converts_units_axes_order_and_clock():
    a = MappedJsonAdapter(MAP)
    h = a.hello()
    assert validate_hello(h)["ok"] and h["synthetic"] is True                               # a 'test' device is synthetic
    # device at the contract's identity attitude: R = D·R_d·Cᵀ = I  →  R_d = Dᵀ·C
    D, C = MAP["world"], MAP["axes"]
    Rd = [[sum(D[k][i] * C[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    from aeris_backend.telemetry.device import _mat_quat
    qd = _mat_quat(Rd)
    line = json.dumps({"ts_us": 999990, "n": 7, "quat": [qd[1], qd[2], qd[3], qd[0]], "gyr": [10.0, 0.0, 0.0], "acc": [0, 0, -1.0],
                       "rpm": [1.0, 2.0, 3.0], "st": 0}).encode()
    f = a.decode(line)[0]
    assert f["t"] == 0.0 and f["seq"] == 7 and f["status"] == "ok"
    assert all(abs(x - y) < 1e-12 for x, y in zip(f["q"], [1, 0, 0, 0]))
    assert all(abs(x - y) < 1e-12 for x, y in zip(f["w"], [0.0, 10 * math.pi / 180, 0.0]))   # device x rate → contract y
    assert all(abs(x - y) < 1e-9 for x, y in zip(f["imu"]["accel"], [0, 0, 9.80665]))
    assert f["wheel_rpm"] == [3.0, -1.0, 2.0]
    f2 = a.decode(json.dumps({"ts_us": 10, "n": 8, "quat": [0, 0, 0, 1], "gyr": [0, 0, 0], "acc": [0, 0, -1], "rpm": [0, 0, 0], "st": 3}).encode())[0]
    assert abs(f2["t"] - 20e-6) < 1e-12 and f2["status"] == "fault"                        # the µs counter wrapped at 1 000 000
    hub = TelemetryHub()
    hub.on_connect({"kind": "test"}, 0)
    assert hub.feed_message(h, 0) == "hello" and hub.feed_message(f, 0) == "frame" and hub.feed_message(f2, 0) == "frame"
    with pytest.raises(AdapterError, match="status code 9"):
        a.decode(json.dumps({"ts_us": 20, "n": 9, "quat": [0, 0, 0, 1], "gyr": [0, 0, 0], "acc": [0, 0, 1], "rpm": [0, 0, 0], "st": 9}).encode())
    with pytest.raises(AdapterError, match="missing field 'n'"):
        a.decode(b'{"ts_us": 30}')


def test_mapping_errors_are_named():
    mirrored = dict(MAP, axes=[[1, 0, 0], [0, 1, 0], [0, 0, -1]])
    assert any(e.startswith("axes: must be a proper rotation") for e in check_mapping(mirrored))
    tmpl = {"device": {"id": "<serial or name>", "kind": "physical", "firmware": "<firmware version string>"}, "mode": "corner",
            "time": {"field": "t", "scale": 1}, "seq": {"field": "n"}}
    errs = check_mapping(tmpl)
    assert any(e.startswith("device.id") for e in errs) and any(e.startswith("device.firmware") for e in errs)
    with pytest.raises(AdapterError):
        MappedJsonAdapter(mirrored)


def test_adapter_errors_count_as_rejected_lines():
    class Broken(MappedJsonAdapter):
        def decode(self, line):
            raise AdapterError("cannot decode")
    hub = TelemetryHub()
    src = FileReplaySource(hub, text='{"x": 1}\n', speed=0, adapter=Broken(MAP))
    asyncio.run(src.run())
    assert hub.rejected_by_reason == {"adapter_error": 1} and hub.last_hello is not None and hub.provenance()["synthetic"] is True
    assert hub.provenance()["active"] is False                                               # the replay ended: no active session


# ---------------------------------------------------------------- the backend API
def test_bridge_setting_parser():
    assert parse_bridge_setting(None) == ("ndjson", None) and parse_bridge_setting("none") == ("none", None)
    assert parse_bridge_setting("ndjson-tcp://127.0.0.1:47100") == ("ndjson", {"source": "tcp", "host": "127.0.0.1", "port": 47100})
    assert parse_bridge_setting("file:a.ndjson")[1]["path"] == "a.ndjson"
    with pytest.raises(ValueError):
        parse_bridge_setting("serial:/dev/ttyUSB0")


@pytest.fixture(scope="module")
def api(tmp_path_factory):
    d = tmp_path_factory.mktemp("tel")
    (d / "telemetry").mkdir()
    Emulator(mode="corner", rate_hz=50, seed=9).write_session(str(d / "telemetry" / "session.ndjson"), 150)
    app = create_app({"db": str(d / "api.sqlite3"), "workers": 1, "max_jobs": 1, "origins": ["http://localhost:8000"],
                      "telemetry_dir": str(d / "telemetry"), "telemetry_max_live": 2})
    emu = Emulator(mode="corner", rate_hz=100, seed=11, faults="drop=0.01,duplicate=0.01")
    port, shutdown = run_emulator_in_thread(emu, speed=2.0)
    with TestClient(app) as c:
        c.emulator_port = port
        yield c
    shutdown()


def until(fn, timeout=30, step=0.05):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v
        time.sleep(step)
    raise AssertionError("condition not reached within %ss" % timeout)


def test_api_connect_rules(api):
    st = api.get("/api/v1/telemetry/status").json()
    assert st["available"] and st["connected"] is False and st["read_only"] is True and st["live"] is False
    r = api.post("/api/v1/telemetry/connect", json={"source": "tcp", "host": "192.168.0.7", "port": 47100})
    assert r.status_code == 422 and r.json()["error"]["details"][0]["path"] == "host"
    r = api.post("/api/v1/telemetry/connect", json={"source": "tcp", "port": 0})
    assert r.status_code == 422 and r.json()["error"]["details"][0]["path"] == "port"
    r = api.post("/api/v1/telemetry/connect", json={"source": "file", "path": "../../api.sqlite3"})
    assert r.status_code == 422 and "telemetry directory" in r.json()["error"]["message"]
    r = api.post("/api/v1/telemetry/connect", json={"source": "serial"})
    assert r.status_code == 422 and r.json()["error"]["details"][0]["path"] == "source"
    r = api.post("/api/v1/telemetry/connect", json={"source": "recording", "recording_id": "AERIS-HW-999999"})
    assert r.status_code == 404
    cap = api.get("/api/v1/capabilities").json()
    assert cap["telemetry"]["available"] and cap["telemetry"]["read_only"] and cap["telemetry"]["loopback_only"] and cap["hardware"]["live"] is False
    files = api.get("/api/v1/telemetry/files").json()["files"]
    assert [f["name"] for f in files] == ["session.ndjson"] and files[0]["bytes"] > 0


def test_api_live_stream_record_export_replay_dataset_compare(api):
    r = api.post("/api/v1/telemetry/connect", json={"source": "tcp", "host": "127.0.0.1", "port": api.emulator_port})
    assert r.status_code == 200
    st = until(lambda: (lambda s: s if s["connected"] and s["counters"]["frames_accepted"] > 20 else None)(api.get("/api/v1/telemetry/status").json()))
    assert st["provenance"]["synthetic"] is True and "SYNTHETIC EMULATOR" in st["provenance"]["label"]
    assert st["live"] is False and st["provenance"]["declared_physical"] is False                 # never shown as the physical cube
    assert api.get("/api/v1/capabilities").json()["hardware"]["live"] is False
    # live WebSocket: status first, then batches of frames carrying the synthetic provenance
    with api.websocket_connect("/api/v1/telemetry/live") as ws:
        first = ws.receive_json()
        assert first["type"] == "status" and first["status"]["provenance"]["synthetic"] is True
        got = []
        while len(got) < 10:
            m = ws.receive_json()
            if m["type"] == "frames":
                assert m["provenance"]["synthetic"] is True
                got += m["frames"]
        ns = [f["n"] for f in got]
        assert ns == sorted(set(ns))
    # polling fallback continues after the last index the client saw
    p = until(lambda: (lambda d: d if d["frames"] else None)(api.get(f"/api/v1/telemetry/frames?after={ns[-1]}").json()))
    assert p["frames"][0]["n"] > ns[-1] and p["provenance"]["synthetic"] is True
    # record, store, export
    assert api.post("/api/v1/telemetry/recordings/start", json={"name": "api test"}).status_code == 201
    assert api.post("/api/v1/telemetry/recordings/start", json={"name": "twice"}).status_code == 409
    n0 = api.get("/api/v1/telemetry/status").json()["counters"]["frames_accepted"]
    until(lambda: api.get("/api/v1/telemetry/status").json()["counters"]["frames_accepted"] > n0 + 60)
    stored = api.post("/api/v1/telemetry/recordings/stop").json()
    assert stored["synthetic"] is True and stored["source"] == "telemetry-recorder" and stored["provenance"]["source_kind"] == "emulator"
    assert stored["provenance"]["declared_physical"] is False and "SYNTHETIC" in stored["provenance"]["label"]
    rid = stored["id"]
    lst = api.get("/api/v1/hardware/recordings").json()["recordings"]
    assert any(x["id"] == rid and x["synthetic"] is True and x["source_kind"] == "emulator" for x in lst)
    nd = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=ndjson")
    assert "SYNTHETIC" in nd.headers["content-disposition"] and json.loads(nd.text.splitlines()[0])["synthetic"] is True
    js = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=json").json()
    assert js["synthetic"] is True and js["provenance"]["source_kind"] == "emulator"
    # a relabelled upload of the same data is refused: provenance says synthetic
    forged = dict(js, synthetic=False)
    r = api.post("/api/v1/hardware/recordings", json=forged)
    assert r.status_code == 422 and any(d["path"] == "synthetic" for d in r.json()["error"]["details"])
    # replay the stored recording through the same path
    assert api.post("/api/v1/telemetry/connect", json={"source": "recording", "recording_id": rid, "speed": 0}).status_code == 200
    st = until(lambda: (lambda s: s if s["source"]["state"] == "finished" else None)(api.get("/api/v1/telemetry/status").json()))
    assert st["provenance"]["replay"] is True and st["provenance"]["synthetic"] is True and st["live"] is False
    # stream quality is reported for this source only: exactly the recording's frames, nothing carried over from the
    # emulator session (its duplicates, gaps or connects); the totals since start-up are reported separately
    c, tot = st["counters"], st["counters_total"]
    assert c["frames_accepted"] == stored["quality"]["n"] and c["duplicates"] == c["gaps"] == c["out_of_order"] == c["rejected"] == 0
    assert c["connects"] == 1 and c["reconnects"] == 0 and st["rejected_by_reason"] == {}
    assert tot["frames_accepted"] > c["frames_accepted"] and tot["connects"] >= 2 and "current source" in st["counters_scope"]
    # replay a file from the telemetry directory
    assert api.post("/api/v1/telemetry/connect", json={"source": "file", "path": "session.ndjson", "speed": 0}).status_code == 200
    until(lambda: api.get("/api/v1/telemetry/status").json()["source"]["state"] == "finished")
    api.post("/api/v1/telemetry/disconnect")
    # dataset: the synthetic member is named in the provenance
    ds = api.post("/api/v1/datasets", json={"title": "synthetic telemetry", "recording_ids": [rid]}).json()
    assert ds["provenance"]["source"] == "synthetic-telemetry" and ds["provenance"]["contains_synthetic"] is True
    assert ds["provenance"]["synthetic_members"] == [rid] and "SYNTHETIC" in ds["provenance"]["note"] and ds["members"][0]["synthetic"] is True
    # offline comparison with a simulated run: computed, but never admissible evidence
    job = api.post("/api/v1/simulations", json={"config": {"mode": "corner", "duration_s": 3, "record_hz": 100}}).json()["job"]
    run_id = until(lambda: (lambda j: j["result_ref"]["id"] if j["state"] == "complete" else None)(api.get(f"/api/v1/jobs/{job['id']}").json()), timeout=120)
    cmp_ = api.post("/api/v1/hardware/compare", json={"run_id": run_id, "recording_id": rid}).json()
    ev = cmp_["evidence"]
    assert cmp_["synthetic"] is True and ev["admissible_as_validation_evidence"] is False
    assert any("SYNTHETIC" in x for x in ev["reasons"]) and ev["model_status_change"].startswith("none")
    proto = api.post("/api/v1/validation/protocols", json={"name": "attitude", "thresholds": {"attitude.rmse": 1000.0}}).json()
    c2 = api.post("/api/v1/hardware/compare", json={"run_id": run_id, "recording_id": rid, "protocol_id": proto["id"]}).json()
    assert c2["result"]["acceptance"]["admissible_as_evidence"] is False and c2["evidence"]["admissible_as_validation_evidence"] is False
    run = api.get(f"/api/v1/runs/{run_id}").json()
    assert run["validation"]["status"] == "nominal"                                               # nothing was promoted


def test_api_live_socket_limit(api):
    with api.websocket_connect("/api/v1/telemetry/live") as a, api.websocket_connect("/api/v1/telemetry/live") as b:
        assert a.receive_json()["type"] == "status" and b.receive_json()["type"] == "status"
        with api.websocket_connect("/api/v1/telemetry/live") as c:
            m = c.receive_json()
            assert m["type"] == "error" and m["error"]["code"] == "too_many_clients"


def test_api_telemetry_can_be_switched_off(tmp_path):
    app = create_app({"db": str(tmp_path / "off.sqlite3"), "workers": 1, "max_jobs": 1, "bridge": "none"})
    with TestClient(app) as c:
        st = c.get("/api/v1/telemetry/status").json()
        assert st["available"] is False and "switched off" in st["reason"]
        r = c.post("/api/v1/telemetry/connect", json={"source": "tcp", "port": 47100})
        assert r.status_code == 409 and r.json()["error"]["code"] == "telemetry_off"
        assert c.get("/api/v1/capabilities").json()["telemetry"]["available"] is False


def test_hub_bridge_reports_a_failed_connection_without_claiming_it(tmp_path):
    async def go():
        b = HubBridge(telemetry_dir=str(tmp_path))
        await b.connect({"source": "tcp", "host": "127.0.0.1", "port": 9, "reconnect": False})
        for _ in range(100):
            if b.source.state == "failed":
                break
            await asyncio.sleep(0.02)
        st = b.status()
        await b.close()
        return st
    st = asyncio.run(go())
    assert st["connected"] is False and st["source"]["state"] == "failed" and "failed" in st["source"]["last_error"] and "failed" in st["reason"]


def serve_lines_in_thread(lines, delay=0.01):
    """A tiny device stand-in: serves the given raw lines once per connection (for the mapping adapter)."""
    import socket as _s
    srv = _s.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port = srv.getsockname()[1]
    stop = threading.Event()

    def run():
        srv.settimeout(0.2)
        while not stop.is_set():
            try:
                c, _ = srv.accept()
            except OSError:
                continue
            with c:
                for ln in lines:
                    if stop.is_set():
                        break
                    try:
                        c.sendall(ln + b"\n")
                    except OSError:
                        break
                    time.sleep(delay)
                while not stop.is_set():
                    time.sleep(0.05)
        srv.close()
    th = threading.Thread(target=run, daemon=True)
    th.start()
    return port, lambda: (stop.set(), th.join(2))


def test_api_device_mapping_from_the_adapters_file(tmp_path):
    mp = tmp_path / "adapters.json"
    mp.write_text(json.dumps({"bench": MAP}))
    lines = [json.dumps({"ts_us": 1000 * k, "n": k, "quat": [0, 0, 0, 1], "gyr": [0, 0, 0], "acc": [0, 0, -1], "rpm": [k, 0, 0], "st": 0}).encode() for k in range(40)]
    port, stop = serve_lines_in_thread(lines)
    app = create_app({"db": str(tmp_path / "m.sqlite3"), "workers": 1, "max_jobs": 1, "telemetry_dir": str(tmp_path), "telemetry_adapters": str(mp)})
    try:
        with TestClient(app) as c:
            r = c.post("/api/v1/telemetry/connect", json={"source": "tcp", "port": port, "adapter": "nope"})
            assert r.status_code == 422 and r.json()["error"]["details"][0]["path"] == "adapter"
            assert c.post("/api/v1/telemetry/connect", json={"source": "tcp", "port": port, "adapter": "bench"}).status_code == 200
            st = until(lambda: (lambda s: s if s["counters"]["frames_accepted"] >= 30 else None)(c.get("/api/v1/telemetry/status").json()))
            assert st["provenance"]["device_id"] == "bench-01" and st["provenance"]["synthetic"] is True and st["transport"]["adapter"] == "mapped-json"
            assert st["latest"]["wheel_rpm"][1] == -st["latest"]["seq"]              # index/sign mapping applied (device wheel 0 → contract y, sign −1)
            c.post("/api/v1/telemetry/disconnect")
    finally:
        stop()
    bad = tmp_path / "bad.json"
    bad.write_text(json.dumps({"x": dict(MAP, axes=[[1, 0, 0], [0, 1, 0], [0, 0, -1]])}))
    with pytest.raises(ValueError, match="proper rotation"):
        create_app({"db": str(tmp_path / "b.sqlite3"), "telemetry_adapters": str(bad)})

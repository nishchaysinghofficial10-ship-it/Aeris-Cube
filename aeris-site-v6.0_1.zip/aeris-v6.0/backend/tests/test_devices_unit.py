"""v6.0 device layer, without a device: calibration maths, authentication configuration and tokens, link framing."""
from __future__ import annotations

import json
import math
import time
import zlib

import pytest

from aeris_backend.devices import calibration as CAL
from aeris_backend.devices import reference, schemas
from aeris_backend.devices.auth import AuthConfig, AuthError, Authenticator
from aeris_backend.devices.linkhost import LinkHost, frame

G = 9.80665


def _mv(m, v):
    return [sum(m[3 * r + c] * v[c] for c in range(3)) for r in range(3)]


def _transpose(m):
    return [m[3 * c + r] for r in range(3) for c in range(3)]


def axes_result(face, to_body, *, noise=(0.0, 0.0, 0.0), g=G, still=True):
    """What calibrate_axes reports when the cube rests with `face` up and the IMU is mounted with `to_body`."""
    e = CAL.face_vector(face)
    up_s = _mv(_transpose(to_body), e)                       # sensor = to_body^T · body
    return {"measurement": "calibrate_axes", "face": face, "accel_mean_mps2": [g * x + n for x, n in zip(up_s, noise)],
            "accel_std_mps2": [0.04, 0.04, 0.04], "gyro_std_radps": [0.003, 0.003, 0.003], "still": still}


IMU_OK = {"measurement": "calibrate_imu", "gyro_mean_radps": [0.0087, -0.0052, 0.0035], "gyro_std_radps": [0.003, 0.003, 0.003],
          "accel_mean_mps2": [0.0, 0.0, 9.81], "accel_std_mps2": [0.04, 0.04, 0.04], "still": True, "samples": 2500, "seconds": 5.0}


# ------------------------------------------------------------------------------------------------ calibration
def test_rotations_are_the_24_proper_axis_aligned_rotations():
    assert len(CAL.ROTATIONS) == 24
    assert len({tuple(m) for m in CAL.ROTATIONS}) == 24
    assert all(schemas.signed_permutation(m) for m in CAL.ROTATIONS)


@pytest.mark.parametrize("k", range(24))
def test_solve_recovers_every_mounting_from_two_faces(k):
    tb = CAL.ROTATIONS[k]
    fit = CAL.solve_to_body([axes_result("+z", tb, noise=(0.05, -0.03, 0.02)), axes_result("+x", tb, noise=(-0.02, 0.04, 0.01))])
    assert fit["to_body"] == tb
    assert fit["max_residual_deg"] < 1.0
    assert fit["next_best_deg"] >= 89.0                     # every other mounting misses a face by a right angle


def test_solve_refuses_one_axis_only_and_bad_faces():
    tb = [1, 0, 0, 0, 1, 0, 0, 0, 1]
    with pytest.raises(CAL.CalibrationError, match="two different body axes"):
        CAL.solve_to_body([axes_result("+z", tb), axes_result("-z", tb)])
    with pytest.raises(CAL.CalibrationError, match="at least two"):
        CAL.solve_to_body([axes_result("+z", tb)])
    bad = axes_result("+z", tb)
    bad["face"] = "top"
    with pytest.raises(CAL.CalibrationError, match="face"):
        CAL.solve_to_body([bad, axes_result("+x", tb)])


def test_solve_refuses_motion_implausible_gravity_and_poor_fit():
    tb = [1, 0, 0, 0, 1, 0, 0, 0, 1]
    with pytest.raises(CAL.CalibrationError, match="moved"):
        CAL.solve_to_body([axes_result("+z", tb, still=False), axes_result("+x", tb)])
    with pytest.raises(CAL.CalibrationError, match="gravity magnitude"):
        CAL.solve_to_body([axes_result("+z", tb, g=7.0), axes_result("+x", tb)])
    # a sensor tilted 30° about y fits no axis-aligned mounting within 10°
    c, s = math.cos(math.radians(30)), math.sin(math.radians(30))
    r = [{"measurement": "calibrate_axes", "face": "+z", "accel_mean_mps2": [G * s, 0, G * c], "still": True},
         {"measurement": "calibrate_axes", "face": "+x", "accel_mean_mps2": [G * c, 0, -G * s], "still": True}]
    with pytest.raises(CAL.CalibrationError, match="no axis-aligned mounting") as ei:
        CAL.solve_to_body(r)
    assert ei.value.details and all("residual_deg" in d for d in ei.value.details)


def test_gyro_bias_checks():
    b = CAL.gyro_bias(IMU_OK)
    assert b["gyro_bias_radps"] == IMU_OK["gyro_mean_radps"] and abs(b["accel_norm_mps2"] - 9.81) < 1e-9
    with pytest.raises(CAL.CalibrationError, match="required"):
        CAL.gyro_bias(None)
    with pytest.raises(CAL.CalibrationError, match="moved"):
        CAL.gyro_bias(dict(IMU_OK, still=False))
    with pytest.raises(CAL.CalibrationError, match="spread"):
        CAL.gyro_bias(dict(IMU_OK, gyro_std_radps=[0.05, 0.0, 0.0]))
    with pytest.raises(CAL.CalibrationError, match="0.2 rad/s"):
        CAL.gyro_bias(dict(IMU_OK, gyro_mean_radps=[0.3, 0, 0]))
    with pytest.raises(CAL.CalibrationError, match="not a calibrate_imu"):
        CAL.gyro_bias(dict(IMU_OK, measurement="calibrate_axes"))


def _enc(*wheels):
    return {"wheels": [{"index": i, "node": i + 1, "encoder_updates": 500, **w} for i, w in enumerate(wheels)]}


def test_wheel_checks_classify_directions():
    prof = reference.reference_profile()
    w = CAL.wheel_checks(_enc({"travel_rev": 2.0, "vel_rads_max": 20.0, "vel_rads_min": -1.0},
                              {"travel_rev": 2.0, "vel_rads_max": 0.5, "vel_rads_min": -20.0},
                              {"travel_rev": 0.1, "vel_rads_max": 3.0, "vel_rads_min": 0.0}), prof)
    assert [x["direction_ok"] for x in w] == [True, False, False]
    assert w[0]["checked"] and w[1]["checked"] and not w[2]["checked"]
    assert "NEGATIVE" in w[1]["note"] and "not turned" in w[2]["note"]
    both = CAL.wheel_checks(_enc({"travel_rev": 2.0, "vel_rads_max": 10.0, "vel_rads_min": -10.0}, {"encoder_updates": 0}, {"encoder_updates": 0}), prof)
    assert both[0]["direction_ok"] is False and "both ways" in both[0]["note"]
    assert both[1]["checked"] is False and "no encoder estimates" in both[1]["note"]
    bad = _enc({"travel_rev": 2.0, "vel_rads_max": 20.0, "vel_rads_min": 0.0}, {"travel_rev": 2.0, "vel_rads_max": 20.0, "vel_rads_min": 0.0},
               {"travel_rev": 2.0, "vel_rads_max": 20.0, "vel_rads_min": 0.0})
    bad["wheels"][0]["node"] = 9
    with pytest.raises(CAL.CalibrationError, match="does not match the profile"):
        CAL.wheel_checks(bad, prof)


def test_build_calibration_document():
    prof = reference.reference_profile()
    measured = [0, 1, 0, -1, 0, 0, 0, 0, 1]                  # rotated 90° about z relative to the declared identity
    good = {"travel_rev": 2.0, "vel_rads_max": 20.0, "vel_rads_min": -0.5}
    doc = CAL.build_calibration("dev-1", {"id": prof["id"], "revision": 1}, prof,
                                {"imu": IMU_OK, "axes": [axes_result("+z", measured), axes_result("-y", measured)], "encoders": _enc(good, good, good)},
                                source="synthetic-device", evidence=[{"command": "c-1"}])
    assert schemas.validate_calibration(doc)["ok"]
    assert doc["imu"]["to_body"] == measured and doc["imu"]["matches_declared"] is False
    assert doc["wheel_directions_confirmed"] is True
    assert any("differs from the profile" in n for n in doc["notes"])
    no_enc = CAL.build_calibration("dev-1", {"id": prof["id"], "revision": 1}, prof,
                                   {"imu": IMU_OK, "axes": [axes_result("+z", measured), axes_result("+x", measured)]}, source="device-measurement")
    assert no_enc["wheel_directions_confirmed"] is False and "wheels" not in no_enc
    assert any("not checked" in n for n in no_enc["notes"])


# ------------------------------------------------------------------------------------------------ authentication
def test_auth_config_refuses_unsafe_settings():
    assert AuthConfig({}).ok and AuthConfig({}).mode == "local"
    assert not AuthConfig({"AERIS_BIND_HOST": "0.0.0.0"}).ok
    assert not AuthConfig({"AERIS_PUBLIC_ORIGIN": "https://cube.example.org"}).ok
    assert AuthConfig({"AERIS_PUBLIC_ORIGIN": "http://127.0.0.1:8750"}).ok
    base = {"AERIS_AUTH": "jwt", "AERIS_JWT_ISSUER": "https://id.example.org/", "AERIS_JWT_AUDIENCE": "aeris", "AERIS_JWT_JWKS_URL": "https://id.example.org/jwks",
            "AERIS_PUBLIC_ORIGIN": "https://cube.example.org", "AERIS_BIND_HOST": "0.0.0.0"}
    assert AuthConfig(base).ok
    assert "HS256" in AuthConfig(dict(base, AERIS_JWT_ALGORITHMS="RS256,HS256")).problem
    assert "none" in AuthConfig(dict(base, AERIS_JWT_ALGORITHMS="none")).problem
    assert not AuthConfig(dict(base, AERIS_JWT_JWKS_URL="http://id.example.org/jwks")).ok
    assert not AuthConfig(dict(base, AERIS_PUBLIC_ORIGIN="http://cube.example.org")).ok
    assert not AuthConfig({k: v for k, v in base.items() if k != "AERIS_JWT_AUDIENCE"}).ok
    assert "fixture" in AuthConfig(dict(base, AERIS_JWT_ISSUER="aeris-dev-issuer")).problem
    assert not AuthConfig({"AERIS_AUTH": "magic"}).ok
    with pytest.raises(AuthError) as ei:
        Authenticator(AuthConfig({"AERIS_BIND_HOST": "0.0.0.0"})).owner(None)
    assert ei.value.status == 503


@pytest.fixture()
def dev_issuer(tmp_path):
    from aeris_backend.tools import devauth
    d = str(tmp_path / "dev-auth")
    devauth.init(d)
    return d, devauth


def test_dev_fixture_tokens(dev_issuer, tmp_path):
    import jwt
    d, devauth = dev_issuer
    env = devauth.env(d)
    a = Authenticator(AuthConfig(env))
    assert a.cfg.ok and a.cfg.summary()["development_fixture"] is True
    assert a.owner("Bearer " + devauth.token(d, "alice")) == "aeris-dev-issuer|alice"
    for bad in (None, "Basic abc", "Bearer ", "Bearer not.a.token"):
        with pytest.raises(AuthError) as ei:
            a.owner(bad)
        assert ei.value.status == 401
    with pytest.raises(AuthError):                            # expired (beyond the 30 s leeway)
        a.owner("Bearer " + devauth.token(d, "alice", ttl=-120))
    key = open(f"{d}/dev-issuer-key.pem", "rb").read()
    kid = json.load(open(f"{d}/jwks.json"))["keys"][0]["kid"]
    now = int(time.time())
    wrong_aud = jwt.encode({"iss": devauth.ISSUER, "aud": "other", "sub": "x", "iat": now, "exp": now + 60}, key, algorithm="ES256", headers={"kid": kid})
    with pytest.raises(AuthError):
        a.owner("Bearer " + wrong_aud)
    no_sub = jwt.encode({"iss": devauth.ISSUER, "aud": devauth.AUDIENCE, "iat": now, "exp": now + 60}, key, algorithm="ES256", headers={"kid": kid})
    with pytest.raises(AuthError):
        a.owner("Bearer " + no_sub)
    other = str(tmp_path / "other")
    devauth.init(other)                                       # another key pair: its tokens do not verify against this JWKS
    with pytest.raises(AuthError):
        a.owner("Bearer " + devauth.token(other, "alice"))
    hs = jwt.encode({"iss": devauth.ISSUER, "aud": devauth.AUDIENCE, "sub": "x", "iat": now, "exp": now + 60}, "a-shared-secret-of-thirty-two-bytes!",
                    algorithm="HS256", headers={"kid": kid})
    with pytest.raises(AuthError):
        a.owner("Bearer " + hs)
    # the fixture's issuer never secures a public origin
    assert not AuthConfig(dict(env, AERIS_PUBLIC_ORIGIN="https://cube.example.org")).ok


# ------------------------------------------------------------------------------------------------ link framing
def test_linkhost_framing():
    sent = []
    h = LinkHost("companion", sent.append)
    got = []
    h.on_dev_hello = got.append
    h.start()
    assert json.loads(sent[0][:-10])["kind"] == "host_hello"
    line = frame({"kind": "dev_hello", "device_id": "d1"})
    h.receive(b"ESP-ROM:esp32s3 boot text\r\n" + line[:7])   # boot text is ignored; a line may arrive in pieces
    h.receive(line[7:])
    assert got and got[0]["device_id"] == "d1" and h.stats["unframed"] == 1
    js = b'{"kind":"dev_hello","device_id":"d2"}'
    h.receive(js + b"\t%08x\n" % (zlib.crc32(js) ^ 1))
    assert h.stats["bad_crc"] == 1 and len(got) == 1
    h.receive(b"x" * 5000 + b"\n" + line)
    assert h.stats["too_long"] == 1 and len(got) == 2
    with pytest.raises(RuntimeError):
        h.send_command("c-1", "identify", None, 1000)          # no session yet
    h.open_session(3)
    assert json.loads(sent[-1][:-10]) == {"kind": "session", "link_session": h.link_session, "lease_epoch": 3}
    info = h.send_command("c-1", "apply_config", None, 2000, "ab" * 32, raw_params_text='{"config":{"b":1,"a":2}}')
    raw = sent[-1][:-10].decode()
    assert raw.endswith(',"params":{"config":{"b":1,"a":2}}}') and info["seq"] == 1     # the exact bytes are sent
    with pytest.raises(ValueError):
        h.send_command("c-2", "apply_config", None, 2000, "ab" * 32, raw_params_text='{"config":"' + "x" * 5000 + '"}')
    assert h.send_command("c-3", "identify", None, 1000)["seq"] == 2 and "c-2" not in h.pending   # a refused command consumes no seq


def test_linkhost_reopens_a_session_the_device_dropped():
    """The device drops a session after 1.5 s without heartbeats (it has stopped anything running): the host opens a
    new one at once with the same lease epoch; an expiry naming another (stale) session changes nothing."""
    sent, events = [], []
    h = LinkHost("companion", sent.append)
    h.on_event = lambda k, m: events.append(k)
    h.open_session(4)
    old = h.link_session
    h.receive(frame({"kind": "session_ok", "link_session": old, "lease_epoch": 4, "role": "supervisor"}))
    assert h.session_ok
    h.receive(frame({"kind": "session_expired", "link_session": "ls-someotherone", "reason": "no heartbeat within 1.5 s"}))
    assert h.link_session == old and h.stats.get("sessions_reopened", 0) == 0
    h.receive(frame({"kind": "session_expired", "link_session": old, "reason": "no heartbeat within 1.5 s"}))
    msg = json.loads(sent[-1][:-10])
    assert msg["kind"] == "session" and msg["link_session"] == h.link_session != old and msg["lease_epoch"] == 4
    assert h.stats["sessions_reopened"] == 1 and not h.session_ok and events.count("session_expired") == 2


# ------------------------------------------------------------------------------------------------ capability negotiation
def test_negotiation_and_profile_fit():
    from aeris_backend.devices import compat
    hello = {"kind": "dev_hello", "link": "aeris-device-link/1", "versions": [1], "device_id": "d", "fw": {"version": "0.1.0", "actuation_build": False},
             "board": {"id": "esp32-s3-devkitc-1", "kind": "physical", "synthetic": False},
             "caps": {"actions": ["identify", "diagnostics", "self_test", "apply_config", "start_experiment", "stop", "set_network"], "controllers": ["edge-lqr"],
                      "estimators": ["cf3d"], "imu": "lsm6dsox", "motor": "odrive-cansimple", "config_schema": "aeris-device-config/1", "max_control_hz": 1000},
             "limits": {"hard_max_current_A": 10, "hard_max_torque_Nm": 1, "hard_max_speed_rpm": 8000}}
    c = compat.negotiate(hello)
    assert c["supported"] and c["mode"] == "full" and "start_experiment" in c["actions"] and "never drives motors" in c["note"]
    prof = reference.reference_profile()
    assert compat.profile_fits(hello, prof, reference.recipe("edge-hold-10s")) == []
    why = compat.profile_fits(hello, prof, reference.recipe("corner-hold-10s"))
    assert any("corner-mimo-lqr" in w for w in why)                  # never substituted by another controller
    hot = reference.reference_profile()
    hot["wheels"][1]["motor"]["Imax_A"] = 12.0
    hot["imu"]["driver"] = "bmi270"
    why = compat.profile_fits(hello, hot)
    assert any("hard limit 10 A" in w for w in why) and any("IMU driver" in w for w in why)
    old = dict(hello, link="aeris-device-link/0", versions=[0])
    c = compat.negotiate(old)
    assert not c["supported"] and c["mode"] == "read-only" and set(c["actions"]) <= {"identify", "diagnostics", "stop"}
    assert compat.profile_fits(old, prof) and compat.negotiate(None)["mode"] == "unknown"


def test_twin_comparison_aligns_a_device_recording_on_the_start_of_the_experiment():
    """A device recording runs on the device's telemetry clock; the twin simulation starts at the experiment. The
    comparison moves the recording's t = 0 to its first frame with status ok (balancing), else to its first frame."""
    from aeris_backend.hardware.compare import align_on_experiment_start
    si = {"t": [10.0, 10.02, 10.04, 10.06, 10.08, 10.1], "status": [1, 1, 0, 0, 1, 0], "theta": [0.5, 0.4, 0.3, 0.2, 0.1, 0.0]}
    out, info = align_on_experiment_start(si)
    assert out["t"] == pytest.approx([0.0, 0.02]) and out["theta"] == [0.3, 0.2] and out["status"] == [0, 0]       # the first balancing run only
    assert info["recording_t0_s"] == 10.04 and info["recording_window_s"] == [10.04, 10.06] and "status ok" in info["recording_t0_rule"]
    assert si["t"][0] == 10.0 and len(si["theta"]) == 6                # the recording itself is not changed
    out, info = align_on_experiment_start({"t": [3.0, 3.5], "status": [1, 1]})
    assert out["t"] == [0.0, 0.5] and "never balanced" in info["recording_t0_rule"]
    out, info = align_on_experiment_start({"t": [3.0, 3.5]})
    assert out["t"] == [0.0, 0.5] and "no status column" in info["recording_t0_rule"]


# ---------------------------------------------------------------- profile validation (acceptance PRF-2)
def _profile(**edits):
    import copy
    p = copy.deepcopy(reference.reference_profile())
    p["id"], p["name"], p["qualification"] = "my-cube", "My cube", {"status": "experimental", "evidence": []}
    for path, value in edits.items():
        cur = p
        keys = path.split(".")
        for k in keys[:-1]:
            cur = cur[int(k)] if isinstance(cur, list) else cur[k]
        if isinstance(cur, list):
            cur[int(keys[-1])] = value
        else:
            cur[keys[-1]] = value
    return p


def _errors(p):
    r = schemas.validate_profile(p)
    return {e["path"]: e["message"] for e in r["errors"]}


def test_profile_validation_rules():
    assert schemas.validate_profile(_profile())["ok"]
    diag = lambda a, b, c: [[a, 0.0, 0.0], [0.0, b, 0.0], [0.0, 0.0, c]]                       # noqa: E731
    assert schemas.validate_profile(_profile(**{"body.inertia_kgm2": diag(4e-3, 4e-3, 4e-3)}))["ok"]
    cases = [
        ({"body.mass_kg": float("nan")}, "body.mass_kg", "finite"),
        ({"body.inertia_kgm2": [[4e-3, 1e-3, 0.0], [0.0, 4e-3, 0.0], [0.0, 0.0, 4e-3]]}, "body.inertia_kgm2", "not symmetric"),
        ({"body.inertia_kgm2": diag(4e-3, 4e-3, -1e-3)}, "body.inertia_kgm2", "not positive definite"),
        ({"body.inertia_kgm2": diag(1e-3, 1e-3, 5e-3)}, "body.inertia_kgm2", "triangle inequality"),
        ({"body.components": [{"id": "pack", "mass_kg": 0.3, "com_m": [0.05, 0.05, 0.05], "inertia_kgm2": diag(1e-5, 1e-5, 5e-5)}]},
         "body.components.0.inertia_kgm2", "triangle inequality"),
        ({"wheels.0.axis": [1.0, 0.1, 0.0]}, "wheels.0.axis", "unit vector"),
        ({"wheels.1.axis": [1.0, 0.0, 0.0]}, "wheels", "coplanar"),
        ({"wheels.1.driver.node": 1}, "wheels", "distinct"),
        ({"wheels.2.driver.sign": 2}, "wheels.2.driver.sign", "+1 or -1"),
        ({"imu.to_body": [1, 0, 0, 0, 1, 0, 0, 0, -1]}, "imu.to_body", "determinant +1"),
        ({"electrical.vbus_min_V": 13.0}, "electrical.vbus_min_V", "below vbus_max_V"),
        ({"electrical.current_abort_A": 5.0}, "electrical.current_abort_A", "motor current limit"),
        ({"qualification": {"status": "qualified", "evidence": []}}, "qualification.status", "not granted by the software"),
        ({"value_sources": {"body": "validated"}}, "value_sources.body", "one of"),
        ({"g_mps2": 3.7}, "g_mps2", "9.7"),
    ]
    for edits, path, words in cases:
        errs = _errors(_profile(**edits))
        assert path in errs and words in errs[path], (edits, errs)
    # a point-mass component (zero inertia) is allowed; the supported topology is exactly three wheels
    assert schemas.validate_profile(_profile(**{"body.components": [{"id": "pack", "mass_kg": 0.3, "com_m": [0.05, 0.05, 0.05],
                                                                     "inertia_kgm2": diag(0.0, 0.0, 0.0)}]}))["ok"]
    two = _profile()
    two["wheels"] = two["wheels"][:2]
    assert "exactly three wheels" in _errors(two)["wheels"]


# ---------------------------------------------------------------- one parameter source (acceptance PRF-5)
def test_twin_runs_are_labelled_through_the_parameter_set_coverage_rule():
    from aeris_backend.config.validate import validate_config
    from aeris_backend.devices import configgen
    from aeris_backend.experiments.provenance import coverage
    ref = {"id": "my-cube", "revision": 3, "hash": "f" * 64}
    rec = reference.recipe("edge-hold-10s")
    # the reference profile declares every group nominal-model: no values, NOMINAL, named after the profile revision
    prof = _profile()
    cfg = validate_config(configgen.engine_config(prof, rec)).config
    ps = configgen.profile_parameter_set(prof, ref, cfg)
    assert ps["id"] == "profile:my-cube:r3" and ps["status"] == "nominal" and ps["values"] is None and ps["source"]["measured_groups"] == []
    # every group declared measured: those inputs are MEASURED with exactly the engine's values; the rest stays NOMINAL
    prof = _profile(**{"value_sources": {g: "measured" for g in ("body", "wheels", "motor", "imu.noise", "imu.placement", "electrical")}})
    cfg = validate_config(configgen.engine_config(prof, rec)).config
    ps = configgen.profile_parameter_set(prof, ref, cfg)
    cov = coverage(cfg, ps)
    assert cov["overridden"] == [] and cov["unused_in_set"] == []
    for path in ("params.m", "params.a", "params.kJ", "wheels.x.Jw", "wheels.y.axis", "wheels.z.KV", "wheels.x.Imax", "wheels.x.cc",
                 "sensor.gyro_noise_dps", "sensor.accel_noise_mps2", "sensor.imu_position_m", "params.rImu"):
        assert path in cov["measured"], path
    for path in ("params.fs", "sensor.rate_hz", "sensor.latency_ms", "actuator.motor_lag_ms", "comOffset_m"):
        assert path in cov["nominal"], path
    assert cov["status"] == "partially-measured" and ps["values"]["params.m"]["evidence"].startswith("aeris-device-profile/1 my-cube revision 3")
    # 'datasheet' and 'estimated' are not measurements
    prof = _profile(**{"value_sources": {"body": "measured", "motor": "datasheet", "wheels": "estimated"}})
    cfg = validate_config(configgen.engine_config(prof, rec)).config
    cov = coverage(cfg, configgen.profile_parameter_set(prof, ref, cfg))
    assert "params.m" in cov["measured"] and "wheels.x.KV" in cov["nominal"] and "wheels.x.Jw" in cov["nominal"]

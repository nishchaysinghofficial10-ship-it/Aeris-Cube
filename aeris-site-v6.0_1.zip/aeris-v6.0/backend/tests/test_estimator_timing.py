"""Fix C (v5): the timestamped estimator lifecycle (docs/ESTIMATION_TIMING.md).

The v4 review found that at 500 Hz control and 100 Hz IMU the controller-facing attitude froze
between delivered samples while the estimate was labelled current (est.t = control time) with
age 0. These tests pin the v5 behaviour: prediction to the control time from the newest gyro
sample, truthful measurement/receipt time and age, stale/validity flags, duplicate and
out-of-order rejection, a covariance that stays finite, symmetric and positive semidefinite, and
unchanged browser-parity legacy estimators and perfect-state baseline.
"""
from __future__ import annotations

import math
from unittest.mock import patch

import numpy as np
import pytest

from aeris_backend.config.normalize import normalize
from aeris_backend.config.validate import validate_config
from aeris_backend.constants import DEG, QEQ
from aeris_backend.estimation import EPS_T, ComplementaryAttitude, Mekf, default_stale_after_s
from aeris_backend.physics.quaternion import angle_between, cross, exp_vec, qmul, up_in_body
from aeris_backend.sensors import Imu3D, ImuSample
from aeris_backend.simulation import simulate
from aeris_backend.simulation.engine import Engine

NOISE_FREE = {"gyro_noise_dps": 0, "gyro_bias_dps": 0, "gyro_bias_walk_dps": 0, "accel_noise_mps2": 0,
              "gyro_quant_dps": 0, "accel_quant_deg": 0}


def spy_run(raw, precise=False, filters=None):
    """Run the engine and capture, at every control tick, what the controller received, what the IMU
    delivered and (optionally) the filter's update state."""
    v = validate_config(raw)
    assert v.ok, v.errors
    eng = Engine(v.config, v.mp, precise=precise)
    rows = []
    delivered = {"n": 0, "last": None}
    orig_deliver = Imu3D.deliver

    def deliver(self, t):
        out = orig_deliver(self, t)
        delivered["n"] = len(out)
        if out:
            delivered["last"] = out[-1].t
        return out
    request = eng.controller.request

    def spy(t, est, ww, failed):
        row = {"t": t, "delivered": delivered["n"], "last_delivered_t": delivered["last"], "est": est.as_dict()}
        if filters:
            f = filters[0]
            row["filter_q"], row["filter_t"] = f.q, f.t
        rows.append(row)
        return request(t, est, ww, failed)
    eng.controller.request = spy
    with patch.object(Imu3D, "deliver", deliver):
        res = eng.run()
    return eng, res, rows


def capture_filters(cls):
    """Patch cls.__init__ to collect the instances the engine creates."""
    got = []
    orig = cls.__init__

    def init(self, *a, **k):
        orig(self, *a, **k)
        got.append(self)
    return got, patch.object(cls, "__init__", init)


# ------------------------------------------------------------------ the review probe
REVIEW_PROBE = {"mode": "corner", "duration_s": .5, "controller": {"type": "none"}, "estimator": {"type": "mekf"},
                "initial": {"tilt_deg": 0, "rate_dps": 10},
                "sensor": {"rate_hz": 100, "dropout": .5, "gyro_noise_dps": 0, "gyro_bias_dps": 0, "gyro_bias_walk_dps": 0,
                           "accel_noise_mps2": 0, "accel_dynamic": False}, "seed": 17}


def test_review_probe_no_frozen_estimate_and_truthful_age():
    """The review's configuration (v4: 216 frozen intervals, age 0 everywhere)."""
    filters, p = capture_filters(Mekf)
    with p:
        eng, res, rows = spy_run(REVIEW_PROBE, filters=filters)
    assert len(rows) >= 250
    frozen = [(a, b) for a, b in zip(rows, rows[1:])
              if math.sqrt(sum(x * x for x in a["est"]["w"])) > .1 and not b["delivered"] and a["est"]["q"] == b["est"]["q"]]
    assert frozen == []
    seen_gap = False
    for r in rows:
        e = r["est"]
        assert e["t"] == r["t"]                              # the estimate refers to the control time
        if r["last_delivered_t"] is None:
            assert e["valid"] is False and e["age"] is None and e["t_meas"] is None
            continue
        assert e["t_meas"] == r["filter_t"]                   # newest processed sample
        assert e["age"] == pytest.approx(r["t"] - e["t_meas"], abs=1e-15)
        assert e["age"] >= -1e-15 and e["t_receipt"] <= r["t"] + 1e-15
        if not r["delivered"]:
            seen_gap = seen_gap or e["age"] > 0.0101
        assert e["source"] == "prediction"
    assert seen_gap                                           # dropouts make the age exceed one IMU period
    st = res["estimator_stats"]
    assert st["samples_dropped"] > 0 and st["timing"] == "prediction"
    assert st["rejected_duplicate"] == 0 and st["rejected_out_of_order"] == 0


def test_prediction_beats_holding_the_last_update():
    """Noise-free rotating corner run: the controller-facing prediction is far closer to the truth than
    the update state the v4 controller received (held between samples)."""
    # the sensor model without dynamic acceleration needs a filter that does not compensate for it (validation warns
    # about the mismatch the review probe has); then the update state itself is accurate and the comparison is clean
    raw = dict(REVIEW_PROBE, record_hz=500, estimator={"type": "mekf", "mekf": {"compensate_dynamic": False}})
    filters, p = capture_filters(Mekf)
    with p:
        eng, res, rows = spy_run(raw, precise=True, filters=filters)
    S = res["samples"]["cols"]
    truth = {round(t, 9): tuple(S["q%d" % j][i] for j in range(4)) for i, t in enumerate(S["t"])}
    err_pred, err_held = [], []
    for r in rows:
        # before the fall (t ≤ 0.3 s, |ω| ≤ 45 °/s); ticks right after a delivery have prediction = update state
        if r["t"] > 0.3 or r["last_delivered_t"] is None or r["t"] - r["filter_t"] < 1e-9:
            continue
        qt = truth[round(r["t"], 9)]
        err_pred.append(angle_between(qt, tuple(r["est"]["q"])))
        err_held.append(angle_between(qt, r["filter_q"]))
    assert len(err_pred) > 100
    assert max(err_held) > 1.0 * DEG                          # what v4 gave the controller (|ω|·age, up to 1.4°)
    assert max(err_pred) < 0.25 * max(err_held)
    assert sum(err_pred) < 0.35 * sum(err_held)
    # the recorded estimate columns are the prediction as well (same values at the control ticks)
    by_t = {round(r["t"], 9): r["est"]["q"] for r in rows}
    for i, t in enumerate(S["t"]):
        if round(t, 9) in by_t and t < 0.49:
            assert np.allclose([S["qh%d" % j][i] for j in range(4)], by_t[round(t, 9)], atol=1e-12)


# ------------------------------------------------------------------ exact constant rotation
def _cfg(kind, **sensor):
    c, iss = normalize({"mode": "corner", "estimator": {"type": kind}, "sensor": dict(NOISE_FREE, **sensor)})
    assert not iss.errors
    return c


def _truth(q0, w, t):
    return qmul(q0, exp_vec((w[0] * t, w[1] * t, w[2] * t)))


def _sample(est, q0, w, t, g=9.81):
    q = _truth(q0, w, t)
    up = up_in_body(q)
    cen = cross(w, cross(w, tuple(est.r)))          # specific force of a constant rotation about the pivot
    return ImuSample(t, tuple(w), tuple(g * up[i] + cen[i] for i in range(3)))


@pytest.mark.parametrize("kind", ["mekf", "cf3d"])
@pytest.mark.parametrize("imu_hz,latency", [(100, 0.0), (100, 0.007), (250, 0.004), (500, 0.0)])
def test_constant_rotation_prediction_is_exact_with_latency_and_consecutive_dropouts(kind, imu_hz, latency):
    cfg = _cfg(kind)
    E = Mekf if kind == "mekf" else ComplementaryAttitude
    est = E(cfg, QEQ)
    w = (0.3, -0.2, 0.5)
    T, dt_c = 1.0 / imu_hz, 0.002
    stale_after = latency + 4 * T
    lost = set(range(10, 16))                       # six consecutive samples lost
    pending = []
    n_imu = int(round(1.0 / T))
    for i in range(n_imu):
        if i not in lost:
            pending.append(_sample(est, QEQ, w, i * T))
    max_err, stale_seen, k = 0.0, 0, 0
    last_meas = None
    while k * dt_c <= 1.0 + 1e-12:
        t = k * dt_c
        while pending and pending[0].t + latency <= t + 1e-12:
            s = pending.pop(0)
            assert est.accept(s, t)
            last_meas = s.t
        qp, wp = est.predict(t)
        if last_meas is not None:
            max_err = max(max_err, angle_between(qp, _truth(QEQ, w, t)))
            assert np.allclose(wp, w, atol=1e-12)
            age = t - est.t
            assert est.t == last_meas and age >= latency - 1e-12
            stale_seen += age > stale_after + EPS_T
        k += 1
    assert max_err < 1e-7            # the alignment's floating-point residual (~4e-8 rad); v4 lagged by |ω|·age ≈ 1e-2 rad
    assert stale_seen > 0                            # six lost samples exceed the 4-period age limit
    assert est.max_gap_s == pytest.approx(7 * T)


def test_v4_style_hold_would_have_lagged_by_rate_times_age():
    """The error the prediction removes: holding the update state lags by |ω|·age."""
    cfg = _cfg("mekf")
    est = Mekf(cfg, QEQ)
    w = (0.0, 0.0, 1.0)
    est.accept(_sample(est, QEQ, w, 0.0), 0.0)
    est.accept(_sample(est, QEQ, w, 0.01), 0.01)
    t = 0.018
    held = angle_between(est.q, _truth(QEQ, w, t))
    pred = angle_between(est.predict(t)[0], _truth(QEQ, w, t))
    assert held == pytest.approx(1.0 * 0.008, rel=1e-6)
    assert pred < 1e-12


# ------------------------------------------------------------------ no double integration, sequencing
def _noisy_stream(n=400, T=0.01, seed=3):
    rng = np.random.default_rng(seed)
    w = np.array([0.4, -0.3, 0.2])
    out = []
    q = QEQ
    for i in range(n):
        w = w + rng.normal(0, 0.05, 3)
        q = qmul(q, exp_vec(tuple(w * T)))
        up = up_in_body(q)
        out.append(ImuSample(i * T, tuple(w + rng.normal(0, 0.01, 3)), tuple(9.81 * np.array(up) + rng.normal(0, 0.05, 3))))
    return out


@pytest.mark.parametrize("E,kind", [(Mekf, "mekf"), (ComplementaryAttitude, "cf3d")])
def test_predict_does_not_change_the_update_state(E, kind):
    cfg = _cfg(kind)
    a, b = E(cfg, QEQ), E(cfg, QEQ)
    for s in _noisy_stream():
        for h in (0.0, 0.003, 0.007, 0.02):       # many predictions between samples on one filter only
            b.predict(b.t + h if b.t is not None else h)
            if kind == "mekf" and b.initialised:
                b.predicted_covariance(b.t + h)
        a.accept(s, s.t)
        b.accept(s, s.t)
    assert a.q == b.q and np.array_equal(a.b, b.b)
    if kind == "mekf":
        assert np.array_equal(a.P, b.P)


def test_duplicate_and_out_of_order_samples_are_rejected_and_counted():
    cfg = _cfg("mekf")
    est = Mekf(cfg, QEQ)
    st = _noisy_stream(n=20)
    for s in st[:10]:
        assert est.accept(s, s.t)
    snap = (est.q, est.b.copy(), est.P.copy(), est.t, est.last_gyro.copy())
    assert est.accept(st[9], 0.2) is False                          # duplicate time stamp
    assert est.accept(ImuSample(st[9].t, (9, 9, 9), (0, 0, 9.81)), 0.2) is False  # same stamp, other content
    assert est.accept(st[4], 0.2) is False                          # out of order
    assert (est.rejected_duplicate, est.rejected_out_of_order) == (2, 1)
    assert est.q == snap[0] and np.array_equal(est.b, snap[1]) and np.array_equal(est.P, snap[2]) and est.t == snap[3]
    assert np.array_equal(est.last_gyro, snap[4])
    assert est.accept(st[10], 0.2) is True and est.processed == 11


def test_uninitialised_estimate_is_nominal_and_invalid():
    raw = dict(REVIEW_PROBE, sensor=dict(REVIEW_PROBE["sensor"], latency_ms=20, dropout=0))
    eng, res, rows = spy_run(raw)
    first = rows[0]["est"]
    assert first["valid"] is False and first["age"] is None and first["source"] == "prediction"
    assert tuple(first["q"]) == tuple(QEQ) and tuple(first["w"]) == (0.0, 0.0, 0.0)
    init_rows = [r for r in rows if r["est"]["valid"]]
    assert init_rows and init_rows[0]["t"] == pytest.approx(0.02)
    tl = [e for e in simulate(raw)["timeline"]["events"] if e["type"] == "estimator_init"]
    assert len(tl) == 1 and tl[0]["t"] == pytest.approx(0.02) and tl[0]["severity"] == "info"
    assert res["estimator_stats"]["initialised_at_s"] == pytest.approx(0.02) and res["estimator_stats"]["initial_sample_t_s"] == 0.0


# ------------------------------------------------------------------ covariance
def test_mekf_covariance_finite_symmetric_psd_with_dropouts_and_predictions():
    raw = {"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": "mekf"}, "duration_s": 6, "seed": 11,
           "initial": {"tilt_deg": 1, "rate_dps": 5}, "sensor": {"rate_hz": 100, "dropout": 0.3, "latency_ms": 5}}
    filters, p = capture_filters(Mekf)
    checks = {"n": 0}
    orig = Mekf.predict

    def predict(self, t):
        P = self.predicted_covariance(t)
        for M in (self.P, P):
            assert np.all(np.isfinite(M))
            assert np.max(np.abs(M - M.T)) <= 1e-15 * max(1.0, np.max(np.abs(M)))
            assert np.min(np.linalg.eigvalsh(M)) >= -1e-15
        checks["n"] += 1
        return orig(self, t)
    with p, patch.object(Mekf, "predict", predict):
        r = simulate(raw)
    assert r["ok"] and r["fellAt"] is None and checks["n"] > 5000
    st = r["executed"]["estimator"]["stats"]
    # gravity-only correction: heading uncertainty grows, tilt stays small (documented limitation kept)
    assert st["final_heading_sd_deg"] > 1.0 > st["final_tilt_sd_deg"]


def test_mekf_reset_jacobian_matches_the_documented_equations():
    cfg = _cfg("mekf")
    est = Mekf(cfg, QEQ)
    s0 = ImuSample(0.0, (0.0, 0.0, 0.0), tuple(9.81 * np.array(up_in_body(QEQ))))
    est.accept(s0, 0.0)
    # a tilted measurement: a large innovation, so G differs visibly from I
    q_t = qmul(QEQ, exp_vec((0.05, -0.04, 0.0)))
    s1 = ImuSample(0.01, (0.0, 0.0, 0.0), tuple(9.81 * np.array(up_in_body(q_t))))
    P0, q0 = est.P.copy(), est.q
    est.accept(s1, 0.01)
    # independent re-computation of propagation, Joseph update and reset
    dt = 0.01
    Pp = est._propagate_cov(P0, np.zeros(3), dt)
    h = np.array(up_in_body(q0))
    H = np.zeros((3, 6))
    H[:, :3] = np.array([[0, -h[2], h[1]], [h[2], 0, -h[0]], [-h[1], h[0], 0]])
    R = np.eye(3) * est.Rm
    K = Pp @ H.T @ np.linalg.inv(H @ Pp @ H.T + R)
    z = np.array(s1.accel) / np.linalg.norm(s1.accel)
    dx = K @ (z - h)
    A = np.eye(6) - K @ H
    Pj = A @ Pp @ A.T + K @ R @ K.T
    d = dx[:3]
    G = np.eye(6)
    G[:3, :3] -= 0.5 * np.array([[0, -d[2], d[1]], [d[2], 0, -d[0]], [-d[1], d[0], 0]])
    expect = G @ Pj @ G.T
    assert np.linalg.norm(d) > 1e-3
    assert np.allclose(est.P, 0.5 * (expect + expect.T), rtol=1e-12, atol=1e-18)
    assert not np.allclose(est.P, Pj, rtol=1e-9, atol=0)    # the reset Jacobian is applied (v4 used G = I)


# ------------------------------------------------------------------ rates, staleness, record, timeline
@pytest.mark.parametrize("integ,fs,imu", [(500, 500, 100), (500, 500, 250), (500, 500, 500), (1000, 500, 1000), (1000, 250, 100)])
def test_age_bounds_at_several_rate_combinations(integ, fs, imu):
    raw = {"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": "mekf"}, "duration_s": 0.6, "seed": 5,
           "params": {"fs": fs}, "solver": {"integration_hz": integ}, "record_hz": fs,
           "sensor": {"rate_hz": imu, "latency_ms": 4}}
    eng, res, rows = spy_run(raw)
    T, dtc = 1.0 / imu, 1.0 / fs
    for r in rows:
        e = r["est"]
        assert e["t"] == r["t"]
        if e["t_meas"] is None:
            continue
        assert e["valid"] and not e["stale"]
        assert abs(e["t_meas"] / T - round(e["t_meas"] / T)) < 1e-6          # a sample time stamp
        # delivered at the first control tick at or after t_m + latency, newest until the next one is delivered
        assert 0.004 - 1e-12 <= e["age"] < 0.004 + T + dtc - 1e-12
    st = res["estimator_stats"]
    assert st["samples_dropped"] == 0 and st["max_sample_gap_s"] == pytest.approx(T)
    assert st["stale_after_s"] == pytest.approx(0.004 + 4 * T)


def test_stale_interval_flags_estimate_record_metrics_and_timeline():
    raw = {"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": "mekf"}, "duration_s": 1.0, "seed": 5,
           "record_hz": 500, "sensor": {"rate_hz": 100}, "initial": {"tilt_deg": 1}}
    orig = Imu3D.measure

    def measure(self, t, q, w, wd):
        if 0.30 <= t < 0.40:        # a 100 ms blackout: ten consecutive samples lost
            self.dropped += 1
            return
        return orig(self, t, q, w, wd)
    with patch.object(Imu3D, "measure", measure):
        eng, res, rows = spy_run(raw)
        r = simulate(raw)
    stale_rows = [x for x in rows if x["est"]["stale"]]
    assert stale_rows
    lim = 4 * 0.01
    for x in rows:
        e = x["est"]
        if e["age"] is not None:
            assert e["stale"] == (e["age"] > lim + EPS_T) and e["valid"] == (not e["stale"])
    t0 = min(x["t"] for x in stale_rows)
    t1 = max(x["t"] for x in stale_rows)
    assert t0 == pytest.approx(0.29 + lim, abs=0.0021) and t1 < 0.40 + 1e-9
    ev = [e for e in r["timeline"]["events"] if e["type"] == "estimate_stale"]
    assert len(ev) == 1 and ev[0]["severity"] == "warning" and ev[0]["t"] == pytest.approx(t0, abs=0.0021)
    est = r["research"]["estimator"]
    assert est["stale_s"] == pytest.approx(t1 - t0 + 0.002, abs=0.0025) and est["invalid_s"] >= est["stale_s"]
    assert est["age_max_s"] == pytest.approx(0.11 - 0.002, abs=0.0021)
    S = r["samples"]["cols"]
    ages = dict(zip(S["t"], S["est_age"]))
    valid = dict(zip(S["t"], S["est_valid"]))
    assert valid[0.36] == 0 and valid[0.2] == 1 and ages[0.36] == pytest.approx(0.07, abs=1e-6)
    assert r["samples"]["units"]["est_age"].startswith("s")


def test_configured_stale_limit_is_validated_and_used():
    raw = dict(REVIEW_PROBE, estimator={"type": "mekf", "stale_after_s": 0.015})
    r = simulate(raw)
    assert r["ok"] and r["executed"]["estimator"]["stats"]["stale_after_s"] == 0.015
    assert r["config"]["estimator"]["stale_after_s"] == 0.015
    bad = validate_config(dict(REVIEW_PROBE, estimator={"type": "mekf", "stale_after_s": -1}))
    assert not bad.ok and any(e["path"] == "estimator.stale_after_s" for e in bad.errors)
    c = normalize({"mode": "corner", "sensor": {"latency_ms": 10}})[0]
    assert default_stale_after_s(c, 0.01) == pytest.approx(0.05)


def test_edge_mode_3d_filter_uses_the_prediction_too():
    raw = {"mode": "edge", "controller": {"type": "none"}, "estimator": {"type": "cf3d"}, "duration_s": 0.5, "seed": 3,
           "initial": {"tilt_deg": 0, "rate_dps": 20}, "sensor": dict(NOISE_FREE, rate_hz=100, accel_dynamic=False)}
    eng, res, rows = spy_run(raw)
    frozen = [(a, b) for a, b in zip(rows, rows[1:]) if not b["delivered"] and a["est"]["theta"] == b["est"]["theta"] and abs(a["est"]["thetadot"]) > .1]
    assert frozen == []
    ages = [r["est"]["age"] for r in rows if r["est"]["age"] is not None]
    assert max(ages) == pytest.approx(0.008, abs=1e-9) and min(ages) == 0.0


# ------------------------------------------------------------------ legacy estimators and the baseline
def test_legacy_edge_estimators_report_truthful_age_without_changing_parity():
    raw = {"mode": "edge", "controller": {"type": "lqr"}, "estimator": {"type": "kf"}, "duration_s": 0.5, "seed": 9,
           "sensor": {"latency_ms": 8, "dropout": 0.2}}
    eng, res, rows = spy_run(raw)
    dt = 0.002
    lagK = 4
    for k, r in enumerate(rows[:-1]):
        e = r["est"]
        assert e["source"] == "legacy" and e["t"] == r["t"]
        assert e["age"] >= min(k, lagK) * dt - 1e-12              # delayed packets keep their own time stamp
        assert abs(e["age"] / dt - round(e["age"] / dt)) < 1e-6
    assert max(r["est"]["age"] for r in rows) > lagK * dt + 1e-9   # a dropout repeats the previous packet
    st = res["estimator_stats"]
    assert st["timing"] == "legacy" and st["packets_repeated_on_dropout"] > 0 and st["latency_steps"] == lagK


def test_perfect_state_baseline_reports_truth_with_zero_age():
    raw = {"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": "ideal"}, "duration_s": 0.5}
    eng, res, rows = spy_run(raw, precise=True)
    for r in rows:
        e = r["est"]
        assert e["source"] == "truth" and e["age"] == 0.0 and e["valid"] and e["t_meas"] == r["t"]
    r = simulate(raw)
    assert r["research"]["estimator"] is None and r["executed"]["estimator"]["truth_access"] is True
    assert "est_age" not in r["samples"]["cols"]


def test_sensor_filter_dynamic_acceleration_mismatch_is_warned_not_changed():
    v = validate_config(REVIEW_PROBE)          # the review probe: gravity-only sensor, compensating filter
    assert v.ok
    w = [x for x in v.warnings if x["path"] == "estimator.mekf.compensate_dynamic"]
    assert len(w) == 1 and "kept as requested" in w[0]["message"]
    assert (v.config["estimator"].get("mekf") or {}).get("compensate_dynamic", True) is True
    v2 = validate_config(dict(REVIEW_PROBE, estimator={"type": "mekf", "mekf": {"compensate_dynamic": False}}))
    assert not [x for x in v2.warnings if x["path"] == "estimator.mekf.compensate_dynamic"]

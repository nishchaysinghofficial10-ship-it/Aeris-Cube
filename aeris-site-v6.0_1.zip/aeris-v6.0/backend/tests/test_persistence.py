"""Persistence (docs/DATABASE.md): immutable final datasets with member hashes, the dataset export bundle, and
backup → restore into a FRESH instance with everything traceable (records, sweeps, datasets, parameter sets,
recordings, id counters), including a reproduction on the restored instance."""
from __future__ import annotations

import json
import sqlite3
import time
import zlib

import pytest
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app
from aeris_backend.storage.base import IntegrityError
from aeris_backend.storage.sqlite import SqliteRepository
from aeris_backend.telemetry.emulator import Emulator
from aeris_backend.telemetry.stream import TelemetryHub
from aeris_backend.tools import dbtool

TERMINAL = ("complete", "failed", "cancelled")


def wait(c, jid, timeout=180):
    t0 = time.time()
    while time.time() - t0 < timeout:
        j = c.get(f"/api/v1/jobs/{jid}").json()
        if j["state"] in TERMINAL:
            return j
        time.sleep(0.05)
    raise AssertionError("job did not finish")


def synthetic_recording(frames=120):
    emu = Emulator(mode="corner", rate_hz=50, seed=3)
    hub = TelemetryHub()
    hub.on_connect({"kind": "test", "address": "memory"}, 0.0)
    gen = emu.session()
    kind, line = next(gen)
    hub.feed_line(line, 0.0)
    hub.start_recording("persistence test", 0.0)
    n = 0
    while n < frames:
        kind, line = next(gen)
        if kind == "line" and hub.feed_line(line, 0.0) == "frame":
            n += 1
    return hub.stop_recording(1.0)


def make_app(db, tmp_path):
    return create_app({"db": str(db), "workers": 2, "max_jobs": 2, "origins": ["http://localhost:8000"], "telemetry_dir": str(tmp_path)})


def populate(c):
    """An advanced run, a sweep, a parameter set, a synthetic recording and a finalised dataset of all of them."""
    ps = c.post("/api/v1/parameter-sets", json={"id": "fixture-set-1", "label": "fixture (not a measurement)",
                                                "values": {"params.m": {"value": 1.85, "unit": "kg", "method": "fixture", "date": "2026-09-01", "evidence": "test fixture"}}}).json()
    cfg = {"mode": "corner", "duration_s": 2, "seed": 11, "controller": {"type": "nlpd"}, "estimator": {"type": "mekf"},
           "initial": {"attitude_q": [0.8809905529792110, 0.3399789848371774, -0.3290195188065467, -0.004011442979123468], "body_rate_dps": [3, -2, 1]},
           "reference": {"attitude": "balance", "heading": "free"}}
    j = wait(c, c.post("/api/v1/simulations", json={"config": cfg, "meta": {"name": "advanced"}, "parameter_set": ps["id"]}).json()["job"]["id"])
    assert j["state"] == "complete", j
    run_id = j["result_ref"]["id"]
    sw = {"name": "persist", "revision": "1.2", "mode": "grid", "base": {"mode": "edge"}, "controllers": ["lqr", "pid"],
          "variables": [{"key": "tilt_deg", "min": 1, "max": 4, "steps": 3}], "duration_s": 2, "record_hz": 10, "criterion": "research"}
    js = wait(c, c.post("/api/v1/sweeps", json={"sweep": sw}).json()["job"]["id"])
    assert js["state"] == "complete"
    sweep_id = js["result_ref"]["id"]
    rec = c.post("/api/v1/hardware/recordings", json=synthetic_recording()).json()
    ds = c.post("/api/v1/datasets", json={"title": "persist", "run_ids": [run_id], "sweep_ids": [sweep_id], "recording_ids": [rec["id"]]}).json()
    fin = c.post(f"/api/v1/datasets/{ds['id']}/finalize").json()
    assert fin["status"] == "final" and set(fin["finalized"]["member_hashes"]) == {run_id, sweep_id, rec["id"]}
    return {"run": run_id, "sweep": sweep_id, "recording": rec["id"], "dataset": ds["id"], "paramset": ps["id"]}


def test_final_datasets_are_immutable_and_exports_prove_it(tmp_path):
    db = tmp_path / "a.sqlite3"
    with TestClient(make_app(db, tmp_path)) as c:
        ids = populate(c)
        r = c.post(f"/api/v1/datasets/{ids['dataset']}/finalize")
        assert r.status_code == 409 and r.json()["error"]["code"] == "already_final"
        repo = c.app.state.repo
        doc = repo.get("datasets", ids["dataset"])
        with pytest.raises(IntegrityError):
            repo.put("datasets", ids["dataset"], dict(doc, title="changed"))            # the repository refuses, not only the API
        assert repo.get("datasets", ids["dataset"])["title"] == "persist"
        b = c.get(f"/api/v1/datasets/{ids['dataset']}/export")
        assert "attachment" in b.headers["content-disposition"]
        bundle = b.json()
        assert bundle["schema"] == "aeris-dataset-bundle/1" and bundle["integrity"]["members_hash_ok"] and bundle["integrity"]["member_content_ok"]
        assert [r["id"] for r in bundle["members"]["runs"]] == [ids["run"]] and len(bundle["members"]["sweeps"][0]["rows"]) == 6
        assert bundle["members"]["recordings"][0]["synthetic"] is True and "SYNTHETIC" in bundle["note"]
        run = bundle["members"]["runs"][0]
        # traceability: configuration hash, software versions, seed, parameter set, executed method, metric version
        rep = run["reproduction"]
        assert rep["config_hash"] and run["config"]["seed"] == 11 and rep["metrics_version"] == "2"
        assert run["software"]["engine"] and run["executed"]["controller"]["type"] == "nlpd" and run["executed"]["estimator"]["type"] == "mekf"
        assert rep["parameter_set"]["id"] == ids["paramset"] and run["validation"]["status"] == "nominal"   # one measured input is not 'measured'


def test_backup_while_running_restore_into_a_fresh_instance_and_reproduce(tmp_path):
    a_db, b_db, bak = tmp_path / "a.sqlite3", tmp_path / "restored" / "b.sqlite3", tmp_path / "backups" / "a-backup.sqlite3"
    with TestClient(make_app(a_db, tmp_path)) as a:
        ids = populate(a)
        run_a = a.get(f"/api/v1/runs/{ids['run']}").json()
        sweep_a = a.get(f"/api/v1/sweeps/{ids['sweep']}").json()
        ds_a = a.get(f"/api/v1/datasets/{ids['dataset']}").json()
        ps_a = a.get(f"/api/v1/parameter-sets/{ids['paramset']}").json()
        rec_a = a.get(f"/api/v1/hardware/recordings/{ids['recording']}").json()
        # online backup while the backend holds its lock and could be writing
        res = dbtool.backup(str(a_db), str(bak))
        assert res["verified"] and res["verify"]["integrity"] == "ok" and res["verify"]["datasets"][0]["integrity"]["member_content_ok"]
        with pytest.raises(FileExistsError):
            dbtool.backup(str(a_db), str(bak))                                     # never overwrites
        last_exp = run_a["experiment_id"]
    out = dbtool.restore(str(bak), str(b_db))
    assert out["verified"] and out["schema"]["schema_version"] == 3
    with pytest.raises(FileExistsError):
        dbtool.restore(str(bak), str(b_db))                                       # never overwrites the restored (or any) database
    with TestClient(make_app(b_db, tmp_path)) as b:
        assert b.get(f"/api/v1/runs/{ids['run']}").json() == run_a
        sweep_b = b.get(f"/api/v1/sweeps/{ids['sweep']}").json()
        assert sweep_b["rows"] == sweep_a["rows"] and sweep_b["analysis"] == sweep_a["analysis"]
        assert b.get(f"/api/v1/datasets/{ids['dataset']}").json() == ds_a
        assert b.get(f"/api/v1/parameter-sets/{ids['paramset']}").json() == ps_a
        assert b.get(f"/api/v1/hardware/recordings/{ids['recording']}").json() == rec_a
        assert b.get(f"/api/v1/datasets/{ids['dataset']}/export").json()["integrity"]["member_content_ok"] is True
        # the restored instance reproduces the run exactly and continues the id counters
        j = wait(b, b.post(f"/api/v1/runs/{ids['run']}/reproduce").json()["job"]["id"])
        rec = b.get(f"/api/v1/runs/{j['result_ref']['id']}").json()
        assert rec["reproduction"]["reproduces"]["identical"] is True
        assert int(rec["experiment_id"].split("-")[-1]) > int(last_exp.split("-")[-1])
        h = b.get("/api/v1/health").json()
        assert h["schema_version"] == 3 and h["db"] == "ok"


def test_verify_detects_a_changed_member_of_a_final_dataset(tmp_path):
    db = tmp_path / "a.sqlite3"
    with TestClient(make_app(db, tmp_path)) as c:
        ids = populate(c)
    assert dbtool.verify(str(db))["ok"] is True
    con = sqlite3.connect(str(db))
    blob = con.execute("SELECT record FROM runs WHERE id=?", (ids["run"],)).fetchone()[0]
    rec = json.loads(zlib.decompress(blob))
    rec["name"] = "edited behind the backend's back"
    con.execute("UPDATE runs SET record=? WHERE id=?", (zlib.compress(json.dumps(rec).encode()), ids["run"]))
    con.commit()
    con.close()
    v = dbtool.verify(str(db))
    assert v["ok"] is False and v["datasets"][0]["integrity"]["changed_members"] == [ids["run"]]
    assert any("content differs" in p for p in v["problems"])


def test_dbtool_cli_prints_json_and_uses_exit_codes(tmp_path):
    db = tmp_path / "x.sqlite3"
    SqliteRepository(str(db)).close()
    assert dbtool.main(["verify", "--db", str(db)]) == 0
    assert dbtool.main(["verify", "--db", str(tmp_path / "missing.sqlite3")]) == 2
    assert dbtool.main(["restore", "--backup", str(db), "--db", str(db)]) == 2          # target exists: refused

"""Reproducing v4 backend records with v5 (docs/MIGRATION_V5.md §3, docs/REPRODUCIBILITY.md §2).

What is asserted, and why it changed in v5.1 (review finding F4 of v5; docs/MIGRATION_V5_1.md §4):
  * Same environment — a rerun made HERE is compared with a second rerun made here, the first one passed through the
    JSON a stored record is kept as: samples (values, units, rate), rows, outcome and research metrics bit-identical.
    Nothing is tolerated.
  * The stored v4 fixtures (site/tests/fixtures/backend_records.json) were generated on another machine (Linux x86-64,
    Python 3.12.3, NumPy 2.5.3). v5 demanded that they reproduce bit-identically on every platform: on macOS arm64 the
    review measured a largest sample difference of 2.053914e-15 for corner_custom (same outcome, 31 rows, 39 columns
    within tolerance), the application correctly said 'within_tolerance', and the test failed. Last-digit
    differences also occur between x86-64 CPUs (NumPy's vectorised maths and BLAS kernels are chosen per CPU), so the
    fixtures are checked with the PREDECLARED cross-environment rule of docs/REPRODUCIBILITY.md §2: every shared
    numeric sample within TOL_REL·max(1, |x|), TOL_REL = 2e-5 (unchanged since v5), the same outcome, the same number
    of rows and the same sample rate, every column and unit on both sides — and the application's own verdict
    'identical' or 'within_tolerance'. The fixtures were not regenerated and the tolerance was not widened.
  * Negative controls show the rule still fails on what matters: one sample changed by a relative 1e-3 or by 1.5 ×
    the tolerance, a changed outcome, a missing column, a changed unit, one row fewer. The Mac-sized 2.05e-15
    difference passes the cross-environment rule and fails the same-environment rule.
  * Runs with a 3-D estimator (cf3d, mekf) differ by design (engine 1.0.0 → 1.1.0): verdict 'different', same
    outcome, and the explanation names the engine change (unchanged from v5)."""
from __future__ import annotations

import copy
import json
import math
import os

import pytest

from aeris_backend.experiments.records import build_record
from aeris_backend.experiments.reproduce import TOL_REL, compare_reproduction, reproduction_config
from aeris_backend.simulation import simulate

FX = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "site", "tests", "fixtures", "backend_records.json")
RECS = json.load(open(FX))["records"]
TOL_DOCUMENTED = 2e-5          # docs/REPRODUCIBILITY.md §2 — changing it is a documented decision, never a test edit
ESTIMATORS_3D = ("cf3d", "mekf")
MAC_DIFF = 2.053914e-15        # the largest sample difference the review measured on macOS arm64 (corner_custom)
_RERUNS: dict = {}


def rerun(name: str) -> dict:
    """The fixture's configuration simulated again here (once per session; the same-environment test below proves
    that a second simulation is bit-identical)."""
    if name not in _RERUNS:
        cfg, _ = reproduction_config(RECS[name])
        _RERUNS[name] = build_record(simulate(cfg), {}, experiment_id="AERIS-EXP-199999")
    return _RERUNS[name]


def cross_environment_problems(orig: dict, new: dict, v: dict) -> list:
    """What the predeclared cross-environment rule finds wrong (an empty list: the reproduction holds)."""
    P = []
    if v["tolerance"]["relative"] != TOL_DOCUMENTED or TOL_REL != TOL_DOCUMENTED:
        P.append(f"tolerance {v['tolerance']} is not the documented relative {TOL_DOCUMENTED}")
    if v["verdict"] not in ("identical", "within_tolerance"):
        P.append(f"verdict {v['verdict']}: first column over tolerance {v['first_column_over_tolerance']}, largest |Δ| {v['max_abs_diff']:.3g}")
    if not v["same_outcome"]:
        P.append(f"outcome {(orig.get('outcome') or {}).get('code')} → {(new.get('outcome') or {}).get('code')}")
    if v["rows"][0] != v["rows"][1] or not v["rows"][0]:
        P.append(f"rows {v['rows']}")
    if v["columns_only_in_original"] or v["columns_only_in_reproduction"]:
        P.append(f"columns only in the fixture {v['columns_only_in_original']}, only in the rerun {v['columns_only_in_reproduction']}")
    if v["columns_compared"] != len(orig["samples"]["cols"]):
        P.append(f"{v['columns_compared']} of {len(orig['samples']['cols'])} columns compared")
    ua, ub = orig["samples"].get("units") or {}, new["samples"].get("units") or {}
    if ua != ub:
        P.append("units differ: " + ", ".join(f"{k}: {ua.get(k)!r} vs {ub.get(k)!r}" for k in sorted(set(ua) | set(ub)) if ua.get(k) != ub.get(k)))
    if not math.isclose(float(orig["samples"]["rate_hz"]), float(new["samples"]["rate_hz"]), rel_tol=0, abs_tol=0):
        P.append(f"sample rate {orig['samples']['rate_hz']} vs {new['samples']['rate_hz']}")
    return P


def same_environment_problems(v: dict, a: dict, b: dict) -> list:
    """What the same-environment rule finds wrong: anything but bit-identical samples, outcome and metrics."""
    P = []
    if v["verdict"] != "identical" or v["max_abs_diff"] != 0.0 or not v["identical"]:
        P.append(f"verdict {v['verdict']}, largest |Δ| {v['max_abs_diff']!r}")
    if a["samples"] != b["samples"]:
        P.append("samples (values, units or rate) are not bit-identical")
    if a.get("outcome") != b.get("outcome"):
        P.append("outcome differs")
    if a.get("research") != b.get("research") or a.get("metrics") != b.get("metrics"):
        P.append("metrics differ")
    return P


@pytest.mark.parametrize("name", sorted(RECS))
def test_v4_fixtures_reproduce_within_the_documented_tolerance(name):
    rec = RECS[name]
    assert rec["software"]["engine"] == "aeris-research-engine 1.0.0"
    new = rerun(name)
    v = compare_reproduction(rec, new, rec["id"])
    est = (rec["config"].get("estimator") or {}).get("type")
    if est in ESTIMATORS_3D:
        assert v["verdict"] == "different" and v["same_outcome"]
        assert any("aeris-research-engine 1.0.0 → aeris-research-engine 1.1.0" in e and "mekf" in e for e in v["explanations"])
    else:
        problems = cross_environment_problems(rec, new, v)
        assert not problems, problems
    assert v["metrics_versions"] == ["1", "2"]            # the old record stays version 1; the reproduction is version 2


@pytest.mark.parametrize("name", sorted(RECS))
def test_a_rerun_in_the_same_environment_is_bit_identical(name):
    cfg, _ = reproduction_config(RECS[name])
    stored = json.loads(json.dumps(rerun(name)))          # a stored record is kept as JSON
    again = build_record(simulate(cfg), {}, experiment_id="AERIS-EXP-199998")
    v = compare_reproduction(stored, again, "same-environment rerun")
    problems = same_environment_problems(v, stored, again)
    assert not problems, problems


def perturbed(how: str, name: str = "corner_custom") -> dict:
    """A COPY of a fixture with one controlled change (the fixture file is never modified)."""
    r = copy.deepcopy(RECS[name])
    cols, units = r["samples"]["cols"], r["samples"]["units"]
    col = next(k for k in cols if k != "t" and any(isinstance(x, float) and x != 0 for x in cols[k]))
    i = next(j for j, x in enumerate(cols[col]) if isinstance(x, float) and x != 0)
    x = cols[col][i]
    if how == "mac_2.05e-15":
        cols[col][i] = x + MAC_DIFF
    elif how == "tolerance_x0.5":
        cols[col][i] = x + 0.5 * TOL_DOCUMENTED * max(1.0, abs(x))
    elif how == "tolerance_x1.5":
        cols[col][i] = x + 1.5 * TOL_DOCUMENTED * max(1.0, abs(x))
    elif how == "relative_1e-3":
        cols[col][i] = x * (1 + 1e-3)
    elif how == "outcome_changed":
        r["outcome"] = dict(r["outcome"], code="fallen" if r["outcome"]["code"] != "fallen" else "recovered")
    elif how == "missing_column":
        del cols[col]
        units.pop(col, None)
    elif how == "unit_changed":
        units[col] = "deg" if units.get(col) != "deg" else "rad"
    elif how == "one_row_fewer":
        for k in cols:
            cols[k] = cols[k][:-1]
    else:
        raise ValueError(how)
    assert r != RECS[name], f"{how}: the copy must differ from the fixture"
    return r


@pytest.mark.parametrize("how,cross_ok", [("mac_2.05e-15", True), ("tolerance_x0.5", True), ("relative_1e-3", False), ("tolerance_x1.5", False),
                                          ("outcome_changed", False), ("missing_column", False), ("unit_changed", False), ("one_row_fewer", False)])
def test_negative_controls_meaningful_deviations_and_outcome_changes_still_fail(how, cross_ok, monkeypatch):
    name = "corner_custom"
    orig, new = perturbed(how, name), rerun(name)
    v = compare_reproduction(orig, new, orig["id"])
    cross = cross_environment_problems(orig, new, v)
    assert (not cross) is cross_ok, (how, cross)
    assert same_environment_problems(v, orig, new), f"{how}: the same-environment rule must reject any change"
    # the fixture test itself, given the perturbed fixture, passes exactly when the rule holds
    monkeypatch.setitem(RECS, name, orig)
    if cross_ok:
        test_v4_fixtures_reproduce_within_the_documented_tolerance(name)
    else:
        with pytest.raises(AssertionError):
            test_v4_fixtures_reproduce_within_the_documented_tolerance(name)


def test_comparison_names_metric_versions_and_withholds_version_1_ise():
    """A v4 record (research metrics version 1) next to a v5 record: the comparison says the versions differ and are
    not comparable, and withholds the version-1 ISE (rad²·s labelled deg²·s) instead of showing it next to version 2;
    field names carry the units."""
    from aeris_backend.experiments.compare import compare_runs
    name = next(n for n in sorted(RECS) if (RECS[n].get("research") or {}).get("attitude_error"))
    old = RECS[name]
    cfg, _ = reproduction_config(old)
    new = build_record(simulate(cfg), {}, experiment_id="AERIS-EXP-199998")
    c = compare_runs([old, new])
    r_old, r_new = c["research"]
    assert (r_old["metrics_version"], r_new["metrics_version"]) == ("1", "2")
    assert r_old["attitude_ise_deg2_s"] is None and r_old["attitude_iae_deg_s"] is not None
    assert r_new["attitude_ise_deg2_s"] is not None and r_new["attitude_iae_deg_s"] is not None and r_new["attitude_rms_deg"] is not None
    assert "not comparable" in c["research_note"] and "rad²·s" in c["research_note"]
    again = build_record(simulate(cfg), {}, experiment_id="AERIS-EXP-199997")
    assert compare_runs([new, again])["research_note"] is None        # same version: no note

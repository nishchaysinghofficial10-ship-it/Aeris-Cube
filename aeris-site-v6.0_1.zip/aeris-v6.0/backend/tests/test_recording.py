"""Fix D (v5): the recording schedule (docs/RECORDING.md).

Policy: explicit rate restriction. Samples are integration-step states taken every
stride = f_int / record_hz steps, so record_hz must divide the integration rate; any other value
is rejected with a field-specific error that names the nearest valid rates. The requested and
realized rates and the stride are saved with every run (samples.schedule, executed.rates). The
state at the end of the executed run is always the last sample (a shorter last interval when the
run does not end on the stride grid). Recording only reads the state: it cannot change the
dynamics, the control or the internal (per-integration-step) research metrics.
"""
from __future__ import annotations

import pytest

from aeris_backend.config.validate import valid_record_rates, validate_config
from aeris_backend.simulation import simulate

from conftest import engine_for


def test_v4_mismatch_is_rejected_with_a_field_specific_error():
    """The review case: 60 Hz at 500 Hz integration (v4 recorded every 8 steps = 62.5 Hz, labelled 60 Hz)."""
    v = validate_config({"mode": "corner", "duration_s": 1, "record_hz": 60})
    assert not v.ok
    err = [e for e in v.errors if e["path"] == "record_hz"]
    assert len(err) == 1 and err[0]["kind"] == "range"
    msg = err[0]["message"]
    assert "62.5 Hz" in msg and "55.5556 Hz" in msg and "does not divide" in msg and "mislabelled" in msg


@pytest.mark.parametrize("f_int,rec", [(500, 30), (500, 75), (500, 200), (1000, 300), (2000, 600), (500, 499)])
def test_other_non_divisor_rates_are_rejected(f_int, rec):
    raw = {"mode": "edge", "duration_s": 1, "record_hz": rec, "solver": {"integration_hz": f_int}}
    v = validate_config(raw)
    assert not v.ok and [e for e in v.errors if e["path"] == "record_hz"]
    r = simulate(raw)
    assert r["ok"] is False and any(e["path"] == "record_hz" for e in r["errors"])


def test_valid_rates_are_the_divisors():
    assert valid_record_rates(500, 1, 1000)[:6] == [500, 250, 500 / 3, 125, 100, 500 / 6]
    assert 62.5 in valid_record_rates(500, 1, 1000) and 60 not in valid_record_rates(500, 1, 1000)


@pytest.mark.parametrize("mode", ["edge", "corner"])
@pytest.mark.parametrize("rec", [10, 25, 50, 62.5, 100, 125, 250, 500])
def test_divisor_rates_are_exact_and_labelled_with_requested_and_realized(mode, rec):
    r = simulate({"mode": mode, "duration_s": 1, "record_hz": rec})
    assert r["ok"], r["errors"]
    sch = r["samples"]["schedule"]
    stride = round(500 / rec)
    assert r["samples"]["rate_hz"] == rec and sch["realized_hz"] == rec and sch["requested_hz"] == rec and sch["matches_request"]
    assert sch["stride_steps"] == stride and sch["policy"] == "stride"
    t = r["samples"]["cols"]["t"]
    assert len(t) == (500 - 1) // stride + 2 == sch["rows"]          # every stride-th step, plus the final state
    assert all(abs(t[i] - i * stride / 500) < 1e-9 for i in range(len(t) - 1)) and t[-1] == pytest.approx(1.0)
    assert sch["final_interval_s"] == pytest.approx((500 - (len(t) - 2) * stride) / 500)
    assert r["executed"]["rates"] == {"integration_hz": 500, "control_hz": 500, "sensor_hz": 500, "record_hz": rec,
                                      "record_hz_requested": rec, "record_stride_steps": stride}


def test_endpoint_off_the_stride_grid_is_recorded_with_a_shorter_last_interval():
    r = simulate({"mode": "edge", "duration_s": 1.004, "record_hz": 100})     # 502 steps, stride 5
    t = r["samples"]["cols"]["t"]
    assert t[-2] == pytest.approx(1.0) and t[-1] == pytest.approx(1.004)
    sch = r["samples"]["schedule"]
    assert sch["final_interval_s"] == pytest.approx(0.004) and sch["t_end_s"] == pytest.approx(1.004)


def test_early_termination_records_the_final_state():
    r = simulate({"mode": "edge", "controller": {"type": "none"}, "initial": {"tilt_deg": 8}, "duration_s": 5, "record_hz": 10,
                  "termination": {"post_fall_s": 0.1}})
    assert r["fellAt"] is not None
    t = r["samples"]["cols"]["t"]
    end = r["executed"]["simulated_s"]
    assert t[-1] == pytest.approx(end) and t[-1] - t[-2] <= 0.1 + 1e-9
    assert r["samples"]["schedule"]["t_end_s"] == pytest.approx(end)


RICH = {"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": "mekf"}, "duration_s": 3, "seed": 21,
        "initial": {"tilt_deg": 2}, "sensor": {"rate_hz": 100, "dropout": 0.1, "latency_ms": 4},
        "disturbances": [{"type": "impulse", "t_s": 1.0, "magnitude_Nms": 0.02, "direction": [1, 0, 0], "frame": "body"}],
        "solver": {"integration_hz": 1000}}


def _strip(d):
    """Research metrics without the entries that describe the recording itself."""
    return {k: v for k, v in d.items() if k not in ("units",)}


@pytest.mark.parametrize("base", [RICH, dict(RICH, mode="edge", estimator={"type": "kf"}, sensor={}, disturbances=[],
                                                  solver={"integration_hz": 500}),
                                  dict(RICH, termination={"stop_on_recovery": True}, recovery={"hold_s": 0.2})])
def test_recording_rate_does_not_change_dynamics_control_or_internal_metrics(base):
    f_int = base["solver"]["integration_hz"]
    runs = {rec: engine_for(dict(base, record_hz=rec), precise=True).run() for rec in (10, 50, f_int / 4, f_int)}
    ref = runs[f_int]
    for rec, res in runs.items():
        assert res["full"]["nSteps"] == ref["full"]["nSteps"]
        for key in ("e", "rate", "sat", "estErr", "estAtt", "estAge", "estStale"):
            if ref["full"].get(key) is not None:
                a, b = list(res["full"][key]), list(ref["full"][key])
                assert [x if x == x else "nan" for x in a] == [x if x == x else "nan" for x in b], (rec, key)
        for i in range(len(ref["full"]["Tapp"])):
            assert list(res["full"]["Tapp"][i]) == list(ref["full"]["Tapp"][i])
            assert list(res["full"]["om"][i]) == list(ref["full"]["om"][i])
        assert res["fellAt"] == ref["fellAt"] and res["energy"] == ref["energy"]
        # every recorded sample equals the finest recording at the same time
        S, R = res["samples"]["cols"], ref["samples"]["cols"]
        idx = {round(t, 9): i for i, t in enumerate(R["t"])}
        for i, t in enumerate(S["t"]):
            j = idx[round(t, 9)]
            for c in S:
                assert S[c][i] == R[c][j], (rec, c, t)
    sims = {rec: simulate(dict(base, record_hz=rec)) for rec in (10, f_int)}
    assert _strip(sims[10]["research"]) == _strip(sims[f_int]["research"])
    assert sims[10]["metrics"] == sims[f_int]["metrics"]
    assert sims[10]["termination"] == sims[f_int]["termination"]

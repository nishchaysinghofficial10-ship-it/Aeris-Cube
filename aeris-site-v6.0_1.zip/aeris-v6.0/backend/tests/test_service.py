"""Storage, job manager (cancel at every stage, restart policies), REST API (envelopes, errors,
reproduction, datasets, parameter sets) and WebSocket/polling consistency."""
import asyncio
import time

import pytest
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app
from aeris_backend.jobs.manager import JobManager
from aeris_backend.storage.base import TransitionError
from aeris_backend.storage.sqlite import SqliteRepository

TERMINAL = ("complete", "failed", "cancelled")


# ---------------------------------------------------------------- repository rules
def test_repository_transitions_monotone_progress_terminal_immutable(tmp_db):
    r = SqliteRepository(tmp_db)
    r.create_job({"id": "j1", "kind": "sweep", "created": "2026-01-01T00:00:00Z", "total": 10})
    with pytest.raises(TransitionError):
        r.update_job("j1", state="running")                         # queued → running skips initializing
    r.update_job("j1", state="initializing")
    j = r.update_job("j1", state="running", progress={"total": 10, "done": 0})
    r.update_job("j1", progress={"done": 4})
    j = r.update_job("j1", progress={"done": 2})                     # never goes back
    assert j["progress"]["done"] == 4
    j = r.update_job("j1", progress={"done": 99})                    # never above total
    assert j["progress"]["done"] == 10
    with pytest.raises(TransitionError):
        r.update_job("j1", progress={"total": 12})                   # total fixed while running
    seq = j["seq"]
    j = r.update_job("j1", state="cancelled")
    assert j["seq"] == seq + 1 and j["finished"]
    with pytest.raises(TransitionError):
        r.update_job("j1", message="x")                               # terminal: immutable
    assert r.next_id("experiment") == 100000 and r.next_id("experiment") == 100001


def test_sweep_rows_idempotent(tmp_db):
    r = SqliteRepository(tmp_db)
    r.create_sweep({"id": "S", "created": "t", "definition": {}, "total": 2})
    row = {"index": 0, "status": "ok", "outcome": "recovered"}
    assert r.add_sweep_row("S", row, {"a": 1}) is True
    assert r.add_sweep_row("S", row, {"a": 1}) is False
    assert r.row_indices("S") == {0}
    assert r.sweep_rows("S", include_config=True)[0]["config"] == {"a": 1}


# ---------------------------------------------------------------- job manager: restart
SWEEP = {"name": "restart", "revision": "1.1", "mode": "grid", "base": {"mode": "edge"}, "controllers": ["lqr", "pid"],
         "variables": [{"key": "tilt_deg", "min": 0, "max": 3, "steps": 12}], "duration_s": 6, "record_hz": 10}


async def run_until_some_rows(db, min_rows=4):
    repo = SqliteRepository(db)
    m = JobManager(repo, workers=1, max_jobs=1)
    await m.start()
    job = m.submit_sweep(SWEEP)
    sid = job["result_ref"]["id"]
    t0 = time.time()
    while len(repo.row_indices(sid)) < min_rows and time.time() - t0 < 60:
        await asyncio.sleep(0.05)
    # simulate a crash: stop without finishing (the job stays 'running' in the database)
    for t in list(m.active.values()):
        t.cancel()
    m.dispatcher.cancel()
    m.pool.shutdown(wait=True, cancel_futures=True)
    await asyncio.sleep(0.1)
    return job["id"], sid


async def recover(db, policy):
    repo = SqliteRepository(db)
    m = JobManager(repo, workers=1, max_jobs=1, restart_policy=policy)
    await m.start()
    return repo, m


def test_restart_resume_completes_without_duplicates(tmp_db):
    async def go():
        jid, sid = await run_until_some_rows(tmp_db)
        repo = SqliteRepository(tmp_db)
        before = repo.get_job(jid)
        assert before["state"] == "running" and before["progress"]["done"] < before["progress"]["total"]
        stored = len(repo.row_indices(sid))
        repo, m = await recover(tmp_db, "resume")
        t0 = time.time()
        while repo.get_job(jid)["state"] not in TERMINAL and time.time() - t0 < 120:
            await asyncio.sleep(0.1)
        j = repo.get_job(jid)
        await m.stop()
        assert j["state"] == "complete" and j["restarts"] == 1
        rows = repo.sweep_rows(sid)
        assert len(rows) == 24 and len({r["index"] for r in rows}) == 24
        assert j["progress"]["done"] == 24
        assert stored >= 4
    asyncio.run(go())


def test_restart_fail_policy_marks_interruption(tmp_db):
    async def go():
        jid, sid = await run_until_some_rows(tmp_db)
        repo, m = await recover(tmp_db, "fail")
        j = repo.get_job(jid)
        await m.stop()
        assert j["state"] == "failed" and j["error"]["code"] == "interrupted"
        sw = repo.get_sweep(sid)
        assert sw["status"] == "interrupted" and sw["partial"] is True and len(sw["rows"]) >= 4
    asyncio.run(go())


# ---------------------------------------------------------------- REST API
@pytest.fixture(scope="module")
def client(tmp_path_factory):
    db = str(tmp_path_factory.mktemp("api") / "api.sqlite3")
    app = create_app({"db": db, "workers": 2, "max_jobs": 2, "origins": ["http://localhost:8000", "null"], "telemetry_dir": str(tmp_path_factory.mktemp("tel"))})
    with TestClient(app) as c:
        yield c


def wait(c, jid, timeout=120):
    t0 = time.time()
    while time.time() - t0 < timeout:
        j = c.get(f"/api/v1/jobs/{jid}").json()
        if j["state"] in TERMINAL:
            return j
        time.sleep(0.05)
    raise AssertionError("job did not finish")


def test_health_and_capabilities_are_reported(client):
    h = client.get("/api/v1/health").json()
    assert h["status"] == "ok" and h["backend"] == "aeris-research-backend"
    c = client.get("/api/v1/capabilities").json()
    assert c["reported"] is True and "mimo-lqr" in c["structures"] and "mekf" in c["estimators"]["corner"]
    # v5: telemetry is available (read-only, loopback), but no physical device is live
    assert c["hardware"]["live"] is False and c["telemetry"]["available"] is True and c["telemetry"]["read_only"] is True
    # v5: the experiment contract is reported (the site refuses revision-1.2 features for a backend that does not)
    assert c["config"]["revisions"] == ["1.0", "1.1", "1.2"] and c["config"]["revision"] == "1.2"
    ex = c["experiment"]
    assert ex["initial_state"]["attitude_q"] and ex["initial_state"]["body_rate_dps"] and ex["initial_state"]["wheel_speeds_rpm"]
    assert ex["reference"]["headings"] == ["hold", "free"] and ex["reference"]["commands"] == ["yaw_step"] and ex["reference"]["equilibrium_reported"]
    assert ex["estimator_timing"]["stale_after_s"] == [1e-4, 10]
    assert c["metrics"]["version"] == "2" and c["sweep"]["revision"] == "1.2" and c["sweep"]["criteria"] == ["legacy", "research", "research_sustained"]
    # what is reported is what is accepted: a revision-1.2 setup built from these fields validates
    v = client.post("/api/v1/validate", json={"config": {"mode": "corner", "initial": {"attitude_q": [0.880990552979211, 0.3399789848371774, -0.3290195188065467, -0.004011442979123468], "body_rate_dps": [0, 0, 1]},
                                                        "reference": {"attitude": "balance", "heading": "free", "yaw_deg": 0},
                                                        "estimator": {"type": "mekf", "stale_after_s": 0.05}}}).json()
    assert v["ok"], v["errors"]


def test_error_envelopes(client):
    for path in ("/api/v1/jobs/nope", "/api/v1/runs/nope", "/api/v1/sweeps/nope", "/api/v1/datasets/nope"):
        r = client.get(path)
        assert r.status_code == 404 and r.json()["error"]["code"] == "not_found"
    r = client.post("/api/v1/simulations", json={"config": {"mode": "edge", "duration_s": "long"}})
    assert r.status_code == 422 and r.json()["error"]["code"] == "invalid_config"
    assert r.json()["error"]["details"][0]["path"] == "duration_s"
    r = client.post("/api/v1/simulations", json={"cfg": {}})
    assert r.status_code == 422 and r.json()["error"]["code"] == "invalid_request"
    r = client.post("/api/v1/sweeps", json={"sweep": {"variables": []}})
    assert r.status_code == 422 and r.json()["error"]["code"] == "invalid_sweep"


def test_single_run_record_and_provenance(client):
    j = client.post("/api/v1/simulations", json={"config": {"mode": "corner", "controller": {"type": "nlpd"}, "estimator": {"type": "mekf"}, "duration_s": 3}, "meta": {"name": "t"}}).json()["job"]
    j = wait(client, j["id"])
    assert j["state"] == "complete" and j["result_ref"]["kind"] == "run"
    rec = client.get(f"/api/v1/runs/{j['result_ref']['id']}").json()
    assert rec["origin"]["engine"] == "aeris-research-backend" and rec["origin"]["adapter"] == "research-api"
    assert rec["schema_revision"] == "1.3" and rec["validation"]["status"] == "nominal"   # v5 run revision
    assert rec["experiment_id"].startswith("AERIS-EXP-1")
    assert rec["executed"]["controller"]["type"] == "nlpd" and rec["executed"]["estimator"]["type"] == "mekf"
    assert "Not a hardware measurement" in rec["provenance"]
    csv = client.get(f"/api/v1/runs/{rec['id']}/export?format=csv").text
    assert csv.startswith("# AERIS run export") and "termination:" in csv


def test_reproduction_is_identical(client):
    j = wait(client, client.post("/api/v1/simulations", json={"config": {"mode": "edge", "estimator": {"type": "kf"}, "seed": 3, "duration_s": 2}}).json()["job"]["id"])
    rid = j["result_ref"]["id"]
    j2 = wait(client, client.post(f"/api/v1/runs/{rid}/reproduce").json()["job"]["id"])
    rec2 = client.get(f"/api/v1/runs/{j2['result_ref']['id']}").json()
    rep = rec2["reproduction"]["reproduces"]
    assert rep["identical"] and rep["max_abs_diff"] == 0.0 and rep["same_config_hash"]


def test_cancel_before_during_after_and_during_analysis(client):
    big = {"revision": "1.1", "mode": "random", "samples": 300, "base": {"mode": "corner"}, "controllers": ["lqr", "pid"],
           "variables": [{"key": "tilt_deg", "min": 0, "max": 10}], "duration_s": 8, "record_hz": 5}
    # before execution: fill both job slots, then cancel a queued one
    a = client.post("/api/v1/sweeps", json={"sweep": big}).json()["job"]
    b = client.post("/api/v1/sweeps", json={"sweep": big}).json()["job"]
    c = client.post("/api/v1/sweeps", json={"sweep": big}).json()["job"]
    time.sleep(0.3)
    cj = client.post(f"/api/v1/jobs/{c['id']}/cancel").json()
    assert cj["state"] == "cancelled" and cj["progress"]["done"] == 0 and cj["result_ref"]["kind"] == "sweep"
    sw = client.get(f"/api/v1/sweeps/{cj['result_ref']['id']}").json()
    assert sw["partial"] is True and sw["rows"] == []
    # during execution: finished runs are kept, in-flight runs are dropped, progress matches the rows
    time.sleep(1.5)
    aj = client.post(f"/api/v1/jobs/{a['id']}/cancel").json()
    assert aj["state"] == "cancelled"
    swa = client.get(f"/api/v1/sweeps/{aj['result_ref']['id']}").json()
    assert swa["partial"] is True and 0 < len(swa["rows"]) < 600 and len(swa["rows"]) == aj["progress"]["done"]
    # the partial sweep's analysis is computed from exactly the finished rows and says so
    an = swa["analysis"]
    assert an is not None and an["partial"] is True and an["computed_from"] == f"{len(swa['rows'])} saved rows" and an["notes"][0].startswith("PARTIAL")
    assert sum(v["n"] for v in an["controllers"].values()) == len(swa["rows"])
    client.post(f"/api/v1/jobs/{b['id']}/cancel")
    # after completion: unchanged
    small = dict(big, samples=3, duration_s=1)
    d = wait(client, client.post("/api/v1/sweeps", json={"sweep": small}).json()["job"]["id"])
    again = client.post(f"/api/v1/jobs/{d['id']}/cancel").json()
    assert again["state"] == "complete" and again["seq"] == d["seq"]
    # during analysis: all runs kept, analysis not computed, not labelled partial
    many = dict(big, samples=2000, duration_s=0.5, controllers=["lqr", "pid", "adp"])
    e = client.post("/api/v1/sweeps", json={"sweep": many}).json()["job"]
    t0 = time.time()
    while client.get(f"/api/v1/jobs/{e['id']}").json()["state"] != "analyzing" and time.time() - t0 < 240:
        time.sleep(0.01)
    ej = client.post(f"/api/v1/jobs/{e['id']}/cancel").json()
    if ej["state"] == "cancelled":
        swe = client.get(f"/api/v1/sweeps/{ej['result_ref']['id']}").json()
        assert swe["partial"] is False and swe["analysis"] is None and swe.get("analysis_cancelled") is True
        assert len(swe["rows"]) == 6000
    else:   # analysis finished before the cancel arrived: the completed job must not change
        assert ej["state"] == "complete"


def test_websocket_and_polling_agree(client):
    j = client.post("/api/v1/simulations", json={"config": {"mode": "edge", "duration_s": 2}}).json()["job"]
    msgs = []
    with client.websocket_connect(f"/api/v1/live/{j['id']}") as ws:
        while True:
            try:
                m = ws.receive_json()
            except Exception:
                break
            msgs.append(m)
            if m["type"] == "job" and m["job"]["state"] in TERMINAL:
                break
    seqs = [m["seq"] for m in msgs if m["type"] == "job"]
    assert seqs == sorted(seqs) and len(set(seqs)) == len(seqs)
    polled = client.get(f"/api/v1/jobs/{j['id']}").json()
    assert msgs[-1]["job"]["state"] == polled["state"] == "complete"
    assert msgs[-1]["seq"] == polled["seq"]


def test_websocket_rejects_foreign_origin(client):
    j = client.post("/api/v1/simulations", json={"config": {"mode": "edge", "duration_s": 1}}).json()["job"]
    with pytest.raises(Exception):
        with client.websocket_connect(f"/api/v1/live/{j['id']}", headers={"origin": "https://evil.example"}) as ws:
            ws.receive_json()


def test_compare_datasets_parameter_sets(client):
    ids = []
    for ctrl in ("pid", "lqr"):
        j = wait(client, client.post("/api/v1/simulations", json={"config": {"mode": "edge", "controller": {"type": ctrl}, "duration_s": 3}}).json()["job"]["id"])
        ids.append(j["result_ref"]["id"])
    cmp = client.post("/api/v1/compare", json={"run_ids": ids}).json()
    assert cmp["controller_set"] is True and cmp["labels"][0]["key"] == "settle"
    ds = client.post("/api/v1/datasets", json={"title": "t", "run_ids": ids}).json()
    assert ds["status"] == "exploratory" and ds["provenance"]["source"] == "simulation"
    fin = client.post(f"/api/v1/datasets/{ds['id']}/finalize").json()
    assert fin["status"] == "final" and fin["finalized"]["content_hash"].startswith("sha256:")
    assert client.post(f"/api/v1/datasets/{ds['id']}/finalize").status_code == 409
    emb = client.get(f"/api/v1/datasets/{ds['id']}?embed=true").json()
    assert len(emb["runs"]) == 2
    # parameter sets: evidence is required per value; partial sets are not 'measured'
    bad = client.post("/api/v1/parameter-sets", json={"values": {"m": {"value": 1.9, "unit": "kg"}}})
    assert bad.status_code == 422
    ok = client.post("/api/v1/parameter-sets", json={"id": "bench-2026", "values": {"m": {"value": 1.9, "unit": "kg", "method": "scale", "date": "2026-09-01", "evidence": "lab notebook p. 12"}}}).json()
    assert ok["status"] == "partially-measured" and "params.a" in ok["missing"]     # v5: missing inputs are named by configuration path
    sets = client.get("/api/v1/parameter-sets").json()["parameter_sets"]
    assert sets[0]["id"] == "nominal-design-v1"


def test_sweep_row_endpoint_returns_the_exact_saved_configuration(client):
    """Every sampled value and resulting configuration is saved; a row can be retrieved with its configuration."""
    from aeris_backend.experiments.records import canonical_hash
    d = {"revision": "1.1", "seed_strategy": "paired", "base": {"mode": "edge"}, "mode": "montecarlo", "samples": 3, "seed": 9, "controllers": ["lqr", "nlpd"],
         "variables": [{"key": "tilt_deg", "min": 1, "max": 5, "dist": "bounded-normal", "mean": 3, "sd": 1},
                       {"path": "params.cv", "min": 0, "max": 2e-5, "dist": "uniform"}], "duration_s": 2}
    j = wait(client, client.post("/api/v1/sweeps", json={"sweep": d}).json()["job"]["id"])
    sid = j["result_ref"]["id"]
    sw = client.get(f"/api/v1/sweeps/{sid}").json()
    assert len(sw["rows"]) == 6
    for r in sw["rows"]:
        full = client.get(f"/api/v1/sweeps/{sid}/rows/{r['index']}").json()
        assert full["config_hash"] == r["config_hash"] == canonical_hash(full["config"])
        assert full["config"]["initial"]["tilt_deg"] == r["values"]["tilt_deg"] and full["config"]["params"]["cv"] == r["values"]["params.cv"]
        assert full["config"]["controller"]["type"] == r["controller"] and full["config"]["seed"] == r["seed"]
    # paired seeds: both controllers at a point share the noise seed
    by_point = {}
    for r in sw["rows"]:
        by_point.setdefault(r["point"], set()).add(r["seed"])
    assert all(len(s) == 1 for s in by_point.values())
    assert client.get(f"/api/v1/sweeps/{sid}/rows/999").status_code == 404
    assert client.get("/api/v1/sweeps/AERIS-SWP-999999/rows/0").status_code == 404


def test_parameter_sets_are_applied_and_labelled_honestly(client):
    """A stored parameter set is applied at its configuration paths; the record names the set and reports THIS run's
    coverage. v5 definition (stricter than v4): a run is MEASURED only when every model input it uses — mass, geometry,
    COM, inertia, wheels, sensor model and timing — comes from the set unchanged (docs/PARAMETERS.md). (Test-fixture values.)"""
    from aeris_backend.config.normalize import normalize
    from aeris_backend.constants import NOMINAL, PARAM_SPEC
    from aeris_backend.experiments.provenance import model_inputs, spec_of
    ev = {"method": "test fixture", "date": "2026-09-01", "evidence": "backend/tests (not a measurement)"}
    part = client.post("/api/v1/parameter-sets", json={"id": "test-partial", "values": {"m": dict(ev, value=1.85, unit=PARAM_SPEC["m"]["unit"])}}).json()
    assert part["status"] == "partially-measured" and part["revision"] == 2
    j = wait(client, client.post("/api/v1/simulations", json={"config": {"mode": "edge", "duration_s": 1}, "parameter_set": "test-partial"}).json()["job"]["id"])
    rec = client.get(f"/api/v1/runs/{j['result_ref']['id']}").json()
    assert rec["config"]["params"]["m"] == 1.85 and rec["validation"]["status"] == "nominal" and "covers 1 of" in rec["validation"]["note"] and "NOMINAL" in rec["validation"]["note"]
    ps = rec["reproduction"]["parameter_set"]
    assert ps["id"] == "test-partial" and ps["applied"] == ["params.m"] and ps["replaced"] == [{"param": "params.m", "config_value": NOMINAL["m"], "measured_value": 1.85}]
    assert ps["coverage"]["measured"] == ["params.m"] and "params.kJ" in ps["coverage"]["nominal"]
    # g is a constant, not a measured property
    g = client.post("/api/v1/parameter-sets", json={"id": "test-g", "values": {"g": dict(ev, value=9.81, unit="m/s²")}})
    assert g.status_code == 422 and "constant" in g.json()["error"]["details"][0]["message"]
    # a set covering every input of an edge run (ideal sensing) makes that run MEASURED
    cfg0, _ = normalize({"mode": "edge", "duration_s": 1})
    vals = {path: dict(ev, value=v, unit=spec_of(path)[0]) for path, v in model_inputs(cfg0).items()}
    full = client.post("/api/v1/parameter-sets", json={"id": "test-complete", "values": vals}).json()
    j2 = wait(client, client.post("/api/v1/simulations", json={"config": {"mode": "edge", "duration_s": 1}, "parameter_set": "test-complete"}).json()["job"]["id"])
    rec2 = client.get(f"/api/v1/runs/{j2['result_ref']['id']}").json()
    assert rec2["validation"]["status"] == "measured" and rec2["validation"]["parameter_set"] == "test-complete" and "measured on the physical cube" in rec2["provenance"]
    assert rec2["reproduction"]["parameter_set"]["coverage"]["nominal"] == [] and rec2["reproduction"]["parameter_set"]["coverage"]["overridden"] == []
    # the same set does not cover the sensor model: an MEKF run is NOMINAL and says which inputs are nominal
    j2b = wait(client, client.post("/api/v1/simulations", json={"config": {"mode": "edge", "duration_s": 1, "estimator": {"type": "cf3d"}}, "parameter_set": "test-complete"}).json()["job"]["id"])
    rec2b = client.get(f"/api/v1/runs/{j2b['result_ref']['id']}").json()
    assert rec2b["validation"]["status"] == "nominal" and "sensor.gyro_noise_dps" in rec2b["reproduction"]["parameter_set"]["coverage"]["nominal"]
    assert full["status"] == "partially-measured" and any(m.startswith("sensor.") for m in full["missing"])    # the set alone: no sensor model
    j3 = wait(client, client.post(f"/api/v1/runs/{rec2['id']}/reproduce").json()["job"]["id"])
    rec3 = client.get(f"/api/v1/runs/{j3['result_ref']['id']}").json()
    assert rec3["validation"]["parameter_set"] == "test-complete" and rec3["reproduction"]["reproduces"]["identical"] is True
    assert client.post("/api/v1/simulations", json={"config": {"mode": "edge"}, "parameter_set": "nope"}).status_code == 404
    # a sweep that varies a measured input overrides it: those rows are not measured, and the sweep says so
    sj = wait(client, client.post("/api/v1/sweeps", json={"parameter_set": "test-complete", "sweep": {"base": {"mode": "edge"}, "mode": "grid", "controllers": ["lqr"],
                                                                                                  "variables": [{"path": "params.cv", "min": 0, "max": 2e-5, "steps": 2}], "duration_s": 1}}).json()["job"]["id"])
    sw = client.get(f"/api/v1/sweeps/{sj['result_ref']['id']}").json()
    assert sw["provenance"]["parameter_set"]["id"] == "test-complete" and sw["provenance"]["validation"]["status"] == "nominal"
    assert "params.cv" in sw["provenance"]["validation"]["overridden_by_variables"]
    assert {r["parameters"]["status"] for r in sw["rows"]} <= {"partially-measured", "measured"}
    assert any(r["parameters"]["overridden"] == ["params.cv"] for r in sw["rows"])
    # immutable: the same id cannot be written twice; a new version names the one it supersedes
    again = client.post("/api/v1/parameter-sets", json={"id": "test-complete", "values": {"m": dict(ev, value=1.9, unit="kg")}})
    assert again.status_code == 409
    v2 = client.post("/api/v1/parameter-sets", json={"id": "test-complete-v2", "supersedes": "test-complete", "values": {"m": dict(ev, value=1.9, unit="kg")}}).json()
    assert v2["supersedes"] == "test-complete"
    assert client.get("/api/v1/parameter-sets/test-complete").json()["values"]["params.m"]["value"] == NOMINAL["m"]

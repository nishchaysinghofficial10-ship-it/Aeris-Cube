"""Research metric definitions, version 2 (review finding A): analytical fixtures, units by dimension,
the interval-weighting rule, early termination, time-step convergence and record versioning."""
import math

import pytest

from aeris_backend.constants import DEG
from aeris_backend.metrics.research import METRICS_VERSION, angle_stats, research_metrics, time_stats
from aeris_backend.simulation import simulate


def _ctx_from(base, dt, n_window):
    return {"mode": "edge", "dt": dt, "wheel_names": ["x", "y", "z"], "recovery": base["config"]["recovery"], "window_s": n_window * dt,
            "fellAt": None, "wmax_list": [w["wmax"] for w in base["wheels"]], "termination": base["termination"]}


def test_constant_one_degree_for_one_second_review_fixture():
    """The review's fixture: a constant 1° error for 1 s sampled every 0.1 s must give RMS 1°, IAE 1°·s, ISE 1°²·s
    (v4 gave IAE 1.1 and ISE 0.0191986)."""
    base = simulate({"mode": "edge", "duration_s": 1}, keep_full=True)
    full = base["full"]
    full["nSteps"] = 10
    full["e"] = [DEG] * 11
    A = research_metrics(full, _ctx_from(base, 0.1, 10))["attitude_error"]
    assert A["rms"] == pytest.approx(1.0, abs=1e-12)
    assert A["iae"] == pytest.approx(1.0, abs=1e-12)
    assert A["ise"] == pytest.approx(1.0, abs=1e-12)
    assert A["peak"] == pytest.approx(1.0) and A["final"] == pytest.approx(1.0) and A["duration_s"] == pytest.approx(1.0)


@pytest.mark.parametrize("c,T,dt", [(1.0, 1.0, 0.1), (2.5, 3.0, 0.002), (-4.0, 0.5, 0.001)])
def test_constant_signal_exact_for_any_step(c, T, dt):
    n = int(round(T / dt))
    s = angle_stats([c * DEG] * (n + 1), n, dt)
    assert s["rms"] == pytest.approx(abs(c), rel=1e-12)
    assert s["iae"] == pytest.approx(abs(c) * T, rel=1e-12)
    assert s["ise"] == pytest.approx(c * c * T, rel=1e-12)       # deg²·s: converted with DEG², not DEG


def test_units_follow_dimensions():
    """ISE converts with the square of the rad→deg factor, IAE and RMS with the factor itself."""
    n, dt = 50, 0.02
    x = [0.01 * math.sin(0.3 * k) for k in range(n + 1)]         # radians
    r = time_stats(x, n, dt)
    d = angle_stats(x, n, dt)
    assert d["iae"] == pytest.approx(r["iae"] / DEG, rel=1e-12)
    assert d["ise"] == pytest.approx(r["ise"] / DEG ** 2, rel=1e-12)
    assert d["rms"] == pytest.approx(r["rms"] / DEG, rel=1e-12)
    assert d["rms"] == pytest.approx(math.sqrt(d["ise"] / (n * dt)), rel=1e-12)


def test_n_intervals_get_n_weights_linear_signal_and_convergence():
    """x(t) = a·t on [0, T]: the trapezoidal IAE is exact (a·T²/2); ISE converges to a²T³/3 with error a²·T·dt²/6."""
    a, T = 2.0, 1.0
    errs = []
    for n in (10, 20, 40, 80):
        dt = T / n
        s = time_stats([a * k * dt for k in range(n + 1)], n, dt)
        assert s["iae"] == pytest.approx(a * T * T / 2, rel=1e-12)
        exact = a * a * T ** 3 / 3
        assert s["ise"] - exact == pytest.approx(a * a * T * dt * dt / 6, rel=1e-9)
        errs.append(s["ise"] - exact)
    for e1, e2 in zip(errs, errs[1:]):
        assert e1 / e2 == pytest.approx(4.0, rel=1e-9)             # second order


def test_early_termination_and_degenerate_cases():
    x = [1.0] * 101
    s = time_stats(x, 40, 0.01)                                     # only 40 of 100 intervals executed
    assert s["duration_s"] == pytest.approx(0.4) and s["iae"] == pytest.approx(0.4) and s["rms"] == pytest.approx(1.0)
    z = time_stats([3.0, 9.0], 0, 0.01)                             # nothing executed
    assert z == {"rms": 3.0, "iae": 0.0, "ise": 0.0, "peak": 3.0, "final": 3.0, "duration_s": 0.0}


def test_engine_metrics_converge_with_the_integration_step():
    """Same run at 500, 1000 and 2000 Hz integration (control at 500 Hz): the research integrals converge."""
    vals = []
    for hz in (500, 1000, 2000):
        r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "initial": {"tilt_deg": 3, "rate_dps": 10}, "duration_s": 3,
                      "solver": {"integration_hz": hz}})
        A = r["research"]["attitude_error"]
        vals.append((A["iae"], A["ise"], A["rms"]))
    d1 = [abs(a - b) for a, b in zip(vals[0], vals[1])]
    d2 = [abs(a - b) for a, b in zip(vals[1], vals[2])]
    for x, y, v in zip(d1, d2, vals[2]):
        assert y <= x + 1e-12 and y < 1e-2 * abs(v)


def test_run_record_carries_metric_version_units_and_definitions():
    from aeris_backend.experiments.records import build_record
    r = simulate({"mode": "edge", "duration_s": 1, "initial": {"tilt_deg": 2}})
    rec = build_record(r)
    assert rec["research"]["metrics_version"] == METRICS_VERSION == "2"
    assert rec["reproduction"]["metrics_version"] == "2"
    assert "trapezoidal" in rec["definitions"]["research"]["attitude_error"]
    assert rec["definitions"]["research_units"]["attitude_error.ise"] == "deg²·s"
    # the historical browser-parity metrics keep their own (unchanged) definition
    assert "rmsLean_deg" in rec["metrics"] and "rms" in rec["definitions"]["metrics"]

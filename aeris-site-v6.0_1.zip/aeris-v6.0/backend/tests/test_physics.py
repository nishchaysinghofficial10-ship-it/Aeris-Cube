"""Quaternion/frame conventions, mass properties, conservation laws, reaction torques, gravity,
gyroscopic coupling and RK4 accuracy against an independent high-accuracy reference.

Tolerances: conservation checks use the engine at 2 kHz and require relative drift < 1e-9 over
0.3 s; the RK4 convergence test requires an observed order between 3.6 and 4.4; the independent
reference (scipy DOP853, rtol 1e-12) must agree with the engine at 4 kHz to 1e-9 rad."""
import math

import numpy as np
import pytest
from scipy.integrate import solve_ivp

from aeris_backend.constants import CH, D_EDGE, DEG, QEQ, RPM
from aeris_backend.physics import quaternion as Q
from aeris_backend.physics.mass import check_tensor, mass_properties, steiner
from aeris_backend.config.normalize import normalize
from conftest import const_torque, engine_for


# ---------------------------------------------------------------- quaternion conventions
def test_quaternion_rotation_maps_body_to_world():
    q = Q.axis_angle((0, 0, 1), math.pi / 2)            # +90° about z
    R = Q.rot(q)
    assert np.allclose(Q.mv(R, (1, 0, 0)), (0, 1, 0), atol=1e-15)   # body x points along world y
    assert np.allclose(Q.up_in_body(q), Q.mtv(R, (0, 0, 1)))


def test_sign_ambiguity_same_attitude():
    q = Q.qnorm((0.3, -0.5, 0.2, 0.7))
    mq = tuple(-x for x in q)
    assert np.allclose(Q.rot(q), Q.rot(mq))
    assert Q.angle_between(q, mq) == pytest.approx(0.0, abs=1e-7)
    assert np.allclose(Q.log_vec(q), Q.log_vec(mq))


def test_exp_log_roundtrip_and_short_way():
    phi = (0.3, -0.2, 0.5)
    assert np.allclose(Q.log_vec(Q.exp_vec(phi)), phi, atol=1e-12)
    big = Q.axis_angle((1, 0, 0), 1.9 * math.pi)        # 342°: the short way is −18°
    assert np.allclose(Q.log_vec(big), (-0.1 * math.pi, 0, 0), atol=1e-12)


def test_qeq_puts_the_diagonal_vertical():
    assert np.allclose(Q.up_in_body(QEQ), CH, atol=1e-12)
    assert np.allclose(Q.up_in_body(Q.edge_quat(0.0)), D_EDGE, atol=1e-12)


def test_kinematics_qdot_matches_body_rate():
    q = Q.qnorm((0.9, 0.1, -0.2, 0.3))
    w = (0.4, -0.7, 1.1)
    dt = 1e-6
    q2 = Q.qnorm(Q.qmul(q, Q.exp_vec((w[0] * dt, w[1] * dt, w[2] * dt))))
    qd = Q.qmul(q, (0, *w))
    assert np.allclose([(a - b) / dt for a, b in zip(q2, q)], [x / 2 for x in qd], atol=1e-5)


# ---------------------------------------------------------------- mass properties
def test_parallel_axis_and_combination():
    cfg, _ = normalize({"mode": "corner", "attachments": [{"mass_kg": 0.1, "pos_m": [0.18, 0.0, 0.09]}],
                        "plant": {"components": [{"mass_kg": 0.2, "com_m": [0.05, 0.12, 0.03], "inertia_kgm2": [[1e-4, 2e-5, 0], [2e-5, 3e-4, 0], [0, 0, 2e-4]]}]}})
    mp = mass_properties(cfg)
    a, m = cfg["params"]["a"], cfg["params"]["m"]
    r0 = np.array([a / 2] * 3)
    Ic = np.array([[1e-4, 2e-5, 0], [2e-5, 3e-4, 0], [0, 0, 2e-4]])
    expected = (cfg["params"]["kJ"] * m * a * a * np.eye(3) + steiner(m, r0) + Ic + steiner(0.2, [0.05, 0.12, 0.03]) + steiner(0.1, [0.18, 0, 0.09]))
    assert np.allclose(mp["ThO"], expected, rtol=1e-14)
    M = m + 0.3
    rc = (m * r0 + 0.2 * np.array([0.05, 0.12, 0.03]) + 0.1 * np.array([0.18, 0, 0.09])) / M
    assert mp["M"] == pytest.approx(M)
    assert np.allclose(mp["rc"], rc)
    # inertia about the COM (ThC) is ThO minus the Steiner term of the total mass
    assert np.allclose(mp["ThC"], np.array(mp["ThO"]) - steiner(M, rc))
    # off-diagonal products of inertia are kept
    assert abs(mp["ThO"][0][1]) > 1e-4


def test_tensor_checks():
    assert check_tensor(np.diag([1, 2, 2.5]), "I") == []
    assert check_tensor([[1, 0.1, 0], [0, 1, 0], [0, 0, 1]], "I")[0].endswith("not symmetric (largest asymmetry 0.1 kg·m²).")
    assert "positive definite" in check_tensor(np.diag([1, -1, 1]), "I")[0]
    assert "triangle inequality" in check_tensor(np.diag([1, 1, 3]), "I")[0]


def test_validation_rejects_bad_component_tensor():
    v = __import__("aeris_backend.config.validate", fromlist=["validate_config"]).validate_config(
        {"mode": "corner", "plant": {"components": [{"mass_kg": 0.1, "com_m": [0.1, 0.1, 0.1], "inertia_kgm2": [[1, 0, 0], [0, 1, 0], [0, 0, 3]]}]}})
    assert not v.ok and any("triangle" in e["message"] for e in v.errors)


# ---------------------------------------------------------------- conservation (g = 0, no friction)
def H_world(S, i, eng):
    q = [S[f"q{j}"][i] for j in range(4)]
    w = np.array([S["wx"][i], S["wy"][i], S["wz"][i]])
    Om = [S["omega_x"][i], S["omega_y"][i], S["omega_z"][i]]
    Th0 = np.array(eng.design["plant"]["Th0"])
    Hb = Th0 @ w + sum(wh.Jw * Om[k] * np.array(wh.axis) for k, wh in enumerate(eng.wheels.wheels))
    return np.array(Q.rot(q)) @ Hb


def kinetic(S, i, eng):
    w = np.array([S["wx"][i], S["wy"][i], S["wz"][i]])
    Om = [S["omega_x"][i], S["omega_y"][i], S["omega_z"][i]]
    Thh = np.array(eng.design["plant"]["Thh"])
    # T = ½ωᵀΘ̂ω + ½ Σ J (a·ω + Ω)²  (body with wheels locked minus spin part, plus wheel spin)
    return 0.5 * w @ Thh @ w + 0.5 * sum(wh.Jw * (np.dot(wh.axis, w) + Om[k]) ** 2 for k, wh in enumerate(eng.wheels.wheels))


FREE = {"mode": "corner", "controller": {"type": "none"}, "params": {"cv": 0, "cc": 0}, "initial": {"tilt_deg": 3, "rate_dps": 20, "azimuth_deg": 30,
        "wheel_speeds_rpm": [3000, -1500, 800]}, "duration_s": 0.5, "record_hz": 500, "solver": {"integration_hz": 2000},
        "termination": {"check_lift_off": False}}


def test_torque_free_body_conserves_momentum_and_energy():
    eng = engine_for(FREE, g=0.0)
    res = eng.run()
    assert eng.termination["reason"] == "duration"
    S = res["samples"]["cols"]
    H0 = H_world(S, 0, eng)
    K0 = kinetic(S, 0, eng)
    n = len(S["t"])
    for i in range(1, n):
        assert np.linalg.norm(H_world(S, i, eng) - H0) / np.linalg.norm(H0) < 1e-9
        assert abs(kinetic(S, i, eng) - K0) / K0 < 1e-9


def test_motor_torque_is_equal_and_opposite():
    """A motor torque only exchanges momentum between wheel and body: total H stays 0."""
    raw = dict(FREE, initial={"tilt_deg": 0, "rate_dps": 0, "azimuth_deg": 0})
    eng = engine_for(raw, g=0.0, controller=const_torque((0.02, -0.01, 0.005)))
    S = eng.run()["samples"]["cols"]
    assert eng.termination["reason"] == "duration" and S["t"][-1] == pytest.approx(0.5)
    for i in range(len(S["t"])):
        assert np.linalg.norm(H_world(S, i, eng)) < 1e-12
    # the wheels spun up in the direction of their torque, the body the other way
    assert S["omega_x"][-1] > 0 and S["omega_y"][-1] < 0 and S["omega_z"][-1] > 0


def test_edge_hinge_motor_reaction():
    raw = {"mode": "edge", "controller": {"type": "none"}, "params": {"cv": 0, "cc": 0}, "initial": {"tilt_deg": 0}, "duration_s": 0.2, "record_hz": 500}
    eng = engine_for(raw, g=0.0, controller=const_torque((0.01, 0, 0)))
    S = eng.run()["samples"]["cols"]
    assert eng.termination["reason"] == "duration" and S["t"][-1] == pytest.approx(0.2)
    Thh = eng.design["plant"]["Thh"]
    Jw = eng.wheels.wheels[0].Jw
    Th0 = Thh + Jw
    for i in range(len(S["t"])):
        # hinge momentum Θ₀θ̇ + J_w Ω stays zero
        assert abs(Th0 * S["thetadot"][i] + Jw * S["omega_x"][i]) < 1e-14
    # θ̈ = −T/Θ̂ exactly (no gravity): θ̇(t) = −T t/Θ̂
    t = S["t"][-1]
    assert S["thetadot"][-1] == pytest.approx(-0.01 * t / Thh, rel=1e-9)


# ---------------------------------------------------------------- gravity
def test_balance_attitude_is_an_equilibrium_and_small_tilt_diverges_at_lambda():
    raw = {"mode": "corner", "controller": {"type": "none"}, "initial": {"tilt_deg": 0, "reference": "balance"}, "duration_s": 0.4, "record_hz": 500}
    S = engine_for(raw).run()["samples"]["cols"]
    assert max(S["e"]) < 1e-12
    raw2 = dict(raw, initial={"tilt_deg": 0.01, "reference": "balance"})
    eng = engine_for(raw2)
    S2 = eng.run()["samples"]["cols"]
    lam = eng.design["plant"]["lambda"]
    # e(t) ≈ e0 cosh(λ_axis t); λ uses the smallest eigenvalue, so the growth is at most cosh(λ t)
    ratio = S2["e"][-1] / S2["e"][0]
    assert 1.5 < ratio <= math.cosh(lam * S2["t"][-1]) * 1.001


def test_gravity_torque_sign_edge():
    raw = {"mode": "edge", "controller": {"type": "none"}, "initial": {"tilt_deg": 1.0}, "duration_s": 0.1, "record_hz": 500}
    S = engine_for(raw).run()["samples"]["cols"]
    assert S["tauG"][0] > 0 and S["thetadot"][5] > 0           # tilting positive falls further positive
    raw["initial"] = {"tilt_deg": -1.0}
    S = engine_for(raw).run()["samples"]["cols"]
    assert S["tauG"][0] < 0 and S["thetadot"][5] < 0


def test_gyroscopic_cross_coupling():
    """Spinning wheel z + body rate about x ⇒ angular acceleration about y (ω × H)."""
    raw = dict(FREE, initial={"tilt_deg": 0, "rate_dps": 0, "azimuth_deg": 0, "wheel_speeds_rpm": [0, 0, 5000]})
    eng = engine_for(raw, g=0.0)
    eng.cfg["initial"]["rate_dps"] = 0
    res = eng.run()
    S = res["samples"]["cols"]
    # no rate initially → nothing happens
    assert max(abs(x) for x in S["wy"]) < 1e-15
    # now with a body rate: compare the first-step angular acceleration with the formula
    raw2 = dict(raw, duration_s=0.01, record_hz=1000, solver={"integration_hz": 20000})
    eng2 = engine_for(raw2, g=0.0)
    from aeris_backend.simulation.setup import initial_state
    ini = initial_state(eng2.cfg, eng2.mp)
    w0 = np.array([0.2, 0.0, 0.0])
    eng2_ini = dict(ini, w=tuple(w0))
    import aeris_backend.simulation.engine as E
    orig = E.initial_state
    E.initial_state = lambda cfg, mp: eng2_ini
    try:
        S2 = eng2.run()["samples"]["cols"]
    finally:
        E.initial_state = orig
    Th0 = np.array(eng2.design["plant"]["Th0"])
    Thh = np.array(eng2.design["plant"]["Thh"])
    H = Th0 @ w0 + eng2.wheels.wheels[2].Jw * 5000 * RPM * np.array([0, 0, 1])
    wd_expected = np.linalg.solve(Thh, -np.cross(w0, H))
    dt = S2["t"][1] - S2["t"][0]
    wd_num = (np.array([S2["wx"][1], S2["wy"][1], S2["wz"][1]]) - w0) / dt
    assert abs(wd_expected[1]) > 0.1
    # forward difference over one 1-ms recording interval: agreement to 1 % (the derivative
    # changes within the interval); sign and magnitude of the coupling are what is tested here
    assert np.allclose(wd_num, wd_expected, rtol=1e-2, atol=1e-6)
    assert np.sign(wd_num[1]) == np.sign(wd_expected[1])


# ---------------------------------------------------------------- RK4 accuracy
def reference_rhs(eng):
    """Independent implementation of the documented corner equations (docs/PHYSICS.md §3)."""
    Th0 = np.array(eng.design["plant"]["Th0"])
    Thh = np.array(eng.design["plant"]["Thh"])
    M, rc, g = eng.design["plant"]["M"], np.array(eng.design["plant"]["rc"]), eng.cfg["params"]["g"]
    A = np.array([w.axis for w in eng.wheels.wheels]).T
    J = np.array([w.Jw for w in eng.wheels.wheels])
    cv = np.array([w.cv for w in eng.wheels.wheels])
    cc = np.array([w.cc for w in eng.wheels.wheels])

    def f(t, x):
        q, w, Om = x[:4] / np.linalg.norm(x[:4]), x[4:7], x[7:]
        R = np.array(Q.rot(tuple(q)))
        gB = R.T @ np.array([0, 0, -g])
        fr = cv * Om + cc * np.tanh(Om)
        H = Th0 @ w + A @ (J * Om)
        rhs = -np.cross(w, H) + M * np.cross(rc, gB) - A @ (-fr)
        wd = np.linalg.solve(Thh, rhs)
        Omd = -fr / J - A.T @ wd
        qd = 0.5 * np.array(Q.qmul(tuple(q), (0, *w)))
        return np.concatenate([qd, wd, Omd])
    return f


def test_rk4_against_high_accuracy_reference_and_order():
    base = {"mode": "corner", "controller": {"type": "none"}, "initial": {"tilt_deg": 2, "rate_dps": 10, "azimuth_deg": 20, "wheel_speeds_rpm": [800, -300, 200]},
            "duration_s": 0.25, "record_hz": 20, "termination": {"check_lift_off": False}}
    errs = {}
    ref = None
    for f_int in (500, 1000, 2000, 4000):
        eng = engine_for(dict(base, solver={"integration_hz": f_int}))
        res = eng.run()
        S = res["samples"]["cols"]
        if ref is None:
            from aeris_backend.simulation.setup import initial_state
            ini = initial_state(eng.cfg, eng.mp)
            x0 = np.concatenate([ini["q"], ini["w"], np.array([800, -300, 200]) * RPM])
            sol = solve_ivp(reference_rhs(eng), (0, 0.25), x0, method="DOP853", rtol=1e-12, atol=1e-14)
            ref = sol.y[:, -1]
        qe = np.array([S[f"q{j}"][-1] for j in range(4)])
        errs[f_int] = abs(np.linalg.norm(qe - ref[:4] / np.linalg.norm(ref[:4])))
    orders = [math.log2(errs[a] / errs[b]) for a, b in ((500, 1000), (1000, 2000))]
    assert all(3.6 < o < 4.4 for o in orders), (errs, orders)
    assert errs[4000] < 1e-9


def test_recording_rate_does_not_change_the_trajectory_or_metrics():
    base = {"mode": "corner", "controller": {"type": "lqr"}, "initial": {"tilt_deg": 4, "rate_dps": 15, "azimuth_deg": 40}, "duration_s": 3}
    from aeris_backend.simulation import simulate
    a = simulate(dict(base, record_hz=10))
    b = simulate(dict(base, record_hz=100))
    assert a["metrics"] == b["metrics"]
    assert a["research"] == b["research"]
    # the 10 Hz rows are a subset of the 100 Hz rows, value for value
    for k in ("q0", "wx", "omega_z", "T_y"):
        assert a["samples"]["cols"][k][:-1] == b["samples"]["cols"][k][:-1:10]

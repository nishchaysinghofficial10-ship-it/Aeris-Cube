"""The read-only legacy export audit follows lineage transitively (v6, review finding V52-4 of v5.2).

Fixtures: the reviewer's chain (ORIGINAL → COPY_1 → COPY_2, produced with the actual v5.1 code) and the chains in
fixtures/legacy_export_chains_v51.json, also produced with the actual v5.1 implementation by
tools/make_legacy_export_fixtures.py (ms/deg original with three legacy generations, a wire-unit control, an omega_*
recording). Newer generations are made here with the CURRENT export and recorder. All data are SYNTHETIC fixtures."""
from __future__ import annotations

import copy
import json
import os
import subprocess
import sys

import pytest

from aeris_backend.storage.sqlite import SqliteRepository
from aeris_backend.telemetry.stream import TelemetryHub, recording_to_ndjson
from aeris_backend.tools.dbtool import export_audit

HERE = os.path.dirname(os.path.abspath(__file__))
REVIEW = json.load(open(os.path.join(HERE, "fixtures", "review_v52_export_audit_chain.json"), encoding="utf-8"))
V51 = json.load(open(os.path.join(HERE, "fixtures", "legacy_export_chains_v51.json"), encoding="utf-8"))["chains"]
MS = V51["ms-deg"]


def current_copy(doc: dict, rid: str, name: str) -> dict:
    """Export with the current code (v6) and record the replay with the current hub."""
    hub = TelemetryHub()
    hub.on_connect({"kind": "file", "address": name + ".ndjson"}, 0.0)
    for i, line in enumerate(recording_to_ndjson(doc, rid).splitlines()):
        r = hub.feed_line(line, i * 0.01)
        assert r in ("hello", "frame", "bye"), (r, line[:100])
        if r == "hello" and hub.recording is None:
            hub.start_recording("SYNTHETIC audit fixture " + name, 0.0)
    return hub.stop_recording(5.0)


def make_db(tmp_path, docs: dict, name="audit.sqlite3"):
    db = str(tmp_path / name)
    repo = SqliteRepository(db)
    try:
        for rid, doc in docs.items():
            assert repo.put_new("recordings", rid, {"document": doc}, name=rid)
    finally:
        repo.close()
    return db


def run_audit(db):
    """The database file is byte-identical afterwards. (SQLite may create the empty -wal/-shm companions of a WAL database
    when it is opened read-only; the -wal must stay empty: nothing was written.)"""
    before = open(db, "rb").read()
    a = export_audit(db)
    assert open(db, "rb").read() == before, "the audit changed the database file"
    if os.path.exists(db + "-wal"):
        assert os.path.getsize(db + "-wal") == 0, "the audit wrote to the write-ahead log"
    return a


def ids(a, key):
    return {x["id"]: x for x in a[key]}


def test_the_reviewers_chain_second_generation_is_found(tmp_path):
    a = run_audit(make_db(tmp_path, REVIEW))
    assert [o["id"] for o in a["originals_whose_v5_v51_ndjson_export_was_wrong"]] == ["ORIGINAL"]
    aff = ids(a, "affected")
    assert set(aff) == {"COPY_1", "COPY_2"}
    assert aff["COPY_2"]["chain"] == ["COPY_2", "COPY_1", "ORIGINAL"] and aff["COPY_2"]["original"] == "ORIGINAL"
    assert any("ms" in i for i in aff["COPY_2"]["issues_of_the_original"])
    assert {c["id"] for c in a["copies_recorded_from_such_an_export"]} == {"COPY_1", "COPY_2"}     # the v5.2 key, now complete
    assert a["unresolved"] == [] and a["read_only"] is True and a["limits"]


def test_three_legacy_generations_and_the_unaffected_control(tmp_path):
    docs = dict(MS, **V51["wire"], **V51["omega"])
    a = run_audit(make_db(tmp_path, docs))
    aff = ids(a, "affected")
    assert set(aff) == {"ORIG-MS-DEG-V51-COPY-1", "ORIG-MS-DEG-V51-COPY-2", "ORIG-MS-DEG-V51-COPY-3", "ORIG-OMEGA-V51-COPY-1"}
    assert [len(aff[f"ORIG-MS-DEG-V51-COPY-{g}"]["chain"]) for g in (1, 2, 3)] == [2, 3, 4]
    assert aff["ORIG-MS-DEG-V51-COPY-3"]["chain"][-1] == "ORIG-MS-DEG"
    assert any("omega_x" in i and "left out" in i for i in aff["ORIG-OMEGA-V51-COPY-1"]["issues_of_the_original"])
    origs = {o["id"] for o in a["originals_whose_v5_v51_ndjson_export_was_wrong"]}
    assert origs == {"ORIG-MS-DEG", "ORIG-OMEGA"}                         # the wire-unit original is not listed
    assert a["clear_copies"] == 2                                         # the wire-unit control's two copies
    assert a["unresolved"] == []


def test_v52_and_later_descendants_of_a_corrupted_copy_stay_affected_and_a_fresh_export_of_the_original_is_clear(tmp_path):
    docs = dict(MS)
    docs["DESC-V6-1"] = current_copy(MS["ORIG-MS-DEG-V51-COPY-1"], "ORIG-MS-DEG-V51-COPY-1", "DESC-V6-1")
    docs["DESC-V6-2"] = current_copy(docs["DESC-V6-1"], "DESC-V6-1", "DESC-V6-2")
    docs["FRESH-V6"] = current_copy(MS["ORIG-MS-DEG"], "ORIG-MS-DEG", "FRESH-V6")
    # the fresh export converted the original's units: the copy really holds seconds and radians
    assert docs["FRESH-V6"]["samples"]["cols"]["t"][1] == pytest.approx(0.1)
    a = run_audit(make_db(tmp_path, docs))
    aff = ids(a, "affected")
    assert aff["DESC-V6-1"]["chain"] == ["DESC-V6-1", "ORIG-MS-DEG-V51-COPY-1", "ORIG-MS-DEG"] and aff["DESC-V6-1"]["export"] == "v5.2+"
    assert aff["DESC-V6-2"]["chain"][:2] == ["DESC-V6-2", "DESC-V6-1"]
    assert "FRESH-V6" not in aff and "FRESH-V6" not in ids(a, "unresolved")
    assert a["clear_copies"] == 1


def test_a_missing_intermediate_is_bridged_by_the_lineage_the_copy_recorded(tmp_path):
    docs = {k: v for k, v in MS.items() if k != "ORIG-MS-DEG-V51-COPY-1"}
    a = run_audit(make_db(tmp_path, docs))
    aff = ids(a, "affected")
    assert set(aff) == {"ORIG-MS-DEG-V51-COPY-2", "ORIG-MS-DEG-V51-COPY-3"}
    c2 = aff["ORIG-MS-DEG-V51-COPY-2"]
    assert c2["chain"] == ["ORIG-MS-DEG-V51-COPY-2", "ORIG-MS-DEG-V51-COPY-1", "ORIG-MS-DEG"]
    assert c2["missing_intermediates"] == ["ORIG-MS-DEG-V51-COPY-1"] and "inferred" in c2["how"]
    assert aff["ORIG-MS-DEG-V51-COPY-3"]["original"] == "ORIG-MS-DEG"


def test_a_missing_original_is_unresolved_risk_never_clear(tmp_path):
    docs = {k: v for k, v in MS.items() if k != "ORIG-MS-DEG"}
    a = run_audit(make_db(tmp_path, docs))
    un = ids(a, "unresolved")
    assert set(un) == {"ORIG-MS-DEG-V51-COPY-1", "ORIG-MS-DEG-V51-COPY-2", "ORIG-MS-DEG-V51-COPY-3"}
    assert "ORIG-MS-DEG" in un["ORIG-MS-DEG-V51-COPY-1"]["missing"]
    assert a["affected"] == [] and a["clear_copies"] == 0


def test_a_v52_descendant_behind_a_missing_corrupted_intermediate_is_unresolved_when_versions_are_unknown(tmp_path):
    desc = current_copy(MS["ORIG-MS-DEG-V51-COPY-1"], "ORIG-MS-DEG-V51-COPY-1", "DESC")
    a = run_audit(make_db(tmp_path, {"ORIG-MS-DEG": MS["ORIG-MS-DEG"], "DESC": desc}))
    un = ids(a, "unresolved")
    assert "DESC" in un and "cannot be decided" in " ".join(un["DESC"]["reasons"]) and un["DESC"]["missing"] == ["ORIG-MS-DEG-V51-COPY-1"]


def test_cycles_terminate_and_are_reported(tmp_path):
    a1 = copy.deepcopy(MS["ORIG-MS-DEG-V51-COPY-1"])
    b1 = copy.deepcopy(MS["ORIG-MS-DEG-V51-COPY-1"])
    for d, parent in ((a1, "CYC-B"), (b1, "CYC-A")):
        for lin in d["provenance"]["lineage"]:
            lin["derived_from"] = parent
        for h in d["provenance"]["hellos"]:
            h["lineage"]["derived_from"] = parent
        for s in d["provenance"]["segments"]:
            s["hello"]["lineage"]["derived_from"] = parent
    a = run_audit(make_db(tmp_path, {"CYC-A": a1, "CYC-B": b1}))
    un = ids(a, "unresolved")
    assert set(un) == {"CYC-A", "CYC-B"} and a["cycles"]
    assert any("cycle" in r for r in un["CYC-A"]["reasons"])


def test_ambiguous_and_duplicate_references(tmp_path):
    o1, o2 = copy.deepcopy(MS["ORIG-MS-DEG"]), copy.deepcopy(MS["ORIG-MS-DEG"])
    o1["recording"]["notes"] = o2["recording"]["notes"] = "the same notes"
    amb = copy.deepcopy(MS["ORIG-MS-DEG-V51-COPY-1"])
    for lin in amb["provenance"]["lineage"]:
        lin["derived_from"] = "the same notes"                           # an export made without a recording id names the notes
    for h in amb["provenance"]["hellos"]:
        h["lineage"]["derived_from"] = "the same notes"
    for s in amb["provenance"]["segments"]:
        s["hello"]["lineage"]["derived_from"] = "the same notes"
    dup = copy.deepcopy(MS["ORIG-MS-DEG-V51-COPY-1"])
    dup["provenance"]["lineage"] = dup["provenance"]["lineage"] * 3      # the same reference three times
    a = run_audit(make_db(tmp_path, {"O1": o1, "O2": o2, "AMB": amb, "ORIG-MS-DEG": MS["ORIG-MS-DEG"], "DUP": dup}))
    un = ids(a, "unresolved")
    assert "AMB" in un and un["AMB"]["ambiguous"] == {"the same notes": ["O1", "O2"]}
    assert [x["id"] for x in a["affected"]].count("DUP") == 1


def test_a_v5_replay_of_the_stored_recording_is_followed(tmp_path):
    v5copy = copy.deepcopy(MS["ORIG-MS-DEG-V51-COPY-1"])
    prov = v5copy["provenance"]
    prov.pop("lineage", None)
    for h in prov["hellos"]:
        h.pop("lineage", None)
    for s in prov["segments"]:
        s["hello"].pop("lineage", None)
    prov["transport"] = {"kind": "file", "address": "recording:ORIG-MS-DEG"}
    a = run_audit(make_db(tmp_path, {"ORIG-MS-DEG": MS["ORIG-MS-DEG"], "V5COPY": v5copy}))
    assert ids(a, "affected")["V5COPY"]["chain"] == ["V5COPY", "ORIG-MS-DEG"]


def test_the_command_line_reports_and_changes_nothing(tmp_path):
    db = make_db(tmp_path, REVIEW)
    before = open(db, "rb").read()
    r = subprocess.run([sys.executable, "-m", "aeris_backend.tools.dbtool", "export-audit", "--db", db], capture_output=True, text=True,
                       cwd=os.path.dirname(HERE))
    assert r.returncode == 0, r.stderr
    out = json.loads(r.stdout)
    assert out["schema"] == "aeris-export-audit/2" and {x["id"] for x in out["affected"]} == {"COPY_1", "COPY_2"}
    assert open(db, "rb").read() == before

"""NDJSON export in the protocol's wire units (v5.2, review finding G1 of v5.1; docs/TELEMETRY.md §6).

v5.1 copied stored sample values into frames without reading samples.units: an import in ms / deg / deg/s was
streamed as s / rad / rad/s and re-recorded under those labels. Here every accepted unit of every exported signal
goes API import → NDJSON export → an actual replay (the backend's file replay through /telemetry/connect, or the
FileReplaySource transport in-process) → a new recording, and the PHYSICAL values and time intervals of the copy are
compared with the original (in SI, through the importer's own conversion), row by row, matched by sequence number.
Columns already in the wire unit must come back bit for bit (identity controls). Inputs the stream cannot carry are
HTTP 422 with the column — never HTTP 500, a silent omission or a relabelled value. All data here is SYNTHETIC
(generated in the test); nothing is a measurement."""
from __future__ import annotations

import asyncio
import copy
import json
import math
import time

import pytest
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app
from aeris_backend.experiments.records import canonical_hash
from aeris_backend.hardware.ingest import UNITS as F, validate_recording
from aeris_backend.telemetry.export import ExportError, check_replayable, recording_to_ndjson, wire_plan
from aeris_backend.telemetry.protocol import UNITS as WIRE, validate_frame, validate_hello
from aeris_backend.telemetry.stream import STATUS_CODES, TelemetryHub
from aeris_backend.telemetry.transport import FileReplaySource

RATE, N = 50.0, 60
REL = 1e-12            # converted values: the importer's factor applied once more than the exact value (a few ulps)


# ---------------------------------------------------------------- synthetic truth (SI; wheel speed in rpm)
def truth(n=N, rate=RATE):
    T = {"t": [i / rate for i in range(n)], "theta": [0.05 * math.sin(i / 9) for i in range(n)]}
    ax = [1 / math.sqrt(14), 2 / math.sqrt(14), 3 / math.sqrt(14)]
    T["q"] = [[math.cos(a / 2)] + [math.sin(a / 2) * c for c in ax] for a in (0.1 * math.sin(i / 11) for i in range(n))]
    T["w"] = [[0.3 * math.sin(i / 7), -0.2 * math.cos(i / 5), 0.1 * math.sin(i / 3)] for i in range(n)]
    T["wheel_rpm"] = [[1500.0 + 10 * i, -800.0 + 5 * i, 300 * math.sin(i / 4)] for i in range(n)]
    T["torque_cmd"] = [[0.02 * math.sin(i / 6), 0.01 * math.cos(i / 6), -0.015 * math.sin(i / 8)] for i in range(n)]
    T["torque_meas"] = [[0.019 * math.sin(i / 6), 0.011 * math.cos(i / 6), -0.014 * math.sin(i / 8)] for i in range(n)]
    T["imu.gyro"] = [[x + 0.001 for x in w] for w in T["w"]]
    T["imu.accel"] = [[0.1 * math.sin(i / 5), 0.05 * math.cos(i / 5), 9.80665 + 0.01 * math.sin(i / 3)] for i in range(n)]
    T["status"] = ["ok" if i % 10 else ("idle" if i % 20 else "calibrating") for i in range(n)]
    return T


FAMILY = {"t": "time", "theta": "angle", "q": "unitless", "w": "rate", "imu.gyro": "rate", "imu.accel": "accel", "wheel_rpm": "wheel",
          "torque_cmd": "torque", "torque_meas": "torque", "seq": "count", "status": "count"}
COLS = {"w": ["w_x", "w_y", "w_z"], "imu.gyro": ["gyro_x", "gyro_y", "gyro_z"], "imu.accel": ["accel_x", "accel_y", "accel_z"],
        "torque_cmd": ["torque_cmd_x", "torque_cmd_y", "torque_cmd_z"], "torque_meas": ["torque_meas_x", "torque_meas_y", "torque_meas_z"],
        "wheel_rpm": ["wheel_rpm_x", "wheel_rpm_y", "wheel_rpm_z"], "omega": ["omega_x", "omega_y", "omega_z"], "q": ["q0", "q1", "q2", "q3"]}


def wire_truth(T, field, i):
    """The value a frame must carry (wire units: SI, wheel speed in rpm)."""
    return T[field][i]


def stored(x, fam, unit, wire_unit):
    """A truth value (in the wire unit) expressed in `unit`, as a source would store it."""
    return x * F[fam][wire_unit] / F[fam][unit] if F[fam][unit] != F[fam][wire_unit] else x


def make_doc(units: dict, *, mode="corner", seq=True, n=N, notes="SYNTHETIC unit-conversion fixture (test only)", wheel_cols="wheel_rpm", status=True):
    """An aeris-hardware-run/1 document whose columns hold the truth in the requested units.
    units: wire field → unit, or wire field → [unit per axis] (mixed units inside one vector)."""
    T = truth(n)
    cols, u = {}, {}
    for field, unit in units.items():
        fam = FAMILY[field]
        names = [field] if field in ("t", "theta") else COLS["omega" if field == "wheel_rpm" and wheel_cols == "omega" else field]
        per = unit if isinstance(unit, list) else [unit] * len(names)
        for j, (c, uu) in enumerate(zip(names, per)):
            vals = T[field] if len(names) == 1 else [row[j] for row in T[field]]
            cols[c] = [stored(x, fam, uu, WIRE[field]) for x in vals]
            u[c] = uu
    if seq:
        cols["seq"], u["seq"] = list(range(100, 100 + n)), "count"
    prov = {}
    if status:
        cols["status"], u["status"] = [STATUS_CODES[s] for s in T["status"]], "count"
        prov["status_codes"] = dict(STATUS_CODES)
    doc = {"schema": "aeris-hardware-run/1", "synthetic": True, "device": {"id": "unit-fixture", "firmware": "test-only"},
           "recording": {"started": "2026-10-01T00:00:00Z", "notes": notes}, "mode": mode, "parameters": {"parameter_set": "nominal-design-v1"},
           "samples": {"rate_hz": RATE, "cols": cols, "units": u}}
    if prov:
        doc["provenance"] = prov
    assert validate_recording(doc)["ok"], validate_recording(doc)["errors"]
    return doc


SI_FIELDS = ("w", "imu.gyro", "imu.accel", "torque_cmd", "torque_meas", "wheel_rpm")
FULL = {"t": "s", "q": "–", "w": "rad/s", "wheel_rpm": "rpm", "torque_cmd": "N·m", "torque_meas": "N·m", "imu.gyro": "rad/s", "imu.accel": "m/s²"}
# every accepted unit of every exported signal (ingest.UNITS), one profile per unit family member
PROFILES = {
    "wire units (identity control)": (FULL, "corner", "wheel_rpm"),
    "wire-unit aliases (identity control)": ({"t": "s", "q": "1", "w": "rad/s", "wheel_rpm": "rpm", "torque_cmd": "N*m", "torque_meas": "Nm",
                                              "imu.gyro": "rad/s", "imu.accel": "m/s^2"}, "corner", "wheel_rpm"),
    "unitless aliases '-' and ''": ({"t": "s", "q": ["-", "", "–", "1"], "w": "rad/s"}, "corner", "wheel_rpm"),
    "ms, deg, deg/s (edge)": ({"t": "ms", "theta": "deg", "w": "deg/s", "imu.gyro": "deg/s"}, "edge", "wheel_rpm"),
    "degree sign units (edge)": ({"t": "ms", "theta": "°", "w": "°/s", "imu.gyro": "°/s"}, "edge", "wheel_rpm"),
    "wheel speed omega_* in rad/s": ({"t": "s", "q": "–", "wheel_rpm": "rad/s"}, "corner", "omega"),
    "wheel speed omega_* in rpm": ({"t": "s", "q": "–", "wheel_rpm": "rpm"}, "corner", "omega"),
    "wheel_rpm_* stored in rad/s": ({"t": "s", "q": "–", "wheel_rpm": "rad/s"}, "corner", "wheel_rpm"),
    "milli-newton-metres and g": ({"t": "ms", "q": "–", "torque_cmd": "mN·m", "torque_meas": "mNm", "imu.accel": "g"}, "corner", "wheel_rpm"),
    "mixed units inside vectors": ({"t": "ms", "theta": "deg", "q": "–", "w": ["deg/s", "rad/s", "°/s"], "imu.gyro": ["rad/s", "deg/s", "rad/s"],
                                    "torque_cmd": ["mNm", "N·m", "mN·m"], "torque_meas": ["N*m", "mNm", "Nm"],
                                    "imu.accel": ["g", "m/s²", "m/s^2"], "wheel_rpm": ["rpm", "rad/s", "rpm"]}, "edge", "omega"),
}


def frames_of(nd):
    lines = [json.loads(x) for x in nd.splitlines()]
    return [x for x in lines if x["type"] == "hello"], [x for x in lines if x["type"] == "frame"]


def check_frames(doc, frames, profile_units, wheel_cols):
    """Every exported frame carries the truth in wire units; identity units bit for bit."""
    T = truth(len(frames))
    assert [f["t"] for f in frames] == pytest.approx([x for x in T["t"]], rel=REL, abs=1e-15)
    for field, unit in profile_units.items():
        if field == "t":
            exact = unit == "s"
            assert all((f["t"] == T["t"][i]) if exact else True for i, f in enumerate(frames))
            continue
        for i, f in enumerate(frames):
            got = f[field] if field in ("theta", "q", "w", "wheel_rpm", "torque_cmd", "torque_meas") else f["imu"][field.split(".")[1]]
            want = wire_truth(T, field, i)
            units = unit if isinstance(unit, list) else [unit] * (len(want) if isinstance(want, list) else 1)
            for k, (g, w) in enumerate(zip(got if isinstance(got, list) else [got], want if isinstance(want, list) else [want])):
                if F[FAMILY[field]][units[k]] == F[FAMILY[field]][WIRE[field]]:
                    assert g == w, (field, i, k, g, w)                 # identity: copied, never multiplied
                else:
                    assert g == pytest.approx(w, rel=REL, abs=1e-15), (field, i, k, g, w)


# ---------------------------------------------------------------- pure export (no API): every unit, every frame
@pytest.mark.parametrize("name", list(PROFILES))
def test_every_accepted_unit_is_exported_in_the_wire_unit(name):
    units, mode, wheel_cols = PROFILES[name]
    doc = make_doc(units, mode=mode, wheel_cols=wheel_cols)
    before = copy.deepcopy(doc)
    nd = recording_to_ndjson(doc, "AERIS-HW-000001")
    assert doc == before                                                           # the stored document is never changed
    hellos, frames = frames_of(nd)
    assert len(frames) == N and all(validate_frame(f, hellos[0])["ok"] for f in frames)
    check_frames(doc, frames, units, wheel_cols)
    assert [f["seq"] for f in frames] == list(range(100, 100 + N)) and [f["status"] for f in frames] == truth()["status"]
    conv = hellos[0]["lineage"].get("export", {}).get("converted", {})
    expect = {}
    for field, unit in units.items():
        names = [field] if field in ("t", "theta") else COLS["omega" if field == "wheel_rpm" and wheel_cols == "omega" else field]
        per = unit if isinstance(unit, list) else [unit] * len(names)
        for c, uu in zip(names, per):
            if F[FAMILY[field]][uu] != F[FAMILY[field]][WIRE[field]]:
                expect[c] = f"{uu} → {WIRE[field]}"
    assert conv == expect                                                           # the conversions are recorded, and only those


def test_the_reviewers_fixture_ms_deg_degs_is_streamed_in_s_rad_rads():
    """The values of the v5.1 review (G1): t 100 ms, theta 11 deg, w_x 180 deg/s at the second sample."""
    doc = {"schema": "aeris-hardware-run/1", "synthetic": True, "device": {"id": "unit-edge-fixture", "firmware": "test"},
           "recording": {"started": "2026-10-01T00:00:00Z", "notes": "unit edge"}, "mode": "edge",
           "samples": {"cols": {"t": [0, 100, 200], "theta": [10, 11, 12], "w_x": [0, 180, 0], "w_y": [0, 0, 0], "w_z": [0, 0, 0]},
                       "units": {"t": "ms", "theta": "deg", "w_x": "deg/s", "w_y": "deg/s", "w_z": "deg/s"}}}
    _, frames = frames_of(recording_to_ndjson(doc))
    assert frames[1]["t"] == pytest.approx(0.1, rel=1e-15) and frames[1]["theta"] == pytest.approx(math.radians(11), rel=1e-15)
    assert frames[1]["w"] == pytest.approx([math.pi, 0, 0], rel=1e-15)
    assert [f["t"] for f in frames] == pytest.approx([0.0, 0.1, 0.2], rel=1e-15) and [f["seq"] for f in frames] == [0, 1, 2]


def test_a_recording_without_seq_streams_the_row_index_and_says_so():
    doc = make_doc({"t": "ms", "theta": "deg"}, mode="edge", seq=False, status=False)
    hellos, frames = frames_of(recording_to_ndjson(doc))
    assert [f["seq"] for f in frames] == list(range(N))
    assert "row index" in hellos[0]["lineage"]["export"]["seq"]


# ---------------------------------------------------------------- refusals: explicit, with the column, never relabelled
def refuse(doc, path_part, text_part, omit_ok=True):
    with pytest.raises(ExportError) as ei:
        recording_to_ndjson(doc)
    det = ei.value.details
    assert any(path_part in d["path"] for d in det) and any(text_part in d["message"] for d in det), det
    if omit_ok:
        nd = recording_to_ndjson(doc, omit_unmapped=True)
        hellos, frames = frames_of(nd)
        assert hellos[0]["lineage"]["export"]["omitted"]["by"] == "omit_unmapped=true" and frames
        return hellos, frames
    with pytest.raises(ExportError):
        recording_to_ndjson(doc, omit_unmapped=True)
    return None, None


def bad(units=None, **kw):
    return make_doc(units or {"t": "s", "q": "–", "w": "rad/s"}, **kw)


def test_incomplete_vectors_are_refused_or_omitted_never_invented():
    for drop, field in (("w_z", "w"), ("gyro_y", "imu.gyro"), ("torque_meas_x", "torque_meas")):
        d = bad({"t": "s", "q": "–", "w": "rad/s", "imu.gyro": "rad/s", "torque_meas": "N·m"})
        del d["samples"]["cols"][drop], d["samples"]["units"][drop]
        hellos, frames = refuse(d, "samples.cols.", "does not invent a missing axis")
        key = field.split(".")[-1]
        assert all(key not in f and key not in (f.get("imu") or {}) for f in frames)
        om = hellos[0]["lineage"]["export"]["omitted"]
        assert set(om["columns"]) == {c for c in COLS[field] if c != drop} and om["count"] == 2


def test_an_incomplete_quaternion_is_refused_or_streamed_as_theta_only():
    d = bad({"t": "s", "theta": "rad", "q": "–"}, mode="edge")
    del d["samples"]["cols"]["q3"], d["samples"]["units"]["q3"]
    hellos, frames = refuse(d, "samples.cols.q0", "4-vector")
    assert all("q" not in f and "theta" in f for f in frames)


def test_columns_without_a_stream_field_are_refused_or_omitted_with_their_names():
    d = bad()
    extra = {"thetadot": ("rate", "rad/s"), "sat": ("flag", "0/1"), "qhat0": ("unitless", "–"), "omega_4": ("wheel", "rpm"), "temperature_c": (None, "degC")}
    for c, (_, unit) in extra.items():
        d["samples"]["cols"][c] = [0.0] * N
        d["samples"]["units"][c] = unit
    hellos, _ = refuse(d, "samples.cols", "no field in aeris-telemetry-ndjson/1")
    assert set(hellos[0]["lineage"]["export"]["omitted"]["columns"]) == set(extra)


def test_status_codes_are_only_named_as_the_recording_declares_them():
    d = bad()
    d["provenance"].pop("status_codes")
    refuse(d, "samples.cols.status", "does not declare what its status codes mean")
    d2 = bad()
    d2["samples"]["cols"]["status"][7] = 9                                  # v5.1 streamed an unknown code as "ok"
    hellos, frames = refuse(d2, "samples.cols.status[7]", "does not relabel")
    assert all("status" not in f for f in frames)
    d3 = bad()
    d3["provenance"]["status_codes"] = {"ok": 5, "fault": 6, "idle": 0, "calibrating": 1, "estop": 2}     # another declared table
    _, frames = frames_of(recording_to_ndjson(d3))
    inv = {v: k for k, v in d3["provenance"]["status_codes"].items()}
    assert [f["status"] for f in frames] == [inv[c] for c in d3["samples"]["cols"]["status"]]


def test_refusals_that_omission_cannot_fix():
    d = bad({"t": "s", "q": "–", "wheel_rpm": "rpm"})
    for c in COLS["omega"]:
        d["samples"]["cols"][c], d["samples"]["units"][c] = [0.0] * N, "rad/s"
    refuse(d, "samples.cols", "two column sets", omit_ok=False)
    d = bad()
    d["samples"]["cols"]["t"] = [x - 0.1 for x in d["samples"]["cols"]["t"]]
    refuse(d, "samples.cols.t", "must be ≥ 0", omit_ok=False)
    d = bad()
    d["samples"]["cols"]["seq"] = list(range(-5, N - 5))
    refuse(d, "samples.cols.seq[0]", "non-negative", omit_ok=False)
    d = bad({"t": "s", "q": "–"}, mode="edge")
    refuse(d, "samples.cols.theta", "edge-mode recording needs theta", omit_ok=False)
    d = bad()
    d["provenance"]["segments"] = [{"segment": 1, "rows": [0, 20], "hello": None}, {"segment": 2, "rows": [25, N], "hello": None}]
    refuse(d, "provenance.segments", "without gaps or overlaps", omit_ok=False)


def test_the_export_replays_its_own_output_before_returning_it(monkeypatch):
    doc = bad()
    res = check_replayable(recording_to_ndjson(doc), expect_frames=N, expect_hellos=1)
    assert res["ok"] and res["frames"] == N and res["hellos"] == 1
    # an over-long hello is caught by the check (MAX_LINE), never returned
    long_id = bad()
    long_id["device"]["id"] = "x" * 70000
    with pytest.raises(ExportError) as ei:
        recording_to_ndjson(long_id)
    assert any("MAX_LINE" in d["message"] for d in ei.value.details)
    # a broken line is reported with its number
    text = recording_to_ndjson(doc)
    lines = text.splitlines()
    lines[3] = lines[3].replace('"seq":102', '"seq":-1')
    res = check_replayable("\n".join(lines) + "\n", expect_frames=N)
    assert not res["ok"] and res["problems"][0]["path"] == "line 4" and "seq" in res["problems"][0]["message"]
    # a time base that does not increase (would be rejected at replay) is refused by the export itself
    import aeris_backend.telemetry.export as EX
    orig = EX._frame
    monkeypatch.setattr(EX, "_frame", lambda plan, i, mode: dict(orig(plan, i, mode), t=0.5))
    with pytest.raises(ExportError) as ei:
        recording_to_ndjson(doc)
    assert any("time_not_increasing" in d["message"] for d in ei.value.details)


# ---------------------------------------------------------------- end to end through the API, with an actual replay
@pytest.fixture(scope="module")
def api(tmp_path_factory):
    d = tmp_path_factory.mktemp("units")
    (d / "telemetry").mkdir()
    app = create_app({"db": str(d / "u.sqlite3"), "workers": 1, "max_jobs": 1, "telemetry_dir": str(d / "telemetry")})
    with TestClient(app) as c:
        c.dir = d / "telemetry"
        yield c


def until(fn, timeout=30, step=0.02):
    t0 = time.time()
    while time.time() - t0 < timeout:
        v = fn()
        if v:
            return v
        time.sleep(step)
    raise AssertionError("condition not reached within %ss" % timeout)


def api_replay_and_record(api, text, name):
    """The exported text as a file in the telemetry directory, replayed by the backend at real speed and recorded."""
    (api.dir / f"{name}.ndjson").write_text(text)
    r = api.post("/api/v1/telemetry/connect", json={"source": "file", "path": f"{name}.ndjson", "speed": 1})
    assert r.status_code == 200, r.text
    until(lambda: api.get("/api/v1/telemetry/status").json()["hello"] is not None)
    r = api.post("/api/v1/telemetry/recordings/start", json={"name": name})
    assert r.status_code == 201, r.text
    until(lambda: api.get("/api/v1/telemetry/status").json()["source"]["state"] == "finished")
    r = api.post("/api/v1/telemetry/recordings/stop")
    assert r.status_code == 201, r.text
    return r.json()


def si_by_seq(doc):
    """{seq: {wire field: SI value(s)}} through the importer's own conversion (validate_recording si)."""
    v = validate_recording(doc)
    assert v["ok"], v["errors"]
    si, cols = v["si"], doc["samples"]["cols"]
    seq = [int(x) for x in cols["seq"]] if "seq" in cols else list(range(len(cols["t"])))
    out = {}
    for i, s in enumerate(seq):
        row = {"t": si["t"][i]}
        if "theta" in si:
            row["theta"] = si["theta"][i]
        if "q0" in si:
            row["q"] = [si[f"q{j}"][i] for j in range(4)]
        for field, names in (("w", COLS["w"]), ("imu.gyro", COLS["imu.gyro"]), ("imu.accel", COLS["imu.accel"]), ("torque_cmd", COLS["torque_cmd"]),
                             ("torque_meas", COLS["torque_meas"]), ("wheel", COLS["wheel_rpm"]), ("wheel", COLS["omega"])):
            if names[0] in si:
                row[field] = [si[c][i] for c in names]          # wheel speeds: rad/s (SI) from either column set
        out[s] = row
    return out


@pytest.mark.parametrize("name", list(PROFILES))
def test_api_import_export_replay_rerecord_keeps_physical_values_and_time_intervals(api, name):
    units, mode, wheel_cols = PROFILES[name]
    doc = make_doc(units, mode=mode, wheel_cols=wheel_cols, notes=f"SYNTHETIC units fixture: {name}")
    up = api.post("/api/v1/hardware/recordings", json=doc)
    assert up.status_code == 201, up.text
    rid = up.json()["id"]
    r = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=ndjson")
    assert r.status_code == 200, r.text
    hellos, frames = frames_of(r.text)
    check_frames(doc, frames, units, wheel_cols)
    rec = api_replay_and_record(api, r.text, "units-" + str(abs(hash(name)) % 10**8))
    new = api.get(f"/api/v1/hardware/recordings/{rec['id']}").json()["document"]
    # the copy is labelled in wire units, as the stream defines them
    nu = new["samples"]["units"]
    assert nu["t"] == "s" and nu["seq"] == "count" and all(nu[c] == WIRE[f] for f in ("w", "imu.gyro", "imu.accel", "torque_cmd", "torque_meas", "wheel_rpm")
                                                            for c in COLS[f] if c in nu)
    assert ("theta" not in nu or nu["theta"] == "rad") and not any(c.startswith("omega_") for c in nu)
    # physical values, row by row (matched by seq), and the time intervals between the replayed rows
    a, b = si_by_seq(doc), si_by_seq(new)
    assert len(b) >= N - 15 and set(b) <= set(a), (len(b), sorted(set(b) - set(a))[:5])
    for s, row in b.items():
        for k, v in row.items():
            assert v == pytest.approx(a[s][k], rel=REL, abs=1e-15), (s, k, v, a[s][k])
    seqs = sorted(b)
    for s0, s1 in zip(seqs, seqs[1:]):
        assert b[s1]["t"] - b[s0]["t"] == pytest.approx(a[s1]["t"] - a[s0]["t"], rel=1e-9, abs=1e-12)
    st = dict(zip(new["samples"]["cols"]["seq"], new["samples"]["cols"]["status"]))
    names = {v: k for k, v in STATUS_CODES.items()}
    assert all(names[st[s]] == truth()["status"][s - 100] for s in seqs)
    # identity profiles: the copy holds the very same numbers
    if name.startswith("wire units"):
        orig = dict(zip(doc["samples"]["cols"]["seq"], range(N)))
        for c in ("t", "q0", "w_x", "wheel_rpm_y", "torque_cmd_z", "gyro_x", "accel_z"):
            got = dict(zip(new["samples"]["cols"]["seq"], new["samples"]["cols"][c]))
            assert all(got[s] == doc["samples"]["cols"][c][orig[s]] for s in seqs), c
    # provenance: the copy is derived from this recording and stays synthetic; the original is untouched
    assert new["synthetic"] is True and new["provenance"]["derived"] is True
    assert {l["derived_from"] for l in new["provenance"]["lineage"]} == {rid}
    again = api.get(f"/api/v1/hardware/recordings/{rid}").json()
    assert canonical_hash(again["document"]) == canonical_hash(doc) == up.json()["content_hash"]
    assert api.get(f"/api/v1/hardware/recordings/{rid}/export?format=json").json() == doc


def test_api_missing_seq_is_replayed_with_the_row_index(api):
    doc = make_doc({"t": "ms", "theta": "deg", "w": "deg/s"}, mode="edge", seq=False, status=False, notes="SYNTHETIC: no seq column")
    rid = api.post("/api/v1/hardware/recordings", json=doc).json()["id"]
    r = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=ndjson")
    hellos, frames = frames_of(r.text)
    assert [f["seq"] for f in frames] == list(range(N)) and "row index" in hellos[0]["lineage"]["export"]["seq"]
    rec = api_replay_and_record(api, r.text, "units-noseq")
    new = api.get(f"/api/v1/hardware/recordings/{rec['id']}").json()["document"]
    a, b = si_by_seq(doc), si_by_seq(new)
    assert len(b) >= N - 15
    for s, row in b.items():
        assert row["t"] == pytest.approx(a[s]["t"], rel=REL) and row["theta"] == pytest.approx(a[s]["theta"], rel=REL)
    assert all("row index" in l["export"]["seq"] for l in new["provenance"]["lineage"])


@pytest.mark.parametrize("case", ["incomplete vector", "unmapped column", "undeclared status codes", "unknown status code", "two wheel sets",
                                  "negative time", "edge without theta"])
def test_api_inputs_the_stream_cannot_carry_are_422_with_the_column_never_500(api, case):
    d = make_doc({"t": "ms", "q": "–", "w": "deg/s", "wheel_rpm": "rpm"}, notes=f"SYNTHETIC refusal fixture: {case}")
    omit_ok = True
    if case == "incomplete vector":
        del d["samples"]["cols"]["w_y"], d["samples"]["units"]["w_y"]
    elif case == "unmapped column":
        d["samples"]["cols"]["thetadot"], d["samples"]["units"]["thetadot"] = [0.0] * N, "deg/s"
    elif case == "undeclared status codes":
        d["provenance"].pop("status_codes")
    elif case == "unknown status code":
        d["samples"]["cols"]["status"][3] = 42
    elif case == "two wheel sets":
        for c in COLS["omega"]:
            d["samples"]["cols"][c], d["samples"]["units"][c] = [0.0] * N, "rad/s"
        omit_ok = False
    elif case == "negative time":
        d["samples"]["cols"]["t"] = [x - 50 for x in d["samples"]["cols"]["t"]]
        omit_ok = False
    elif case == "edge without theta":
        d["mode"] = "edge"
        omit_ok = False
    up = api.post("/api/v1/hardware/recordings", json=d)
    assert up.status_code == 201, up.text                                    # the import accepts it (it is a valid recording) …
    rid = up.json()["id"]
    r = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=ndjson")
    assert r.status_code == 422, (r.status_code, r.text[:300])               # … the stream cannot carry it: explicit, not 500
    err = r.json()["error"]
    assert err["code"] == "export_not_possible" and err["details"] and all(x["message"] for x in err["details"])
    c = api.post("/api/v1/telemetry/connect", json={"source": "recording", "recording_id": rid})
    assert c.status_code == 422 and c.json()["error"]["code"] == "export_not_possible"
    r2 = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=ndjson&omit_unmapped=true")
    if omit_ok:
        assert r2.status_code == 200, r2.text
        hellos, frames = frames_of(r2.text)
        assert hellos[0]["lineage"]["export"]["omitted"]["count"] >= 1 and len(frames) == N
        c2 = api.post("/api/v1/telemetry/connect", json={"source": "recording", "recording_id": rid, "omit_unmapped": True, "speed": 0})
        assert c2.status_code == 200, c2.text
    else:
        assert r2.status_code == 422
    assert api.get(f"/api/v1/hardware/recordings/{rid}/export?format=json").json() == d     # the stored original is unchanged


# ---------------------------------------------------------------- the transport itself (FileReplaySource), in process
def test_file_replay_transport_of_converted_exports_paces_by_seconds():
    """v5.1 paced a replay of a millisecond recording by the raw numbers (0, 100, 200 → 100 s per step). The
    FileReplaySource pacing now sees seconds: the recorded wall-clock waits match the original intervals."""
    doc = make_doc({"t": "ms", "theta": "deg"}, mode="edge", n=6, status=False)
    nd = recording_to_ndjson(doc)
    hub, waits, clock = TelemetryHub(), [], [0.0]

    async def sleep(dt):
        waits.append(dt)
        clock[0] += dt
    asyncio.run(FileReplaySource(hub, text=nd, speed=1.0, clock=lambda: clock[0], sleep=sleep).run())
    assert hub.counters["frames_accepted"] == 6 and hub.counters["rejected"] == 0
    assert waits == pytest.approx([1 / RATE] * 5, rel=1e-9)


# ---------------------------------------------------------------- existing faulty copies: found, never repaired or rewritten
def test_export_audit_lists_v51_copies_of_recordings_in_other_units_read_only(tmp_path):
    """dbtool export-audit (read-only): originals whose v5/v5.1 NDJSON export was wrong, and copies recorded from such
    an export (their lineage has none of the v5.2 fields). A copy recorded from a v5.2 export is not listed."""
    from aeris_backend.tools.dbtool import export_audit
    db = tmp_path / "audit.sqlite3"
    app = create_app({"db": str(db), "workers": 1, "max_jobs": 1, "telemetry_dir": str(tmp_path / "telemetry")})
    with TestClient(app) as c:
        doc = make_doc({"t": "ms", "theta": "deg", "wheel_rpm": "rad/s"}, mode="edge", wheel_cols="omega", notes="SYNTHETIC audit fixture")
        orig = c.post("/api/v1/hardware/recordings", json=doc).json()["id"]
        wire_doc = make_doc(FULL, notes="SYNTHETIC wire-unit fixture")
        c.post("/api/v1/hardware/recordings", json=wire_doc)
        nd = c.get(f"/api/v1/hardware/recordings/{orig}/export?format=ndjson").text
        hub = TelemetryHub()
        hub.on_connect({"kind": "file", "address": "audit.ndjson"}, 0.0)
        for i, ln in enumerate(nd.splitlines()):
            r = hub.feed_line(ln, 0.1)
            if r == "hello" and hub.recording is None:
                hub.start_recording("audit copy (v5.2 export)", 0.1)
        v52 = hub.stop_recording(1.0)
        v52_id = c.post("/api/v1/hardware/recordings", json=v52).json()["id"]
        v51 = copy.deepcopy(v52)                                  # what a v5.1 export left: lineage without the v5.2 fields
        for l in [v51["provenance"]["lineage"][0], v51["provenance"]["segments"][0]["hello"]["lineage"], v51["provenance"]["hellos"][0]["lineage"]]:
            for k in ("generation", "ancestry", "ancestry_trust", "ancestry_omitted", "export"):
                l.pop(k, None)
        v51_id = c.post("/api/v1/hardware/recordings", json=v51).json()["id"]
    before = db.read_bytes()                                     # (the backend has stopped: nothing else touches the file)
    rep = export_audit(str(db))
    assert db.read_bytes() == before and rep["read_only"] is True
    originals = {x["id"]: x["issues"] for x in rep["originals_whose_v5_v51_ndjson_export_was_wrong"]}
    assert set(originals) == {orig}
    assert any("t [ms] was streamed as s" in i for i in originals[orig]) and any("omega_x [rad/s] (wheel speed) was left out" in i for i in originals[orig])
    assert [x["id"] for x in rep["copies_recorded_from_such_an_export"]] == [v51_id] and v52_id not in json.dumps(rep["copies_recorded_from_such_an_export"])

"""/api/v6 in-process: ownership and isolation (jwt mode, two owners), pairing proofs, leases, command gates, calibrations
from reported measurements, approved configurations, the twin, start-up expiry of open commands.

The pairing signatures here come from a SOFTWARE key standing in for a device (the firmware's own signing is exercised
by firmware/tests and by test_devices_e2e.py against the synthetic device process)."""
from __future__ import annotations

import base64
import json
import time

import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app
from aeris_backend.devices import calibration as CAL
from aeris_backend.devices import service as SVC
from aeris_backend.devices.linkhost import pair_message
from aeris_backend.storage.sqlite import SqliteRepository
from aeris_backend.tools import devauth

G = 9.80665


def b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


class SoftDevice:
    def __init__(self, device_id: str, synthetic: bool = True):
        self.key = ec.generate_private_key(ec.SECP256R1())
        self.pub = b64u(self.key.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint))
        self.device_id, self.synthetic = device_id, synthetic

    def sign(self, msg: bytes) -> str:
        r, s = decode_dss_signature(self.key.sign(msg, ec.ECDSA(hashes.SHA256())))
        return b64u(r.to_bytes(32, "big") + s.to_bytes(32, "big"))

    def proof(self, sess: dict) -> dict:
        p = {"session": sess["session"], "nonce": sess["nonce"], "device_id": self.device_id, "pubkey": self.pub,
             "board_id": "aeris-synthetic" if self.synthetic else "esp32-s3-devkitc-1", "firmware": "0.1.0", "local_confirmed": True,
             "synthetic": self.synthetic}
        p["sig"] = self.sign(pair_message(p))
        return p


def pair(c, dev: SoftDevice, headers=None, name=None):
    s = c.post("/api/v6/pairing/start", headers=headers)
    assert s.status_code == 201, s.text
    r = c.post("/api/v6/pairing/complete", json={"proof": dev.proof(s.json()), "name": name}, headers=headers)
    return r


def app_for(tmp_path, **extra):
    st = {"db": str(tmp_path / "aeris.sqlite3"), "workers": 1, "max_jobs": 1, "origins": ["http://localhost:8000"], "telemetry_dir": str(tmp_path / "tel")}
    st.update(extra)
    return create_app(st)


def axes_result(face, to_body=(1, 0, 0, 0, 1, 0, 0, 0, 1)):
    e = CAL.face_vector(face)
    up = [sum(to_body[3 * c + r] * e[c] for c in range(3)) for r in range(3)]       # sensor = to_bodyᵀ · body
    return {"measurement": "calibrate_axes", "face": face, "accel_mean_mps2": [G * x for x in up], "accel_std_mps2": [0.04] * 3,
            "gyro_std_radps": [0.003] * 3, "still": True}


IMU = {"measurement": "calibrate_imu", "gyro_mean_radps": [0.0087, -0.0052, 0.0035], "gyro_std_radps": [0.003] * 3, "accel_mean_mps2": [0, 0, 9.81],
       "still": True, "samples": 2500, "seconds": 5.0}
ENC_OK = {"wheels": [{"index": i, "node": i + 1, "encoder_updates": 400, "travel_rev": 2.0, "vel_rads_max": 20.0, "vel_rads_min": -0.3} for i in range(3)]}


def tiny_recording(device="SYNTHETIC-API"):
    n = 20
    cols = {"t": [i * 0.02 for i in range(n)], "seq": list(range(n)), "q0": [1.0] * n, "q1": [0.0] * n, "q2": [0.0] * n, "q3": [0.0] * n}
    units = {"t": "s", "seq": "count", "q0": "–", "q1": "–", "q2": "–", "q3": "–"}
    return {"schema": "aeris-hardware-run/1", "synthetic": True, "device": {"id": device, "firmware": "none"}, "recording": {"started": "2026-10-01T10:00:00Z"},
            "mode": "corner", "parameters": {"parameter_set": "nominal-design-v1"}, "samples": {"rate_hz": 50, "cols": cols, "units": units}}


def wait_job(c, job_id, headers=None, timeout=120):
    t0 = time.time()
    while time.time() - t0 < timeout:
        j = c.get(f"/api/v1/jobs/{job_id}", headers=headers).json()
        if j["state"] in ("complete", "failed", "cancelled"):
            return j
        time.sleep(0.2)
    raise AssertionError("job did not finish")


# ------------------------------------------------------------------------------------------------ local mode
def test_local_mode_pairing_profiles_and_revocation(tmp_path):
    with TestClient(app_for(tmp_path)) as c:
        st = c.get("/api/v6/status").json()
        assert st["auth"]["mode"] == "local" and st["auth"]["enabled"] and "start_experiment" in st["remote_actions"]
        assert "unpair" in st["usb_local_only"] and "unpair" not in st["remote_actions"]
        assert c.get("/api/v1/capabilities").json()["devices"]["api"] == "/api/v6"
        assert c.get("/api/v6/me").json() == {"owner": "local", "mode": "local"}
        profs = c.get("/api/v6/profiles").json()["profiles"]
        assert profs[0]["id"] == "aeris-ref-a1" and profs[0]["qualification"] == "experimental"
        assert {r["id"] for r in c.get("/api/v6/recipes").json()["recipes"]} >= {"edge-hold-10s", "corner-hold-10s"}
        dev = SoftDevice("synthetic-api-1")
        r = pair(c, dev, name="bench cube")
        assert r.status_code == 201, r.text
        assert r.json()["name"] == "bench cube" and r.json()["synthetic"] is True and r.json()["profile_id"] == "aeris-ref-a1"
        v = c.get("/api/v6/devices/synthetic-api-1").json()
        assert v["connected"] is False and v["routes"] == [] and v["lease"] is None
        # a proof is single-use; a forged signature never registers anything
        s = c.post("/api/v6/pairing/start").json()
        p = dev.proof(s)
        assert c.post("/api/v6/pairing/complete", json={"proof": p}).status_code == 201
        assert c.post("/api/v6/pairing/complete", json={"proof": p}).json()["error"]["code"] == "pairing_refused"
        s2 = c.post("/api/v6/pairing/start").json()
        forged = dict(dev.proof(s2), device_id="synthetic-api-2")
        r = c.post("/api/v6/pairing/complete", json={"proof": forged})
        assert r.status_code == 422 and r.json()["error"]["code"] == "invalid_signature"
        no_local = dev.proof(c.post("/api/v6/pairing/start").json())
        no_local["local_confirmed"] = False
        assert c.post("/api/v6/pairing/complete", json={"proof": no_local}).status_code == 422
        # profiles: a user revision is experimental at most; the reference id is reserved
        mine = dict(c.get("/api/v6/profiles/aeris-ref-a1").json()["document"], id="my-cube", name="My cube")
        r = c.post("/api/v6/profiles", json=mine)
        assert r.status_code == 201 and r.json()["revision"] == 1
        assert c.post("/api/v6/profiles", json=mine).json().get("unchanged") is True
        mine2 = dict(mine, body=dict(mine["body"], mass_kg=1.9))
        assert c.post("/api/v6/profiles", json=mine2).json()["revision"] == 2
        q = dict(mine, qualification={"status": "qualified"})
        r = c.post("/api/v6/profiles", json=q)
        assert r.status_code == 422 and any(e["path"] == "qualification.status" for e in r.json()["error"]["details"])
        assert c.post("/api/v6/profiles", json=dict(mine, id="aeris-ref-a1")).status_code == 409
        assert c.post("/api/v6/devices/synthetic-api-1/profile", json={"id": "my-cube", "revision": 2}).json()["profile_revision"] == 2
        assert c.post("/api/v6/devices/synthetic-api-1/name", json={"name": "renamed"}).json()["name"] == "renamed"
        # revoking forgets the credential; the device is then not found
        assert c.post("/api/v6/devices/synthetic-api-1/revoke").status_code == 200
        assert c.get("/api/v6/devices/synthetic-api-1").status_code == 404
        assert c.get("/api/v6/devices").json()["devices"] == []


def test_device_api_disabled_on_a_public_bind_without_jwt(tmp_path):
    with TestClient(app_for(tmp_path, auth_env={"AERIS_BIND_HOST": "0.0.0.0"})) as c:
        st = c.get("/api/v6/status").json()
        assert st["auth"]["enabled"] is False and "AERIS_AUTH=jwt" in st["auth"]["problem"]
        r = c.get("/api/v6/devices")
        assert r.status_code == 503 and r.json()["error"]["code"] == "device_api_disabled"
        assert c.post("/api/v6/pairing/start").status_code == 503
        assert c.get("/api/v1/health").status_code == 200         # the research API keeps its v5 behaviour in local mode


def test_leases_and_command_gates(tmp_path):
    with TestClient(app_for(tmp_path)) as c:
        assert pair(c, SoftDevice("synthetic-lease")).status_code == 201
        base = "/api/v6/devices/synthetic-lease"
        r = c.post(base + "/commands", json={"action": "identify", "holder": "holder-aaaa"})
        assert r.status_code == 409 and r.json()["error"]["code"] == "not_connected"
        for a in ("set_network", "unpair", "commission", "motor_test", "enter_update"):
            r = c.post(base + "/commands", json={"action": a})
            assert r.status_code == 422 and r.json()["error"]["code"] == "action_not_available", a
        assert c.post(base + "/commands", json={"action": "identify", "ttl_ms": 50}).json()["error"]["code"] == "ttl"
        a = c.post(base + "/lease", json={"holder": "holder-aaaa"}).json()
        assert a["epoch"] == 1 and a["holder"] == "holder-aaaa"
        assert c.post(base + "/lease", json={"holder": "holder-aaaa"}).json()["epoch"] == 1       # renewal keeps the epoch
        r = c.post(base + "/lease", json={"holder": "holder-bbbb"})
        assert r.status_code == 409 and r.json()["error"]["code"] == "lease_held"
        b = c.post(base + "/lease", json={"holder": "holder-bbbb", "takeover": True}).json()
        assert b["epoch"] == 2 and b["holder"] == "holder-bbbb"                                  # an explicit takeover: a new epoch
        assert c.post(base + "/lease", json={"holder": "holder-aaaa"}).status_code == 409
        assert c.post(base + "/lease/release", json={"holder": "holder-aaaa"}).json() == {"released": False}
        assert c.post(base + "/lease/release", json={"holder": "holder-bbbb"}).json() == {"released": True}
        assert c.post(base + "/lease", json={"holder": "holder-aaaa"}).json()["epoch"] == 3
        assert c.post(base + "/lease", json={"holder": "short"}).status_code == 422


def test_calibration_from_reported_measurements_and_configurations(tmp_path):
    with TestClient(app_for(tmp_path)) as c:
        assert pair(c, SoftDevice("synthetic-cal")).status_code == 201
        assert pair(c, SoftDevice("board-cal", synthetic=False)).status_code == 201
        rot = [0, 1, 0, -1, 0, 0, 0, 0, 1]
        body = {"measurements": {"imu": IMU, "axes": [axes_result("+z", rot), axes_result("+x", rot)], "encoders": ENC_OK}}
        r = c.post("/api/v6/devices/synthetic-cal/calibrations", json=body)
        assert r.status_code == 201, r.text
        cal = r.json()
        assert cal["id"].startswith("AERIS-CAL-") and cal["document"]["imu"]["to_body"] == rot
        assert cal["document"]["source"] == "synthetic-device" and cal["document"]["wheel_directions_confirmed"] is True
        assert all(e["origin"] == "client-reported" for e in cal["document"]["evidence"]) and len(cal["document"]["evidence"]) == 4
        bad = {"measurements": {"imu": IMU, "axes": [axes_result("+z"), axes_result("-z")]}}
        r = c.post("/api/v6/devices/synthetic-cal/calibrations", json=bad)
        assert r.status_code == 422 and r.json()["error"]["code"] == "calibration_rejected"
        assert c.post("/api/v6/devices/synthetic-cal/calibrations", json={"commands": {"imu": "c-nope", "axes": []}}).status_code == 422
        assert c.post("/api/v6/devices/synthetic-cal/calibrations", json={}).status_code == 422
        assert [x["id"] for x in c.get("/api/v6/devices/synthetic-cal/calibrations").json()["calibrations"]] == [cal["id"]]
        # an approved configuration: the measured mounting and the bias rotated into the body frame; hash reproducible
        r = c.post("/api/v6/devices/synthetic-cal/configs", json={"recipe": "edge-hold-10s", "calibration": cal["id"]})
        assert r.status_code == 201, r.text
        cfg = r.json()
        assert cfg["config"]["imu"]["to_body"] == rot and len(cfg["id"]) == 64
        gb = cfg["config"]["imu"]["gyro_bias_radps"]
        assert abs(gb[0] - IMU["gyro_mean_radps"][1]) < 1e-9 and abs(gb[1] + IMU["gyro_mean_radps"][0]) < 1e-9
        again = c.post("/api/v6/devices/synthetic-cal/configs", json={"recipe": "edge-hold-10s", "calibration": cal["id"]}).json()
        assert again["id"] == cfg["id"]
        assert c.get(f"/api/v6/configs/{cfg['id']}").json()["text"] == cfg["text"]
        # a physical device needs its own calibration; another device's calibration is refused
        r = c.post("/api/v6/devices/board-cal/configs", json={"recipe": "edge-hold-10s"})
        assert r.status_code == 409 and r.json()["error"]["code"] == "calibration_required"
        r = c.post("/api/v6/devices/board-cal/configs", json={"recipe": "edge-hold-10s", "calibration": cal["id"]})
        assert r.status_code == 409 and r.json()["error"]["code"] == "calibration_device"


def test_corner_recipe_needs_an_edge_trial_on_a_declared_physical_device(tmp_path):
    """The corner recipe's prerequisite (a completed edge trial of the same device and profile revision) is enforced by the
    service for a declared-physical device; a device that declares itself synthetic is exempt (its plant is fixed to one
    mode and it has no hardware to protect). Service level, with a stand-in connection: nothing is sent to hardware."""
    from aeris_backend.devices import compat
    from aeris_backend.devices.auth import AuthConfig, Authenticator
    repo = SqliteRepository(str(tmp_path / "gates.sqlite3"))
    svc = SVC.DeviceService(repo, Authenticator(AuthConfig({})))
    hello = {"kind": "dev_hello", "link": "aeris-device-link/1", "versions": [1], "fw": {"version": "0.1.0", "actuation_build": True},
             "caps": {"actions": ["identify", "diagnostics", "self_test", "apply_config", "start_experiment", "stop"], "controllers": ["edge-lqr", "corner-mimo-lqr"],
                      "estimators": ["cf3d"], "imu": "lsm6dsox", "motor": "odrive-cansimple", "config_schema": "aeris-device-config/1", "max_control_hz": 1000},
             "limits": {"hard_max_current_A": 10, "hard_max_torque_Nm": 1, "hard_max_speed_rpm": 8000}}

    class Host:
        link_session, lease_epoch = "ls-gates", 0

        def __init__(self):
            self.sent = []

        def send_command(self, cid, action, params, ttl_ms, config_hash, raw_params_text=None):
            self.sent.append((action, config_hash))
            return {"seq": len(self.sent), "lease_epoch": self.lease_epoch}

        def set_lease_epoch(self, e):
            self.lease_epoch = e

    class Conn:
        route = "companion"

        def __init__(self):
            self.host = Host()

    out = {}
    for did, synthetic in (("synthetic-gate", True), ("board-gate", False)):
        repo.device_register({"id": did, "owner": "local", "pubkey": "key-" + did, "board": "aeris-synthetic" if synthetic else "esp32-s3-devkitc-1", "firmware": "0.1.0",
                              "synthetic": synthetic, "name": did, "profile_id": "aeris-ref-a1", "profile_revision": 1, "extra": {}})
        cal = svc.calibration_create("local", did, {"measurements": {"imu": IMU, "axes": [axes_result("+z"), axes_result("+x")], "encoders": ENC_OK}})
        rt = SVC.DeviceRuntime(did, "local")
        conn = Conn()
        rt.routes["companion"] = conn
        rt.dev_hello = dict(hello, device_id=did, board={"id": "b", "kind": "emulator" if synthetic else "physical", "synthetic": synthetic})
        rt.compat = compat.negotiate(rt.dev_hello)
        svc.runtimes[did] = rt
        corner = svc.build_config("local", did, "corner-hold-10s", cal["id"])
        edge = svc.build_config("local", did, "edge-hold-10s", cal["id"])
        rt.state = {"state": "READY", "config_hash": corner["id"]}
        svc.lease_acquire("local", did, "holder-gates")
        try:
            out[did] = svc.command_submit("local", did, "holder-gates", "start_experiment", {"duration_s": 2}, 10000, corner["id"])["status"]
        except SVC.ServiceError as e:
            out[did] = e.code
        out[did + ":edge"], out[did + ":cal"] = edge["id"], cal["id"]
        out[did + ":conn"], out[did + ":corner"] = conn, corner["id"]
    assert out["synthetic-gate"] == "sent" and out["board-gate"] == "prerequisite", out
    # an edge trial of the physical device that completed its duration is on record: the corner request goes out
    repo.command_insert({"id": "c-edge-done", "device_id": "board-gate", "owner": "local", "holder": "holder-gates", "action": "start_experiment", "params": {"duration_s": 10},
                         "config_hash": out["board-gate:edge"], "created": "2026-10-10T10:00:00Z", "ttl_ms": 10000, "status": "sent", "history": [{"status": "sent"}],
                         "route": "companion", "lease_epoch": 1})
    repo.command_update("c-edge-done", "completed", {"status": "completed", "by": "device"}, result={"ended": "tilt limit", "duration_s": 3.1})
    with pytest.raises(SVC.ServiceError) as e:                 # an edge trial that ended early does not count
        svc.command_submit("local", "board-gate", "holder-gates", "start_experiment", {"duration_s": 2}, 10000, out["board-gate:corner"])
    assert e.value.code == "prerequisite"
    repo.command_update("c-edge-done", "completed", {"status": "completed", "by": "device"}, result={"ended": "duration reached", "duration_s": 10.0})
    c = svc.command_submit("local", "board-gate", "holder-gates", "start_experiment", {"duration_s": 2}, 10000, out["board-gate:corner"])
    assert c["status"] == "sent" and out["board-gate:conn"].host.sent[-1] == ("start_experiment", out["board-gate:corner"])
    repo.close()


def test_restart_expires_open_commands(tmp_path):
    db = str(tmp_path / "aeris.sqlite3")
    with TestClient(app_for(tmp_path)) as c:
        assert pair(c, SoftDevice("synthetic-restart")).status_code == 201
    r = SqliteRepository(db)
    r.command_insert({"id": "c-open-1", "device_id": "synthetic-restart", "owner": "local", "holder": "h", "action": "self_test", "params": None,
                      "created": "2026-10-01T10:00:00Z", "ttl_ms": 5000, "status": "sent", "history": [{"status": "sent"}], "route": "companion", "lease_epoch": 1})
    r.close()
    with TestClient(app_for(tmp_path)) as c:
        assert c.get("/api/v6/status").json()["commands_closed_at_start"] == 1
        cmd = c.get("/api/v6/commands/c-open-1").json()
        assert cmd["status"] == "expired" and "never resent" in cmd["history"][-1]["reason"]


# ------------------------------------------------------------------------------------------------ jwt mode: two owners
@pytest.fixture()
def jwt_app(tmp_path):
    d = str(tmp_path / "dev-auth")
    devauth.init(d)
    env = devauth.env(d)
    app = app_for(tmp_path, auth_env=env, bridge="ndjson")
    alice = {"Authorization": "Bearer " + devauth.token(d, "alice")}
    bob = {"Authorization": "Bearer " + devauth.token(d, "bob")}
    with TestClient(app) as c:
        yield c, alice, bob


def test_jwt_requires_tokens_and_isolates_owners(jwt_app, monkeypatch):
    c, alice, bob = jwt_app
    assert c.get("/api/v1/health").status_code == 200 and c.get("/api/v6/status").status_code == 200
    for path in ("/api/v6/devices", "/api/v1/runs", "/api/v1/jobs", "/api/v1/hardware/recordings"):
        r = c.get(path)
        assert r.status_code == 401 and r.json()["error"]["code"] == "unauthorized", path
    assert c.get("/api/v6/me", headers=alice).json()["owner"] == "aeris-dev-issuer|alice"
    # the global v1 telemetry bridge is off in jwt mode (per-device telemetry is owner-scoped)
    ts = c.get("/api/v1/telemetry/status", headers=alice).json()
    assert ts["available"] is False and "AERIS_AUTH=jwt" in ts["reason"]
    dev = SoftDevice("synthetic-alice-1")
    assert pair(c, dev, alice).status_code == 201
    base = "/api/v6/devices/synthetic-alice-1"
    for method, path, body in (("get", base, None), ("get", base + "/calibrations", None), ("post", base + "/lease", {"holder": "holder-bbbb"}),
                               ("post", base + "/configs", {"recipe": "edge-hold-10s"}), ("post", base + "/commands", {"action": "stop"}),
                               ("post", base + "/revoke", None), ("get", base + "/recordings", None), ("post", base + "/recordings/start", {})):
        r = getattr(c, method)(path, headers=bob, **({"json": body} if body is not None else {}))
        assert r.status_code == 404, (path, r.status_code, r.text)
    assert c.get("/api/v6/devices", headers=bob).json()["devices"] == []
    # the device cannot be taken over by another account until its owner revokes it
    r = pair(c, dev, bob)
    assert r.status_code == 409 and r.json()["error"]["code"] == "owned_elsewhere"
    assert c.post(base + "/revoke", headers=alice).status_code == 200
    assert pair(c, dev, bob).status_code == 201
    assert c.get(base, headers=alice).status_code == 404 and c.get(base, headers=bob).status_code == 200
    # profiles and calibrations belong to their owner
    mine = dict(c.get("/api/v6/profiles/aeris-ref-a1", headers=alice).json()["document"], id="alice-cube", name="Alice's cube")
    assert c.post("/api/v6/profiles", json=mine, headers=alice).status_code == 201
    assert c.get("/api/v6/profiles/alice-cube", headers=bob).status_code == 404
    assert all(p["id"] != "alice-cube" for p in c.get("/api/v6/profiles", headers=bob).json()["profiles"])
    assert c.post("/api/v6/profiles", json=dict(mine, name="Bob's"), headers=bob).json()["revision"] == 1
    cal = c.post(base + "/calibrations", json={"measurements": {"imu": IMU, "axes": [axes_result("+z"), axes_result("+y")]}}, headers=bob).json()
    assert c.get(f"/api/v6/calibrations/{cal['id']}", headers=alice).status_code == 404
    # v1 recordings uploaded in jwt mode belong to the uploader
    rec = c.post("/api/v1/hardware/recordings", json=tiny_recording(), headers=alice)
    assert rec.status_code == 201, rec.text
    rid = rec.json()["id"]
    assert c.get(f"/api/v1/hardware/recordings/{rid}", headers=bob).status_code == 404
    assert c.get(f"/api/v1/hardware/recordings/{rid}/export", headers=bob).status_code == 404
    assert rid not in [r["id"] for r in c.get("/api/v1/hardware/recordings", headers=bob).json()["recordings"]]
    assert rid in [r["id"] for r in c.get("/api/v1/hardware/recordings", headers=alice).json()["recordings"]]
    assert c.post("/api/v1/datasets", json={"title": "x", "recording_ids": [rid]}, headers=bob).status_code == 404
    ds = c.post("/api/v1/datasets", json={"title": "alice's", "recording_ids": [rid]}, headers=alice).json()
    assert c.get(f"/api/v1/datasets/{ds['id']}", headers=bob).status_code == 404
    assert ds["id"] not in [d["id"] for d in c.get("/api/v1/datasets", headers=bob).json()["datasets"]]
    # a twin run belongs to the owner of the simulated profile
    tw = c.post("/api/v6/twin/simulate", json={"profile": {"id": "alice-cube", "revision": 1}, "recipe": "edge-hold-10s"}, headers=alice)
    assert tw.status_code == 202, tw.text
    assert tw.json()["twin"]["profile"]["id"] == "alice-cube"
    jid = tw.json()["job"]["id"]
    assert c.get(f"/api/v1/jobs/{jid}", headers=bob).status_code == 404
    assert jid not in [j["id"] for j in c.get("/api/v1/jobs", headers=bob).json()["jobs"]]
    j = wait_job(c, jid, alice)
    assert j["state"] == "complete", j
    run_id = j["result_ref"]["id"]
    run = c.get(f"/api/v1/runs/{run_id}", headers=alice).json()
    assert run["owner"] == "aeris-dev-issuer|alice" and run["twin"]["profile"]["id"] == "alice-cube"
    # one parameter source (PRF-5): the run is labelled by its profile revision's value sources (all nominal-model here)
    assert tw.json()["parameter_set"]["id"] == "profile:alice-cube:r1" and run["validation"] == dict(run["validation"], status="nominal", parameter_set="profile:alice-cube:r1")
    assert c.get(f"/api/v1/runs/{run_id}", headers=bob).status_code == 404
    assert run_id not in [r["id"] for r in c.get("/api/v1/runs", headers=bob).json()["runs"]]
    assert c.post("/api/v1/compare", json={"run_ids": [run_id]}, headers=bob).status_code == 404
    assert c.post("/api/v6/twin/compare", json={"run_id": run_id, "recording_id": rid}, headers=bob).status_code == 404
    cmp = c.post("/api/v6/twin/compare", json={"run_id": run_id, "recording_id": rid}, headers=alice)
    assert cmp.status_code == 200 and cmp.json()["evidence"]["admissible_as_validation_evidence"] is False
    # an expired pairing session is refused
    monkeypatch.setattr(SVC, "PAIR_TTL_S", -1)
    r = pair(c, SoftDevice("synthetic-late"), alice)
    assert r.status_code == 409 and "expired" in r.json()["error"]["message"]


def test_jwt_websocket_tickets(jwt_app):
    c, alice, bob = jwt_app
    assert pair(c, SoftDevice("synthetic-ws"), alice).status_code == 201
    t = c.post("/api/v6/tickets", json={"purpose": "live"}, headers=alice).json()["ticket"]
    with c.websocket_connect(f"/api/v6/devices/synthetic-ws/live?ticket={t}") as ws:
        first = ws.receive_json()
        assert first["type"] == "device" and first["device"]["id"] == "synthetic-ws"
    from starlette.websockets import WebSocketDisconnect
    with pytest.raises(WebSocketDisconnect) as ei:                 # single use
        with c.websocket_connect(f"/api/v6/devices/synthetic-ws/live?ticket={t}") as ws:
            ws.receive_json()
    assert ei.value.code == 4401
    tb = c.post("/api/v6/tickets", json={"purpose": "live"}, headers=bob).json()["ticket"]
    with pytest.raises(WebSocketDisconnect) as ei:                 # bob's ticket does not open alice's device
        with c.websocket_connect(f"/api/v6/devices/synthetic-ws/live?ticket={tb}") as ws:
            ws.receive_json()
    assert ei.value.code == 4404
    tr = c.post("/api/v6/tickets", json={"purpose": "relay"}, headers=alice).json()["ticket"]
    with pytest.raises(WebSocketDisconnect) as ei:                 # a ticket opens only its purpose
        with c.websocket_connect(f"/api/v6/devices/synthetic-ws/live?ticket={tr}") as ws:
            ws.receive_json()
    assert ei.value.code == 4401
    with pytest.raises(WebSocketDisconnect) as ei:                 # a browser page cannot pose as a device
        with c.websocket_connect("/api/v6/device-link", headers={"origin": "http://localhost:8000"}) as ws:
            ws.receive_bytes()
    assert ei.value.code == 4403


def test_backup_and_restore_keep_devices_commands_and_documents(tmp_path):
    from aeris_backend.tools import dbtool
    with TestClient(app_for(tmp_path)) as c:
        assert pair(c, SoftDevice("synthetic-backup")).status_code == 201
        cal = c.post("/api/v6/devices/synthetic-backup/calibrations",
                     json={"measurements": {"imu": IMU, "axes": [axes_result("+z"), axes_result("+x")]}}).json()
        assert c.post("/api/v6/devices/synthetic-backup/lease", json={"holder": "holder-backup"}).json()["epoch"] == 1
    out = dbtool.backup(str(tmp_path / "aeris.sqlite3"), str(tmp_path / "backup.sqlite3"))
    assert out["verified"] and out["verify"]["tables"]["devices"] == 1 and out["verify"]["tables"]["leases"] == 1
    assert out["verify"]["documents"]["calibrations"] == 1
    res = dbtool.restore(str(tmp_path / "backup.sqlite3"), str(tmp_path / "restored" / "aeris.sqlite3"))
    assert res["verified"] and res["schema"]["schema_version"] == 3
    with TestClient(app_for(tmp_path / "restored")) as c:
        assert c.get("/api/v6/devices/synthetic-backup").json()["lease"]["epoch"] == 1
        assert c.get(f"/api/v6/calibrations/{cal['id']}").json()["hash"] == cal["hash"]


def test_twin_run_is_labelled_by_the_profiles_value_sources(tmp_path):
    """PRF-5: groups a profile revision declares measured become the run's parameter set; the coverage rule of
    docs/PARAMETERS.md labels the run (partially measured counts as NOMINAL); nothing becomes VALIDATED."""
    with TestClient(app_for(tmp_path)) as c:
        doc = c.get("/api/v6/profiles/aeris-ref-a1").json()["document"]
        mine = dict(doc, id="measured-cube", name="Measured cube",
                    value_sources={"body": "measured", "wheels": "measured", "motor": "measured", "imu.noise": "nominal-model",
                                   "imu.placement": "measured", "electrical": "datasheet"})
        assert c.post("/api/v6/profiles", json=mine).status_code == 201
        tw = c.post("/api/v6/twin/simulate", json={"profile": {"id": "measured-cube", "revision": 1}, "recipe": "edge-hold-10s"})
        assert tw.status_code == 202, tw.text
        ps = tw.json()["parameter_set"]
        assert ps["id"] == "profile:measured-cube:r1" and ps["status"] == "partially-measured"
        assert ps["source"]["measured_groups"] == ["body", "imu.placement", "motor", "wheels"]
        j = wait_job(c, tw.json()["job"]["id"])
        assert j["state"] == "complete", j
        run = c.get(f"/api/v1/runs/{j['result_ref']['id']}").json()
        cov = run["reproduction"]["parameter_set"]["coverage"]
        assert run["validation"]["status"] == "nominal" and run["validation"]["parameter_set"] == "profile:measured-cube:r1"
        assert "params.m" in cov["measured"] and "wheels.x.KV" in cov["measured"] and "sensor.imu_position_m" in cov["measured"]
        assert "sensor.gyro_noise_dps" in cov["nominal"] and "params.fs" in cov["nominal"] and cov["overridden"] == []
        assert "covers" in run["validation"]["note"] and "validated" not in json.dumps(run["validation"]).lower()


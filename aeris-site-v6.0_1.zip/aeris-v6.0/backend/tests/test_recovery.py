"""Fix B (v5): restart recovery of every non-terminal job state, with deterministic fault injection at
the persistence boundaries (docs/JOBS_AND_RECOVERY.md).

A "crash" here is SimulatedCrash raised by the fault hook at a named point: the job handler stops at
once, the dispatcher is stopped, no cleanup write happens, and the database is left exactly as a
process crash at that point would leave it. A fresh repository and job manager on the same database
file then play the restarted backend. tests/test_process_restart.py does the same with real
processes (os._exit and SIGKILL).
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
import time
import zlib

import pytest

from aeris_backend.jobs.manager import JobManager, SimulatedCrash, row_run_id
from aeris_backend.storage.base import TERMINAL
from aeris_backend.storage.sqlite import SCHEMA_SQL_V1, SchemaError, SqliteRepository

SINGLE = {"mode": "edge", "duration_s": 1, "controller": {"type": "lqr"}, "initial": {"tilt_deg": 2}}
SWEEP = {"name": "recovery", "revision": "1.2", "mode": "grid", "base": {"mode": "edge"}, "controllers": ["lqr", "pid"],
         "variables": [{"key": "tilt_deg", "min": 0, "max": 3, "steps": 4}], "duration_s": 1, "record_hz": 10, "store_runs": True}


class Crash:
    """Fault hook: SimulatedCrash at the nth occurrence of point (optionally also requesting cancellation)."""

    def __init__(self, point, nth=1, action="crash"):
        self.point, self.nth, self.action = point, nth, action
        self.n = 0
        self.fired = False
        self.manager = None

    def __call__(self, point, job_id, info=None):
        if point != self.point:
            return
        self.n += 1
        if self.n != self.nth:
            return
        self.fired = True
        if self.action == "cancel":              # a cancellation request arriving exactly here (no crash)
            self.manager.cancel_events[job_id].set()
            self.manager.repo.update_job(job_id, cancel_requested=1)
            return
        if self.action == "raise":
            raise RuntimeError(f"injected fault at {point}")
        self.manager.dispatcher.cancel()           # the process is gone: nothing else is dispatched
        raise SimulatedCrash(point)


def submit_single(m):
    return m.submit_simulation(SINGLE)


def submit_sweep(m):
    return m.submit_sweep(SWEEP)


async def run_until(db, submit, hook=None, timeout=90, cancel_after=None):
    repo = SqliteRepository(db)
    m = JobManager(repo, workers=1, max_jobs=1, fault_hook=hook)
    if hook is not None:
        hook.manager = m
    await m.start()
    job = submit(m)
    jid = job["id"]
    t0 = time.time()
    crashed = False
    while time.time() - t0 < timeout:
        t = m.active.get(jid)
        if t is not None and t.done():
            crashed = (not t.cancelled()) and isinstance(t.exception(), SimulatedCrash)
            if crashed or repo.get_job(jid)["state"] in TERMINAL:
                break
        if repo.get_job(jid)["state"] in TERMINAL and jid not in m.active:
            break
        await asyncio.sleep(0.005)
    seq = repo.get_job(jid)["seq"]
    m.dispatcher.cancel()
    for t in m.active.values():
        t.cancel()
    m.pool.shutdown(wait=True, cancel_futures=True)
    repo.close()
    return jid, crashed, seq


async def restart(db, policy="resume", timeout=90, jid=None, hook=None):
    repo = SqliteRepository(db)
    m = JobManager(repo, workers=1, max_jobs=1, restart_policy=policy, fault_hook=hook)
    if hook is not None:
        hook.manager = m
    await m.start()
    t0 = time.time()
    while jid is not None and time.time() - t0 < timeout:
        if repo.get_job(jid)["state"] in TERMINAL and jid not in {k for k, v in m.active.items() if not v.done()}:
            break
        await asyncio.sleep(0.01)
    return repo, m


async def shutdown(repo, m):
    await m.stop()
    repo.close()


# ------------------------------------------------------------------ the review's probe
def test_review_probe_analyzing_without_run_fails_visibly_and_is_not_redispatched(tmp_db):
    """v4: analyzing → running raised TransitionError, swallowed; the job stayed analyzing and was re-dispatched
    every second. v5: such a job (no saved run) is FAILED with a visible error at recovery, once."""
    async def go():
        repo = SqliteRepository(tmp_db)
        m = JobManager(repo, workers=1, restart_policy="resume")
        jid = m.submit_simulation({"mode": "edge", "duration_s": 1})["id"]
        repo.update_job(jid, state="initializing")
        repo.update_job(jid, state="running")
        repo.update_job(jid, state="analyzing", progress={"done": 1})
        repo.close()
        repo, m = await restart(tmp_db, jid=jid)
        j = repo.get_job(jid)
        assert j["state"] == "failed" and j["error"]["code"] == "inconsistent_state" and "no run is saved" in j["error"]["message"]
        assert m.recovery_report["jobs"][0]["action"] == "failed: inconsistent_state"
        await asyncio.sleep(2.2)                      # two dispatcher cycles: the terminal job is never picked up again
        assert repo.get_job(jid)["attempts"] == 0 and not m.active
        await shutdown(repo, m)
    asyncio.run(go())


# ------------------------------------------------------------------ single runs at every boundary
@pytest.mark.parametrize("point,saved", [("single.before_compute", False), ("single.before_save", False),
                                         ("single.after_save", True), ("single.before_complete", True)])
@pytest.mark.parametrize("policy", ["resume", "fail"])
def test_single_job_crash_at_each_boundary(tmp_db, point, saved, policy):
    async def go():
        hook = Crash(point)
        jid, crashed, seq0 = await run_until(tmp_db, submit_single, hook)
        assert crashed and hook.fired
        repo = SqliteRepository(tmp_db)
        before = repo.get_job(jid)
        ids = before["extra"]["ids"]                  # identifiers stored with the → RUNNING transition
        assert before["state"] == ("analyzing" if saved else "running")
        assert len(repo.runs_of_job(jid)) == (1 if saved else 0)
        created0 = (repo.get_run(ids["run_id"]) or {}).get("created")
        repo.close()
        repo, m = await restart(tmp_db, policy, jid=jid)
        j = repo.get_job(jid)
        runs = repo.runs_of_job(jid)
        if saved or policy == "resume":
            assert j["state"] == "complete", j
            assert runs == [ids["run_id"]] and j["result_ref"] == {"kind": "run", "id": ids["run_id"]}
            rec = repo.get_run(ids["run_id"])
            assert rec["experiment_id"] == ids["experiment_id"]
            assert j["progress"]["done"] == 1 and j["error"] is None
            if saved:                                  # finished from the saved run: nothing recomputed
                assert rec["created"] == created0 and m.stats["runs_completed"] == 0 and "nothing was recomputed" in j["message"]
            else:
                assert j["restarts"] == 1 and m.stats["runs_completed"] == 1
        else:
            assert j["state"] == "failed" and j["error"]["code"] == "interrupted" and runs == []
        assert j["seq"] > seq0
        await shutdown(repo, m)
    asyncio.run(go())


def test_cancellation_requested_before_a_crash_wins_after_restart(tmp_db):
    async def go():
        # no run saved: cancelled, nothing computed after the restart
        hook = Crash("single.before_save")
        jid, crashed, _ = await run_until(tmp_db, submit_single, hook)
        repo = SqliteRepository(tmp_db)
        repo.update_job(jid, cancel_requested=1)
        repo.close()
        repo, m = await restart(tmp_db, jid=jid)
        j = repo.get_job(jid)
        assert j["state"] == "cancelled" and repo.runs_of_job(jid) == [] and m.stats["runs_completed"] == 0
        await shutdown(repo, m)
        # run saved: cancelled, the finished run is kept and named
        hook = Crash("single.after_save")
        jid, crashed, _ = await run_until(tmp_db, submit_single, hook)
        repo = SqliteRepository(tmp_db)
        repo.update_job(jid, cancel_requested=1)
        rid = repo.runs_of_job(jid)[0]
        repo.close()
        repo, m = await restart(tmp_db, "fail", jid=jid)
        j = repo.get_job(jid)
        assert j["state"] == "cancelled" and j["result_ref"] == {"kind": "run", "id": rid} and repo.runs_of_job(jid) == [rid]
        await shutdown(repo, m)
    asyncio.run(go())


def test_cancel_arriving_right_after_the_save_keeps_the_run(tmp_db):
    async def go():
        hook = Crash("single.after_save", action="cancel")
        jid, crashed, _ = await run_until(tmp_db, submit_single, hook)
        repo = SqliteRepository(tmp_db)
        j = repo.get_job(jid)
        assert not crashed and hook.fired
        assert j["state"] == "cancelled" and j["result_ref"]["kind"] == "run" and repo.runs_of_job(jid) == [j["result_ref"]["id"]]
        repo.close()
    asyncio.run(go())


# ------------------------------------------------------------------ sweeps
@pytest.mark.parametrize("point,nth", [("sweep.row_saved", 3), ("sweep.before_analyzing", 1), ("sweep.after_analyzing", 1), ("sweep.analysis_saved", 1)])
@pytest.mark.parametrize("policy", ["resume", "fail"])
def test_sweep_crash_at_each_boundary(tmp_db, point, nth, policy):
    async def go():
        hook = Crash(point, nth)
        jid, crashed, seq0 = await run_until(tmp_db, submit_sweep, hook)
        assert crashed
        repo = SqliteRepository(tmp_db)
        sid = repo.get_job(jid)["result_ref"]["id"]
        rows0 = repo.row_indices(sid)
        done0 = repo.get_job(jid)["progress"]["done"]
        runs0 = repo.runs_of_job(jid)
        assert len(runs0) == len(rows0)                          # row and run are one transaction
        if point == "sweep.row_saved":
            assert len(rows0) == 3
        else:
            assert len(rows0) == 8
        repo.close()
        repo, m = await restart(tmp_db, policy, jid=jid)
        j = repo.get_job(jid)
        sw = repo.get_sweep(sid)
        rows = sw["rows"]
        runs = repo.runs_of_job(jid)
        assert j["progress"]["done"] >= done0                   # monotone
        assert len(runs) == len(rows) == len({r["index"] for r in rows})
        assert sorted(runs) == sorted(row_run_id(sid, r["index"]) for r in rows)
        assert all(r["run_id"] == row_run_id(sid, r["index"]) for r in rows if r["status"] == "ok")
        interrupted = policy == "fail" and point in ("sweep.row_saved", "sweep.before_analyzing")
        if interrupted:
            assert j["state"] == "failed" and j["error"]["code"] == "interrupted"
            assert sw["status"] == "interrupted" and sw["partial"] is True and len(rows) == len(rows0)
            an = await m.analyze_stored(sid)                      # partial rows can still be analysed on request
            assert sum(v["n"] for v in an["controllers"].values()) == len(rows)
            if len(rows) < 8:
                assert an["partial"] is True and an["notes"][0].startswith("PARTIAL")
        else:
            assert j["state"] == "complete", j
            assert sw["status"] == "complete" and sw["partial"] is False and len(rows) == 8
            assert sum(v["n"] for v in sw["analysis"]["controllers"].values()) == 8
        await shutdown(repo, m)
    asyncio.run(go())


def test_sweep_cancel_requested_then_crash_finishes_cancelled_with_partial_analysis(tmp_db):
    async def go():
        hook = Crash("sweep.row_saved", 3)
        jid, crashed, _ = await run_until(tmp_db, submit_sweep, hook)
        repo = SqliteRepository(tmp_db)
        repo.update_job(jid, cancel_requested=1)
        sid = repo.get_job(jid)["result_ref"]["id"]
        repo.close()
        repo, m = await restart(tmp_db, "resume", jid=jid)
        j = repo.get_job(jid)
        sw = repo.get_sweep(sid)
        assert j["state"] == "cancelled" and sw["status"] == "cancelled" and sw["partial"] is True and len(sw["rows"]) == 3
        assert sw["analysis"]["partial"] is True and sum(v["n"] for v in sw["analysis"]["controllers"].values()) == 3
        assert len(repo.runs_of_job(jid)) == 3
        await shutdown(repo, m)
    asyncio.run(go())


# ------------------------------------------------------------------ bounded redispatch, visible errors
def test_a_job_that_crashes_every_time_is_failed_after_the_attempt_limit(tmp_db):
    async def go():
        jid, crashed, _ = await run_until(tmp_db, submit_single, Crash("single.before_compute"))
        assert crashed
        for k in range(2):                                       # restarts 1 and 2 crash again at the same point
            hook = Crash("single.before_compute")
            repo, m = await restart(tmp_db, hook=hook)
            t0 = time.time()
            while not hook.fired and time.time() - t0 < 30:
                await asyncio.sleep(0.01)
            assert hook.fired
            m.pool.shutdown(wait=True, cancel_futures=True)
            repo.close()
        repo, m = await restart(tmp_db, jid=jid)                  # the fourth dispatch is refused
        j = repo.get_job(jid)
        assert j["state"] == "failed" and j["error"]["code"] == "retry_limit" and j["attempts"] == 4
        assert repo.runs_of_job(jid) == []
        await shutdown(repo, m)
    asyncio.run(go())


def test_unexpected_errors_become_failed_jobs_not_silent_retries(tmp_db):
    async def go():
        jid, crashed, _ = await run_until(tmp_db, submit_single, Crash("single.before_save", action="raise"))
        repo = SqliteRepository(tmp_db)
        j = repo.get_job(jid)
        assert j["state"] == "failed" and j["error"]["code"] == "internal" and "injected fault at single.before_save" in j["error"]["message"]
        assert j["attempts"] == 1 and repo.runs_of_job(jid) == []
        repo.close()
    asyncio.run(go())


def test_a_failure_that_cannot_be_recorded_quarantines_the_job(tmp_db):
    async def go():
        repo = SqliteRepository(tmp_db)
        hook = Crash("single.before_save", action="raise")
        m = JobManager(repo, workers=1, max_jobs=1, fault_hook=hook)
        hook.manager = m
        orig = repo.update_job

        def update_job(job_id, **kw):
            if kw.get("state") == "failed":
                raise sqlite3.OperationalError("disk I/O error (injected)")
            return orig(job_id, **kw)
        repo.update_job = update_job
        await m.start()
        jid = m.submit_simulation(SINGLE)["id"]
        t0 = time.time()
        while jid not in m.quarantine and time.time() - t0 < 30:
            await asyncio.sleep(0.02)
        assert jid in m.quarantine and "disk I/O error" in m.quarantine[jid]
        await asyncio.sleep(2.2)                                # the dispatcher does not pick it up again
        assert repo.get_job(jid)["attempts"] == 1 and repo.get_job(jid)["state"] == "running"
        await shutdown(repo, m)
    asyncio.run(go())


def test_transition_error_inside_a_handler_is_reported(tmp_db):
    async def go():
        repo = SqliteRepository(tmp_db)
        m = JobManager(repo, workers=1, max_jobs=1)
        orig = repo.update_job

        def update_job(job_id, **kw):
            if kw.get("state") == "complete":
                from aeris_backend.storage.base import TransitionError
                raise TransitionError("illegal job transition analyzing → complete (injected)")
            return orig(job_id, **kw)
        repo.update_job = update_job
        await m.start()
        jid = m.submit_simulation(SINGLE)["id"]
        t0 = time.time()
        while repo.get_job(jid)["state"] not in TERMINAL and time.time() - t0 < 30:
            await asyncio.sleep(0.02)
        j = repo.get_job(jid)
        assert j["state"] == "failed" and j["error"]["code"] == "illegal_transition" and "(injected)" in j["error"]["message"]
        assert len(repo.runs_of_job(jid)) == 1                  # the saved run stays; the failure is visible
        await shutdown(repo, m)
    asyncio.run(go())


# ------------------------------------------------------------------ database migration
def _v4_db(path, record):
    """A database as AERIS v4 left it (schema version 1), with the states v4's non-atomic saves could produce."""
    db = sqlite3.connect(path, isolation_level=None)
    db.executescript(SCHEMA_SQL_V1)
    db.execute("INSERT INTO meta(key, value) VALUES ('schema_version', '1')")

    def job(jid, state, done=0):
        db.execute("INSERT INTO jobs(id, kind, state, created, updated, done, total, failed, message, request, seq, extra) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                   (jid, "single", state, "2026-09-01T00:00:00.000Z", "2026-09-01T00:00:00.000Z", done, 1, 0, "", json.dumps({"config": record["config"], "meta": {}}), 3, "{}"))

    def run(rid, exp, jid, created):
        r = dict(record, id=rid, experiment_id=exp, created=created)
        db.execute("INSERT INTO runs(id, experiment_id, created, name, mode, controller, outcome, job_id, sweep_id, row_index, config_hash, record) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                   (rid, exp, created, "v4 run", "edge", "lqr", "recovered", jid, None, None, "sha256:x", zlib.compress(json.dumps(r).encode())))
    job("job-v4-analyzing", "analyzing", 1)                      # crash between → analyzing and → complete
    run("run-a", "AERIS-EXP-100001", "job-v4-analyzing", "2026-09-01T00:00:01.000Z")
    job("job-v4-duplicate", "running", 0)                        # crash after save_run, then v4 recomputed: two runs
    run("run-b1", "AERIS-EXP-100002", "job-v4-duplicate", "2026-09-01T00:00:02.000Z")
    run("run-b2", "AERIS-EXP-100003", "job-v4-duplicate", "2026-09-01T00:00:03.000Z")
    job("job-v4-done", "complete", 1)
    db.close()


def _record():
    from aeris_backend.experiments.records import build_record
    from aeris_backend.simulation import simulate
    return build_record(simulate(SINGLE), {}, experiment_id="AERIS-EXP-100000")


def test_v4_database_is_migrated_and_its_unfinished_jobs_finished_without_duplicates(tmp_db):
    _v4_db(tmp_db, _record())

    async def go():
        repo, m = await restart(tmp_db, jid="job-v4-duplicate")
        info = repo.schema_info()
        assert info["schema_version"] == 3 and info["migrations"][0]["version"] == 2 and info["migrations"][1]["version"] == 3
        notes = info["migrations"][0]["notes"]
        assert notes["duplicates_single_job"] == [{"job_id": "job-v4-duplicate", "runs": 2}]
        assert "runs_one_per_job" not in notes["unique_indexes"] and "runs_one_per_row" in notes["unique_indexes"]
        assert info["warnings"] and "kept" in info["warnings"][0]
        a = repo.get_job("job-v4-analyzing")
        assert a["state"] == "complete" and a["result_ref"] == {"kind": "run", "id": "run-a"}
        b = repo.get_job("job-v4-duplicate")
        assert b["state"] == "complete" and b["result_ref"] == {"kind": "run", "id": "run-b1"} and "2 runs were saved" in b["message"]
        assert repo.runs_of_job("job-v4-duplicate") == ["run-b1", "run-b2"]     # user data is never deleted
        assert repo.get_job("job-v4-done")["state"] == "complete"
        assert m.stats["runs_completed"] == 0
        await shutdown(repo, m)
    asyncio.run(go())


def test_fresh_database_has_the_unique_result_indexes(tmp_db):
    repo = SqliteRepository(tmp_db)
    info = repo.schema_info()
    assert info["schema_version"] == 3 and set(info["migrations"][0]["notes"]["unique_indexes"]) == {"runs_one_per_job", "runs_one_per_row"}
    rec = _record()
    repo.create_job({"id": "j", "kind": "single", "created": "t"})
    repo.update_job("j", state="initializing")
    repo.update_job("j", state="running", progress={"total": 1})
    with pytest.raises(sqlite3.IntegrityError):                   # the index backs the code's rule
        repo.save_run(dict(rec, id="r1", experiment_id="E1"), job_id="j")
        repo.save_run(dict(rec, id="r2", experiment_id="E2"), job_id="j")
    repo.close()


def test_database_from_a_newer_schema_is_refused_unchanged(tmp_db):
    repo = SqliteRepository(tmp_db)
    repo.db.execute("UPDATE meta SET value='4' WHERE key='schema_version'")
    repo.close()
    before = hashlib.sha256(open(tmp_db, "rb").read()).hexdigest()
    with pytest.raises(SchemaError):
        SqliteRepository(tmp_db)
    assert hashlib.sha256(open(tmp_db, "rb").read()).hexdigest() == before


def test_one_backend_process_per_database(tmp_db):
    from aeris_backend.storage.sqlite import DatabaseInUse
    a = SqliteRepository(tmp_db, exclusive=True)
    with pytest.raises(DatabaseInUse):
        SqliteRepository(tmp_db, exclusive=True)
    a.close()
    b = SqliteRepository(tmp_db, exclusive=True)                  # released on close
    b.close()


def test_job_update_queue_is_bounded_and_always_keeps_the_newest_state(tmp_db):
    """A live-update subscriber that falls behind (a stalled WebSocket client) holds at most AERIS_SUBSCRIBER_QUEUE
    messages: the oldest job update is dropped for the newest (each update carries the full state), log lines are
    dropped when the queue is full, and nothing blocks the job."""
    repo = SqliteRepository(tmp_db)
    try:
        m = JobManager(repo, workers=1)
        m.queue_limit = 5
        q = m.subscribe("AERIS-JOB-1")
        for i in range(20):
            m._publish({"id": "AERIS-JOB-1", "seq": i, "state": "running"})
        m.log("AERIS-JOB-1", "a log line while the queue is full")
        assert q.qsize() == 5
        got = [q.get_nowait() for _ in range(5)]
        assert [g["seq"] for g in got] == [15, 16, 17, 18, 19] and all(g["type"] == "job" for g in got)
        m.unsubscribe("AERIS-JOB-1", q)
        assert "AERIS-JOB-1" not in m.subs
    finally:
        repo.close()

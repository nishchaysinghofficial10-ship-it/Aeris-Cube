"""Start-up options: the static site served on the backend's origin (scripts/start.sh), and the command line."""
from __future__ import annotations

import os
import subprocess
import sys
import time
import urllib.request

import pytest
from fastapi.testclient import TestClient

from aeris_backend.api.app import create_app

SITE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "site")


def test_site_is_served_on_the_same_origin_with_its_backend_address(tmp_path):
    app = create_app({"db": str(tmp_path / "s.sqlite3"), "workers": 1, "max_jobs": 1, "site_dir": SITE, "telemetry_dir": str(tmp_path)})
    with TestClient(app) as c:
        r = c.get("/")
        assert r.status_code == 200 and r.headers["content-type"].startswith("text/html")
        i_cfg, i_first = r.text.find("window.AERIS_CONFIG = {researchApi: {baseUrl: location.origin"), r.text.find('<script defer src="vendor/three.min.js">')
        assert 0 < i_cfg < i_first                                                     # the address is set before any site script runs
        assert c.get("/index.html").text == r.text
        assert c.get("/js/core.js").status_code == 200 and "AERIS_TWIN" in c.get("/js/core.js").text
        assert c.get("/api/v1/health").json()["status"] == "ok"                        # the API keeps its routes
        assert c.get("/js/nope.js").status_code == 404
    with pytest.raises(ValueError, match="no index.html"):
        create_app({"db": str(tmp_path / "t.sqlite3"), "site_dir": str(tmp_path)})


def test_command_line_serves_site_and_api_on_one_loopback_port(tmp_path):
    import socket
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    env = dict(os.environ, PYTHONUNBUFFERED="1")
    p = subprocess.Popen([sys.executable, "-m", "aeris_backend.api.main", "--port", str(port), "--db", str(tmp_path / "cli.sqlite3"), "--workers", "1",
                          "--serve-site", SITE, "--telemetry-dir", str(tmp_path), "--log-level", "info"],
                         cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        t0 = time.time()
        while time.time() - t0 < 40:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/v1/health", timeout=2) as r:
                    if r.status == 200:
                        break
            except OSError:
                time.sleep(0.2)
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=5) as r:
            assert "AERIS_CONFIG" in r.read().decode()
        p.terminate()                                                                   # clean shutdown on SIGTERM
        code = p.wait(timeout=30)
        out = p.stdout.read().decode()
        # uvicorn shuts down gracefully (lifespan: telemetry bridge closed, job manager stopped, database closed) and then
        # re-raises the signal, so the exit status is -15 after a clean shutdown
        assert code in (0, -15) and "Application shutdown complete" in out, (code, out[-800:])
        from aeris_backend.storage.sqlite import SqliteRepository
        SqliteRepository(str(tmp_path / "cli.sqlite3"), exclusive=True).close()          # the single-process lock was released
    finally:
        if p.poll() is None:
            p.kill()

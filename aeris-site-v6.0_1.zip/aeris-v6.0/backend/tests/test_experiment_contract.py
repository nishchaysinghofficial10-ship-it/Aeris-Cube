"""The v5 experiment contract (configuration revision 1.2; docs/EXPERIMENT_CONTRACT.md): explicit initial
state, reference/objective block, requested target vs plant equilibrium, recovery summaries, and the
field-specific refusals for unsupported combinations."""
from __future__ import annotations

import math

import pytest

from aeris_backend.config.normalize import normalize
from aeris_backend.config.validate import validate_config
from aeris_backend.constants import DEG
from aeris_backend.experiments import sweeps as SW
from aeris_backend.metrics.research import recovery
from aeris_backend.physics.mass import mass_properties
from aeris_backend.physics.quaternion import angle_between, axis_angle, edge_quat, qmul
from aeris_backend.simulation import simulate
from aeris_backend.simulation.setup import initial_state

from conftest import engine_for


def errs(raw, path=None):
    v = validate_config(raw)
    return [e for e in v.errors if path is None or e["path"] == path]


# ------------------------------------------------------------------ explicit initial state
@pytest.mark.parametrize("mode,legacy", [("corner", {"tilt_deg": 3, "rate_dps": 10, "azimuth_deg": 40, "reference": "balance"}),
                                         ("corner", {"tilt_deg": -2, "rate_dps": -5, "azimuth_deg": 0, "reference": "geometric"}),
                                         ("edge", {"tilt_deg": 2.5, "rate_dps": 8, "reference": "geometric"}),
                                         ("edge", {"tilt_deg": 1, "rate_dps": 0, "reference": "balance"})])
def test_explicit_state_equal_to_the_legacy_inputs_gives_the_identical_run(mode, legacy):
    base = {"mode": mode, "controller": {"type": "lqr"}, "duration_s": 1.5, "attachments": [{"label": "m", "mass_kg": 0.04, "pos_m": [0.03, 0.12, 0.1]}]}
    a_cfg = dict(base, initial=legacy)
    v = validate_config(a_cfg)
    ini = initial_state(v.config, v.mp)
    if mode == "edge":
        phi = math.pi / 4 + ini["theta"]
        explicit = {"attitude_q": [math.cos(phi / 2), math.sin(phi / 2), 0.0, 0.0], "body_rate_dps": [ini["thetadot"] / DEG, 0.0, 0.0]}
    else:
        explicit = {"attitude_q": list(ini["q"]), "body_rate_dps": [x / DEG for x in ini["w"]]}
    a = engine_for(a_cfg).run()
    b = engine_for(dict(base, initial=explicit)).run()
    for c in a["samples"]["cols"]:
        assert all(abs(x - y) <= 1e-9 * max(1.0, abs(x)) for x, y in zip(a["samples"]["cols"][c], b["samples"]["cols"][c])), c
    r = simulate(dict(base, initial=explicit))
    assert r["executed"]["initial_state"]["attitude_from"] == "explicit attitude quaternion"
    assert r["config"]["initial"]["tilt_deg"] is None and r["config"]["config_revision"] == "1.2"


def test_non_unit_quaternion_is_refused_and_a_near_unit_one_renormalised():
    e = errs({"mode": "corner", "initial": {"attitude_q": [1, 0.1, 0, 0]}}, "initial.attitude_q")
    assert e and "unit quaternion" in e[0]["message"] and "1.00498756" in e[0]["message"]
    q = [0.88099055 * (1 + 5e-7), 0.33997898, -0.32901952, -0.00401144]
    v = validate_config({"mode": "corner", "initial": {"attitude_q": q}})
    assert v.ok and any(w["path"] == "initial.attitude_q" and "renormalised" in w["message"] for w in v.warnings)
    assert abs(math.sqrt(sum(x * x for x in v.config["initial"]["attitude_q"])) - 1) < 1e-15


def test_conflicting_legacy_and_explicit_inputs_are_refused():
    assert errs({"mode": "corner", "initial": {"attitude_q": [0.88099055, 0.33997898, -0.32901952, -0.00401144], "tilt_deg": 2}}, "initial.attitude_q")
    assert errs({"mode": "corner", "initial": {"body_rate_dps": [1, 0, 0], "rate_dps": 3}}, "initial.body_rate_dps")
    # an explicit attitude with a legacy (axis-less) rate in corner mode
    assert errs({"mode": "corner", "initial": {"attitude_q": [0.88099055, 0.33997898, -0.32901952, -0.00401144], "rate_dps": 5}}, "initial.rate_dps")
    # null legacy fields are fine (what the frontend sends)
    assert validate_config({"mode": "corner", "initial": {"attitude_q": [0.88099055, 0.33997898, -0.32901952, -0.00401144], "tilt_deg": None,
                                                          "azimuth_deg": None, "reference": None, "body_rate_dps": [0, 0, 1], "rate_dps": None}}).ok


def test_edge_mode_accepts_only_rotations_about_the_hinge():
    ok_q = list(edge_quat(2 * DEG))
    assert validate_config({"mode": "edge", "initial": {"attitude_q": ok_q, "body_rate_dps": [5, 0, 0]}}).ok
    off = list(qmul(edge_quat(0.0), axis_angle((0.0, 1.0, 0.0), 1 * DEG)))
    e = errs({"mode": "edge", "initial": {"attitude_q": off}}, "initial.attitude_q")
    assert e and "support edge" in e[0]["message"] and "1°" in e[0]["message"].replace("0.9999", "1") or "off that axis" in e[0]["message"]
    assert errs({"mode": "edge", "initial": {"body_rate_dps": [1, 0.5, 0]}}, "initial.body_rate_dps")


def test_initial_attitude_through_the_floor_is_refused():
    e = errs({"mode": "corner", "initial": {"attitude_q": [1, 0, 0, 0]}})       # body = world: faces on the floor plane
    assert any(x["path"] == "initial" and "floor" in x["message"] for x in e)


def test_initial_wheel_speeds_and_body_rate_start_the_run():
    r = simulate({"mode": "corner", "controller": {"type": "none"}, "duration_s": 0.5,
                  "initial": {"attitude_q": list(initial_state(normalize({"mode": "corner"})[0], mass_properties(normalize({"mode": "corner"})[0]))["q"]),
                              "body_rate_dps": [4, -3, 2], "wheel_speeds_rpm": [300, -200, 100]}})
    S = r["samples"]["cols"]
    assert [round(S[c][0] / DEG, 4) for c in ("wx", "wy", "wz")] == [4, -3, 2]
    assert [round(S[c][0] * 60 / (2 * math.pi), 3) for c in ("omega_x", "omega_y", "omega_z")] == [300, -200, 100]


# ------------------------------------------------------------------ reference / objective
def test_unsupported_objectives_are_refused_with_field_specific_errors():
    e = errs({"mode": "corner", "reference": {"attitude": "tilted"}}, "reference.attitude")
    assert e and "not an equilibrium" in e[0]["message"] and "not projected" in e[0]["message"]
    assert errs({"mode": "edge", "reference": {"heading": "free"}}, "reference.heading")
    assert errs({"mode": "corner", "controller": {"type": "lqr", "structure": "mimo-lqr"}, "reference": {"heading": "free"}}, "reference.heading")
    assert errs({"mode": "corner", "reference": {"heading": "free"}, "commands": [{"type": "yaw_step", "t_s": 1, "angle_deg": 30}]}, "commands")
    assert errs({"mode": "corner", "reference": {"heading": "free", "yaw_deg": 20}}, "reference.yaw_deg")
    assert errs({"mode": "corner", "reference": {"heading": "free"}, "recovery": {"yaw_objective": "hold"}}, "recovery.yaw_objective")
    assert errs({"mode": "corner", "reference": {"heading": "hold", "extra": 1}}, "reference.extra")


def test_heading_offset_is_tracked_and_is_the_recovery_target():
    r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "duration_s": 8, "initial": {"tilt_deg": 0.5}, "reference": {"yaw_deg": 20}})
    psi_end = r["samples"]["cols"]["psi"][-1] / DEG
    assert abs(psi_end - 20) < 1.0
    assert all(abs(x / DEG - 20) < 1e-4 for x in r["samples"]["cols"]["psiRef"])      # samples keep 6 significant digits
    rc = r["research"]["recovery"]
    assert "+ 20°" in rc["target"] and rc["recovered"]
    assert r["executed"]["reference"]["requested"]["yaw_deg"] == 20


def test_free_heading_is_not_corrected_and_the_criteria_follow_it():
    """A yaw rate about the vertical at t = 0: 'hold' brings the heading back, 'free' only damps the rate."""
    from aeris_backend.physics.quaternion import mtv, rot
    c0 = normalize({"mode": "corner"})[0]
    q0 = initial_state(c0, mass_properties(c0))["q"]
    w_body = [x / DEG for x in mtv(rot(q0), (0.0, 0.0, 20 * DEG))]           # 20 °/s about world z, in body axes
    common = {"mode": "corner", "controller": {"type": "lqr"}, "duration_s": 8, "initial": {"attitude_q": list(q0), "body_rate_dps": w_body}}
    hold = simulate(common)
    free = simulate(dict(common, reference={"heading": "free"}))
    assert hold["ok"] and free["ok"]
    psi_hold, psi_free = hold["samples"]["cols"]["psi"][-1] / DEG, free["samples"]["cols"]["psi"][-1] / DEG
    assert abs(psi_hold) < 0.5                 # returned to the initial heading
    assert abs(psi_free) > 2.0                 # displaced heading left as it is (rate damped, no heading feedback)
    yaw_rate_end = abs(free["samples"]["cols"]["wz"][-1]) / DEG
    assert yaw_rate_end < 0.5
    assert free["config"]["recovery"]["yaw_objective"] == "free" and "any heading" in free["research"]["recovery"]["target"]
    assert free["executed"]["reference"]["requested"]["heading"] == "free"


def test_requested_target_vs_plant_equilibrium_is_recorded():
    att = [{"label": "m", "mass_kg": 0.06, "pos_m": [0.02, 0.1, 0.12]}]
    blind = simulate({"mode": "corner", "duration_s": 1, "attachments": att})["executed"]["reference"]
    known = simulate({"mode": "corner", "duration_s": 1, "attachments": att, "controller": {"type": "lqr", "knowsAttachments": True}})["executed"]["reference"]
    assert blind["target_offset_deg"] > 0.5 and known["target_offset_deg"] < 1e-9
    e = simulate({"mode": "edge", "duration_s": 1, "attachments": att})["executed"]["reference"]
    assert e["plant_equilibrium"]["kind"].startswith("centre of mass above the support edge") and e["target_offset_deg"] > 0.1


# ------------------------------------------------------------------ recovery summary: first, sustained, exits, falls
def _ctx(n, dt, **rec):
    crit = dict({"attitude_error_deg": 1.0, "rate_dps": 1000.0, "hold_s": 0.1, "max_time_s": None, "yaw_objective": "hold"}, **rec)
    return {"mode": "edge", "dt": dt, "recovery": crit, "window_s": n * dt, "fellAt": None}


def _full(err_deg):
    n = len(err_deg) - 1
    return {"nSteps": n, "e": [x * DEG for x in err_deg], "rate": [0.0] * (n + 1)}


def test_recovery_distinguishes_first_sustained_exits_and_falls():
    dt = 0.01
    sig = [5.0] * 20 + [0.5] * 30 + [3.0] * 10 + [0.5] * 41            # enter at 0.20 s, exit at 0.50 s, re-enter at 0.60 s
    r = recovery(_full(sig), _ctx(len(sig) - 1, dt))
    assert r["recovered"] and r["first_recovery_s"] == pytest.approx(0.20) and r["exits_after_recovery"] == 1
    assert r["last_exit_s"] == pytest.approx(0.50) and r["sustained"] is False and r["sustained_from_s"] == pytest.approx(0.60)
    sig2 = [5.0] * 20 + [0.5] * 81
    r2 = recovery(_full(sig2), _ctx(len(sig2) - 1, dt))
    assert r2["sustained"] and r2["exits_after_recovery"] == 0 and r2["sustained_from_s"] == pytest.approx(0.20)
    c = _ctx(len(sig2) - 1, dt)
    c["fellAt"] = 0.9
    r3 = recovery(_full(sig2), c)
    assert r3["recovered"] and r3["fell_after_recovery"] and not r3["sustained"]
    r4 = recovery(_full(sig2), _ctx(len(sig2) - 1, dt, max_time_s=0.1))          # deadline before the first entry
    assert not r4["recovered"] and r4["first_entry_s"] == pytest.approx(0.20) and r4["within_max_time"] is False
    assert "by t = 0.1 s" in r4["summary"]


# ------------------------------------------------------------------ sweeps carry the new fields
def test_sweep_paths_over_the_new_fields_and_conflicting_named_variables():
    base = {"mode": "corner", "initial": {"attitude_q": [0.88099055, 0.33997898, -0.32901952, -0.00401144], "body_rate_dps": [0, 0, 0]}, "reference": {"yaw_deg": 0}}
    d = {"revision": "1.2", "mode": "grid", "base": base, "controllers": ["lqr"], "duration_s": 1, "criterion": "research",
         "variables": [{"path": "initial.body_rate_dps.0", "min": -20, "max": 20, "steps": 3}, {"path": "reference.yaw_deg", "min": 0, "max": 30, "steps": 2}]}
    v = SW.validate_def(d)
    assert v["ok"], v["errors"]
    specs = SW.expand(v["def"])
    assert len(specs) == 6
    rows = [SW.row_of(s, simulate(s["config"])) for s in specs]
    assert all(r["status"] == "ok" for r in rows)
    assert sorted({(s["config"]["initial"]["body_rate_dps"][0], s["config"]["reference"]["yaw_deg"]) for s in specs}) == [(-20, 0), (-20, 30), (0, 0), (0, 30), (20, 0), (20, 30)]
    an = SW.analyze(v["def"], rows)
    assert an["criterion"] == "research" and sum(c["n"] for c in an["controllers"].values()) == 6
    bad = SW.validate_def(dict(d, variables=[{"key": "tilt_deg", "min": 0, "max": 3, "steps": 2}]))
    assert not bad["ok"] and "attitude_q" in bad["errors"][0]["message"]


def test_reproduction_of_a_revision_1_2_run_is_identical():
    cfg = {"mode": "corner", "controller": {"type": "nlpd"}, "estimator": {"type": "mekf", "stale_after_s": 0.03}, "duration_s": 2, "seed": 4,
           "initial": {"attitude_q": [0.88099055, 0.33997898, -0.32901952, -0.00401144], "body_rate_dps": [2, -1, 0]},
           "reference": {"yaw_deg": 10}, "sensor": {"rate_hz": 100}}
    a, b = simulate(cfg), simulate(simulate(cfg)["config"])
    assert a["samples"]["cols"] == b["samples"]["cols"] and a["research"] == b["research"]

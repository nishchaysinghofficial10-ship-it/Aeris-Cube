"""Controller designs (Riccati residuals, stability, controllability, unsupported cases), the
MIMO LQR, the nonlinear controller, research recovery criteria, termination and metrics."""
import math

import numpy as np
import pytest

from aeris_backend.config.validate import validate_config
from aeris_backend.constants import DEG, LQR_DEFAULTS, NOMINAL, PID_DEFAULTS, RPM
from aeris_backend.control.design import DesignError, controllable_subspace, corner_linearization, design_mimo, design_tilt, lqr, pbh
from aeris_backend.physics.mass import steiner
from aeris_backend.simulation import simulate


def bare():
    a, m = NOMINAL["a"], NOMINAL["m"]
    r = np.array([a / 2] * 3)
    return NOMINAL["kJ"] * m * a * a * np.eye(3) + steiner(m, r), m, r


def test_tilt_design_riccati_residual_and_stability():
    d = design_tilt(0.0403, 0.0408, 2.25, 5e-4, 0.1528, LQR_DEFAULTS, PID_DEFAULTS, 2e-4)
    assert d["riccati_residual"] < 1e-9
    assert all(r[0] < 0 for r in d["cl"])
    assert all(r[0] < 0 for r in d["pidPoles"]) and all(r[0] < 0 for r in d["adpPoles"])
    assert all(c["controllable"] for c in d["controllability"])


def test_unphysical_and_unstabilisable_designs_raise():
    with pytest.raises(DesignError):
        design_tilt(-1, 0.04, 2.25, 5e-4, 0.15, LQR_DEFAULTS, PID_DEFAULTS, 2e-4)
    A = np.array([[1.0, 0], [0, 2.0]])
    B = np.array([[1.0], [0.0]])                     # the mode at +2 is not controllable
    assert not pbh(A, B)[1]["controllable"]
    with pytest.raises(DesignError):
        lqr(A, B, np.eye(2), np.eye(1))


def test_mimo_linearisation_rank_and_conserved_vertical_momentum():
    ThO, M, rc = bare()
    L = corner_linearization(ThO, M, rc, 9.81, np.eye(3).tolist(), [5e-4] * 3)
    Vc, Vu, r, _ = controllable_subspace(L["A"], L["B"])
    assert r == 8 and Vu.shape[1] == 1
    # the uncontrollable direction is the vertical angular momentum u·(Θ_O ω + J Ω)
    u = L["u"]
    h = np.concatenate([np.zeros(3), ThO @ u, 5e-4 * u])
    h /= np.linalg.norm(h)
    assert abs(abs(Vu[:, 0] @ h) - 1) < 1e-9 or np.linalg.norm(L["A"].T @ h) < 1e-9
    # h is conserved by the linear dynamics: hᵀ A = 0 and hᵀ B = 0
    assert np.allclose(h @ L["A"], 0, atol=1e-9) and np.allclose(h @ L["B"], 0, atol=1e-9)


def test_mimo_design_uses_full_tensor_and_is_stable():
    ThO, M, rc = bare()
    ThO2 = ThO + np.array([[0, 4e-4, -2e-4], [4e-4, 0, 3e-4], [-2e-4, 3e-4, 0]])   # products of inertia
    d1 = design_mimo(ThO, M, rc, 9.81, np.eye(3).tolist(), [5e-4] * 3, [0.1528] * 3, LQR_DEFAULTS)
    d2 = design_mimo(ThO2, M, rc, 9.81, np.eye(3).tolist(), [5e-4] * 3, [0.1528] * 3, LQR_DEFAULTS)
    assert d1["gain_shape"] == [3, 9] and d1["controllable_rank"] == 8
    assert all(e[0] < 0 for e in d1["cl_reduced"]) and all(e[0] < 0 for e in d2["cl_reduced"])
    assert d1["riccati_residual"] < 1e-9
    # the gains change when the products of inertia change: the design is genuinely coupled
    assert np.max(np.abs(np.array(d1["K"]) - np.array(d2["K"]))) > 1e-3
    # a coupled gain: tilt about x feeds more than one wheel
    K = np.array(d2["K"])
    assert np.count_nonzero(np.abs(K[:, 0]) > 1e-6) >= 2


def test_mimo_is_not_three_scalar_loops_and_runs():
    r = simulate({"mode": "corner", "controller": {"type": "lqr", "structure": "mimo-lqr"}, "initial": {"tilt_deg": 3, "rate_dps": 10, "azimuth_deg": 60}, "duration_s": 5})
    assert r["ok"] and r["outcome"]["code"] == "recovered"
    assert r["executed"]["controller"]["structure"] == "mimo-lqr"
    assert r["design"]["mimo"]["uncontrollable_eigenvalues"][0][0] == pytest.approx(0, abs=1e-9)


def test_mimo_rejected_where_it_does_not_apply():
    for cfg, path in (({"mode": "edge", "controller": {"type": "lqr", "structure": "mimo-lqr"}}, "controller.structure"),
                      ({"mode": "corner", "controller": {"type": "pid", "structure": "mimo-lqr"}}, "controller.structure")):
        v = validate_config(cfg)
        assert not v.ok and v.errors[0]["path"] == path and v.errors[0]["kind"] == "capability"


def test_mimo_redesign_after_failure_is_reported():
    r = simulate({"mode": "corner", "controller": {"type": "lqr", "structure": "mimo-lqr"}, "events": [{"type": "wheel_failure", "wheel": "z", "t_s": 1.5}], "duration_s": 4})
    red = r["executed"]["controller"]["redesigns"]
    assert red and red[0]["wheels"] == ["x", "y"]
    assert any(e["type"] == "controller_mode" for e in r["timeline"]["events"])


def test_nonlinear_controller_recovers_and_manages_momentum():
    r = simulate({"mode": "edge", "controller": {"type": "nlpd"}, "comOffset_m": 0.004, "duration_s": 12})
    assert r["outcome"]["code"] == "recovered"
    # the momentum loop brings the wheel back (a pure PD with gravity compensation would drift)
    assert abs(r["metrics"]["finalOmega_rpm"]["x"]) < 200
    assert r["executed"]["controller"]["type"] == "nlpd"
    rc = simulate({"mode": "corner", "controller": {"type": "nlpd"}, "comShift_m": [0.003, -0.002, 0.001], "duration_s": 12})
    assert rc["outcome"]["code"] == "recovered"


def test_nonlinear_controller_limits_are_honest():
    """Beyond the torque capability no controller recovers: the nonlinear law is not magic."""
    r = simulate({"mode": "edge", "controller": {"type": "nlpd"}, "initial": {"tilt_deg": 12}, "duration_s": 4})
    assert r["outcome"]["code"] == "fallen"


def test_no_silent_controller_substitution():
    r = simulate({"mode": "corner", "controller": {"type": "adp"}, "duration_s": 2})
    assert r["executed"]["controller"]["type"] == "adp" and r["executed"]["controller"]["name"] == "COM-adaptive LQR"
    v = validate_config({"mode": "corner", "controller": {"type": "sliding-mode"}})
    assert not v.ok and v.errors[0]["path"] == "controller.type"


# ---------------------------------------------------------------- recovery, termination, metrics
def test_research_recovery_criteria_saved_and_evaluated():
    crit = {"attitude_error_deg": 0.3, "rate_dps": 1.0, "hold_s": 0.8, "max_time_s": 3.0, "yaw_objective": "hold"}
    r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "recovery": crit, "duration_s": 5})
    rr = r["research"]["recovery"]
    assert rr["criteria"] == crit and r["config"]["recovery"] == crit
    assert rr["recovered"] and rr["t_s"] <= 3.0
    # tighter than the legacy band: the research time is not the legacy settling time by definition
    assert rr["objective"] == "hold"


def test_yaw_objective_relinquished_after_failure_is_labelled():
    r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "events": [{"type": "wheel_failure", "wheel": "z", "t_s": 1}], "duration_s": 4})
    rr = r["research"]["recovery"]
    assert rr["objective"] == "hold" and rr["objective_effective"].startswith("free")
    assert rr["objective_note"] and "relinquished" in rr["objective_note"]
    assert any(e["type"] == "yaw_objective" for e in r["timeline"]["events"])


def test_legacy_recovered_can_coexist_with_yaw_rotation():
    """Legacy 'Recovered' is COM-lean recovery; with yaw free-spinning the research 'hold'
    objective is not met while the legacy outcome still is."""
    r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": "cf3d"}, "duration_s": 6})
    assert r["outcome"]["code"] == "recovered"
    assert r["research"]["recovery"]["recovered"] is False       # the heading drifted (gravity gives no yaw)


def test_termination_reasons_are_separate_from_outcome():
    cases = [({"mode": "edge", "termination": {"stop_on_recovery": True}, "duration_s": 5}, "recovery"),
             ({"mode": "edge", "controller": {"type": "pid"}, "comOffset_m": 0.004, "termination": {"overspeed_rpm": 2000}, "duration_s": 20}, "safety_limit"),
             ({"mode": "edge", "initial": {"tilt_deg": 25}, "duration_s": 4}, "fall"),
             ({"mode": "edge", "duration_s": 2}, "duration")]
    for cfg, reason in cases:
        r = simulate(cfg)
        assert r["termination"]["reason"] == reason, (cfg, r["termination"])
    r = simulate({"mode": "edge", "termination": {"stop_on_recovery": True}, "duration_s": 5})
    assert r["outcome"]["code"] == "recovered" and r["samples"]["cols"]["t"][-1] < 5


def test_lift_off_is_loss_of_support():
    r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "disturbances": [
        {"type": "force", "magnitude_N": 40, "point_m": [0.09, 0.09, 0.09], "direction": [0, 0, 1], "frame": "world", "t_start_s": 0.5, "duration_s": 0.2}], "duration_s": 2})
    assert r["termination"]["reason"] == "loss_of_support"
    assert r["outcome"]["code"] == "fallen" and "lift-off" in r["outcome"]["reason"]


def test_numerical_failure_is_reported_as_invalid():
    # a coarse 100 Hz step with a fast tumble drifts the quaternion norm by ~2e-10 per step
    r = simulate({"mode": "corner", "controller": {"type": "none"}, "termination": {"max_quaternion_drift": 1e-12}, "params": {"fs": 100},
                  "initial": {"tilt_deg": 5, "rate_dps": 100}, "duration_s": 2})
    assert not r["ok"] and r["outcome"]["code"] == "invalid" and r["termination"]["reason"] == "numerical_failure"
    # a non-finite state (here from a non-finite command) is reported as invalid_state, never as a result
    from conftest import engine_for, const_torque
    eng = engine_for({"mode": "corner", "duration_s": 1}, controller=const_torque((float("nan"), 0, 0)))
    out = eng.run()
    assert out.get("numericalFailure") and eng.termination["reason"] == "invalid_state"


def test_cancellation_stops_the_run():
    calls = {"n": 0}

    def cancel():
        calls["n"] += 1
        return calls["n"] > 1
    r = simulate({"mode": "corner", "duration_s": 10}, cancel_check=cancel)
    assert r.get("cancelled") and r["termination"]["reason"] == "cancelled"


def test_research_metrics_units_and_definitions():
    r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": "mekf"}, "duration_s": 3})
    R = r["research"]
    for k in ("recovery", "attitude_error", "lean", "body_rate", "wheel_speed", "torque", "effort_Nms", "energy_model_J", "saturation_s",
              "speed_limited_s", "estimator", "final", "termination", "event_counts"):
        assert k in R, k
    assert set(R["attitude_error"]) == {"rms", "iae", "ise", "peak", "final", "duration_s"}
    # version-2 definitions: RMS is the time-weighted root of ISE over the executed duration (units deg, deg·s, deg²·s)
    A = R["attitude_error"]
    assert R["metrics_version"] == "2" and abs(A["rms"] - math.sqrt(A["ise"] / A["duration_s"])) < 1e-9 * max(1.0, A["rms"])
    assert R["units"]["attitude_error.ise"] == "deg²·s" and R["units"]["attitude_error.iae"] == "deg·s"
    assert R["estimator"]["tilt_rmse_deg"] < R["estimator"]["attitude_rmse_deg"] + 1e-12
    from aeris_backend.metrics.research import DEFINITIONS
    assert "not a measurement" in DEFINITIONS["energy"] or "MODEL" in DEFINITIONS["energy"]
    # peak requested ≥ peak applied (limits only reduce torque)
    for w, v in R["torque"]["peak_applied_Nm"].items():
        assert v <= R["torque"]["peak_requested_Nm"][w] + 1e-9


def test_executed_method_is_persisted_with_its_gains_and_structure():
    """The record names the method that ran: structure labels, and the nonlinear controller's gains and model."""
    import math
    kinds = {}
    for ctl in ({"type": "pid"}, {"type": "lqr"}, {"type": "lqr", "structure": "mimo-lqr"}, {"type": "nlpd"}, {"type": "none"}):
        r = simulate({"mode": "corner", "controller": ctl, "duration_s": 0.6})
        kinds[ctl["type"] + ("/mimo" if ctl.get("structure") else "")] = r["executed"]["controller"]["structure"]
    assert kinds == {"pid": "decoupled", "lqr": "decoupled", "lqr/mimo": "mimo-lqr", "nlpd": "nonlinear-full-tensor", "none": "none"}
    e = simulate({"mode": "edge", "controller": {"type": "nlpd", "nonlinear": {"omega_n": 10, "momentum_omega": 0.5}}, "duration_s": 0.6})
    x = e["executed"]["controller"]
    assert x["gains"]["kp_tilt_per_s2"] == 100 and math.isclose(x["gains"]["kd_tilt_per_s"], 2 * 0.9 * 10)
    # edge mode: the momentum loop uses the lever arm about the support edge, k1 = 2 ω_o / (m g l_edge)
    mgl_edge = e["design"]["edge_model_mgl"]
    assert math.isclose(x["model_used"]["mgl_Nm"], mgl_edge) and math.isclose(x["gains"]["k1_momentum_rad_per_Nms"], 2 * 0.5 / mgl_edge)
    assert x["gains"]["kp_yaw_per_s2"] is None


def test_default_blocks_are_not_research_extensions():
    """A normalised configuration carries solver/plant/recovery/termination blocks; defaults change nothing."""
    from aeris_backend.config.normalize import normalize, uses_extensions
    c, _ = normalize({"mode": "corner"})
    assert uses_extensions(c) == []
    c2, _ = normalize({"mode": "corner", "solver": {"integration_hz": 1000}, "recovery": {"hold_s": 2}, "plant": {"components": [{"mass_kg": 0.1, "com_m": [0.05, 0.05, 0.05]}]}})
    assert uses_extensions(c2) == ["solver", "plant", "recovery"]


class _Est:
    def __init__(self, theta=0.0, thetadot=0.0, q=None, w=(0.0, 0.0, 0.0)):
        self.theta, self.thetadot, self.q, self.w, self.t = theta, thetadot, q, w, 0.0


def _pid_edge(aw, reset=False):
    from tests.conftest import engine_for
    eng = engine_for({"mode": "edge", "controller": {"type": "pid", "pid": {"anti_windup": aw, "reset_on_events": reset}}, "duration_s": 1})
    return eng.controller


def test_pid_integral_limit_conditional_anti_windup_and_reset():
    """Sign convention e = θ̂ + β_ref, T = Kp·e + Ki·∫e + Kd·θ̂̇. The integral is bounded by τmax/Ki (both modes);
    'conditional' also stops integrating while saturated in the direction the error pushes; reset clears it."""
    ww = [0.0, 0.0, 0.0]
    clamp, cond = _pid_edge("clamp"), _pid_edge("conditional")
    lim = clamp.ctx.taumax_act / clamp.pid["Ki"]
    for c in (clamp, cond):
        for _ in range(2000):                      # a large constant error for 4 s: the integral saturates at its bound
            c.request(0.0, _Est(theta=0.2), ww, [False, False, False])
            c.after(1, False, ww, c.ctx.dt, T_des=10.0, T_lim=c.ctx.taumax_act)   # saturated in the + direction
    assert clamp.I == pytest.approx(lim)          # clamp: grows to the bound
    assert cond.I == pytest.approx(0.2 * cond.ctx.dt)   # conditional: integrated once, then frozen while saturated
    T = clamp.request(0.0, _Est(theta=0.2, thetadot=0.1), ww, [False] * 3).per_wheel[clamp.ctx.drive]
    assert T == pytest.approx(clamp.pid["Kp"] * 0.2 + clamp.pid["Ki"] * lim + clamp.pid["Kd"] * 0.1)
    # an error of the opposite sign is integrated even while saturated (it unwinds the demand)
    cond.request(0.0, _Est(theta=-0.1), ww, [False] * 3)
    assert cond.I == pytest.approx(0.2 * cond.ctx.dt - 0.1 * cond.ctx.dt)
    # reset: only when configured, at wheel events and yaw-command steps
    clamp.on_event(0.5, "wheel_failure on")
    assert clamp.I == pytest.approx(lim)
    r = _pid_edge("clamp", reset=True)
    r.I = 0.3
    r.on_event(0.5, "wheel_failure on")
    assert r.I == 0.0 and r.summary()["integrator_resets"] == [{"t": 0.5, "reason": "wheel_failure on"}]


def test_pid_reset_in_a_run_is_recorded_and_default_matches_the_browser():
    base = {"mode": "corner", "controller": {"type": "pid"}, "events": [{"id": "F", "type": "wheel_degradation", "wheel": "y", "t_s": 1.0, "health": 0.6}],
            "commands": [{"id": "C", "type": "yaw_step", "t_s": 1.5, "angle_deg": 20}], "initial": {"tilt_deg": 2}, "duration_s": 3}
    a = simulate(base)
    assert a["executed"]["controller"]["reset_on_events"] is False and a["executed"]["controller"]["integrator_resets"] == []
    b = simulate(dict(base, controller={"type": "pid", "pid": {"reset_on_events": True}}))
    reasons = [(round(x["t"], 3), x["reason"]) for x in b["executed"]["controller"]["integrator_resets"]]
    assert reasons == [(1.0, "wheel_degradation on"), (1.5, "yaw command")]
    assert a["samples"]["cols"]["T_x"] != b["samples"]["cols"]["T_x"]      # the reset changes the command after t = 1 s
    ia = a["samples"]["cols"]["t"].index(1.0)
    assert a["samples"]["cols"]["T_x"][:ia] == b["samples"]["cols"]["T_x"][:ia]   # identical before the first event


def test_authority_residual_matches_saturation_and_reports_lost_authority():
    """r = u_req − Σ T_i a_i: zero while every wheel delivers its command (up to motor lag), non-zero while saturated,
    and it stays non-zero when a failure removes authority the controller still asks for (no fault-tolerance claim)."""
    a = simulate({"mode": "edge", "controller": {"type": "lqr"}, "initial": {"tilt_deg": 3}, "duration_s": 3})
    au, sat = a["research"]["authority"], a["research"]["saturation_s"]["any"]
    assert au["deficit_s"] == pytest.approx(sat, abs=0.01) and au["residual_peak_Nm"] > 0
    b = simulate({"mode": "edge", "controller": {"type": "lqr"}, "initial": {"tilt_deg": 0.5}, "duration_s": 2})
    assert b["research"]["saturation_s"]["any"] == 0 and b["research"]["authority"]["residual_peak_Nm"] < 1e-12
    c = simulate({"mode": "corner", "controller": {"type": "nlpd"}, "events": [{"type": "wheel_failure", "wheel": "z", "t_s": 1}], "initial": {"tilt_deg": 3}, "duration_s": 3})
    auc = c["research"]["authority"]
    assert auc["deficit_s"] > c["research"]["saturation_s"]["any"] + 1.0     # the yaw request after the failure cannot be met
    from aeris_backend.metrics.research import DEFINITIONS, UNITS
    assert "authority" in DEFINITIONS and UNITS["authority.residual"] == "N·m"


def test_nonlinear_pd_exact_model_gives_the_designed_error_dynamics():
    """With the controller's model equal to the plant (knowsAttachments, no friction, 2 kHz loop, momentum loop
    negligible, no saturation), u = τ_g − ω̂×H − Θ̂α_d makes ω̇ = α_d: the attitude error follows
    φ̈ + 2ζω_n φ̇ + ω_n² φ = 0. Tolerance 0.5 % of the initial error (zero-order hold, 6-digit recording)."""
    import math
    wn, z = 14.0, 0.9
    wd = wn * math.sqrt(1 - z * z)

    def ana(x0, t):
        return x0 * math.exp(-z * wn * t) * (math.cos(wd * t) + z * wn / wd * math.sin(wd * t))
    nl = {"type": "nlpd", "knowsAttachments": True, "nonlinear": {"momentum_omega": 0.001, "omega_n": wn, "zeta": z, "compensate_friction": False}}
    common = {"controller": nl, "params": {"cv": 0, "cc": 0, "fs": 2000}, "duration_s": 0.8, "record_hz": 1000}
    c = simulate(dict(common, mode="corner", initial={"tilt_deg": 0.5, "rate_dps": 0, "azimuth_deg": 30, "reference": "balance"}))
    e = simulate(dict(common, mode="edge", initial={"tilt_deg": 0.5, "reference": "balance"}))
    for r, col in ((c, "att_err"), (e, "e")):
        assert r["research"]["saturation_s"]["any"] == 0
        S = r["samples"]["cols"]
        x0 = S[col][0]
        worst = max(abs(abs(S[col][k]) - abs(ana(x0, t))) for k, t in enumerate(S["t"]))
        assert worst < 0.005 * abs(x0), (r["config"]["mode"], worst / abs(x0))


def test_csv_export_names_the_executed_method():
    """The CSV header states the method that ran (a nonlinear controller is not shown as the configured default
    'decoupled' structure; the perfect-state baseline is named)."""
    from aeris_backend.experiments.records import build_record, to_csv
    res = simulate({"mode": "corner", "controller": {"type": "nlpd"}, "estimator": {"type": "mekf"}, "duration_s": 0.5, "record_hz": 20})
    line = [x for x in to_csv(build_record(res)).splitlines() if x.startswith("# mode:")][0]
    assert "controller (executed): nlpd (nonlinear-full-tensor)" in line and "estimator (executed): mekf ;" in line
    res = simulate({"mode": "corner", "controller": {"type": "lqr", "structure": "mimo-lqr"}, "duration_s": 0.5, "record_hz": 20})
    line = [x for x in to_csv(build_record(res)).splitlines() if x.startswith("# mode:")][0]
    assert "controller (executed): lqr (mimo-lqr)" in line and "estimator (executed): ideal (perfect-state baseline)" in line

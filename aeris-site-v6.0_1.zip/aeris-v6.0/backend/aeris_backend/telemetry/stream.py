"""TelemetryHub: the normalised telemetry stream (docs/TELEMETRY.md §3).

feed_line(raw, now) processes one received line. Session rules:

  hello      starts a session (a new connection must start with one); an invalid hello is reported and
             every frame is rejected until a valid hello arrives ('no_valid_hello')
  frames     validated by protocol.validate_frame; then, by sequence number within the session:
               seq == last          duplicate: dropped, counted
               seq <  last          out of order: dropped, counted (no re-ordering buffer: late frames are lost)
               seq >  last + 1      gap: accepted, the missing count is added to 'dropped_by_source'
               t   <= last t        rejected ('time_not_increasing')
  stale      tick(now): no accepted frame for more than stale_after_s while connected → stale (event); the next
             accepted frame clears it (event)
  connection on_connect / on_disconnect record events; a reconnect starts a new session segment (seq and t
             restart are allowed after the new hello)

Accepted frames get a hub-wide index n (strictly increasing, never reused within this hub) and are published to
subscribers through bounded queues: a subscriber that does not keep up loses its OLDEST queued frames (counted per
subscriber); the reader never blocks. The last `recent_frames` frames are also kept for polling clients
(frames_after(n)); a client de-duplicates by n after a reconnect. Every hub has a STREAM IDENTITY (stream_id, new
for every hub, i.e. every backend process): n is only meaningful together with it. It is reported with the status,
every live batch and every poll; a client that sees a new stream_id (the backend restarted) starts its cursor again
(v5.1, review finding F2; docs/TELEMETRY.md §7).

Each valid hello starts a SOURCE SEGMENT (hub-wide counter `segment`, carried by every frame). A recording collects
the accepted frames and the stream events of one segment or more, remembering which source declared what for
which rows (provenance.segments); a hello with a different mode closes the recording (samples of two modes cannot
share one table). stop_recording() returns an aeris-hardware-run/1 document whose provenance (source kind, synthetic
flag, device, segments, lineage, transport, quality, events) travels with every export, dataset and comparison;
one synthetic, test or undeclared segment makes the whole recording synthetic (telemetry/lineage.py).
"""
from __future__ import annotations

import asyncio
import datetime as _dt
import json
import math
import secrets
from collections import deque

from .lineage import classify, source_trust
from .protocol import CONVENTIONS, PROTOCOL, parse_line, validate_frame, validate_hello

STATUS_CODES = {"ok": 0, "idle": 1, "calibrating": 2, "fault": 3, "estop": 4}


def _iso(ts=None):
    d = _dt.datetime.now(_dt.timezone.utc) if ts is None else _dt.datetime.fromtimestamp(ts, _dt.timezone.utc)
    return d.isoformat(timespec="milliseconds").replace("+00:00", "Z")


class Subscriber:
    def __init__(self, maxsize: int):
        self.queue = deque()
        self.maxsize = maxsize
        self.dropped = 0
        self.event = asyncio.Event() if _has_loop() else None

    def offer(self, item):
        if len(self.queue) >= self.maxsize:
            self.queue.popleft()
            self.dropped += 1
        self.queue.append(item)
        if self.event is not None:
            self.event.set()

    def drain(self, max_items=None):
        out = []
        while self.queue and (max_items is None or len(out) < max_items):
            out.append(self.queue.popleft())
        if self.event is not None and not self.queue:
            self.event.clear()
        return out


def _has_loop():
    try:
        asyncio.get_running_loop()
        return True
    except RuntimeError:
        return False


class TelemetryHub:
    def __init__(self, *, stale_after_s: float = 0.5, subscriber_queue: int = 512, max_events: int = 1000, recent_frames: int = 2000,
                 max_subscribers: int = 16):
        self.stale_after_s = stale_after_s
        self.max_subscribers = max_subscribers
        self.recent = deque(maxlen=recent_frames)
        self.n = 0
        # the identity of this stream: frame indices n restart with every hub (every backend process)
        self.stream_started = _iso()
        self.stream_id = _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + secrets.token_hex(6)
        self.segment = 0
        self.subscriber_queue = subscriber_queue
        self.max_events = max_events
        self.subscribers: list[Subscriber] = []
        self.transport = None
        self.connected = False
        self.hello = None
        self.last_hello = None
        self.hello_errors = []
        self.session = 0
        self.last_seq = None
        self.last_t = None
        self.last_frame_wall = None
        self.stale = False
        self.rate_hz = None
        self.latest = None
        self.counters = {"lines": 0, "frames_accepted": 0, "duplicates": 0, "out_of_order": 0, "gaps": 0, "dropped_by_source": 0,
                         "rejected": 0, "connects": 0, "disconnects": 0, "reconnects": 0, "stale_events": 0, "status_messages": 0}
        self.rejected_by_reason: dict[str, int] = {}
        self.last_errors = deque(maxlen=20)
        self.events = deque(maxlen=max_events)
        self.recording = None
        self.ended_cleanly = False

    # ------------------------------------------------------------------ connection
    def on_connect(self, transport: dict, now: float):
        if self.counters["connects"] > 0:
            self.counters["reconnects"] += 1
        self.counters["connects"] += 1
        self.transport = dict(transport)
        self.connected = True
        self.hello = None
        self.hello_errors = []
        self.session += 1
        self.last_seq = None
        self.last_t = None
        self.last_frame_wall = now
        self.ended_cleanly = False
        self._event("connect", now, detail=f"{transport.get('kind')} {transport.get('address') or ''}".strip())

    def on_disconnect(self, reason: str, now: float):
        if not self.connected:
            return
        self.connected = False
        self.counters["disconnects"] += 1
        # the session ends: frames are refused until a new connection sends a new hello; the last hello is kept
        # (last_hello) so that the status still says what the source WAS
        if self.hello is not None:
            self.last_hello = self.hello
        self.hello = None
        self._event("disconnect", now, detail=reason)

    # ------------------------------------------------------------------ lines
    def _reject(self, reason: str, now: float, detail: str | None = None):
        self.counters["rejected"] += 1
        self.rejected_by_reason[reason] = self.rejected_by_reason.get(reason, 0) + 1
        self.last_errors.append({"at": now, "reason": reason, "detail": (detail or "")[:300]})

    def reject(self, reason: str, now: float, detail: str | None = None) -> str:
        """A transport-level rejection (e.g. 'line_too_long' found while splitting, 'truncated_line' at a disconnect)."""
        self.counters["lines"] += 1
        self._reject(reason, now, detail)
        return "rejected:" + reason

    def feed_line(self, raw, now: float) -> str:
        """Process one line; returns what happened ('hello', 'frame', 'duplicate', 'rejected:<reason>', …)."""
        self.counters["lines"] += 1
        msg, err = parse_line(raw)
        if err:
            self._reject(err, now)
            return "rejected:" + err
        return self._message(msg, now)

    def feed_message(self, msg: dict, now: float) -> str:
        """An already decoded contract message (from a device adapter); validated exactly like a line."""
        self.counters["lines"] += 1
        if not isinstance(msg, dict) or msg.get("type") not in ("hello", "frame", "status", "bye"):
            self._reject("unknown_type", now)
            return "rejected:unknown_type"
        return self._message(msg, now)

    def _message(self, msg: dict, now: float) -> str:
        typ = msg["type"]
        if typ == "hello":
            v = validate_hello(msg)
            if not v["ok"]:
                self.hello = None
                self.hello_errors = v["errors"]
                self._reject("invalid_hello", now, "; ".join(v["errors"]))
                self._event("invalid_hello", now, detail="; ".join(v["errors"]))
                return "rejected:invalid_hello"
            self.hello = {k: msg[k] for k in ("protocol", "device", "synthetic", "mode", "conventions", "lineage") if k in msg}
            self.hello["nominal_rate_hz"] = msg.get("nominal_rate_hz")
            self.hello_errors = []
            self.last_seq = None
            self.last_t = None
            self.segment += 1
            self._event("hello", now, detail=f"{msg['device']['kind']} {msg['device']['id']} firmware {msg['device']['firmware']}" + (" SYNTHETIC" if msg["synthetic"] else "")
                        + (f" (lineage: {msg['lineage'].get('derived_from')})" if isinstance(msg.get("lineage"), dict) else ""))
            if self.recording is not None and self.recording.get("closed") is None:
                rec = self.recording
                if self.hello.get("mode") != rec["segments"][0]["hello"].get("mode"):
                    # samples of two modes cannot share one table: the recording stops here (stop_recording() returns it)
                    rec["closed"] = {"reason": f"the source changed mode from {rec['segments'][0]['hello'].get('mode')} to {self.hello.get('mode')}; "
                                               "the recording stopped at the change (start a new recording for the new mode)", "at": now}
                    self._event("recording_closed", now, detail=rec["closed"]["reason"])
                else:
                    rec["hellos"].append(dict(self.hello))
                    rec["segments"].append({"segment": self.segment, "session": self.session, "hello": dict(self.hello), "frames": 0})
            return "hello"
        if typ == "bye":
            self.ended_cleanly = True
            if self.hello is not None:
                self.last_hello = self.hello
            self.hello = None                       # the source ended its session: later frames need a new hello
            self._event("bye", now)
            return "bye"
        if typ == "status":
            self.counters["status_messages"] += 1
            self._event("source_status", now, detail=str(msg.get("state"))[:80])
            return "status"
        # frame
        if self.hello is None:
            self._reject("no_valid_hello", now)
            return "rejected:no_valid_hello"
        v = validate_frame(msg, self.hello)
        if not v["ok"]:
            reason = "unit_mismatch" if any("unit mismatch" in e for e in v["errors"]) else ("non_unit_quaternion" if any("unit quaternion" in e for e in v["errors"]) else "invalid_frame")
            self._reject(reason, now, "; ".join(v["errors"]))
            return "rejected:" + reason
        f = v["frame"]
        seq, t = f["seq"], f["t"]
        if self.last_seq is not None:
            if seq == self.last_seq:
                self.counters["duplicates"] += 1
                return "duplicate"
            if seq < self.last_seq:
                self.counters["out_of_order"] += 1
                self._event("out_of_order", now, detail=f"seq {seq} after {self.last_seq}")
                return "out_of_order"
            if seq > self.last_seq + 1:
                missing = seq - self.last_seq - 1
                self.counters["gaps"] += 1
                self.counters["dropped_by_source"] += missing
                self._event("gap", now, t=t, detail=f"{missing} frame(s) missing before seq {seq}")
        if self.last_t is not None and not t > self.last_t:
            self._reject("time_not_increasing", now, f"t {t} after {self.last_t}")
            return "rejected:time_not_increasing"
        if self.last_t is not None and t > self.last_t:
            inst = 1.0 / (t - self.last_t) * (1 if self.last_seq is None else max(1, seq - self.last_seq))
            self.rate_hz = inst if self.rate_hz is None else self.rate_hz + 0.1 * (inst - self.rate_hz)
        self.last_seq, self.last_t = seq, t
        self.last_frame_wall = now
        if self.stale:
            self.stale = False
            self._event("fresh", now, t=t, detail="frames resumed")
        self.counters["frames_accepted"] += 1
        self.n += 1
        f = dict(f, n=self.n, session=self.session, segment=self.segment, rx=now)
        self.latest = f
        self.recent.append(f)
        for s in list(self.subscribers):
            s.offer(f)
        if self.recording is not None:
            self._record(f)
        return "frame"

    def tick(self, now: float):
        if self.connected and not self.stale and self.last_frame_wall is not None and now - self.last_frame_wall > self.stale_after_s:
            self.stale = True
            self.counters["stale_events"] += 1
            self._event("stale", now, t=self.last_t, detail=f"no frame for more than {self.stale_after_s:g} s")

    def source_gap(self, missing: int, now: float, detail: str) -> None:
        """Frames the SOURCE reports it can no longer deliver (a device whose backfill ring was overwritten while no
        route carried its stream, v6): counted like a sequence gap (gaps, dropped_by_source) and recorded as a 'gap'
        event — also in a running recording — instead of being skipped silently."""
        if missing <= 0:
            return
        self.counters["gaps"] += 1
        self.counters["dropped_by_source"] += int(missing)
        self._event("gap", now, t=self.last_t, detail=detail)

    def _event(self, kind, now, t=None, detail=None):
        e = {"type": kind, "at": now, "t": t, "session": self.session, "detail": detail}
        self.events.append(e)
        if self.recording is not None and (self.recording.get("closed") is None or kind == "recording_closed"):
            self.recording["events"].append(e)

    # ------------------------------------------------------------------ subscribers
    def subscribe(self, maxsize: int | None = None) -> Subscriber:
        if len(self.subscribers) >= self.max_subscribers:
            raise OverflowError(f"at most {self.max_subscribers} live telemetry subscribers")
        s = Subscriber(maxsize or self.subscriber_queue)
        self.subscribers.append(s)
        return s

    def frames_after(self, n: int, limit: int = 500, stream: str | None = None) -> dict:
        """Polling fallback: accepted frames with index > n still held in the recent buffer. 'missed' counts frames
        after n that already left the buffer (the client polled too slowly). A cursor n belongs to a stream: when the
        client names another stream (the backend restarted since its last poll), n is meaningless here and the
        answer starts at the beginning of this stream (stream_changed: true)."""
        changed = stream is not None and stream != self.stream_id
        if changed:
            n = 0
        out = [f for f in self.recent if f["n"] > n][:max(1, limit)]
        oldest = self.recent[0]["n"] if self.recent else self.n + 1
        missed = max(0, oldest - n - 1) if self.n > n else 0
        return {"frames": out, "last_n": self.n, "missed": missed, "stream_id": self.stream_id, "stream_changed": changed}

    def unsubscribe(self, s: Subscriber):
        if s in self.subscribers:
            self.subscribers.remove(s)

    # ------------------------------------------------------------------ status
    def provenance(self) -> dict:
        """What the current (or, when disconnected, the last) source declared. Declared, never verified.

        v6 (review finding V52-2 of v5.2): the trust comes from lineage.source_trust — the same conservative rule the
        recorder, the exports, the datasets and the comparison evidence use — so a hello that declares physical /
        synthetic: false but carries a synthetic or unknown ancestry (ancestry_trust, an ancestry reference,
        original_synthetic, v5.1 nested ancestors, unknown trust) is never reported as a live physical device.
        As for a stored recording's provenance, 'synthetic' means trust == "synthetic"; an UNKNOWN origin is reported as
        trust "unknown" (synthetic false, declared_physical false, never live) — distinct, and never promoted. A hello
        with a lineage is a copy of earlier data (derived), never a live measurement."""
        h = self.hello or self.last_hello or {}
        dev = h.get("device") or {}
        lin = h.get("lineage") if isinstance(h.get("lineage"), dict) else None
        st = source_trust(h)
        trust = st["trust"]
        kind = dev.get("kind")
        replay = (self.transport or {}).get("kind") == "file" or kind == "file-replay" or st["derived"]
        synthetic = None if not h else trust == "synthetic"
        declared_physical = bool(h) and trust == "declared-physical" and kind == "physical"
        if not h:
            label = "NO SOURCE"
        elif trust == "synthetic":
            label = ("SYNTHETIC " + ("EMULATOR" if kind == "emulator" else "TEST SOURCE" if kind == "test" else "REPLAY" if kind == "file-replay" else "DATA")
                     + " — not the physical cube" + (" (its lineage has a synthetic ancestor)" if kind == "physical" else ""))
        elif trust == "unknown":
            label = "UNKNOWN ORIGIN — not shown as the cube (the source or its lineage does not establish where the data came from)"
        elif replay:
            label = "REPLAY of a recording declared from a physical device" + (" (a copy, not a live measurement)" if st["derived"] else "")
        else:
            label = "DECLARED PHYSICAL DEVICE (not verified by the software)"
        return {"active": self.hello is not None, "source_kind": kind, "device_id": dev.get("id"), "firmware": dev.get("firmware"), "synthetic": synthetic,
                "trust": trust, "trust_reasons": st["reasons"], "derived": st["derived"],
                "declared_physical": declared_physical, "physical_verified": False, "replay": replay, "lineage": lin, "segment": self.segment,
                "label": label}

    def status(self, now: float) -> dict:
        self.tick(now)
        age = (now - self.last_frame_wall) if self.last_frame_wall is not None else None
        return {"protocol": PROTOCOL, "stream_id": self.stream_id, "stream_started": self.stream_started, "segment": self.segment,
                "connected": self.connected, "transport": self.transport, "session": self.session,
                "hello": self.hello, "hello_errors": self.hello_errors, "provenance": self.provenance(),
                "stale": self.stale, "stale_after_s": self.stale_after_s, "last_frame_age_s": age, "last_t": self.last_t, "last_seq": self.last_seq,
                "rate_hz": self.rate_hz, "last_n": self.n, "latest": self.latest, "counters": dict(self.counters), "rejected_by_reason": dict(self.rejected_by_reason),
                "last_errors": list(self.last_errors)[-5:], "subscribers": [{"queued": len(s.queue), "dropped": s.dropped} for s in self.subscribers],
                "recording": None if self.recording is None else {"name": self.recording["name"], "frames": len(self.recording["frames"]), "started": self.recording["started"],
                                                                 "segments": len(self.recording["segments"]), "closed": (self.recording.get("closed") or {}).get("reason")},
                "read_only": True}

    # ------------------------------------------------------------------ recording
    def start_recording(self, name: str, now: float) -> dict:
        if self.recording is not None:
            raise RuntimeError("a recording is already running")
        if self.hello is None:
            raise RuntimeError("no telemetry session: connect a source that sent a valid hello first")
        self.recording = {"name": name, "started": _iso(), "started_at": now, "frames": [], "events": [], "hellos": [dict(self.hello)],
                          "segments": [{"segment": self.segment, "session": self.session, "hello": dict(self.hello), "frames": 0}],
                          "counters_at_start": dict(self.counters), "transport": dict(self.transport or {}), "closed": None}
        return {"name": name, "started": self.recording["started"]}

    def _record(self, f):
        rec = self.recording
        if rec.get("closed") is not None:
            return
        seg = next((s for s in reversed(rec["segments"]) if s["segment"] == f.get("segment")), None)
        if seg is None:                                  # cannot happen: every accepted frame follows a recorded hello
            return
        seg["frames"] += 1
        rec["frames"].append(f)

    def stop_recording(self, now: float) -> dict:
        rec = self.recording
        if rec is None:
            raise RuntimeError("no recording is running")
        self.recording = None
        return self.recording_document(rec, now)

    def recording_document(self, rec: dict, now: float) -> dict:
        """The recorded frames as an aeris-hardware-run/1 document (columnar, units per column) with provenance: which
        source declared what for which rows (segments), the lineage of replayed exports, and a trust classification
        that never exceeds the least trustworthy segment (telemetry/lineage.py)."""
        frames = rec["frames"]
        if len(frames) < 2:
            raise RuntimeError(f"only {len(frames)} frame(s) were recorded; a recording needs at least two")
        segs_used = [s for s in rec["segments"] if s["frames"] > 0]
        first = segs_used[0]["hello"]
        mode = first["mode"]
        # One time base across source segments (reconnects, a replaced source): a source whose clock and sequence
        # continue keeps its own values (the outage shows as a gap); a source that restarted them is re-based to follow
        # the previous segment, which is recorded as a 'time_base_reset' event because the outage length is then unknown.
        key = lambda f: f.get("segment", f["session"])                       # noqa: E731  (frames without a segment: v5)
        t_off, seq_off, prev_seg, last_t, last_seq = 0.0, 0, key(frames[0]), None, None
        cols = {"t": [], "seq": []}
        resets, bounds = [], [[key(frames[0]), 0, None]]
        for i, f in enumerate(frames):
            if key(f) != prev_seg:
                prev_seg = key(f)
                bounds[-1][2] = i
                bounds.append([prev_seg, i, None])
                if not (f["t"] + t_off > last_t):
                    t_off = last_t + 1e-3 - f["t"]
                    resets.append({"type": "time_base_reset", "t": last_t, "session": f["session"],
                                   "detail": "the source restarted its clock at a new segment (reconnect or new source); the segment is placed 1 ms after the previous one (outage length unknown)"})
                if not (f["seq"] + seq_off > last_seq):
                    seq_off = last_seq + 1 - f["seq"]
            last_t = f["t"] + t_off
            last_seq = f["seq"] + seq_off
            cols["t"].append(last_t)
            cols["seq"].append(last_seq)
        bounds[-1][2] = len(frames)
        units = {"t": "s", "seq": "count"}

        def put(name, vals, unit):
            if all(v is not None for v in vals):
                cols[name] = vals
                units[name] = unit
        if all("q" in f for f in frames):
            for j in range(4):
                put(f"q{j}", [f["q"][j] for f in frames], "–")
        if all("theta" in f for f in frames):
            put("theta", [f["theta"] for f in frames], "rad")
        axes = "xyz"
        for key_, prefix, unit in (("w", "w_", "rad/s"), ("wheel_rpm", "wheel_rpm_", "rpm"), ("torque_cmd", "torque_cmd_", "N·m"), ("torque_meas", "torque_meas_", "N·m")):
            if all(key_ in f for f in frames):
                for j in range(3):
                    put(prefix + axes[j], [f[key_][j] for f in frames], unit)
        if all(isinstance(f.get("imu"), dict) and "gyro" in f["imu"] for f in frames):
            for j in range(3):
                put("gyro_" + axes[j], [f["imu"]["gyro"][j] for f in frames], "rad/s")
        if all(isinstance(f.get("imu"), dict) and "accel" in f["imu"] for f in frames):
            for j in range(3):
                put("accel_" + axes[j], [f["imu"]["accel"][j] for f in frames], "m/s²")
        if all("status" in f for f in frames):
            put("status", [STATUS_CODES[f["status"]] for f in frames], "count")
        by_seg = {s["segment"]: s for s in rec["segments"]}
        segments = []
        for k, (sid, a, b) in enumerate(bounds):
            h = (by_seg.get(sid) or {}).get("hello") or first
            d = h.get("device") or {}
            segments.append({"segment": k + 1, "rows": [a, b], "t": [cols["t"][a], cols["t"][b - 1]], "session": frames[a]["session"],
                             "device": {"id": d.get("id"), "kind": d.get("kind"), "firmware": d.get("firmware")}, "synthetic": h.get("synthetic"),
                             "mode": h.get("mode"), "nominal_rate_hz": h.get("nominal_rate_hz"), "hello": dict(h)})
        lineage = [s["hello"]["lineage"] for s in segments if isinstance(s["hello"].get("lineage"), dict)]
        c0, c1 = rec["counters_at_start"], self.counters
        quality = {k: c1[k] - c0.get(k, 0) for k in ("frames_accepted", "duplicates", "out_of_order", "gaps", "dropped_by_source", "rejected", "reconnects", "stale_events")}
        dur = cols["t"][-1] - cols["t"][0]
        idents = {(s["device"]["id"], s["device"]["kind"], s["device"]["firmware"], s["synthetic"]) for s in segments}
        prov = {"protocol": PROTOCOL, "transport": rec["transport"], "hellos": [s["hello"] for s in segments], "segments": segments,
                "conventions": CONVENTIONS, "stream_quality": quality, "stream_id": self.stream_id}
        if lineage:
            prov["lineage"] = lineage
        if rec.get("closed"):
            prov["recording_closed"] = {"reason": rec["closed"]["reason"], "at_s": round(rec["closed"]["at"] - rec["started_at"], 6)}
        probe = {"synthetic": False, "provenance": prov, "samples": {"cols": cols}}
        cls = classify(probe)                    # judged from the segments and their lineage alone (the document flag follows from it)
        synthetic = cls["trust"] != "declared-physical"
        if len(idents) == 1:
            dev = dict(segments[0]["device"])
            source_kind = dev["kind"]
        else:
            ids = list(dict.fromkeys(str(s["device"]["id"]) for s in segments))
            fws = list(dict.fromkeys(str(s["device"]["firmware"]) for s in segments))
            dev = {"id": "mixed: " + " + ".join(ids), "kind": "mixed", "firmware": " + ".join(fws)}
            source_kind = "mixed"
        prov.update({"source_kind": source_kind, "synthetic": synthetic, "trust": cls["trust"], "trust_reasons": cls["reasons"],
                     "mixed_sources": cls["mixed_sources"], "derived": cls["derived"], "derived_from": cls["derived_from"]})
        if cls["trust"] == "unknown":
            prov["synthetic_flag_reason"] = "unknown-origin"         # v6: stored synthetic (never evidence), classified unknown
        kinds = ", ".join(dict.fromkeys(str(s["device"]["kind"]) for s in segments))
        prov["events"] = ([{k: v for k, v in e.items() if k != "at"} | {"at_s": round(e["at"] - rec["started_at"], 6)} for e in rec["events"]] + resets)[:self.max_events]
        prov["status_codes"] = STATUS_CODES
        prov["note"] = ("SYNTHETIC telemetry (" + kinds + ("; mixed sources — one synthetic or undeclared segment makes the whole recording synthetic" if len(idents) > 1 else "")
                        + "): not a measurement of the physical cube; it can never be validation evidence." if synthetic
                        else "Declared by the source as a physical device; the software cannot verify this. Evidence only through a predeclared protocol."
                        + (" Captured from a replay: a copy of earlier data, not an original measurement." if cls["derived"] else ""))
        doc = {"schema": "aeris-hardware-run/1", "synthetic": synthetic,
               "device": dev,
               "recording": {"started": rec["started"], "operator": "AERIS backend telemetry recorder", "notes": rec["name"]},
               "mode": mode, "parameters": {"parameter_set": "nominal-design-v1"},
               "samples": {"rate_hz": (len(frames) - 1) / dur if dur > 0 else None, "cols": cols, "units": units},
               "provenance": prov}
        return doc


def finite(x):
    return isinstance(x, (int, float)) and math.isfinite(x)


# v5.2 (review findings G1, G2 of v5.1): the NDJSON export converts every signal to the wire units, refuses what it
# cannot map instead of dropping or relabelling it, bounds the lineage and replays its own output through a scratch hub
# before returning it (telemetry/export.py). The name stays importable from here.
from .export import ExportError, check_replayable, recording_to_ndjson, wire_plan  # noqa: E402,F401

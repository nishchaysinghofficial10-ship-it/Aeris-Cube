"""Synthetic telemetry emulator: a STANDALONE process that serves aeris-telemetry-ndjson/1 over TCP.

Every session starts with a hello declaring device.kind 'emulator' and synthetic: true. The frames are states
simulated by the AERIS research engine with NOMINAL parameters, plus seeded synthetic IMU readings (gyro = body
rate + bias + white noise; accelerometer = gravity in body axes + white noise, no lever-arm acceleration). It
exists to exercise the software pipeline; it is not the physical cube, and its data can never be evidence.

    python -m aeris_backend.telemetry.emulator [--host 127.0.0.1] [--port 47100] [--mode corner|edge]
            [--rate 100] [--seed 1] [--episode-s 8] [--speed 1]
            [--faults drop=0.01,duplicate=0.005,reorder=0.005,malformed=0.002,bad_quaternion=0.002,
                      wrong_units=0.002,disconnect_after=2000,stall_after=500,stall_s=1.0,restart_clock=1]
            [--write FILE --frames N]        one session to an NDJSON file (for file replay) instead of serving

Faults (all optional, deterministic for a given seed): per-frame probabilities of dropping a frame (a sequence
gap), sending it twice, swapping it with the next one, sending a malformed line, a non-unit quaternion or a
frame that declares wrong units; disconnect_after N frames (the connection is closed; the next connection
continues the trajectory unless restart_clock=1, which restarts t and seq like a rebooted device); stall_after
N frames for stall_s seconds (no data: the backend should flag the stream stale). The host must be a loopback
address unless --allow-remote is given.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import math
import random
import sys

from ..simulation import simulate
from ..version import ENGINE_VERSION
from .protocol import UNITS, dumps, hello_message
from .transport import check_host

DEFAULT_PORT = 47100
G = 9.80665
FAULT_KEYS = {"drop": float, "duplicate": float, "reorder": float, "malformed": float, "bad_quaternion": float, "wrong_units": float,
              "disconnect_after": int, "stall_after": int, "stall_s": float, "restart_clock": int}


def parse_faults(spec) -> dict:
    """'drop=0.01,stall_after=500' or a dict → validated faults; raises ValueError naming the field."""
    if spec in (None, "", {}):
        return {}
    items = spec.items() if isinstance(spec, dict) else (kv.split("=", 1) if "=" in kv else (kv, None) for kv in str(spec).split(",") if kv.strip())
    out = {}
    for k, v in items:
        k = str(k).strip()
        if k not in FAULT_KEYS:
            raise ValueError(f"faults.{k}: unknown fault (known: {', '.join(FAULT_KEYS)})")
        try:
            val = FAULT_KEYS[k](v)
        except (TypeError, ValueError):
            raise ValueError(f"faults.{k}: {v!r} is not a {FAULT_KEYS[k].__name__}") from None
        if FAULT_KEYS[k] is float and k not in ("stall_s",) and not 0 <= val <= 0.5:
            raise ValueError(f"faults.{k}: a probability between 0 and 0.5")
        if k in ("disconnect_after", "stall_after") and val < 1:
            raise ValueError(f"faults.{k}: at least 1 frame")
        if k == "stall_s" and not 0 < val <= 60:
            raise ValueError("faults.stall_s: between 0 and 60 s")
        out[k] = val
    return out


class Emulator:
    def __init__(self, *, mode: str = "corner", rate_hz: float = 100.0, seed: int = 1, faults=None, episode_s: float = 8.0,
                 device_id: str = "aeris-emulator", config: dict | None = None):
        if mode not in ("edge", "corner"):
            raise ValueError("mode: the emulator simulates 'edge' or 'corner' (the engine's support models)")
        self.mode, self.rate_hz, self.seed = mode, float(rate_hz), int(seed)
        self.faults = parse_faults(faults)
        self.episode_s = float(episode_s)
        self.device_id = device_id
        self.base = config or {"mode": mode, "duration_s": self.episode_s, "record_hz": self.rate_hz,
                               "initial": {"tilt_deg": 4.0, "rate_dps": 0.0}, "controller": {"type": "lqr"}}
        self.base = dict(self.base, mode=mode, record_hz=self.rate_hz)
        self._episodes = {}
        self.t_next, self.seq_next, self.k_next, self.i_next = 0.0, 0, 0, 0
        self.sessions = 0
        self.rng = random.Random(self.seed * 7919 + 17)
        self.frames_sent = 0
        self.episode(0)                   # fails here, with the engine's message, for an invalid rate or setup

    # ------------------------------------------------------------------ content
    def hello(self) -> dict:
        return hello_message(self.device_id, "emulator", f"aeris-emulator ({ENGINE_VERSION})", True, self.mode, self.rate_hz,
                             emulator={"engine": ENGINE_VERSION, "parameters": "nominal-design-v1", "seed": self.seed, "faults": self.faults,
                                       "imu_model": "gyro = body rate + bias + N(0, 0.002 rad/s); accel = gravity in body axes + N(0, 0.02 m/s²); no lever-arm term",
                                       "note": "SYNTHETIC: simulated by the AERIS research engine with nominal parameters; not a measurement."})

    def episode(self, k: int) -> list[dict]:
        if k in self._episodes:
            return self._episodes[k]
        cfg = json.loads(json.dumps(self.base))
        r = random.Random(self.seed * 1000003 + k)
        cfg.setdefault("initial", {})
        if "attitude_q" not in cfg["initial"]:
            cfg["initial"]["tilt_deg"] = round(r.uniform(2.0, 6.0) * (1 if r.random() < 0.5 else -1), 3)
            if self.mode == "corner":
                cfg["initial"]["azimuth_deg"] = round(r.uniform(0, 360), 1)
        cfg["seed"] = self.seed * 100 + k
        res = simulate(cfg)
        if not res.get("ok"):
            errs = res.get("errors") or [{"message": (res.get("outcome") or {}).get("reason")}]
            raise ValueError("emulator setup rejected by the engine: " + "; ".join(str(e.get("path", "") + ": " + e.get("message", "")).strip(": ") for e in errs))
        S = res["samples"]["cols"]
        bias = [r.gauss(0, 0.003) for _ in range(3)]
        out = []
        for i in range(len(S["t"])):
            f = {"t": S["t"][i]}
            if self.mode == "edge":
                th = S["theta"][i]
                f["theta"] = th
                f["w"] = [S["thetadot"][i], 0.0, 0.0]
                phi = math.pi / 4 + th                      # edge attitude as a quaternion about body x (docs/EXPERIMENT_CONTRACT.md)
                R = _rotx(phi)
                f["torque_cmd"] = [S["Tc_x"][i], 0.0, 0.0]
            else:
                q = [S["q0"][i], S["q1"][i], S["q2"][i], S["q3"][i]]
                n = math.sqrt(sum(x * x for x in q))
                q = [x / n for x in q]
                f["q"] = q
                f["w"] = [S["wx"][i], S["wy"][i], S["wz"][i]]
                R = _qrot(q)
                f["torque_cmd"] = [S["Tc_x"][i], S["Tc_y"][i], S["Tc_z"][i]]
            f["wheel_rpm"] = [S[f"omega_{a}"][i] * 30 / math.pi for a in "xyz"]
            f["torque_meas"] = [S[f"T_{a}"][i] for a in "xyz"]
            g_body = [R[2][0] * G, R[2][1] * G, R[2][2] * G]      # Rᵀ·(0, 0, g): the third row of R (body→world)
            f["imu"] = {"gyro": [f["w"][j] + bias[j] + r.gauss(0, 0.002) for j in range(3)],
                        "accel": [g_body[j] + r.gauss(0, 0.02) for j in range(3)]}
            f["status"] = "ok"
            out.append(f)
        if len(self._episodes) > 4:
            self._episodes.pop(min(self._episodes))
        self._episodes[k] = out
        return out

    def next_frame(self) -> dict:
        """The next clean frame: continuous t and seq across episodes."""
        ep = self.episode(self.k_next)
        if self.i_next >= len(ep):
            self.k_next += 1
            self.i_next = 0
            ep = self.episode(self.k_next)
        base = ep[self.i_next]
        dt = 1.0 / self.rate_hz
        if self.i_next == 0 and self.seq_next > 0:
            self.t_next += dt                               # the next episode continues the clock
        elif self.i_next > 0:
            self.t_next += ep[self.i_next]["t"] - ep[self.i_next - 1]["t"]
        self.i_next += 1
        f = {"type": "frame", "t": round(self.t_next, 9), "seq": self.seq_next, "mode": self.mode}
        f.update({k: v for k, v in base.items() if k != "t"})
        self.seq_next += 1
        return f

    def session(self):
        """One connection's messages: ('line', bytes) | ('stall', seconds) | ('disconnect', None). Infinite unless a
        disconnect fault ends it."""
        F, rng = self.faults, self.rng
        self.sessions += 1
        if self.sessions > 1 and F.get("restart_clock"):
            self.t_next, self.seq_next = 0.0, 0
            self.k_next, self.i_next = self.k_next + 1, 0
        yield "line", dumps(self.hello())
        sent = 0
        held = None
        stalled = False
        while True:
            f = self.next_frame()
            if F.get("drop") and rng.random() < F["drop"]:
                continue
            if F.get("reorder") and held is None and rng.random() < F["reorder"]:
                held = f
                continue
            batch = [f] + ([held] if held is not None else [])
            held = None
            for fr in batch:
                if F.get("malformed") and rng.random() < F["malformed"]:
                    yield "line", b'{"type": "frame", "t": ' + str(fr["t"]).encode() + b', "seq": BROKEN\n'
                    continue
                if F.get("bad_quaternion") and "q" in fr and rng.random() < F["bad_quaternion"]:
                    fr = dict(fr, q=[x * 1.05 for x in fr["q"]])
                if F.get("wrong_units") and rng.random() < F["wrong_units"]:
                    fr = dict(fr, units=dict(UNITS, w="deg/s"))
                yield "line", dumps(fr)
                self.frames_sent += 1
                sent += 1
                if F.get("duplicate") and rng.random() < F["duplicate"]:
                    yield "line", dumps(fr)
                if F.get("stall_after") and not stalled and sent >= F["stall_after"]:
                    stalled = True
                    yield "stall", F.get("stall_s", 1.0)
                if F.get("disconnect_after") and sent >= F["disconnect_after"]:
                    yield "disconnect", None
                    return

    def write_session(self, path: str, frames: int) -> dict:
        """One session (hello, frames with the configured faults, bye) to an NDJSON file."""
        n_lines = n_frames = 0
        with open(path, "wb") as fh:
            for kind, val in self.session():
                if kind == "line":
                    fh.write(val)
                    n_lines += 1
                    if b'"type":"frame"' in val:
                        n_frames += 1
                elif kind == "disconnect":
                    break
                if n_frames >= frames:
                    break
            fh.write(dumps({"type": "bye"}))
        return {"path": path, "lines": n_lines + 1, "frames": n_frames}

    # ------------------------------------------------------------------ TCP server
    async def serve(self, host: str = "127.0.0.1", port: int = DEFAULT_PORT, *, speed: float = 1.0, allow_remote: bool = False, ready=None):
        err = check_host(host, allow_remote)
        if err:
            raise ValueError(err)
        lock = asyncio.Lock()      # one client at a time: a second client waits (the emulator is one simulated device)

        async def client(reader, writer):
            async with lock:
                try:
                    period = 1.0 / self.rate_hz / max(speed, 1e-6)
                    loop = asyncio.get_running_loop()
                    t0, k = loop.time(), 0
                    for kind, val in self.session():
                        if kind == "line":
                            writer.write(val)
                            if b'"type":"frame"' in val:
                                k += 1
                                wait = t0 + k * period - loop.time()
                                if wait > 0:
                                    await writer.drain()
                                    await asyncio.sleep(wait)
                                elif k % 50 == 0:
                                    await writer.drain()
                        elif kind == "stall":
                            await writer.drain()
                            await asyncio.sleep(val)
                            t0, k = loop.time(), 0
                        elif kind == "disconnect":
                            break
                except (ConnectionError, OSError):
                    pass
                finally:
                    try:
                        writer.close()
                        await writer.wait_closed()
                    except (ConnectionError, OSError):
                        pass
        server = await asyncio.start_server(client, host, port)
        bound = server.sockets[0].getsockname()[1]
        if ready is not None:
            ready(bound)
        async with server:
            await server.serve_forever()


def _qrot(q):
    w, x, y, z = q
    return [[1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]]


def _rotx(a):
    c, s = math.cos(a), math.sin(a)
    return [[1, 0, 0], [0, c, -s], [0, s, c]]


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m aeris_backend.telemetry.emulator", description="SYNTHETIC AERIS telemetry emulator (aeris-telemetry-ndjson/1). Not the physical cube.")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--mode", default="corner", choices=["corner", "edge"])
    ap.add_argument("--rate", type=float, default=100.0, help="frame rate [Hz]; must divide the engine's integration rate (e.g. 50, 100, 125, 250)")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--episode-s", type=float, default=8.0)
    ap.add_argument("--speed", type=float, default=1.0, help="time scale of the served stream (1 = real time)")
    ap.add_argument("--faults", default="")
    ap.add_argument("--allow-remote", action="store_true")
    ap.add_argument("--write", default=None, help="write one session to this NDJSON file and exit")
    ap.add_argument("--frames", type=int, default=1000)
    a = ap.parse_args(argv)
    try:
        emu = Emulator(mode=a.mode, rate_hz=a.rate, seed=a.seed, faults=a.faults, episode_s=a.episode_s)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    if a.write:
        info = emu.write_session(a.write, a.frames)
        print(json.dumps(dict(info, synthetic=True, note="SYNTHETIC emulator session")))
        return 0
    try:
        asyncio.run(emu.serve(a.host, a.port, speed=a.speed, allow_remote=a.allow_remote,
                              ready=lambda p: print(f"AERIS SYNTHETIC telemetry emulator on {a.host}:{p} ({a.mode}, {a.rate:g} Hz, seed {a.seed}"
                                                    + (f", faults {emu.faults}" if emu.faults else "") + "). Not the physical cube. Ctrl+C stops.", flush=True)))
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""NDJSON export of a stored recording in the WIRE units of aeris-telemetry-ndjson/1 (v5.2, review findings G1 and G2
of v5.1; docs/TELEMETRY.md §6).

v5.1 copied the stored sample values into frames without reading `samples.units`: an imported recording accepted in
ms, deg or deg/s (hardware/ingest.py accepts every unit of its tables) was exported as if those numbers were s, rad
and rad/s, the hub accepted the copy and a re-recording labelled it s/rad. Now every exported signal is converted to
the protocol's fixed unit (protocol.UNITS) with the SAME factors the importer uses (ingest.UNITS — there is no second
table): time → s, angles → rad, body and gyro rates → rad/s, wheel speed → rpm (also from omega_x… stored in rad/s),
torques → N·m, acceleration → m/s²; quaternions, sequence numbers and status codes are dimensionless. A column whose
unit already is the wire unit (or an alias with the same factor) is copied exactly, never multiplied.

Nothing is guessed, invented or relabelled. These are errors (ExportError, HTTP 422 with the column and row) instead
of v5.1's HTTP 500, silent omission or relabelling:
  * an incomplete vector (w_x without w_y, …): the stream carries 3-vectors and the export does not invent an axis;
  * columns the stream has no field for (estimates, references, extra wheels, unknown signals);
  * a status column whose codes the recording does not declare (provenance.status_codes; the AERIS recorder writes
    it), or a code outside that declaration (v5.1 called every unknown code "ok");
  * two wheel-speed column sets (wheel_rpm_* and omega_*), negative t or seq, an edge-mode recording without theta,
    source segments that do not cover the samples in order.
`omit_unmapped=True` leaves out the incomplete vectors, the unmapped columns and an undeclared status column instead,
and every hello's lineage records what was left out ("export": {"omitted": …}). A recording without a seq column gets
the row index as seq, recorded the same way ("export": {"seq": …}). The stored document is never changed: the JSON
export returns it byte for byte, with its own units.

Before anything is returned, the complete NDJSON text is fed through a scratch TelemetryHub exactly as a file replay
feeds it (line splitting with MAX_LINE, hello and frame validation, sequence and time rules): an export that the hub
would not accept line for line — every hello valid, every row an accepted frame — is an ExportError, never a file.
"""
from __future__ import annotations

import json

from ..hardware.ingest import STATUS, UNITS as UNIT_FACTORS, validate_recording
from .lineage import LineageError, export_segments, segments_of
from .protocol import MAX_LINE, UNITS as WIRE

# wire field → (column family, the column sets that can carry it); wire units come from protocol.UNITS
VECTORS = (
    ("w", "rate", (("w_x", "w_y", "w_z"),)),
    ("wheel_rpm", "wheel", (("wheel_rpm_x", "wheel_rpm_y", "wheel_rpm_z"), ("omega_x", "omega_y", "omega_z"))),
    ("torque_cmd", "torque", (("torque_cmd_x", "torque_cmd_y", "torque_cmd_z"),)),
    ("torque_meas", "torque", (("torque_meas_x", "torque_meas_y", "torque_meas_z"),)),
    ("imu.gyro", "rate", (("gyro_x", "gyro_y", "gyro_z"),)),
    ("imu.accel", "accel", (("accel_x", "accel_y", "accel_z"),)),
)
STREAM_FIELDS = "t, seq, q (q0–q3) or theta, w, wheel_rpm, torque_cmd, torque_meas, imu.gyro, imu.accel, status"
MAX_LISTED = 24          # column names listed in an export note (the count is always complete)


class ExportError(ValueError):
    """The recording cannot be written as aeris-telemetry-ndjson/1 without changing, inventing or losing data.
    details: [{"path", "message"}] (the API returns them with HTTP 422)."""

    def __init__(self, message: str, details: list | None = None):
        super().__init__(message)
        self.details = details or []


def _name(c: str) -> str:
    return c if len(c) <= 64 else c[:64] + "…"


def _to_wire(raw: list, si: list, fam: str, unit: str, wire_unit: str):
    """One column in the wire unit, using the importer's factors (ingest.UNITS): (values, conversion or None).
    The importer's SI values are x · factor(unit); the wire value is that / factor(wire unit) (1 for SI wire units)."""
    f_in, f_out = UNIT_FACTORS[fam][unit], UNIT_FACTORS[fam][wire_unit]
    if f_in == f_out:
        return list(raw), None                       # already the wire unit (or an alias with the same factor): copied exactly
    return (list(si) if f_out == 1.0 else [x / f_out for x in si]), f"{unit or '(none)'} → {wire_unit}"


def _status_table(doc: dict):
    t = (doc.get("provenance") or {}).get("status_codes") if isinstance(doc.get("provenance"), dict) else None
    if t is None:
        return None, None
    ok = (isinstance(t, dict) and t and all(k in STATUS for k in t)
          and all(isinstance(v, int) and not isinstance(v, bool) for v in t.values()) and len(set(t.values())) == len(t))
    if not ok:
        return None, ("provenance.status_codes: must map status names (" + ", ".join(STATUS) + ") to distinct integer codes; "
                      f"found {json.dumps(t, default=str)[:120]}")
    return {v: k for k, v in t.items()}, None


def wire_plan(doc: dict, *, omit_unmapped: bool = False) -> dict:
    """What an NDJSON export of `doc` writes: every stream field in its wire unit, the sequence numbers, and the
    export notes recorded in the lineage. Raises ExportError (see the module docstring)."""
    v = validate_recording(doc)
    if not v["ok"]:
        raise ExportError("The stored recording does not pass the importer's validation, so it cannot be exported as a stream.",
                          [{"path": e.split(":")[0] if ":" in e else "", "message": e} for e in v["errors"]])
    cols, units, si = doc["samples"]["cols"], doc["samples"]["units"], v["si"]
    n = len(cols["t"])
    E, omitted, converted, used = [], [], {}, set()

    def wire(c, fam, wire_unit):
        vals, conv = _to_wire(cols[c], si[c], fam, units[c], wire_unit)
        if conv:
            converted[_name(c)] = conv
        used.add(c)
        return vals

    plan = {"n": n, "t": wire("t", "time", WIRE["t"])}
    if plan["t"][0] < 0:
        E.append({"path": "samples.cols.t", "message": f"t starts at {cols['t'][0]} {units['t']} (= {plan['t'][0]} s); the stream's t is the time since the "
                                                      "session start and must be ≥ 0. The export does not shift the time base."})
    # sequence numbers: the stored ones (integers, checked by the importer) or, without a seq column, the row index
    if "seq" in cols:
        used.add("seq")
        plan["seq"] = [int(x) for x in cols["seq"]]
        neg = next((i for i, x in enumerate(plan["seq"]) if x < 0), None)
        if neg is not None:
            E.append({"path": f"samples.cols.seq[{neg}]", "message": f"{cols['seq'][neg]}: the stream's seq must be a non-negative integer"})
        plan["seq_source"] = "column"
    else:
        plan["seq"] = list(range(n))
        plan["seq_source"] = "row index"
    # attitude
    qc = [f"q{j}" for j in range(4)]
    qp = [c for c in qc if c in cols]
    if len(qp) == 4:
        plan["q"] = [wire(c, "unitless", WIRE["q"]) for c in qc]
    elif qp:
        msg = f"{', '.join(qp)} without {', '.join(c for c in qc if c not in cols)}: the stream's q is a 4-vector (w, x, y, z)"
        if omit_unmapped and "theta" in cols:
            omitted.append({"columns": qp, "reason": "incomplete quaternion"})
            used.update(qp)
        else:
            E.append({"path": "samples.cols." + qp[0], "message": msg + ("; the export does not invent the missing components "
                     "(export with omit_unmapped=true to stream theta only)" if "theta" in cols else "; the export does not invent the missing components")})
    if "theta" in cols:
        plan["theta"] = wire("theta", "angle", WIRE["theta"])
    if doc.get("mode") == "edge" and "theta" not in plan:
        E.append({"path": "samples.cols.theta", "message": "an edge-mode recording needs theta to be streamed (frames of an edge session must carry theta [rad]); "
                                                           "the export does not derive it from q0–q3"})
    # 3-vectors
    for field, fam, sets in VECTORS:
        present = [[c for c in s if c in cols] for s in sets]
        given = [i for i, p in enumerate(present) if p]
        if not given:
            continue
        if len(given) > 1:
            E.append({"path": "samples.cols", "message": f"{field}: two column sets carry it ({'; '.join(', '.join(present[i]) for i in given)}); keep one — "
                                                         "the export does not choose between them"})
            used.update(c for i in given for c in present[i])
            continue
        s, p = sets[given[0]], present[given[0]]
        if len(p) < 3:
            missing = [c for c in s if c not in cols]
            if omit_unmapped:
                omitted.append({"columns": p, "reason": f"incomplete {field} vector (missing {', '.join(missing)})"})
                used.update(p)
            else:
                E.append({"path": "samples.cols." + p[0], "message": f"{', '.join(p)} without {', '.join(missing)}: the stream's {field} is a 3-vector "
                                                                     f"[{WIRE[field]}] and the export does not invent a missing axis; add the missing column(s), "
                                                                     "remove the incomplete ones, or export with omit_unmapped=true to leave "
                                                                     f"{field} out (the omission is recorded in the export)"})
                used.update(p)
            continue
        plan[field] = [wire(c, fam, WIRE[field]) for c in s]
    # status codes → status names, only as the recording declares them
    if "status" in cols:
        used.add("status")
        inv, bad = _status_table(doc)
        problem = None
        if bad:
            problem = {"path": "provenance.status_codes", "message": bad}
        elif inv is None:
            problem = {"path": "samples.cols.status", "message": "the recording does not declare what its status codes mean (provenance.status_codes, e.g. "
                                                                 '{"ok": 0, "idle": 1, "calibrating": 2, "fault": 3, "estop": 4}); the export does not guess them'}
        else:
            for i, x in enumerate(cols["status"]):
                if float(x) != int(x) or int(x) not in inv:
                    problem = {"path": f"samples.cols.status[{i}]", "message": f"{x} is not one of the declared status codes "
                                                                               f"({', '.join(f'{c} {k}' for c, k in sorted(inv.items()))}); "
                                                                               "the export does not relabel it"}
                    break
        if problem is None:
            plan["status"] = [inv[int(x)] for x in cols["status"]]
        elif omit_unmapped:
            omitted.append({"columns": ["status"], "reason": problem["message"][:200]})
        else:
            problem["message"] += " (export with omit_unmapped=true to leave status out; the omission is recorded in the export)"
            E.append(problem)
    rest = [c for c in cols if c not in used]
    if rest:
        if omit_unmapped:
            omitted.append({"columns": rest, "reason": "no field in aeris-telemetry-ndjson/1"})
        else:
            E.append({"path": "samples.cols", "message": f"{', '.join(_name(c) for c in rest[:MAX_LISTED])}{f' (+{len(rest) - MAX_LISTED} more)' if len(rest) > MAX_LISTED else ''}: "
                                                         f"no field in aeris-telemetry-ndjson/1 (a stream carries {STREAM_FIELDS}). Export with omit_unmapped=true "
                                                         "to leave them out (recorded in the export), or use the JSON export, which keeps every column."})
    # source segments must cover the samples in order
    segs = segments_of(doc)
    pos = 0
    for s in segs:
        try:
            a, b = int(s["rows"][0]), int(s["rows"][1])
        except (TypeError, ValueError):
            a, b = -1, -1
        if a != pos or b <= a:
            E.append({"path": "provenance.segments", "message": f"segment {s.get('segment')}: rows {s.get('rows')} — the segments must cover the samples [0, {n}) "
                                                                "in order without gaps or overlaps"})
            break
        pos = b
    else:
        if pos != n:
            E.append({"path": "provenance.segments", "message": f"the segments end at row {pos}, the samples at {n}"})
    if E:
        raise ExportError("The recording cannot be exported as aeris-telemetry-ndjson/1 without changing, inventing or losing data.", E)
    notes = {}
    if converted:
        notes["converted"] = converted
    if plan["seq_source"] == "row index":
        notes["seq"] = "row index (the recording has no seq column, so gaps in the original sampling cannot be detected)"
    if omitted:
        names = [_name(c) for o in omitted for c in o["columns"]]
        notes["omitted"] = {"columns": names[:MAX_LISTED], "count": len(names), "reasons": list(dict.fromkeys(o["reason"][:200] for o in omitted))[:6],
                            "by": "omit_unmapped=true"}
    plan["notes"] = notes
    return plan


def _frame(plan: dict, i: int, mode: str) -> dict:
    f = {"type": "frame", "t": plan["t"][i], "seq": plan["seq"][i]}
    if "q" in plan:
        f["q"] = [c[i] for c in plan["q"]]
    if "theta" in plan:
        f["theta"] = plan["theta"][i]
    for key in ("w", "wheel_rpm", "torque_cmd", "torque_meas"):
        if key in plan:
            f[key] = [c[i] for c in plan[key]]
    if "imu.gyro" in plan or "imu.accel" in plan:
        f["imu"] = {}
        if "imu.gyro" in plan:
            f["imu"]["gyro"] = [c[i] for c in plan["imu.gyro"]]
        if "imu.accel" in plan:
            f["imu"]["accel"] = [c[i] for c in plan["imu.accel"]]
    if "status" in plan:
        f["status"] = plan["status"][i]
    f["mode"] = mode
    return f


def recording_to_ndjson(doc: dict, recording_id: str | None = None, *, omit_unmapped: bool = False, check: bool = True) -> str:
    """An NDJSON session (hello + frames per source segment, then bye) from a stored recording document, in wire units,
    replayable by FileReplay. Provenance never gains trust on the way (telemetry/lineage.py): a declared-physical
    recording keeps its sources' hellos; any recording with a synthetic, test or undeclared segment is exported so
    that every segment replays as synthetic. Every hello names the recording it was exported from (lineage, bounded).
    check=True (always, outside tests of the checker itself) replays the text through a scratch hub first."""
    plan = wire_plan(doc, omit_unmapped=omit_unmapped)
    try:
        segs = export_segments(doc, recording_id, notes=plan["notes"] or None)
    except LineageError as e:
        raise ExportError("The export's lineage cannot be kept within the protocol's limit.", [{"path": "provenance.lineage", "message": str(e)}]) from None
    lines = []
    for k, (hello, a, b) in enumerate(segs):
        if k:
            lines.append(json.dumps({"type": "bye"}))
        lines.append(json.dumps(hello, separators=(",", ":")))
        mode = hello.get("mode") or doc["mode"]
        for i in range(a, b):
            lines.append(json.dumps(_frame(plan, i, mode), separators=(",", ":"), allow_nan=False))
    lines.append(json.dumps({"type": "bye"}))
    text = "\n".join(lines) + "\n"
    if check:
        res = check_replayable(text, expect_frames=plan["n"], expect_hellos=len(segs))
        if not res["ok"]:
            raise ExportError("The generated export would not replay line for line; nothing was returned.", res["problems"])
    return text


def check_replayable(text: str, expect_frames: int | None = None, expect_hellos: int | None = None) -> dict:
    """Feed an NDJSON text through a scratch TelemetryHub exactly as FileReplaySource does (LineSplitter with MAX_LINE,
    hub.feed_line: hello and frame validation, duplicates, order and time). ok only if every line is accepted — each
    hello valid, each frame accepted as a frame — and the counts match the expectations."""
    from .stream import TelemetryHub                    # (stream imports this module)
    from .transport import TOO_LONG, LineSplitter
    hub = TelemetryHub(recent_frames=1, max_events=16)
    hub.on_connect({"kind": "export-check", "address": "recording_to_ndjson"}, 0.0)
    sp = LineSplitter()
    problems, frames, hellos, k = [], 0, 0, 0
    for line in sp.feed(text.encode("utf-8")):
        k += 1
        if line is TOO_LONG:
            problems.append({"path": f"line {k}", "message": f"longer than the protocol's MAX_LINE ({MAX_LINE} bytes)"})
        else:
            r = hub.feed_line(line, 0.0)
            if r == "frame":
                frames += 1
            elif r == "hello":
                hellos += 1
            elif r != "bye":
                detail = hub.last_errors[-1]["detail"] if hub.last_errors and r.startswith("rejected") else ""
                problems.append({"path": f"line {k}", "message": f"{r}{': ' + detail if detail else ''}"[:400]})
        if len(problems) >= 20:
            problems.append({"path": "", "message": "(further lines not checked)"})
            break
    if not problems:
        tail = sp.tail()
        if tail.strip():
            problems.append({"path": f"line {k + 1}", "message": "the text does not end with a newline"})
        if expect_frames is not None and frames != expect_frames:
            problems.append({"path": "", "message": f"{frames} frames accepted, {expect_frames} rows exported"})
        if expect_hellos is not None and hellos != expect_hellos:
            problems.append({"path": "", "message": f"{hellos} hellos accepted, {expect_hellos} segments exported"})
    return {"ok": not problems, "lines": k, "frames": frames, "hellos": hellos, "problems": problems}

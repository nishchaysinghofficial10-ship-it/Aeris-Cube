"""Read-only telemetry pipeline (docs/TELEMETRY.md):

    transport (NDJSON over local TCP, or a file replay)
      → strict validation (protocol.py: session hello, frames, units and frame conventions)
      → normalised stream with sequence, gap, duplicate, reorder and staleness rules (stream.py: TelemetryHub)
      → subscribers (live WebSocket, bounded queues: a slow consumer loses its oldest frames, never blocks the reader)
      → recorder (aeris-hardware-run/1 document with provenance) → storage → export / replay / offline comparison

The wire format aeris-telemetry-ndjson/1 is this software's PROPOSED reference contract, not a
description of any existing firmware. A device-specific adapter (device.py) translates a real
device's protocol into it (docs/HARDWARE_HANDOFF.md). The emulator (emulator.py) is SYNTHETIC: its
sessions are always labelled synthetic, never reported as the physical cube, and never admissible
as validation evidence. Nothing here sends anything to a device: the pipeline is receive-only.
"""

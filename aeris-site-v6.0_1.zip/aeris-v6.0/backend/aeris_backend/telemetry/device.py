"""Device adapters: the one place where a specific device's telemetry is mapped onto the reference contract
(protocol.py, docs/TELEMETRY.md §5, docs/HARDWARE_HANDOFF.md).

A DeviceAdapter is deliberately small and READ-ONLY: it turns what a device sends into contract messages and has
no method that sends anything to the device (no commands, no set-points, no motor control — those belong to the
later firmware stage). Its output is validated by the hub exactly like any other source.

  DeviceAdapter          the interface (hello, decode)
  ContractAdapter        a device that already speaks aeris-telemetry-ndjson/1 (pass-through)
  MappedJsonAdapter      a device that sends one JSON object per line with its own field names, units, quaternion
                         order, axes and clock: everything is declared in a mapping (see MAPPING_TEMPLATE), nothing
                         is guessed. The mapping is what the hardware owner supplies (HARDWARE_HANDOFF.md §2).

No mapping for the physical AERIS cube exists yet: its firmware and protocol are not available to this software.
"""
from __future__ import annotations

import json
import math
from abc import ABC, abstractmethod

from .protocol import CONVENTIONS, PROTOCOL, SOURCE_KINDS


class AdapterError(ValueError):
    pass


class DeviceAdapter(ABC):
    name = "abstract"

    @abstractmethod
    def hello(self) -> dict | None:
        """The contract hello for this device (identity, firmware version, synthetic flag, mode), or None when the
        device sends its own contract hello."""

    @abstractmethod
    def decode(self, line: bytes) -> list[dict]:
        """One line/packet from the device → zero or more contract messages (frame / status / bye). Raise
        AdapterError for input that cannot be decoded; the hub counts it as a rejected line."""


class ContractAdapter(DeviceAdapter):
    name = "contract"

    def hello(self):
        return None

    def decode(self, line: bytes) -> list[dict]:
        try:
            m = json.loads(line)
        except (ValueError, UnicodeDecodeError) as e:
            raise AdapterError(f"not JSON: {e}") from None
        return [m]


MAPPING_TEMPLATE = {
    "device": {"id": "<serial or name>", "kind": "physical", "firmware": "<firmware version string>"},
    "mode": "corner",
    "rate_hz": 200,
    "type_field": None,                     # field naming the message kind, or None when every line is a frame
    "time": {"field": "ts_us", "scale": 1e-6, "wrap": 4294967296},     # device clock → seconds; wrap: counter modulus
    "seq": {"field": "n"},
    "quaternion": {"field": "quat", "order": "xyzw"},                   # the device's component order
    "theta": None,                          # edge mode: {"field": ..., "scale": ...} [→ rad]
    "vectors": {                            # body-frame 3-vectors: device axes are rotated with 'axes'
        "w": {"field": "gyr", "scale": 0.017453292519943295},           # deg/s → rad/s
    },
    "imu": {"gyro": {"field": "gyr", "scale": 0.017453292519943295}, "accel": {"field": "acc", "scale": 9.80665}},
    "wheels": {                             # per-wheel values (not rotated): device order and sign per contract wheel x, y, z
        "wheel_rpm": {"field": "rpm", "index": [0, 1, 2], "sign": [1, 1, 1], "scale": 1.0},
        "torque_cmd": {"field": "tq_cmd", "index": [0, 1, 2], "sign": [1, 1, 1], "scale": 0.001},   # mN·m → N·m
        "torque_meas": {"field": "tq", "index": [0, 1, 2], "sign": [1, 1, 1], "scale": 0.001},
    },
    "axes": [[1, 0, 0], [0, 1, 0], [0, 0, 1]],      # C: contract body vector = C · device body vector (proper rotation)
    "world": [[1, 0, 0], [0, 1, 0], [0, 0, 1]],     # D: contract world vector = D · device world vector (z up; NED → diag(1, -1, -1))
    "status": {"field": "st", "map": {"0": "ok", "1": "idle", "2": "calibrating", "3": "fault", "4": "estop"}},
}


def _det3(M):
    return (M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0])
            + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]))


def _is_rotation(M) -> bool:
    if not (isinstance(M, list) and len(M) == 3 and all(isinstance(r, list) and len(r) == 3 and all(isinstance(x, (int, float)) for x in r) for r in M)):
        return False
    for i in range(3):
        for j in range(3):
            d = sum(M[k][i] * M[k][j] for k in range(3))
            if abs(d - (1.0 if i == j else 0.0)) > 1e-6:
                return False
    return abs(_det3(M) - 1.0) < 1e-6


def _mat_quat(M):
    """Unit quaternion (w, x, y, z) of a rotation matrix."""
    tr = M[0][0] + M[1][1] + M[2][2]
    if tr > 0:
        s = math.sqrt(tr + 1.0) * 2
        q = [0.25 * s, (M[2][1] - M[1][2]) / s, (M[0][2] - M[2][0]) / s, (M[1][0] - M[0][1]) / s]
    elif M[0][0] > M[1][1] and M[0][0] > M[2][2]:
        s = math.sqrt(1.0 + M[0][0] - M[1][1] - M[2][2]) * 2
        q = [(M[2][1] - M[1][2]) / s, 0.25 * s, (M[0][1] + M[1][0]) / s, (M[0][2] + M[2][0]) / s]
    elif M[1][1] > M[2][2]:
        s = math.sqrt(1.0 + M[1][1] - M[0][0] - M[2][2]) * 2
        q = [(M[0][2] - M[2][0]) / s, (M[0][1] + M[1][0]) / s, 0.25 * s, (M[1][2] + M[2][1]) / s]
    else:
        s = math.sqrt(1.0 + M[2][2] - M[0][0] - M[1][1]) * 2
        q = [(M[1][0] - M[0][1]) / s, (M[0][2] + M[2][0]) / s, (M[1][2] + M[2][1]) / s, 0.25 * s]
    n = math.sqrt(sum(x * x for x in q))
    return [x / n for x in q]


def _qmul(a, b):
    return [a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
            a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
            a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
            a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]]


def _conj(q):
    return [q[0], -q[1], -q[2], -q[3]]


def _mv(M, v):
    return [sum(M[i][k] * v[k] for k in range(3)) for i in range(3)]


def check_mapping(m: dict) -> list[str]:
    E = []
    dev = m.get("device") or {}
    if not isinstance(dev.get("id"), str) or not dev["id"] or dev["id"].startswith("<"):
        E.append("device.id: the device's identity (serial or name)")
    if dev.get("kind") not in SOURCE_KINDS:
        E.append(f"device.kind: one of {', '.join(SOURCE_KINDS)}")
    if not isinstance(dev.get("firmware"), str) or dev["firmware"].startswith("<"):
        E.append("device.firmware: the firmware version the mapping was written for")
    if m.get("mode") not in ("edge", "corner", "free"):
        E.append("mode: edge, corner or free")
    tm = m.get("time") or {}
    if not isinstance(tm.get("field"), str) or not (isinstance(tm.get("scale"), (int, float)) and tm["scale"] > 0):
        E.append("time: {field, scale > 0 [s per device unit]} is required")
    if tm.get("wrap") is not None and not (isinstance(tm["wrap"], (int, float)) and tm["wrap"] > 0):
        E.append("time.wrap: the counter modulus (e.g. 4294967296 for a 32-bit µs counter)")
    if not isinstance((m.get("seq") or {}).get("field"), str):
        E.append("seq: {field} is required (duplicate, gap and order detection)")
    qm = m.get("quaternion")
    if qm is not None and (not isinstance(qm.get("field"), str) or qm.get("order") not in ("wxyz", "xyzw")):
        E.append("quaternion: {field, order: 'wxyz' | 'xyzw'}")
    if m.get("mode") == "edge" and not m.get("theta") and qm is None:
        E.append("theta: edge mode needs the tilt angle {field, scale → rad} (or a quaternion)")
    for k in ("axes", "world"):
        if not _is_rotation(m.get(k, [[1, 0, 0], [0, 1, 0], [0, 0, 1]])):
            E.append(f"{k}: must be a proper rotation matrix (orthonormal, determinant +1); a mirrored axis set is an error in the mapping")
    for k, spec in (m.get("vectors") or {}).items():
        if k not in ("w",):
            E.append(f"vectors.{k}: only 'w' (body rate) is a body-frame vector of the contract")
        elif not isinstance(spec.get("field"), str):
            E.append(f"vectors.{k}.field: required")
    for k, spec in (m.get("imu") or {}).items():
        if k not in ("gyro", "accel") or not isinstance(spec.get("field"), str):
            E.append(f"imu.{k}: gyro or accel with a field")
    for k, spec in (m.get("wheels") or {}).items():
        if k not in ("wheel_rpm", "torque_cmd", "torque_meas"):
            E.append(f"wheels.{k}: wheel_rpm, torque_cmd or torque_meas")
            continue
        if sorted(spec.get("index", [0, 1, 2])) != [0, 1, 2] or any(s not in (1, -1) for s in spec.get("sign", [1, 1, 1])):
            E.append(f"wheels.{k}: index must be a permutation of 0, 1, 2 and sign ±1 per wheel")
    return E


class MappedJsonAdapter(DeviceAdapter):
    name = "mapped-json"

    def __init__(self, mapping: dict):
        E = check_mapping(mapping)
        if E:
            raise AdapterError("invalid device mapping: " + "; ".join(E))
        self.m = mapping
        self.C = mapping.get("axes", [[1, 0, 0], [0, 1, 0], [0, 0, 1]])
        self.D = mapping.get("world", [[1, 0, 0], [0, 1, 0], [0, 0, 1]])
        self.qC, self.qD = _mat_quat(self.C), _mat_quat(self.D)
        self.t0 = None
        self.prev_raw = None
        self.wraps = 0

    def hello(self) -> dict:
        d = self.m["device"]
        return {"type": "hello", "protocol": PROTOCOL, "device": {"id": d["id"], "kind": d["kind"], "firmware": d["firmware"]},
                "synthetic": d["kind"] in ("emulator", "test") or bool(d.get("synthetic")), "mode": self.m["mode"],
                "nominal_rate_hz": self.m.get("rate_hz"), "conventions": dict(CONVENTIONS),
                "adapter": {"name": self.name, "mapping_note": self.m.get("note")}}

    @staticmethod
    def _get(obj, field):
        cur = obj
        for part in field.split("."):
            if not isinstance(cur, dict) or part not in cur:
                raise AdapterError(f"missing field '{field}'")
            cur = cur[part]
        return cur

    def _vec(self, obj, spec, n=3):
        v = self._get(obj, spec["field"])
        if not (isinstance(v, list) and len(v) == n and all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in v)):
            raise AdapterError(f"field '{spec['field']}': expected {n} numbers")
        return [x * spec.get("scale", 1.0) for x in v]

    def decode(self, line: bytes) -> list[dict]:
        try:
            obj = json.loads(line)
        except (ValueError, UnicodeDecodeError) as e:
            raise AdapterError(f"not JSON: {e}") from None
        if not isinstance(obj, dict):
            raise AdapterError("not a JSON object")
        m = self.m
        tf = m.get("type_field")
        if tf:
            kind = obj.get(tf)
            if kind in ("bye", "end"):
                return [{"type": "bye"}]
            if kind in ("status", "log"):
                return [{"type": "status", "state": str(obj.get("state") or obj.get("msg") or kind)[:80]}]
        tm = m["time"]
        raw = self._get(obj, tm["field"])
        if not isinstance(raw, (int, float)) or isinstance(raw, bool):
            raise AdapterError(f"field '{tm['field']}': the time stamp must be a number")
        if self.prev_raw is not None and raw < self.prev_raw and tm.get("wrap"):
            if self.prev_raw - raw > tm["wrap"] / 2:       # the counter wrapped (a small step back is left to the hub: not increasing)
                self.wraps += 1
        self.prev_raw = raw
        ticks = raw + self.wraps * (tm.get("wrap") or 0)
        if self.t0 is None:
            self.t0 = ticks
        f = {"type": "frame", "t": (ticks - self.t0) * tm["scale"], "seq": self._get(obj, m["seq"]["field"])}
        qm = m.get("quaternion")
        if qm is not None:
            q = self._vec(obj, {"field": qm["field"]}, 4)
            if qm["order"] == "xyzw":
                q = [q[3], q[0], q[1], q[2]]
            # device attitude R_d (device body → device world); contract R = D · R_d · Cᵀ  →  q = q_D ⊗ q_d ⊗ conj(q_C)
            q = _qmul(_qmul(self.qD, q), _conj(self.qC))
            f["q"] = q if q[0] >= 0 else [-x for x in q]
        if m.get("theta"):
            f["theta"] = float(self._get(obj, m["theta"]["field"])) * m["theta"].get("scale", 1.0)
        for k, spec in (m.get("vectors") or {}).items():
            f[k] = _mv(self.C, self._vec(obj, spec))
        imu = {}
        for k, spec in (m.get("imu") or {}).items():
            imu[k] = _mv(self.C, self._vec(obj, spec))
        if imu:
            f["imu"] = imu
        for k, spec in (m.get("wheels") or {}).items():
            v = self._get(obj, spec["field"])
            if not (isinstance(v, list) and len(v) >= 3 and all(isinstance(x, (int, float)) for x in v)):
                raise AdapterError(f"field '{spec['field']}': expected one number per wheel")
            idx, sg, sc = spec.get("index", [0, 1, 2]), spec.get("sign", [1, 1, 1]), spec.get("scale", 1.0)
            f[k] = [v[idx[j]] * sg[j] * sc for j in range(3)]
        st = m.get("status")
        if st:
            code = obj.get(st["field"])
            if code is not None:
                s = st.get("map", {}).get(str(code))
                if s is None:
                    raise AdapterError(f"field '{st['field']}': status code {code!r} is not in the mapping")
                f["status"] = s
        f["mode"] = m["mode"]
        return [f]

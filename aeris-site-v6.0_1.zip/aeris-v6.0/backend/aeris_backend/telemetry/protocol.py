"""aeris-telemetry-ndjson/1 — the proposed reference telemetry contract (docs/TELEMETRY.md §2).

One JSON object per line (UTF-8, '\\n'-terminated, at most MAX_LINE bytes). Every object has a "type":

  hello   first message of every connection: identity, provenance and conventions of the source
          {"type": "hello", "protocol": "aeris-telemetry-ndjson/1",
           "device": {"id": str, "kind": "physical" | "emulator" | "file-replay" | "test", "firmware": str},
           "synthetic": bool, "mode": "edge" | "corner" | "free", "nominal_rate_hz": number,
           "conventions": CONVENTIONS (exactly these values; a device adapter converts anything else)}
  frame   one sample, the fields of aeris-telemetry-frame/1 (hardware/ingest.py parse_frame):
          t [s since session start], seq (integer, +1 per sample), q [w, x, y, z] body→world (unit ±1e-3)
          or theta [rad], w [rad/s], wheel_rpm [rpm], torque_cmd / torque_meas [N·m],
          imu {gyro [rad/s], accel [m/s²]}, status
          A frame may repeat "units"; they must equal UNITS (declared units are checked, never converted).
  status  free-form source status, e.g. {"type": "status", "state": "calibrating"} (recorded, not a sample)
  bye     the source ends the session cleanly

Provenance rules: kind "emulator" and "test" must declare synthetic: true; "physical" must declare
synthetic: false. The backend reports "physical" only as DECLARED by the source — it cannot verify
that a physical cube is attached — and never promotes a synthetic session.

Additive in v5.1 (optional, older sources are unaffected): a hello may carry "lineage" — an object naming the
recording an NDJSON export came from and the original declaration ({"derived_from", "original_device",
"original_synthetic", "trust": "synthetic" | "declared-physical" | "unknown", "reason", "ancestors"}). The backend's
own exports always write it; an export of anything synthetic uses the synthetic replay identity
device.kind "file-replay" with synthetic: true for every segment that was not already synthetic. A lineage whose
trust is "synthetic" makes the session synthetic whatever the rest of the hello says (telemetry/lineage.py).
"""
from __future__ import annotations

import json
import math

from ..hardware.ingest import MODES, parse_frame

PROTOCOL = "aeris-telemetry-ndjson/1"
MAX_LINE = 65536
MAX_LINEAGE = 8192
SOURCE_KINDS = ("physical", "emulator", "file-replay", "test")
CONVENTIONS = {
    "quaternion": "w,x,y,z; body to world; Hamilton product",
    "body_axes": "x, y, z along the cube edges from the pivot corner",
    "world_axes": "z up",
    "time": "seconds since the session start (monotonic)",
}
UNITS = {"t": "s", "q": "1", "theta": "rad", "w": "rad/s", "wheel_rpm": "rpm", "torque_cmd": "N·m", "torque_meas": "N·m",
         "imu.gyro": "rad/s", "imu.accel": "m/s²"}
MESSAGE_TYPES = ("hello", "frame", "status", "bye")


def parse_line(raw) -> tuple[dict | None, str | None]:
    """Decode one line. Returns (message, None) or (None, reason)."""
    if isinstance(raw, (bytes, bytearray)):
        if len(raw) > MAX_LINE:
            return None, "line_too_long"
        try:
            raw = raw.decode("utf-8")
        except UnicodeDecodeError:
            return None, "not_utf8"
    if len(raw) > MAX_LINE:
        return None, "line_too_long"
    raw = raw.strip()
    if not raw:
        return None, "empty_line"
    try:
        msg = json.loads(raw)
    except (ValueError, RecursionError):
        return None, "not_json"
    if not isinstance(msg, dict):
        return None, "not_an_object"
    if msg.get("type") not in MESSAGE_TYPES:
        return None, "unknown_type"
    return msg, None


def validate_hello(h: dict) -> dict:
    E = []
    if h.get("protocol") != PROTOCOL:
        E.append(f"protocol: expected '{PROTOCOL}', got {h.get('protocol')!r}")
    dev = h.get("device")
    if not isinstance(dev, dict) or not isinstance(dev.get("id"), str) or not dev.get("id"):
        E.append("device.id: required string")
        dev = {}
    if dev.get("kind") not in SOURCE_KINDS:
        E.append(f"device.kind: must be one of {', '.join(SOURCE_KINDS)}")
    if not isinstance(dev.get("firmware"), str):
        E.append("device.firmware: required string ('unknown' if the source cannot tell)")
    syn = h.get("synthetic")
    if not isinstance(syn, bool):
        E.append("synthetic: required true or false (never inferred)")
    elif dev.get("kind") in ("emulator", "test") and syn is not True:
        E.append(f"synthetic: a '{dev.get('kind')}' source must declare synthetic: true")
    elif dev.get("kind") == "physical" and syn is not False:
        E.append("synthetic: a 'physical' source must declare synthetic: false")
    if h.get("mode") not in MODES:
        E.append(f"mode: must be one of {', '.join(MODES)}")
    conv = h.get("conventions")
    if not isinstance(conv, dict):
        E.append("conventions: required object (frame and axis conventions)")
    else:
        for k, v in CONVENTIONS.items():
            if conv.get(k) != v:
                E.append(f"conventions.{k}: {conv.get(k)!r} is not the contract's {v!r}; convert in the device adapter (frame/axis mismatch)")
    r = h.get("nominal_rate_hz")
    if r is not None and not (isinstance(r, (int, float)) and not isinstance(r, bool) and math.isfinite(r) and r > 0):
        E.append("nominal_rate_hz: must be a positive number when given")
    lin = h.get("lineage")
    if lin is not None:
        if not isinstance(lin, dict):
            E.append("lineage: must be an object when given (where an exported recording came from)")
        elif len(json.dumps(lin, default=str)) > MAX_LINEAGE:
            E.append(f"lineage: at most {MAX_LINEAGE} bytes")
        elif lin.get("trust") is not None and lin.get("trust") not in ("synthetic", "declared-physical", "unknown"):
            E.append("lineage.trust: must be 'synthetic', 'declared-physical' or 'unknown'")
    return {"ok": not E, "errors": E}


def validate_frame(f: dict, hello: dict | None) -> dict:
    """A frame line against the contract and its session's hello."""
    E = []
    body = {k: v for k, v in f.items() if k not in ("type", "units")}
    units = f.get("units")
    if units is not None:
        if not isinstance(units, dict):
            E.append("units: must be an object when given")
        else:
            for k, u in units.items():
                if UNITS.get(k) != u:
                    E.append(f"units.{k}: '{u}' is not the contract unit '{UNITS.get(k, '(unknown field)')}' (unit mismatch; nothing is converted)")
    r = parse_frame(body)
    E += r["errors"]
    if hello is not None and body.get("mode") is not None and body["mode"] != hello.get("mode"):
        E.append(f"mode: frame says {body['mode']!r} but the session hello says {hello.get('mode')!r}")
    if hello is not None and hello.get("mode") == "edge" and "theta" not in body and "q" in body:
        E.append("edge session: frames need theta [rad]")
    if "seq" not in body:
        E.append("seq: required in a stream (duplicate, gap and order detection)")
    return {"ok": not E, "errors": E, "warnings": r.get("warnings", []), "frame": body}


def hello_message(device_id: str, kind: str, firmware: str, synthetic: bool, mode: str, rate_hz: float | None = None, **extra) -> dict:
    out = {"type": "hello", "protocol": PROTOCOL, "device": {"id": device_id, "kind": kind, "firmware": firmware}, "synthetic": synthetic,
           "mode": mode, "conventions": dict(CONVENTIONS)}
    if rate_hz is not None:
        out["nominal_rate_hz"] = rate_hz
    out.update(extra)
    return out


def dumps(msg: dict) -> bytes:
    return (json.dumps(msg, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")

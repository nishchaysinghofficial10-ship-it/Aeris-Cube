"""Conservative provenance of telemetry recordings (docs/TELEMETRY.md §6, review finding F1 of v5).

A recording can span several source segments (reconnects, a source replaced while recording). Provenance only ever
travels DOWN in trust: one synthetic, test or undeclared segment makes the whole recording — and everything derived
from it (JSON/NDJSON exports, replays, recordings of replays, datasets, comparisons) — non-evidence.

classify(doc) reads an aeris-hardware-run/1 document and returns

  trust      "synthetic"          any sign of synthetic data: the document's flag, a synthetic/emulator/test hello or
                                  segment, a synthetic ancestor in the lineage of a replayed export, a mixed recording
                                  that includes any of these
             "declared-physical"  every segment was DECLARED physical by its source (synthetic: false) and nothing in the
                                  lineage is synthetic; the software still cannot verify that a physical cube was attached
             "unknown"            no telemetry source declared the origin (e.g. an uploaded file without hellos) or a
                                  declaration is missing/ambiguous: never treated as physical
  synthetic  True unless trust is "declared-physical" or "unknown" (unknown is reported as unknown, never as physical)
  derived    the recording was captured from a replay (transport "file"): a copy of earlier data, not an original
             measurement (evidence must use the original recording)

export_segments(doc, recording_id) chooses, per segment, the hello an NDJSON export writes: a declared-physical
recording keeps its sources' own hellos; any other recording is exported so that EVERY segment replays as
synthetic — a segment whose own hello is synthetic keeps it, any other segment gets the protocol-valid synthetic
replay identity (device kind "file-replay", synthetic: true; a "physical" hello can never say synthetic: true).
Each exported hello carries a "lineage" object naming the recording it came from and the original declaration.
Old (v5) documents are never rewritten: they are classified and exported by these rules as they are.

Bounded lineage (v5.2, review finding G2 of v5.1). A v5.1 export nested the previous lineage objects ("ancestors"),
each with its own nested ancestors, so the lineage grew with every export → replay → re-record generation until the
hello broke the protocol's 8 KiB lineage limit (the fifth generation of a two-segment recording). A v5.2 lineage is
FLAT: "ancestry" lists compact references to earlier exports (derived_from, generation, trust, original declaration),
deduplicated, newest first, at most MAX_ANCESTRY of them — the parents and the original sources are kept, the middle
generations are dropped first, and "ancestry_omitted" says how many were dropped. The conservative status never
depends on that descriptive list: "trust" (as before) and "ancestry_trust" (the least trustworthy of EVERY ancestor,
dropped or not) carry it, and "generation" counts the export steps since the original recording. Readers still
understand v5.1's nested "ancestors" (they are flattened on the next export and checked by classify()); stored
documents are never rewritten. Every lineage an export writes stays within LINEAGE_BUDGET bytes (as the protocol
measures it), below the protocol's MAX_LINEAGE.
"""
from __future__ import annotations

import copy
import json

from .protocol import CONVENTIONS, MAX_LINEAGE, PROTOCOL

SYNTHETIC_KINDS = ("emulator", "test")
LINEAGE_KEYS = ("derived_from", "exported_by", "original_device", "original_synthetic", "trust", "reason", "ancestors",          # v5.1
                "generation", "ancestry", "ancestry_trust", "ancestry_omitted", "ancestry_note", "export")                   # v5.2 (additive)
TRUSTS = ("synthetic", "unknown", "declared-physical")      # least trustworthy first
MAX_ANCESTRY = 12             # flattened ancestry references kept per exported hello
KEEP_ORIGINS = 4              # of those, the oldest references (the original sources) that are always kept
LINEAGE_BUDGET = 6144         # bytes an exported lineage may use (protocol limit MAX_LINEAGE = 8192)
MAX_TEXT = 160                # characters kept from an identifier or text field copied into the lineage
MAX_WALK = 20000              # lineage objects read from v5.1 nested ancestors before the walk stops (then: unknown)
assert LINEAGE_BUDGET < MAX_LINEAGE


def _worst(*trusts) -> str:
    """The least trustworthy of the given trust classes (anything unrecognised counts as unknown)."""
    vals = [t if t in TRUSTS else "unknown" for t in trusts]
    return min(vals, key=TRUSTS.index) if vals else "declared-physical"


def _measure(obj) -> int:
    """The size the protocol checks (protocol.validate_hello: len(json.dumps(lineage, default=str)))."""
    return len(json.dumps(obj, default=str))


def _text(x, limit=MAX_TEXT):
    """A bounded copy of an identifier or text field; a cut is marked, never silent."""
    if x is None or isinstance(x, (bool, int, float)):
        return x
    s = x if isinstance(x, str) else json.dumps(x, default=str)
    return s if len(s) <= limit else s[:limit] + f"…[{len(s) - limit} more characters]"


def _device(d) -> dict:
    d = d if isinstance(d, dict) else {}
    return {k: _text(d.get(k)) for k in ("id", "kind", "firmware") if d.get(k) is not None}


def _stated(l: dict):
    """The trust one lineage object (or ancestry reference) STATES: 'synthetic' when its trust says so or its original
    declaration was not synthetic: false; 'unknown' / 'declared-physical' as stated; None when it states no trust (as in
    v5.1, a lineage without a trust neither lowers nor raises anything); an unrecognised value counts as unknown."""
    t, osyn = l.get("trust"), l.get("original_synthetic")
    if t == "synthetic" or (osyn is not None and osyn is not False):
        return "synthetic"
    if t is None:
        return None
    return t if t in ("unknown", "declared-physical") else "unknown"


def _children(l: dict) -> list:
    a = l.get("ancestors")                         # v5.1: nested copies of the previous lineage objects
    return [x for x in a if isinstance(x, dict)] if isinstance(a, list) else []


def _stated_generation(l: dict):
    g = l.get("generation")
    return g if isinstance(g, int) and not isinstance(g, bool) and g >= 1 else None


def _ref(l: dict, generation: int) -> dict:
    """A compact, flat reference to one earlier export: which recording it came from, how many export steps from the
    original recording, the trust it stated and the original declaration (device id/kind/firmware)."""
    r = {"derived_from": _text(l.get("derived_from")), "generation": generation, "trust": _stated(l)}
    osyn = l.get("original_synthetic")
    r["original_synthetic"] = osyn if (osyn is None or isinstance(osyn, bool)) else True
    dev = _device(l.get("original_device"))
    if dev:
        r["original_device"] = dev
    return r


def collect(lineages) -> dict:
    """Everything a list of lineage objects says about the history behind them, flattened (no nesting):

      refs        one compact reference per lineage object reachable through v5.1 nested 'ancestors', plus every v5.2
                  'ancestry' reference, deduplicated, newest generation first
      trust       the least trustworthy status STATED anywhere — own trust, original declarations, v5.2 'ancestry_trust'
                  summaries, every reference and nested ancestor — or None when nothing states one; 'unknown' when the
                  walk had to stop (MAX_WALK objects)
      generation  the largest generation among them (0 for none)
      omitted     the largest number of references an earlier export reported dropping ('ancestry_omitted')
      cut         whether the walk stopped early"""
    tops = [x for x in (lineages or []) if isinstance(x, dict)]
    height, order, cut = {}, [], False
    stack = [(l, False) for l in reversed(tops)]
    while stack:                                   # iterative post-order: generations of v5.1 nested ancestors
        node, post = stack.pop()
        if post:
            g = _stated_generation(node)
            height[id(node)] = g if g is not None else 1 + max((height.get(id(a), 1) for a in _children(node)), default=0)
            continue
        if len(order) >= MAX_WALK:
            cut = True
            break
        order.append(node)
        stack.append((node, True))
        stack.extend((a, False) for a in reversed(_children(node)))
    stated, refs, omitted = [], [], 0
    for node in order:
        g = height.get(id(node)) or _stated_generation(node) or 1
        stated.append(_stated(node))
        if node.get("ancestry_trust") is not None:
            stated.append(node["ancestry_trust"] if node["ancestry_trust"] in TRUSTS else "unknown")
        refs.append(_ref(node, g))
        anc = node.get("ancestry")
        for r in (anc if isinstance(anc, list) else []):
            if isinstance(r, dict):
                stated.append(_stated(r))
                refs.append(_ref(r, _stated_generation(r) or max(1, g - 1)))
        om = node.get("ancestry_omitted")
        if isinstance(om, int) and not isinstance(om, bool) and om > omitted:
            omitted = om
    if cut:
        stated.append("unknown")
    stated = [t for t in stated if t is not None]
    seen, flat = set(), []
    for r in sorted(refs, key=lambda r: -r["generation"]):          # stable: keeps the walk order within a generation
        k = json.dumps(r, sort_keys=True, default=str)
        if k not in seen:
            seen.add(k)
            flat.append(r)
    return {"refs": flat, "trust": _worst(*stated) if stated else None, "generation": max((r["generation"] for r in flat), default=0),
            "omitted": omitted, "cut": cut}


def ancestry_trust(lineage: dict):
    """The least trustworthy status stated anywhere in one lineage object (see collect); None if nothing is stated."""
    return collect([lineage])["trust"]


def _select(refs: list, limit: int) -> tuple[list, int]:
    """At most `limit` references: the newest (parents first) and the KEEP_ORIGINS oldest (the original sources);
    the generations in between are dropped first. Returns (kept, dropped)."""
    if len(refs) <= limit:
        return list(refs), 0
    if limit <= 0:
        return [], len(refs)
    origins = min(KEEP_ORIGINS, limit // 2)
    head = refs[:limit - origins]
    tail = refs[len(refs) - origins:] if origins else []
    return head + tail, len(refs) - limit


def _identity(h: dict) -> tuple:
    d = (h or {}).get("device") or {}
    return (d.get("id"), d.get("kind"), d.get("firmware"), (h or {}).get("synthetic"), (h or {}).get("mode"))


def _hello_trust(h) -> str:
    """Trust of one hello (a source declaration). Its lineage can only lower it: the lineage's own trust and original
    declaration (as in v5.1) and, since v5.2, everything stated in its history — the 'ancestry_trust' summary, the
    flattened 'ancestry' references and v5.1 nested 'ancestors' (lineage.collect)."""
    if not isinstance(h, dict):
        return "unknown"
    lin = h.get("lineage") if isinstance(h.get("lineage"), dict) else None
    if lin is not None:
        stated = collect([lin])["trust"]
        if stated in ("synthetic", "unknown"):
            return stated
    syn, kind = h.get("synthetic"), ((h.get("device") or {}).get("kind"))
    if syn is True or kind in SYNTHETIC_KINDS:
        return "synthetic"
    if syn is False and kind in ("physical", "file-replay"):
        return "declared-physical"
    return "unknown"


def source_trust(h) -> dict:
    """The conservative trust of ONE live source declaration (a hello), by the same rule recordings, exports, datasets and
    comparisons use (_hello_trust; v6, review finding V52-2 of v5.2): {"trust", "reasons", "derived"}.

    trust      "synthetic" when the source declares synthetic data, is an emulator/test source, or its lineage states a
               synthetic ancestor anywhere (its own trust, original_synthetic, the ancestry_trust summary, a flattened
               ancestry reference or a v5.1 nested ancestor); "unknown" when the declaration is missing or ambiguous or the
               lineage states unknown origin (or was too large to read completely); "declared-physical" only when the source
               declared physical/synthetic: false and nothing behind it says otherwise. Unknown is never promoted to
               physical, and neither is synthetic.
    derived    the hello carries a lineage: the data is a copy of an earlier recording, not a live measurement."""
    if not isinstance(h, dict) or not h:
        return {"trust": None, "reasons": ["no source has declared itself"], "derived": False}
    trust = _hello_trust(h)
    lin = h.get("lineage") if isinstance(h.get("lineage"), dict) else None
    reasons = []
    syn, kind = h.get("synthetic"), ((h.get("device") or {}).get("kind"))
    hist = collect([lin]) if lin is not None else None
    if syn is True:
        reasons.append("the source declares synthetic data")
    if kind in SYNTHETIC_KINDS:
        reasons.append(f"a '{kind}' source is synthetic by definition")
    if hist is not None and hist["trust"] == "synthetic":
        reasons.append("its lineage states a synthetic origin or a synthetic ancestor")
    if hist is not None and hist["trust"] == "unknown":
        reasons.append("its lineage states an unknown origin" + (" (too large to read completely)" if hist["cut"] else ""))
    if trust == "unknown" and not reasons:
        reasons.append("the declaration is missing or ambiguous (kind " + repr(kind) + ", synthetic " + repr(syn) + ")")
    if lin is not None:
        reasons.append("it carries a lineage: a copy of an earlier recording" + (f" ({_text(lin.get('derived_from'))})" if lin.get("derived_from") else ""))
    return {"trust": trust, "reasons": reasons, "derived": lin is not None}


def segments_of(doc: dict) -> list:
    """The source segments of a document: provenance.segments (v5.1 recorder) or, for older documents, one segment
    covering every row with the recorded hellos (their boundaries were not stored)."""
    prov = doc.get("provenance") or {}
    n = len(((doc.get("samples") or {}).get("cols") or {}).get("t") or [])
    segs = prov.get("segments")
    if isinstance(segs, list) and segs and all(isinstance(s, dict) and isinstance(s.get("rows"), list) and len(s["rows"]) == 2 for s in segs):
        return [dict(s) for s in segs]
    hellos = [h for h in (prov.get("hellos") or []) if isinstance(h, dict)]
    return [{"segment": 1, "rows": [0, n], "hello": hellos[0] if hellos else None, "hellos": hellos, "legacy": True}]


def classify(doc: dict) -> dict:
    prov = doc.get("provenance") if isinstance(doc.get("provenance"), dict) else {}
    hellos = [h for h in (prov.get("hellos") or []) if isinstance(h, dict)]
    segs = segments_of(doc)
    seg_hellos = [s.get("hello") for s in segs if isinstance(s.get("hello"), dict)]
    declared = hellos + [h for h in seg_hellos if h not in hellos]
    reasons, trusts = [], [_hello_trust(h) for h in declared]
    kinds = {((h.get("device") or {}).get("kind")) for h in declared} - {None}
    if prov.get("source_kind"):
        kinds.add(prov["source_kind"])
    flag, pflag = doc.get("synthetic"), prov.get("synthetic")
    # v6 (V52-2): a recording of a source of UNKNOWN origin is stored with synthetic: true (it is never evidence) and
    # says why (provenance.synthetic_flag_reason = "unknown-origin"); that flag alone keeps it unknown instead of turning
    # it into synthetic. Any other synthetic sign still makes it synthetic; nothing here can make it declared-physical.
    unknown_marked = prov.get("synthetic_flag_reason") == "unknown-origin"
    if (flag is True or pflag is True) and not unknown_marked:
        reasons.append("the recording is marked synthetic")
    if "synthetic" in trusts:
        reasons.append("a source segment declared synthetic data or has a synthetic ancestor")
    if kinds & set(SYNTHETIC_KINDS) or "mixed" in kinds and "synthetic" in trusts:
        reasons.append("an emulator or test source contributed data")
    for s in segs:
        if s.get("synthetic") is True:
            reasons.append(f"segment {s.get('segment')} is synthetic")
    lineage = [l for l in (prov.get("lineage") or []) if isinstance(l, dict)]
    for l in lineage:
        if l.get("trust") == "synthetic" or (l.get("original_synthetic") is not None and l.get("original_synthetic") is not False):
            reasons.append(f"it derives from synthetic data ({l.get('derived_from') or 'an earlier export'})")
    # v5.2: the whole history behind the lineage (summaries, flattened references, v5.1 nested ancestors) — only lowers
    hist = collect(lineage + [h["lineage"] for h in declared if isinstance(h.get("lineage"), dict)])
    if hist["trust"] == "synthetic" and not any(r.startswith("it derives from synthetic data") for r in reasons):
        reasons.append("an earlier generation in its lineage is synthetic")
    if reasons:
        trust = "synthetic"
    elif not declared:
        trust = "unknown"
        reasons.append("no telemetry source declared where the data came from")
    elif "unknown" in trusts or flag is not False or hist["trust"] == "unknown":
        trust = "unknown"
        reasons.append("its lineage was too large to read completely" if hist["cut"] else "an earlier generation in its lineage is of unknown origin" if hist["trust"] == "unknown"
                       else "a source declaration is missing or ambiguous" if "unknown" in trusts
                       else "stored with synthetic: true because its origin is unknown (never evidence)" if unknown_marked
                       else "the recording does not state synthetic: false")
    else:
        trust = "declared-physical"
    transport = prov.get("transport") if isinstance(prov.get("transport"), dict) else {}
    derived = transport.get("kind") == "file" or any(isinstance(l, dict) and l.get("derived_from") for l in lineage) \
        or any(isinstance(h.get("lineage"), dict) for h in declared)
    ids = sorted({str(i[0]) for i in map(_identity, declared) if i[0] is not None})
    return {"trust": trust, "synthetic": trust == "synthetic", "declared_physical": trust == "declared-physical",
            "reasons": list(dict.fromkeys(reasons)), "derived": bool(derived),
            "derived_from": transport.get("address") if transport.get("kind") == "file" else next((l.get("derived_from") for l in lineage if l.get("derived_from")), None),
            "mixed_sources": len({_identity(h)[:4] for h in declared}) > 1, "device_ids": ids, "segments": len(segs)}


class LineageError(ValueError):
    """An exported lineage could not be kept within LINEAGE_BUDGET (it never is silently cut)."""


def _lineage(doc: dict, seg: dict, recording_id: str | None, cls: dict, reason: str | None, notes: dict | None = None) -> dict:
    """The lineage an exported hello carries (v5.2: flat and bounded; see the module docstring)."""
    h = seg.get("hello") or {}
    own = h.get("lineage") if isinstance(h.get("lineage"), dict) else None             # this segment's own source, if a replay
    prior = [l for l in ((doc.get("provenance") or {}).get("lineage") or []) if isinstance(l, dict)]
    hist = collect(([own] if own is not None else []) + prior)
    osyn = h.get("synthetic") if h else doc.get("synthetic")
    out = {"derived_from": _text(recording_id or (doc.get("recording") or {}).get("notes") or "an aeris-hardware-run/1 document"),
           "exported_by": "AERIS backend NDJSON export", "original_device": _device(h.get("device")) or _device(doc.get("device")),
           "original_synthetic": osyn if (osyn is None or isinstance(osyn, bool)) else True, "trust": cls["trust"],
           "generation": hist["generation"] + 1}
    if reason:
        out["reason"] = _text(reason, 600)
    if hist["trust"] is not None:
        out["ancestry_trust"] = hist["trust"]
    if hist["refs"] or hist["omitted"]:
        out["ancestry"], dropped = _select(hist["refs"], MAX_ANCESTRY)
        if dropped + hist["omitted"]:
            out["ancestry_omitted"] = dropped + hist["omitted"]
    if hist["cut"]:
        out["ancestry_note"] = f"the v5.1 lineage behind this export was read up to {MAX_WALK} entries; the unread part counts as unknown"
    if notes:
        out["export"] = notes
    limit = len(out.get("ancestry") or [])
    while _measure(out) > LINEAGE_BUDGET and limit > 0:          # drop more references (middle generations first), never the summary
        limit -= 1
        out["ancestry"], dropped = _select(hist["refs"], limit)
        out["ancestry_omitted"] = dropped + hist["omitted"]
    if _measure(out) > LINEAGE_BUDGET:
        raise LineageError(f"the lineage of segment {seg.get('segment')} needs {_measure(out)} bytes even without ancestry references "
                           f"(budget {LINEAGE_BUDGET}, protocol limit {MAX_LINEAGE})")
    return out


def export_segments(doc: dict, recording_id: str | None = None, notes: dict | None = None) -> list:
    """[(hello_message, row_start, row_end), ...] for an NDJSON export (see the module docstring). `notes` (v5.2) is
    recorded in every hello's lineage as "export" (the unit conversions, sequence source and omissions of the export)."""
    cls = classify(doc)
    mode = doc.get("mode")
    rate = (doc.get("samples") or {}).get("rate_hz")
    out = []
    for seg in segments_of(doc):
        a, b = int(seg["rows"][0]), int(seg["rows"][1])
        h = copy.deepcopy(seg.get("hello")) if isinstance(seg.get("hello"), dict) else None
        own = _hello_trust(h) if h else "unknown"
        if cls["trust"] == "declared-physical" and h is not None and own == "declared-physical" and not (seg.get("legacy") and len(seg.get("hellos") or []) > 1
                                                                                                      and len({_identity(x)[:4] for x in seg["hellos"]}) > 1):
            hello = {k: v for k, v in h.items() if k != "lineage"}
            hello["lineage"] = _lineage(doc, seg, recording_id, cls, None, notes)
        elif h is not None and own == "synthetic" and h.get("synthetic") is True and (h.get("device") or {}).get("kind") in SYNTHETIC_KINDS + ("file-replay",) \
                and not (seg.get("legacy") and len({_identity(x)[:4] for x in (seg.get("hellos") or [h])}) > 1):
            hello = {k: v for k, v in h.items() if k != "lineage"}
            hello["lineage"] = _lineage(doc, seg, recording_id, cls, None, notes)
        else:
            src = (h or {}).get("device") or doc.get("device") or {}
            syn = cls["trust"] != "declared-physical"
            reason = ("the recording includes synthetic or undeclared data (" + "; ".join(cls["reasons"]) + "): every segment of its export is synthetic"
                      if syn else "the recording mixes declared sources whose boundaries were not stored")
            hello = {"protocol": PROTOCOL, "device": {"id": "replay:" + str(src.get("id") or "unknown"), "kind": "file-replay", "firmware": str(src.get("firmware") or "unknown")},
                     "synthetic": bool(syn), "mode": (h or {}).get("mode") or mode, "conventions": dict(CONVENTIONS)}
            if (h or {}).get("nominal_rate_hz") or rate:
                hello["nominal_rate_hz"] = (h or {}).get("nominal_rate_hz") or rate
            hello["lineage"] = _lineage(doc, seg, recording_id, cls, reason, notes)
        hello["type"] = "hello"
        hello.setdefault("protocol", PROTOCOL)
        hello.setdefault("conventions", dict(CONVENTIONS))
        hello.setdefault("mode", mode)
        out.append((hello, a, b))
    return out

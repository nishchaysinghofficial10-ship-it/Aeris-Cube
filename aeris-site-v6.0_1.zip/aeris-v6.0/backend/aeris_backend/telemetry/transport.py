"""Transports that feed a TelemetryHub (docs/TELEMETRY.md §4). All of them are READ-ONLY: nothing is ever
written to a source (no commands, no acknowledgements), so this software cannot actuate a device.

TcpNdjsonSource   connects to host:port and reads NDJSON lines; loopback addresses only unless the operator
                  allows remote hosts explicitly (AERIS_TELEMETRY_ALLOW_REMOTE=1). Reconnects with a bounded
                  exponential back-off; every connect, disconnect and failed attempt is reported.
FileReplaySource  feeds an NDJSON session (a file in the telemetry directory, or a stored recording converted
                  by stream.recording_to_ndjson) with its recorded pacing (speed factor; 0 = as fast as
                  possible). The transport kind is 'file', so the stream is marked as a replay.
LineSplitter      byte stream → lines, enforcing protocol.MAX_LINE (an over-long line is discarded up to its
                  newline and reported as 'line_too_long'; a line cut by a disconnect is 'truncated_line').
"""
from __future__ import annotations

import asyncio
import ipaddress
import json
import os
import time

from .protocol import MAX_LINE

TOO_LONG = object()


def is_loopback(host: str) -> bool:
    if host in ("localhost", "localhost.localdomain"):
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def check_host(host, allow_remote: bool) -> str | None:
    """None when the host may be used, else a field-specific message."""
    if not isinstance(host, str) or not host.strip():
        return "host: required (e.g. 127.0.0.1)"
    if not allow_remote and not is_loopback(host.strip()):
        return (f"host: '{host}' is not a loopback address. The telemetry transport defaults to this computer only; "
                "set AERIS_TELEMETRY_ALLOW_REMOTE=1 when starting the backend to allow a device on another host.")
    return None


class LineSplitter:
    def __init__(self, max_line: int = MAX_LINE):
        self.buf = bytearray()
        self.max_line = max_line
        self.discarding = False

    def feed(self, data: bytes) -> list:
        """Complete lines (bytes, without the newline) and TOO_LONG markers."""
        out = []
        self.buf += data
        while True:
            i = self.buf.find(b"\n")
            if i < 0:
                if len(self.buf) > self.max_line:
                    if not self.discarding:
                        out.append(TOO_LONG)
                        self.discarding = True
                    self.buf.clear()
                return out
            line = bytes(self.buf[:i])
            del self.buf[:i + 1]
            if self.discarding:           # the rest of an over-long line
                self.discarding = False
                continue
            if len(line) > self.max_line:
                out.append(TOO_LONG)
                continue
            out.append(line)

    def tail(self) -> bytes:
        """Unterminated data left when the stream ends ('' if none)."""
        t = b"" if self.discarding else bytes(self.buf)
        self.buf.clear()
        self.discarding = False
        return t


class _Source:
    kind = "abstract"

    def __init__(self, hub, *, adapter=None, clock=time.monotonic):
        self.hub = hub
        self.adapter = adapter
        self.clock = clock
        self._stop = asyncio.Event()
        self.state = "idle"
        self.last_error = None
        self.attempts = 0
        self.task = None

    def _deliver(self, line) -> str:
        now = self.clock()
        if line is TOO_LONG:
            return self.hub.reject("line_too_long", now, f"a line exceeded {MAX_LINE} bytes and was discarded")
        if self.adapter is None:
            return self.hub.feed_line(line, now)
        try:
            msgs = self.adapter.decode(line)
        except Exception as e:  # an adapter error is a rejected line, never a crash of the reader
            return self.hub.reject("adapter_error", now, f"{type(e).__name__}: {e}")
        res = "ignored"
        for m in msgs:
            res = self.hub.feed_message(m, now)
        return res

    def start(self):
        self.task = asyncio.ensure_future(self.run())
        return self.task

    async def stop(self):
        self._stop.set()
        if self.task is not None and not self.task.done():
            self.task.cancel()
            try:
                await self.task
            except (asyncio.CancelledError, Exception):
                pass

    def describe(self) -> dict:
        return {"kind": self.kind, "state": self.state, "last_error": self.last_error, "attempts": self.attempts}


class TcpNdjsonSource(_Source):
    kind = "tcp"

    def __init__(self, hub, host: str, port: int, *, reconnect: bool = True, backoff=(0.2, 5.0), connect_timeout: float = 3.0,
                 allow_remote: bool = False, adapter=None, clock=time.monotonic):
        super().__init__(hub, adapter=adapter, clock=clock)
        err = check_host(host, allow_remote)
        if err:
            raise ValueError(err)
        if not (isinstance(port, int) and 1 <= port <= 65535):
            raise ValueError("port: must be an integer 1–65535")
        self.host, self.port = host.strip(), port
        self.reconnect, self.backoff, self.connect_timeout = reconnect, backoff, connect_timeout
        self.next_attempt_in = None

    def describe(self) -> dict:
        return dict(super().describe(), address=f"{self.host}:{self.port}", reconnect=self.reconnect, next_attempt_in_s=self.next_attempt_in)

    async def run(self):
        delay = self.backoff[0]
        try:
            while not self._stop.is_set():
                self.state = "connecting"
                self.attempts += 1
                try:
                    reader, writer = await asyncio.wait_for(asyncio.open_connection(self.host, self.port, limit=MAX_LINE + 2), self.connect_timeout)
                except (OSError, asyncio.TimeoutError) as e:
                    self.last_error = f"connect to {self.host}:{self.port} failed: {type(e).__name__}: {e}".strip()
                    self.state = "waiting"
                    if not self.reconnect:
                        self.state = "failed"
                        return
                    self.next_attempt_in = delay
                    await self._sleep(delay)
                    delay = min(self.backoff[1], delay * 2)
                    continue
                delay = self.backoff[0]
                self.state = "connected"
                self.last_error = None
                self.next_attempt_in = None
                self.hub.on_connect({"kind": "tcp", "address": f"{self.host}:{self.port}", "adapter": getattr(self.adapter, "name", None)}, self.clock())
                if self.adapter is not None:
                    hello = self.adapter.hello()
                    if hello is not None:
                        self.hub.feed_message(hello, self.clock())
                reason = "closed by the source"
                try:
                    reason = await self._pump(reader)
                except asyncio.CancelledError:
                    reason = "stopped by the operator"
                    raise
                except (ConnectionError, OSError) as e:
                    reason = f"connection lost: {type(e).__name__}"
                finally:
                    writer.close()
                    try:
                        await asyncio.wait_for(writer.wait_closed(), 1.0)
                    except (Exception, asyncio.CancelledError):
                        pass
                    self.hub.on_disconnect(reason, self.clock())
                    self.state = "disconnected"
                if not self.reconnect or self._stop.is_set():
                    return
                self.state = "waiting"
                self.next_attempt_in = delay
                await self._sleep(delay)
        finally:
            if self.state not in ("failed",):
                self.state = "stopped" if self._stop.is_set() else self.state

    async def _sleep(self, s):
        try:
            await asyncio.wait_for(self._stop.wait(), s)
        except asyncio.TimeoutError:
            pass

    async def _pump(self, reader) -> str:
        sp = LineSplitter()
        while True:
            data = await reader.read(65536)
            if not data:
                tail = sp.tail()
                if tail.strip():
                    self.hub.reject("truncated_line", self.clock(), f"{len(tail)} bytes without a newline when the connection closed")
                return "source said bye" if self.hub.ended_cleanly else "closed by the source"
            for line in sp.feed(data):
                self._deliver(line)


class FileReplaySource(_Source):
    kind = "file"

    def __init__(self, hub, *, path: str | None = None, text: str | None = None, label: str | None = None, speed: float = 1.0,
                 adapter=None, clock=time.monotonic, sleep=asyncio.sleep):
        super().__init__(hub, adapter=adapter, clock=clock)
        if (path is None) == (text is None):
            raise ValueError("give exactly one of path or text")
        if not (isinstance(speed, (int, float)) and speed >= 0 and speed <= 100):
            raise ValueError("speed: must be between 0 (as fast as possible) and 100")
        self.path, self.text, self.speed = path, text, float(speed)
        self.label = label or (os.path.basename(path) if path else "text")
        self.sleep = sleep
        self.lines_fed = 0

    def describe(self) -> dict:
        return dict(super().describe(), address=self.label, speed=self.speed, lines_fed=self.lines_fed)

    def _chunks(self):
        if self.text is not None:
            yield self.text.encode("utf-8")
            return
        with open(self.path, "rb") as fh:
            while True:
                b = fh.read(65536)
                if not b:
                    return
                yield b

    async def run(self):
        self.state = "replaying"
        self.hub.on_connect({"kind": "file", "address": self.label, "speed": self.speed, "adapter": getattr(self.adapter, "name", None)}, self.clock())
        reason = "end of file"
        wall0 = src0 = None
        try:
            if self.adapter is not None:
                h = self.adapter.hello()
                if h is not None:
                    self.hub.feed_message(h, self.clock())
            sp = LineSplitter()
            for chunk in self._chunks():
                for line in sp.feed(chunk):
                    if self._stop.is_set():
                        reason = "stopped by the operator"
                        return
                    if self.speed > 0 and line is not TOO_LONG and self.adapter is None:
                        t = _peek_t(line)
                        if t is not None:
                            if wall0 is None or (src0 is not None and t < src0):
                                wall0, src0 = self.clock(), t
                            wait = wall0 + (t - src0) / self.speed - self.clock()
                            if wait > 0:
                                await self.sleep(min(wait, 5.0))
                    self._deliver(line)
                    self.lines_fed += 1
                    if self.speed == 0 and self.lines_fed % 200 == 0:
                        await asyncio.sleep(0)       # stay cooperative when replaying as fast as possible
            tail = sp.tail()
            if tail.strip():
                self.hub.reject("truncated_line", self.clock(), f"{len(tail)} bytes without a newline at the end of the file")
        except asyncio.CancelledError:
            reason = "stopped by the operator"
            raise
        except OSError as e:
            reason = f"file error: {e}"
            self.last_error = reason
        finally:
            self.hub.on_disconnect(reason, self.clock())
            self.state = "finished" if reason == "end of file" else "stopped"


def _peek_t(line: bytes):
    try:
        m = json.loads(line)
    except (ValueError, UnicodeDecodeError, RecursionError):
        return None
    if isinstance(m, dict) and m.get("type") == "frame":
        t = m.get("t")
        if isinstance(t, (int, float)) and not isinstance(t, bool):
            return float(t)
    return None

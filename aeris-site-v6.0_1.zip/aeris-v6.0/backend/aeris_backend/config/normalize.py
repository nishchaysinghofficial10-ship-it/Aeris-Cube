"""aeris-config/1 normalisation (layer 1 of the validation stack: structure and types).

Revision 1.0 fields keep exactly the browser engine's meaning (site/js/core.js normalizeConfig);
revision 1.1 adds optional research blocks and revision 1.2 the general initial state and the
reference block (docs/SCHEMA_EXTENSIONS.md, docs/EXPERIMENT_CONTRACT.md). The backend is strict:
a value of the wrong type is an error with its path, never coerced or dropped. Unknown fields
are kept in the normalised configuration and reported as warnings, so nothing is silently lost.

normalize(raw) returns (cfg, issues) where issues is a list of
{"path", "message", "severity": "error" | "warning", "kind": "structure"}.
"""
from __future__ import annotations

import copy
import math
from typing import Any

from ..constants import (ACTUATOR_DEFAULTS, ADAPTIVE_DEFAULTS, ALLOCATION_METHODS, CF3D_DEFAULTS,
                         CONTROLLER_TYPES, DISTURBANCE_TYPES, ELECTRICAL_LIMIT_MODES, EVENT_TYPES,
                         LQR_DEFAULTS, MEKF_DEFAULTS, NOMINAL, NONLINEAR_DEFAULTS, PID_DEFAULTS,
                         RECOVERY_DEFAULTS, SENSOR_DEFAULTS, STRUCTURES, TERMINATION_DEFAULTS, WHEELS,
                         YAW_OBJECTIVES)
from ..version import CONFIG_REVISION, CONFIG_REVISIONS_READ, CONFIG_SCHEMA

LEGACY_KEYS = {"schema", "mode", "params", "comOffset_m", "comShift_m", "attachments", "controller", "estimator",
               "seed", "sensor", "actuator", "initial", "disturbances", "events", "commands", "uncertainty",
               "torqueScale", "duration_s", "record_hz"}
EXTENSION_KEYS = {"config_revision", "solver", "plant", "wheels", "recovery", "termination", "reference"}
REFERENCE_ATTITUDES = ("balance",)
HEADINGS = ("hold", "free")
LEGACY_TILT_KEYS = ("tilt_deg", "azimuth_deg", "reference")
KNOWN_KEYS = LEGACY_KEYS | EXTENSION_KEYS
ESTIMATORS_ALL = ("ideal", "cf", "kf", "accel", "gyro", "cf3d", "mekf")


class Issues(list):
    def err(self, path, message, kind="structure"):
        self.append({"path": path, "message": message, "severity": "error", "kind": kind})

    def warn(self, path, message, kind="structure"):
        self.append({"path": path, "message": message, "severity": "warning", "kind": kind})

    @property
    def errors(self):
        return [i for i in self if i["severity"] == "error"]

    @property
    def warnings(self):
        return [i for i in self if i["severity"] == "warning"]


def is_num(x) -> bool:
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def default_config(mode: str = "edge") -> dict:
    """Revision 1.0 defaults, identical to AERIS_TWIN.defaultConfig."""
    return {
        "schema": CONFIG_SCHEMA, "mode": "corner" if mode == "corner" else "edge",
        "params": dict(NOMINAL), "comOffset_m": 0, "comShift_m": [0, 0, 0], "attachments": [],
        "controller": {"type": "lqr", "knowsAttachments": False, "reconfigureOnFailure": True, "structure": "decoupled"},
        "estimator": {"type": "ideal"}, "seed": 7,
        "sensor": dict(SENSOR_DEFAULTS), "actuator": copy.deepcopy(ACTUATOR_DEFAULTS),
        "initial": {"tilt_deg": 2, "rate_dps": 0, "azimuth_deg": 0, "reference": "geometric"},
        "disturbances": [], "events": [], "commands": [],
        "uncertainty": {"inertiaScale": 1}, "torqueScale": 1, "duration_s": 10, "record_hz": 50,
    }


def default_wheels(params: dict, health: dict | None = None) -> list[dict]:
    """The browser's three wheels: spin axes along body x, y, z with the shared motor parameters."""
    out = []
    for i, w in enumerate(WHEELS):
        ax = [0.0, 0.0, 0.0]
        ax[i] = 1.0
        out.append({"id": w, "axis": ax, "Jw": params["Jw"], "KV": params["KV"], "R": params["R"], "Vs": params["Vs"],
                    "Imax": params["Imax"], "wmaxRpm": params["wmaxRpm"], "cv": params["cv"], "cc": params["cc"],
                    "health": (health or {}).get(w, 1)})
    return out


def _num(v, path, iss: Issues, *, nullable=False, integer=False):
    if v is None and nullable:
        return None
    if not is_num(v):
        iss.err(path, f"must be a finite number (got {json_repr(v)}).")
        return math.nan
    if integer and float(v) != int(v):
        iss.err(path, f"must be an integer (got {v}).")
    return v


def _vec(v, path, iss: Issues, n=3):
    if not isinstance(v, list) or len(v) != n:
        iss.err(path, f"must be a list of {n} numbers (got {json_repr(v)}).")
        return [math.nan] * n
    return [_num(x, f"{path}.{j}", iss) for j, x in enumerate(v)]


def _mat3(v, path, iss: Issues):
    if not isinstance(v, list) or len(v) != 3 or any(not isinstance(r, list) or len(r) != 3 for r in v):
        iss.err(path, f"must be a 3×3 list of lists (got {json_repr(v)}).")
        return [[math.nan] * 3 for _ in range(3)]
    return [[_num(x, f"{path}.{i}.{j}", iss) for j, x in enumerate(r)] for i, r in enumerate(v)]


def _bool(v, path, iss: Issues):
    if not isinstance(v, bool):
        iss.err(path, f"must be true or false (got {json_repr(v)}).")
        return False
    return v


def _enum(v, allowed, path, iss: Issues, label="value"):
    if v not in allowed:
        iss.err(path, f"unknown {label} {json_repr(v)}; allowed: {', '.join(map(str, allowed))}.")
    return v


def _str(v, path, iss: Issues, default=None):
    if v is None:
        return default
    if not isinstance(v, str):
        iss.err(path, f"must be a string (got {json_repr(v)}).")
        return str(v)
    return v


def json_repr(v) -> str:
    s = repr(v)
    return s if len(s) <= 60 else s[:57] + "..."


def _block(src: dict, key: str, defaults: dict, path: str, iss: Issues, spec: dict) -> dict:
    """Copy a research block over its defaults; spec maps field → 'num' | 'num?' | 'bool' | ('enum', allowed)."""
    out = dict(defaults)
    val = src.get(key)
    if val is None:
        return out
    if not isinstance(val, dict):
        iss.err(path, f"must be an object (got {json_repr(val)}).")
        return out
    for k, v in val.items():
        if k not in spec:
            iss.warn(f"{path}.{k}", f"unknown field '{k}' in {path}; kept in the configuration but not used by this engine.")
            out[k] = copy.deepcopy(v)
            continue
        t = spec[k]
        if t == "num":
            out[k] = _num(v, f"{path}.{k}", iss)
        elif t == "num?":
            out[k] = _num(v, f"{path}.{k}", iss, nullable=True)
        elif t == "bool":
            out[k] = _bool(v, f"{path}.{k}", iss)
        elif isinstance(t, tuple) and t[0] == "enum":
            out[k] = _enum(v, t[1], f"{path}.{k}", iss)
    return out


def _block_in_use(k: str, v) -> bool:
    """A normalised configuration always carries solver/plant/recovery/termination blocks; a block that
    only restates the defaults does not change the model (same rule as site/js/platform/config.js)."""
    if v is None:
        return False
    if not isinstance(v, dict):
        return True
    if k == "solver":
        return not (v.get("method") in (None, "rk4") and v.get("integration_hz") is None and set(v) <= {"method", "integration_hz"})
    if k == "plant":
        return not (v.get("base_inertia_kgm2") is None and v.get("base_com_m") is None and not v.get("components")
                    and set(v) <= {"base_inertia_kgm2", "base_com_m", "components"})
    if k == "reference":
        return not (v.get("attitude") in (None, "balance") and v.get("heading") in (None, "hold") and v.get("yaw_deg") in (None, 0)
                    and set(v) <= {"attitude", "heading", "yaw_deg"})
    dflt = {"recovery": RECOVERY_DEFAULTS, "termination": TERMINATION_DEFAULTS}.get(k)
    if dflt is not None:
        return not (set(v) <= set(dflt) and all(v[x] == dflt[x] for x in v))
    return True


def uses_extensions(raw: dict) -> list[str]:
    """Paths of revision-1.1 features used by a raw configuration (empty = a revision 1.0 setup).
    Blocks that only restate the defaults do not count."""
    if not isinstance(raw, dict):
        return []
    used = [k for k in ("solver", "plant", "wheels", "recovery", "termination", "reference") if _block_in_use(k, raw.get(k))]
    if isinstance(raw.get("initial"), dict):
        used += ["initial." + k for k in ("wheel_speeds_rpm", "attitude_q", "body_rate_dps") if raw["initial"].get(k) is not None]
    c = raw.get("controller") or {}
    if isinstance(c, dict):
        if c.get("type") == "nlpd":
            used.append("controller.type")
        if c.get("structure") == "mimo-lqr":
            used.append("controller.structure")
        used += ["controller." + k for k in ("pid", "lqr", "adaptive", "nonlinear", "allocation") if c.get(k) is not None]
    e = raw.get("estimator") or {}
    if isinstance(e, dict):
        if e.get("type") in ("cf3d", "mekf"):
            used.append("estimator.type")
        used += ["estimator." + k for k in ("mekf", "cf3d", "stale_after_s") if e.get(k) is not None]
    a = raw.get("actuator") or {}
    if isinstance(a, dict) and a.get("electrical_limit") is not None:
        used.append("actuator.electrical_limit")
    s = raw.get("sensor") or {}
    if isinstance(s, dict):
        used += ["sensor." + k for k in ("imu_position_m", "accel_dynamic") if s.get(k) is not None]
    u = raw.get("uncertainty") or {}
    if isinstance(u, dict) and u.get("inertia_perturbation_kgm2") is not None:
        used.append("uncertainty.inertia_perturbation_kgm2")
    for i, d in enumerate(raw.get("disturbances") or []):
        if isinstance(d, dict) and d.get("type") in ("impulse", "force_impulse", "bias"):
            used.append(f"disturbances.{i}.type")
    for i, e2 in enumerate(raw.get("events") or []):
        if isinstance(e2, dict) and (e2.get("type") in EVENT_TYPES[1:] or e2.get("duration_s") is not None):
            used.append(f"events.{i}")
    return used


def normalize(raw: Any) -> tuple[dict, Issues]:
    iss = Issues()
    if not isinstance(raw, dict):
        iss.err("", "The configuration must be a JSON object.")
        return default_config("edge"), iss
    mode = raw.get("mode", "edge")
    if mode not in ("edge", "corner"):
        iss.err("mode", "Balance mode must be 'edge' or 'corner'.")
        mode = "edge"
    c = default_config(mode)
    if raw.get("schema") not in (None, CONFIG_SCHEMA):
        iss.err("schema", f"Expected schema '{CONFIG_SCHEMA}', found {json_repr(raw.get('schema'))}.")
    rev = raw.get("config_revision")
    if rev not in (None,) + CONFIG_REVISIONS_READ:
        iss.err("config_revision", f"Unknown configuration revision {json_repr(rev)}; this backend reads {', '.join(CONFIG_REVISIONS_READ)}.")
    for k in raw:
        if k not in KNOWN_KEYS:
            iss.warn(k, f"unknown field '{k}'; kept in the configuration but not used by this engine.")
            c[k] = copy.deepcopy(raw[k])

    p = raw.get("params")
    if p is not None:
        if not isinstance(p, dict):
            iss.err("params", "must be an object.")
        else:
            for k, v in p.items():
                if k in NOMINAL:
                    c["params"][k] = _num(v, f"params.{k}", iss)
                else:
                    iss.warn(f"params.{k}", f"unknown parameter '{k}'; kept but not used.")
                    c["params"][k] = copy.deepcopy(v)
    if "comOffset_m" in raw:
        c["comOffset_m"] = _num(raw["comOffset_m"], "comOffset_m", iss)
    if "comShift_m" in raw:
        c["comShift_m"] = _vec(raw["comShift_m"], "comShift_m", iss)
    s = raw.get("sensor")
    if s is not None:
        if not isinstance(s, dict):
            iss.err("sensor", "must be an object.")
        else:
            for k, v in s.items():
                if k == "rate_hz":
                    c["sensor"][k] = _num(v, "sensor.rate_hz", iss, nullable=True)
                elif k in SENSOR_DEFAULTS:
                    c["sensor"][k] = _num(v, f"sensor.{k}", iss)
                elif k == "imu_position_m":
                    c["sensor"][k] = None if v is None else _vec(v, "sensor.imu_position_m", iss)
                elif k == "accel_dynamic":
                    c["sensor"][k] = _bool(v, "sensor.accel_dynamic", iss)
                elif k == "accel_bias_mps2":
                    c["sensor"][k] = _vec(v, "sensor.accel_bias_mps2", iss)
                else:
                    iss.warn(f"sensor.{k}", f"unknown sensor field '{k}'; kept but not used.")
                    c["sensor"][k] = copy.deepcopy(v)
    a = raw.get("actuator")
    if a is not None:
        if not isinstance(a, dict):
            iss.err("actuator", "must be an object.")
        else:
            if "motor_lag_ms" in a:
                c["actuator"]["motor_lag_ms"] = _num(a["motor_lag_ms"], "actuator.motor_lag_ms", iss)
            wh = a.get("wheel_health")
            if wh is not None:
                if not isinstance(wh, dict):
                    iss.err("actuator.wheel_health", "must be an object {x, y, z}.")
                else:
                    for w, v in wh.items():
                        if w in WHEELS:
                            c["actuator"]["wheel_health"][w] = _num(v, f"actuator.wheel_health.{w}", iss)
                        else:
                            iss.err(f"actuator.wheel_health.{w}", "wheel must be x, y or z.")
            if "electrical_limit" in a:
                c["actuator"]["electrical_limit"] = _enum(a["electrical_limit"], ELECTRICAL_LIMIT_MODES, "actuator.electrical_limit", iss)
            for k in a:
                if k not in ("motor_lag_ms", "wheel_health", "electrical_limit"):
                    iss.warn(f"actuator.{k}", f"unknown actuator field '{k}'; kept but not used.")
                    c["actuator"][k] = copy.deepcopy(a[k])
    at = raw.get("attachments")
    if at is not None:
        if not isinstance(at, list):
            iss.err("attachments", "must be a list.")
        else:
            c["attachments"] = []
            for i, x in enumerate(at):
                if not isinstance(x, dict):
                    iss.err(f"attachments.{i}", "must be an object.")
                    continue
                c["attachments"].append({"id": str(x.get("id") or f"m{i + 1}"), "label": str(x.get("label") or f"Mass {i + 1}"),
                                         "mass_kg": _num(x.get("mass_kg"), f"attachments.{i}.mass_kg", iss),
                                         "pos_m": _vec(x.get("pos_m"), f"attachments.{i}.pos_m", iss)})
    ct = raw.get("controller")
    if ct is not None:
        if not isinstance(ct, dict):
            iss.err("controller", "must be an object.")
        else:
            cc = c["controller"]
            if "type" in ct:
                cc["type"] = _enum(ct["type"], CONTROLLER_TYPES, "controller.type", iss, "controller")
            if "knowsAttachments" in ct:
                cc["knowsAttachments"] = _bool(ct["knowsAttachments"], "controller.knowsAttachments", iss)
            if "reconfigureOnFailure" in ct:
                cc["reconfigureOnFailure"] = _bool(ct["reconfigureOnFailure"], "controller.reconfigureOnFailure", iss)
            if "structure" in ct:
                cc["structure"] = _enum(ct["structure"], STRUCTURES, "controller.structure", iss, "controller structure")
            specs = {
                "pid": (PID_DEFAULTS, {"integrator_pole": "num", "yaw_integrator_pole": "num", "anti_windup": ("enum", ("clamp", "conditional")), "reset_on_events": "bool"}),
                "lqr": (LQR_DEFAULTS, {k: "num" for k in LQR_DEFAULTS}),
                "adaptive": (ADAPTIVE_DEFAULTS, {"gamma": "num", "clamp_deg": "num"}),
                "nonlinear": (NONLINEAR_DEFAULTS, {k: ("bool" if isinstance(v, bool) else "num") for k, v in NONLINEAR_DEFAULTS.items()}),
                "allocation": ({"method": "clip"}, {"method": ("enum", ALLOCATION_METHODS)}),
            }
            for key, (dflt, spec) in specs.items():
                if ct.get(key) is not None:
                    cc[key] = _block(ct, key, dflt, f"controller.{key}", iss, spec)
            for k in ct:
                if k not in ("type", "knowsAttachments", "reconfigureOnFailure", "structure") and k not in specs:
                    iss.warn(f"controller.{k}", f"unknown controller field '{k}'; kept but not used.")
                    cc[k] = copy.deepcopy(ct[k])
    es = raw.get("estimator")
    if es is not None:
        if not isinstance(es, dict):
            iss.err("estimator", "must be an object.")
        else:
            ce = c["estimator"]
            ce["type"] = _enum(es.get("type", "ideal"), ESTIMATORS_ALL, "estimator.type", iss, "estimator")
            if "Rkf_deg" in es:
                ce["Rkf_deg"] = _num(es["Rkf_deg"], "estimator.Rkf_deg", iss)
            if es.get("stale_after_s") is not None:
                # revision 1.2: age limit of the controller-facing estimate (docs/ESTIMATION_TIMING.md)
                ce["stale_after_s"] = _num(es["stale_after_s"], "estimator.stale_after_s", iss)
            if es.get("mekf") is not None:
                ce["mekf"] = _block(es, "mekf", MEKF_DEFAULTS, "estimator.mekf", iss, {k: ("bool" if isinstance(v, bool) else "num?") for k, v in MEKF_DEFAULTS.items()})
            if es.get("cf3d") is not None:
                ce["cf3d"] = _block(es, "cf3d", CF3D_DEFAULTS, "estimator.cf3d", iss, {k: ("bool" if isinstance(v, bool) else "num") for k, v in CF3D_DEFAULTS.items()})
            for k in es:
                if k not in ("type", "Rkf_deg", "mekf", "cf3d", "stale_after_s"):
                    iss.warn(f"estimator.{k}", f"unknown estimator field '{k}'; kept but not used.")
                    ce[k] = copy.deepcopy(es[k])
    if "seed" in raw:
        sd = _num(raw["seed"], "seed", iss, integer=True)
        c["seed"] = int(round(sd)) if is_num(sd) else sd
    ini = raw.get("initial")
    if ini is not None:
        if not isinstance(ini, dict):
            iss.err("initial", "must be an object.")
        else:
            explicit_q = ini.get("attitude_q") is not None
            explicit_w = ini.get("body_rate_dps") is not None
            # revision 1.2: an explicit attitude replaces the legacy tilt inputs, an explicit body-rate vector the legacy
            # rate; the replaced fields are null (absent or null in the request; a value is a conflict, reported by validation)
            if explicit_q:
                for k in LEGACY_TILT_KEYS:
                    c["initial"][k] = None
            if explicit_w:
                c["initial"]["rate_dps"] = None
            for k in ("tilt_deg", "rate_dps", "azimuth_deg"):
                if k in ini:
                    c["initial"][k] = _num(ini[k], f"initial.{k}", iss, nullable=(explicit_w if k == "rate_dps" else explicit_q))
            if "reference" in ini:
                c["initial"]["reference"] = None if (explicit_q and ini["reference"] is None) else _enum(ini["reference"], ("geometric", "balance"), "initial.reference", iss, "tilt reference")
            if explicit_q:
                c["initial"]["attitude_q"] = _vec(ini["attitude_q"], "initial.attitude_q", iss, 4)
            if explicit_w:
                c["initial"]["body_rate_dps"] = _vec(ini["body_rate_dps"], "initial.body_rate_dps", iss, 3)
            if ini.get("wheel_speeds_rpm") is not None:
                ws = ini["wheel_speeds_rpm"]
                if not isinstance(ws, list) or not ws:
                    iss.err("initial.wheel_speeds_rpm", "must be a list of wheel speeds [rpm], one per wheel.")
                else:
                    c["initial"]["wheel_speeds_rpm"] = [_num(x, f"initial.wheel_speeds_rpm.{j}", iss) for j, x in enumerate(ws)]
            for k in ini:
                if k not in ("tilt_deg", "rate_dps", "azimuth_deg", "reference", "wheel_speeds_rpm", "attitude_q", "body_rate_dps"):
                    iss.warn(f"initial.{k}", f"unknown field '{k}'; kept but not used.")
                    c["initial"][k] = copy.deepcopy(ini[k])
    c["disturbances"] = _disturbances(raw.get("disturbances"), iss) if "disturbances" in raw else []
    c["events"] = _events(raw.get("events"), iss) if "events" in raw else []
    cm = raw.get("commands")
    if cm is not None:
        if not isinstance(cm, list):
            iss.err("commands", "must be a list.")
        else:
            c["commands"] = []
            for i, e in enumerate(cm):
                if not isinstance(e, dict):
                    iss.err(f"commands.{i}", "must be an object.")
                    continue
                c["commands"].append({"id": str(e.get("id") or f"C{i + 1}"), "type": _enum(e.get("type"), ("yaw_step",), f"commands.{i}.type", iss, "command"),
                                      "t_s": _num(e.get("t_s"), f"commands.{i}.t_s", iss), "angle_deg": _num(e.get("angle_deg"), f"commands.{i}.angle_deg", iss)})
    un = raw.get("uncertainty")
    if un is not None:
        if not isinstance(un, dict):
            iss.err("uncertainty", "must be an object.")
        else:
            if "inertiaScale" in un:
                c["uncertainty"]["inertiaScale"] = _num(un["inertiaScale"], "uncertainty.inertiaScale", iss)
            if un.get("inertia_perturbation_kgm2") is not None:
                c["uncertainty"]["inertia_perturbation_kgm2"] = _mat3(un["inertia_perturbation_kgm2"], "uncertainty.inertia_perturbation_kgm2", iss)
            for k in un:
                if k not in ("inertiaScale", "inertia_perturbation_kgm2"):
                    iss.warn(f"uncertainty.{k}", f"unknown field '{k}'; kept but not used.")
                    c["uncertainty"][k] = copy.deepcopy(un[k])
    for k in ("torqueScale", "duration_s", "record_hz"):
        if k in raw:
            c[k] = _num(raw[k], k, iss)

    # ---------------- revision 1.1 blocks ----------------
    c["solver"] = _block(raw, "solver", {"method": "rk4", "integration_hz": None}, "solver", iss,
                         {"method": ("enum", ("rk4",)), "integration_hz": "num?"})
    c["plant"] = _plant(raw.get("plant"), iss)
    c["wheels"] = _wheels(raw.get("wheels"), c["params"], c["actuator"]["wheel_health"], iss)
    c["recovery"] = _block(raw, "recovery", RECOVERY_DEFAULTS, "recovery", iss,
                           {"attitude_error_deg": "num", "rate_dps": "num", "hold_s": "num", "max_time_s": "num?",
                            "yaw_objective": ("enum", YAW_OBJECTIVES)})
    c["termination"] = _block(raw, "termination", TERMINATION_DEFAULTS, "termination", iss,
                              {"stop_on_recovery": "bool", "post_fall_s": "num", "check_lift_off": "bool",
                               "overspeed_rpm": "num?", "max_quaternion_drift": "num"})
    c["reference"] = _reference(raw, c["mode"], iss)
    if c["reference"].get("heading") == "free" and not (isinstance(raw.get("recovery"), dict) and "yaw_objective" in raw["recovery"]):
        c["recovery"]["yaw_objective"] = "free"      # the criteria follow the controller's objective unless stated
    c["config_revision"] = CONFIG_REVISION
    return c, iss


def reference_defaults(mode: str) -> dict:
    """The control objective of revision 1.0/1.1 configurations: the balance attitude; in corner mode the initial
    heading plus the yaw commands (edge mode has no heading)."""
    return {"attitude": "balance", "heading": "hold" if mode == "corner" else None, "yaw_deg": 0.0 if mode == "corner" else None}


def _reference(raw: dict, mode: str, iss: Issues) -> dict:
    out = reference_defaults(mode)
    v = raw.get("reference")
    if v is None:
        return out
    if not isinstance(v, dict):
        iss.err("reference", f"must be an object (got {json_repr(v)}).")
        return out
    if "attitude" in v:
        a = v["attitude"]
        if a not in REFERENCE_ATTITUDES:
            iss.err("reference.attitude", "Only 'balance' is supported: on a fixed edge or corner support the balance attitude (centre of mass above the "
                    "support) is the only attitude the wheels can hold with bounded wheel speed; any other attitude needs a constant wheel torque, "
                    f"so it is not an equilibrium. {json_repr(a)} is rejected, not projected onto the balance point.")
        out["attitude"] = a
    for k in ("heading", "yaw_deg"):
        if k in v and v[k] is not None and mode == "edge":
            iss.err(f"reference.{k}", "Edge mode has no heading: the cube can only rotate about the support edge (one tilt axis).")
    if "heading" in v and v["heading"] is not None:
        out["heading"] = _enum(v["heading"], HEADINGS, "reference.heading", iss, "heading objective")
    if "yaw_deg" in v and v["yaw_deg"] is not None:
        out["yaw_deg"] = _num(v["yaw_deg"], "reference.yaw_deg", iss)
    for k in v:
        if k not in ("attitude", "heading", "yaw_deg"):
            iss.err(f"reference.{k}", f"unknown reference field '{k}'; supported: attitude, heading, yaw_deg (scheduled heading changes are 'commands').")
    return out


def _disturbances(v, iss: Issues) -> list:
    if not isinstance(v, list):
        iss.err("disturbances", "must be a list.")
        return []
    out = []
    for i, d in enumerate(v):
        path = f"disturbances.{i}"
        if not isinstance(d, dict):
            iss.err(path, "must be an object.")
            continue
        t = _enum(d.get("type"), DISTURBANCE_TYPES, path + ".type", iss, "disturbance type")
        o = {"id": str(d.get("id") or f"L{i + 1}"), "type": t,
             "frame": _enum(d.get("frame"), ("world", "body"), path + ".frame", iss, "frame"),
             "direction": _vec(d.get("direction"), path + ".direction", iss)}
        if t in ("force", "torque", "bias"):
            o["t_start_s"] = _num(d.get("t_start_s"), path + ".t_start_s", iss)
            o["duration_s"] = _num(d.get("duration_s"), path + ".duration_s", iss, nullable=(t == "bias"))
        if t in ("impulse", "force_impulse"):
            o["t_s"] = _num(d.get("t_s"), path + ".t_s", iss)
        if t == "force":
            o["magnitude_N"] = _num(d.get("magnitude_N"), path + ".magnitude_N", iss)
            o["point_m"] = _vec(d.get("point_m"), path + ".point_m", iss)
        elif t in ("torque", "bias"):
            o["magnitude_Nm"] = _num(d.get("magnitude_Nm"), path + ".magnitude_Nm", iss)
        elif t == "impulse":
            o["magnitude_Nms"] = _num(d.get("magnitude_Nms"), path + ".magnitude_Nms", iss)
        elif t == "force_impulse":
            o["impulse_Ns"] = _num(d.get("impulse_Ns"), path + ".impulse_Ns", iss)
            o["point_m"] = _vec(d.get("point_m"), path + ".point_m", iss)
        for k in d:
            if k not in o and k not in ("id",):
                iss.warn(f"{path}.{k}", f"field '{k}' is not used by a '{t}' disturbance; kept but not used.")
                o[k] = copy.deepcopy(d[k])
        out.append(o)
    return out


def _events(v, iss: Issues) -> list:
    if not isinstance(v, list):
        iss.err("events", "must be a list.")
        return []
    out = []
    for i, e in enumerate(v):
        path = f"events.{i}"
        if not isinstance(e, dict):
            iss.err(path, "must be an object.")
            continue
        t = _enum(e.get("type"), EVENT_TYPES, path + ".type", iss, "event type")
        o = {"id": str(e.get("id") or f"E{i + 1}"), "type": t, "wheel": _str(e.get("wheel"), path + ".wheel", iss, ""),
             "t_s": _num(e.get("t_s"), path + ".t_s", iss)}
        if "duration_s" in e:
            o["duration_s"] = _num(e.get("duration_s"), path + ".duration_s", iss, nullable=True)
        if t == "wheel_degradation":
            o["health"] = _num(e.get("health"), path + ".health", iss)
        elif t == "wheel_torque_limit":
            o["limit_Nm"] = _num(e.get("limit_Nm"), path + ".limit_Nm", iss)
        elif t == "wheel_speed_limit":
            o["limit_rpm"] = _num(e.get("limit_rpm"), path + ".limit_rpm", iss)
        for k in e:
            if k not in o:
                iss.warn(f"{path}.{k}", f"field '{k}' is not used by a '{t}' event; kept but not used.")
                o[k] = copy.deepcopy(e[k])
        out.append(o)
    return out


def _plant(v, iss: Issues) -> dict:
    out = {"base_inertia_kgm2": None, "base_com_m": None, "components": []}
    if v is None:
        return out
    if not isinstance(v, dict):
        iss.err("plant", "must be an object.")
        return out
    if v.get("base_inertia_kgm2") is not None:
        out["base_inertia_kgm2"] = _mat3(v["base_inertia_kgm2"], "plant.base_inertia_kgm2", iss)
    if v.get("base_com_m") is not None:
        out["base_com_m"] = _vec(v["base_com_m"], "plant.base_com_m", iss)
    comps = v.get("components")
    if comps is not None:
        if not isinstance(comps, list):
            iss.err("plant.components", "must be a list.")
        else:
            for i, x in enumerate(comps):
                path = f"plant.components.{i}"
                if not isinstance(x, dict):
                    iss.err(path, "must be an object.")
                    continue
                out["components"].append({
                    "id": str(x.get("id") or f"c{i + 1}"), "label": str(x.get("label") or f"Component {i + 1}"),
                    "mass_kg": _num(x.get("mass_kg"), path + ".mass_kg", iss), "com_m": _vec(x.get("com_m"), path + ".com_m", iss),
                    "inertia_kgm2": None if x.get("inertia_kgm2") is None else _mat3(x["inertia_kgm2"], path + ".inertia_kgm2", iss)})
    for k in v:
        if k not in out:
            iss.warn(f"plant.{k}", f"unknown plant field '{k}'; kept but not used.")
            out[k] = copy.deepcopy(v[k])
    return out


WHEEL_FIELDS = ("axis", "Jw", "KV", "R", "Vs", "Imax", "wmaxRpm", "cv", "cc", "health")


def effective_wheels(cfg: dict) -> list:
    """The wheels the engine simulates: the explicit `wheels` block, or the browser's three wheels
    derived from `params` and `actuator.wheel_health` (kept implicit so that editing params keeps
    them consistent)."""
    if cfg.get("wheels"):
        return cfg["wheels"]
    return default_wheels(cfg["params"], cfg["actuator"]["wheel_health"])


def _wheels(v, params: dict, health: dict, iss: Issues):
    if v is None:
        return None
    base = default_wheels(params, health)
    if not isinstance(v, list) or not v:
        iss.err("wheels", "must be a non-empty list of wheel objects.")
        return None
    out = []
    for i, w in enumerate(v):
        path = f"wheels.{i}"
        if not isinstance(w, dict):
            iss.err(path, "must be an object.")
            continue
        d = dict(base[i]) if i < 3 else dict(base[0], id=f"w{i + 1}")
        d["id"] = _str(w.get("id"), path + ".id", iss, d["id"])
        for k in WHEEL_FIELDS:
            if k in w:
                d[k] = _vec(w[k], f"{path}.axis", iss) if k == "axis" else _num(w[k], f"{path}.{k}", iss)
        for k in w:
            if k not in WHEEL_FIELDS and k != "id":
                iss.warn(f"{path}.{k}", f"unknown wheel field '{k}'; kept but not used.")
                d[k] = copy.deepcopy(w[k])
        out.append(d)
    return out

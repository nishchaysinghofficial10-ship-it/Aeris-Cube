"""Authoritative backend validation of an aeris-config/1 setup (layers 1–3).

Layer 1  structure and types            (normalize.py)
Layer 2  ranges this engine supports     (kind "range"), and features it can run (kind "capability")
Layer 3  physical consistency            (kind "physics"): the browser engine's checks
         (AERIS_TWIN.validateConfig) plus the research extensions (tensors, wheels, rates)
Every issue has a dotted path, a message, a severity and a kind. The browser runs the same
layer-1 rules and its own capability rules (site/js/platform/config.js); this module decides for
SIMULATION mode.
"""
from __future__ import annotations

import math

import numpy as np

from ..constants import (ASSESS, BACKEND_LIMITS, CORNER_ESTIMATORS, DEG, EDGE_ESTIMATORS, PARAM_SPEC, RPM,
                         SENSOR_DEFAULTS, SENSOR_SPEC)
from ..control.design import DesignError
from ..physics.mass import check_tensor, mass_properties
from .normalize import Issues, effective_wheels, is_num, normalize


def fmt(x, unit="", sig=3):
    if not isinstance(x, (int, float)) or not math.isfinite(x):
        return str(x)
    s = f"{x:.{sig}g}" if 1e-3 <= abs(x) < 1e5 or x == 0 else f"{x:.{sig - 1}e}"
    return s + (" " + unit if unit else "")


class Result:
    def __init__(self, cfg, issues: Issues, mp=None, design=None, workload=None):
        self.config = cfg
        self.issues = issues
        self.mp = mp
        self.design = design
        self.workload = workload

    @property
    def errors(self):
        return self.issues.errors

    @property
    def warnings(self):
        return self.issues.warnings

    @property
    def ok(self):
        return not self.issues.errors

    def as_dict(self):
        return {"ok": self.ok, "errors": self.errors, "warnings": self.warnings, "config": self.config, "workload": self.workload}


def validate_config(raw, limits: dict | None = None) -> Result:
    L = dict(BACKEND_LIMITS, **(limits or {}))
    cfg, iss = normalize(raw)
    if iss.errors:
        return Result(cfg, iss)
    E = iss
    p = cfg["params"]
    edge = cfg["mode"] == "edge"

    def chk(path, v, lo, hi, label, unit="", kind="range"):
        if not is_num(v):
            E.err(path, f"{label} must be a finite number.", kind)
        elif v < lo or v > hi:
            E.err(path, f"{label} = {fmt(v, unit)} must lie between {fmt(lo, unit)} and {fmt(hi, unit)}.", kind)

    # ---------------- layer 2: ranges ----------------
    for k, sp in PARAM_SPEC.items():
        v = p[k]
        if v < sp["min"] or v > sp["max"]:
            E.err("params." + k, f"{sp['label']} = {fmt(v, sp['unit'])} is outside the supported range {fmt(sp['min'], sp['unit'])} to {fmt(sp['max'], sp['unit'])}.", "range")
    chk("duration_s", cfg["duration_s"], L["minDuration_s"], L["maxDuration_s"], "Duration", "s")
    chk("record_hz", cfg["record_hz"], L["minRecord_hz"], L["maxRecord_hz"], "Recording rate", "Hz")
    chk("torqueScale", cfg["torqueScale"], 0.2, 2, "Torque limit scale")
    chk("uncertainty.inertiaScale", cfg["uncertainty"]["inertiaScale"], 0.5, 2, "Plant inertia scale")
    chk("comOffset_m", cfg["comOffset_m"], -0.02, 0.02, "Base COM offset", "m")
    for j, v in enumerate(cfg["comShift_m"]):
        chk(f"comShift_m.{j}", v, -0.05, 0.05, "Base COM shift " + "xyz"[j], "m")
    for k, sp in SENSOR_SPEC.items():
        chk("sensor." + k, cfg["sensor"][k], sp["min"], sp["max"], sp["label"], sp["unit"])
    chk("actuator.motor_lag_ms", cfg["actuator"]["motor_lag_ms"], 0, 200, "Motor torque lag", "ms")
    for w in ("x", "y", "z"):
        chk("actuator.wheel_health." + w, cfg["actuator"]["wheel_health"][w], 0, 1, f"Wheel {w.upper()} health")
    _initial_checks(cfg, raw, E, chk, edge)
    wsr = cfg["initial"].get("wheel_speeds_rpm")
    if wsr is not None:
        nw = len(effective_wheels(cfg))
        if len(wsr) != nw:
            E.err("initial.wheel_speeds_rpm", f"needs {nw} values (one per wheel).", "range")
        for j, x in enumerate(wsr):
            chk(f"initial.wheel_speeds_rpm.{j}", x, -30000, 30000, "Initial wheel speed", "rpm")
    if not (is_num(cfg["seed"]) and 0 <= cfg["seed"] <= 0xFFFFFFFF):
        E.err("seed", "Random seed must be an integer from 0 to 4294967295.", "range")
    if cfg["estimator"].get("Rkf_deg") is not None:
        chk("estimator.Rkf_deg", cfg["estimator"]["Rkf_deg"], 0.01, 20, "Kalman accelerometer noise", "°")
    if cfg["estimator"].get("stale_after_s") is not None:
        chk("estimator.stale_after_s", cfg["estimator"]["stale_after_s"], 1e-4, 10, "Estimate age limit", "s")
        if cfg["estimator"]["type"] == "ideal":
            E.warn("estimator.stale_after_s", "The perfect-state baseline has no measurement age, so the age limit has no effect.", "capability")
    if len(cfg["attachments"]) > L["maxAttachments"]:
        E.err("attachments", f"At most {L['maxAttachments']} attached masses are supported.", "range")
    a = p["a"]
    for i, at in enumerate(cfg["attachments"]):
        nm = f"Attached mass '{at['label']}'"
        chk(f"attachments.{i}.mass_kg", at["mass_kg"], 1e-4, 5, nm + " mass", "kg")
        for j, v in enumerate(at["pos_m"]):
            if v < -1e-4 or v > a + 1e-4:
                E.err(f"attachments.{i}.pos_m", f"{nm}: {'xyz'[j]} = {fmt(v * 1000, 'mm')} is outside the cube (0 to {fmt(a * 1000, 'mm')}). Attachments must sit on or inside the frame.", "range")
    # rates
    fs = p["fs"]
    f_int = cfg["solver"]["integration_hz"] or fs
    if cfg["solver"]["integration_hz"] is not None:
        chk("solver.integration_hz", f_int, fs, L["maxIntegration_hz"], "Integration rate", "Hz")
    ratio = f_int / fs
    if abs(ratio - round(ratio)) > 1e-9:
        E.err("solver.integration_hz", f"The integration rate ({fmt(f_int, 'Hz')}) must be an integer multiple of the control rate f_s = {fmt(fs, 'Hz')}, so every control update falls on an integration step.", "range")
    rate = cfg["sensor"]["rate_hz"]
    if rate is not None:
        if not rate > 0:
            E.err("sensor.rate_hz", "IMU sample rate must be a positive number of hertz, or null (the control rate).", "range")
        elif abs(f_int / rate - round(f_int / rate)) > 1e-9:
            E.err("sensor.rate_hz", f"The IMU rate ({fmt(rate, 'Hz')}) must divide the integration rate ({fmt(f_int, 'Hz')}) so samples fall on integration steps.", "range")
        elif cfg["estimator"]["type"] in ("cf", "kf", "accel", "gyro") and abs(rate - fs) > 1e-9:
            E.err("sensor.rate_hz", "The browser edge estimators (cf, kf, accel, gyro) sample at the control rate; an independent IMU rate needs cf3d or mekf.", "capability")
        elif cfg["estimator"]["type"] == "ideal":
            E.warn("sensor.rate_hz", "The estimator is the perfect-state baseline, so the IMU rate has no effect.", "capability")
    rec_hz = cfg["record_hz"]
    if rec_hz > f_int + 1e-9:
        E.err("record_hz", f"The recording rate ({fmt(rec_hz, 'Hz')}) cannot exceed the integration rate ({fmt(f_int, 'Hz')}).", "range")
    elif rec_hz > 0 and abs(f_int / rec_hz - round(f_int / rec_hz)) > 1e-9 * max(1.0, f_int / rec_hz):
        E.err("record_hz", record_rate_message(rec_hz, f_int, L), "range")
    steps = int(round(cfg["duration_s"] * f_int))
    if abs(steps / f_int - cfg["duration_s"]) > 1e-9 * max(1.0, cfg["duration_s"]):
        E.warn("duration_s", f"The run advances in whole integration steps: {steps} steps of {fmt(1 / f_int, 's')} cover {fmt(steps / f_int, 's', 9)}, not exactly the requested {fmt(cfg['duration_s'], 's', 9)}. The executed window is saved with the run.", "range")
    if steps > L["maxSteps_per_run"]:
        E.err("duration_s", f"{steps:,} integration steps exceed this backend's limit of {L['maxSteps_per_run']:,} per run; shorten the run or lower the integration rate.", "range")
    # ---------------- extension blocks ----------------
    wl = effective_wheels(cfg)
    if len(wl) > L["maxWheels"]:
        E.err("wheels", f"At most {L['maxWheels']} wheels are supported.", "range")
    for i, w in enumerate(wl):
        path = f"wheels.{i}"
        if cfg.get("wheels") is None:
            break
        axn = math.sqrt(sum(x * x for x in w["axis"]))
        if not axn > 1e-9:
            E.err(path + ".axis", "Wheel axis must be a non-zero vector.", "range")
        for k in ("Jw", "KV", "R", "Vs", "Imax", "wmaxRpm", "cv", "cc"):
            sp = PARAM_SPEC[k]
            if w[k] < sp["min"] or w[k] > sp["max"]:
                E.err(f"{path}.{k}", f"Wheel {w['id']}: {sp['label']} = {fmt(w[k], sp['unit'])} is outside {fmt(sp['min'], sp['unit'])} to {fmt(sp['max'], sp['unit'])}.", "range")
        chk(f"{path}.health", w["health"], 0, 1, f"Wheel {w['id']} health")
    if cfg.get("wheels") is not None and len({w["id"] for w in wl}) != len(wl):
        E.err("wheels", "Wheel ids must be unique.", "range")
    ids = [w["id"] for w in wl]
    if cfg.get("wheels") is not None:
        A = np.array([w["axis"] for w in wl], dtype=float).T
        if not edge and np.linalg.matrix_rank(A, tol=1e-6) < 3:
            E.err("wheels", "Corner mode needs wheel axes that span three dimensions.", "physics")
        if edge and max(abs(w["axis"][0]) for w in wl) < 1e-6:
            E.err("wheels", "Edge mode needs a wheel with a component along the support edge (body x).", "physics")
    pl = cfg["plant"]
    if pl.get("base_inertia_kgm2") is not None:
        for msg in check_tensor(pl["base_inertia_kgm2"], "The base inertia tensor"):
            E.err("plant.base_inertia_kgm2", msg, "physics")
    if pl.get("base_com_m") is not None:
        for j, v in enumerate(pl["base_com_m"]):
            if v < -1e-4 or v > a + 1e-4:
                E.err("plant.base_com_m", f"Base centre of mass {'xyz'[j]} = {fmt(v * 1000, 'mm')} is outside the cube.", "physics")
    if len(pl.get("components") or []) > L["maxComponents"]:
        E.err("plant.components", f"At most {L['maxComponents']} components are supported.", "range")
    for i, c in enumerate(pl.get("components") or []):
        path = f"plant.components.{i}"
        chk(path + ".mass_kg", c["mass_kg"], 1e-5, 20, f"Component '{c['label']}' mass", "kg")
        for j, v in enumerate(c["com_m"]):
            if v < -1e-4 or v > a + 1e-4:
                E.err(path + ".com_m", f"Component '{c['label']}': {'xyz'[j]} = {fmt(v * 1000, 'mm')} is outside the cube.", "physics")
        if c.get("inertia_kgm2") is not None:
            for msg in check_tensor(c["inertia_kgm2"], f"Component '{c['label']}' inertia tensor", allow_zero=True):
                E.err(path + ".inertia_kgm2", msg, "physics")
    pert = cfg["uncertainty"].get("inertia_perturbation_kgm2")
    if pert is not None:
        P = np.array(pert)
        if np.max(np.abs(P - P.T)) > 1e-12:
            E.err("uncertainty.inertia_perturbation_kgm2", "The inertia perturbation must be symmetric.", "physics")
    # controller capability
    ct = cfg["controller"]
    st = ct.get("structure", "decoupled")
    if st == "mimo-lqr":
        if edge:
            E.err("controller.structure", "The MIMO LQR is a corner-mode design; edge mode has one tilt degree of freedom (use the decoupled structure).", "capability")
        elif ct["type"] != "lqr":
            E.err("controller.structure", f"The 'mimo-lqr' structure is an LQR design; controller type '{ct['type']}' has no MIMO form here. Choose type 'lqr' or the decoupled structure.", "capability")
    if ct["type"] in ("pid", "lqr", "adp") and st == "decoupled" and not edge and cfg.get("wheels") is not None:
        from ..actuators import WheelSet
        if not WheelSet(cfg).standard:
            E.err("controller.type", "The browser's decoupled corner controllers assume three wheels along the body axes. With another wheel layout use 'mimo-lqr' or 'nlpd'.", "capability")
    est = cfg["estimator"]["type"]
    allowed = EDGE_ESTIMATORS if edge else CORNER_ESTIMATORS
    if est not in allowed:
        E.err("estimator.type", f"Estimator '{est}' is not available in {cfg['mode']} mode here; choose one of: {', '.join(allowed)}. (cf, kf, accel and gyro are the browser's single-axis edge filters; corner mode uses the quaternion filters cf3d or mekf.)", "capability")
    if est in ("cf3d", "mekf"):
        comp = (cfg["estimator"].get(est) or {}).get("compensate_dynamic", True)
        if cfg["sensor"].get("accel_dynamic", True) is False and comp is not False:
            E.warn(f"estimator.{est}.compensate_dynamic",
                   f"The sensor model measures gravity only (sensor.accel_dynamic = false), but the filter removes a dynamic acceleration α̂×r + ω̂×(ω̂×r) the samples do not contain, which biases its gravity direction when the cube rotates. Set estimator.{est}.compensate_dynamic = false for a matched filter (kept as requested).", "capability")
    sensor_changed = any(is_num(cfg["sensor"][k]) and cfg["sensor"][k] != SENSOR_DEFAULTS[k] for k in SENSOR_SPEC)
    if sensor_changed and est == "ideal":
        E.warn("sensor", "The estimator is 'Ideal state': the controller sees the true state, so the sensor settings have no effect. Choose an estimator to use them.", "capability")
    if edge and (cfg["actuator"]["wheel_health"]["y"] != 1 or cfg["actuator"]["wheel_health"]["z"] != 1) and cfg.get("wheels") is None:
        E.warn("actuator.wheel_health", "Edge mode drives only wheel X; the health of wheels Y and Z has no effect.", "capability")
    rc = cfg["recovery"]
    chk("recovery.attitude_error_deg", rc["attitude_error_deg"], 0.01, 30, "Recovery attitude threshold", "°")
    chk("recovery.rate_dps", rc["rate_dps"], 0.01, 500, "Recovery rate threshold", "°/s")
    chk("recovery.hold_s", rc["hold_s"], 0, 60, "Recovery hold time", "s")
    if rc["max_time_s"] is not None:
        chk("recovery.max_time_s", rc["max_time_s"], 0, L["maxDuration_s"], "Maximum recovery time", "s")
    if edge and rc["yaw_objective"] != "hold" and raw.get("recovery", {}) and isinstance(raw.get("recovery"), dict) and "yaw_objective" in raw["recovery"]:
        E.warn("recovery.yaw_objective", "Edge mode has no yaw; the yaw objective has no effect.", "capability")
    tm = cfg["termination"]
    chk("termination.post_fall_s", tm["post_fall_s"], 0, 10, "Recording after a fall", "s")
    if tm["overspeed_rpm"] is not None:
        chk("termination.overspeed_rpm", tm["overspeed_rpm"], 1, 100000, "Overspeed safety limit", "rpm")
    chk("termination.max_quaternion_drift", tm["max_quaternion_drift"], 1e-12, 0.1, "Quaternion drift tolerance")
    nl = ct.get("nonlinear")
    if nl:
        for k in ("omega_n", "zeta", "yaw_omega_n", "yaw_zeta", "momentum_omega", "max_ref_tilt_deg"):
            chk(f"controller.nonlinear.{k}", nl[k], 1e-3, 1e3, k)
    lq = ct.get("lqr")
    if lq:
        for k in ("tilt_deg", "rate_dps", "wheel_rad_s", "yaw_deg", "yaw_rate_dps", "r_scale"):
            chk(f"controller.lqr.{k}", lq[k], 1e-6, 1e6, f"LQR weight {k}")
    ad = ct.get("adaptive")
    if ad:
        chk("controller.adaptive.gamma", ad["gamma"], 0, 1, "Adaptation gain γ")
        chk("controller.adaptive.clamp_deg", ad["clamp_deg"], 0, 30, "Adaptation clamp", "°")
    # disturbances / events / commands
    dur = cfg["duration_s"]
    for i, Ld in enumerate(cfg["disturbances"]):
        path = f"disturbances.{i}"
        t = Ld["type"]
        nm = {"force": "Force", "torque": "Torque load", "bias": "Torque bias", "impulse": "Impulse", "force_impulse": "Force impulse"}[t] + f" '{Ld['id']}'"
        if not any(is_num(x) for x in Ld["direction"]) or math.sqrt(sum(x * x for x in Ld["direction"])) < 1e-9:
            E.err(path + ".direction", f"{nm}: direction must be a non-zero vector.", "range")
        if t == "force":
            chk(path + ".magnitude_N", Ld["magnitude_N"], 0, 100, nm + " magnitude", "N")
        elif t in ("torque", "bias"):
            chk(path + ".magnitude_Nm", Ld["magnitude_Nm"], 0, 5, nm + " magnitude", "N·m")
        elif t == "impulse":
            chk(path + ".magnitude_Nms", Ld["magnitude_Nms"], 0, 5, nm + " magnitude", "N·m·s")
        elif t == "force_impulse":
            chk(path + ".impulse_Ns", Ld["impulse_Ns"], 0, 50, nm + " magnitude", "N·s")
        if t in ("force", "force_impulse"):
            for j, v in enumerate(Ld["point_m"]):
                if v < -1e-4 or v > a + 1e-4:
                    E.err(path + ".point_m", f"{nm}: application point {'xyz'[j]} = {fmt(v * 1000, 'mm')} is outside the cube.", "range")
        if t in ("force", "torque", "bias"):
            chk(path + ".t_start_s", Ld["t_start_s"], 0, L["maxDuration_s"], nm + " start time", "s")
            if not (t == "bias" and Ld["duration_s"] is None):
                chk(path + ".duration_s", Ld["duration_s"], 1e-3, L["maxDuration_s"], nm + " duration", "s")
                if is_num(Ld["duration_s"]) and Ld["duration_s"] < 4 / f_int:
                    E.warn(path + ".duration_s", f"{nm} lasts {fmt(Ld['duration_s'], 's')}, less than four integration steps; the RK4 stages sample it only approximately. Use an 'impulse' for short events or raise solver.integration_hz.", "range")
            if Ld["t_start_s"] >= dur:
                E.warn(path + ".t_start_s", f"{nm} starts after the run ends and will have no effect.", "range")
        else:
            chk(path + ".t_s", Ld["t_s"], 0, L["maxDuration_s"], nm + " time", "s")
            if Ld["t_s"] >= dur:
                E.warn(path + ".t_s", f"{nm} is scheduled after the run ends and will have no effect.", "range")
    for i, ev in enumerate(cfg["events"]):
        path = f"events.{i}"
        if ev["wheel"] not in ids:
            E.err(path + ".wheel", f"Wheel must be one of {', '.join(ids)}.", "range")
        chk(path + ".t_s", ev["t_s"], 0, L["maxDuration_s"], "Event time", "s")
        if ev.get("duration_s") is not None:
            chk(path + ".duration_s", ev["duration_s"], 1e-3, L["maxDuration_s"], "Event duration", "s")
        if ev["type"] == "wheel_degradation":
            chk(path + ".health", ev["health"], 0, 1, "Degraded health factor")
        elif ev["type"] == "wheel_torque_limit":
            chk(path + ".limit_Nm", ev["limit_Nm"], 0, 10, "Imposed torque limit", "N·m")
        elif ev["type"] == "wheel_speed_limit":
            chk(path + ".limit_rpm", ev["limit_rpm"], 0, 30000, "Imposed speed limit", "rpm")
        if is_num(ev["t_s"]) and ev["t_s"] >= dur:
            E.warn(path + ".t_s", f"The event on wheel {str(ev['wheel']).upper()} at {fmt(ev['t_s'], 's')} happens after the run ends and will have no effect.", "range")
        if edge and ev["wheel"] in ids and cfg.get("wheels") is None and ev["wheel"] != "x":
            E.warn(path + ".wheel", f"Edge mode drives only the X wheel (its axis is parallel to the support edge); an event on wheel {ev['wheel'].upper()} has no effect.", "capability")
    _reference_checks(cfg, raw, E, chk, edge, ct)
    for i, c in enumerate(cfg["commands"]):
        path = f"commands.{i}"
        if edge:
            E.err(path, "Yaw commands apply to corner mode only.", "capability")
        chk(path + ".t_s", c["t_s"], 0, L["maxDuration_s"], "Yaw command time", "s")
        chk(path + ".angle_deg", c["angle_deg"], -180, 180, "Yaw command angle", "°")
        if is_num(c["t_s"]) and c["t_s"] >= dur:
            E.warn(path + ".t_s", f"The yaw command at {fmt(c['t_s'], 's')} happens after the run ends and will have no effect.", "range")
    if E.errors:
        return Result(cfg, E)
    # ---------------- layer 3: physics ----------------
    Jc = p["kJ"] * p["m"] * a * a
    JwMax = p["m"] * a * a / 12
    for w in wl:
        if w["Jw"] >= JwMax:
            E.err("params.Jw" if cfg.get("wheels") is None else "wheels", f"Wheel spin inertia J_w = {fmt(w['Jw'], 'kg·m²')} is too large for a {fmt(p['m'], 'kg')}, {fmt(a * 1000, 'mm')} cube. A wheel of radius at most a/2 carrying at most a third of the base mass has J_w < m·a²/12 = {fmt(JwMax, 'kg·m²')}. Reduce J_w or increase the mass or edge length.", "physics")
    if pl.get("base_inertia_kgm2") is None and Jc < 2 * p["Jw"]:
        E.err("params.kJ", f"Body inertia J_c = k_J·m·a² = {fmt(Jc, 'kg·m²')} is smaller than the {fmt(2 * p['Jw'], 'kg·m²')} that the three wheels alone contribute about any axis (one wheel's spin inertia plus half of each other wheel's, by the perpendicular-axis theorem). This would make the effective inertias negative. Increase k_J, m or a, or reduce J_w.", "physics")
    kt = 60 / (2 * math.pi * p["KV"])
    wnl = p["Vs"] / kt
    if wnl < p["wmaxRpm"] * RPM:
        E.warn("params.wmaxRpm", f"The wheel speed limit ({fmt(p['wmaxRpm'], 'rpm')}) is above the motor's no-load speed ({fmt(wnl / RPM, 'rpm', 4)}); back-EMF will stop the wheel before the limit.", "physics")
    if E.errors:
        return Result(cfg, E)
    mp = mass_properties(cfg)
    ThO = np.array(mp["ThO"])
    for msg in check_tensor(ThO, "The total inertia about the pivot"):
        E.err("plant", msg, "physics")
    tol = 0.5e-3
    if edge:
        if not mp["edge"]["Thh"] > 0:
            E.err("attachments", "Effective inertia about the support edge is not positive.", "physics")
        if mp["edge"]["l"] < 1e-3:
            E.err("attachments", f"The centre of mass lies on the support edge ({fmt(mp['edge']['l'] * 1000, 'mm')} from it); there is nothing to balance.", "physics")
        xc = mp["edge"]["xc"]
        if xc <= tol or xc >= a - tol:
            E.err("attachments", f"The centre of mass (x = {fmt(xc * 1000, 'mm')}) is at or beyond the end of the support edge (0 to {fmt(a * 1000, 'mm')}). The cube would tip over the end of the edge, which the planar edge model cannot represent.", "physics")
        elif xc < 0.1 * a or xc > 0.9 * a:
            E.warn("attachments", f"The centre of mass sits {fmt(min(xc, a - xc) * 1000, 'mm')} from one end of the support edge. A real cube could tip over that end; the planar edge model only allows rotation about the edge.", "physics")
        bE = abs(mp["edge"]["beta"]) / DEG
        if bE >= ASSESS["contactEdgeDeg"]:
            E.err("attachments", f"The centre of mass is {bE:.1f}° off the edge's balance line. Balancing would need a lean of {bE:.1f}°, but a face touches the floor at {ASSESS['contactEdgeDeg']:g}°.", "physics")
        elif bE > ASSESS["fallEdgeDeg"] - 5:
            E.warn("attachments", f"The balance attitude is {bE:.1f}° from the geometric one, close to where a face touches the floor.", "physics")
    else:
        if not mp["corner"]["minEig"] > 0:
            E.err("attachments", "Effective inertia about the pivot is not positive definite.", "physics")
        if mp["corner"]["l"] < 1e-3:
            E.err("attachments", "The centre of mass coincides with the pivot corner.", "physics")
        bC = mp["corner"]["beta"] / DEG
        clr = mp["corner"]["edgeClear"] / DEG
        if not mp["corner"]["edgeClear"] > 0:
            E.err("attachments", f"With the centre of mass {bC:.1f}° off the main diagonal, the balance attitude would put one of the pivot's edges on the floor, so the cube would be resting on an edge rather than balancing on the corner.", "physics")
        elif clr < ASSESS["cornerEdgeClearWarnDeg"]:
            E.warn("attachments", f"The centre of mass is {bC:.1f}° off the main diagonal. At the balance attitude the lowest edge is only {clr:.1f}° above the floor.", "physics")
    design = None
    if not E.errors:
        from ..simulation.setup import initial_state
        ini = initial_state(cfg, mp)
        fall_lim = ASSESS["fallEdgeDeg"] if edge else ASSESS["fallCornerDeg"]
        if not ini["clear"] > 0:
            E.err("initial", "The initial attitude puts part of the cube on the floor (" + (f"|θ₀| = {abs(ini['theta']) / DEG:.1f}° ≥ {ASSESS['contactEdgeDeg']:g}°" if edge else "one of the pivot's edges is below the floor") + "). Reduce the initial tilt.", "physics")
        elif abs(ini["e"]) / DEG > fall_lim:
            E.warn("initial", f"At t = 0 the centre of mass is already {abs(ini['e']) / DEG:.1f}° from vertical, beyond the {fall_lim:g}° fall threshold, so the run will be reported as Fallen straight away.", "physics")
    for i, Ld in enumerate(cfg["disturbances"]):
        if Ld["type"] == "force" and Ld["magnitude_N"] > 0.5 * mp["M"] * p["g"]:
            E.warn(f"disturbances.{i}", f"Force '{Ld['id']}' ({fmt(Ld['magnitude_N'], 'N')}) exceeds half the cube's weight ({fmt(0.5 * mp['M'] * p['g'], 'N')}). The model assumes the pivot never slips; lift-off ends the run (termination.check_lift_off).", "physics")
    if not E.errors:
        from ..actuators import WheelSet
        from ..simulation.setup import design_for_config
        try:
            design = design_for_config(cfg, mp, WheelSet(cfg))
        except DesignError as ex:
            E.err("controller", f"Controller design failed: {ex}. Check the inertia and torque parameters.", "physics")
        if design is not None:
            fastest = 0.0
            polys = []
            if "tilt" in design:
                polys += [design["tilt"]["cl"], design["tilt"]["pidPoles"], design["tilt"]["adpPoles"]]
            if "yaw" in design:
                polys.append(design["yaw"]["cl"])
            if "mimo" in design:
                polys.append(design["mimo"]["cl_reduced"])
            if ct["type"] == "nlpd":
                c = design_nl_rate(cfg)
                polys.append([[c, 0.0]])
            for ps in polys:
                for r in ps:
                    fastest = max(fastest, math.hypot(r[0], r[1]))
            lam = design["plant"]["lambda"]
            dt_ctrl = 1 / fs
            if not (math.isfinite(fastest) and math.isfinite(lam)):
                E.err("controller", "Controller design produced non-finite poles.", "physics")
            elif max(fastest, lam) * dt_ctrl > 0.5:
                E.err("params.fs", f"The loop rate f_s = {fmt(fs, 'Hz')} is too slow for these dynamics (fastest mode {fmt(max(fastest, lam), 's⁻¹')}). The sampled controller needs f_s ≥ {fmt(math.ceil(max(fastest, lam) / 0.5), 'Hz')}.", "physics")
            hold = mp["M"] * p["g"] * (mp["edge"]["l"] * abs(math.sin(mp["edge"]["beta"])) if edge else mp["corner"]["l"] * math.sin(mp["corner"]["beta"]))
            if hold > design["actuator"]["taumax"] and not ct["knowsAttachments"] and ct["type"] != "none":
                E.warn("controller.knowsAttachments", f"Held at the geometric attitude, gravity pulls with {fmt(hold, 'N·m')}, more than the motors' {fmt(design['actuator']['taumax'], 'N·m')}. This controller is designed for the bare cube, so it steers toward that attitude and is likely to fall. Enabling 'controller knows the attached masses' designs for the true balance attitude instead.", "physics")
    stride = max(1, round(f_int / cfg["record_hz"])) if cfg["record_hz"] > 0 else 1
    wl_ = {"integration_steps": steps, "integration_hz": f_int, "control_hz": fs, "sensor_hz": rate if rate is not None else fs,
           "record_hz": cfg["record_hz"], "record_stride_steps": stride,
           "recorded_rows": steps // stride + 1 + (1 if steps % stride else 0)}
    return Result(cfg, E, mp if not E.errors else None, design if not E.errors else None, wl_)


def _initial_checks(cfg, raw, E, chk, edge):
    """Revision 1.2 initial state (docs/EXPERIMENT_CONTRACT.md §1): explicit attitude quaternion and body-rate
    vector, their conflicts with the legacy tilt inputs, and the support model's constraints."""
    from ..physics.quaternion import edge_quat, qconj, qmul
    ini = cfg["initial"]
    raw_ini = raw.get("initial") if isinstance(raw, dict) and isinstance(raw.get("initial"), dict) else {}
    q = ini.get("attitude_q")
    if q is not None:
        conflict = [k for k in ("tilt_deg", "azimuth_deg", "reference") if raw_ini.get(k) is not None]
        if conflict:
            E.err("initial.attitude_q", "An explicit initial attitude replaces the legacy tilt inputs; " + ", ".join("initial." + k for k in conflict)
                  + " must be null or absent (they would describe a different attitude).", "range")
        if all(is_num(x) for x in q):
            n = math.sqrt(sum(x * x for x in q))
            if abs(n - 1.0) > 1e-6:
                E.err("initial.attitude_q", f"must be a unit quaternion [w, x, y, z] (scalar first, body → world); its norm is {n:.9g}. Normalise it (tolerance 1e-6).", "range")
            else:
                if abs(n - 1.0) > 1e-12:
                    E.warn("initial.attitude_q", f"renormalised from norm {n:.12g} to 1 (stored normalised).", "range")
                ini["attitude_q"] = [x / n for x in q]
                if edge:
                    qr = qmul(qconj(edge_quat(0.0)), tuple(ini["attitude_q"]))
                    off = 2 * math.degrees(math.atan2(math.hypot(qr[2], qr[3]), math.hypot(qr[0], qr[1])))
                    if off > 1e-4:
                        E.err("initial.attitude_q", f"Edge mode rotates only about the support edge (body x): the attitude must be a rotation about x from the edge reference attitude; this one is {off:.4g}° off that axis.", "range")
    else:
        chk("initial.tilt_deg", ini["tilt_deg"], -30, 30, "Initial tilt", "°")
        chk("initial.azimuth_deg", ini["azimuth_deg"], -360, 360, "Initial tilt direction", "°")
    w = ini.get("body_rate_dps")
    if w is not None:
        if raw_ini.get("rate_dps") is not None:
            E.err("initial.body_rate_dps", "An explicit body-rate vector replaces the legacy initial.rate_dps, which must be null or absent.", "range")
        for j, x in enumerate(w):
            chk(f"initial.body_rate_dps.{j}", x, -200, 200, f"Initial body rate ω_{'xyz'[j]}", "°/s")
        if edge and all(is_num(x) for x in w) and (abs(w[1]) > 1e-9 or abs(w[2]) > 1e-9):
            E.err("initial.body_rate_dps", "Edge mode rotates only about the support edge: the body rate must be [ω_x, 0, 0].", "range")
    else:
        chk("initial.rate_dps", ini["rate_dps"], -200, 200, "Initial rate", "°/s")
        if q is not None and not edge and is_num(ini["rate_dps"]) and ini["rate_dps"] != 0:
            E.err("initial.rate_dps", "With an explicit initial attitude the legacy rate (about the legacy tilt axis) has no axis; give initial.body_rate_dps instead.", "range")


def _reference_checks(cfg, raw, E, chk, edge, ct):
    """Revision 1.2 reference block (docs/EXPERIMENT_CONTRACT.md §2): supported objective/controller combinations."""
    ref = cfg["reference"]
    if edge:
        return
    if ref.get("yaw_deg") is not None:
        chk("reference.yaw_deg", ref["yaw_deg"], -180, 180, "Heading offset", "°")
    if ref.get("heading") == "free":
        if ct["type"] == "lqr" and ct.get("structure") == "mimo-lqr":
            E.err("reference.heading", "The coupled MIMO LQR regulates the full attitude including the heading; a free heading is not supported with it. "
                  "Hold the heading, or use a decoupled controller or the nonlinear PD.", "capability")
        if cfg["commands"]:
            E.err("commands", "Yaw commands need reference.heading = 'hold' (a free heading has no heading objective to command).", "capability")
        if is_num(ref.get("yaw_deg")) and ref["yaw_deg"] != 0:
            E.err("reference.yaw_deg", "A heading offset needs reference.heading = 'hold'.", "capability")
        raw_rec = raw.get("recovery") if isinstance(raw, dict) and isinstance(raw.get("recovery"), dict) else {}
        if raw_rec.get("yaw_objective") == "hold":
            E.err("recovery.yaw_objective", "The recovery criteria cannot require a heading that the controller does not control (reference.heading = 'free').", "capability")
    elif ct["type"] == "none" and (cfg["commands"] or (is_num(ref.get("yaw_deg")) and ref["yaw_deg"] != 0)):
        E.warn("reference", "Controller 'none' applies no torque, so the heading reference is not tracked; the recovery criteria still use it.", "capability")


def valid_record_rates(f_int, lo, hi):
    """Recording rates that divide the integration rate (samples fall on integration steps), within [lo, hi]."""
    out = []
    m = 1
    while f_int / m >= lo - 1e-12 and m <= 100000:
        r = f_int / m
        if r <= hi + 1e-12:
            out.append(r)
        m += 1
    return out


def record_rate_message(rec_hz, f_int, L):
    rates = valid_record_rates(f_int, L["minRecord_hz"], L["maxRecord_hz"])
    below = [r for r in rates if r < rec_hz]
    above = [r for r in rates if r > rec_hz]
    sugg = [fmt(x, "Hz", 6) for x in ([max(below)] if below else []) + ([min(above)] if above else [])]
    realized = f_int / max(1, round(f_int / rec_hz))
    return (f"The recording rate {fmt(rec_hz, 'Hz', 6)} does not divide the {fmt(f_int, 'Hz', 6)} integration rate. Samples are integration-step "
            f"states, so it could only be realized as {fmt(realized, 'Hz', 6)} and would be mislabelled. Choose a divisor of the integration rate"
            + (f" (nearest: {' or '.join(sugg)})" if sugg else "") + " or change solver.integration_hz.")


def design_nl_rate(cfg):
    from ..simulation.setup import nonlinear_settings
    c = nonlinear_settings(cfg)
    return max(c["omega_n"], c["yaw_omega_n"]) * (c["zeta"] + math.sqrt(max(0.0, c["zeta"] ** 2 - 1)) + 1)

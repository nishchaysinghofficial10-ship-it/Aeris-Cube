"""Quaternion and small-vector helpers (plain Python floats for speed in the step loop).

Conventions (identical to the browser engine, site/js/core.js):
- a quaternion is (w, x, y, z), scalar first, Hamilton product;
- rot(q) is the rotation matrix that maps BODY coordinates to WORLD coordinates, v_w = R v_b;
- attitude kinematics q̇ = ½ q ⊗ (0, ω) with ω the body angular velocity in body coordinates;
- q and −q describe the same attitude (sign ambiguity); angle() and log() pick the short way.
"""
from __future__ import annotations

import math

Vec = tuple  # (x, y, z)
Quat = tuple  # (w, x, y, z)


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def scale(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def norm(a):
    return math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])


def unit(a):
    n = norm(a)
    return (a[0] / n, a[1] / n, a[2] / n) if n > 0 else (0.0, 0.0, 0.0)


def mv(M, v):
    return (M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2],
            M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2],
            M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2])


def mtv(M, v):
    """Mᵀ v."""
    return (M[0][0] * v[0] + M[1][0] * v[1] + M[2][0] * v[2],
            M[0][1] * v[0] + M[1][1] * v[1] + M[2][1] * v[2],
            M[0][2] * v[0] + M[1][2] * v[1] + M[2][2] * v[2])


def proj_on(v, u):
    """Component of v perpendicular to the unit vector u."""
    s = dot(v, u)
    return (v[0] - s * u[0], v[1] - s * u[1], v[2] - s * u[2])


def qmul(a, b):
    return (a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
            a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
            a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
            a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0])


def qconj(q):
    return (q[0], -q[1], -q[2], -q[3])


def qnorm(q):
    n = math.sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
    return (q[0] / n, q[1] / n, q[2] / n, q[3] / n)


def qlen(q):
    return math.sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])


def rot(q):
    """Rotation matrix body → world (same formula as AERIS_TWIN.Q3.rot)."""
    q0, q1, q2, q3 = q
    return ((1 - 2 * (q2 * q2 + q3 * q3), 2 * (q1 * q2 - q0 * q3), 2 * (q1 * q3 + q0 * q2)),
            (2 * (q1 * q2 + q0 * q3), 1 - 2 * (q1 * q1 + q3 * q3), 2 * (q2 * q3 - q0 * q1)),
            (2 * (q1 * q3 - q0 * q2), 2 * (q2 * q3 + q0 * q1), 1 - 2 * (q1 * q1 + q2 * q2)))


def up_in_body(q):
    """World up (0, 0, 1) expressed in body coordinates = third row of rot(q)."""
    q0, q1, q2, q3 = q
    return (2 * (q1 * q3 - q0 * q2), 2 * (q2 * q3 + q0 * q1), 1 - 2 * (q1 * q1 + q2 * q2))


def axis_angle(ax, ang):
    n = math.sqrt(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2])
    if not n > 0:
        return (1.0, 0.0, 0.0, 0.0)
    s = math.sin(ang / 2) / n
    return (math.cos(ang / 2), ax[0] * s, ax[1] * s, ax[2] * s)


def from_to(u, v):
    """Shortest rotation taking unit vector u to unit vector v (AERIS_TWIN.Q3.fromTo)."""
    c = dot(u, v)
    ax = cross(u, v)
    s = norm(ax)
    if s < 1e-12:
        if c > 0:
            return (1.0, 0.0, 0.0, 0.0)
        perp = cross(u, (1.0, 0.0, 0.0)) if abs(u[0]) < 0.9 else cross(u, (0.0, 1.0, 0.0))
        return axis_angle(perp, math.pi)
    return axis_angle(ax, math.atan2(s, c))


def exp_vec(phi):
    """Quaternion of the rotation vector phi (angle |phi| about phi/|phi|)."""
    a = norm(phi)
    if a < 1e-12:
        return qnorm((1.0, phi[0] / 2, phi[1] / 2, phi[2] / 2))
    s = math.sin(a / 2) / a
    return (math.cos(a / 2), phi[0] * s, phi[1] * s, phi[2] * s)


def log_vec(q):
    """Rotation vector of q, taking the short way (q and −q give the same result)."""
    w, x, y, z = q
    if w < 0:
        w, x, y, z = -w, -x, -y, -z
    s = math.sqrt(x * x + y * y + z * z)
    if s < 1e-12:
        return (2 * x, 2 * y, 2 * z)
    a = 2 * math.atan2(s, w)
    return (x * a / s, y * a / s, z * a / s)


def angle_between(qa, qb):
    """Geodesic angle between two attitudes, in [0, π] (sign ambiguity handled)."""
    d = abs(qa[0] * qb[0] + qa[1] * qb[1] + qa[2] * qb[2] + qa[3] * qb[3])
    return 2 * math.acos(min(1.0, d))


def rot_x(phi):
    c, s = math.cos(phi), math.sin(phi)
    return ((1.0, 0.0, 0.0), (0.0, c, -s), (0.0, s, c))


def edge_rot(theta):
    """Body → world rotation of the edge (hinge) model: rotX(π/4 + θ) (AERIS_TWIN.edgeR)."""
    return rot_x(math.pi / 4 + theta)


def edge_quat(theta):
    return axis_angle((1.0, 0.0, 0.0), math.pi / 4 + theta)


def skew(v):
    return ((0.0, -v[2], v[1]), (v[2], 0.0, -v[0]), (-v[1], v[0], 0.0))

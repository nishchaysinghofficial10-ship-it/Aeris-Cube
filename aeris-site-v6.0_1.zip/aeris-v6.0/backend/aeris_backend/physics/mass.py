"""Mass properties of the cube: base body, rigid components, point masses and wheels.

Reference point: the pivot vertex O (body-frame origin); body axes along the three cube
edges that meet at O. All inertia tensors are 3×3, symmetric, in body axes, in kg·m².

- The base (frame, wheels, electronics) has mass m, centre of mass r0 and inertia I_base about
  r0. By default I_base = k_J·m·a²·I (the browser engine's isotropic approximation) and
  r0 = (a/2, a/2, a/2) + δ·n̂ + Δr (comOffset along n̂ = N_EDGE in edge mode or E1 in corner mode,
  plus the 3-D comShift). `plant.base_inertia_kgm2` gives the full tensor instead and
  `plant.base_com_m` replaces the geometric centre.
- Components (`plant.components`) are rigid bodies with mass, COM and their own inertia tensor
  about their COM; attachments are point masses (legacy).
- Θ_O = Σ (I_c + m·S(r)) with S(r) = |r|²I − r rᵀ (parallel-axis theorem, off-diagonal terms kept).
  Θ_O includes the wheels as LOCKED rigid parts (their mass and full inertia).
- Θ̂ = Θ_O − Σ J_w,i a_i a_iᵀ removes each wheel's spin inertia about its own axis; the dynamics use
  it with RELATIVE wheel speeds (docs/PHYSICS.md §3), so no wheel momentum is counted twice.
"""
from __future__ import annotations

import math

import numpy as np

from ..constants import CH, D_EDGE, E1, N_EDGE


def steiner(m: float, r) -> np.ndarray:
    r = np.asarray(r, dtype=float)
    return m * (float(r @ r) * np.eye(3) - np.outer(r, r))


def check_tensor(I, label: str, *, allow_zero: bool = False, tol: float = 1e-12) -> list[str]:
    """Symmetry, positive (semi)definiteness and the triangle inequality of principal moments."""
    errs = []
    I = np.asarray(I, dtype=float)
    if I.shape != (3, 3) or not np.all(np.isfinite(I)):
        return [f"{label} must be a 3×3 matrix of finite numbers."]
    scale = max(1e-30, float(np.max(np.abs(I))))
    if np.max(np.abs(I - I.T)) > 1e-9 * scale:
        errs.append(f"{label} is not symmetric (largest asymmetry {np.max(np.abs(I - I.T)):.3g} kg·m²).")
        return errs
    ev = np.linalg.eigvalsh(I)
    if allow_zero:
        if ev[0] < -1e-12 * scale:
            errs.append(f"{label} is not positive semi-definite (smallest principal moment {ev[0]:.3g} kg·m²).")
    elif not ev[0] > tol * scale:
        errs.append(f"{label} is not positive definite (smallest principal moment {ev[0]:.3g} kg·m²).")
    if not errs and ev[0] + ev[1] < ev[2] * (1 - 1e-9):
        errs.append(f"{label} violates the triangle inequality of principal moments "
                    f"({ev[0]:.4g} + {ev[1]:.4g} < {ev[2]:.4g} kg·m²): no rigid body has this inertia.")
    return errs


def base_offset_direction(mode: str):
    return N_EDGE if mode == "edge" else E1


def wheel_axes(cfg) -> list[tuple]:
    from ..config.normalize import effective_wheels
    return [tuple(w["axis"]) for w in effective_wheels(cfg)]


def mass_properties(cfg: dict) -> dict:
    """Mass properties of the configured build (no plant-uncertainty scaling)."""
    p, a = cfg["params"], cfg["params"]["a"]
    m0 = p["m"]
    plant = cfg.get("plant") or {}
    centre = np.array(plant.get("base_com_m") or [a / 2, a / 2, a / 2], dtype=float)
    off = np.array(base_offset_direction(cfg["mode"])) * float(cfg.get("comOffset_m") or 0.0)
    shift = np.array(cfg.get("comShift_m") or [0, 0, 0], dtype=float)
    r0 = centre + off + shift
    if plant.get("base_inertia_kgm2") is not None:
        Ib = np.array(plant["base_inertia_kgm2"], dtype=float)
        Jc0 = None
    else:
        Jc0 = p["kJ"] * m0 * a * a
        Ib = Jc0 * np.eye(3)
    M = m0
    S = r0 * m0
    ThO = Ib + steiner(m0, r0)
    parts = [{"id": "base", "label": "Base cube", "kind": "base", "mass": m0, "pos": r0.tolist(),
              "ownInertia": Jc0 if Jc0 is not None else Ib.tolist()}]
    for c in plant.get("components") or []:
        mc, rcp = c["mass_kg"], np.array(c["com_m"], dtype=float)
        Ic = np.zeros((3, 3)) if c.get("inertia_kgm2") is None else np.array(c["inertia_kgm2"], dtype=float)
        M += mc
        S = S + rcp * mc
        ThO = ThO + Ic + steiner(mc, rcp)
        parts.append({"id": c["id"], "label": c.get("label", c["id"]), "kind": "component", "mass": mc,
                      "pos": rcp.tolist(), "ownInertia": Ic.tolist()})
    for at in cfg.get("attachments") or []:
        ma, ra = at["mass_kg"], np.array(at["pos_m"], dtype=float)
        M += ma
        S = S + ra * ma
        ThO = ThO + steiner(ma, ra)
        parts.append({"id": at["id"], "label": at.get("label", at["id"]), "kind": "point", "mass": ma,
                      "pos": ra.tolist(), "ownInertia": 0})
    rc = S / M
    ThC = ThO - steiner(M, rc)
    return _geometry(cfg, M, rc, r0, m0, Jc0, Ib, ThO, ThC, parts, a)


def _geometry(cfg, M, rc, r0, m0, Jc0, Ib, ThO, ThC, parts, a) -> dict:
    from ..config.normalize import effective_wheels
    wl = effective_wheels(cfg)
    axes = [np.array(w["axis"], dtype=float) / max(1e-300, float(np.linalg.norm(w["axis"]))) for w in wl]
    Jw = [w["Jw"] for w in wl]
    Wsum = sum(j * np.outer(ax, ax) for j, ax in zip(Jw, axes))
    out = {"M": float(M), "rc": rc.tolist(), "r0": r0.tolist(), "m0": m0, "Jc0": Jc0, "baseInertia": Ib.tolist(),
           "ThO": ThO.tolist(), "ThC": ThC.tolist(), "parts": parts, "baseCenter": [a / 2, a / 2, a / 2]}
    # edge: support edge along body x through O (browser convention)
    le = math.hypot(rc[1], rc[2])
    beta_e = math.atan2(float(rc @ np.array(N_EDGE)), float(rc @ np.array(D_EDGE)))
    ex = np.array([1.0, 0.0, 0.0])
    Th0e = float(ex @ ThO @ ex)
    Thhe = Th0e - sum(j * float(np.dot(ax, ex)) ** 2 for j, ax in zip(Jw, axes))
    out["edge"] = {"l": le, "beta": beta_e, "Th0": Th0e, "Thh": Thhe, "xc": float(rc[0])}
    lc = float(np.linalg.norm(rc))
    u = rc / lc if lc > 0 else np.array(CH)
    beta_c = math.acos(max(-1.0, min(1.0, float(u @ np.array(CH)))))
    Thh = ThO - Wsum
    ev = np.linalg.eigvalsh(Thh)
    ThPar = float(u @ ThO @ u)
    trace = float(np.trace(ThO))
    out["corner"] = {"l": lc, "u": u.tolist(), "beta": beta_c, "Thh": Thh.tolist(), "minEig": float(ev[0]),
                     "eig": ev.tolist(), "ThPar": ThPar, "ThPerp": (trace - ThPar) / 2,
                     "edgeClear": math.asin(max(-1.0, min(1.0, float(min(u))))) }
    return out


def plant_inertia(cfg: dict, mp: dict) -> np.ndarray:
    """True plant inertia about O: Θ_O × inertiaScale + the configured symmetric perturbation."""
    s = float(cfg["uncertainty"]["inertiaScale"])
    Th = np.array(mp["ThO"]) * s
    pert = cfg["uncertainty"].get("inertia_perturbation_kgm2")
    if pert is not None:
        Th = Th + np.array(pert, dtype=float)
    return Th


def nominal_bare(cfg: dict) -> dict:
    """The bare nominal cube the browser's controllers are designed for when they are not told
    about added masses: base mass and isotropic inertia at the geometric centre, no offsets."""
    p, a = cfg["params"], cfg["params"]["a"]
    Jc = p["kJ"] * p["m"] * a * a
    r = np.array([a / 2, a / 2, a / 2])
    ThO = Jc * np.eye(3) + steiner(p["m"], r)
    return {"M": p["m"], "rc": r.tolist(), "ThO": ThO.tolist(), "Jc": Jc}

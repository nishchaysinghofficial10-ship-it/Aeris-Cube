"""simulate(config) → validated configuration, trajectory samples, legacy metrics and outcome,
research metrics, event timeline, design and the executed method. The single entry point used
by the API, the job workers, sweeps and the tests."""
from __future__ import annotations

from ..config.validate import validate_config
from ..constants import CONTROLLER_NAMES, ESTIMATOR_NAMES, OUTCOMES
from ..metrics.legacy import assess, build_timeline
from ..metrics.research import research_metrics
from .engine import Engine


def _allocation_text(cfg, eng, edge):
    """How requested torque reached the wheels in this run (persisted with the record)."""
    c = cfg["controller"]
    if c["type"] == "none":
        return "none (motors off)"
    if edge:
        return "hinge torque to the wheel(s) with an axis component along the support edge (edge_alloc)"
    if c["type"] == "nlpd":
        return ("body torque → wheels by bounded least squares within each wheel's deliverable torque at its speed (bounded-ls)"
                if eng.ctx.alloc_method == "bounded-ls" else "body torque → wheels by least squares, then the driver limits clip each wheel (clip)")
    if c.get("structure") == "mimo-lqr":
        return "none needed: the MIMO gain maps the state to wheel torques; after a failure the gain is redesigned without that wheel" + ("" if c["reconfigureOnFailure"] else " (reconfiguration off: the failed wheel just gives no torque)")
    return "per body axis (browser law); after a failure, least squares on the tilt plane with yaw given up" + ("" if c["reconfigureOnFailure"] else " (reconfiguration off)")


def executed_reference(cfg, mp, design) -> dict:
    """The requested objective next to the plant's equilibrium (docs/EXPERIMENT_CONTRACT.md §2). The controller aims at
    the balance point of ITS model (nominal cube unless it knows the attachments); the research recovery criteria use the
    plant's balance point. A target that is not the plant's equilibrium cannot be held with zero wheel torque."""
    import math
    from ..constants import DEG, CH
    ref = cfg.get("reference") or {}
    out = {"requested": {"attitude": ref.get("attitude", "balance"), "heading": ref.get("heading"), "yaw_deg": ref.get("yaw_deg"),
                         "commands": [{"t_s": c["t_s"], "yaw_deg": c["angle_deg"]} for c in cfg["commands"]]},
           "controller_model": (design.get("model_mass") or {}).get("source")}
    if cfg["mode"] == "edge":
        b_true = mp["edge"]["beta"]
        b_model = design.get("betaRef", 0.0)
        out.update({"controller_target": {"kind": "balance line of the controller's model", "lean_from_geometric_deg": b_model / DEG},
                    "plant_equilibrium": {"kind": "centre of mass above the support edge", "theta_deg": -b_true / DEG, "lean_from_geometric_deg": b_true / DEG},
                    "target_offset_deg": abs(b_true - b_model) / DEG})
    else:
        u_true = mp["corner"]["u"]
        u_model = design.get("uRef") or list(CH)
        c = max(-1.0, min(1.0, sum(a * b for a, b in zip(u_true, u_model))))
        out.update({"controller_target": {"kind": "balance axis of the controller's model (body frame)", "axis_body": list(u_model)},
                    "plant_equilibrium": {"kind": "centre of mass above the pivot (body frame direction of the COM)", "axis_body": list(u_true)},
                    "target_offset_deg": math.degrees(math.acos(c))})
    out["note"] = ("The requested objective is the balance attitude" + ("" if cfg["mode"] == "edge" else
                   (" with a free heading" if ref.get("heading") == "free" else " at the commanded heading")) +
                   ". The controller steers toward the balance point of its own model; target_offset_deg is its distance from the plant's "
                   "equilibrium (non-zero when the model does not know the attachments; controllers with integral or adaptive action can remove it). "
                   "The research recovery criteria are evaluated against the plant's equilibrium.")
    return out


def simulate(raw_cfg, *, cancel_check=None, keep_full: bool = False, limits: dict | None = None) -> dict:
    v = validate_config(raw_cfg, limits)
    cfg = v.config
    if not v.ok:
        return {"ok": False, "config": cfg, "errors": v.errors, "warnings": v.warnings,
                "outcome": {"code": "invalid", "label": OUTCOMES["invalid"]["label"], "reason": " ".join(e["message"] for e in v.errors), "notes": []},
                "termination": {"reason": "invalid_config", "t": None, "detail": "the configuration failed validation"}}
    eng = Engine(cfg, v.mp, cancel_check=cancel_check)
    res = eng.run()
    base = {"config": cfg, "mp": v.mp, "design": eng.design, "warnings": v.warnings, "workload": v.workload}
    if res.get("cancelled"):
        return dict(base, ok=False, cancelled=True, errors=[{"path": "", "message": "cancelled", "severity": "error", "kind": "cancelled"}],
                    outcome={"code": "invalid", "label": "Cancelled", "reason": "The run was cancelled before it finished.", "notes": []},
                    termination={"reason": "cancelled", "t": None, "detail": "cancelled on request"})
    if res.get("numericalFailure"):
        return dict(base, ok=False, errors=[{"path": "solver", "message": res["numericalFailure"], "severity": "error", "kind": "numerical"}],
                    outcome={"code": "invalid", "label": OUTCOMES["invalid"]["label"], "reason": "Numerical failure: " + res["numericalFailure"], "notes": []},
                    termination=res["termination"], samples=None)
    full = res["full"]
    W = eng.wheels
    edge = cfg["mode"] == "edge"
    names = res["samples"]["cols"]
    wheel_names = ["x", "y", "z"] if W.standard else W.ids
    drive = eng.ctx.drive
    active = [drive] if edge else full.get("activeIdx", list(range(W.n)))
    ctx = {"mode": cfg["mode"], "dt": eng.dt, "wmax": W.wheels[drive if edge else 0].wmax, "fellAt": res["fellAt"], "fallCause": res["fallCause"],
           "contactAt": res["contactAt"], "window_s": cfg["duration_s"], "failedWheels": res["failedWheels"], "hasYawCmd": len(cfg["commands"]) > 0,
           "wheel_names": wheel_names, "active": active}
    if edge:
        # the browser assesses only the driven wheel in edge mode
        full_a = dict(full, om=[full["om"][drive]])
        ctx_a = dict(ctx, wheel_names=[wheel_names[drive]], active=[0])
        A = assess(full_a, ctx_a)
    else:
        A = assess(full, ctx)
    rctx = {"mode": cfg["mode"], "dt": eng.dt, "recovery": cfg["recovery"], "window_s": cfg["duration_s"], "fellAt": res["fellAt"],
            "yaw_given_up_at": res.get("yaw_given_up_at"), "wheel_names": wheel_names, "wmax_list": [w.wmax for w in W.wheels],
            "termination": eng.termination, "axes": [list(w.axis) for w in W.wheels], "target": _recovery_target(cfg)}
    rec = research_metrics(full, rctx)
    reconfig_detail = None
    if hasattr(eng.controller, "redesigns") and eng.controller.redesigns:
        r0 = eng.controller.redesigns[0]
        reconfig_detail = ("MIMO LQR redesigned for wheels " + ", ".join(r0["wheels"]) + f" (controllable rank {r0.get('controllable_rank')} of {r0.get('state_dim')}); yaw is part of the design only if still controllable."
                           if r0["ok"] else "MIMO redesign without the failed wheel failed: " + r0.get("error", "") + "; the original gain is kept and the failed wheel gives no torque.")
    tl = build_timeline({"mode": cfg["mode"], "n": full["nSteps"], "tAt": lambda k: k * eng.dt, "satW": full["satW"], "om": full["om"],
                         "wmax": [w.wmax for w in W.wheels], "estErr": full.get("estErr") if full.get("estErr") is not None else full.get("estAtt"),
                         "cfg": cfg, "metrics": A["metrics"], "fellAt": res["fellAt"], "fallCause": res["fallCause"], "contactAt": res["contactAt"],
                         "windowEnd": cfg["duration_s"], "recordedEnd": full["nSteps"] * eng.dt, "resolution_s": eng.dt, "wheel_names": wheel_names,
                         "drive": drive, "yaw_objective_changes": eng.yaw_objective_changes, "research_recovery": rec["recovery"],
                         "termination": eng.termination, "post_fall_s": cfg["termination"]["post_fall_s"], "reconfig_detail": reconfig_detail,
                         "estStale": full.get("estStale"), "stale_after_s": getattr(eng, "stale_after_s", None),
                         "est_init_t": (res.get("estimator_stats") or {}).get("initialised_at_s")})
    if eng.termination and eng.termination["reason"] in ("safety_limit", "recovery", "loss_of_support"):
        A["outcome"]["notes"].append(f"Run ended early ({eng.termination['reason'].replace('_', ' ')}) at t = {eng.termination['t']:.3f} s: {eng.termination['detail']}. The outcome rules were applied to the recorded window.")
    counts = {}
    for e in tl["events"]:
        counts[e["type"]] = counts.get(e["type"], 0) + 1
    rec["event_counts"] = counts
    ctrl = eng.controller
    executed = {
        "controller": dict(ctrl.summary(), name=CONTROLLER_NAMES.get(cfg["controller"]["type"], cfg["controller"]["type"]),
                           model=eng.design.get("model"), knowsAttachments=cfg["controller"]["knowsAttachments"],
                           reconfigureOnFailure=cfg["controller"]["reconfigureOnFailure"]),
        "estimator": {"type": cfg["estimator"]["type"], "name": ESTIMATOR_NAMES.get(cfg["estimator"]["type"]),
                      "truth_access": cfg["estimator"]["type"] == "ideal", "stats": res.get("estimator_stats")},
        "allocation": {"method": _allocation_text(cfg, eng, edge), "wheels": W.ids},
        "reference": executed_reference(cfg, v.mp, eng.design),
        "initial_state": _initial_summary(cfg, eng),
        "rates": {"integration_hz": eng.f_int, "control_hz": cfg["params"]["fs"], "sensor_hz": (cfg["sensor"]["rate_hz"] or cfg["params"]["fs"]),
                  "record_hz": eng.record_hz_realized, "record_hz_requested": cfg["record_hz"], "record_stride_steps": eng.rec_every},
        "solver": {"method": "rk4", "step_s": eng.dt, "zero_order_hold": True, "electrical_limit": W.electrical},
        "schedule": eng.sched.executed(), "impulses_applied": eng.impulses_applied,
        "steps": full["nSteps"], "simulated_s": full["nSteps"] * eng.dt,
    }
    out = dict(base, ok=True, errors=[], samples=res["samples"], metrics=A["metrics"], outcome=A["outcome"], timeline=tl,
               research=rec, termination=eng.termination, executed=executed, fellAt=res["fellAt"], contactAt=res["contactAt"],
               fallCause=res["fallCause"], failedWheels=res["failedWheels"], wheels=W.summary())
    if keep_full:
        out["full"] = full
    return out


def _recovery_target(cfg):
    """The research recovery target in words, with the configured objective (docs/EXPERIMENT_CONTRACT.md §3)."""
    if cfg["mode"] == "edge":
        return "COM above the support edge (tilt about the hinge)"
    ref = cfg.get("reference") or {}
    if cfg["recovery"]["yaw_objective"] == "free":
        why = " (the controller holds no heading: reference.heading free)" if ref.get("heading") == "free" else " (recovery.yaw_objective free; the controller still holds its heading)"
        return "balance attitude (COM above the pivot), any heading" + why
    off = ref.get("yaw_deg") or 0.0
    return ("balance attitude (COM above the pivot) at the commanded heading: the initial heading"
            + (f" + {off:g}°" if off else "") + (" then the yaw commands" if cfg["commands"] else ""))


def _initial_summary(cfg, eng):
    """The initial state actually simulated, whichever inputs described it."""
    from ..constants import DEG
    from .setup import initial_state
    ini = initial_state(cfg, eng.mp)
    src = "explicit attitude quaternion" if cfg["initial"].get("attitude_q") is not None else f"legacy tilt ({cfg['initial']['reference']} reference)"
    rsrc = "explicit body-rate vector" if cfg["initial"].get("body_rate_dps") is not None else "legacy rate"
    if cfg["mode"] == "edge":
        return {"attitude_from": src, "rate_from": rsrc, "theta_deg": ini["theta"] / DEG, "thetadot_dps": ini["thetadot"] / DEG,
                "lean_deg": ini["e"] / DEG, "wheel_speeds_rpm": cfg["initial"].get("wheel_speeds_rpm")}
    return {"attitude_from": src, "rate_from": rsrc, "q": list(ini["q"]), "body_rate_dps": [x / DEG for x in ini["w"]],
            "lean_deg": ini["e"] / DEG, "wheel_speeds_rpm": cfg["initial"].get("wheel_speeds_rpm"),
            "frames": "q maps body to world (scalar first, Hamilton); body rate in body axes; world z up"}

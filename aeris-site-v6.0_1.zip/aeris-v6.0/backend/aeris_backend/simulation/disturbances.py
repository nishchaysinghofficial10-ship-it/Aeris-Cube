"""Disturbance and wheel-event schedule.

Continuous loads (evaluated at every RK4 stage time, so a load that starts inside a step is
partly seen by that step, exactly as in the browser engine):
  force   magnitude_N along `direction` at `point_m` (body frame), frame world|body, for
          [t_start_s, t_start_s + duration_s)
  torque  magnitude_Nm about `direction`, frame world|body, same window
  bias    constant torque magnitude_Nm from t_start_s for duration_s (None = to the end)
Impulses (instantaneous momentum jumps at the first integration step with t ≥ t_s):
  impulse        angular impulse magnitude_Nms [N·m·s] about `direction`
  force_impulse  linear impulse impulse_Ns [N·s] along `direction` at `point_m`; angular
                 impulse r × J
  The body absorbs the jump: Δω = Θ̂⁻¹ J_body, and each wheel keeps its absolute spin
  (no impulsive torque passes through the bearings), so ΔΩ_i = −a_i·Δω.
Wheel events (take effect at the first integration step at or after t_s):
  wheel_failure       no motor torque (friction still acts); optional duration_s → clearance
  wheel_degradation   health factor × `health` (0–1) for duration_s (None = permanent)
  wheel_torque_limit  torque capped at limit_Nm
  wheel_speed_limit   speed cut-off lowered to limit_rpm
"""
from __future__ import annotations

import math

from ..constants import RPM
from ..physics.quaternion import cross, mtv, mv, unit


class Schedule:
    def __init__(self, cfg: dict, wheels):
        self.wheels = wheels
        n = wheels.n
        self.failed = [False] * n
        self.ever_failed = [False] * n
        self.loads = []
        self.impulses = []
        for L in cfg["disturbances"]:
            t = L["type"]
            if t in ("force", "torque", "bias"):
                d = dict(L)
                d["_dir"] = unit(tuple(L["direction"]))
                d["_t0"] = L["t_start_s"]
                d["_t1"] = math.inf if (t == "bias" and L.get("duration_s") is None) else L["t_start_s"] + L["duration_s"]
                self.loads.append(d)
            elif t in ("impulse", "force_impulse"):
                d = dict(L)
                d["_dir"] = unit(tuple(L["direction"]))
                d["_done"] = False
                self.impulses.append(d)
        self.impulses.sort(key=lambda x: x["t_s"])
        self.has_continuous = bool(self.loads)
        self.events = []
        for e in cfg["events"]:
            i = wheels.index(e["wheel"])
            if i < 0:
                continue
            dur = e.get("duration_s")
            self.events.append({"ev": e, "i": i, "t0": e["t_s"], "t1": math.inf if dur is None else e["t_s"] + dur,
                                "on": False, "done": False})
        self.log = []   # the schedule as executed (applied times)

    # ---- wheel events ----
    def apply_events(self, t: float) -> list:
        """Switch wheel events on/off at time t; returns the log entries created now (empty when nothing changed)."""
        n0 = len(self.log)
        for s in self.events:
            if s["done"]:
                continue
            e, i = s["ev"], s["i"]
            w = self.wheels.wheels[i]
            if not s["on"] and t >= s["t0"]:
                s["on"] = True
                self._set(e, w, i, True)
                self.log.append({"t": t, "type": e["type"], "wheel": e["wheel"], "id": e["id"], "state": "on"})
            if s["on"] and t >= s["t1"]:
                s["on"] = False
                s["done"] = True
                self._set(e, w, i, False)
                self.log.append({"t": t, "type": "wheel_clearance" if e["type"] == "wheel_failure" else e["type"], "wheel": e["wheel"], "id": e["id"], "state": "off"})
        return self.log[n0:]

    def _set(self, e, w, i, on):
        t = e["type"]
        if t == "wheel_failure":
            self.failed[i] = on
            w.failed = on
            if on:
                self.ever_failed[i] = True
        elif t == "wheel_degradation":
            w.deg_health = e["health"] if on else None
        elif t == "wheel_torque_limit":
            w.torque_cap = e["limit_Nm"] if on else None
        elif t == "wheel_speed_limit":
            w.speed_cap = e["limit_rpm"] * RPM if on else None

    # ---- continuous loads ----
    def torque_body(self, t: float, R) -> tuple:
        sx = sy = sz = 0.0
        for L in self.loads:
            if t >= L["_t0"] and t < L["_t1"]:
                d = L["_dir"]
                if L["type"] == "force":
                    F = (d[0] * L["magnitude_N"], d[1] * L["magnitude_N"], d[2] * L["magnitude_N"])
                    if L["frame"] == "world":
                        F = mtv(R, F)
                    tq = cross(tuple(L["point_m"]), F)
                else:
                    tq = (d[0] * L["magnitude_Nm"], d[1] * L["magnitude_Nm"], d[2] * L["magnitude_Nm"])
                    if L["frame"] == "world":
                        tq = mtv(R, tq)
                sx += tq[0]
                sy += tq[1]
                sz += tq[2]
        return (sx, sy, sz)

    def force_world(self, t: float, R) -> tuple:
        s = [0.0, 0.0, 0.0]
        for L in self.loads:
            if L["type"] == "force" and t >= L["_t0"] and t < L["_t1"]:
                d = L["_dir"]
                F = (d[0] * L["magnitude_N"], d[1] * L["magnitude_N"], d[2] * L["magnitude_N"])
                if L["frame"] == "body":
                    F = mv(R, F)
                s = [s[j] + F[j] for j in range(3)]
        return tuple(s)

    # ---- impulses ----
    def impulses_due(self, t: float) -> list:
        out = []
        for x in self.impulses:
            if not x["_done"] and t >= x["t_s"] - 1e-12:
                x["_done"] = True
                out.append(x)
        return out

    def impulse_body(self, x, R) -> tuple:
        d = x["_dir"]
        if x["type"] == "impulse":
            J = (d[0] * x["magnitude_Nms"], d[1] * x["magnitude_Nms"], d[2] * x["magnitude_Nms"])
            return mtv(R, J) if x["frame"] == "world" else J
        P = (d[0] * x["impulse_Ns"], d[1] * x["impulse_Ns"], d[2] * x["impulse_Ns"])
        if x["frame"] == "world":
            P = mtv(R, P)
        return cross(tuple(x["point_m"]), P)

    def executed(self) -> dict:
        """The disturbance and event schedule as it was actually applied (persisted with the run)."""
        return {"wheel_events": self.log,
                "loads": [{k: v for k, v in L.items() if not k.startswith("_")} | {"t_end_s": (None if L["_t1"] == math.inf else L["_t1"])} for L in self.loads],
                "impulses": [{k: v for k, v in x.items() if not k.startswith("_")} | {"applied": x["_done"]} for x in self.impulses]}

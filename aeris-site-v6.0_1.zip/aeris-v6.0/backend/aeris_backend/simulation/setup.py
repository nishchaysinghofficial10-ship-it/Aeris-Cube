"""Run set-up: mass properties, controller design for a configuration, initial state, the
controller context (allocation, references) and the disturbance/event schedules."""
from __future__ import annotations

import math

import numpy as np

from ..actuators import WheelSet, allocate_bounded, least_squares_plane
from ..constants import CH, DEG, E1, E2, QEQ
from ..control.design import DesignError, design_mimo_cached, design_tilt, design_yaw
from ..physics.mass import mass_properties, nominal_bare, plant_inertia
from ..physics.quaternion import (axis_angle, cross, from_to, mtv, norm, proj_on, qmul, qnorm, rot, unit,
                                  up_in_body)


def lqr_weights(cfg):
    from ..constants import LQR_DEFAULTS
    return cfg["controller"].get("lqr") or dict(LQR_DEFAULTS)


def pid_settings(cfg):
    from ..constants import PID_DEFAULTS
    return cfg["controller"].get("pid") or dict(PID_DEFAULTS)


def adaptive_settings(cfg):
    from ..constants import ADAPTIVE_DEFAULTS
    return cfg["controller"].get("adaptive") or dict(ADAPTIVE_DEFAULTS)


def nonlinear_settings(cfg):
    from ..constants import NONLINEAR_DEFAULTS
    return dict(NONLINEAR_DEFAULTS, **(cfg["controller"].get("nonlinear") or {}))


def design_for_config(cfg: dict, mp: dict, wheels: WheelSet) -> dict:
    """Controller design (AERIS_TWIN.designForConfig, extended). Raises DesignError."""
    p = cfg["params"]
    knows = bool(cfg["controller"]["knowsAttachments"])
    s = cfg["uncertainty"]["inertiaScale"]
    bare = nominal_bare(cfg)
    lw, pw, aw = lqr_weights(cfg), pid_settings(cfg), adaptive_settings(cfg)
    ctrl = cfg["controller"]["type"]
    structure = cfg["controller"].get("structure", "decoupled")
    drive = edge_drive_index(wheels)
    Jw = wheels.wheels[drive].Jw if cfg["mode"] == "edge" else p["Jw"]
    taumax_nom = wheels.wheels[drive].taumax_nominal if cfg["mode"] == "edge" else wheels.wheels[0].taumax_nominal
    ThO_true = plant_inertia(cfg, mp)
    act = {"taumax": wheels.wheels[0].taumax, "taumaxNominal": wheels.wheels[0].taumax_nominal, "kt": wheels.wheels[0].kt,
           "ke": wheels.wheels[0].ke, "R": wheels.wheels[0].R, "Vs": wheels.wheels[0].Vs, "wmax": wheels.wheels[0].wmax,
           "wnl": wheels.wheels[0].wnl, "cv": wheels.wheels[0].cv, "cc": wheels.wheels[0].cc, "hmax": wheels.wheels[0].Jw * wheels.wheels[0].wmax,
           "per_wheel": wheels.summary()}
    out = {"mode": cfg["mode"], "model": "actual" if knows else "nominal", "actuator": act, "structure": structure,
           "controller": ctrl}
    model_M = mp["M"] if knows else bare["M"]
    model_rc = mp["rc"] if knows else bare["rc"]
    model_ThO = np.array(mp["ThO"]) if knows else np.array(bare["ThO"])
    Wsum = sum(w.Jw * np.outer(w.axis, w.axis) for w in wheels.wheels)
    out["model_mass"] = {"M": model_M, "rc": list(model_rc), "ThO": model_ThO.tolist(), "Thh": (model_ThO - Wsum).tolist(),
                         "source": "the run's mass properties (controller knows the attachments)" if knows else "the bare nominal cube (k_J·m·a², COM at the centre)"}
    if cfg["mode"] == "edge":
        l_true = mp["edge"]["l"]
        Th0 = mp["edge"]["Th0"] if knows else bare_edge_Th0(cfg)
        mgl = mp["M"] * p["g"] * l_true if knows else p["m"] * p["g"] * math.sqrt(2) / 2 * p["a"]
        tilt = design_tilt(Th0 - Jw, Th0, mgl, Jw, taumax_nom, lw, pw, aw["gamma"])
        ex = np.array([1.0, 0.0, 0.0])
        Th_plant = float(ex @ ThO_true @ ex)
        plantThh = Th_plant - sum(w.Jw * w.axis[0] ** 2 for w in wheels.wheels)
        if not plantThh > 0:
            raise DesignError("plant inertia about the edge is not positive after the inertia scale")
        out.update({"tilt": tilt, "betaRef": mp["edge"]["beta"] if knows else 0.0, "edge_model_Thh": Th0 - Jw, "edge_model_mgl": mgl,
                    "plant": {"Th0": Th_plant, "Thh": plantThh, "mgl": mp["M"] * p["g"] * l_true, "beta": mp["edge"]["beta"],
                              "lambda": math.sqrt(mp["M"] * p["g"] * l_true / plantThh)}})
        return out
    u = mp["corner"]["u"] if knows else list(CH)
    Thp = mp["corner"]["ThPerp"] if knows else bare_corner_Th0(cfg)
    mglc = mp["M"] * p["g"] * mp["corner"]["l"] if knows else p["m"] * p["g"] * math.sqrt(3) / 2 * p["a"]
    Thpar = mp["corner"]["ThPar"] if knows else p["kJ"] * p["m"] * p["a"] ** 2
    if ctrl in ("pid", "lqr", "adp") and structure == "decoupled":
        out["tilt"] = design_tilt(Thp - Jw, Thp, mglc, Jw, taumax_nom, lw, pw, aw["gamma"])
        out["yaw"] = design_yaw(Thpar - Jw, taumax_nom, lw, pw)
    if structure == "mimo-lqr" and ctrl == "lqr":
        out["mimo"] = design_mimo_cached(model_ThO, model_M, model_rc, p["g"], [list(w.axis) for w in wheels.wheels],
                                         [w.Jw for w in wheels.wheels], [w.taumax_nominal for w in wheels.wheels], lw)
    out["uRef"] = list(u)
    plantThh = ThO_true - Wsum
    ev = np.linalg.eigvalsh(plantThh)
    if not ev[0] > 0:
        raise DesignError("plant inertia about the pivot is not positive definite after the inertia scale")
    lam = math.sqrt(mp["M"] * p["g"] * mp["corner"]["l"] / max(1e-12, ev[0]))
    out["plant"] = {"Th0": ThO_true.tolist(), "Thh": plantThh.tolist(), "Thhi": np.linalg.inv(plantThh).tolist(),
                    "M": mp["M"], "rc": mp["rc"], "lambda": lam}
    return out


def bare_edge_Th0(cfg):
    p = cfg["params"]
    return p["kJ"] * p["m"] * p["a"] ** 2 + p["m"] * (math.sqrt(2) / 2 * p["a"]) ** 2


def bare_corner_Th0(cfg):
    p = cfg["params"]
    return p["kJ"] * p["m"] * p["a"] ** 2 + p["m"] * (math.sqrt(3) / 2 * p["a"]) ** 2


def edge_drive_index(wheels: WheelSet) -> int:
    """Edge mode drives the wheel whose axis is (most nearly) along the hinge (body x)."""
    best, bi = -1.0, 0
    for i, w in enumerate(wheels.wheels):
        if abs(w.axis[0]) > best:
            best, bi = abs(w.axis[0]), i
    return bi


def initial_state(cfg: dict, mp: dict) -> dict:
    """AERIS_TWIN.initialState: 'geometric' tilt from the diagonal-vertical attitude, 'balance'
    tilt from the attitude with the centre of mass above the pivot."""
    ini = cfg["initial"]
    q_ex, w_ex = ini.get("attitude_q"), ini.get("body_rate_dps")
    if cfg["mode"] == "edge":
        if q_ex is not None:          # revision 1.2: rotation about the hinge from the edge reference attitude
            from ..physics.quaternion import edge_quat, qconj
            qr = qmul(qconj(edge_quat(0.0)), tuple(q_ex))
            th0 = 2 * math.atan2(qr[1], qr[0])
            th0 = (th0 + math.pi) % (2 * math.pi) - math.pi
        else:
            tilt = ini["tilt_deg"] * DEG
            th0 = tilt - mp["edge"]["beta"] if ini["reference"] == "balance" else tilt
        rate = w_ex[0] * DEG if w_ex is not None else ini["rate_dps"] * DEG
        return {"theta": th0, "thetadot": rate, "e": th0 + mp["edge"]["beta"], "clear": math.pi / 4 - abs(th0)}
    rcu = tuple(mp["corner"]["u"])
    if q_ex is not None:
        q = qnorm(tuple(q_ex))
        w = tuple(x * DEG for x in w_ex) if w_ex is not None else (0.0, 0.0, 0.0)
        uB = mtv(rot(q), (0.0, 0.0, 1.0))
        return {"q": q, "w": w, "tiltAxis": None,
                "e": math.acos(max(-1.0, min(1.0, uB[0] * rcu[0] + uB[1] * rcu[1] + uB[2] * rcu[2]))),
                "clear": math.asin(max(-1.0, min(1.0, min(uB))))}
    tilt, rate = ini["tilt_deg"] * DEG, ini["rate_dps"] * DEG if ini["rate_dps"] is not None else 0.0
    az = ini["azimuth_deg"] * DEG
    rcu = tuple(mp["corner"]["u"])
    tax = tuple(math.cos(az) * E1[i] + math.sin(az) * E2[i] for i in range(3))
    base = QEQ
    if ini["reference"] == "balance":
        base = from_to(rcu, (0.0, 0.0, 1.0))
        tax = unit(proj_on(tax, rcu))
        if norm(tax) < 1e-9:
            tax = unit(cross(rcu, (1.0, 0.0, 0.0)))
    q = qnorm(qmul(base, axis_angle(tax, tilt))) if tilt else tuple(base)
    uB = mtv(rot(q), (0.0, 0.0, 1.0))
    w = tuple(x * DEG for x in w_ex) if w_ex is not None else (tax[0] * rate, tax[1] * rate, tax[2] * rate)
    return {"q": q, "w": w, "tiltAxis": tax,
            "e": math.acos(max(-1.0, min(1.0, uB[0] * rcu[0] + uB[1] * rcu[1] + uB[2] * rcu[2]))),
            "clear": math.asin(max(-1.0, min(1.0, min(uB))))}


class RunContext:
    """What a controller may use besides the Estimate: its design, settings, reference
    generator and the allocation onto the wheels. No plant state."""

    def __init__(self, cfg, mp, design, wheels: WheelSet, dt_ctrl: float):
        self.cfg = cfg
        self.mode = cfg["mode"]
        self.design = design
        self.n = wheels.n
        self.ids = wheels.ids
        self.axes = [w.axis for w in wheels.wheels]
        self.Jws = [w.Jw for w in wheels.wheels]
        self.dt = dt_ctrl
        self.adaptive = adaptive_settings(cfg)
        self.pid_cfg = pid_settings(cfg)
        self.nonlinear = nonlinear_settings(cfg)
        self.model = design["model_mass"]
        self.taumax_act = design["actuator"]["taumax"]
        self.reconfigure = bool(cfg["controller"]["reconfigureOnFailure"])
        self.drive = edge_drive_index(wheels)
        self.wheels = wheels
        self.alloc_method = (cfg["controller"].get("allocation") or {}).get("method", "clip")
        if self.mode == "corner":
            self.uRef = tuple(design["uRef"])
            self.qRef = from_to(self.uRef, (0.0, 0.0, 1.0))
        else:
            self.uRef = None
            self.qRef = None
        self.psi0 = None
        self.cmds = sorted([c for c in cfg["commands"] if c["type"] == "yaw_step"], key=lambda c: c["t_s"])
        self.yaw_given_up_at = None
        ref = cfg.get("reference") or {}
        # revision 1.2 reference block: heading objective and fixed heading offset (corner mode)
        self.heading_free = self.mode == "corner" and ref.get("heading") == "free"
        self.yaw_offset = (ref.get("yaw_deg") or 0.0) * DEG if self.mode == "corner" else 0.0

    def psi_ref(self, t):
        """Commanded heading: the initial heading plus the fixed offset, replaced by each yaw command from its time on."""
        return (self.psi0 if self.psi0 is not None else 0.0) + self.cmd_angle(t)

    def cmd_angle(self, t):
        a = self.yaw_offset
        for c in self.cmds:
            if t >= c["t_s"]:
                a = c["angle_deg"] * DEG
        return a

    # ---- allocation ----
    def edge_alloc(self, tau_e: float) -> list:
        """Scalar hinge torque → wheels with a component along the hinge (minimum norm)."""
        out = [0.0] * self.n
        if self.wheels.standard or self.n == 1:
            out[self.drive] = tau_e
            return out
        s = sum(ax[0] ** 2 for ax in self.axes)
        for i, ax in enumerate(self.axes):
            out[i] = tau_e * ax[0] / s if s > 0 else 0.0
        return out

    def corner_alloc_legacy(self, TpP, Tc, failed, fell):
        """AERIS_TWIN.simCorner allocation: body axes = wheel axes; after a failure with
        reconfiguration, least squares on the tilt plane with the healthy wheels (yaw given up)."""
        any_fail = any(failed)
        if any_fail and self.reconfigure and not fell:
            idx = [k for k in range(3) if not failed[k]]
            T = [0.0, 0.0, 0.0]
            if idx:
                cols = []
                for k in idx:
                    e = [0.0, 0.0, 0.0]
                    e[k] = 1.0
                    cols.append(tuple(e))
                sol = least_squares_plane(cols, TpP, self.uRef)
                for k, v in zip(idx, sol):
                    T[k] = v
            return T, True
        u = self.uRef
        return [TpP[k] + u[k] * Tc for k in range(3)], False

    def body_alloc(self, body, failed, ww):
        """Body wheel-torque vector u → per-wheel torques for general wheel layouts.
        Healthy wheels only; when they cannot span 3-D and reconfiguration is on, the request is
        fitted on the tilt plane (yaw given up); 'bounded-ls' respects each wheel's deliverable
        torque at its current speed (bounded least squares) instead of clipping afterwards."""
        idx = [k for k in range(self.n) if not failed[k]]
        T = [0.0] * self.n
        if not idx:
            return T, False
        A = np.array([self.axes[k] for k in idx]).T
        given_up = False
        target = np.array(body, dtype=float)
        weights = None
        if np.linalg.matrix_rank(A, tol=1e-9) < 3 and self.reconfigure and self.mode == "corner":
            P = np.eye(3) - np.outer(self.uRef, self.uRef)
            A = P @ A
            target = P @ target
            given_up = True
        if self.alloc_method == "bounded-ls":
            lo, hi = zip(*[self.wheels.wheels[k].bounds(ww[k]) for k in idx])
            sol = allocate_bounded(A, target, lo, hi, weights)
        else:
            sol = np.linalg.lstsq(A, target, rcond=None)[0]
        for k, v in zip(idx, sol):
            T[k] = float(v)
        return T, given_up

    def mimo_design(self, keep):
        p = self.cfg["params"]
        w = [self.wheels.wheels[i] for i in keep]
        from .setup import lqr_weights as _lw
        return design_mimo_cached(np.array(self.model["ThO"]), self.model["M"], self.model["rc"], p["g"],
                                  [list(x.axis) for x in w], [x.Jw for x in w], [x.taumax_nominal for x in w], _lw(self.cfg))


def up_body(q):
    return up_in_body(q)

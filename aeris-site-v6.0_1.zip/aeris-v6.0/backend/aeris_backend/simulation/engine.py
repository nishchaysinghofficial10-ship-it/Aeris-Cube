"""The run engine: one fixed-step RK4 loop per balance mode, a zero-order-hold controller at the
control rate, sensors at the sensor rate, recording at the recording rate (recording only reads
the state, so it cannot change the trajectory).

Time grid: the integration step Δt = 1/solver.integration_hz (default the control rate f_s).
The control rate must be an integer fraction of the integration rate; so must the IMU rate.
Wheel events take effect at the first integration step at or after their time; impulses are
applied as momentum jumps at the start of that step (docs/PHYSICS.md §6). With the default
settings the loops reproduce the browser engine (AERIS_TWIN.simEdge / simCorner) operation by
operation, which tests/test_parity.py checks against fixtures generated with the browser code.
"""
from __future__ import annotations

import math
from array import array

import numpy as np

from ..actuators import WheelSet
from ..constants import ASSESS, CH, DEG, RPM
from ..control.controllers import YawTracker, make_controller
from ..estimation import EPS_T, ComplementaryAttitude, EdgeLegacyEstimator, Estimate, Mekf, default_stale_after_s
from ..physics.quaternion import (angle_between, axis_angle, cross, dot, edge_quat, edge_rot, from_to, mtv, mv,
                                  qconj, qlen, qmul, qnorm, rot, up_in_body)
from ..rng import Rng
from ..sensors import EdgeImuLegacy, Imu3D
from ..metrics.research import RecoveryMonitor
from .disturbances import Schedule
from .setup import RunContext, design_for_config, initial_state

LEGACY_EDGE_ESTIMATORS = ("cf", "kf", "accel", "gyro")


def _round6(x):
    return float("%.6g" % x) if math.isfinite(x) else x


def _ident(x):
    return x


r6 = _round6


class Cancelled(Exception):
    pass


class Engine:
    def __init__(self, cfg: dict, mp: dict, cancel_check=None, precise: bool = False):
        self.precise = precise   # tests: record full-precision samples instead of 6 significant digits
        self.cfg = cfg
        self.mp = mp
        p = cfg["params"]
        self.fs = p["fs"]
        f_int = cfg["solver"].get("integration_hz") or p["fs"]
        self.f_int = f_int
        self.dt = 1.0 / f_int
        self.ctrl_every = max(1, int(round(f_int / p["fs"])))
        self.dt_ctrl = self.ctrl_every * self.dt
        rate = cfg["sensor"].get("rate_hz")
        self.sens_every = self.ctrl_every if rate is None else max(1, int(round(f_int / rate)))
        self.n = int(round(cfg["duration_s"] * f_int))
        # recording schedule (docs/RECORDING.md): every rec_every-th integration step. Validation only accepts
        # recording rates that divide the integration rate, so the realized rate equals the requested one; the
        # schedule actually used is saved with the samples either way (never a silently rounded label).
        self.rec_every = max(1, int(round(f_int / cfg["record_hz"])))
        self.record_hz_realized = f_int / self.rec_every
        self.wheels = WheelSet(cfg)
        self.design = design_for_config(cfg, mp, self.wheels)
        self.ctx = RunContext(cfg, mp, self.design, self.wheels, self.dt_ctrl)
        self.controller = make_controller(self.ctx)
        self.sched = Schedule(cfg, self.wheels)
        self.cancel_check = cancel_check
        self.est_kind = cfg["estimator"]["type"]
        self.rng = Rng(cfg["seed"])
        self.term = cfg["termination"]
        self.E = 0.0
        self.effort = 0.0
        self.fellAt = None
        self.fallCause = None
        self.contactAt = None
        self.termination = None
        self.yaw_objective_changes = []
        self.lag = self.wheels.lag_factor(self.dt)
        self.impulses_applied = []
        self.monitor = RecoveryMonitor(cfg["recovery"], self.dt, cfg["mode"] == "edge")

    # ------------------------------------------------------------------ helpers
    def _check_cancel(self, k):
        if self.cancel_check is not None and (k & 1023) == 0 and self.cancel_check():
            raise Cancelled()

    def _limits(self, T_des, ww, failed):
        """Driver limits on the allocated commands (AERIS_TWIN.tauAvail) and saturation flags."""
        n = self.wheels.n
        T = [0.0] * n
        satW = [0] * n
        for i in range(n):
            w = self.wheels.wheels[i]
            if failed[i]:
                T[i] = 0.0
                if T_des[i] != 0:
                    satW[i] = 1
            else:
                T[i] = w.avail(T_des[i], ww[i])
                if abs(T[i] - T_des[i]) > 1e-9:
                    satW[i] = 1
        return T, satW

    def _apply_lag(self, T):
        if self.lag < 1:
            for i, w in enumerate(self.wheels.wheels):
                w.lag_state += (T[i] - w.lag_state) * self.lag
                T[i] = w.lag_state
        return T

    def _continuous_limit(self, T, ww, failed):
        if self.wheels.electrical == "continuous":
            return [0.0 if failed[i] else self.wheels.wheels[i].avail(T[i], ww[i]) for i in range(len(T))]
        return T

    # ------------------------------------------------------------------ run
    def run(self) -> dict:
        try:
            if self.cfg["mode"] == "edge":
                return self._run_edge()
            return self._run_corner()
        except Cancelled:
            return {"cancelled": True}


# =====================================================================================
# EDGE (hinge about body x)
# =====================================================================================
def _run_edge(self: Engine) -> dict:
    r6 = _ident if self.precise else _round6
    cfg, p, d = self.cfg, self.cfg["params"], self.design
    dt, n = self.dt, self.n
    W = self.wheels
    nw = W.n
    drive = self.ctx.drive
    Thh = d["plant"]["Thh"]
    Mgl = d["plant"]["mgl"]
    beta = d["plant"]["beta"]
    ae = [w.axis[0] for w in W.wheels]              # a_i · e (hinge axis e = body x)
    Jw = [w.Jw for w in W.wheels]
    active_w = [i for i in range(nw) if abs(ae[i]) > 1e-12]
    sched = self.sched
    ini = initial_state(cfg, self.mp)
    th, thd = ini["theta"], ini["thetadot"]
    ww = [x * RPM for x in cfg["initial"]["wheel_speeds_rpm"]] if cfg["initial"].get("wheel_speeds_rpm") else [0.0] * nw
    est_kind = self.est_kind
    legacy_imu = EdgeImuLegacy(cfg, self.dt_ctrl, self.rng) if est_kind in LEGACY_EDGE_ESTIMATORS else None
    legacy_est = EdgeLegacyEstimator(est_kind, cfg, self.dt_ctrl) if legacy_imu else None
    imu3 = est3 = None
    if est_kind in ("cf3d", "mekf"):
        imu3 = Imu3D(cfg, self.rng, self.sens_every * dt)
        est3 = (Mekf if est_kind == "mekf" else ComplementaryAttitude)(cfg, edge_quat(0.0))
    q_edge0C = qconj(edge_quat(0.0))
    ctrl = self.controller
    est = Estimate()
    stale_after = default_stale_after_s(cfg, self.sens_every * dt if est3 is not None else self.dt_ctrl)
    self.stale_after_s = stale_after if est_kind != "ideal" else None
    thdd = 0.0
    fallRad, contactRad = ASSESS["fallEdgeDeg"] * DEG, ASSESS["contactEdgeDeg"] * DEG
    rec_every = self.rec_every
    ids = W.ids
    dname = "x" if W.standard else ids[drive]
    S = {k: [] for k in ("t", "theta", "thetadot", "omega_x", "T_x", "Tc_x", "e", "betahat", "thetahat", "tauF", "tauG", "E", "sat")}
    extra_w = [i for i in range(nw) if i != drive]
    for i in extra_w:
        S["omega_" + ids[i]] = []
        S["T_" + ids[i]] = []
    if est_kind != "ideal":
        S["bias_est"] = []
        S["gyro_bias"] = []
        S["est_age"] = []
        S["est_valid"] = []
    nl = ctrl.type == "nlpd"
    if nl:
        S["ref_tilt"] = []
    full = _full_arrays(n, nw, est_kind != "ideal")
    stop_at = n
    post_fall = int(round(self.term["post_fall_s"] * self.f_int))
    cur = {"T": [0.0] * nw, "Tc": [0.0] * nw, "sat": 0, "satW": [0] * nw, "thm": th, "bh": 0.0, "u": 0.0}
    cmd_T = [0.0] * nw
    OFF = None

    def tau_ext(t, th_):
        return sched.torque_body(t, edge_rot(th_))[0] if sched.has_continuous else 0.0

    def f(th_, thd_, ww_, T, t):
        failed = sched.failed
        Tn = [(-W.wheels[i].friction(ww_[i]) if failed[i] else T[i] - W.wheels[i].friction(ww_[i])) for i in active_w]
        a = (Mgl * math.sin(th_ + beta) + tau_ext(t, th_) - sum(ae[i] * Tn[k] for k, i in enumerate(active_w))) / Thh
        dw = [0.0] * nw
        for k, i in enumerate(active_w):
            dw[i] = Tn[k] / Jw[i] - ae[i] * a
        return thd_, a, dw

    def ctrl_event(t, what):
        ctrl.on_event(t, what)

    def est_theta(t):
        """3-D filters: the controller-facing hinge angle and rate at time t (prediction)."""
        qp, wp = est3.predict(t)
        qr = qmul(q_edge0C, qp)
        return 2 * math.atan2(qr[1], qr[0]), wp[0], qp

    def control(t, k):
        nonlocal thdd
        for e in sched.apply_events(t):
            ctrl_event(t, e["type"] + (" on" if e["state"] == "on" else " off"))
        failed = sched.failed
        thm, thdm = th, thd
        if legacy_imu is not None:
            wm, am = legacy_imu.sample(th, thd, thdd, t)
            thm, thdm = legacy_est.update(wm, am)
            est.set_timing(t, legacy_imu.t_meas, t, stale_after, "legacy")
        elif est3 is not None:
            for s in imu3.deliver(t):
                est3.accept(s, t)
            thm, thdm, est.q = est_theta(t)
            est.bias = (float(est3.b[0]), float(est3.b[1]), float(est3.b[2]))
            est.set_timing(t, est3.t if est3.initialised else None, est3.t_receipt, stale_after, "prediction")
        else:
            est.set_truth(t)
        est.theta, est.thetadot = thm, thdm
        est.w = (thdm, 0.0, 0.0)
        req = ctrl.request(t, est, ww, failed)
        T_des = req.per_wheel
        T, satW = self._limits(T_des, ww, failed)
        sat = 1 if any(satW) else 0
        T_lim = T[drive]
        T = self._apply_lag(T)
        failed_any = failed[drive]
        ctrl.after(sat, failed_any, ww, self.dt_ctrl, T_des[drive], T_lim)
        if self.fellAt is not None:
            return {"T": [0.0] * nw, "Tc": [0.0] * nw, "sat": 0, "satW": [0] * nw, "thm": thm, "bh": req.bh, "u": 0.0}
        return {"T": T, "Tc": list(T_des), "sat": sat, "satW": satW, "thm": thm, "bh": req.bh, "u": T_des[drive]}

    def rec(t, c):
        S["t"].append(r6(t))
        S["theta"].append(r6(th))
        S["thetadot"].append(r6(thd))
        S["omega_x"].append(r6(ww[drive]))
        S["T_x"].append(r6(c["T"][drive]))
        S["Tc_x"].append(r6(c["Tc"][drive]))
        S["e"].append(r6(th + beta))
        bh = c.get("bh")
        S["betahat"].append(r6(bh if bh is not None else ctrl_bh()))
        thm = est_theta(t)[0] if est3 is not None else c.get("thm")
        S["thetahat"].append(r6(thm if thm is not None else th))
        S["tauF"].append(r6(tau_ext(t, th)))
        S["tauG"].append(r6(Mgl * math.sin(th + beta)))
        S["E"].append(r6(self.E))
        S["sat"].append(c["sat"])
        for i in extra_w:
            S["omega_" + ids[i]].append(r6(ww[i]))
            S["T_" + ids[i]].append(r6(c["T"][i]))
        if est_kind != "ideal":
            S["bias_est"].append(r6(_edge_bias_est(legacy_est, est3)))
            S["gyro_bias"].append(r6(_edge_true_bias(legacy_imu, imu3)))
            tm = meas_time()
            S["est_age"].append(r6(t - tm) if tm is not None else -1.0)
            S["est_valid"].append(1 if (tm is not None and t - tm <= stale_after + EPS_T) else 0)
        if nl:
            S["ref_tilt"].append(r6(ctrl.delta))

    def meas_time():
        """Measurement time of the newest observation behind the estimate (None before the first)."""
        if est3 is not None:
            return est3.t if est3.initialised else None
        if legacy_imu is not None:
            return legacy_imu.t_meas
        return None

    def ctrl_bh():
        return getattr(ctrl, "bh", 0.0) if not isinstance(getattr(ctrl, "bh", 0.0), list) else 0.0

    full["e"][0] = th + beta
    for i in range(nw):
        full["om"][i][0] = ww[i]
    k = 0
    ended = False
    for k in range(n):
        self._check_cancel(k)
        t = k * dt
        for e in sched.apply_events(t):     # wheel events switch at the integration step; controllers are told (PID reset option)
            ctrl_event(t, e["type"] + (" on" if e["state"] == "on" else " off"))
        imp = sched.impulses_due(t)
        if imp:
            J = sum(sched.impulse_body(x, edge_rot(th))[0] for x in imp)
            dthd = J / Thh
            thd += dthd
            for i in active_w:
                ww[i] -= ae[i] * dthd
            self.impulses_applied += [{"id": x["id"], "t": t, "J_hinge_Nms": sched.impulse_body(x, edge_rot(th))[0]} for x in imp]
        if imu3 is not None and k % self.sens_every == 0:
            imu3.measure(t, edge_quat(th), (thd, 0.0, 0.0), (thdd, 0.0, 0.0))
        if k % self.ctrl_every == 0:
            cur = control(t, k)
            cmd_T = cur["T"]
        T = self._continuous_limit(cmd_T, ww, sched.failed) if W.electrical == "continuous" else cmd_T
        full["sat"][k] = cur["sat"]
        for i in range(nw):
            full["satW"][i][k] = cur["satW"][i]
            full["Treq"][i][k] = cur["Tc"][i]
            full["Tapp"][i][k] = T[i]
        full["ureq"][0][k] = cur["u"]
        if full["estErr"] is not None:
            # 3-D filters: the prediction at t (between control ticks the filter state does not change);
            # legacy estimators: the estimate of the latest control tick (zero-order hold, as in the browser)
            full["estErr"][k] = (est_theta(t)[0] if est3 is not None else cur["thm"]) - th
            tm = meas_time()
            if tm is None:
                full["estAge"][k] = math.nan
            else:
                full["estAge"][k] = t - tm
                full["estStale"][k] = 1 if t - tm > stale_after + EPS_T else 0
        if k % rec_every == 0:
            rec(t, cur)
        k1 = f(th, thd, ww, T, t)
        h2 = dt / 2
        s2 = (th + h2 * k1[0], thd + h2 * k1[1], [ww[i] + h2 * k1[2][i] for i in range(nw)])
        k2 = f(s2[0], s2[1], s2[2], T, t + h2)
        s3 = (th + h2 * k2[0], thd + h2 * k2[1], [ww[i] + h2 * k2[2][i] for i in range(nw)])
        k3 = f(s3[0], s3[1], s3[2], T, t + h2)
        s4 = (th + dt * k3[0], thd + dt * k3[1], [ww[i] + dt * k3[2][i] for i in range(nw)])
        k4 = f(s4[0], s4[1], s4[2], T, t + dt)
        th += dt / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])
        thd += dt / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])
        for i in active_w:
            ww[i] += dt / 6 * (k1[2][i] + 2 * k2[2][i] + 2 * k3[2][i] + k4[2][i])
        tn = t + dt
        if not (math.isfinite(th) and math.isfinite(thd) and all(math.isfinite(x) for x in ww)):
            return _numerical_failure(self, "invalid_state", f"the state became non-finite at t = {tn:.3f} s")
        thdd = f(th, thd, ww, T, tn)[1]
        for i in range(nw):
            w = W.wheels[i]
            ii = T[i] / w.kt
            Pel = ii * ii * w.R + T[i] * ww[i]
            if Pel > 0:
                self.E += Pel * dt
            self.effort += abs(T[i]) * dt
        full["e"][k + 1] = th + beta
        for i in range(nw):
            full["om"][i][k + 1] = ww[i]
        full["rate"][k + 1] = abs(thd)
        full["nSteps"] = k + 1
        if self.fellAt is None and (abs(th + beta) > fallRad or abs(th) >= contactRad):
            self.fellAt = tn
            self.fallCause = "contact" if abs(th) >= contactRad else "lean"
            stop_at = min(n, k + 1 + post_fall)
            ctrl.fell = True
            self.termination = {"reason": "fall", "t": tn, "detail": "COM lean passed the fall threshold" if self.fallCause == "lean" else "a face reached the floor"}
        touching = abs(th) >= contactRad
        if touching:
            th = math.copysign(contactRad, th)
            thd = 0.0
            if self.contactAt is None:
                self.contactAt = tn
        stop = _research_checks(self, tn, k, ww, lambda: _edge_normal_force(self, th, thd, thdd, tn))
        stop = _stop_on_recovery(self, k + 1, th + beta, abs(thd), tn) or stop
        if touching or k + 1 >= stop_at or stop:
            rec(tn, _off(nw) if self.fellAt is not None else control(tn, k + 1))
            ended = True
            break
    if not ended:
        rec(n * dt, control(n * dt, n))
    if self.termination is None:
        self.termination = {"reason": "duration", "t": full["nSteps"] * dt, "detail": "end of the observation window"}
    elif self.termination["reason"] == "fall":
        self.termination["detail"] += "; recorded until floor contact" if self.contactAt is not None else f"; recorded {self.term['post_fall_s']} s after the fall"
    full["E"] = self.E
    full["effort"] = self.effort
    units = {"t": "s", "theta": "rad", "thetadot": "rad/s", "omega_x": "rad/s", "T_x": "N·m", "Tc_x": "N·m", "e": "rad",
             "betahat": "rad", "thetahat": "rad", "tauF": "N·m", "tauG": "N·m", "E": "J", "sat": "0/1"}
    for i in extra_w:
        units["omega_" + ids[i]] = "rad/s"
        units["T_" + ids[i]] = "N·m"
    if est_kind != "ideal":
        units["bias_est"] = "rad/s"
        units["gyro_bias"] = "rad/s"
        units["est_age"] = "s (−1: no measurement yet)"
        units["est_valid"] = "0/1"
    if nl:
        units["ref_tilt"] = "rad"
    failed_ids = [ids[i] for i in range(nw) if sched.ever_failed[i]]
    return {"mode": "edge", "samples": {"rate_hz": self.record_hz_realized, "schedule": _schedule(self, S["t"]), "fs": p["fs"], "integration_hz": self.f_int,
                                        "convention": "zero-order hold: state at t and the command computed from it", "cols": S, "units": units},
            "full": full, "fellAt": self.fellAt, "fallCause": self.fallCause, "contactAt": self.contactAt, "energy": self.E,
            "activeWheels": [dname] if not sched.failed[drive] else [], "failedWheels": ["x" if (W.standard and i == drive) else ids[i] for i in range(nw) if sched.ever_failed[i] and i == drive] or failed_ids,
            "drive": drive, "estimator_stats": _est_stats(imu3, est3, legacy_imu, self.stale_after_s)}


def _schedule(self, times) -> dict:
    """The recording schedule that was actually used (saved with the samples)."""
    req = self.cfg["record_hz"]
    real = self.record_hz_realized
    last = times[-1] if times else None
    prev = times[-2] if len(times) > 1 else None
    stride_dt = self.rec_every * self.dt
    out = {"policy": "stride", "text": (f"the state at every {self.rec_every} integration steps (every {stride_dt:.6g} s)" if self.rec_every > 1 else "the state at every integration step") + " plus the final state of the run",
           "requested_hz": req, "realized_hz": real, "stride_steps": self.rec_every, "integration_hz": self.f_int,
           "matches_request": abs(real - req) <= 1e-9 * max(1.0, req),
           "endpoint": "The state at the end of the executed run is always the last sample; if the run does not end on the stride grid (early termination, or a window that is not a multiple of the stride), the last interval is shorter.",
           "t_end_s": last, "final_interval_s": (last - prev) if (last is not None and prev is not None) else None, "rows": len(times),
           "interpolation": "none (samples are integration-step states, no interpolation)"}
    return out


def _edge_bias_est(legacy_est, est3):
    if legacy_est is not None:
        return legacy_est.bias
    if est3 is not None:
        return float(est3.b[0])
    return 0.0


def _edge_true_bias(legacy_imu, imu3):
    if legacy_imu is not None:
        return legacy_imu.true_bias
    if imu3 is not None:
        return imu3.b[0]
    return 0.0


def _edge_normal_force(self, th, thd, thdd, t):
    """Vertical hinge reaction N_z = M (a_c,z + g) − F_ext,z (world)."""
    rc = self.mp["rc"]
    M = self.mp["M"]
    g = self.cfg["params"]["g"]
    w = (thd, 0.0, 0.0)
    wd = (thdd, 0.0, 0.0)
    ab = tuple(a + b for a, b in zip(cross(wd, rc), cross(w, cross(w, rc))))
    R = edge_rot(th)
    az = R[2][0] * ab[0] + R[2][1] * ab[1] + R[2][2] * ab[2]
    Fz = self.sched.force_world(t, R)[2]
    return M * (az + g) - Fz


def _off(nw):
    return {"T": [0.0] * nw, "Tc": [0.0] * nw, "sat": 0, "satW": [0] * nw, "thm": None, "bh": None, "u": 0.0}


def _full_arrays(n, nw, with_est):
    return {"e": array("d", bytes(8 * (n + 1))), "om": [array("d", bytes(8 * (n + 1))) for _ in range(nw)],
            "sat": bytearray(n + 1), "satW": [bytearray(n + 1) for _ in range(nw)],
            "Treq": [array("d", bytes(8 * (n + 1))) for _ in range(nw)], "Tapp": [array("d", bytes(8 * (n + 1))) for _ in range(nw)],
            "ureq": [array("d", bytes(8 * (n + 1))) for _ in range(3)],
            "rate": array("d", bytes(8 * (n + 1))), "rate_tilt": None, "att": None, "estErr": array("d", bytes(8 * (n + 1))) if with_est else None,
            "estAtt": None, "biasErr": None, "psi": None, "psiRef": None, "E": 0.0, "effort": 0.0, "nSteps": 0,
            # per step k = 0 … n−1: age of the newest observation behind the controller-facing estimate (NaN before the
            # first) and the stale flag (age > stale_after_s)
            "estAge": array("d", bytes(8 * (n + 1))) if with_est else None, "estStale": bytearray(n + 1) if with_est else None}


def _numerical_failure(self, reason, message):
    self.termination = {"reason": reason, "t": None, "detail": message}
    return {"numericalFailure": message, "termination": self.termination, "samples": None}


def _stop_on_recovery(self, k, att, rate, tn):
    if self.monitor.update(k, att, rate) and self.term.get("stop_on_recovery") and self.termination is None and self.fellAt is None:
        self.termination = {"reason": "recovery", "t": tn, "detail": f"research recovery criteria met at t = {self.monitor.t_rec:.3f} s and held for {self.cfg['recovery']['hold_s']:g} s (termination.stop_on_recovery)"}
        return True
    return False


def _research_checks(self, tn, k, ww, normal_force):
    """Research termination rules: safety overspeed, lift-off (loss of support)."""
    ov = self.term.get("overspeed_rpm")
    if ov is not None and self.termination is None:
        for i, w in enumerate(ww):
            if abs(w) > ov * RPM:
                self.termination = {"reason": "safety_limit", "t": tn, "detail": f"wheel {self.wheels.ids[i]} exceeded the {ov:g} rpm safety limit"}
                return True
    if self.term.get("check_lift_off") and self.fellAt is None and k % self.ctrl_every == 0:
        N = normal_force()
        if N <= 0:
            self.termination = {"reason": "loss_of_support", "t": tn, "detail": f"the pivot would have to pull the cube down (vertical reaction {N:.3g} N): lift-off"}
            self.fellAt = tn
            self.fallCause = "lift_off"
            return True
    return False


def _est_stats(imu3, est3, legacy_imu=None, stale_after=None):
    if imu3 is None:
        if legacy_imu is None:
            return None
        return {"timing": "legacy", "packets_repeated_on_dropout": legacy_imu.repeated, "latency_steps": legacy_imu.lagK,
                "stale_after_s": stale_after}
    out = {"samples_delivered": imu3.delivered, "samples_dropped": imu3.dropped, "accel_updates": est3.updates, "accel_gated": est3.gated,
           "timing": "prediction", "samples_processed": est3.processed, "rejected_duplicate": est3.rejected_duplicate,
           "rejected_out_of_order": est3.rejected_out_of_order, "initialised_at_s": est3.t_init_receipt, "initial_sample_t_s": est3.t_init,
           "max_sample_gap_s": est3.max_gap_s,
           "stale_after_s": stale_after, "filter_time_s": est3.t,
           "note": "Covariance figures refer to the update state at filter_time_s (the newest processed sample)."}
    P = est3.covariance()
    if P is not None:
        # final MEKF attitude uncertainty split into the vertical (heading: not observable from gravity) and tilt parts
        u = np.array(up_in_body(est3.q))
        Pa = np.asarray(P)[:3, :3]
        var_v = float(u @ Pa @ u)
        out["final_heading_sd_deg"] = math.sqrt(max(0.0, var_v)) / DEG
        out["final_tilt_sd_deg"] = math.sqrt(max(0.0, (float(np.trace(Pa)) - var_v) / 2)) / DEG
        out["final_bias_sd_dps"] = [math.sqrt(max(0.0, float(P[3 + i][3 + i]))) / DEG for i in range(3)]
    return out


Engine._run_edge = _run_edge


# =====================================================================================
# CORNER (point pivot, full 3-D)
# =====================================================================================
def _run_corner(self: Engine) -> dict:
    r6 = _ident if self.precise else _round6
    cfg, p, d = self.cfg, self.cfg["params"], self.design
    dt, n = self.dt, self.n
    W = self.wheels
    nw = W.n
    g = p["g"]
    Th0 = d["plant"]["Th0"]
    Thhi = d["plant"]["Thhi"]
    M = d["plant"]["M"]
    rc = tuple(d["plant"]["rc"])
    rcu = tuple(x / math.sqrt(dot(rc, rc)) for x in rc)
    Mrc = (M * rc[0], M * rc[1], M * rc[2])
    axes = [w.axis for w in W.wheels]
    Jw = [w.Jw for w in W.wheels]
    ids = W.ids
    std = W.standard
    sched = self.sched
    ini = initial_state(cfg, self.mp)
    q = tuple(ini["q"])
    w = tuple(ini["w"])
    ww = [x * RPM for x in cfg["initial"]["wheel_speeds_rpm"]] if cfg["initial"].get("wheel_speeds_rpm") else [0.0] * nw
    ctx = self.ctx
    uRef = ctx.uRef
    truth_yaw = YawTracker(ctx.qRef, uRef)
    est_kind = self.est_kind
    imu3 = est3 = None
    if est_kind in ("cf3d", "mekf"):
        imu3 = Imu3D(cfg, self.rng, self.sens_every * dt)
        est3 = (Mekf if est_kind == "mekf" else ComplementaryAttitude)(cfg, QEQ_nominal(cfg))
    ctrl = self.controller
    est = Estimate()
    stale_after = default_stale_after_s(cfg, self.sens_every * dt) if est3 is not None else None
    self.stale_after_s = stale_after
    fallRad = ASSESS["fallCornerDeg"] * DEG
    rec_every = self.rec_every
    wn = ["x", "y", "z"] if std else ids
    cols = ["t", "q0", "q1", "q2", "q3", "wx", "wy", "wz"] + ["omega_" + x for x in wn] + ["T_" + x for x in wn] + ["Tc_" + x for x in wn] + \
        ["e", "geo", "psi", "psiRef", "tauF_x", "tauF_y", "tauF_z", "tauG_x", "tauG_y", "tauG_z", "betahat_x", "betahat_y", "betahat_z", "E", "sat",
         "u_x", "u_y", "u_z", "att_err"]
    if est3 is not None:
        cols += ["qh0", "qh1", "qh2", "qh3", "bias_est_x", "bias_est_y", "bias_est_z", "est_err", "gyro_bias_x", "gyro_bias_y", "gyro_bias_z",
                 "est_age", "est_valid"]
    nl = ctrl.type == "nlpd"
    if nl:
        cols += ["ref_tilt_x", "ref_tilt_y", "ref_tilt_z"]
    S = {c: [] for c in cols}
    full = _full_arrays(n, nw, False)
    if est3 is not None:
        full["estAge"] = array("d", bytes(8 * (n + 1)))
        full["estStale"] = bytearray(n + 1)
    full["psi"] = array("d", bytes(8 * (n + 1)))
    full["psiRef"] = array("d", bytes(8 * (n + 1)))
    full["rate_tilt"] = array("d", bytes(8 * (n + 1)))
    full["att"] = array("d", bytes(8 * (n + 1)))
    if est3 is not None:
        full["estAtt"] = array("d", bytes(8 * (n + 1)))
        full["estTilt"] = array("d", bytes(8 * (n + 1)))
        full["biasErr"] = array("d", bytes(8 * (n + 1)))
    stop_at = n
    post_fall = int(round(self.term["post_fall_s"] * self.f_int))
    q_bal = from_to(rcu, (0.0, 0.0, 1.0))
    bal_yaw = YawTracker(q_bal, rcu)
    yaw_state = {"psi0_true": None, "psi0_bal": None, "given_up": None}

    def ext_torque(t, qq):
        return sched.torque_body(t, rot(qq)) if sched.has_continuous else (0.0, 0.0, 0.0)

    def deriv(qq, wb, wwh, TT, t):
        up = up_in_body(qq)
        gB = (-g * up[0], -g * up[1], -g * up[2])
        failed = sched.failed
        Tn = [(-W.wheels[i].friction(wwh[i]) if failed[i] else TT[i] - W.wheels[i].friction(wwh[i])) for i in range(nw)]
        L = list(mv(Th0, wb))
        for i in range(nw):
            a = axes[i]
            s = wwh[i] * Jw[i]
            L[0] += s * a[0]
            L[1] += s * a[1]
            L[2] += s * a[2]
        c1 = cross(wb, L)
        c2 = cross(Mrc, gB)
        te = ext_torque(t, qq)
        rhs = [-c1[0] + c2[0] + te[0], -c1[1] + c2[1] + te[1], -c1[2] + c2[2] + te[2]]
        for i in range(nw):
            a = axes[i]
            rhs[0] -= Tn[i] * a[0]
            rhs[1] -= Tn[i] * a[1]
            rhs[2] -= Tn[i] * a[2]
        wd = mv(Thhi, rhs)
        qd = qmul(qq, (0.0, wb[0], wb[1], wb[2]))
        wwd = [Tn[i] / Jw[i] - (axes[i][0] * wd[0] + axes[i][1] * wd[1] + axes[i][2] * wd[2]) for i in range(nw)]
        return (qd[0] / 2, qd[1] / 2, qd[2] / 2, qd[3] / 2), wd, wwd

    def sense():
        R = rot(q)
        uB = (R[2][0], R[2][1], R[2][2])
        psi = truth_yaw.psi(q)
        pb = bal_yaw.psi(q)
        return {"R": R, "uB": uB, "psi": psi, "psi_bal": pb, "e": math.acos(max(-1.0, min(1.0, dot(uB, rcu)))),
                "geo": math.acos(max(-1.0, min(1.0, dot(uB, CH)))), "clr": min(uB)}

    cmd_state = {"angle": 0.0}

    def ctrl_event(t, what):
        ctrl.on_event(t, what)

    def control(t, s):
        for e in sched.apply_events(t):
            ctrl_event(t, e["type"] + (" on" if e["state"] == "on" else " off"))
        a_cmd = ctx.cmd_angle(t)
        if a_cmd != cmd_state["angle"]:
            cmd_state["angle"] = a_cmd
            ctrl_event(t, "yaw command")
        failed = sched.failed
        if est3 is not None:
            for smp in imu3.deliver(t):
                est3.accept(smp, t)
            est.q, est.w = est3.predict(t)
            est.bias = (float(est3.b[0]), float(est3.b[1]), float(est3.b[2]))
            est.set_timing(t, est3.t if est3.initialised else None, est3.t_receipt, stale_after, "prediction")
        else:
            est.q, est.w = q, w
            est.set_truth(t)
        req = ctrl.request(t, est, ww, failed)
        if req.per_wheel is not None:
            T_des = list(req.per_wheel)
            u_req = [sum(T_des[i] * axes[i][k] for i in range(nw)) for k in range(3)]
            given_up = req.yaw_given_up
        else:
            u_req = list(req.body)
            T_des, given_up = ctx.body_alloc(req.body, failed, ww)
            if ctx.nonlinear.get("compensate_friction") and ctrl.type == "nlpd":
                fc = [(W.wheels[i].friction(ww[i]) if not failed[i] and T_des[i] != 0 else 0.0) for i in range(nw)]
                T_des = [T_des[i] + fc[i] for i in range(nw)]
                # the friction feed-forward is part of what is asked of the motors (authority metric compares like with like)
                u_req = [u_req[k] + sum(fc[i] * axes[i][k] for i in range(nw)) for k in range(3)]
        if given_up and yaw_state["given_up"] is None and self.fellAt is None:
            yaw_state["given_up"] = t
            self.yaw_objective_changes.append({"t": t, "objective": "free", "reason": "wheel failure: torque reallocated to the healthy wheels, yaw control given up"})
        T, satW = self._limits(T_des, ww, failed)
        sat = 1 if any(satW) else 0
        T_lim = list(T)
        T = self._apply_lag(T)
        ctrl.after(sat, any(failed), ww, self.dt_ctrl, T_des, T_lim)
        bh = req.bh
        if self.fellAt is not None:
            return {"T": [0.0] * nw, "Tc": [0.0] * nw, "sat": 0, "satW": [0] * nw, "bh": bh, "u": [0.0, 0.0, 0.0]}
        return {"T": T, "Tc": T_des, "sat": sat, "satW": satW, "bh": bh, "u": u_req}

    def target_err(s, t):
        """Research attitude error to the target: COM above the pivot at the commanded heading."""
        if yaw_state["psi0_bal"] is None:
            yaw_state["psi0_bal"] = s["psi_bal"]
        objective = cfg["recovery"]["yaw_objective"]
        if objective == "free" or (yaw_state["given_up"] is not None and t >= yaw_state["given_up"]):
            return s["e"]
        psi_t = yaw_state["psi0_bal"] + ctx.cmd_angle(t)
        qt = qmul(axis_angle((0.0, 0.0, 1.0), psi_t), q_bal)
        return angle_between(q, qt)

    def rec(t, s, c):
        tf = ext_torque(t, q)
        gB = mtv(s["R"], (0.0, 0.0, -g))
        tg = cross(rc, gB)
        bb = c.get("bh")
        if bb is None or not isinstance(bb, (list, tuple)):
            bb = getattr(ctrl, "bh", (0.0, 0.0, 0.0)) if isinstance(getattr(ctrl, "bh", None), list) else (0.0, 0.0, 0.0)
        S["t"].append(r6(t))
        for j in range(4):
            S["q%d" % j].append(r6(q[j]))
        S["wx"].append(r6(w[0]))
        S["wy"].append(r6(w[1]))
        S["wz"].append(r6(w[2]))
        for i, nm in enumerate(wn):
            S["omega_" + nm].append(r6(ww[i]))
            S["T_" + nm].append(r6(c["T"][i]))
            S["Tc_" + nm].append(r6(c["Tc"][i]))
        S["e"].append(r6(s["e"]))
        S["geo"].append(r6(s["geo"]))
        S["psi"].append(r6(s["psi"] - yaw_state["psi0_true"]))
        S["psiRef"].append(r6(ctx.cmd_angle(t)))
        for j, ax in enumerate("xyz"):
            S["tauF_" + ax].append(r6(tf[j]))
            S["tauG_" + ax].append(r6(M * tg[j]))
            S["betahat_" + ax].append(r6(bb[j]))
            S["u_" + ax].append(r6(c["u"][j]))
        S["E"].append(r6(self.E))
        S["sat"].append(c["sat"])
        S["att_err"].append(r6(target_err(s, t)))
        if est3 is not None:
            qh = est3.predict(t)[0]          # the controller-facing estimate at the sample time
            for j in range(4):
                S["qh%d" % j].append(r6(qh[j]))
            for j, ax in enumerate("xyz"):
                S["bias_est_" + ax].append(r6(float(est3.b[j])))
            S["est_err"].append(r6(angle_between(q, qh)))
            for j, ax in enumerate("xyz"):
                S["gyro_bias_" + ax].append(r6(imu3.b[j]))
            tm = est3.t if est3.initialised else None
            S["est_age"].append(r6(t - tm) if tm is not None else -1.0)
            S["est_valid"].append(1 if (tm is not None and t - tm <= stale_after + EPS_T) else 0)
        if nl:
            for j, ax in enumerate("xyz"):
                S["ref_tilt_" + ax].append(r6(ctrl.delta[j]))

    s0 = sense()
    yaw_state["psi0_true"] = s0["psi"]
    full["e"][0] = s0["e"]
    for i in range(nw):
        full["om"][i][0] = ww[i]
    full["att"][0] = target_err(s0, 0.0)
    wmag = math.sqrt(dot(w, w))
    full["rate"][0] = wmag
    full["rate_tilt"][0] = math.sqrt(max(0.0, wmag * wmag - dot(w, s0["uB"]) ** 2))
    cur = None
    cmd_T = [0.0] * nw
    wd_last = (0.0, 0.0, 0.0)
    ended = False
    k = 0
    for k in range(n):
        self._check_cancel(k)
        t = k * dt
        for e in sched.apply_events(t):     # wheel events switch at the integration step; controllers are told (PID reset option)
            ctrl_event(t, e["type"] + (" on" if e["state"] == "on" else " off"))
        imp = sched.impulses_due(t)
        if imp:
            R = rot(q)
            J = [0.0, 0.0, 0.0]
            for x in imp:
                jb = sched.impulse_body(x, R)
                J = [J[j] + jb[j] for j in range(3)]
                self.impulses_applied.append({"id": x["id"], "t": t, "J_body_Nms": list(jb)})
            dw = mv(Thhi, J)
            w = (w[0] + dw[0], w[1] + dw[1], w[2] + dw[2])
            for i in range(nw):
                ww[i] -= axes[i][0] * dw[0] + axes[i][1] * dw[1] + axes[i][2] * dw[2]
        s = sense()
        if imu3 is not None and k % self.sens_every == 0:
            imu3.measure(t, q, w, wd_last)
        if k % self.ctrl_every == 0:
            cur = control(t, s)
            cmd_T = cur["T"]
        T = self._continuous_limit(cmd_T, ww, sched.failed) if W.electrical == "continuous" else cmd_T
        full["sat"][k] = cur["sat"]
        for i in range(nw):
            full["satW"][i][k] = cur["satW"][i]
            full["Treq"][i][k] = cur["Tc"][i]
            full["Tapp"][i][k] = T[i]
        uq = cur["u"]
        full["ureq"][0][k], full["ureq"][1][k], full["ureq"][2][k] = uq[0], uq[1], uq[2]
        if est3 is not None:
            qh = est3.predict(t)[0]          # between control ticks the filter state does not change
            full["estAtt"][k] = angle_between(q, qh)
            full["estTilt"][k] = math.acos(max(-1.0, min(1.0, dot(s["uB"], up_in_body(qh)))))
            full["biasErr"][k] = math.sqrt(sum((imu3.b[j] - float(est3.b[j])) ** 2 for j in range(3)))
            if est3.initialised:
                full["estAge"][k] = t - est3.t
                full["estStale"][k] = 1 if t - est3.t > stale_after + EPS_T else 0
            else:
                full["estAge"][k] = math.nan
        if k % rec_every == 0:
            rec(t, s, cur)
        k1 = deriv(q, w, ww, T, t)
        h2 = dt / 2
        q2 = tuple(q[j] + h2 * k1[0][j] for j in range(4))
        w2 = tuple(w[j] + h2 * k1[1][j] for j in range(3))
        ww2 = [ww[i] + h2 * k1[2][i] for i in range(nw)]
        k2 = deriv(q2, w2, ww2, T, t + h2)
        q3 = tuple(q[j] + h2 * k2[0][j] for j in range(4))
        w3 = tuple(w[j] + h2 * k2[1][j] for j in range(3))
        ww3 = [ww[i] + h2 * k2[2][i] for i in range(nw)]
        k3 = deriv(q3, w3, ww3, T, t + h2)
        q4 = tuple(q[j] + dt * k3[0][j] for j in range(4))
        w4 = tuple(w[j] + dt * k3[1][j] for j in range(3))
        ww4 = [ww[i] + dt * k3[2][i] for i in range(nw)]
        k4 = deriv(q4, w4, ww4, T, t + dt)
        qn = tuple(q[j] + dt / 6 * (k1[0][j] + 2 * k2[0][j] + 2 * k3[0][j] + k4[0][j]) for j in range(4))
        w = tuple(w[j] + dt / 6 * (k1[1][j] + 2 * k2[1][j] + 2 * k3[1][j] + k4[1][j]) for j in range(3))
        for i in range(nw):
            ww[i] += dt / 6 * (k1[2][i] + 2 * k2[2][i] + 2 * k3[2][i] + k4[2][i])
        tn = t + dt
        drift = abs(qlen(qn) - 1.0)
        q = qnorm(qn)
        if not (all(math.isfinite(x) for x in q) and all(math.isfinite(x) for x in w) and all(math.isfinite(x) for x in ww)):
            return _numerical_failure(self, "invalid_state", f"the state became non-finite at t = {tn:.3f} s")
        if drift > self.term["max_quaternion_drift"]:
            return _numerical_failure(self, "numerical_failure", f"the quaternion norm drifted by {drift:.2e} in one step at t = {tn:.3f} s (step too large for the motion)")
        for i in range(nw):
            wh = W.wheels[i]
            ii = T[i] / wh.kt
            Pe = ii * ii * wh.R + T[i] * ww[i]
            if Pe > 0:
                self.E += Pe * dt
            self.effort += abs(T[i]) * dt
        s1 = sense()
        full["e"][k + 1] = s1["e"]
        for i in range(nw):
            full["om"][i][k + 1] = ww[i]
        full["psi"][k + 1] = s1["psi"] - yaw_state["psi0_true"]
        full["psiRef"][k + 1] = ctx.cmd_angle(tn)
        wmag = math.sqrt(dot(w, w))
        full["rate"][k + 1] = wmag
        full["rate_tilt"][k + 1] = math.sqrt(max(0.0, wmag * wmag - dot(w, s1["uB"]) ** 2))
        full["att"][k + 1] = target_err(s1, tn)
        full["nSteps"] = k + 1
        need_wd = imu3 is not None or (self.term.get("check_lift_off") and self.fellAt is None and (k + 1) % self.ctrl_every == 0)
        if need_wd:
            wd_last = deriv(q, w, ww, T, tn)[1]
        if self.fellAt is None and (s1["e"] > fallRad or s1["clr"] <= 0):
            self.fellAt = tn
            self.fallCause = "contact" if s1["clr"] <= 0 else "lean"
            stop_at = min(n, k + 1 + post_fall)
            ctrl.fell = True
            self.termination = {"reason": "fall", "t": tn, "detail": "COM lean passed the fall threshold" if self.fallCause == "lean" else "an edge at the pivot reached the floor"}
        touching = s1["clr"] <= 0
        if touching and self.contactAt is None:
            self.contactAt = tn
        stop = _research_checks(self, tn, k, ww, lambda: _corner_normal_force(self, q, w, wd_last, tn, M, rc, g))
        free = cfg["recovery"]["yaw_objective"] == "free" or yaw_state["given_up"] is not None
        stop = _stop_on_recovery(self, k + 1, full["att"][k + 1], full["rate_tilt"][k + 1] if free else wmag, tn) or stop
        if touching or k + 1 >= stop_at or stop:
            rec(tn, s1, _off3(nw) if self.fellAt is not None else control(tn, s1))
            ended = True
            break
    if not ended:
        sN = sense()
        rec(n * dt, sN, control(n * dt, sN))
    if self.termination is None:
        self.termination = {"reason": "duration", "t": full["nSteps"] * dt, "detail": "end of the observation window"}
    elif self.termination["reason"] == "fall":
        self.termination["detail"] += "; recorded until floor contact" if self.contactAt is not None else f"; recorded {self.term['post_fall_s']} s after the fall"
    full["E"] = self.E
    full["effort"] = self.effort
    full["activeIdx"] = [i for i in range(nw) if not sched.failed[i]]
    units = {c: "" for c in cols}
    units.update({"t": "s", "q0": "–", "q1": "–", "q2": "–", "q3": "–", "wx": "rad/s", "wy": "rad/s", "wz": "rad/s", "e": "rad", "geo": "rad",
                  "psi": "rad", "psiRef": "rad", "E": "J", "sat": "0/1", "att_err": "rad"})
    for nm in wn:
        units["omega_" + nm], units["T_" + nm], units["Tc_" + nm] = "rad/s", "N·m", "N·m"
    for ax in "xyz":
        units["tauF_" + ax] = units["tauG_" + ax] = units["u_" + ax] = "N·m"
        units["betahat_" + ax] = "rad"
    if est3 is not None:
        for j in range(4):
            units["qh%d" % j] = "–"
        for ax in "xyz":
            units["bias_est_" + ax] = units["gyro_bias_" + ax] = "rad/s"
        units["est_err"] = "rad"
        units["est_age"] = "s (−1: no measurement yet)"
        units["est_valid"] = "0/1"
    if nl:
        for ax in "xyz":
            units["ref_tilt_" + ax] = "rad"
    return {"mode": "corner", "samples": {"rate_hz": self.record_hz_realized, "schedule": _schedule(self, S["t"]), "fs": p["fs"], "integration_hz": self.f_int,
                                          "convention": "zero-order hold: state at t and the command computed from it", "cols": S, "units": units},
            "full": full, "fellAt": self.fellAt, "fallCause": self.fallCause, "contactAt": self.contactAt, "energy": self.E,
            "activeWheels": [wn[i] for i in range(nw) if not sched.failed[i]], "psi0": yaw_state["psi0_true"],
            "failedWheels": [wn[i] for i in range(nw) if sched.ever_failed[i]], "yaw_given_up_at": yaw_state["given_up"],
            "estimator_stats": _est_stats(imu3, est3, None, self.stale_after_s)}


def QEQ_nominal(cfg):
    from ..constants import QEQ
    return QEQ


def _off3(nw):
    return {"T": [0.0] * nw, "Tc": [0.0] * nw, "sat": 0, "satW": [0] * nw, "bh": None, "u": [0.0, 0.0, 0.0]}


def _corner_normal_force(self, q, w, wd, t, M, rc, g):
    ab = tuple(a + b for a, b in zip(cross(wd, rc), cross(w, cross(w, rc))))
    R = rot(q)
    az = R[2][0] * ab[0] + R[2][1] * ab[1] + R[2][2] * ab[2]
    Fz = self.sched.force_world(t, R)[2]
    return M * (az + g) - Fz


Engine._run_corner = _run_corner

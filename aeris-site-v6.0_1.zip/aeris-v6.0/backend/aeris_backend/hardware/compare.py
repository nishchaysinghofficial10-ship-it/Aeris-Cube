"""Simulation ↔ hardware comparison (offline). Extends the browser's AERIS_VALIDATION.compare:

- time alignment: the simulation is interpolated onto the hardware time stamps inside the
  overlap (no extrapolation); a lag in ±max_lag_s is chosen on the primary attitude signal and
  applied to every signal (reported);
- attitude: tilt θ (edge) or the quaternion geodesic error 2·acos|⟨q_sim, q_hw⟩| (corner/free),
  the simulation quaternion interpolated component-wise and renormalised;
- body rates (per axis and vector), wheel speeds, commanded vs measured torque (hardware
  internal consistency) and simulated applied vs measured torque;
- estimator error when both an estimate and an independent reference exist in the recording
  (qhat* against qref*, or thetahat against theta_ref);
- data quality: overlap fraction, samples compared, the ingestion quality report.

Acceptance is evaluated ONLY against a validation protocol whose thresholds were registered
before the recording was ingested. The result never changes a model's validation status; it
is evidence with traceable ids and hashes.
"""
from __future__ import annotations

import bisect
import math

DEG, RPM = math.pi / 180, math.pi / 30


def _interp(xs, ys, x):
    n = len(xs)
    if not n or x < xs[0] - 1e-12 or x > xs[-1] + 1e-12:
        return None
    i = bisect.bisect_right(xs, x)
    if i <= 0:
        return ys[0]
    if i >= n:
        return ys[-1]
    x0, x1 = xs[i - 1], xs[i]
    f = (x - x0) / (x1 - x0) if x1 > x0 else 0.0
    return ys[i - 1] + f * (ys[i] - ys[i - 1])


def _err_stats(errs):
    if not errs:
        return None
    n = len(errs)
    return {"n": n, "rmse": math.sqrt(sum(e * e for e in errs) / n), "mae": sum(abs(e) for e in errs) / n, "peak": max(abs(e) for e in errs)}


def _scaled(st, s):
    return None if st is None else {k: (v * s if k != "n" else v) for k, v in st.items()}


STATUS_OK = 0          # telemetry status code of a balancing device (telemetry/stream.py STATUS_CODES["ok"])


def align_on_experiment_start(hw_si: dict) -> tuple[dict, dict]:
    """v6.0 (Simulate My Cube, twin comparisons): a DEVICE recording runs on the device's telemetry clock (seconds since
    its stream started, idle time before and after the experiment included), while a twin simulation starts at t = 0
    at the start of the experiment. The recording's balancing run — its first frame with status 'ok' up to the last
    frame of that uninterrupted 'ok' run — is compared, with t = 0 at its first frame; a recording without a status
    column or without an 'ok' frame is compared whole from its first frame (the rule says which). The lag search then
    refines the offset. The stored recording is not changed."""
    t = hw_si["t"]
    st = hw_si.get("status")
    i0 = next((i for i, s in enumerate(st) if s == STATUS_OK), None) if st is not None else None
    if i0 is not None:
        i1 = i0
        while i1 + 1 < len(t) and st[i1 + 1] == STATUS_OK:
            i1 += 1
        rule = "the recording's balancing run (status ok, the device balancing or stopping normally): t = 0 at its first frame, the start of the experiment"
    else:
        i0, i1 = 0, len(t) - 1
        rule = ("the whole recording from its first frame (no frame has status ok: the device never balanced while recording)" if st is not None
                else "the whole recording from its first frame (the recording has no status column)")
    t0 = t[i0]
    out = {k: (v[i0:i1 + 1] if isinstance(v, list) and len(v) == len(t) else v) for k, v in hw_si.items()}
    out["t"] = [x - t0 for x in t[i0:i1 + 1]]
    return out, {"recording_t0_s": t0, "recording_window_s": [t0, t[i1]], "recording_t0_rule": rule}


def compare(sim: dict, hw_doc: dict, hw_si: dict, *, max_lag_s: float = 0.25, protocol: dict | None = None, recording_meta: dict | None = None) -> dict:
    S = sim["samples"]["cols"]
    st = S["t"]
    ht = hw_si["t"]
    t0, t1 = max(st[0], ht[0]), min(st[-1], ht[-1])
    out = {"ok": False, "errors": [], "warnings": [], "signals": {}, "alignment": None, "quality": None, "acceptance": None}
    mode = sim["config"]["mode"]
    if hw_doc.get("mode") not in ("free", mode):
        out["errors"].append(f"The simulation is in {mode} mode but the recording is in {hw_doc.get('mode')} mode.")
        return out
    if not t1 > t0:
        out["errors"].append("The simulation and the recording do not overlap in time.")
        return out
    idx = [i for i, t in enumerate(ht) if t0 - 1e-12 <= t <= t1 + 1e-12]

    def att_err(lag):
        errs = []
        if mode == "edge" and "theta" in hw_si:
            for i in idx:
                s = _interp(st, S["theta"], ht[i] - lag)
                if s is not None:
                    errs.append(hw_si["theta"][i] - s)
        elif all(f"q{j}" in hw_si for j in range(4)):
            for i in idx:
                qs = [_interp(st, S[f"q{j}"], ht[i] - lag) for j in range(4)]
                if None in qs:
                    continue
                n = math.sqrt(sum(x * x for x in qs))
                qh = [hw_si[f"q{j}"][i] for j in range(4)]
                d = abs(sum(a / n * b for a, b in zip(qs, qh)))
                errs.append(2 * math.acos(min(1.0, d)))
        return errs
    base = att_err(0.0)
    dt_h = (ht[-1] - ht[0]) / max(1, len(ht) - 1)
    best = (0.0, _err_stats(base))
    if base:
        steps = min(400, int(max_lag_s / max(1e-4, dt_h)))
        for k in range(-steps, steps + 1):
            if not k:
                continue
            e = att_err(k * dt_h)
            if len(e) >= 0.8 * len(base):
                s = _err_stats(e)
                if s["rmse"] < best[1]["rmse"]:
                    best = (k * dt_h, s)
    lag = best[0]
    out["alignment"] = {"overlap_s": [t0, t1], "lag_s": lag, "lag_search_s": max_lag_s, "primary": "theta" if mode == "edge" else "quaternion geodesic",
                        "note": "The simulation is shifted by lag_s (positive: hardware later) before every signal is compared."}
    a = _err_stats(att_err(lag))
    if a:
        out["signals"]["attitude"] = {"unit": "deg", "definition": "θ_hw − θ_sim" if mode == "edge" else "geodesic angle between q_sim and q_hw", **_scaled(a, 1 / DEG),
                                      "before_alignment": _scaled(_err_stats(base), 1 / DEG)}

    def pair(sim_col, hw_col, unit_scale, unit):
        if sim_col not in S or hw_col not in hw_si:
            return None
        errs = []
        for i in idx:
            s = _interp(st, S[sim_col], ht[i] - lag)
            if s is not None:
                errs.append(hw_si[hw_col][i] - s)
        st_ = _err_stats(errs)
        return None if st_ is None else {"unit": unit, "sim": sim_col, "hw": hw_col, **_scaled(st_, unit_scale)}
    rate_cols = [("thetadot", "thetadot"), ("thetadot", "w_x")] if mode == "edge" else [("wx", "w_x"), ("wy", "w_y"), ("wz", "w_z")]
    for sc, hc in rate_cols:
        r = pair(sc, hc, 1 / DEG, "deg/s")
        if r:
            out["signals"]["rate_" + hc] = r
    for w in ("x", "y", "z"):
        for hc in (f"omega_{w}", f"wheel_rpm_{w}"):
            r = pair(f"omega_{w}", hc, 1 / RPM, "rpm")
            if r:
                out["signals"]["wheel_" + w] = r
                break
        r = pair(f"T_{w}", f"torque_meas_{w}", 1.0, "N·m")
        if r:
            out["signals"]["torque_sim_vs_meas_" + w] = r
        if f"torque_cmd_{w}" in hw_si and f"torque_meas_{w}" in hw_si:
            errs = [hw_si[f"torque_meas_{w}"][i] - hw_si[f"torque_cmd_{w}"][i] for i in range(len(ht))]
            out["signals"]["torque_cmd_vs_meas_" + w] = {"unit": "N·m", "definition": "hardware measured − hardware commanded (driver tracking)", **_err_stats(errs)}
    if all(f"qhat{j}" in hw_si for j in range(4)) and all(f"qref{j}" in hw_si for j in range(4)):
        errs = []
        for i in range(len(ht)):
            d = abs(sum(hw_si[f"qhat{j}"][i] * hw_si[f"qref{j}"][i] for j in range(4)))
            errs.append(2 * math.acos(min(1.0, d)))
        out["signals"]["estimator_attitude_error"] = {"unit": "deg", "definition": "geodesic angle between the on-board estimate (qhat) and the reference (qref)", **_scaled(_err_stats(errs), 1 / DEG)}
    elif "thetahat" in hw_si and "theta_ref" in hw_si:
        errs = [hw_si["thetahat"][i] - hw_si["theta_ref"][i] for i in range(len(ht))]
        out["signals"]["estimator_attitude_error"] = {"unit": "deg", "definition": "thetahat − theta_ref", **_scaled(_err_stats(errs), 1 / DEG)}
    else:
        out["warnings"].append("No estimator error: the recording has no independent attitude reference (qref*/theta_ref) next to the on-board estimate.")
    dur_h = ht[-1] - ht[0]
    out["quality"] = {"overlap_fraction_of_recording": (t1 - t0) / dur_h if dur_h > 0 else None, "samples_compared": len(idx),
                      "recording": (recording_meta or {}).get("quality")}
    if not out["signals"]:
        out["errors"].append("No signal is present in both the simulation and the recording.")
    if protocol is not None:
        out["acceptance"] = evaluate(out, protocol, recording_meta or {})
    out["ok"] = not out["errors"]
    return out


def metric_value(result, key):
    """'attitude.rmse' → result.signals.attitude.rmse."""
    sig, _, stat = key.rpartition(".")
    s = result["signals"].get(sig)
    return None if s is None else s.get(stat)


def evaluate(result, protocol, recording_meta) -> dict:
    admissible = True
    notes = []
    if recording_meta.get("synthetic"):
        admissible = False
        notes.append("The recording is SYNTHETIC; it cannot be validation evidence.")
    elif recording_meta.get("trust") not in (None, "declared-physical"):
        admissible = False
        notes.append("The recording's origin is not declared by a telemetry source; unknown provenance cannot be validation evidence.")
    if recording_meta.get("derived"):
        admissible = False
        notes.append("The recording was captured from a replay: a copy of earlier data, not an original measurement.")
    if protocol.get("created") and recording_meta.get("created") and protocol["created"] >= recording_meta["created"]:
        admissible = False
        notes.append("The protocol's thresholds were registered after the recording was ingested; acceptance thresholds must be fixed before the data are seen.")
    checks = []
    for key, thr in protocol["thresholds"].items():
        v = metric_value(result, key)
        checks.append({"metric": key, "threshold": thr, "value": v, "pass": (v is not None and v <= thr), "missing": v is None})
    all_pass = bool(checks) and all(c["pass"] for c in checks)
    return {"protocol_id": protocol["id"], "checks": checks, "all_pass": all_pass, "admissible_as_evidence": admissible, "notes": notes,
            "status_change": "none — the backend never marks a model VALIDATED; a person reviews admissible evidence and updates the parameter/model status with a reference to this comparison."}

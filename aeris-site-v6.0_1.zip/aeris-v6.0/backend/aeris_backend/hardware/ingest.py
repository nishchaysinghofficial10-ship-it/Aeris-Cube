"""Strict validation of hardware data: live frames (aeris-telemetry-frame/1) and recordings
(aeris-hardware-run/1). Nothing is coerced: a string where a number belongs, a non-finite value,
a vector of the wrong length, an unknown mode or unit, or a non-unit quaternion is an error with
its path. Accepted recordings are converted to SI and get a data-quality report.

No hardware data ships with this project. Synthetic data used by the tests is generated in the
tests and labelled SYNTHETIC; it is never presented as a measurement."""
from __future__ import annotations

import math
import re

MODES = ("edge", "corner", "free")
STATUS = ("ok", "idle", "calibrating", "fault", "estop")
UNITS = {
    "time": {"s": 1.0, "ms": 1e-3},
    "angle": {"rad": 1.0, "deg": math.pi / 180, "°": math.pi / 180},
    "rate": {"rad/s": 1.0, "deg/s": math.pi / 180, "°/s": math.pi / 180},
    "wheel": {"rad/s": 1.0, "rpm": math.pi / 30},
    "torque": {"N·m": 1.0, "N*m": 1.0, "Nm": 1.0, "mN·m": 1e-3, "mNm": 1e-3},
    "accel": {"m/s²": 1.0, "m/s^2": 1.0, "g": 9.80665},
    "unitless": {"–": 1.0, "-": 1.0, "": 1.0, "1": 1.0},
    "count": {"count": 1.0, "": 1.0, "–": 1.0, "-": 1.0},
    "flag": {"0/1": 1.0, "": 1.0, "–": 1.0},
}
COLUMN_FAMILY = [
    (r"^t$", "time"), (r"^seq$", "count"), (r"^q[0-3]$", "unitless"), (r"^qhat[0-3]$", "unitless"), (r"^qref[0-3]$", "unitless"),
    (r"^theta(hat|_ref)?$", "angle"), (r"^thetadot$", "rate"), (r"^w_[xyz]$", "rate"), (r"^gyro_[xyz]$", "rate"),
    (r"^accel_[xyz]$", "accel"), (r"^omega_[a-z0-9]+$", "wheel"), (r"^wheel_rpm_[a-z0-9]+$", "wheel"),
    (r"^torque_(cmd|meas)_[a-z0-9]+$", "torque"), (r"^T_[a-z0-9]+$", "torque"), (r"^sat$", "flag"), (r"^status$", "count"),
]
ISO = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})$")


def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _vec(f, key, n, E, required=False):
    if key not in f:
        if required:
            E.append(f"{key}: required")
        return None
    v = f[key]
    if not (isinstance(v, list) and len(v) == n and all(_num(x) for x in v)):
        E.append(f"{key}: must be {n} finite numbers (got {str(v)[:60]})")
        return None
    return v


def parse_frame(f) -> dict:
    """aeris-telemetry-frame/1: {t [s], seq, mode, q[4] | theta [rad], w[3] [rad/s],
    wheel_rpm[3] [rpm], torque_cmd[3] [N·m], torque_meas[3] [N·m], imu: {gyro[3] [rad/s],
    accel[3] [m/s²]}, status}. Units are fixed by the schema (SI, wheel speed in rpm)."""
    E = []
    if not isinstance(f, dict):
        return {"ok": False, "errors": ["frame is not an object"]}
    if f.get("schema") not in (None, "aeris-telemetry-frame/1"):
        E.append("schema: expected 'aeris-telemetry-frame/1'")
    if not _num(f.get("t")):
        E.append("t: required finite number (seconds since the start of the recording)")
    elif f["t"] < 0:
        E.append("t: must be ≥ 0")
    if "seq" in f and not (isinstance(f["seq"], int) and not isinstance(f["seq"], bool) and f["seq"] >= 0):
        E.append("seq: must be a non-negative integer")
    if "mode" in f and f.get("mode") not in MODES:   # optional in aeris-telemetry-frame/1; checked when present
        E.append(f"mode: must be one of {', '.join(MODES)}")
    q = _vec(f, "q", 4, E)
    th = f.get("theta")
    if th is not None and not _num(th):
        E.append("theta: must be a finite number [rad]")
    if q is None and th is None and "q" not in f:
        E.append("attitude: q[4] (w, x, y, z) or theta [rad] is required")
    if q is not None:
        n = math.sqrt(sum(x * x for x in q))
        if abs(n - 1) > 1e-3:
            E.append(f"q: not a unit quaternion (|q| = {n:.5f}; tolerance 1e-3)")
    if f.get("mode") == "edge" and th is None and q is None:
        E.append("edge mode needs theta or q")
    for k in ("w", "wheel_rpm", "torque_cmd", "torque_meas"):
        _vec(f, k, 3, E)
    imu = f.get("imu")
    if imu is not None:
        if not isinstance(imu, dict):
            E.append("imu: must be an object {gyro[3], accel[3]}")
        else:
            _vec(imu, "gyro", 3, E)
            _vec(imu, "accel", 3, E)
    if "status" in f and f["status"] not in STATUS:
        E.append(f"status: must be one of {', '.join(STATUS)}")
    extra = [k for k in f if k not in ("schema", "t", "seq", "mode", "q", "theta", "w", "wheel_rpm", "torque_cmd", "torque_meas", "imu", "status")]
    W = [f"unknown field '{k}' ignored" for k in extra]
    return {"ok": not E, "errors": E, "warnings": W}


def family(col: str):
    for pat, fam in COLUMN_FAMILY:
        if re.match(pat, col):
            return fam
    return None


def validate_recording(h) -> dict:
    E, W = [], []
    if not isinstance(h, dict):
        return {"ok": False, "errors": ["The file does not contain a JSON object."], "warnings": []}
    if h.get("schema") != "aeris-hardware-run/1":
        E.append(f"schema: expected 'aeris-hardware-run/1', found {h.get('schema')!r}")
    dev = h.get("device")
    if not isinstance(dev, dict) or not isinstance(dev.get("id"), str) or not dev.get("id"):
        E.append("device.id: required (string)")
    else:
        for k in ("firmware", "imu", "wheels"):
            if k in dev and not isinstance(dev[k], str):
                E.append(f"device.{k}: must be a string")
        if "firmware" not in dev:
            W.append("device.firmware: not given; the comparison cannot name the firmware version.")
    rec = h.get("recording")
    if not isinstance(rec, dict) or not isinstance(rec.get("started"), str) or not ISO.match(rec.get("started", "")):
        E.append("recording.started: required ISO 8601 date-time with time zone (e.g. 2026-09-01T10:00:00Z)")
    if h.get("mode") not in MODES:
        E.append(f"mode: must be one of {', '.join(MODES)}")
    if h.get("synthetic") is True:
        W.append("This recording is marked SYNTHETIC: it is not a measurement and cannot support MEASURED or VALIDATED claims.")
    S = h.get("samples")
    if not isinstance(S, dict) or not isinstance(S.get("cols"), dict) or not isinstance(S.get("units"), dict):
        E.append("samples.cols and samples.units: required objects")
        return {"ok": False, "errors": E, "warnings": W}
    cols, units = S["cols"], S["units"]
    if not isinstance(cols.get("t"), list):
        E.append("samples.cols.t: required")
        return {"ok": False, "errors": E, "warnings": W}
    n = len(cols["t"])
    if n < 2:
        E.append("At least two samples are needed.")
    has_q = all(isinstance(cols.get(f"q{i}"), list) for i in range(4))
    has_th = isinstance(cols.get("theta"), list)
    if not has_q and not has_th:
        E.append("attitude: give quaternion columns q0–q3 (corner/free) or 'theta' (edge)")
    if h.get("mode") == "edge" and not has_th and not has_q:
        E.append("edge mode needs 'theta' (or q0–q3)")
    si = {}
    for c, col in cols.items():
        fam = family(c)
        if fam is None:
            W.append(f"column '{c}': not a recognised signal; kept but not compared")
        if not isinstance(col, list):
            E.append(f"samples.cols.{c}: must be a list")
            continue
        if len(col) != n:
            E.append(f"samples.cols.{c}: {len(col)} rows; 't' has {n}")
            continue
        bad = next((i for i, x in enumerate(col) if not _num(x)), None)
        if bad is not None:
            E.append(f"samples.cols.{c}[{bad}]: {col[bad]!r} is not a finite number (strings, null, NaN and booleans are rejected)")
            continue
        u = units.get(c)
        if fam is not None:
            if u is None:
                E.append(f"samples.units.{c}: required (a {fam} unit: {', '.join(k for k in UNITS[fam] if k)})")
                continue
            if u not in UNITS[fam]:
                E.append(f"samples.units.{c}: '{u}' is not a {fam} unit ({', '.join(k for k in UNITS[fam] if k)})")
                continue
            si[c] = [x * UNITS[fam][u] for x in col]
    if E:
        return {"ok": False, "errors": E, "warnings": W}
    t = si["t"]
    nonmono = [i for i in range(1, n) if not t[i] > t[i - 1]]
    if nonmono:
        E.append(f"samples.cols.t: time must increase strictly (first violation at row {nonmono[0]})")
    if has_q:
        dev_max = 0.0
        for i in range(n):
            nq = math.sqrt(sum(si[f"q{j}"][i] ** 2 for j in range(4)))
            dev_max = max(dev_max, abs(nq - 1))
        if dev_max > 1e-2:
            E.append(f"q0–q3: not unit quaternions (largest |‖q‖ − 1| = {dev_max:.3g}; tolerance 1e-2)")
    if E:
        return {"ok": False, "errors": E, "warnings": W}
    dts = sorted(t[i] - t[i - 1] for i in range(1, n))
    med = dts[len(dts) // 2]
    gaps = [d for d in dts if d > 1.5 * med]
    q = {"n": n, "duration_s": t[-1] - t[0], "median_dt_s": med, "rate_hz_median": 1 / med if med > 0 else None,
         "jitter_s": (dts[int(0.95 * (len(dts) - 1))] - dts[int(0.05 * (len(dts) - 1))]) if dts else 0.0,
         "gaps": len(gaps), "largest_gap_s": max(gaps) if gaps else 0.0}
    if isinstance(cols.get("seq"), list):
        seq = cols["seq"]
        if any(float(x) != int(x) for x in seq):
            E.append("samples.cols.seq: sequence numbers must be integers")
        else:
            steps = [int(seq[i]) - int(seq[i - 1]) for i in range(1, n)]
            q["dropouts"] = sum(s - 1 for s in steps if s > 1)
            q["duplicates_or_reorders"] = sum(1 for s in steps if s < 1)
            if q["duplicates_or_reorders"]:
                E.append(f"samples.cols.seq: {q['duplicates_or_reorders']} duplicate or out-of-order sequence numbers")
    if has_q:
        q["quaternion_norm_max_dev"] = dev_max
    if S.get("rate_hz") is not None and _num(S["rate_hz"]) and q["rate_hz_median"] and abs(S["rate_hz"] - q["rate_hz_median"]) / S["rate_hz"] > 0.05:
        W.append(f"samples.rate_hz = {S['rate_hz']} but the time stamps give {q['rate_hz_median']:.1f} Hz")
    if not isinstance(h.get("parameters"), dict) or not h["parameters"].get("parameter_set"):
        W.append("No 'parameters.parameter_set': the comparison cannot say which model parameters were used.")
    return {"ok": not E, "errors": E, "warnings": W, "quality": q, "si": si, "synthetic": h.get("synthetic") is True}

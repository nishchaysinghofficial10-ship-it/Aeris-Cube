"""Telemetry bridge abstraction (HARDWARE mode). A bridge turns a device link into validated
aeris-telemetry-frame/1 frames with sequence numbers and reports only what the link actually observed.

  NoBridge    telemetry switched off (AERIS_TELEMETRY_BRIDGE=none): every telemetry request says so.
  HubBridge   the reference bridge (default): a TelemetryHub (telemetry/stream.py) fed by ONE source at a time —
              a TCP NDJSON connection (loopback unless the operator allows remote hosts), a replayed NDJSON file
              from the telemetry directory, or a stored recording replayed through the same path. The source is
              chosen at run time (POST /telemetry/connect) or at start-up:
                  AERIS_TELEMETRY_BRIDGE=ndjson-tcp://127.0.0.1:47100     connect at start-up (reconnects)
                  AERIS_TELEMETRY_BRIDGE=file:session.ndjson               replay a file at start-up
              Device-specific links are added as a DeviceAdapter (telemetry/device.py), not as a new bridge.

Everything here is read-only: no bridge sends anything to a device. No bridge can tell whether a physical cube is
attached: the source DECLARES its kind in its hello, the synthetic emulator declares itself synthetic, and a
declared physical source is reported as declared, never as verified.
"""
from __future__ import annotations

import os
import time
from abc import ABC, abstractmethod

from ..telemetry.protocol import PROTOCOL
from ..telemetry.stream import ExportError, TelemetryHub, recording_to_ndjson
from ..telemetry.transport import FileReplaySource, TcpNdjsonSource, check_host


class BridgeError(ValueError):
    def __init__(self, message, details=None, code="invalid_source", status=422):
        super().__init__(message)
        self.details, self.code, self.status = details or [], code, status


class TelemetryBridge(ABC):
    name = "abstract"

    @abstractmethod
    def status(self) -> dict: ...

    @abstractmethod
    async def connect(self, spec: dict | None = None) -> dict: ...

    @abstractmethod
    async def frames(self):
        """Async iterator of validated frames."""

    async def disconnect(self, reason: str = "operator") -> dict:
        return self.status()

    async def close(self) -> None:
        return None


class NoBridge(TelemetryBridge):
    name = "none"
    REASON = "Telemetry is switched off on this backend (AERIS_TELEMETRY_BRIDGE=none)."

    def status(self) -> dict:
        return {"bridge": None, "available": False, "connected": False, "live": False, "reason": self.REASON, "last_frame_t": None, "frames": 0, "dropped": 0,
                "read_only": True}

    async def connect(self, spec=None):
        raise BridgeError(self.REASON, code="telemetry_off", status=409)

    async def frames(self):
        raise ConnectionError(self.REASON)
        yield  # pragma: no cover


class HubBridge(TelemetryBridge):
    name = "ndjson"

    def __init__(self, *, telemetry_dir: str | None = None, allow_remote: bool = False, stale_after_s: float = 0.5, tick_s: float = 0.1,
                 clock=time.monotonic, recording_loader=None, adapter_factory=None):
        self.hub = TelemetryHub(stale_after_s=stale_after_s)
        self.telemetry_dir = os.path.abspath(telemetry_dir or os.path.join(os.getcwd(), "data", "telemetry"))
        self.allow_remote = allow_remote
        self.tick_s = tick_s
        self.clock = clock
        self.source = None
        self.source_spec = None
        self.recording_loader = recording_loader
        self.adapter_factory = adapter_factory
        self._ticker = None
        # stream-quality counters are reported for the current source (since it was connected); the hub keeps the
        # totals since the backend started (counters_total), so a replay never shows an earlier source's duplicates
        self._base, self._base_rej, self._since = {}, {}, None

    # ------------------------------------------------------------------ status
    def status(self) -> dict:
        now = self.clock()
        st = self.hub.status(now)
        prov = st["provenance"]
        src = self.source.describe() if self.source else None
        tot = st["counters"]
        cur = {k: v - self._base.get(k, 0) for k, v in tot.items()}
        cur["reconnects"] = max(0, cur["connects"] - 1)            # a new source's first connection is not a reconnect
        rej = {k: v - self._base_rej.get(k, 0) for k, v in st["rejected_by_reason"].items() if v - self._base_rej.get(k, 0) > 0}
        return dict(st, bridge=self.name, available=True, source=src, source_spec=self.source_spec, telemetry_dir=self.telemetry_dir,
                    allow_remote=self.allow_remote, counters=cur, rejected_by_reason=rej, counters_total=tot,
                    counters_scope="current source, since it was connected" + (f" ({self._since})" if self._since else "") + "; counters_total: since the backend started",
                    # 'live' (a declared physical device streaming now) is never true for an emulator, a test source or a replay
                    live=bool(st["connected"] and prov["declared_physical"] and not prov["replay"] and not st["stale"]),
                    last_frame_t=st["last_t"], frames=cur["frames_accepted"], dropped=cur["dropped_by_source"],
                    reason=None if st["connected"] else ("No telemetry source is connected." if not src else f"Source {src.get('address')}: {src.get('state')}"
                                                         + (f" ({src['last_error']})" if src.get("last_error") else "")))

    # ------------------------------------------------------------------ sources
    def _file_path(self, name: str) -> str:
        if not isinstance(name, str) or not name.strip():
            raise BridgeError("path: required (a file name in the telemetry directory)", [{"path": "path", "message": "required"}])
        p = os.path.abspath(os.path.join(self.telemetry_dir, name))
        if os.path.commonpath([p, self.telemetry_dir]) != self.telemetry_dir:
            raise BridgeError(f"path: only files inside the telemetry directory ({self.telemetry_dir}) can be replayed", [{"path": "path", "message": "outside the telemetry directory"}])
        if not os.path.isfile(p):
            raise BridgeError(f"path: no file '{name}' in the telemetry directory ({self.telemetry_dir})", [{"path": "path", "message": "not found"}])
        return p

    def make_source(self, spec: dict):
        if not isinstance(spec, dict):
            raise BridgeError("The source must be an object {source: 'tcp' | 'file' | 'recording', …}.")
        kind = spec.get("source")
        adapter = None
        if spec.get("adapter"):
            if self.adapter_factory is None:
                raise BridgeError("adapter: no device adapters are configured on this backend", [{"path": "adapter", "message": "unknown adapter"}])
            adapter = self.adapter_factory(spec["adapter"])
        if kind == "tcp":
            host, port = spec.get("host", "127.0.0.1"), spec.get("port")
            err = check_host(host, self.allow_remote)
            if err:
                raise BridgeError(err, [{"path": "host", "message": err}])
            if not (isinstance(port, int) and not isinstance(port, bool) and 1 <= port <= 65535):
                raise BridgeError("port: an integer between 1 and 65535", [{"path": "port", "message": "an integer between 1 and 65535"}])
            return TcpNdjsonSource(self.hub, host, port, reconnect=spec.get("reconnect", True) is not False, allow_remote=self.allow_remote, adapter=adapter, clock=self.clock)
        speed = spec.get("speed", 1.0)
        if not (isinstance(speed, (int, float)) and not isinstance(speed, bool) and 0 <= speed <= 100):
            raise BridgeError("speed: a number from 0 (as fast as possible) to 100", [{"path": "speed", "message": "0–100"}])
        if kind == "file":
            return FileReplaySource(self.hub, path=self._file_path(spec.get("path")), speed=speed, adapter=adapter, clock=self.clock)
        if kind == "recording":
            rid = spec.get("recording_id")
            doc = self.recording_loader(rid) if (self.recording_loader and isinstance(rid, str)) else None
            if doc is None:
                raise BridgeError(f"recording_id: no stored recording '{rid}'", [{"path": "recording_id", "message": "not found"}], code="not_found", status=404)
            omit = spec.get("omit_unmapped", False)
            if not isinstance(omit, bool):
                raise BridgeError("omit_unmapped: true or false", [{"path": "omit_unmapped", "message": "true | false"}])
            try:          # v5.2: wire units, explicit refusals, bounded lineage, checked by a scratch replay (telemetry/export.py)
                text = recording_to_ndjson(doc, rid, omit_unmapped=omit)
            except ExportError as e:
                raise BridgeError(f"recording_id: {e}", e.details, code="export_not_possible", status=422) from None
            return FileReplaySource(self.hub, text=text, label=f"recording:{rid}", speed=speed, clock=self.clock)
        raise BridgeError("source: 'tcp' (NDJSON over TCP), 'file' (NDJSON file in the telemetry directory) or 'recording' (a stored recording)",
                          [{"path": "source", "message": "tcp | file | recording"}])

    async def connect(self, spec: dict | None = None) -> dict:
        src = self.make_source(spec or {})            # validate before touching the current source
        await self.disconnect("replaced by a new source")
        self._base, self._base_rej = dict(self.hub.counters), dict(self.hub.rejected_by_reason)
        self._since = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.hub.last_errors.clear()                  # rejected lines of the previous source are not this source's
        self.source, self.source_spec = src, {k: v for k, v in (spec or {}).items() if k in ("source", "host", "port", "path", "recording_id", "speed", "adapter", "reconnect", "omit_unmapped")}
        src.start()
        self._ensure_ticker()
        return self.status()

    async def disconnect(self, reason: str = "operator") -> dict:
        if self.source is not None:
            await self.source.stop()
            self.hub.on_disconnect("stopped by the operator" if reason == "operator" else reason, self.clock())
        return self.status()

    def _ensure_ticker(self):
        import asyncio
        if self._ticker is None or self._ticker.done():
            async def tick():
                while True:
                    self.hub.tick(self.clock())
                    await asyncio.sleep(self.tick_s)
            self._ticker = asyncio.ensure_future(tick())

    async def frames(self):
        import asyncio
        sub = self.hub.subscribe()
        try:
            while True:
                if sub.event is not None:
                    await sub.event.wait()
                else:
                    await asyncio.sleep(0.05)
                for f in sub.drain():
                    yield f
        finally:
            self.hub.unsubscribe(sub)

    async def close(self):
        import asyncio
        await self.disconnect("backend shutting down")
        if self._ticker is not None:
            self._ticker.cancel()
            try:
                await self._ticker
            except (asyncio.CancelledError, Exception):
                pass


def parse_bridge_setting(name: str | None):
    """AERIS_TELEMETRY_BRIDGE → (bridge kind, start-up source spec or None)."""
    if name is None or name.strip() in ("", "ndjson", "hub", "default"):
        return "ndjson", None
    name = name.strip()
    if name == "none":
        return "none", None
    if name.startswith("ndjson-tcp://"):
        hostport = name[len("ndjson-tcp://"):].rstrip("/")
        host, _, port = hostport.rpartition(":")
        if not host or not port.isdigit():
            raise ValueError(f"AERIS_TELEMETRY_BRIDGE: '{name}' is not ndjson-tcp://HOST:PORT")
        return "ndjson", {"source": "tcp", "host": host.strip("[]"), "port": int(port)}
    if name.startswith("file:"):
        return "ndjson", {"source": "file", "path": name[5:], "speed": 1.0}
    raise ValueError(f"AERIS_TELEMETRY_BRIDGE: unknown value '{name}' (none | ndjson | ndjson-tcp://127.0.0.1:PORT | file:NAME)")


def make_bridge(name: str | None, **kw) -> TelemetryBridge:
    kind, _ = parse_bridge_setting(name)
    if kind == "none":
        return NoBridge()
    return HubBridge(**kw)


__all__ = ["TelemetryBridge", "NoBridge", "HubBridge", "BridgeError", "make_bridge", "parse_bridge_setting", "PROTOCOL"]

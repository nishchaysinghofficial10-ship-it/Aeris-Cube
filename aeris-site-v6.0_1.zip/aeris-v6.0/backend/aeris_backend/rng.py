"""Seeded random numbers, bit-compatible with the browser engine's rng(seed).

AERIS_TWIN.rng is mulberry32 (uniform) plus Box–Muller with a cached spare (normal). The
integer part is reproduced exactly here; the normal values also use log/cos/sin, whose last
bit can differ between JavaScript engines and C libraries, so noise sequences agree with the
browser to within about one unit in the last place (tests/test_parity.py states the tolerance).
"""
from __future__ import annotations

import math

_M32 = 0xFFFFFFFF


def _imul(a: int, b: int) -> int:
    return (a * b) & _M32


class Rng:
    __slots__ = ("a", "spare")

    def __init__(self, seed: int):
        self.a = int(seed) & _M32
        self.spare = None

    def u(self) -> float:
        """Uniform in [0, 1)."""
        self.a = (self.a + 0x6D2B79F5) & _M32
        t = self.a
        t = _imul(t ^ (t >> 15), t | 1)
        t = (t ^ ((t + _imul(t ^ (t >> 7), t | 61)) & _M32)) & _M32
        return ((t ^ (t >> 14)) & _M32) / 4294967296.0

    def n(self) -> float:
        """Standard normal (Box–Muller; the second value of each pair is cached)."""
        if self.spare is not None:
            s = self.spare
            self.spare = None
            return s
        u1 = 0.0
        while u1 == 0.0:
            u1 = self.u()
        u2 = self.u()
        r = math.sqrt(-2.0 * math.log(u1))
        self.spare = r * math.sin(2 * math.pi * u2)
        return r * math.cos(2 * math.pi * u2)


def derive_seed(*parts) -> int:
    """Deterministic 32-bit seed from integers and strings (FNV-1a over the text form).

    Used for paired sweep conditions: the same (base seed, point index, stream name) always
    gives the same seed, independently of controller and of the order runs are executed in.
    """
    h = 0x811C9DC5
    for ch in "|".join(str(p) for p in parts).encode("utf-8"):
        h ^= ch
        h = (h * 0x01000193) & _M32
    return h

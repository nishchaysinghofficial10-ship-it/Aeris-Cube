"""State estimation. Estimators receive observations only (IMU samples and wheel encoders) and
publish an Estimate; controllers read the Estimate, never the true state. The one exception is
the explicit perfect-state baseline ('ideal'), which copies the true attitude and rates and is
labelled as such in every record.

Estimators:
  ideal   perfect-state baseline
  cf, kf, accel, gyro   the browser engine's edge-mode estimators (bit-for-bit algorithm, with
                        the browser's fixed tuning for the nominal sensor)
  cf3d    complementary quaternion filter: gyro propagation, gravity-direction correction with gain
          Δt/(τ+Δt), optional integral bias correction, accelerometer gating
  mekf    multiplicative extended Kalman filter: attitude (quaternion reference + 3-D error) and gyro
          bias, Joseph-form update with the gravity direction, accelerometer gating

Gravity-only correction observes tilt (two angles) but not rotation about the vertical: in
corner mode the estimated yaw drifts with the gyro bias; the MEKF variance of that direction
keeps growing (reported at the end of a run as executed.estimator.stats.final_heading_sd_deg, next to
the bounded final_tilt_sd_deg).

Timing lifecycle of the 3-D filters (cf3d, mekf; docs/ESTIMATION_TIMING.md):

  measurement time t_m   when the IMU sampled the state (the sample's time stamp)
  receipt time  t_r      the control tick at which the sample was delivered (t_r ≥ t_m + latency)
  filter time   t_f      measurement time of the newest processed sample; the filter's update state
                         (q̂_f, b̂, P) refers to t_f
  estimate time t        the control time the controller-facing estimate refers to
  age                    t − t_f

Accepted samples are processed in time-stamp order: propagate the update state from t_f to t_m
with the previous gyro sample (held), apply the accelerometer update, then keep the new gyro
sample. The controller-facing estimate is a prediction that does not change the update state:
    q̂(t) = q̂_f ⊗ exp((ω_m − b̂)(t − t_f)),   ω̂(t) = ω_m − b̂     (ω_m: newest gyro sample)
so the next update propagates from t_f again and no interval is integrated twice. The MEKF
covariance of the prediction, Φ(t − t_f) P Φᵀ + Q_d(t − t_f), is computed on demand
(predicted_covariance) and never written back.

Sequencing policy: a sample whose time stamp equals the filter time is a duplicate, one older than
the filter time arrives out of order; both are rejected (the filter does not re-run history) and
counted. Initialisation: the first accepted sample aligns the filter (tilt from its accelerometer,
heading from the nominal attitude); before that the estimate is the nominal attitude with zero
rate and valid = False. Staleness: the estimate is flagged stale (valid = False) while its age
exceeds estimator.stale_after_s (default: sensor latency + 4 IMU periods). Controllers always
receive the prediction; validity and age are reported with it, per step in the record and as
timeline events, and never change the control law silently.
"""
from __future__ import annotations

import math

import numpy as np

from ..constants import DEG, SENSOR_TUNING
from ..physics.quaternion import (angle_between, cross, exp_vec, from_to, norm, qmul, qnorm, up_in_body)


EPS_T = 1e-12   # time-stamp comparison tolerance [s]


class Estimate:
    """What a controller may read: the controller-facing estimate at the control time t.

    t          estimate time (the control time) [s]
    q, w       attitude (scalar-first, body→world) and body rate [rad/s] at t
    theta, thetadot   edge mode: hinge angle and rate at t
    bias       gyro bias estimate [rad/s]
    t_meas     measurement time of the newest observation behind the estimate [s] (None before the first)
    t_receipt  time that observation was delivered to the estimator [s] (None before the first)
    age        t − t_meas [s] (None before the first observation)
    stale      age > stale_after_s
    valid      False before initialisation and while stale
    source     'truth' (perfect-state baseline, age 0), 'prediction' (3-D filters), 'legacy'
               (browser-parity edge estimators: estimate at the control tick, no prediction)
    """
    __slots__ = ("t", "q", "w", "theta", "thetadot", "bias", "age", "valid", "stale", "t_meas", "t_receipt", "source")

    def __init__(self):
        self.t = 0.0
        self.q = (1.0, 0.0, 0.0, 0.0)
        self.w = (0.0, 0.0, 0.0)
        self.theta = 0.0
        self.thetadot = 0.0
        self.bias = (0.0, 0.0, 0.0)
        self.age = None
        self.valid = False
        self.stale = False
        self.t_meas = None
        self.t_receipt = None
        self.source = None

    def set_truth(self, t):
        """Perfect-state baseline: the true state at t (age 0, always valid)."""
        self.t = self.t_meas = self.t_receipt = t
        self.age = 0.0
        self.valid, self.stale, self.source = True, False, "truth"

    def set_timing(self, t, t_meas, t_receipt, stale_after, source):
        self.t, self.t_meas, self.t_receipt, self.source = t, t_meas, t_receipt, source
        if t_meas is None:
            self.age, self.stale, self.valid = None, False, False
        else:
            self.age = t - t_meas
            self.stale = self.age > stale_after + EPS_T
            self.valid = not self.stale

    def as_dict(self):
        return {k: getattr(self, k) for k in self.__slots__}


def default_stale_after_s(cfg: dict, sample_period_s: float) -> float:
    """estimator.stale_after_s, or the default sensor latency + 4 sample periods."""
    v = (cfg.get("estimator") or {}).get("stale_after_s")
    if v is not None:
        return float(v)
    return cfg["sensor"]["latency_ms"] / 1000.0 + 4.0 * sample_period_s


class EdgeLegacyEstimator:
    """The browser's edge estimators (AERIS_TWIN.simEdge control()), fed by EdgeImuLegacy."""

    def __init__(self, kind: str, cfg: dict, dt: float):
        self.kind = kind
        self.dt = dt
        Rkf = cfg["estimator"].get("Rkf_deg")
        Rkf = Rkf * DEG if Rkf is not None else SENSOR_TUNING["Rkf"]
        self.thHat = 0.0
        self.kx0 = 0.0
        self.kx1 = 0.0
        self.P00 = (5 * DEG) ** 2
        self.P01 = 0.0
        self.P11 = (1 * DEG) ** 2
        self.qa = SENSOR_TUNING["sg"] ** 2 * dt * dt
        self.qb = SENSOR_TUNING["sbw"] ** 2 * dt
        self.Rk = Rkf * Rkf
        self.alpha = SENSOR_TUNING["tauCf"] / (SENSOR_TUNING["tauCf"] + dt)

    def update(self, wm: float, am: float) -> tuple[float, float]:
        dt = self.dt
        k = self.kind
        if k == "accel":
            return am, wm
        if k == "gyro":
            self.thHat += wm * dt
            return self.thHat, wm
        if k == "cf":
            self.thHat = self.alpha * (self.thHat + wm * dt) + (1 - self.alpha) * am
            return self.thHat, wm
        # kf: angle + gyro bias
        self.kx0 = self.kx0 + (wm - self.kx1) * dt
        P00, P01, P11 = self.P00, self.P01, self.P11
        nP00 = P00 - dt * (P01 + P01) + dt * dt * P11 + self.qa
        nP01 = P01 - dt * P11
        nP11 = P11 + self.qb
        P00, P01, P11 = nP00, nP01, nP11
        Sk = P00 + self.Rk
        K0, K1 = P00 / Sk, P01 / Sk
        inn = am - self.kx0
        self.kx0 += K0 * inn
        self.kx1 += K1 * inn
        self.P00, self.P01, self.P11 = (1 - K0) * P00, (1 - K0) * P01, P11 - K1 * P01
        return self.kx0, wm - self.kx1

    @property
    def bias(self):
        return self.kx1 if self.kind == "kf" else 0.0


class Attitude3DBase:
    """Common parts of the quaternion estimators.

    Dynamic-acceleration compensation (on by default, estimator.<kind>.compensate_dynamic): the
    accelerometer measures f = g·û + α×r + ω×(ω×r) at the IMU position r (a known installation
    parameter, not the true state). The filters remove α̂×r + ω̂×(ω̂×r), with ω̂ = gyro − b̂ and α̂ a
    low-passed (time constant tau_alpha_s) finite difference of ω̂, before using the remaining
    vector as the gravity direction; then they gate samples whose norm is further than
    accel_gate_mps2 from g."""

    def __init__(self, cfg: dict, q_nominal, settings: dict | None = None):
        from ..constants import D_EDGE
        settings = settings or {}
        self.q = tuple(q_nominal)
        self.q_nominal = tuple(q_nominal)
        self.b = np.zeros(3)
        self.t = None
        self.last_gyro = None
        self.initialised = False
        self.g = cfg["params"]["g"]
        self.gated = 0
        self.updates = 0
        pos = cfg["sensor"].get("imu_position_m")
        if pos is None:
            base = D_EDGE if cfg["mode"] == "edge" else (1 / math.sqrt(3),) * 3
            pos = [c * cfg["params"]["rImu"] for c in base]
        self.r = np.array(pos, dtype=float)
        self.compensate = settings.get("compensate_dynamic", True) is not False
        self.tau_a = settings.get("tau_alpha_s") or 0.02
        self.alpha = np.zeros(3)
        self.prev_w = None
        self.t_receipt = None           # delivery time of the newest processed sample
        self.t_init = None              # measurement time of the aligning sample
        self.t_init_receipt = None      # when it was delivered: the estimate is valid from here on
        self.processed = 0
        self.rejected_duplicate = 0
        self.rejected_out_of_order = 0
        self.max_gap_s = 0.0            # largest interval between consecutive processed samples

    def accept(self, s, t_receipt) -> bool:
        """Sequencing policy, then process(). Returns False for a rejected (duplicate or
        out-of-order) sample; the filter state is then unchanged."""
        if self.initialised and self.t is not None and s.t <= self.t + EPS_T:
            if abs(s.t - self.t) <= EPS_T:
                self.rejected_duplicate += 1
            else:
                self.rejected_out_of_order += 1
            return False
        if self.initialised and self.t is not None:
            self.max_gap_s = max(self.max_gap_s, s.t - self.t)
        self.process(s)
        self.t_receipt = t_receipt
        self.processed += 1
        if self.t_init is None:
            self.t_init = s.t
            self.t_init_receipt = t_receipt
        return True

    def predict(self, t):
        """Controller-facing attitude and rate at time t (≥ the filter time), from the update
        state and the newest gyro sample; the filter state is not changed. Before the first
        sample: the nominal attitude and zero rate."""
        if not self.initialised or self.last_gyro is None:
            return self.q, (0.0, 0.0, 0.0)
        w = self.last_gyro - self.b
        h = t - self.t
        wt = (float(w[0]), float(w[1]), float(w[2]))
        if h <= EPS_T:
            return self.q, wt
        return qnorm(qmul(self.q, exp_vec((wt[0] * h, wt[1] * h, wt[2] * h)))), wt

    def dynamic(self, gyro, dt):
        """α̂×r + ω̂×(ω̂×r) from the gyro (zero when compensation is off)."""
        w = np.array(gyro) - self.b
        if self.prev_w is not None and dt > 0:
            raw = (w - self.prev_w) / dt
            k = dt / (self.tau_a + dt)
            self.alpha = self.alpha + k * (raw - self.alpha)
        self.prev_w = w
        if not self.compensate:
            return np.zeros(3)
        return np.cross(self.alpha, self.r) + np.cross(w, np.cross(w, self.r))

    def align(self, accel, gyro=None):
        """Alignment from the first sample: tilt from its accelerometer vector, heading from the
        nominal attitude (gravity says nothing about heading). With dynamic compensation on, the
        centripetal part ω_m × (ω_m × r) is removed first (v5; the angular acceleration and the bias
        are unknown at this point and taken as zero)."""
        if gyro is not None and self.compensate:
            w = np.array(gyro, dtype=float)
            accel = tuple(np.array(accel, dtype=float) - np.cross(w, np.cross(w, self.r)))
        n = norm(accel)
        if n <= 0:
            return
        up_meas = (accel[0] / n, accel[1] / n, accel[2] / n)
        up_nom = up_in_body(self.q_nominal)
        self.q = qnorm(qmul(self.q_nominal, from_to(up_meas, up_nom)))
        self.initialised = True

    def propagate(self, t):
        if self.t is None or self.last_gyro is None:
            self.t = t
            return 0.0
        dt = t - self.t
        if dt <= 0:
            return 0.0
        w = self.last_gyro - self.b
        self.q = qnorm(qmul(self.q, exp_vec((w[0] * dt, w[1] * dt, w[2] * dt))))
        self.t = t
        return dt

    def rate(self):
        if self.last_gyro is None:
            return (0.0, 0.0, 0.0)
        w = self.last_gyro - self.b
        return (float(w[0]), float(w[1]), float(w[2]))


class ComplementaryAttitude(Attitude3DBase):
    def __init__(self, cfg: dict, q_nominal):
        c = cfg["estimator"].get("cf3d") or {}
        super().__init__(cfg, q_nominal, c)
        self.tau = c.get("tau_s", 0.5)
        self.gate = c.get("accel_gate_mps2", 0.5)
        self.kb = c.get("bias_gain", 0.0)

    def process(self, s):
        if not self.initialised:
            self.align(s.accel, s.gyro)
            self.t = s.t
            self.last_gyro = np.array(s.gyro)
            return
        dt = self.propagate(s.t)
        self.last_gyro = np.array(s.gyro)
        f = np.array(s.accel) - self.dynamic(s.gyro, dt)
        n = float(np.linalg.norm(f))
        if dt <= 0 or n <= 0 or abs(n - self.g) > self.gate:
            self.gated += 1 if (n > 0 and abs(n - self.g) > self.gate) else 0
            return
        up_meas = (f[0] / n, f[1] / n, f[2] / n)
        up_hat = up_in_body(self.q)
        e = cross(up_meas, up_hat)
        k = dt / (self.tau + dt)
        self.q = qnorm(qmul(self.q, exp_vec((k * e[0], k * e[1], k * e[2]))))
        if self.kb:
            self.b = self.b - self.kb * dt * np.array(e)
        self.updates += 1

    def covariance(self):
        return None

    def predicted_covariance(self, t):
        return None


class Mekf(Attitude3DBase):
    """Multiplicative EKF, error state δx = [δθ (body-frame attitude error), δb (gyro bias)].

    Propagation over Δt with ω̂ = ω_m − b̂:  q̂ ← q̂ ⊗ exp(ω̂ Δt),
        Φ = [[exp(−[ω̂Δt]×), −IΔt], [0, I]],
        Q_d = [[((σ_g Δt)² + σ_bw² Δt³/3) I, −σ_bw² Δt²/2 I], [−σ_bw² Δt²/2 I, σ_bw² Δt I]]
        (σ_g is the per-sample gyro noise, σ_bw the bias random-walk density).
    Update with the measured gravity direction z = f/|f|, f = a_m − (α̂×r + ω̂×(ω̂×r)) (gated when
    ||f| − g| > gate):  h(q̂) = R̂ᵀ e_z,  H = [[h]×, 0],  R_m = ((σ_a/g)² + σ_dir²) I with
    σ_dir = accel_direction_sd_deg (default 1°), Joseph form, then δθ is reset into q̂ and δb added
    to b̂, and the covariance is carried through the reset Jacobian G = diag(I − ½[δθ̂]×, I)
    (v4 took G = I). The covariance is symmetrised after every propagation and update.
    The update state (q̂, b̂, P) refers to the filter time; predict()/predicted_covariance() give the
    controller-facing values at a later time without changing it.
    """

    def __init__(self, cfg: dict, q_nominal):
        from ..sensors import nominal_sensor_for
        m = cfg["estimator"].get("mekf") or {}
        super().__init__(cfg, q_nominal, m)
        nom = nominal_sensor_for(cfg)
        self.sg = (m.get("gyro_noise_dps") if m.get("gyro_noise_dps") is not None else nom["gyro_noise_dps"]) * DEG
        self.sbw = (m.get("gyro_bias_walk_dps") if m.get("gyro_bias_walk_dps") is not None else nom["gyro_bias_walk_dps"]) * DEG
        sa = m.get("accel_noise_mps2") if m.get("accel_noise_mps2") is not None else nom["accel_noise_mps2"]
        # direction noise of the gravity measurement: sensor noise plus what compensation leaves of
        # the dynamic acceleration (accel_direction_sd_deg, default 1°), added in quadrature
        dsd = (m.get("accel_direction_sd_deg") if m.get("accel_direction_sd_deg") is not None else 1.0) * DEG
        self.Rm = max(1e-12, (sa / self.g) ** 2 + dsd ** 2)
        self.gate = m.get("accel_gate_mps2", 0.5) if m.get("accel_gate_mps2") is not None else 0.5
        a0 = (m.get("init_attitude_sd_deg") or 5.0) * DEG
        b0 = (m.get("init_bias_sd_dps") or 1.0) * DEG
        self.P = np.diag([a0 ** 2] * 3 + [b0 ** 2] * 3)

    def _propagate_cov(self, P, w, dt):
        """Φ P Φᵀ + Q_d over dt with the held rate estimate w (symmetrised)."""
        wv = w * dt
        ang = float(np.linalg.norm(wv))
        K = np.array([[0, -wv[2], wv[1]], [wv[2], 0, -wv[0]], [-wv[1], wv[0], 0]])
        if ang > 1e-12:
            Rt = np.eye(3) - math.sin(ang) / ang * K + (1 - math.cos(ang)) / ang ** 2 * (K @ K)
        else:
            Rt = np.eye(3) - K
        Phi = np.eye(6)
        Phi[:3, :3] = Rt
        Phi[:3, 3:] = -np.eye(3) * dt
        Qd = np.zeros((6, 6))
        qth = (self.sg * dt) ** 2 + self.sbw ** 2 * dt ** 3 / 3
        Qd[:3, :3] = np.eye(3) * qth
        Qd[:3, 3:] = Qd[3:, :3] = -np.eye(3) * self.sbw ** 2 * dt ** 2 / 2
        Qd[3:, 3:] = np.eye(3) * self.sbw ** 2 * dt
        Pn = Phi @ P @ Phi.T + Qd
        return 0.5 * (Pn + Pn.T)

    def process(self, s):
        if not self.initialised:
            self.align(s.accel, s.gyro)
            self.t = s.t
            self.last_gyro = np.array(s.gyro)
            return
        w = self.last_gyro - self.b
        dt = self.propagate(s.t)
        if dt > 0:
            self.P = self._propagate_cov(self.P, w, dt)
        self.last_gyro = np.array(s.gyro)
        f = np.array(s.accel) - self.dynamic(s.gyro, dt)
        n = float(np.linalg.norm(f))
        if n <= 0 or abs(n - self.g) > self.gate:
            if n > 0:
                self.gated += 1
            return
        z = f / n
        h = np.array(up_in_body(self.q))
        H = np.zeros((3, 6))
        H[:, :3] = np.array([[0, -h[2], h[1]], [h[2], 0, -h[0]], [-h[1], h[0], 0]])
        S = H @ self.P @ H.T + np.eye(3) * self.Rm
        Kg = self.P @ H.T @ np.linalg.inv(S)
        dx = Kg @ (z - h)
        IKH = np.eye(6) - Kg @ H
        P = IKH @ self.P @ IKH.T + Kg @ (np.eye(3) * self.Rm) @ Kg.T
        # reset: fold δθ into q̂ and δb into b̂; the error of the reset attitude is
        # δθ' ≈ δθ − δθ̂ − ½ δθ̂ × δθ, so the covariance is carried through G = diag(I − ½[δθ̂]×, I)
        dth = dx[:3]
        G = np.eye(6)
        G[:3, :3] = np.eye(3) - 0.5 * np.array([[0, -dth[2], dth[1]], [dth[2], 0, -dth[0]], [-dth[1], dth[0], 0]])
        P = G @ P @ G.T
        self.P = 0.5 * (P + P.T)
        self.q = qnorm(qmul(self.q, exp_vec((float(dx[0]), float(dx[1]), float(dx[2])))))
        self.b = self.b + dx[3:]
        self.updates += 1

    def covariance(self):
        """Covariance of the update state (at the filter time)."""
        return self.P

    def predicted_covariance(self, t):
        """Covariance of the controller-facing prediction at time t (not stored)."""
        if not self.initialised or self.last_gyro is None or t - self.t <= EPS_T:
            return self.P.copy()
        return self._propagate_cov(self.P, self.last_gyro - self.b, t - self.t)


def attitude_error(q_true, q_est) -> float:
    return angle_between(q_true, q_est)

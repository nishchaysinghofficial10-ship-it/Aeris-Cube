"""Constants shared with the browser engine, plus the backend's research defaults.

The browser engine's nominal parameters, ranges, assessment rules and definition texts are
loaded from data/browser_constants.json, which tools/export_browser_constants.js generates
from site/js/core.js. Using the exported file (instead of retyping the values) keeps the two
engines' legacy definitions identical; tests/test_constants.py checks the file is current.
"""
from __future__ import annotations

import copy
import json
import math
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_HERE, "data", "browser_constants.json"), encoding="utf-8") as _f:
    BROWSER = json.load(_f)

DEG = math.pi / 180.0
RPM = math.pi / 30.0

NOMINAL = BROWSER["NOMINAL"]
PARAM_SPEC = BROWSER["PARAM_SPEC"]
WEIGHTS = BROWSER["WEIGHTS"]
SENSOR_TUNING = BROWSER["SENSOR"]            # nominal sensor the browser estimators are tuned for
SENSOR_DEFAULTS = BROWSER["SENSOR_DEFAULTS"]
SENSOR_SPEC = BROWSER["SENSOR_SPEC"]
ACTUATOR_DEFAULTS = BROWSER["ACTUATOR_DEFAULTS"]
ASSESS = BROWSER["ASSESS"]
OUTCOMES = BROWSER["OUTCOMES"]
METRIC_DEFS = BROWSER["METRIC_DEFS"]
EVENT_RULES = BROWSER["EVENT_RULES"]
EVENT_DEFS = BROWSER["EVENT_DEFS"]
BROWSER_MODEL = BROWSER["model"]
WHEELS = ("x", "y", "z")

# Geometry constants of the browser engine (corner balance reference frame, edge line).
CH = tuple(BROWSER["CH"])
QEQ = tuple(BROWSER["QEQ"])
E1 = tuple(BROWSER["E1"])
E2 = tuple(BROWSER["E2"])
D_EDGE = tuple(BROWSER["D_EDGE"])
N_EDGE = tuple(BROWSER["N_EDGE"])

# ---------------------------------------------------------------------------------------
# Research extensions (aeris-config/1 revision 1.1). Absent blocks keep legacy semantics.
# ---------------------------------------------------------------------------------------
CONTROLLER_TYPES = ("pid", "lqr", "adp", "nlpd", "none")
CONTROLLER_NAMES = {
    "pid": "PID", "lqr": "LQR", "adp": "COM-adaptive LQR", "none": "No control",
    "nlpd": "Nonlinear model-compensated quaternion PD",
}
STRUCTURES = ("decoupled", "mimo-lqr")
EDGE_ESTIMATORS = ("ideal", "cf", "kf", "accel", "gyro", "cf3d", "mekf")
CORNER_ESTIMATORS = ("ideal", "cf3d", "mekf")
ESTIMATOR_NAMES = {
    "ideal": "Ideal state (perfect-state baseline; the controller sees the true state)",
    "cf": "Complementary filter (browser edge estimator)",
    "kf": "Two-state Kalman filter, angle + gyro bias (browser edge estimator)",
    "accel": "Accelerometer angle only (browser edge estimator)",
    "gyro": "Gyro integration only (browser edge estimator)",
    "cf3d": "Complementary attitude filter (quaternion, gravity correction)",
    "mekf": "Multiplicative extended Kalman filter (quaternion attitude + gyro bias)",
}
DISTURBANCE_TYPES = ("force", "torque", "impulse", "force_impulse", "bias")
EVENT_TYPES = ("wheel_failure", "wheel_degradation", "wheel_torque_limit", "wheel_speed_limit")
YAW_OBJECTIVES = ("hold", "free")

RECOVERY_DEFAULTS = {
    "attitude_error_deg": 0.5,   # quaternion geodesic error to the target attitude
    "rate_dps": 2.0,             # body-rate magnitude (the yaw component is excluded when yaw is free)
    "hold_s": 1.0,               # both thresholds held continuously for at least this long
    "max_time_s": None,          # recovery must be reached by this time (None = the window)
    "yaw_objective": "hold",     # corner: 'hold' = the commanded heading is part of the target; 'free' = tilt only
}
TERMINATION_DEFAULTS = {
    "stop_on_recovery": False,   # stop the run once the research recovery criteria are met
    "post_fall_s": 1.5,          # keep recording this long after a fall (browser behaviour)
    "check_lift_off": True,      # end the run if the pivot would have to pull the cube down
    "overspeed_rpm": None,       # safety limit: end the run if any wheel exceeds this speed
    "max_quaternion_drift": 1e-4,  # |‖q‖ − 1| after one RK4 step (before renormalisation) that counts as a numerical failure
}
LQR_DEFAULTS = {
    "tilt_deg": WEIGHTS["th"] / DEG, "rate_dps": WEIGHTS["thd"] / DEG, "wheel_rad_s": WEIGHTS["ww"],
    "yaw_deg": WEIGHTS["psi"] / DEG, "yaw_rate_dps": WEIGHTS["psid"] / DEG, "r_scale": 1.0,
}
PID_DEFAULTS = {"integrator_pole": WEIGHTS["pint"], "yaw_integrator_pole": WEIGHTS["pinty"],
                "anti_windup": "clamp",        # clamp: integral bounded by τmax/Ki (browser); conditional: also stop integrating while saturated in the same direction
                "reset_on_events": False}      # True: integrators reset at wheel events (failure/degradation/limits) and yaw-command steps
ADAPTIVE_DEFAULTS = {"gamma": WEIGHTS["gam"], "clamp_deg": 6.0}
NONLINEAR_DEFAULTS = {
    "omega_n": 14.0,         # tilt error natural frequency [rad/s]
    "zeta": 0.9,             # tilt error damping ratio
    "yaw_omega_n": 4.0, "yaw_zeta": 1.0,
    "momentum_omega": 0.8,   # outer momentum loop natural frequency [rad/s] (critically damped)
    "max_ref_tilt_deg": 6.0, # limit on the tilt offset commanded by the momentum loop
    "compensate_gravity": True, "compensate_gyroscopic": True, "compensate_friction": True,
}
ALLOCATION_METHODS = ("clip", "bounded-ls")
ELECTRICAL_LIMIT_MODES = ("command", "continuous")
MEKF_DEFAULTS = {
    "gyro_noise_dps": None, "gyro_bias_walk_dps": None, "accel_noise_mps2": None,  # None = the configured sensor
    "init_attitude_sd_deg": 5.0, "init_bias_sd_dps": 1.0, "accel_gate_mps2": 0.5,
    "accel_direction_sd_deg": 1.0, "tau_alpha_s": 0.02, "compensate_dynamic": True,
}
CF3D_DEFAULTS = {"tau_s": 0.5, "accel_gate_mps2": 0.5, "bias_gain": 0.0, "tau_alpha_s": 0.02, "compensate_dynamic": True}

# Engine limits the backend accepts (reported by GET /capabilities; enforced by validation).
BACKEND_LIMITS = {
    "maxDuration_s": 600.0, "minDuration_s": 0.5,
    "maxIntegration_hz": 20000.0, "maxRecord_hz": 1000.0, "minRecord_hz": 1.0,
    "maxSteps_per_run": 5_000_000, "maxAttachments": 32, "maxComponents": 32, "maxWheels": 6,
    "maxRuns_per_sweep": 100_000, "maxSteps_per_job": 2_000_000_000,
}


def clone(o):
    return copy.deepcopy(o)

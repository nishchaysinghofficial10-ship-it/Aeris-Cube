"""Local development server.

    python -m aeris_backend.api.main [--host 127.0.0.1] [--port 8750] [--db data/aeris.sqlite3]
                                     [--workers N] [--max-jobs 2] [--cors http://localhost:8000,...]
                                     [--restart-policy resume|fail] [--dev]
                                     [--telemetry ndjson|none|ndjson-tcp://127.0.0.1:47100|file:NAME]
                                     [--telemetry-dir data/telemetry] [--serve-site ../site]

Command-line options override the AERIS_* environment variables (backend/README.md). The server
binds to 127.0.0.1 by default; put an authenticating reverse proxy in front of it before exposing it
on a network (backend/README.md, "Deployment"). v6.0: the device API (/api/v6) is enabled in local mode only on a
loopback bind; a networked deployment uses AERIS_AUTH=jwt (devices/auth.py)."""
from __future__ import annotations

import argparse
import os


def main(argv=None):
    import uvicorn
    ap = argparse.ArgumentParser(description="AERIS research backend (development server)")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8750)
    ap.add_argument("--db", help="SQLite database file (AERIS_DB); default ./data/aeris.sqlite3")
    ap.add_argument("--workers", type=int, help="simulation worker processes (AERIS_WORKERS); default min(4, CPUs)")
    ap.add_argument("--max-jobs", type=int, help="jobs executed at the same time (AERIS_MAX_JOBS); default 2")
    ap.add_argument("--cors", help="comma-separated allowed browser origins (AERIS_CORS_ORIGINS)")
    ap.add_argument("--restart-policy", choices=("resume", "fail"), help="what happens to unfinished jobs after a restart (AERIS_RESTART_POLICY)")
    ap.add_argument("--dev", action="store_true", help="also allow the 'null' origin (pages opened from file://)")
    ap.add_argument("--telemetry", help="telemetry bridge (AERIS_TELEMETRY_BRIDGE): ndjson (default), none, ndjson-tcp://127.0.0.1:PORT, file:NAME")
    ap.add_argument("--telemetry-dir", help="directory of replayable NDJSON sessions (AERIS_TELEMETRY_DIR); default ./data/telemetry")
    ap.add_argument("--serve-site", metavar="DIR", help="also serve the static site from DIR on this origin (AERIS_SITE_DIR); open http://HOST:PORT/")
    ap.add_argument("--log-level", default="info")
    a = ap.parse_args(argv)
    env = {"AERIS_DB": a.db, "AERIS_WORKERS": a.workers, "AERIS_MAX_JOBS": a.max_jobs, "AERIS_CORS_ORIGINS": a.cors,
           "AERIS_RESTART_POLICY": a.restart_policy, "AERIS_DEV": "1" if a.dev else None,
           "AERIS_TELEMETRY_BRIDGE": a.telemetry, "AERIS_TELEMETRY_DIR": a.telemetry_dir, "AERIS_SITE_DIR": a.serve_site}
    if a.serve_site:
        # the page and the API share one origin; it must be allowed for the WebSocket origin check as well
        own = [f"http://{a.host}:{a.port}", f"http://localhost:{a.port}", f"http://127.0.0.1:{a.port}"]
        cur = [o for o in (a.cors or os.environ.get("AERIS_CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000")).split(",") if o]
        env["AERIS_CORS_ORIGINS"] = ",".join(dict.fromkeys(cur + own))
    env["AERIS_BIND_HOST"] = a.host       # the device API refuses local (unauthenticated) mode on a non-loopback bind
    from ..telemetry.transport import is_loopback
    if not is_loopback(a.host) and (os.environ.get("AERIS_AUTH") or "local") != "jwt":
        print(f"WARNING: binding to {a.host} exposes the backend beyond this computer without authentication (AERIS_AUTH=local): "
              "the device API (/api/v6) stays disabled; see backend/README.md 'Remote hosting' (AERIS_AUTH=jwt behind a TLS proxy).", flush=True)
    for k, v in env.items():
        if v is not None:
            os.environ[k] = str(v)
    uvicorn.run("aeris_backend.api.app:create_app", factory=True, host=a.host, port=a.port, log_level=a.log_level)


if __name__ == "__main__":
    main()

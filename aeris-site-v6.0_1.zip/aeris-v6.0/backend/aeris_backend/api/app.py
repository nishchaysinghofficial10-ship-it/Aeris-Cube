"""FastAPI application: the /api/v1 contract of site/docs/BACKEND_INTEGRATION.md plus the
documented research endpoints (validation, reproduction, datasets, parameter sets, hardware).

Errors always use the envelope {"error": {code, message, details, retryable}}.
Local start:   python -m aeris_backend.api.main     (or: uvicorn aeris_backend.api.app:create_app --factory)
Settings (environment):
  AERIS_DB              SQLite file (default ./data/aeris.sqlite3)
  AERIS_WORKERS         simulation worker processes (default min(4, CPUs))
  AERIS_MAX_JOBS        jobs executed concurrently (default 2)
  AERIS_CORS_ORIGINS    comma-separated allowed origins (default http://localhost:8000,http://127.0.0.1:8000)
  AERIS_DEV=1           also allow the 'null' origin (the site opened from file://) — development only
  AERIS_RESTART_POLICY  resume | fail (docs/JOBS_AND_RECOVERY.md)
  AERIS_MAX_JOB_ATTEMPTS  dispatches of one job before it is failed with 'retry_limit' (default 3)
  AERIS_TELEMETRY_BRIDGE  ndjson (default: telemetry available, no source until one is connected) | none (switched off)
                        | ndjson-tcp://127.0.0.1:PORT (connect at start-up) | file:NAME (replay at start-up) — docs/TELEMETRY.md
  AERIS_TELEMETRY_DIR   directory whose NDJSON files may be replayed (default ./data/telemetry)
  AERIS_TELEMETRY_ALLOW_REMOTE=1  allow telemetry sources on other hosts (default: loopback only)
  AERIS_TELEMETRY_MAX_LIVE  simultaneous live telemetry WebSockets (default 4)
  AERIS_SITE_DIR        serve the static site from this directory on the same origin (the page gets its research-backend
                        address from the server, so nothing in the site files has to be edited; used by scripts/start.sh)
  AERIS_TELEMETRY_ADAPTERS  JSON file {name: mapping} of device mappings (telemetry/device.py MappedJsonAdapter);
                        a source then names one: POST /telemetry/connect {"source": "tcp", …, "adapter": name}
  AERIS_AUTH            local (default: one owner, this computer) | jwt (bearer tokens of the configured identity
                        provider; AERIS_JWT_* and AERIS_PUBLIC_ORIGIN — devices/auth.py, site/docs/CONNECT.md §Security)
  AERIS_BIND_HOST       the address the server is bound to (set by main.py; local mode refuses a non-loopback bind)
The database is locked for this process (<db>.lock): one backend process per database.
local mode: no credentials are needed or accepted from the browser, and the device API (/api/v6) is offered only on a
loopback bind. jwt mode (v6.0): every /api/v1 and /api/v6 request except /health, /capabilities and /api/v6/status
carries a bearer token; device data, profiles, calibrations, configurations, commands, device recordings and twin runs
belong to their owner (404 for anyone else); the global v1 telemetry bridge is switched off (per-device telemetry is
in /api/v6). Never put keys in the site.
"""
from __future__ import annotations

import asyncio
import contextlib
import copy
import json
import math
import os
import uuid

from fastapi import FastAPI, Query, Request, WebSocket, WebSocketDisconnect
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel, ConfigDict, Field
from starlette.concurrency import run_in_threadpool
from starlette.exceptions import HTTPException as StarletteHTTPException

from ..config.validate import validate_config
from ..config.normalize import HEADINGS, REFERENCE_ATTITUDES
from ..constants import (BACKEND_LIMITS, CONTROLLER_NAMES, CORNER_ESTIMATORS, DISTURBANCE_TYPES, EDGE_ESTIMATORS, ESTIMATOR_NAMES,
                         EVENT_TYPES, NOMINAL, PARAM_SPEC, RECOVERY_DEFAULTS, TERMINATION_DEFAULTS, YAW_OBJECTIVES)
from ..experiments import datasets as DSI
from ..experiments import sweeps as SW
from ..experiments.compare import compare_runs
from ..experiments.records import canonical_hash, now_iso, to_csv
from ..experiments.provenance import PS_REVISION, apply_parameter_set, canonical_path, check_value, set_status
from ..experiments.reproduce import reproduction_config
from ..metrics.research import METRICS_VERSION
from ..hardware import compare as HWC
from ..hardware.bridge import BridgeError, make_bridge, parse_bridge_setting
from ..hardware.ingest import parse_frame, validate_recording
from ..telemetry.protocol import PROTOCOL as TELEMETRY_PROTOCOL
from ..telemetry import lineage as LIN
from ..telemetry.stream import ExportError, recording_to_ndjson
from ..jobs.manager import InvalidRequest, JobManager
from ..storage.base import TERMINAL, IntegrityError
from ..storage.sqlite import SqliteRepository
from ..version import (API_PREFIX, BACKEND_NAME, BACKEND_VERSION, CONFIG_REVISION, CONFIG_REVISIONS_READ, ENGINE_VERSION, PARITY_TARGET, RUN_REVISION,
                       SWEEP_REVISION, software_versions)
from ..devices.auth import AuthConfig, AuthError, Authenticator
from .errors import ApiError, envelope  # noqa: F401  (ApiError and envelope stay importable from this module)

NOMINAL_SET = {"id": "nominal-design-v1", "status": "nominal", "created": None, "values": None,
               "note": "The browser engine's nominal design values (site/js/core.js NOMINAL). Not measurements."}


class Loose(BaseModel):
    model_config = ConfigDict(extra="allow")


class SimulationRequest(BaseModel):
    config: dict
    meta: dict = Field(default_factory=dict)
    client: dict = Field(default_factory=dict)
    parameter_set: str | None = Field(default=None, description="id of a stored parameter set whose values replace config.params")


class SweepRequest(BaseModel):
    sweep: dict
    parameter_set: str | None = Field(default=None, description="id of a stored parameter set applied to the sweep's base setup")


class ValidateRequest(BaseModel):
    config: dict | None = None
    sweep: dict | None = None


class CompareRequest(BaseModel):
    run_ids: list[str] = Field(min_length=1, max_length=50)


class DatasetCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    run_ids: list[str] = Field(default_factory=list)
    sweep_ids: list[str] = Field(default_factory=list)
    recording_ids: list[str] = Field(default_factory=list)
    description: str = ""


class ParameterValue(BaseModel):
    value: float | list[float] | list[list[float]]
    unit: str
    method: str = Field(min_length=3)
    date: str = Field(min_length=10)
    evidence: str = Field(min_length=3, description="where the measurement is documented (file, notebook page, photo id)")
    uncertainty: float | None = None


class ParameterSetCreate(BaseModel):
    id: str | None = None
    label: str = ""
    values: dict[str, ParameterValue] = Field(description="configuration path (docs/PARAMETERS.md) → measured value; legacy bare parameter names mean params.<name>")
    supersedes: str | None = Field(default=None, description="id of the parameter set this version replaces (sets are immutable; a new version gets a new id)")


class ProtocolCreate(BaseModel):
    name: str = Field(min_length=3)
    description: str = ""
    thresholds: dict[str, float] = Field(min_length=1, description="metric key (e.g. 'attitude.rmse', 'wheel_x.rmse') → maximum allowed value")


class RecordingStart(BaseModel):
    name: str = Field(default="telemetry recording", min_length=1, max_length=200)


class HardwareCompareRequest(BaseModel):
    run_id: str
    recording_id: str
    protocol_id: str | None = None
    max_lag_s: float = Field(default=0.25, ge=0, le=5)


def adapter_factory_from(path):
    """Device mappings from a JSON file {name: mapping} (docs/HARDWARE_HANDOFF.md §1B). Each mapping is checked when
    the backend starts, so a bad mapping fails loudly instead of at the first connection."""
    if not path:
        return None
    from ..telemetry.device import MappedJsonAdapter, check_mapping
    with open(path, encoding="utf-8") as fh:
        maps = json.load(fh)
    if not isinstance(maps, dict) or not maps:
        raise ValueError(f"AERIS_TELEMETRY_ADAPTERS: {path} must hold an object {{name: mapping}}")
    for name, m in maps.items():
        errs = check_mapping(m)
        if errs:
            raise ValueError(f"AERIS_TELEMETRY_ADAPTERS: mapping '{name}': " + "; ".join(errs))

    def factory(name):
        if name not in maps:
            raise BridgeError(f"adapter: no device mapping '{name}' (configured: {', '.join(sorted(maps))})", [{"path": "adapter", "message": "unknown adapter"}])
        return MappedJsonAdapter(maps[name])
    return factory


def settings_from_env():
    origins = [o.strip() for o in os.environ.get("AERIS_CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if o.strip()]
    if os.environ.get("AERIS_DEV") == "1" and "null" not in origins:
        origins.append("null")
    return {"db": os.environ.get("AERIS_DB", os.path.join(os.getcwd(), "data", "aeris.sqlite3")),
            "workers": int(os.environ["AERIS_WORKERS"]) if os.environ.get("AERIS_WORKERS") else None,
            "max_jobs": int(os.environ.get("AERIS_MAX_JOBS", "2")), "origins": origins,
            "restart_policy": os.environ.get("AERIS_RESTART_POLICY", "resume"), "bridge": os.environ.get("AERIS_TELEMETRY_BRIDGE", "ndjson"),
            "telemetry_dir": os.environ.get("AERIS_TELEMETRY_DIR", os.path.join(os.getcwd(), "data", "telemetry")),
            "telemetry_allow_remote": os.environ.get("AERIS_TELEMETRY_ALLOW_REMOTE") == "1",
            "telemetry_max_live": int(os.environ.get("AERIS_TELEMETRY_MAX_LIVE", "4")),
            "telemetry_adapters": os.environ.get("AERIS_TELEMETRY_ADAPTERS"),
            "site_dir": os.environ.get("AERIS_SITE_DIR"), "auth_env": None}


def create_app(settings: dict | None = None) -> FastAPI:
    st = dict(settings_from_env(), **(settings or {}))
    auth_cfg = AuthConfig(st.get("auth_env"))
    authn = Authenticator(auth_cfg)
    jwt_mode = auth_cfg.mode == "jwt"            # fail closed: a broken jwt configuration refuses requests (503), never opens them
    if jwt_mode and st.get("bridge") not in (None, "none"):
        st["bridge_requested"] = st.get("bridge")
        st["bridge"] = "none"                    # the global v1 bridge is a single-owner facility (per-device telemetry: /api/v6)
    repo = SqliteRepository(st["db"], exclusive=st.get("exclusive", True))
    manager = JobManager(repo, workers=st.get("workers"), max_jobs=st["max_jobs"], restart_policy=st["restart_policy"], limits=st.get("limits"))
    _bridge_kind, bridge_startup = parse_bridge_setting(st.get("bridge"))
    bridge = make_bridge(st.get("bridge"), telemetry_dir=st.get("telemetry_dir"), allow_remote=bool(st.get("telemetry_allow_remote")),
                         recording_loader=lambda rid: (repo.get("recordings", rid) or {}).get("document"),
                         adapter_factory=adapter_factory_from(st.get("telemetry_adapters")))
    live_sockets = {"n": 0}

    @contextlib.asynccontextmanager
    async def lifespan(app):
        await manager.start()
        await app.state.devices.start()
        app.state.bridge_startup_error = None
        if bridge_startup:
            try:
                await bridge.connect(bridge_startup)
            except BridgeError as e:      # a bad start-up source is reported by /telemetry/status, not a crash
                app.state.bridge_startup_error = str(e)
        yield
        await app.state.devices.stop()
        await bridge.close()
        await manager.stop()
        repo.close()

    app = FastAPI(title="AERIS research backend", version=BACKEND_VERSION, lifespan=lifespan,
                  description="Authoritative Python engine for AERIS Lab SIMULATION mode. Nominal parameters unless a measured parameter set is named; nothing here is a hardware measurement.")
    app.state.repo, app.state.manager, app.state.settings, app.state.bridge = repo, manager, st, bridge
    app.state.auth = authn
    P = API_PREFIX
    PUBLIC_V1 = {P + "/health", P + "/capabilities"}
    from .devices_api import Tickets
    tickets = Tickets()

    async def v1_owner(request: Request, call_next):
        """jwt mode: every /api/v1 request except /health and /capabilities carries a bearer token; request.state.owner
        is then the caller (owned records of others are 'not found'). local mode: no owner, one shared workspace."""
        request.state.owner = None
        path = request.url.path
        if jwt_mode and path.startswith(P + "/") and request.method != "OPTIONS" and path not in PUBLIC_V1:
            try:
                request.state.owner = authn.owner(request.headers.get("authorization"))
            except AuthError as e:
                return JSONResponse(envelope("unauthorized" if e.status == 401 else "unavailable", e.message, retryable=e.status == 503), status_code=e.status)
        return await call_next(request)

    # the authentication middleware is added first so that CORS wraps it (a browser can read a 401)
    app.add_middleware(BaseHTTPMiddleware, dispatch=v1_owner)
    app.add_middleware(CORSMiddleware, allow_origins=st["origins"] + ([auth_cfg.public_origin] if auth_cfg.public_origin else []), allow_credentials=True,
                       allow_methods=["GET", "POST"], allow_headers=["Content-Type", "Accept", "X-AERIS-Client", "Authorization"], max_age=600)

    def viewer(request) -> str | None:
        return getattr(request.state, "owner", None) if jwt_mode else None

    def visible(owner_field, request) -> bool:
        """Owned records (device recordings, twin runs, datasets made in jwt mode) are visible to their owner only."""
        return not jwt_mode or owner_field is None or owner_field == viewer(request)

    def need_visible(obj, what, ident, request, owner_of=lambda o: o.get("owner")):
        if obj is None or not visible(owner_of(obj), request):
            raise ApiError(404, "not_found", f"No {what} '{ident}'.")
        return obj

    def job_owner(j):
        return (j.get("extra") or {}).get("owner")

    async def ws_v1_allowed(ws: WebSocket) -> str | None | bool:
        """jwt mode: a v1 live socket presents a ticket (POST /api/v6/tickets {"purpose": "v1-live"}). Returns the owner
        (jwt), None (local mode) or False (refused)."""
        if not jwt_mode:
            return None
        if not auth_cfg.ok:
            return False
        o = tickets.take(ws.query_params.get("ticket"), "v1-live")
        return o if o else False

    @app.exception_handler(ApiError)
    async def _api_err(request, ex: ApiError):
        return JSONResponse(envelope(ex.code, ex.message, ex.details, ex.retryable), status_code=ex.status)

    @app.exception_handler(InvalidRequest)
    async def _inv(request, ex: InvalidRequest):
        return JSONResponse(envelope(ex.code, ex.message, [{"path": e["path"], "message": e["message"], "kind": e.get("kind")} for e in ex.details], False), status_code=422)

    @app.exception_handler(RequestValidationError)
    async def _rv(request, ex: RequestValidationError):
        det = [{"path": ".".join(str(x) for x in e["loc"][1:]), "message": e["msg"]} for e in ex.errors()]
        return JSONResponse(envelope("invalid_request", "The request body does not match the endpoint's schema.", det), status_code=422)

    @app.exception_handler(StarletteHTTPException)
    async def _http(request, ex: StarletteHTTPException):
        code = {404: "not_found", 405: "method_not_allowed", 429: "rate_limited", 503: "unavailable"}.get(ex.status_code, f"http_{ex.status_code}")
        return JSONResponse(envelope(code, str(ex.detail), retryable=ex.status_code in (429, 503)), status_code=ex.status_code)

    @app.exception_handler(Exception)
    async def _any(request, ex: Exception):
        return JSONResponse(envelope("internal", f"{type(ex).__name__}: {ex}", retryable=False), status_code=500)

    def need(obj, what, ident):
        if obj is None:
            raise ApiError(404, "not_found", f"No {what} '{ident}'.")
        return obj

    def with_parameter_set(config, ps_id):
        """Apply a stored parameter set to a configuration: its values are written at their configuration paths
        (each replacement is reported). Returns (config, identity); the identity carries the values so that every
        run computes its own coverage (docs/PARAMETERS.md)."""
        if not ps_id or ps_id == NOMINAL_SET["id"]:
            return config, None
        ps = need(repo.get("parameter_sets", ps_id), "parameter set", ps_id)
        if not isinstance(config, dict):
            return config, None
        cfg, replaced = apply_parameter_set(config, ps)
        ident = {"id": ps["id"], "status": ps["status"], "revision": ps.get("revision", 1), "applied": sorted(canonical_path(k) for k in ps["values"]),
                 "missing": ps.get("missing", []), "replaced": replaced, "values": ps["values"]}
        return cfg, ident

    # ------------------------------------------------------------------ service
    @app.get(P + "/health")
    async def health():
        jobs = repo.list_jobs(states=["queued", "initializing", "running", "analyzing"], limit=10000)
        schema = repo.schema_info()
        return {"status": "ok" if not manager.quarantine else "degraded", "backend": BACKEND_NAME, "version": BACKEND_VERSION, "engine_version": ENGINE_VERSION,
                "time": now_iso(), "db": "ok", "schema_version": schema["schema_version"], "db_warnings": schema["warnings"],
                "workers": manager.workers, "max_jobs": manager.max_jobs,
                "jobs": {"active": sum(1 for j in jobs if j["state"] != "queued"), "queued": sum(1 for j in jobs if j["state"] == "queued")},
                "quarantined": [{"job": k, "reason": v} for k, v in manager.quarantine.items()],
                "restart_policy": manager.restart_policy, "recovery": manager.recovery_report, "metrics_version": METRICS_VERSION, "mock": False}

    @app.get(P + "/capabilities")
    async def capabilities():
        L = dict(BACKEND_LIMITS, **(st.get("limits") or {}))
        return {"kind": "simulation", "engine": BACKEND_NAME, "engine_version": ENGINE_VERSION, "backend_version": BACKEND_VERSION,
                "parity_target": PARITY_TARGET, "label": "AERIS research backend (Python)", "reported": True, "mock": False,
                "single": True, "controllerSet": True, "reproduce": True, "validate": True, "compare": True, "datasets": True, "live": True,
                "config": {"schema": "aeris-config/1", "revision": CONFIG_REVISION, "revisions": list(CONFIG_REVISIONS_READ)},
                "run": {"schema": "aeris-run/1", "revision": RUN_REVISION},
                # the experiment contract of configuration revision 1.2 (docs/EXPERIMENT_CONTRACT.md): what this backend executes
                "experiment": {"initial_state": {"attitude_q": True, "body_rate_dps": True, "wheel_speeds_rpm": True,
                                                 "convention": "attitude_q = [w, x, y, z], scalar first, Hamilton product, rotates body → world (z up); body_rate_dps in body axes",
                                                 "legacy_inputs": ["tilt_deg", "rate_dps", "azimuth_deg", "reference"],
                                                 "conflicts": "an explicit attitude or body rate together with a legacy tilt or rate input is refused"},
                               "reference": {"attitudes": list(REFERENCE_ATTITUDES), "headings": list(HEADINGS), "yaw_deg": True, "commands": ["yaw_step"],
                                             "equilibrium_reported": True},
                               "estimator_timing": {"stale_after_s": [1e-4, 10], "prediction_to_control_time": True},
                               "recovery_breakdown": ["first_recovery_s", "sustained", "exits_after_recovery", "fell_after_recovery"]},
                "metrics": {"version": METRICS_VERSION, "reanalyze": True},
                "controllers": list(CONTROLLER_NAMES), "controller_names": CONTROLLER_NAMES, "structures": ["decoupled", "mimo-lqr"],
                "structure_rules": {"mimo-lqr": "corner mode, controller type 'lqr'"},
                "estimators": {"edge": list(EDGE_ESTIMATORS), "corner": list(CORNER_ESTIMATORS)}, "estimator_names": ESTIMATOR_NAMES,
                "sensorModel": {"edge": True, "corner": True, "imuRateIndependent": True, "latency": True, "dropout": True, "quantisation": True,
                                "dynamicAcceleration": True, "timestamps": True},
                "actuatorModel": {"motorLag": True, "wheelHealth": True, "perWheel": True, "customAxes": True, "maxWheels": L["maxWheels"],
                                  "electricalLimit": ["command", "continuous"], "allocation": list(("clip", "bounded-ls"))},
                "plant": {"fullBaseInertia": True, "components": True, "maxComponents": L["maxComponents"], "maxAttachments": L["maxAttachments"]},
                "disturbances": list(DISTURBANCE_TYPES), "events": list(EVENT_TYPES), "commands": ["yaw_step"],
                "recovery": {"defaults": RECOVERY_DEFAULTS, "yaw_objectives": list(YAW_OBJECTIVES)}, "termination": {"defaults": TERMINATION_DEFAULTS},
                "rates": {"maxIntegration_hz": L["maxIntegration_hz"], "record_hz": [L["minRecord_hz"], L["maxRecord_hz"]]},
                "sweep": {"modes": ["grid", "random", "montecarlo"], "revision": SWEEP_REVISION, "criteria": list(SW.CRITERIA),
                          "maxRuns": L["maxRuns_per_sweep"], "maxDuration_s": L["maxDuration_s"],
                          "maxSteps_per_job": L["maxSteps_per_job"], "controllers": list(SW.CONTROLLER_KEYS), "variables": list(SW.VARIABLES),
                          "paths": True, "distributions": SW.DISTRIBUTIONS, "seed_strategies": SW.SEED_STRATEGIES, "mass_configs": list(SW.MASS_CONFIGS)},
                "limits": {"maxDuration_s": L["maxDuration_s"], "minDuration_s": L["minDuration_s"], "maxSteps_per_run": L["maxSteps_per_run"]},
                "params": PARAM_SPEC,
                "hardware": {"ingest": True, "compare": True, "protocols": True, "live": bool(bridge.status().get("live")), "bridge": bridge.name,
                             "physical_device": "never verified by the software: a source declares its kind; synthetic sources are never shown as the cube"},
                "telemetry": {"available": bridge.name != "none", "protocol": TELEMETRY_PROTOCOL, "transports": ["tcp", "file", "recording"] if bridge.name != "none" else [],
                              "read_only": True, "loopback_only": not st.get("telemetry_allow_remote"), "live_socket": True, "polling": True,
                              "max_live_sockets": st.get("telemetry_max_live", 4)},
                "trueVsEstimated": {"edge": "tilt, gyro bias", "corner": "attitude (quaternion), tilt, gyro bias"},
                "devices": {"api": "/api/v6", "status": "/api/v6/status", "auth": auth_cfg.summary(), "twin": True,
                            "note": "Device profiles, pairing, calibration, approved configurations, bounded commands and per-device telemetry (v6.0)."},
                "workers": manager.workers, "max_jobs": manager.max_jobs}

    @app.post(P + "/validate")
    async def validate(body: ValidateRequest):
        if body.config is not None:
            v = validate_config(body.config, st.get("limits"))
            return {"ok": v.ok, "errors": v.errors, "warnings": v.warnings, "config": v.config, "workload": v.workload,
                    "config_hash": canonical_hash(v.config) if v.ok else None}
        if body.sweep is not None:
            r = SW.validate_def(body.sweep, st.get("limits"))
            return {"ok": r["ok"], "errors": r["errors"], "warnings": r["warnings"], "workload": r["workload"], "total": r["total"]}
        raise ApiError(422, "invalid_request", "Give 'config' or 'sweep'.")

    # ------------------------------------------------------------------ simulations and jobs
    @app.post(P + "/simulations", status_code=202)
    async def simulations(body: SimulationRequest, request: Request):
        meta = dict(body.meta)
        meta["client_site"] = (body.client or {}).get("site")
        cfg, ps = with_parameter_set(body.config, body.parameter_set)
        job = manager.submit_simulation(cfg, meta, parameter_set=ps)
        return {"job": job}

    @app.post(P + "/sweeps", status_code=202)
    async def sweeps(body: SweepRequest):
        d, ps = body.sweep, None
        if body.parameter_set and isinstance(d, dict):
            base, ps = with_parameter_set(d.get("base") or {"mode": "edge"}, body.parameter_set)
            d = dict(d, base=base)
        return {"job": manager.submit_sweep(d, parameter_set=ps)}

    @app.get(P + "/jobs")
    async def jobs(request: Request, limit: int = Query(50, ge=1, le=500)):
        return {"jobs": repo.list_jobs(limit=limit, viewer=viewer(request))}

    @app.get(P + "/jobs/{job_id}")
    async def get_job(request: Request, job_id: str):
        return need_visible(repo.get_job(job_id), "job", job_id, request, job_owner)

    @app.post(P + "/jobs/{job_id}/cancel")
    async def cancel(request: Request, job_id: str):
        need_visible(repo.get_job(job_id), "job", job_id, request, job_owner)
        return need(await manager.cancel(job_id), "job", job_id)

    @app.post(P + "/jobs/{job_id}/retry", status_code=202)
    async def retry(request: Request, job_id: str):
        """A NEW job with the request of a failed or cancelled single-run job (the old job stays as it is)."""
        job = need_visible(repo.get_job(job_id), "job", job_id, request, job_owner)
        if job["kind"] == "sweep":
            raise ApiError(422, "not_retryable", "Sweeps are not retried as a whole: a resumed sweep skips its stored rows; submit the definition again for a new sweep.")
        if job["state"] not in ("failed", "cancelled"):
            raise ApiError(409, "not_finished", f"Job {job_id} is {job['state']}; only failed or cancelled jobs are retried.")
        req = repo.get_job_request(job_id) or {}
        extra = {k: v for k, v in (job.get("extra") or {}).items() if k not in ("ids",)}
        extra["retry_of"] = job_id
        return {"job": manager.submit_simulation(req.get("config"), dict(req.get("meta") or {}, name=(req.get("meta") or {}).get("name")), extra=extra,
                                                 parameter_set=extra.pop("parameter_set", None))}

    @app.websocket(P + "/live/{job_id}")
    async def live(ws: WebSocket, job_id: str):
        origin = ws.headers.get("origin")
        if origin is not None and origin not in st["origins"] and origin != auth_cfg.public_origin:
            await ws.close(code=4403)
            return
        who = await ws_v1_allowed(ws)
        if who is False:
            await ws.close(code=4401)
            return
        job = repo.get_job(job_id)
        if job is not None and jwt_mode and job_owner(job) not in (None, who):
            job = None
        await ws.accept()
        if job is None:
            await ws.send_json({"type": "error", "error": {"code": "not_found", "message": f"No job '{job_id}'."}})
            await ws.close(code=4404)
            return
        q = manager.subscribe(job_id)
        try:
            await ws.send_json({"type": "job", "seq": job["seq"], "job": job})
            if job["state"] in TERMINAL:
                await ws.close(code=1000)
                return
            while True:
                try:
                    msg = await asyncio.wait_for(q.get(), timeout=15)
                except asyncio.TimeoutError:
                    cur = repo.get_job(job_id)
                    await ws.send_json({"type": "job", "seq": cur["seq"], "job": cur})
                    if cur["state"] in TERMINAL:
                        break
                    continue
                await ws.send_json(msg)
                if msg.get("type") == "job" and msg["job"]["state"] in TERMINAL:
                    break
            await ws.close(code=1000)
        except WebSocketDisconnect:
            pass
        finally:
            manager.unsubscribe(job_id, q)

    # ------------------------------------------------------------------ runs
    @app.get(P + "/runs")
    async def runs(request: Request, limit: int = Query(50, ge=1, le=500), offset: int = Query(0, ge=0)):
        return {"runs": repo.list_runs(limit, offset, viewer=viewer(request))}

    @app.get(P + "/runs/{run_id}")
    async def get_run(request: Request, run_id: str):
        return need_visible(repo.get_run(run_id), "run", run_id, request)

    @app.get(P + "/runs/{run_id}/export")
    async def export_run(request: Request, run_id: str, format: str = Query("json", pattern="^(json|csv)$")):
        rec = need_visible(repo.get_run(run_id), "run", run_id, request)
        if format == "csv":
            return PlainTextResponse(to_csv(rec), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{rec.get("experiment_id") or run_id}.csv"'})
        return JSONResponse(rec, headers={"Content-Disposition": f'attachment; filename="{rec.get("experiment_id") or run_id}.json"'})

    def submit_reproduction(rec, name, lineage=None):
        cfg, changes = reproduction_config(rec)
        ps = (rec.get("reproduction") or {}).get("parameter_set")
        extra = {"reproduction_of": rec["id"], "seed_strategy": (rec.get("reproduction") or {}).get("seed_strategy"), "config_changes": changes}
        if lineage:
            extra["lineage"] = lineage
        return manager.submit_simulation(cfg, {"name": name}, extra=extra,
                                         parameter_set=ps if isinstance(ps, dict) and ps.get("id") != NOMINAL_SET["id"] else None)

    @app.post(P + "/runs/{run_id}/reproduce", status_code=202)
    async def reproduce(request: Request, run_id: str):
        rec = need_visible(repo.get_run(run_id), "run", run_id, request)
        if (rec.get("origin") or {}).get("engine") != BACKEND_NAME:
            raise ApiError(422, "not_reproducible", "Only runs produced by this backend can be reproduced here.")
        return {"job": submit_reproduction(rec, "Reproduction of " + (rec.get("experiment_id") or run_id))}

    @app.post(P + "/runs/{run_id}/reanalyze", status_code=202)
    async def reanalyze(request: Request, run_id: str):
        """Current research metrics for a record computed with an older metric definition: the saved configuration
        is simulated again as a NEW record with lineage (the samples of the old record hold the recording rate only,
        while the metrics integrate every step). The old record is never changed."""
        rec = need_visible(repo.get_run(run_id), "run", run_id, request)
        if (rec.get("origin") or {}).get("engine") != BACKEND_NAME:
            raise ApiError(422, "not_reproducible", "Only runs produced by this backend can be reanalysed here (its configuration is simulated again).")
        old = (rec.get("reproduction") or {}).get("metrics_version") or "1"
        if old == METRICS_VERSION:
            raise ApiError(409, "already_current", f"Run {run_id} already carries research metrics version {METRICS_VERSION}.")
        lineage = {"relation": "reanalysis", "derived_from": rec["id"], "derived_from_experiment": rec.get("experiment_id"),
                   "metrics_version_before": old, "metrics_version_after": METRICS_VERSION,
                   "why_rerun": "The research metrics integrate over every integration step; the saved samples hold the recording rate only, "
                                "so the corrected metrics are computed by simulating the saved configuration again (docs/METRICS.md)."}
        return {"job": submit_reproduction(rec, "Reanalysis of " + (rec.get("experiment_id") or run_id) + f" (metrics v{old} → v{METRICS_VERSION})", lineage)}

    @app.post(P + "/reproduce", status_code=202)
    async def reproduce_record(request: Request, body: Loose):
        """Reproduce a run record the client holds (e.g. a backend run imported from a file)."""
        rec = body.model_dump()
        if (rec.get("origin") or {}).get("engine") != BACKEND_NAME or not isinstance(rec.get("config"), dict):
            raise ApiError(422, "not_reproducible", "Send an aeris-run/1 record produced by aeris-research-backend (with its config).")
        stored = repo.get_run(rec.get("id", "")) if rec.get("id") else None
        if stored is not None and not visible(stored.get("owner"), request):
            stored = None
        if stored is None:
            raise ApiError(404, "not_found", "This backend has no copy of that run; it can only compare a reproduction against runs it stored. Re-submit the configuration as a new simulation instead.")
        return {"job": submit_reproduction(stored, "Reproduction of " + (stored.get("experiment_id") or stored["id"]))}

    # ------------------------------------------------------------------ sweeps
    @app.get(P + "/sweeps/{sweep_id}")
    async def get_sweep(sweep_id: str):
        sw = need(repo.get_sweep(sweep_id), "sweep", sweep_id)
        sw["job"] = repo.get_job(sw["job_id"]) if sw.get("job_id") else None
        return sw

    @app.get(P + "/sweeps/{sweep_id}/rows")
    async def sweep_rows(sweep_id: str, offset: int = Query(0, ge=0), limit: int = Query(1000, ge=1, le=100000), include_config: bool = False):
        need(repo.get_sweep(sweep_id, with_rows=False), "sweep", sweep_id)
        return {"sweep_id": sweep_id, "offset": offset, "rows": repo.sweep_rows(sweep_id, offset=offset, limit=limit, include_config=include_config)}

    @app.get(P + "/sweeps/{sweep_id}/rows/{index}")
    async def sweep_row(sweep_id: str, index: int):
        """One row with the exact configuration that was simulated (saved at execution time)."""
        need(repo.get_sweep(sweep_id, with_rows=False), "sweep", sweep_id)
        return need(repo.sweep_row(sweep_id, index), "sweep row", f"{sweep_id}#{index}")

    @app.post(P + "/sweeps/{sweep_id}/analyze")
    async def analyze_sweep(sweep_id: str):
        """The analysis of the rows stored for a sweep that is no longer running (e.g. cancelled or interrupted). Returned, not
        stored: a finished sweep's stored analysis never changes; a partial analysis says so in its notes."""
        sw = need(repo.get_sweep(sweep_id, with_rows=False), "sweep", sweep_id)
        if sw["status"] in ("queued", "running", "analyzing"):
            raise ApiError(409, "not_finished", f"Sweep {sweep_id} is {sw['status']}; wait for it to finish or cancel it first.")
        if not sw["rows_stored"]:
            raise ApiError(409, "no_rows", f"Sweep {sweep_id} has no stored rows to analyse.")
        return {"sweep_id": sweep_id, "rows": sw["rows_stored"], "total": sw["total"], "status": sw["status"], "analysis": await manager.analyze_stored(sweep_id)}

    @app.get(P + "/sweeps/{sweep_id}/export")
    async def export_sweep(sweep_id: str, format: str = Query("csv", pattern="^(json|csv)$")):
        sw = need(repo.get_sweep(sweep_id), "sweep", sweep_id)
        if format == "csv":
            return PlainTextResponse(SW.to_csv(sw), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{sweep_id}.csv"'})
        return JSONResponse(sw)

    # ------------------------------------------------------------------ comparison
    @app.post(P + "/compare")
    async def compare(request: Request, body: CompareRequest):
        recs = [need_visible(repo.get_run(i), "run", i, request) for i in body.run_ids]
        return compare_runs(recs)

    # ------------------------------------------------------------------ datasets
    def list_visible(table, request, limit=100):
        """A document listing for the caller: everything (local mode) or the shared documents plus the caller's own."""
        if not jwt_mode:
            return repo.list(table, limit=limit)
        rows = repo.list_where(table, limit, owner=viewer(request)) + repo.list_where(table, limit, owner=None)
        rows.sort(key=lambda r: r.get("created") or "", reverse=True)
        return rows[:limit]

    @app.post(P + "/datasets", status_code=201)
    async def create_dataset(request: Request, body: DatasetCreate):
        members = []
        for rid in body.run_ids:
            r = need_visible(repo.get_run(rid), "run", rid, request)
            members.append({"kind": "run", "id": r["id"], "experiment_id": r.get("experiment_id"), "schema": "aeris-run/1", "config_hash": (r.get("reproduction") or {}).get("config_hash")})
        for sid in body.sweep_ids:
            sw = need(repo.get_sweep(sid, with_rows=False), "sweep", sid)
            if sw["status"] in ("queued", "running", "analyzing"):
                raise ApiError(409, "not_finished", f"Sweep {sid} is still {sw['status']}; a dataset can only contain finished or cancelled sweeps.")
            members.append({"kind": "sweep", "id": sid, "schema": "aeris-sweep/1", "runs": sw["rows_stored"], "partial": sw["partial"]})
        for hid in body.recording_ids:
            h = need_visible(repo.get("recordings", hid), "recording", hid, request)
            pr = effective_provenance(h)
            members.append({"kind": "hardware-run", "id": hid, "schema": "aeris-hardware-run/1", "synthetic": pr["synthetic"], "trust": pr["trust"],
                            "source_kind": pr.get("source_kind"), "declared_physical": pr["declared_physical"], "derived": pr["derived"],
                            "content_hash": h.get("content_hash"), "label": pr.get("label")})
        if not members:
            raise ApiError(422, "invalid_request", "A dataset needs at least one run, sweep or recording.")
        ds_id = "AERIS-DS-%06d" % repo.next_id("dataset")
        kinds = {m["kind"] for m in members}
        synthetic_ids = [m["id"] for m in members if m["kind"] == "hardware-run" and m["synthetic"]]
        unknown_ids = [m["id"] for m in members if m["kind"] == "hardware-run" and m["trust"] == "unknown"]
        derived_ids = [m["id"] for m in members if m["kind"] == "hardware-run" and m.get("derived")]
        hw = [m for m in members if m["kind"] == "hardware-run"]
        # "hardware" only when every recording was declared physical by its source; anything else is never upgraded
        hw_source = "synthetic-telemetry" if hw and len(synthetic_ids) == len(hw) else ("hardware" if hw and all(m["trust"] == "declared-physical" for m in hw) else "mixed")
        source = "mixed" if ("hardware-run" in kinds and len(kinds) > 1) else (hw_source if kinds == {"hardware-run"} else "simulation")
        note = "Created on the AERIS research backend. Simulated members use nominal parameters unless their records say otherwise; not validated against the physical cube."
        if synthetic_ids:
            note += " Contains SYNTHETIC telemetry (" + ", ".join(synthetic_ids) + "): emulator/test data or data derived from it, not measurements, never validation evidence."
        if unknown_ids:
            note += " Contains recordings of undeclared origin (" + ", ".join(unknown_ids) + "): never validation evidence."
        if derived_ids:
            note += " Contains recordings captured from a replay (" + ", ".join(derived_ids) + "): copies of earlier data, not original measurements."
        doc = {"schema": "aeris-dataset/1", "id": ds_id, "title": body.title, "created": now_iso(), "status": "exploratory", "mock": False,
               "description": body.description, "members": members,
               "provenance": {"source": source, "engine": {"engine": BACKEND_NAME, "engine_version": ENGINE_VERSION}, "validation": {"status": "nominal", "parameter_set": "nominal-design-v1"},
                              "contains_synthetic": bool(synthetic_ids), "synthetic_members": synthetic_ids,
                              "contains_unknown_origin": bool(unknown_ids), "unknown_origin_members": unknown_ids, "derived_members": derived_ids,
                              "demo": False, "mock": False, "note": note},
               "finalized": None}
        if jwt_mode:
            doc["owner"] = viewer(request)       # jwt mode: a dataset belongs to its creator (its members may be owned)
        if not repo.put_new("datasets", ds_id, doc, title=body.title, status="exploratory", **({"owner": doc["owner"]} if jwt_mode else {})):
            raise ApiError(409, "exists", f"Dataset {ds_id} exists.")
        return doc

    @app.post(P + "/datasets/{ds_id}/finalize")
    async def finalize_dataset(request: Request, ds_id: str):
        doc = need_visible(repo.get("datasets", ds_id), "dataset", ds_id, request)
        if doc["status"] == "final":
            raise ApiError(409, "already_final", f"Dataset {ds_id} is already final; final datasets never change.")
        doc["status"] = "final"
        doc["finalized"] = {"at": now_iso(), "content_hash": canonical_hash(doc["members"]), "member_hashes": DSI.member_hashes(repo, doc["members"]),
                            "software": software_versions()}
        try:
            repo.put("datasets", ds_id, doc, title=doc["title"], status="final", **({"owner": doc["owner"]} if doc.get("owner") else {}))
        except IntegrityError as e:          # finalised concurrently: the first finalisation stands
            raise ApiError(409, "already_final", str(e))
        return doc

    @app.get(P + "/datasets/{ds_id}/export")
    async def export_dataset(request: Request, ds_id: str):
        """One self-contained bundle: the dataset document, every member (runs, sweeps with rows, recordings) and an
        integrity check of a final dataset against the hashes taken when it was finalised."""
        doc = need_visible(repo.get("datasets", ds_id), "dataset", ds_id, request)
        runs = [repo.get_run(m["id"]) for m in doc["members"] if m["kind"] == "run"]
        sweeps = [repo.get_sweep(m["id"]) for m in doc["members"] if m["kind"] == "sweep"]
        recs = [repo.get("recordings", m["id"]) for m in doc["members"] if m["kind"] == "hardware-run"]
        integrity = DSI.check_final(repo, doc)
        bundle = {"schema": "aeris-dataset-bundle/1", "exported": now_iso(), "software": software_versions(), "dataset": doc,
                  "members": {"runs": runs, "sweeps": sweeps, "recordings": recs}, "integrity": integrity,
                  "note": "Exported from the AERIS research backend. Simulated members use nominal parameters unless their records name a parameter set"
                          + ("; SYNTHETIC telemetry members are not measurements" if (doc.get("provenance") or {}).get("contains_synthetic") else "") + "."}
        return JSONResponse(bundle, headers={"Content-Disposition": f'attachment; filename="{ds_id}.json"'})

    @app.get(P + "/datasets")
    async def list_datasets(request: Request):
        return {"datasets": list_visible("datasets", request)}

    @app.get(P + "/datasets/{ds_id}")
    async def get_dataset(request: Request, ds_id: str, embed: bool = False):
        doc = need_visible(repo.get("datasets", ds_id), "dataset", ds_id, request)
        if embed:
            doc = dict(doc)
            doc["runs"] = [repo.get_run(m["id"]) for m in doc["members"] if m["kind"] == "run"]
            doc["sweeps"] = [repo.get_sweep(m["id"]) for m in doc["members"] if m["kind"] == "sweep"]
        return doc

    # ------------------------------------------------------------------ parameter sets
    @app.get(P + "/parameter-sets")
    async def parameter_sets():
        return {"parameter_sets": [NOMINAL_SET] + repo.list("parameter_sets")}

    @app.get(P + "/parameter-sets/{ps_id}")
    async def get_parameter_set(ps_id: str):
        if ps_id == NOMINAL_SET["id"]:
            return NOMINAL_SET
        return need(repo.get("parameter_sets", ps_id), "parameter set", ps_id)

    @app.post(P + "/parameter-sets", status_code=201)
    async def create_parameter_set(body: ParameterSetCreate):
        errs = []
        values = {}
        for k, v in body.values.items():
            path = canonical_path(k)
            for m in check_value(path, v.value, v.unit):
                errs.append({"path": f"values.{k}", "message": m})
            values[path] = v.model_dump()
        if errs:
            raise ApiError(422, "invalid_parameter_set", "The parameter set is not valid.", errs)
        if body.supersedes and not repo.get("parameter_sets", body.supersedes):
            raise ApiError(422, "invalid_parameter_set", f"supersedes: no parameter set '{body.supersedes}'.", [{"path": "supersedes", "message": "unknown id"}])
        ps_id = body.id or "paramset-%04d" % repo.next_id("paramset")
        st = set_status(values)
        doc = {"id": ps_id, "revision": PS_REVISION, "label": body.label, "created": now_iso(), "status": st["status"], "values": values, "missing": st["missing"],
               "supersedes": body.supersedes,
               "note": "Values as supplied with their method, date and evidence reference. Each run reports its own coverage: MEASURED only when every model input "
                       "it uses comes from this set unchanged; runs are otherwise NOMINAL with the nominal and overridden inputs listed. " + st["note"]}
        if not repo.put_new("parameter_sets", ps_id, doc, status=doc["status"], label=body.label):
            raise ApiError(409, "exists", f"Parameter set '{ps_id}' exists; parameter sets are immutable (create a new id and set 'supersedes').")
        return doc

    # ------------------------------------------------------------------ hardware and telemetry
    def recording_provenance(doc: dict) -> dict:
        """What a recording says about its origin (declared, never verified), recomputed from the immutable document
        (telemetry/lineage.py): trust is never higher than the least trustworthy segment or ancestor."""
        prov = doc.get("provenance") if isinstance(doc.get("provenance"), dict) else {}
        c = LIN.classify(doc)
        kinds = {((h.get("device") or {}).get("kind")) for h in (prov.get("hellos") or []) if isinstance(h, dict)} - {None}
        declared_physical = c["trust"] == "declared-physical" and bool(kinds & {"physical", "file-replay"} or prov.get("source_kind") == "physical")
        label = ("SYNTHETIC — " + ("mixed sources including synthetic or undeclared data; " if c["mixed_sources"] else "") + "not a measurement of the physical cube"
                 if c["trust"] == "synthetic" else
                 "declared physical device (not verified by the software)" + (" · captured from a replay (a copy, not an original measurement)" if c["derived"] else "")
                 if declared_physical else "origin not declared by a telemetry source (unknown provenance: never evidence)")
        return {"synthetic": c["synthetic"], "trust": c["trust"], "trust_reasons": c["reasons"], "source_kind": prov.get("source_kind") or (doc.get("device") or {}).get("kind"),
                "protocol": prov.get("protocol"), "transport": (prov.get("transport") or {}).get("kind"), "declared_physical": declared_physical,
                "physical_verified": False, "mixed_sources": c["mixed_sources"], "derived": c["derived"], "derived_from": c["derived_from"], "label": label}

    def effective_provenance(stored: dict) -> dict:
        """A stored recording's provenance for any decision (evidence, datasets): recomputed from its document and
        combined with what was stored, so nothing stored earlier can raise trust (v5 records are never rewritten)."""
        pr = recording_provenance(stored["document"])
        old = stored.get("provenance") or {}
        if (stored.get("synthetic") or old.get("synthetic")) and pr["trust"] == "declared-physical":
            # stored as synthetic but the document now reads as declared physical: the stored flag wins (never raised)
            pr = dict(pr, synthetic=True, trust="synthetic", declared_physical=False,
                      trust_reasons=list(dict.fromkeys(pr["trust_reasons"] + ["stored as synthetic"])),
                      label="SYNTHETIC — not a measurement of the physical cube")
        elif stored.get("synthetic") or old.get("synthetic"):
            pr = dict(pr, declared_physical=False)        # synthetic or unknown (v6: unknown stays unknown; both are never evidence)
        return pr

    def check_synthetic_flag(doc: dict) -> list[str]:
        pr = recording_provenance(doc)
        if pr["synthetic"] and doc.get("synthetic") is not True:
            return ["synthetic: the recording's provenance declares synthetic data (" + "; ".join(pr["trust_reasons"]) + "), so 'synthetic' must be true; "
                    "a synthetic recording (or anything derived from one) can never be relabelled as a measurement"]
        return []

    def store_recording(doc: dict, source: str, extra: dict | None = None, owner: str | None = None) -> dict:
        """extra (v6.0): the device link context of a device recording {owner, device_id, config_hash, boot_id, route}."""
        if extra and extra.get("owner"):
            owner = extra["owner"]
        v = validate_recording(doc)
        errs = v["errors"] + check_synthetic_flag(doc)
        if errs:
            raise ApiError(422, "invalid_recording", "The recording failed strict validation.", [{"path": e.split(":")[0] if ":" in e else "", "message": e} for e in errs])
        rid = "AERIS-HW-%06d" % repo.next_id("recording")
        pr = recording_provenance(doc)
        stored = {"id": rid, "created": now_iso(), "document": doc, "content_hash": canonical_hash(doc), "quality": v["quality"],
                  "warnings": v["warnings"], "synthetic": v["synthetic"] or pr["synthetic"], "source": source, "provenance": pr}
        idx = {}
        if owner:
            stored["owner"] = idx["owner"] = owner
        if extra:
            stored["device_link"] = {k: extra.get(k) for k in ("device_id", "config_hash", "boot_id", "route")}
            idx["device_id"] = extra.get("device_id")
        repo.put_new("recordings", rid, stored, device=doc["device"]["id"], mode=doc["mode"], synthetic=stored["synthetic"], source=source,
                     source_kind=pr["source_kind"], name=(doc.get("recording") or {}).get("notes"), samples=v["quality"]["n"],
                     trust=("synthetic" if stored["synthetic"] and pr["trust"] == "declared-physical" else pr["trust"]), derived=pr["derived"], **idx)
        return {k: stored[k] for k in ("id", "created", "content_hash", "quality", "warnings", "synthetic", "source", "provenance") + (("device_link",) if extra else ())}

    def NoBridgeReason():
        return "Telemetry is switched off on this backend (AERIS_TELEMETRY_BRIDGE=none)."

    def bridge_call_error(e: BridgeError):
        return ApiError(e.status, e.code, str(e), e.details)

    def bridge_status():
        s = dict(bridge.status(), startup_error=getattr(app.state, "bridge_startup_error", None))
        if jwt_mode:
            s["reason"] = ("AERIS_AUTH=jwt: the global telemetry bridge (one source for the whole backend) is switched off; each paired "
                           "device has its own owner-scoped telemetry (/api/v6/devices/{id}/live, /frames).")
        return s

    @app.get(P + "/hardware/status")
    async def hardware_status():
        return bridge_status()

    @app.get(P + "/telemetry/status")
    async def telemetry_status():
        return bridge_status()

    @app.post(P + "/telemetry/connect")
    async def telemetry_connect(body: Loose):
        try:
            return await bridge.connect(body.model_dump())
        except BridgeError as e:
            raise bridge_call_error(e)

    @app.post(P + "/telemetry/disconnect")
    async def telemetry_disconnect():
        return await bridge.disconnect("operator")

    @app.get(P + "/telemetry/files")
    async def telemetry_files():
        d = getattr(bridge, "telemetry_dir", None)
        if not d:
            return {"directory": None, "files": []}
        files = []
        if os.path.isdir(d):
            for name in sorted(os.listdir(d)):
                fp = os.path.join(d, name)
                if os.path.isfile(fp) and name.endswith((".ndjson", ".jsonl")):
                    files.append({"name": name, "bytes": os.path.getsize(fp)})
        return {"directory": d, "files": files}

    @app.get(P + "/telemetry/frames")
    async def telemetry_frames(after: int = Query(0, ge=0), limit: int = Query(500, ge=1, le=2000),
                               stream: str | None = Query(None, max_length=64, pattern=r"^[A-Za-z0-9._:-]+$")):
        """Polling fallback for clients without a WebSocket: accepted frames with index n > after. The cursor belongs
        to the stream named by `stream` (the stream_id of the status and of every batch); a cursor of another stream
        (the backend restarted) starts again at the beginning of this one and the answer says stream_changed: true."""
        if bridge.name == "none":
            raise ApiError(409, "telemetry_off", NoBridgeReason())
        return dict(bridge.hub.frames_after(after, limit, stream), provenance=bridge.hub.provenance(), stale=bridge.hub.stale, connected=bridge.hub.connected)

    @app.websocket(P + "/telemetry/live")
    async def telemetry_live(ws: WebSocket):
        """Live frames in batches: {"type": "frames", "stream": id, "frames": [...], "dropped": n} plus {"type": "status"}
        (with stream_id) about once a second. Frame indices n belong to the stream id (they restart with every backend
        process). Each client has a bounded queue (the oldest frames are dropped for a slow client; the count is sent).
        Read-only: messages from the client are ignored."""
        origin = ws.headers.get("origin")
        if origin is not None and origin not in st["origins"]:
            await ws.close(code=4403)
            return
        await ws.accept()
        if bridge.name == "none":
            await ws.send_json({"type": "error", "error": {"code": "telemetry_off", "message": NoBridgeReason()}})
            await ws.close(code=4409)
            return
        if live_sockets["n"] >= st.get("telemetry_max_live", 4):
            await ws.send_json({"type": "error", "error": {"code": "too_many_clients", "message": f"At most {st.get('telemetry_max_live', 4)} live telemetry clients; use GET /telemetry/frames to poll."}})
            await ws.close(code=4429)
            return
        try:
            sub = bridge.hub.subscribe()
        except OverflowError as e:
            await ws.send_json({"type": "error", "error": {"code": "too_many_clients", "message": str(e)}})
            await ws.close(code=4429)
            return
        live_sockets["n"] += 1
        loop = asyncio.get_running_loop()
        try:
            await ws.send_json({"type": "status", "status": bridge.status()})
            last_status = loop.time()
            while True:
                try:
                    await asyncio.wait_for(sub.event.wait(), timeout=0.25)
                except asyncio.TimeoutError:
                    pass
                batch = sub.drain(200)
                if batch:
                    await ws.send_json({"type": "frames", "stream": bridge.hub.stream_id, "frames": batch, "dropped": sub.dropped, "provenance": bridge.hub.provenance()})
                if loop.time() - last_status >= 1.0:
                    await ws.send_json({"type": "status", "status": bridge.status()})
                    last_status = loop.time()
        except (WebSocketDisconnect, RuntimeError, ConnectionError):
            pass
        finally:
            bridge.hub.unsubscribe(sub)
            live_sockets["n"] -= 1

    @app.post(P + "/telemetry/recordings/start", status_code=201)
    async def telemetry_record_start(body: RecordingStart):
        if bridge.name == "none":
            raise ApiError(409, "telemetry_off", NoBridgeReason())
        try:
            return dict(bridge.hub.start_recording(body.name, bridge.clock()), provenance=bridge.hub.provenance())
        except RuntimeError as e:
            raise ApiError(409, "recording_state", str(e))

    @app.post(P + "/telemetry/recordings/stop", status_code=201)
    async def telemetry_record_stop():
        if bridge.name == "none":
            raise ApiError(409, "telemetry_off", NoBridgeReason())
        try:
            doc = bridge.hub.stop_recording(bridge.clock())
        except RuntimeError as e:
            raise ApiError(409, "recording_state", str(e))
        return store_recording(doc, "telemetry-recorder")

    @app.post(P + "/hardware/frames/validate")
    async def validate_frame(body: Loose):
        return parse_frame(body.model_dump())

    @app.post(P + "/hardware/recordings", status_code=201)
    async def ingest(request: Request, body: Loose):
        return store_recording(body.model_dump(), "upload", owner=viewer(request))

    @app.get(P + "/hardware/recordings")
    async def list_recordings(request: Request, limit: int = Query(100, ge=1, le=1000)):
        """Stored recordings, newest first. Rows stored before v5.1 carry no trust class: it is computed here from the
        immutable document by the current rules (never higher than what was stored; nothing is rewritten)."""
        rows = list_visible("recordings", request, limit)
        for r in rows:
            if "trust" not in r:
                stored = repo.get("recordings", r["id"])
                if stored:
                    pr = effective_provenance(stored)
                    r.update(trust=pr["trust"], derived=pr["derived"], synthetic=bool(r.get("synthetic")) or pr["synthetic"])
        return {"recordings": rows}

    @app.get(P + "/hardware/recordings/{rid}")
    async def get_recording(request: Request, rid: str):
        rec = need_visible(repo.get("recordings", rid), "recording", rid, request)
        rec.setdefault("provenance", recording_provenance(rec["document"]))
        return rec

    @app.get(P + "/hardware/recordings/{rid}/export")
    async def export_recording(request: Request, rid: str, format: str = Query("json", pattern="^(json|ndjson)$"), omit_unmapped: bool = Query(False)):
        """json: the stored document unchanged (its own units). ndjson (v5.2): a replayable session in the protocol's wire
        units; what cannot be mapped without inventing or relabelling data is an HTTP 422 naming the columns, unless
        omit_unmapped=true leaves it out (recorded in every hello's lineage). The text is replayed through a scratch hub
        before it is returned (telemetry/export.py)."""
        rec = need_visible(repo.get("recordings", rid), "recording", rid, request)
        tag = "-SYNTHETIC" if rec.get("synthetic") else ""
        if format == "ndjson":
            try:
                text = await run_in_threadpool(recording_to_ndjson, rec["document"], rid, omit_unmapped=omit_unmapped)
            except ExportError as e:
                raise ApiError(422, "export_not_possible", str(e), e.details)
            return PlainTextResponse(text, media_type="application/x-ndjson",
                                     headers={"Content-Disposition": f'attachment; filename="{rid}{tag}.ndjson"'})
        return JSONResponse(rec["document"], headers={"Content-Disposition": f'attachment; filename="{rid}{tag}.json"'})

    @app.post(P + "/validation/protocols", status_code=201)
    async def create_protocol(body: ProtocolCreate):
        pid = "AERIS-VP-%04d" % repo.next_id("protocol")
        doc = {"id": pid, "created": now_iso(), "name": body.name, "description": body.description, "thresholds": body.thresholds,
               "note": "Acceptance thresholds registered before evaluation. A comparison uses them only for recordings ingested after this time."}
        repo.put_new("protocols", pid, doc, name=body.name)
        return doc

    @app.get(P + "/validation/protocols/{pid}")
    async def get_protocol(pid: str):
        return need(repo.get("protocols", pid), "protocol", pid)

    @app.post(P + "/hardware/compare")
    async def hw_compare(request: Request, body: HardwareCompareRequest):
        run = need_visible(repo.get_run(body.run_id), "run", body.run_id, request)
        rec = need_visible(repo.get("recordings", body.recording_id), "recording", body.recording_id, request)
        proto = need(repo.get("protocols", body.protocol_id), "protocol", body.protocol_id) if body.protocol_id else None
        return do_compare(run, rec, proto, body.max_lag_s, body.protocol_id)

    async def compare_recording(owner: str, run_id: str, rid: str, protocol_id: str | None, max_lag_s: float) -> dict:
        """/api/v6/twin/compare: the same comparison for an explicit owner (device recordings and twin runs)."""
        run = repo.get_run(run_id)
        if run is None or (jwt_mode and run.get("owner") not in (None, owner)):
            raise ApiError(404, "not_found", f"No run '{run_id}'.")
        rec = repo.get("recordings", rid)
        if rec is None or (jwt_mode and rec.get("owner") not in (None, owner)):
            raise ApiError(404, "not_found", f"No recording '{rid}'.")
        proto = need(repo.get("protocols", protocol_id), "protocol", protocol_id) if protocol_id else None
        if not 0 <= max_lag_s <= 5:
            raise ApiError(422, "invalid_request", "max_lag_s: 0…5")
        return await run_in_threadpool(do_compare, run, rec, proto, max_lag_s, protocol_id, True)

    def do_compare(run, rec, proto, max_lag_s, protocol_id, align_start=False):
        """align_start (v6.0 twin comparisons): the recording's t = 0 moves to the start of the experiment
        (hardware/compare.py align_on_experiment_start); the v1 comparison keeps the recording's own time."""
        v = validate_recording(rec["document"])
        pr = effective_provenance(rec)
        synthetic = pr["synthetic"]
        si, t0 = HWC.align_on_experiment_start(v["si"]) if align_start else (v["si"], None)
        res = HWC.compare(run, rec["document"], si, max_lag_s=max_lag_s, protocol=proto,
                          recording_meta={"created": rec["created"], "synthetic": synthetic, "trust": pr["trust"], "derived": pr["derived"], "quality": rec["quality"]})
        if t0:
            res["alignment"] = dict(res.get("alignment") or {}, **t0)
        reasons = []
        if synthetic:
            reasons.append("The recording is SYNTHETIC (" + str(pr.get("source_kind")) + "; " + "; ".join(pr["trust_reasons"]) + "): it is not a measurement and can never be validation evidence.")
        elif pr["trust"] == "unknown":
            reasons.append("The recording's origin is not declared (" + "; ".join(pr["trust_reasons"]) + "): unknown provenance is never validation evidence.")
        if not pr.get("declared_physical"):
            reasons.append("No telemetry source declared this recording as coming from a physical device.")
        if pr["derived"]:
            reasons.append("The recording was captured from a replay (" + str(pr.get("derived_from") or "an exported recording") + "): a copy of earlier data, "
                           "not an original measurement; compare the original recording.")
        if proto is None:
            reasons.append("No predeclared validation protocol was named, so no acceptance thresholds apply.")
        elif res.get("acceptance") and not res["acceptance"]["admissible_as_evidence"]:
            reasons += res["acceptance"]["notes"]
        evidence = {"admissible_as_validation_evidence": not reasons, "reasons": reasons, "recording_provenance": pr,
                    "model_status_change": "none — the software never promotes a model to VALIDATED; a person reviews admissible evidence."}
        cid = "AERIS-CMP-%06d" % repo.next_id("comparison")
        doc = {"id": cid, "created": now_iso(), "run_id": run["id"], "run_config_hash": (run.get("reproduction") or {}).get("config_hash"),
               "recording_id": rec["id"], "recording_hash": rec["content_hash"], "protocol_id": protocol_id, "synthetic": synthetic,
               "evidence": evidence, "result": res}
        repo.put_new("comparisons", cid, doc, run_id=run["id"], recording_id=rec["id"], synthetic=synthetic)
        return doc

    # ------------------------------------------------------------------ v6.0: devices (/api/v6)
    from . import devices_api
    devices_api.mount(app, repo=repo, settings=st, authn=authn, tickets=tickets, store_recording=store_recording, manager=manager,
                      compare_recording=compare_recording)

    # ------------------------------------------------------------------ the static site on the same origin (optional)
    if st.get("site_dir"):
        from starlette.staticfiles import StaticFiles
        site_dir = os.path.abspath(st["site_dir"])
        if not os.path.isfile(os.path.join(site_dir, "index.html")):
            raise ValueError(f"AERIS_SITE_DIR: no index.html in {site_dir}")
        CONFIG_JS = ('<script>window.AERIS_CONFIG = {researchApi: {baseUrl: location.origin, wsUrl: (location.protocol === "https:" ? "wss://" : "ws://") + location.host,'
                     ' pollMs: 1000, probeMs: 60000, mock: false}};</script>')

        def index_page():
            html = open(os.path.join(site_dir, "index.html"), encoding="utf-8").read()
            i = html.find("<script")
            html = html[:i] + CONFIG_JS + "\n" + html[i:] if i >= 0 else html.replace("</head>", CONFIG_JS + "</head>", 1)
            return HTMLResponse(html, headers={"Cache-Control": "no-store"})

        @app.get("/", include_in_schema=False)
        async def site_root():
            return index_page()

        @app.get("/index.html", include_in_schema=False)
        async def site_index():
            return index_page()

        app.mount("/", StaticFiles(directory=site_dir), name="site")

    return app

"""/api/v6 — devices and the physical (or synthetic) cube: ownership, pairing, device profiles, experiment recipes, kits,
calibrations, approved configurations, control leases, bounded commands, per-device telemetry and recordings, and the
digital twin of a profile (site/docs/CONNECT.md, site/docs/DEVICE_LINK.md).

Authentication (devices/auth.py): AERIS_AUTH=local (one owner, this computer only) or jwt (bearer tokens of the
configured identity provider). Browser WebSockets cannot carry an Authorization header: they present a single-use
ticket obtained with POST /api/v6/tickets (30 s). The companion (a program) may send the header instead.

WebSockets
  /api/v6/device-link           the device's own outbound connection (wss through the TLS proxy). The device proves
                                its identity with the key registered at pairing (challenge-response) within 10 s or
                                the socket is closed. Binary frames carry aeris-device-link/1 bytes.
  /api/v6/relay?route=…         the owner's companion (route=companion) or browser (route=browser-relay) relaying a
                                USB serial port: binary frames are link bytes in both directions; text frames are
                                control messages ({"op": "pair", "name": …}, {"op": "status"} → {"type": …} replies).
  /api/v6/devices/{id}/live     the owner's view: device state, command progress, route changes, telemetry frames.
Every HTTP answer for another owner's device is 404, exactly as for a device that does not exist.
"""
from __future__ import annotations

import asyncio
import json
import secrets
import time

from fastapi import Body, Query, Request, WebSocket
from starlette.concurrency import run_in_threadpool

from ..config.validate import validate_config
from ..devices import configgen, reference
from ..devices.auth import AuthError
from ..devices.service import REMOTE_ACTIONS, DeviceService, ServiceError
from .errors import ApiError

V6 = "/api/v6"
AUTH_DEADLINE_S = 10.0
MAX_WS_MESSAGE = 65536
MAX_GATEWAY_PENDING = 32        # connections that have not authenticated yet
MAX_LIVE_PER_DEVICE = 8


class Tickets:
    """Single-use, short-lived WebSocket tickets bound to an owner and a purpose (random 192-bit tokens)."""

    def __init__(self, ttl_s: float = 30.0, clock=time.monotonic):
        self.ttl_s, self.clock = ttl_s, clock
        self._t = {}

    def issue(self, owner: str, purpose: str) -> dict:
        now = self.clock()
        for k in [k for k, v in self._t.items() if v[2] < now]:
            del self._t[k]
        if len(self._t) > 10000:
            raise ApiError(429, "rate_limited", "too many open tickets")
        tok = secrets.token_urlsafe(24)
        self._t[tok] = (owner, purpose, now + self.ttl_s)
        return {"ticket": tok, "purpose": purpose, "expires_in_s": self.ttl_s}

    def take(self, tok: str | None, purpose: str) -> str | None:
        if not tok:
            return None
        v = self._t.pop(tok, None)
        if v is None or v[1] != purpose or v[2] < self.clock():
            return None
        return v[0]


def mount(app, *, repo, settings: dict, authn, tickets: Tickets, store_recording, manager, compare_recording):
    svc = DeviceService(repo, authn, store_recording=store_recording, gateway_id=settings.get("gateway_id") or "aeris-backend")
    app.state.devices = svc
    origins = list(settings.get("origins") or [])
    counts = {"gateway_pending": 0, "live": {}}

    def owner_of(request: Request) -> str:
        try:
            return authn.owner(request.headers.get("authorization"))
        except AuthError as e:
            raise ApiError(e.status, "device_api_disabled" if e.status == 503 else "unauthorized", e.message)

    def run(fn, *a, **k):
        try:
            return fn(*a, **k)
        except ServiceError as e:
            raise ApiError(e.status, e.code, e.message, e.details)

    async def run_bg(fn, *a, **k):
        try:
            return await run_in_threadpool(fn, *a, **k)
        except ServiceError as e:
            raise ApiError(e.status, e.code, e.message, e.details)

    # ------------------------------------------------------------------ service
    @app.get(V6 + "/status")
    async def v6_status():
        """Public: whether the device API is enabled, its authentication mode and what this backend offers."""
        s = svc.status()
        return dict(s, api="aeris-devices/1", link="aeris-device-link/1", websockets={"device_link": V6 + "/device-link", "relay": V6 + "/relay",
                    "live": V6 + "/devices/{id}/live"}, tickets_needed=authn.cfg.mode == "jwt",
                    remote_actions=sorted(REMOTE_ACTIONS),
                    usb_local_only=["set_network", "unpair", "enter_update", "commission", "motor_test"],
                    note="Commands never arm motors: an experiment starts only after a press of ARM on the cube; stop is always accepted.")

    @app.get(V6 + "/me")
    async def v6_me(request: Request):
        return {"owner": owner_of(request), "mode": authn.cfg.mode}

    @app.post(V6 + "/tickets", status_code=201)
    async def v6_ticket(request: Request, body: dict = Body(default={})):
        owner = owner_of(request)
        purpose = (body or {}).get("purpose", "live")
        if purpose not in ("live", "relay", "v1-live"):
            raise ApiError(422, "invalid_request", "purpose: live, relay or v1-live")
        return tickets.issue(owner, purpose)

    # ------------------------------------------------------------------ profiles, recipes, kits
    @app.get(V6 + "/profiles")
    async def v6_profiles(request: Request):
        return {"profiles": run(svc.profile_list, owner_of(request))}

    @app.get(V6 + "/profiles/{pid}")
    async def v6_profile(request: Request, pid: str, revision: int | None = Query(None, ge=1)):
        return run(svc.profile_get, owner_of(request), pid, revision)

    @app.post(V6 + "/profiles", status_code=201)
    async def v6_profile_create(request: Request, body: dict = Body(...)):
        return run(svc.profile_create_revision, owner_of(request), body)

    @app.post(V6 + "/profiles/validate")
    async def v6_profile_validate(request: Request, body: dict = Body(...)):
        owner_of(request)
        from ..devices import schemas
        return schemas.validate_profile(body, author_is_user=True)

    @app.get(V6 + "/recipes")
    async def v6_recipes(request: Request):
        return {"recipes": run(svc.recipe_list, owner_of(request))}

    @app.get(V6 + "/recipes/{rid}")
    async def v6_recipe(request: Request, rid: str):
        return run(svc.recipe_get, owner_of(request), rid)

    @app.post(V6 + "/recipes", status_code=201)
    async def v6_recipe_create(request: Request, body: dict = Body(...)):
        return run(svc.recipe_create, owner_of(request), body)

    @app.get(V6 + "/kits")
    async def v6_kits():
        """Public kit content (versioned build guides, BOM references, readiness): the same documents the site serves."""
        return {"kits": [{k: d.get(k) for k in ("id", "revision", "name", "readiness")} for d in reference.kits()]}

    @app.get(V6 + "/kits/{kid}")
    async def v6_kit(kid: str, revision: str | None = None):
        for d in reference.kits():
            if d["id"] == kid and (revision is None or d["revision"] == revision):
                return d
        raise ApiError(404, "not_found", f"No kit '{kid}'" + (f" revision {revision}" if revision else "") + ".")

    # ------------------------------------------------------------------ devices and pairing
    @app.get(V6 + "/devices")
    async def v6_devices(request: Request):
        return {"devices": run(svc.device_list, owner_of(request))}

    @app.get(V6 + "/devices/{device_id}")
    async def v6_device(request: Request, device_id: str):
        return run(svc.device_view, owner_of(request), device_id)

    @app.post(V6 + "/devices/{device_id}/profile")
    async def v6_device_profile(request: Request, device_id: str, body: dict = Body(...)):
        if not isinstance(body.get("id"), str) or not isinstance(body.get("revision"), int):
            raise ApiError(422, "invalid_request", "{id, revision} of a profile revision")
        return run(svc.device_set_profile, owner_of(request), device_id, body["id"], body["revision"])

    @app.post(V6 + "/devices/{device_id}/name")
    async def v6_device_name(request: Request, device_id: str, body: dict = Body(...)):
        owner = owner_of(request)
        name = body.get("name")
        if not isinstance(name, str) or not 0 < len(name.strip()) <= 80:
            raise ApiError(422, "invalid_request", "name: 1…80 characters")
        run(svc.device_get, owner, device_id)
        return repo.device_update(device_id, owner, name=name.strip())

    @app.post(V6 + "/devices/{device_id}/revoke")
    async def v6_device_revoke(request: Request, device_id: str):
        """Forget the device's credential: its connections close at once and it must be paired again (the device keeps
        its key until it is unpaired locally)."""
        return run(svc.device_revoke, owner_of(request), device_id)

    @app.post(V6 + "/pairing/start", status_code=201)
    async def v6_pairing_start(request: Request):
        """For a client that talks to the device itself (the Connect page over Web Serial): a single-use session and
        nonce (5 min) to send in pair_begin; the device signs them after its ARM press and the client posts the proof."""
        return run(svc.pairing_start, owner_of(request))

    @app.post(V6 + "/pairing/complete", status_code=201)
    async def v6_pairing_complete(request: Request, body: dict = Body(...)):
        proof = body.get("proof") if isinstance(body.get("proof"), dict) else body
        return run(svc.pairing_complete, owner_of(request), dict(proof, via=proof.get("via") or "client"), name=body.get("name"))

    # ------------------------------------------------------------------ calibrations and approved configurations
    @app.get(V6 + "/devices/{device_id}/calibrations")
    async def v6_calibrations(request: Request, device_id: str):
        return {"calibrations": run(svc.calibration_list, owner_of(request), device_id)}

    @app.post(V6 + "/devices/{device_id}/calibrations", status_code=201)
    async def v6_calibration_create(request: Request, device_id: str, body: dict = Body(...)):
        return run(svc.calibration_create, owner_of(request), device_id, body)

    @app.get(V6 + "/calibrations/{cid}")
    async def v6_calibration(request: Request, cid: str):
        return run(svc.calibration_get, owner_of(request), cid)

    @app.post(V6 + "/devices/{device_id}/configs", status_code=201)
    async def v6_config_build(request: Request, device_id: str, body: dict = Body(...)):
        owner = owner_of(request)
        if not isinstance(body.get("recipe"), str):
            raise ApiError(422, "invalid_request", "recipe: the id of an experiment recipe")
        return await run_bg(svc.build_config, owner, device_id, body["recipe"], body.get("calibration"), body.get("profile"))

    @app.get(V6 + "/configs/{h}")
    async def v6_config(request: Request, h: str):
        return run(svc.config_get, owner_of(request), h)

    # ------------------------------------------------------------------ leases and commands
    @app.post(V6 + "/devices/{device_id}/lease")
    async def v6_lease(request: Request, device_id: str, body: dict = Body(...)):
        holder = body.get("holder")
        if not isinstance(holder, str) or not 8 <= len(holder) <= 64:
            raise ApiError(422, "invalid_request", "holder: the client's session id (8…64 characters)")
        return run(svc.lease_acquire, owner_of(request), device_id, holder, bool(body.get("takeover")))

    @app.post(V6 + "/devices/{device_id}/lease/release")
    async def v6_lease_release(request: Request, device_id: str, body: dict = Body(...)):
        return run(svc.lease_release, owner_of(request), device_id, str(body.get("holder") or ""))

    @app.post(V6 + "/devices/{device_id}/commands", status_code=201)
    async def v6_command(request: Request, device_id: str, body: dict = Body(...)):
        owner = owner_of(request)
        action = body.get("action")
        if not isinstance(action, str):
            raise ApiError(422, "invalid_request", "action is required")
        params = body.get("params")
        if params is not None and not isinstance(params, dict):
            raise ApiError(422, "invalid_request", "params must be an object")
        ttl = body.get("ttl_ms", 5000)
        return run(svc.command_submit, owner, device_id, body.get("holder"), action, params, ttl, body.get("config_hash"), body.get("route"))

    @app.get(V6 + "/devices/{device_id}/commands")
    async def v6_commands(request: Request, device_id: str, limit: int = Query(50, ge=1, le=500)):
        owner = owner_of(request)
        run(svc.device_get, owner, device_id)
        return {"commands": repo.command_list(device_id, owner, limit)}

    @app.get(V6 + "/commands/{cid}")
    async def v6_command_get(request: Request, cid: str):
        return run(svc.command_get, owner_of(request), cid)

    # ------------------------------------------------------------------ telemetry and recordings
    @app.get(V6 + "/devices/{device_id}/frames")
    async def v6_frames(request: Request, device_id: str, after: int = Query(0, ge=0), limit: int = Query(500, ge=1, le=2000),
                        stream: str | None = Query(None, max_length=64, pattern=r"^[A-Za-z0-9._:-]+$")):
        rt = run(svc.runtime, owner_of(request), device_id)
        return dict(rt.hub.frames_after(after, limit, stream), provenance=rt.hub.provenance(), stale=rt.hub.stale, connected=bool(rt.routes))

    @app.post(V6 + "/devices/{device_id}/recordings/start", status_code=201)
    async def v6_rec_start(request: Request, device_id: str, body: dict = Body(default={})):
        name = (body or {}).get("name") or "device recording"
        if not isinstance(name, str) or len(name) > 200:
            raise ApiError(422, "invalid_request", "name: at most 200 characters")
        return run(svc.recording_start, owner_of(request), device_id, name)

    @app.post(V6 + "/devices/{device_id}/recordings/stop", status_code=201)
    async def v6_rec_stop(request: Request, device_id: str):
        return run(svc.recording_stop, owner_of(request), device_id)

    @app.get(V6 + "/devices/{device_id}/recordings")
    async def v6_recordings(request: Request, device_id: str, limit: int = Query(100, ge=1, le=1000)):
        owner = owner_of(request)
        run(svc.device_get, owner, device_id)
        return {"recordings": repo.list_where("recordings", limit, owner=owner, device_id=device_id)}

    # ------------------------------------------------------------------ the twin of a profile
    @app.post(V6 + "/twin/simulate", status_code=202)
    async def v6_twin_simulate(request: Request, body: dict = Body(...)):
        """Simulate My Cube: the research engine runs the engine configuration of a profile revision, a recipe and
        (optionally) a calibration — the same model the approved configuration's gains were designed on."""
        owner = owner_of(request)
        pr = body.get("profile") or {}
        if body.get("device_id"):
            dev = run(svc.device_get, owner, body["device_id"])
            pr = pr or {"id": dev.get("profile_id"), "revision": dev.get("profile_revision")}
        prof = run(svc.profile_get, owner, pr.get("id") or reference.REFERENCE_PROFILE["id"], pr.get("revision"))
        rec = run(svc.recipe_get, owner, body.get("recipe") or "edge-hold-10s")
        cal = run(svc.calibration_get, owner, body["calibration"]) if body.get("calibration") else None
        seed = body.get("seed", 7)
        if not isinstance(seed, int) or isinstance(seed, bool) or not 0 <= seed < 2**31:
            raise ApiError(422, "invalid_request", "seed: an integer 0…2^31-1")
        try:
            cfg = await run_in_threadpool(configgen.engine_config, prof["document"], rec["document"], cal["document"] if cal else None, seed=seed)
        except configgen.ConfigError as e:
            raise ApiError(422, "config_error", str(e), e.errors)
        twin = {"profile": {"id": prof["id"], "revision": prof["revision"], "hash": prof["hash"]}, "recipe": {"id": rec["id"], "hash": rec["hash"]},
                "calibration": {"id": cal["id"], "hash": cal["hash"]} if cal else None, "owner": owner}
        # one parameter source (PRF-5): the run is labelled by the coverage rule of docs/PARAMETERS.md with the profile's
        # value groups declared measured (never by the backend's global parameter set, which describes another cube)
        v = validate_config(cfg, manager.limits)
        ps = configgen.profile_parameter_set(prof["document"], twin["profile"], v.config if v.ok else None)
        job = manager.submit_simulation(cfg, {"name": f"Twin: {prof['document'].get('name', prof['id'])} r{prof['revision']} · {rec['id']}", "twin": twin},
                                        extra={"twin": twin, "owner": owner}, parameter_set=ps)
        return {"job": job, "engine_config": cfg, "twin": twin, "parameter_set": {k: ps[k] for k in ("id", "status", "source", "applied")},
                "note": "A simulation of the profile's MODEL (nominal and declared values unless the profile says measured); not a measurement."}

    @app.post(V6 + "/twin/compare")
    async def v6_twin_compare(request: Request, body: dict = Body(...)):
        """Compare a device recording with a twin run (the v1 comparison with ownership checks)."""
        owner = owner_of(request)
        rid, run_id = body.get("recording_id"), body.get("run_id")
        if not isinstance(rid, str) or not isinstance(run_id, str):
            raise ApiError(422, "invalid_request", "run_id and recording_id are required")
        return await compare_recording(owner, run_id, rid, body.get("protocol_id"), float(body.get("max_lag_s", 0.25)))

    # ------------------------------------------------------------------ WebSockets
    def ws_origin_ok(ws: WebSocket) -> bool:
        return authn.check_origin(ws.headers.get("origin"), origins)

    async def ws_owner(ws: WebSocket, purpose: str) -> str | None:
        """The owner of a WebSocket: Authorization header (programs) or a ticket (browsers); local mode: 'local'."""
        if not authn.cfg.ok:
            return None
        if authn.cfg.mode == "local":
            return authn.owner(None)
        hdr = ws.headers.get("authorization")
        if hdr:
            try:
                return authn.owner(hdr)
            except AuthError:
                return None
        return tickets.take(ws.query_params.get("ticket"), purpose)

    async def link_socket(ws: WebSocket, c, *, relay: bool, auth_deadline_s: float | None, on_text=None) -> str:
        async def reader():
            while True:
                msg = await ws.receive()
                if msg["type"] == "websocket.disconnect":
                    return "the other side closed the connection"
                b = msg.get("bytes")
                if b is not None:
                    if len(b) > MAX_WS_MESSAGE:
                        return "message too large"
                    c.host.receive(b)
                elif msg.get("text") is not None:
                    if relay:
                        await on_text(msg["text"])
                    else:
                        t = msg["text"].encode("utf-8")
                        if len(t) > MAX_WS_MESSAGE:
                            return "message too large"
                        c.host.receive(t)

        async def writer():
            while True:
                b = await c.out.get()
                parts, n = [b], len(b)
                while n < 32768 and not c.out.empty():
                    x = c.out.get_nowait()
                    parts.append(x)
                    n += len(x)
                await ws.send_bytes(b"".join(parts))

        async def ctl_writer():
            while True:
                m = await c.ctl.get()
                await ws.send_text(json.dumps(m, default=str))

        async def watchdog():
            if auth_deadline_s:
                try:
                    await asyncio.wait_for(c.closed.wait(), timeout=auth_deadline_s)
                except asyncio.TimeoutError:
                    if not c.host.authenticated:
                        return "the device did not authenticate in time"
            await c.closed.wait()
            await asyncio.sleep(0.05)          # let the writer flush a last message (e.g. why pairing failed)
            return c.close_reason or "closed"

        tasks = [asyncio.create_task(reader()), asyncio.create_task(writer()), asyncio.create_task(watchdog())]
        if relay:
            tasks.append(asyncio.create_task(ctl_writer()))
        done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        reason = "closed"
        for t in done:
            if t.cancelled():
                continue
            if t.exception() is not None:
                reason = f"transport error: {type(t.exception()).__name__}"
            elif isinstance(t.result(), str):
                reason = t.result()
        for t in pending:
            t.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
        return reason

    async def close_ws(ws: WebSocket, code: int, reason: str = ""):
        try:
            await ws.close(code=code, reason=reason[:120])
        except Exception:
            pass

    async def refuse(ws: WebSocket, code: int, reason: str):
        """Refusals are sent as a close code after the handshake (a client — browser or companion — can read why; a
        handshake rejection would only show an opaque HTTP 403)."""
        try:
            await ws.accept()
        except Exception:
            return
        await close_ws(ws, code, reason)

    @app.websocket(V6 + "/device-link")
    async def ws_device_link(ws: WebSocket):
        if not authn.cfg.ok:
            await refuse(ws, 4503, "device API disabled")
            return
        if ws.headers.get("origin") is not None:
            await refuse(ws, 4403, "devices do not send an Origin")   # a browser page cannot pose as a device
            return
        if counts["gateway_pending"] >= MAX_GATEWAY_PENDING:
            await refuse(ws, 4429, "too many unauthenticated connections")
            return
        await ws.accept()
        counts["gateway_pending"] += 1
        c = svc.connection_open("gateway", None)
        pending = True

        async def authed_watch():
            nonlocal pending
            while pending and not c.closed.is_set():
                if c.host.authenticated:
                    counts["gateway_pending"] -= 1
                    pending = False
                    return
                await asyncio.sleep(0.05)
        aw = asyncio.create_task(authed_watch())
        try:
            reason = await link_socket(ws, c, relay=False, auth_deadline_s=AUTH_DEADLINE_S)
        finally:
            aw.cancel()
            if pending:
                counts["gateway_pending"] -= 1
            svc.connection_closed(c, "device link closed")
        await close_ws(ws, 1000 if c.host.authenticated else 4401, reason)

    @app.websocket(V6 + "/relay")
    async def ws_relay(ws: WebSocket, route: str = Query("companion")):
        if route not in ("companion", "browser-relay"):
            await refuse(ws, 4400, "route: companion or browser-relay")
            return
        if not ws_origin_ok(ws):
            await refuse(ws, 4403, "origin not allowed")
            return
        owner = await ws_owner(ws, "relay")
        if owner is None:
            await refuse(ws, 4401 if authn.cfg.ok else 4503, "authentication required")
            return
        await ws.accept()
        c = svc.connection_open(route, owner)
        c.notify({"type": "relay", "route": route, "owner": owner, "link": "aeris-device-link/1",
                  "note": "write the binary frames you receive to the serial port unchanged; send what the port reads as binary frames"})

        async def on_text(t: str):
            try:
                m = json.loads(t)
            except ValueError:
                c.notify({"type": "error", "error": "control messages are JSON objects"})
                return
            op = m.get("op") if isinstance(m, dict) else None
            try:
                if op == "pair":
                    svc.pair_via_connection(owner, c, m.get("name"))
                elif op == "status":
                    c.notify({"type": "status", "device_id": c.device_id, "session_ok": c.host.session_ok, "role": c.host.role,
                              "paired_to_you": bool(c.device_id and c.device_id in svc.runtimes and svc.runtimes[c.device_id].routes.get(route) is c),
                              "link_stats": c.host.stats, "pairing": c.pair_outcome})
                else:
                    c.notify({"type": "error", "error": f"unknown op {op!r} (pair, status)"})
            except ServiceError as e:
                c.notify({"type": "error", "code": e.code, "error": e.message})
        try:
            reason = await link_socket(ws, c, relay=True, auth_deadline_s=None, on_text=on_text)
        finally:
            svc.connection_closed(c, "relay closed")
        await close_ws(ws, 1000, reason)

    @app.websocket(V6 + "/devices/{device_id}/live")
    async def ws_device_live(ws: WebSocket, device_id: str):
        if not ws_origin_ok(ws):
            await refuse(ws, 4403, "origin not allowed")
            return
        owner = await ws_owner(ws, "live")
        if owner is None:
            await refuse(ws, 4401 if authn.cfg.ok else 4503, "authentication required")
            return
        try:
            q, rt = svc.subscribe(owner, device_id)
        except ServiceError:
            await refuse(ws, 4404, "not found")
            return
        n = counts["live"].get(device_id, 0)
        if n >= MAX_LIVE_PER_DEVICE:
            svc.unsubscribe(device_id, q)
            await refuse(ws, 4429, "too many live views of this device")
            return
        await ws.accept()
        counts["live"][device_id] = n + 1
        sub = rt.hub.subscribe()
        loop = asyncio.get_running_loop()
        try:
            await ws.send_json({"type": "device", "device": json.loads(json.dumps(svc.device_view(owner, device_id), default=str))})
            last_status = loop.time()
            while True:
                try:
                    m = await asyncio.wait_for(q.get(), timeout=0.2)
                    await ws.send_text(json.dumps(m, default=str))
                    while not q.empty():
                        await ws.send_text(json.dumps(q.get_nowait(), default=str))
                except asyncio.TimeoutError:
                    pass
                batch = sub.drain(200)
                if batch:
                    await ws.send_json({"type": "frames", "stream": rt.hub.stream_id, "frames": batch, "dropped": sub.dropped,
                                        "provenance": rt.hub.provenance()})
                if loop.time() - last_status >= 1.0:
                    await ws.send_json({"type": "status", "connected": bool(rt.routes), "routes": sorted(rt.routes), "state": rt.state,
                                        "telemetry": rt.hub.status(time.monotonic())})
                    last_status = loop.time()
        except Exception:
            pass
        finally:
            rt.hub.unsubscribe(sub)
            svc.unsubscribe(device_id, q)
            counts["live"][device_id] = max(0, counts["live"].get(device_id, 1) - 1)

    return svc

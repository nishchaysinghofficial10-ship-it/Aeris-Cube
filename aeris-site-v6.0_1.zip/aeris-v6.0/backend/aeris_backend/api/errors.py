"""The error envelope shared by /api/v1 and /api/v6: {"error": {code, message, details, retryable}}."""
from __future__ import annotations


class ApiError(Exception):
    def __init__(self, status, code, message, details=None, retryable=False):
        super().__init__(message)
        self.status, self.code, self.message, self.details, self.retryable = status, code, message, details or [], retryable


def envelope(code, message, details=None, retryable=False):
    return {"error": {"code": code, "message": message, "details": details or [], "retryable": retryable}}

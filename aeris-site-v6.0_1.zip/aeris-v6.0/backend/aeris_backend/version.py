"""Version identifiers written into every record the backend produces."""
import platform
import sys

BACKEND_NAME = "aeris-research-backend"
BACKEND_VERSION = "1.2.0"   # 1.2.0 (AERIS v6.0): device API /api/v6, schema 3 (additive); the engine is unchanged
# 1.1.2 (AERIS v5.2): NDJSON export in wire units, bounded lineage (additive)
# 1.1.1 (AERIS v5.1): telemetry provenance and stream identity (additive)
# The physics/numerics version. Bump when a change can alter a trajectory.
# 1.1.0 (AERIS v5): controller-facing estimator prediction and MEKF reset Jacobian (cf3d/mekf runs change),
#                   general initial state and reference block (new configurations only).
ENGINE_VERSION = "aeris-research-engine 1.1.0"
# The browser engine whose conventions and default behaviour this engine reproduces.
PARITY_TARGET = "aeris-twin 0.3.0"
CONFIG_SCHEMA = "aeris-config/1"
CONFIG_REVISION = "1.2"
CONFIG_REVISIONS_READ = ("1.0", "1.1", "1.2")
RUN_SCHEMA = "aeris-run/1"
RUN_REVISION = "1.3"
SWEEP_SCHEMA = "aeris-sweep/1"
SWEEP_REVISION = "1.2"
DATASET_SCHEMA = "aeris-dataset/1"
JOB_SCHEMA = "aeris-job/1"
HARDWARE_RUN_SCHEMA = "aeris-hardware-run/1"
FRAME_SCHEMA = "aeris-telemetry-frame/1"
API_PREFIX = "/api/v1"


def software_versions() -> dict:
    """Interpreter and numerical library versions (stored with every run for reproduction)."""
    import numpy
    import scipy
    return {
        "backend": BACKEND_NAME + " " + BACKEND_VERSION,
        "engine": ENGINE_VERSION,
        "python": sys.version.split()[0],
        "numpy": numpy.__version__,
        "scipy": scipy.__version__,
        "platform": platform.platform(terse=True),
        "machine": platform.machine(),
    }

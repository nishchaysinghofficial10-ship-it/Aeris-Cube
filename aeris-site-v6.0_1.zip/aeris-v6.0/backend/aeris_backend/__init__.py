"""AERIS research backend: the authoritative Python engine behind SIMULATION mode.

Package layout (see backend/README.md and docs/PHYSICS.md):
    config/       aeris-config/1 (revision 1.1) normalisation and validation layers
    physics/      quaternions, mass properties, plant dynamics, RK4
    actuators     wheel model and torque allocation (aeris_backend.actuators)
    sensors       IMU model with timestamps (aeris_backend.sensors)
    estimation/   ideal, browser edge estimators, complementary 3-D, quaternion MEKF
    control/      controller designs and laws (PID, LQR, MIMO LQR, COM-adaptive, nonlinear)
    simulation/   the single run engine
    metrics/      legacy assessment (browser parity), event timeline, research metrics
    experiments/  run records, sweeps, analysis, datasets
    jobs/         job manager (process pool, cancel, restart)
    storage/      repository interface and SQLite implementation
    hardware/     strict recording ingestion, telemetry bridge, sim-vs-hardware comparison
    api/          FastAPI application (/api/v1)

Every simulated number uses the configured (nominal unless stated) parameters. Nothing in
this package is a hardware measurement.
"""
from .version import BACKEND_NAME, BACKEND_VERSION, ENGINE_VERSION  # noqa: F401

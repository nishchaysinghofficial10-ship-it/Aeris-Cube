"""Research sweeps (aeris-sweep/1, revision 1.1 = revision 1.0 plus optional fields).

Definition (revision 1.0 fields keep the browser's meaning, site/js/platform/sweep.js):
  base, mode grid|random|montecarlo, seed, samples, controllers, mass_configs, variables,
  disturbance, duration_s, record_hz
Revision 1.1 additions:
  variables[i].path       any numeric configuration path (e.g. "params.Jw", "wheels.1.Imax",
                          "uncertainty.inertia_perturbation_kgm2.0.1", "controller.lqr.tilt_deg");
                          the legacy named variables (variables[i].key) still work
  variables[i].dist       uniform | normal | bounded-normal | categorical   (see DISTRIBUTIONS)
  controllers             may also contain "nlpd" and "lqr-mimo" (LQR with structure mimo-lqr)
  estimators              optional list: every point is run with each estimator
  seed_strategy           paired (default) | legacy | fixed | independent  (see SEED_STRATEGIES)
  limits                  optional per-sweep caps (never above the backend's)
Every sampled value, the seed and the resulting configuration hash are saved with each row;
invalid and failed runs stay in the rows. The analysis uses the saved rows only.
"""
from __future__ import annotations

import copy
import math

from scipy.special import ndtr, ndtri

from ..config.normalize import default_config, default_wheels, normalize
from ..constants import BACKEND_LIMITS, DEG, SENSOR_DEFAULTS
from ..rng import Rng, derive_seed
from .records import canonical_hash

SCHEMA_ID = "aeris-sweep/1"
REVISION = "1.2"

DISTRIBUTIONS = {
    "uniform": "U(min, max), each sample independent.",
    "normal": "N(mean, sd) without truncation. A sample outside [min, max] is NOT clipped or redrawn: its run is recorded as invalid (outside the stated range) and stays in the rows, so the sampled distribution is exactly the normal one.",
    "bounded-normal": "Exact truncated normal on [min, max]: x = mean + sd·Φ⁻¹(Φ(a) + u(Φ(b) − Φ(a))) with a, b the standardised bounds (inverse-CDF sampling, no clipping, no redraw loop). Rejected at validation if the interval holds less than 1e-9 of the probability.",
    "categorical": "One of `values` with the given `probabilities` (default equal). A grid uses every value once.",
}
CRITERIA = {
    "legacy": "the legacy outcome 'recovered' (COM lean within ±0.25° held to the end of the window; the browser rule)",
    "research": "the research recovery criteria of each run (attitude error and body rate within their thresholds for hold_s, reached by max_time_s): first recovery",
    "research_sustained": "research recovery that is sustained: recovered, no exit from the criteria afterwards and no fall after recovery",
}
SEED_STRATEGIES = {
    "paired": "Noise seed per point: derive_seed(sweep seed, point index, 'noise'). Every controller, mass configuration and estimator at the same point gets the same seed, so their comparison is paired.",
    "legacy": "The browser's rule: Monte Carlo points get seed + point index; other modes keep the base seed (also paired across controllers).",
    "fixed": "Every run uses the base configuration's seed.",
    "independent": "Every run gets its own seed derive_seed(sweep seed, run index, 'noise') (unpaired).",
}


def _set_disturbance(c, v, d):
    tpl = (d or {}).get("disturbance") or {}
    a = c["params"]["a"]
    c["disturbances"] = [L for L in c["disturbances"] if L.get("id") != "SWEEP-F"]
    if v > 0:
        c["disturbances"].append({"id": "SWEEP-F", "type": "force", "magnitude_N": v,
                                  "point_m": tpl.get("point_m") or ([a / 2, a, a] if c["mode"] == "edge" else [a, a, a]),
                                  "direction": tpl.get("direction") or ([0, 1, 0] if c["mode"] == "edge" else [1, 0.4, 0]),
                                  "frame": tpl.get("frame") or "world", "t_start_s": tpl.get("t_start_s", 1), "duration_s": tpl.get("duration_s", 0.2)})


def _noise(c, v, d):
    c["sensor"]["gyro_noise_dps"] = SENSOR_DEFAULTS["gyro_noise_dps"] * v
    c["sensor"]["accel_noise_mps2"] = SENSOR_DEFAULTS["accel_noise_mps2"] * v


# the browser's named variables (same keys, ranges and effects)
VARIABLES = {
    "com_x_mm": {"label": "COM shift x (body)", "unit": "mm", "min": -50, "max": 50, "apply": lambda c, v, d: c["comShift_m"].__setitem__(0, v / 1000)},
    "com_y_mm": {"label": "COM shift y (body)", "unit": "mm", "min": -50, "max": 50, "apply": lambda c, v, d: c["comShift_m"].__setitem__(1, v / 1000)},
    "com_z_mm": {"label": "COM shift z (body)", "unit": "mm", "min": -50, "max": 50, "apply": lambda c, v, d: c["comShift_m"].__setitem__(2, v / 1000)},
    "tilt_deg": {"label": "Initial tilt", "unit": "°", "min": -30, "max": 30, "apply": lambda c, v, d: c["initial"].__setitem__("tilt_deg", v)},
    "rate_dps": {"label": "Initial angular velocity", "unit": "°/s", "min": -200, "max": 200, "apply": lambda c, v, d: c["initial"].__setitem__("rate_dps", v)},
    "torque_pct": {"label": "Torque limit", "unit": "% of nominal", "min": 20, "max": 200, "apply": lambda c, v, d: c.__setitem__("torqueScale", v / 100)},
    "rpm_limit": {"label": "Wheel speed limit", "unit": "rpm", "min": 100, "max": 30000, "apply": lambda c, v, d: c["params"].__setitem__("wmaxRpm", v)},
    "disturbance_N": {"label": "Push magnitude", "unit": "N", "min": 0, "max": 5, "apply": _set_disturbance},
    "noise_scale": {"label": "Sensor noise", "unit": "× nominal", "min": 0, "max": 10, "apply": _noise},
    "inertia_scale": {"label": "True inertia (model mismatch)", "unit": "× model", "min": 0.5, "max": 2, "apply": lambda c, v, d: c["uncertainty"].__setitem__("inertiaScale", v)},
}
MASS_CONFIGS = {
    "base": None, "none": [],
    "top50": [{"id": "S1", "label": "50 g top", "mass_kg": 0.05, "pos_f": [1, 1, 1]}],
    "face100": [{"id": "S1", "label": "100 g face", "mass_kg": 0.1, "pos_f": [0.5, 1, 0.5]}],
    "asym2x60": [{"id": "S1", "label": "60 g A", "mass_kg": 0.06, "pos_f": [0.2, 0.9, 1]}, {"id": "S2", "label": "60 g B", "mass_kg": 0.06, "pos_f": [1, 0.3, 0.8]}],
}
CONTROLLER_KEYS = {"pid": ("pid", "decoupled"), "lqr": ("lqr", "decoupled"), "adp": ("adp", "decoupled"),
                   "nlpd": ("nlpd", "decoupled"), "lqr-mimo": ("lqr", "mimo-lqr"), "none": ("none", "decoupled")}
MEASURES = ["settle_s", "rmsLean_deg", "peakLean_deg", "peakOmega_rpm", "effort_Nms", "torqueLimited_s", "speedLimited_s", "leanMargin_deg", "energy_J"]
CELL = {"recovered": 2, "not_settled": 1, "drifting": 1, "fallen": 0, "invalid": -2}


def js_prec10(x: float) -> float:
    return float(f"{x:.10g}")


def normalize_def(d: dict) -> tuple[dict, list]:
    E = []
    if not isinstance(d, dict):
        return {}, [{"path": "", "message": "The sweep definition must be an object."}]
    base_raw = d.get("base") if isinstance(d.get("base"), dict) else default_config("edge")
    o = {"schema": SCHEMA_ID, "revision": REVISION, "id": d.get("id"), "name": d.get("name") or "", "created": d.get("created"),
         "base": copy.deepcopy(base_raw), "mode": d.get("mode", "grid"), "seed": d.get("seed", 1), "samples": d.get("samples", 60),
         "controllers": list(d.get("controllers") or ["pid", "lqr", "adp"]), "mass_configs": list(d.get("mass_configs") or ["base"]),
         "estimators": list(d["estimators"]) if d.get("estimators") else None,
         "variables": [], "disturbance": d.get("disturbance"), "duration_s": d.get("duration_s", 5), "record_hz": d.get("record_hz", 10),
         "seed_strategy": d.get("seed_strategy") or ("legacy" if d.get("revision") in (None, "1.0") and d.get("seed_strategy") is None else "paired"),
         "store_runs": bool(d.get("store_runs", False)), "limits": d.get("limits") or {},
         # the success criterion every analysis number uses (maps, probabilities, paired tests, limits); definitions older than
         # revision 1.2 keep the legacy outcome 'recovered', revision 1.2 defaults to the research criterion
         "criterion": d.get("criterion") or ("legacy" if d.get("revision") in (None, "1.0", "1.1") else "research")}
    o["sampling_notes"] = []
    legacy = d.get("revision") in (None, "1.0")
    for i, v in enumerate(d.get("variables") or []):
        if not isinstance(v, dict):
            E.append({"path": f"variables.{i}", "message": "must be an object."})
            continue
        if legacy and v.get("dist") == "normal":
            v = dict(v, dist="bounded-normal")
            o["sampling_notes"].append(f"variables.{i}: a revision-1.0 'normal' variable (the browser's truncated normal) is sampled as 'bounded-normal', the exact truncated normal on [min, max].")
        vv = {"key": v.get("key"), "path": v.get("path"), "label": v.get("label"), "unit": v.get("unit"), "min": v.get("min"), "max": v.get("max"),
              "steps": v.get("steps", 5), "dist": v.get("dist", "uniform"), "mean": v.get("mean"), "sd": v.get("sd"),
              "values": v.get("values"), "probabilities": v.get("probabilities")}
        o["variables"].append(vv)
    return o, E


# the configuration path a named variable changes (parameter provenance: which measured inputs a sweep overrides)
VARIABLE_PATHS = {"com_x_mm": "comShift_m", "com_y_mm": "comShift_m", "com_z_mm": "comShift_m", "tilt_deg": "initial.tilt_deg",
                  "rate_dps": "initial.rate_dps", "torque_pct": "torqueScale", "rpm_limit": "params.wmaxRpm", "disturbance_N": "disturbances",
                  "noise_scale": "sensor", "inertia_scale": "uncertainty.inertiaScale"}


def variable_config_path(v: dict) -> str | None:
    """The configuration path a sweep variable writes (named variables through VARIABLE_PATHS; path variables
    without list indices below a vector, e.g. comShift_m.0 → comShift_m)."""
    if v.get("path"):
        parts = v["path"].split(".")
        while parts and parts[-1].isdigit():
            parts.pop()
        return ".".join(parts)
    return VARIABLE_PATHS.get(v.get("key"))


def validate_def(defn: dict, limits: dict | None = None) -> dict:
    d, E = normalize_def(defn)
    W = []
    L = dict(BACKEND_LIMITS)
    for k, v in (limits or {}).items():
        L[k] = v
    for k, v in (d.get("limits") or {}).items():
        if k in L and isinstance(v, (int, float)):
            L[k] = min(L[k], v)   # a sweep may lower the caps, never raise them
    if d.get("mode") not in ("grid", "random", "montecarlo"):
        E.append({"path": "mode", "message": "Sweep mode must be grid, random or montecarlo."})
    if not d.get("controllers"):
        E.append({"path": "controllers", "message": "Choose at least one controller."})
    for c in d.get("controllers", []):
        if c not in CONTROLLER_KEYS:
            E.append({"path": "controllers", "message": f"Unknown controller '{c}' (pid, lqr, adp, nlpd, lqr-mimo, none)."})
    for m in d.get("mass_configs", []):
        if m not in MASS_CONFIGS:
            E.append({"path": "mass_configs", "message": f"Unknown mass configuration '{m}'."})
    if d.get("estimators") is not None:
        for e in d["estimators"]:
            if e not in ("ideal", "cf", "kf", "accel", "gyro", "cf3d", "mekf"):
                E.append({"path": "estimators", "message": f"Unknown estimator '{e}'."})
    if d.get("seed_strategy") not in SEED_STRATEGIES:
        E.append({"path": "seed_strategy", "message": "seed_strategy must be paired, legacy, fixed or independent."})
    if d.get("criterion") not in CRITERIA:
        E.append({"path": "criterion", "message": "criterion must be one of " + ", ".join(CRITERIA) + "."})
    if not d.get("variables"):
        E.append({"path": "variables", "message": "Vary at least one parameter; with nothing varied this is a single experiment."})
    if not (isinstance(d.get("seed"), int) and 0 <= d["seed"] <= 0xFFFFFFFF):
        E.append({"path": "seed", "message": "Seed must be an integer from 0 to 4294967295."})
    if d.get("mode") in ("random", "montecarlo") and not (isinstance(d.get("samples"), int) and 1 <= d["samples"] <= L["maxRuns_per_sweep"]):
        E.append({"path": "samples", "message": f"Number of samples must be an integer between 1 and {L['maxRuns_per_sweep']:,}."})
    if not (isinstance(d.get("duration_s"), (int, float)) and L["minDuration_s"] <= d["duration_s"] <= L["maxDuration_s"]):
        E.append({"path": "duration_s", "message": f"Observation window must be between {L['minDuration_s']} and {L['maxDuration_s']} s for this engine."})
    seen = set()
    for i, v in enumerate(d.get("variables", [])):
        path = f"variables.{i}"
        ident = v["key"] or v["path"]
        if not ident:
            E.append({"path": path, "message": "A variable needs a 'key' (named variable) or a 'path' (configuration path)."})
            continue
        if ident in seen:
            E.append({"path": path, "message": f"{ident} is listed twice."})
        seen.add(ident)
        spec = VARIABLES.get(v["key"]) if v["key"] else None
        if v["key"] and not spec:
            E.append({"path": path, "message": f"Unknown variable '{v['key']}'. Use a named variable or give a configuration 'path'."})
            continue
        base_ini = (d.get("base") or {}).get("initial") or {}
        if v["key"] == "tilt_deg" and base_ini.get("attitude_q") is not None:
            E.append({"path": path, "message": "tilt_deg varies the legacy initial tilt, but the base setup gives an explicit initial.attitude_q; vary a component of initial.attitude_q by path instead (conflicting inputs are not combined)."})
            continue
        if v["key"] == "rate_dps" and base_ini.get("body_rate_dps") is not None:
            E.append({"path": path, "message": "rate_dps varies the legacy initial rate, but the base setup gives an explicit initial.body_rate_dps; vary initial.body_rate_dps.<i> by path instead."})
            continue
        if v["path"] and not _path_ok(d["base"], v["path"]):
            E.append({"path": path, "message": f"'{v['path']}' is not a numeric field of the base configuration."})
            continue
        if v["dist"] not in DISTRIBUTIONS:
            E.append({"path": path, "message": f"Distribution must be one of {', '.join(DISTRIBUTIONS)}."})
            continue
        if v["dist"] == "categorical":
            vals = v.get("values")
            if not (isinstance(vals, list) and vals and all(isinstance(x, (int, float)) and math.isfinite(x) for x in vals)):
                E.append({"path": path, "message": "A categorical variable needs a non-empty list of numeric 'values'."})
            pr = v.get("probabilities")
            if pr is not None and (not isinstance(pr, list) or len(pr) != len(vals or []) or any((not isinstance(p, (int, float))) or p < 0 for p in pr) or abs(sum(pr) - 1) > 1e-9):
                E.append({"path": path, "message": "'probabilities' must be non-negative numbers, one per value, summing to 1."})
            continue
        lo, hi = v.get("min"), v.get("max")
        if not (isinstance(lo, (int, float)) and isinstance(hi, (int, float)) and math.isfinite(lo) and math.isfinite(hi)):
            E.append({"path": path, "message": f"{ident}: the range needs two numbers."})
            continue
        if not hi > lo:
            E.append({"path": path, "message": f"{ident}: the upper end must be above the lower end."})
        if spec and (lo < spec["min"] or hi > spec["max"]):
            E.append({"path": path, "message": f"{spec['label']}: the range must lie within {spec['min']} to {spec['max']} {spec['unit']}."})
        if d["mode"] == "grid" and not (isinstance(v["steps"], int) and 2 <= v["steps"] <= 200):
            E.append({"path": path, "message": f"{ident}: a grid needs 2 to 200 values per variable."})
        if v["dist"] in ("normal", "bounded-normal"):
            if d["mode"] == "grid":
                E.append({"path": path, "message": f"{ident}: a grid uses evenly spaced values; distributions apply to random and Monte Carlo sweeps."})
            elif not (isinstance(v["mean"], (int, float)) and isinstance(v["sd"], (int, float)) and v["sd"] > 0):
                E.append({"path": path, "message": f"{ident}: a normal distribution needs a mean and a positive standard deviation."})
            elif v["dist"] == "bounded-normal":
                mass = float(ndtr((hi - v["mean"]) / v["sd"]) - ndtr((lo - v["mean"]) / v["sd"]))
                if mass < 1e-9:
                    E.append({"path": path, "message": f"{ident}: [min, max] holds only {mass:.2e} of the normal distribution's probability; a truncated normal on this interval is numerically meaningless."})
                elif mass < 0.5:
                    W.append({"path": path, "message": f"{ident}: [min, max] holds {mass * 100:.1f} % of the normal distribution; the truncated distribution differs strongly from N(mean, sd)."})
            elif v["dist"] == "normal":
                out = 1 - float(ndtr((hi - v["mean"]) / v["sd"]) - ndtr((lo - v["mean"]) / v["sd"]))
                if out > 0.001:
                    W.append({"path": path, "message": f"{ident}: about {out * 100:.2f} % of normal samples fall outside [{lo}, {hi}]; those runs will be recorded as invalid, not clipped."})
    base_v = None
    if not E:
        from ..config.validate import validate_config
        b = copy.deepcopy(d["base"])
        b["duration_s"] = d["duration_s"]
        b["record_hz"] = d["record_hz"]
        base_v = validate_config(b)
        for e in base_v.errors:
            E.append({"path": "base." + e["path"], "message": "Base setup: " + e["message"]})
    total = points = 0
    steps = 0
    if not E:
        points = point_count(d)
        total = points * len(d["mass_configs"]) * len(d["controllers"]) * len(d["estimators"] or [None])
        f_int = base_v.config["solver"]["integration_hz"] or base_v.config["params"]["fs"]
        steps = int(round(d["duration_s"] * f_int)) * total
        if total > L["maxRuns_per_sweep"]:
            E.append({"path": "samples", "message": f"{total:,} runs is more than this backend accepts ({L['maxRuns_per_sweep']:,}). Reduce the grid or the sample count."})
        if steps > L["maxSteps_per_job"]:
            E.append({"path": "duration_s", "message": f"The sweep needs {steps:,} integration steps, above this backend's limit of {L['maxSteps_per_job']:,} per job."})
    return {"ok": not E, "errors": E, "warnings": W, "def": d, "total": total, "points": points,
            "workload": {"runs": total, "points": points, "integration_steps": steps, "limits": L}}


def _path_ok(base: dict, path: str) -> bool:
    cfg, iss = normalize(base)
    try:
        v = _get(cfg, path, materialize=True)
    except (KeyError, IndexError, TypeError, ValueError):
        return False
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _get(cfg, path, materialize=False):
    parts = path.split(".")
    if parts[0] == "wheels" and cfg.get("wheels") is None and materialize:
        cfg["wheels"] = default_wheels(cfg["params"], cfg["actuator"]["wheel_health"])
    if parts[0] == "uncertainty" and len(parts) > 1 and parts[1] == "inertia_perturbation_kgm2" and cfg["uncertainty"].get("inertia_perturbation_kgm2") is None and materialize:
        cfg["uncertainty"]["inertia_perturbation_kgm2"] = [[0.0] * 3 for _ in range(3)]
    for key in ("controller.lqr", "controller.nonlinear", "controller.adaptive", "controller.pid", "estimator.mekf", "estimator.cf3d"):
        if path.startswith(key + ".") and materialize:
            a, b = key.split(".")
            if cfg[a].get(b) is None:
                from ..constants import ADAPTIVE_DEFAULTS, CF3D_DEFAULTS, LQR_DEFAULTS, MEKF_DEFAULTS, NONLINEAR_DEFAULTS, PID_DEFAULTS
                cfg[a][b] = dict({"lqr": LQR_DEFAULTS, "nonlinear": NONLINEAR_DEFAULTS, "adaptive": ADAPTIVE_DEFAULTS, "pid": PID_DEFAULTS,
                                  "mekf": MEKF_DEFAULTS, "cf3d": CF3D_DEFAULTS}[b])
    o = cfg
    for p in parts:
        o = o[int(p)] if isinstance(o, list) else o[p]
    return o


def _set(cfg, path, value):
    _get(cfg, path, materialize=True)
    parts = path.split(".")
    o = cfg
    for p in parts[:-1]:
        o = o[int(p)] if isinstance(o, list) else o[p]
    last = parts[-1]
    if isinstance(o, list):
        o[int(last)] = value
    else:
        o[last] = value
    if len(parts) == 4 and parts[1] == "inertia_perturbation_kgm2":   # keep the perturbation symmetric
        i, j = int(parts[2]), int(parts[3])
        cfg["uncertainty"]["inertia_perturbation_kgm2"][j][i] = value


def point_count(d):
    if d["mode"] == "grid":
        n = 1
        for v in d["variables"]:
            n *= len(v["values"]) if v["dist"] == "categorical" else max(1, v["steps"])
        return n
    return d["samples"]


def linspace(a, b, n):
    return [a] if n == 1 else [a + (b - a) * i / (n - 1) for i in range(n)]


def sample_points(d) -> tuple[list, list]:
    """Points (one value per variable) and, per point, notes about the draw (e.g. out of range)."""
    P, notes = [], []
    if d["mode"] == "grid":
        axes = [(list(v["values"]) if v["dist"] == "categorical" else [js_prec10(x) for x in linspace(v["min"], v["max"], v["steps"])]) for v in d["variables"]]

        def rec(i, cur):
            if i == len(axes):
                P.append(list(cur))
                notes.append(None)
                return
            for x in axes[i]:
                cur.append(x)
                rec(i + 1, cur)
                cur.pop()
        rec(0, [])
        return P, notes
    R = Rng(d["seed"] & 0xFFFFFFFF)   # the browser's point stream: uniform draws are identical
    for _ in range(d["samples"]):
        pt, nt = [], None
        for v in d["variables"]:
            dist = v["dist"]
            if d["mode"] == "random" and dist != "categorical":
                dist = "uniform"
            if dist == "uniform":
                x = js_prec10(v["min"] + (v["max"] - v["min"]) * R.u())
            elif dist == "bounded-normal":
                a = float(ndtr((v["min"] - v["mean"]) / v["sd"]))
                b = float(ndtr((v["max"] - v["mean"]) / v["sd"]))
                x = js_prec10(min(v["max"], max(v["min"], v["mean"] + v["sd"] * float(ndtri(a + R.u() * (b - a))))))
            elif dist == "normal":
                u = R.u()
                while u == 0.0:
                    u = R.u()
                x = js_prec10(v["mean"] + v["sd"] * float(ndtri(u)))
                if x < v["min"] or x > v["max"]:
                    nt = (nt or []) + [f"{v.get('key') or v.get('path')} = {x:g} is outside [{v['min']}, {v['max']}] (normal draw, not clipped)"]
            else:   # categorical
                vals = v["values"]
                pr = v.get("probabilities") or [1 / len(vals)] * len(vals)
                u, acc, x = R.u(), 0.0, vals[-1]
                for val, p in zip(vals, pr):
                    acc += p
                    if u < acc:
                        x = val
                        break
            pt.append(x)
        P.append(pt)
        notes.append(nt)
    return P, notes


def expand(d: dict) -> list:
    P, notes = sample_points(d)
    runs = []
    idx = 0
    ests = d["estimators"] or [None]
    for pi, pt in enumerate(P):
        for mk in d["mass_configs"]:
            for ck in d["controllers"]:
                for ek in ests:
                    c = copy.deepcopy(d["base"])
                    c["duration_s"] = d["duration_s"]
                    c["record_hz"] = d["record_hz"]
                    typ, st = CONTROLLER_KEYS[ck]
                    c.setdefault("controller", {})
                    c["controller"]["type"] = typ
                    c["controller"]["structure"] = st
                    if ek is not None:
                        c.setdefault("estimator", {})["type"] = ek
                    cfg, _ = normalize(c)
                    _apply_mass(cfg, mk)
                    values = {}
                    for v, x in zip(d["variables"], pt):
                        ident = v["key"] or v["path"]
                        values[ident] = x
                        if v["key"]:
                            VARIABLES[v["key"]]["apply"](cfg, x, d)
                        else:
                            _set(cfg, v["path"], x)
                    cfg["seed"] = seed_for(d, pi, idx, cfg["seed"])
                    runs.append({"index": idx, "point": pi, "controller": ck, "mass_config": mk, "estimator": ek, "values": values,
                                 "seed": cfg["seed"], "config": cfg, "note": notes[pi], "out_of_range": bool(notes[pi])})
                    idx += 1
    return runs


def seed_for(d, point, index, base_seed):
    s = d["seed_strategy"]
    if s == "paired":
        return derive_seed(d["seed"], point, "noise")
    if s == "legacy":
        return (d["seed"] + point) & 0xFFFFFFFF if d["mode"] == "montecarlo" else base_seed
    if s == "independent":
        return derive_seed(d["seed"], index, "noise")
    return base_seed


def _apply_mass(c, key):
    M = MASS_CONFIGS[key]
    if M is None:
        return
    a = c["params"]["a"]
    c["attachments"] = [{"id": m["id"], "label": m["label"], "mass_kg": m["mass_kg"], "pos_m": [js_prec10(f * a) for f in m["pos_f"]]} for m in M]


def row_of(spec: dict, res: dict | None, *, run_id=None, error=None) -> dict:
    """One saved row: sampled values, seed, configuration hash, outcome, metrics or the reason."""
    row = {"index": spec["index"], "point": spec["point"], "controller": spec["controller"], "mass_config": spec["mass_config"],
           "estimator": spec.get("estimator"), "values": spec["values"], "seed": spec["seed"], "config_hash": canonical_hash(spec["config"]),
           "status": "ok", "outcome": "invalid", "saturated": False, "metrics": None, "research": None, "termination": None, "reason": None, "run_id": run_id}
    if spec.get("note"):
        row["sample_note"] = spec["note"]
    if spec.get("out_of_range"):
        row["status"] = "invalid"
        row["reason"] = "sampled value outside the variable's stated range (normal distribution, not clipped): " + "; ".join(spec["note"])
        return row
    if error is not None:
        row["status"] = "failed"
        row["reason"] = error
        return row
    code = res["outcome"]["code"] if res and res.get("outcome") else "invalid"
    row["outcome"] = code
    if not res.get("ok"):
        row["status"] = "invalid"
        row["reason"] = res["outcome"]["reason"] if res.get("outcome") else "invalid"
        row["termination"] = res.get("termination")
        return row
    m = res["metrics"]
    row["metrics"] = {k: (float(f"{m[k]:.6g}") if isinstance(m.get(k), (int, float)) and math.isfinite(m[k]) else None) for k in MEASURES}
    row["saturated"] = (m.get("torqueLimited_s") or 0) > 0 or (m.get("speedLimited_s") or 0) > 0
    rr = res["research"]["recovery"]
    est = res["research"].get("estimator") or {}
    row["research"] = {"metrics_version": res["research"].get("metrics_version"), "recovered": rr["recovered"], "t_s": rr["t_s"],
                       "sustained": rr.get("sustained"), "exits_after_recovery": rr.get("exits_after_recovery"), "fell_after_recovery": rr.get("fell_after_recovery"),
                       "objective": rr["objective_effective"],
                       "attitude_rms_deg": res["research"]["attitude_error"]["rms"], "attitude_iae_deg_s": res["research"]["attitude_error"]["iae"],
                       "attitude_ise_deg2_s": res["research"]["attitude_error"]["ise"], "attitude_final_deg": res["research"]["attitude_error"]["final"],
                       "estimator_tilt_rmse_deg": est.get("tilt_rmse_deg"), "estimator_attitude_rmse_deg": est.get("attitude_rmse_deg")}
    row["termination"] = res["termination"]
    return row


# ---------------------------------------------------------------------------------------
# analysis (from the saved rows only)
# ---------------------------------------------------------------------------------------
def wilson(k, n, z=1.959963984540054):
    if not n:
        return [0.0, 1.0]
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return [max(0.0, c - h), min(1.0, c + h)]


def success_of(criterion: str):
    """The success test every analysis number uses (the sweep's declared criterion)."""
    if criterion == "legacy":
        return lambda r: r["outcome"] == "recovered"
    if criterion == "research_sustained":
        return lambda r: bool(r.get("research") and r["research"].get("recovered") and r["research"].get("sustained"))
    return lambda r: bool(r.get("research") and r["research"].get("recovered"))


def analyze(d: dict, rows: list) -> dict:
    crit = d.get("criterion") or "legacy"
    succ = success_of(crit)
    out = {"schema": "aeris-sweep-analysis/1", "revision": "1.2", "computed_from": f"{len(rows)} saved rows", "criterion": crit,
           "criterion_text": CRITERIA.get(crit, crit), "controllers": {}, "maps": [], "distributions": {},
           "probability": [], "boundaries": {}, "labels": [], "paired": [],
           "notes": ["Recovery rates are the fraction of SIMULATED runs that met the criterion under this sweep's sampling; they are not hardware reliability estimates.",
                     "Maps show sampled points only (no interpolation); boundaries are observed limits at the sampled points.",
                     f"Success criterion for every number below: {CRITERIA.get(crit, crit)}.",
                     "Invalid and failed rows are kept: they are counted in 'n', shown as invalid cells, and excluded from rates and tests (their count is reported)."]}
    groups = [(c, e) for c in d["controllers"] for e in (d["estimators"] or [None])]

    def gkey(c, e):
        return c if e is None else f"{c}/{e}"
    for c, e in groups:
        R = [r for r in rows if r["controller"] == c and r.get("estimator") == e]
        valid = [r for r in R if r["outcome"] != "invalid"]
        ks = sum(1 for r in valid if succ(r))
        k = sum(1 for r in valid if r["outcome"] == "recovered")
        kr = sum(1 for r in valid if r.get("research") and r["research"]["recovered"])
        ksu = sum(1 for r in valid if r.get("research") and r["research"].get("sustained"))
        kex = sum(1 for r in valid if r.get("research") and (r["research"].get("exits_after_recovery") or 0) > 0)
        kfa = sum(1 for r in valid if r.get("research") and r["research"].get("fell_after_recovery"))
        cnt = {}
        for r in R:
            cnt[r["outcome"]] = cnt.get(r["outcome"], 0) + 1
        out["controllers"][gkey(c, e)] = {"n": len(R), "valid": len(valid), "invalid": len(R) - len(valid), "failed": sum(1 for r in R if r["status"] == "failed"),
                                          "success": ks, "success_rate": (ks / len(valid)) if valid else None, "success_ci95": wilson(ks, len(valid)),
                                          "recovered": k, "rate": (k / len(valid)) if valid else None, "ci95": wilson(k, len(valid)),
                                          "research_recovered": kr, "research_rate": (kr / len(valid)) if valid else None, "research_ci95": wilson(kr, len(valid)),
                                          "research_sustained": ksu, "research_exits": kex, "research_fell_after": kfa,
                                          "counts": cnt, "saturatedRecoveries": sum(1 for r in valid if r["outcome"] == "recovered" and r["saturated"])}
    # paired comparisons (same point, mass configuration, and seed; different controller)
    if len(groups) > 1:
        by = {}
        for r in rows:
            by.setdefault((r["point"], r["mass_config"]), {})[gkey(r["controller"], r.get("estimator"))] = r
        keys = [gkey(c, e) for c, e in groups]
        for i in range(len(keys)):
            for j in range(i + 1, len(keys)):
                a, b = keys[i], keys[j]
                both = only_a = only_b = neither = n = 0
                for cell in by.values():
                    if a in cell and b in cell and cell[a]["outcome"] != "invalid" and cell[b]["outcome"] != "invalid":
                        n += 1
                        ra, rb = succ(cell[a]), succ(cell[b])
                        both += ra and rb
                        only_a += ra and not rb
                        only_b += rb and not ra
                        neither += (not ra) and (not rb)
                disc = only_a + only_b
                p_exact = _mcnemar_exact(only_a, only_b) if disc else None
                out["paired"].append({"a": a, "b": b, "pairs": n, "both": both, "only_a": only_a, "only_b": only_b, "neither": neither,
                                      "mcnemar_exact_p": p_exact, "paired_seeds": d["seed_strategy"] in ("paired", "legacy", "fixed"),
                                      "criterion": crit, "note": f"Exact two-sided McNemar test on the discordant pairs ({CRITERIA.get(crit, crit)})."})
    keys_v = [v["key"] or v["path"] for v in d["variables"]]

    def uniq(a):
        return sorted(set(a))

    def pair_map(xk, yk, title):
        xs = uniq(r["values"][xk] for r in rows)
        ys = uniq(r["values"][yk] for r in rows)
        per = {}
        for c, e in groups:
            cells = []
            for j, y in enumerate(ys):
                for i, x in enumerate(xs):
                    R = [r for r in rows if r["controller"] == c and r.get("estimator") == e and r["values"][xk] == x and r["values"][yk] == y]
                    if not R:
                        cells.append({"i": i, "j": j, "x": x, "y": y, "n": 0, "code": None})
                        continue
                    rec = [r for r in R if r["outcome"] != "invalid" and succ(r)]
                    inv = [r for r in R if r["outcome"] == "invalid"]
                    code = ("invalid" if len(inv) == len(R) else ("recovered_saturated" if any(r["saturated"] for r in rec) else "recovered") if len(rec) == len(R)
                            else "mixed" if rec else "fallen" if any(r["outcome"] == "fallen" for r in R) else "not_recovered")
                    cells.append({"i": i, "j": j, "x": x, "y": y, "n": len(R), "recovered": len(rec), "invalid": len(inv), "code": code})
            per[gkey(c, e)] = cells
        return {"x": xk, "y": yk, "xs": xs, "ys": ys, "title": title, "cells": per, "criterion": crit,
                "aggregated_over": "other varied parameters and mass configurations (a cell is 'recovered' only if every run in it recovered)" if (len(keys_v) > 2 or len(d["mass_configs"]) > 1) else None}
    if d["mode"] == "grid" and len(keys_v) >= 2:
        named = [("tilt_deg", "rate_dps", "Domain of attraction (slice)"), ("com_x_mm", "com_y_mm", "COM stability map"), ("torque_pct", "tilt_deg", "Saturation map"),
                 ("com_y_mm", "com_z_mm", "COM stability map (y–z)")]
        for xk, yk, t in named:
            if xk in keys_v and yk in keys_v:
                out["maps"].append(pair_map(xk, yk, t))
        if not out["maps"]:
            out["maps"].append(pair_map(keys_v[0], keys_v[1], "Outcome map"))
    for k, over in (("settle_s", "recovered"), ("rmsLean_deg", "valid"), ("peakOmega_rpm", "valid"), ("effort_Nms", "valid")):
        pool = [r for r in rows if r["metrics"] and r["metrics"].get(k) is not None and ((r["outcome"] == "recovered") if over == "recovered" else r["outcome"] != "invalid")]
        if len(pool) < 2:
            continue
        vals = [r["metrics"][k] for r in pool]
        lo, hi = min(vals), max(vals)
        if hi - lo < 1e-12:
            hi = lo + 1
        bins = max(4, min(16, round(math.sqrt(len(pool)))))
        per = {}
        for c, e in groups:
            vv = sorted(r["metrics"][k] for r in pool if r["controller"] == c and r.get("estimator") == e)
            w = (hi - lo) / bins
            counts = [0] * bins
            for x in vv:
                i = min(bins - 1, max(0, int((x - lo) // w)))
                counts[i] += 1
            per[gkey(c, e)] = {"n": len(vv), "hist": {"lo": lo, "hi": hi, "width": w, "counts": counts}, "median": (vv[len(vv) // 2] if len(vv) % 2 else (vv[len(vv) // 2 - 1] + vv[len(vv) // 2]) / 2) if vv else None}
        out["distributions"][k] = {"over": over, "per": per, "lo": lo, "hi": hi, "bins": bins}
    for v in d["variables"]:
        ident = v["key"] or v["path"]
        vals = uniq(r["values"][ident] for r in rows)
        edges = None if len(vals) <= 10 else linspace(min(vals), max(vals), 9)
        grp = [{"lo": e0, "hi": edges[i + 1], "x": (e0 + edges[i + 1]) / 2} for i, e0 in enumerate(edges[:-1])] if edges else [{"lo": x, "hi": x, "x": x} for x in vals]
        per = {}
        for c, e in groups:
            lst = []
            for gi, g in enumerate(grp):
                Rall = [r for r in rows if r["controller"] == c and r.get("estimator") == e and
                        ((g["lo"] <= r["values"][ident] < g["hi"] or (gi == len(grp) - 1 and r["values"][ident] <= g["hi"])) if edges else r["values"][ident] == g["x"])]
                R = [r for r in Rall if r["outcome"] != "invalid"]
                k = sum(1 for r in R if succ(r))
                lst.append({"x": g["x"], "lo": g["lo"], "hi": g["hi"], "n": len(R), "invalid": len(Rall) - len(R), "recovered": k,
                            "p": (k / len(R)) if R else None, "ci95": wilson(k, len(R))})
            per[gkey(c, e)] = lst
        out["probability"].append({"variable": ident, "per": per, "binned": bool(edges)})
        out["boundaries"][ident] = {}
        for c, e in groups:
            R = [r for r in rows if r["controller"] == c and r.get("estimator") == e and r["outcome"] != "invalid"]
            ok = [abs(r["values"][ident]) for r in R if succ(r)]
            bad = [abs(r["values"][ident]) for r in R if not succ(r)]
            out["boundaries"][ident][gkey(c, e)] = {"maxRecovered": max(ok) if ok else None, "minNotRecovered": min(bad) if bad else None, "nRecovered": len(ok), "nNot": len(bad)}
    rated = [g for g, s in out["controllers"].items() if s["valid"] > 0]
    if len(rated) > 1:
        best = max(out["controllers"][g]["success_rate"] for g in rated)
        top = [g for g in rated if out["controllers"][g]["success_rate"] == best]
        out["labels"].append({"key": "highest_recovery_rate", "controllers": top, "value": best, "criterion": crit,
                              "text": "Highest success rate in this sweep (" + crit + " criterion)", "tie": len(top) > 1})
    return out


def _mcnemar_exact(b, c):
    from scipy.stats import binomtest
    return float(binomtest(min(b, c), b + c, 0.5).pvalue)


def to_csv(sw: dict) -> str:
    d = sw["definition"]
    vars_ = [v["key"] or v["path"] for v in d["variables"]]
    p = sw.get("provenance") or {}
    lines = [f"# AERIS sweep export · {sw['id']} · {sw.get('name', '')}", f"# source: {p.get('note', 'simulation')}",
             f"# engine: {sw['engine']['engine']} {sw['engine'].get('engine_version', '')}",
             f"# {'PARTIAL (cancelled)' if sw.get('partial') else 'complete'} · {len(sw['rows'])} runs · seed strategy {d.get('seed_strategy')}",
             f"# success criterion of the analysis: {d.get('criterion', 'legacy')} · research metrics definition version per row in 'metrics_version'",
             ",".join(["index", "point", "controller", "mass_config", "estimator", "seed", "config_hash"] + vars_ + ["status", "outcome", "saturated", "research_recovered",
                      "research_t_s [s]", "research_sustained", "research_exits", "research_fell_after", "attitude_rms [deg]", "attitude_iae [deg·s]", "attitude_ise [deg²·s]",
                      "metrics_version", "termination"] + [m for m in MEASURES])]
    def rv(r, k, b=False):
        R = r.get("research") or {}
        v = R.get(k)
        if v is None:
            return ""
        return (1 if v else 0) if b else v
    for r in sw["rows"]:
        lines.append(",".join(str(x) for x in ([r["index"], r["point"], r["controller"], r["mass_config"], r.get("estimator") or "", r["seed"], r["config_hash"]]
                                               + [r["values"][k] for k in vars_] + [r["status"], r["outcome"], 1 if r["saturated"] else 0,
                                                                                    rv(r, "recovered", True), rv(r, "t_s"), rv(r, "sustained", True),
                                                                                    rv(r, "exits_after_recovery"), rv(r, "fell_after_recovery", True),
                                                                                    rv(r, "attitude_rms_deg"), rv(r, "attitude_iae_deg_s"), rv(r, "attitude_ise_deg2_s"),
                                                                                    rv(r, "metrics_version") or ("1" if r.get("research") else ""),
                                                                                    (r.get("termination") or {}).get("reason", "")]
                                               + ["" if not r["metrics"] or r["metrics"].get(m) is None else r["metrics"][m] for m in MEASURES])))
    return "\n".join(lines) + "\n"


__all__ = ["validate_def", "expand", "row_of", "analyze", "to_csv", "DISTRIBUTIONS", "SEED_STRATEGIES", "DEG"]

"""Per-metric labels for a set of runs (the same definitions as site/js/platform/compare.js:
one label per metric, ties reported, no overall winner) plus the research metrics."""
from __future__ import annotations

import json

LABELS = [
    {"key": "settle", "label": "Lowest settling time", "metric": "settle_s", "better": "min", "unit": "s", "digits": 3,
     "eligible": lambda r: r["outcome"]["code"] == "recovered" and r["metrics"].get("settle_s") is not None,
     "why": "Time after which the COM lean stays within the settling band to the end of the window (recovered runs only)."},
    {"key": "effort", "label": "Lowest control effort", "metric": "effort_Nms", "better": "min", "unit": "N·m·s", "digits": 4,
     "eligible": lambda r: r["metrics"].get("fellAt_s") is None and r["metrics"].get("effort_Nms") is not None,
     "why": "∫ Σ|T| dt over the window: total motor torque used (runs that did not fall)."},
    {"key": "margin", "label": "Largest recovery margin", "metric": "leanMargin_deg", "better": "max", "unit": "°", "digits": 2,
     "eligible": lambda r: r["metrics"].get("leanMargin_deg") is not None,
     "why": "Fall threshold minus the peak COM lean: how far the run stayed from falling."},
    {"key": "wheel", "label": "Lowest peak wheel speed", "metric": "peakOmega_frac", "better": "min", "unit": "% of limit", "digits": 0, "scale": 100,
     "eligible": lambda r: r["metrics"].get("fellAt_s") is None and r["metrics"].get("peakOmega_frac") is not None,
     "why": "Highest wheel speed reached, as a share of the speed limit (runs that did not fall)."},
]


def _flatten(o, pre="", out=None):
    out = {} if out is None else out
    for k, v in (o or {}).items():
        p = f"{pre}.{k}" if pre else k
        if isinstance(v, dict):
            _flatten(v, p, out)
        else:
            out[p] = json.dumps(v, sort_keys=True)
    return out


def compare_runs(records: list) -> dict:
    labels = []
    for L in LABELS:
        el = [i for i, r in enumerate(records) if L["eligible"](r)]
        ex = [i for i in range(len(records)) if i not in el]
        o = {"key": L["key"], "label": L["label"], "metric": L["metric"], "unit": L["unit"], "why": L["why"], "winners": [], "value": None, "tie": False,
             "eligible": len(el), "excluded": ex}
        if len(el) < 2:
            o["reason"] = "only one run has this metric defined" if len(el) == 1 else "no run has this metric defined"
        else:
            sc = L.get("scale", 1)
            vals = [round(records[i]["metrics"][L["metric"]] * sc, L["digits"]) for i in el]
            best = min(vals) if L["better"] == "min" else max(vals)
            o["winners"] = [i for i, v in zip(el, vals) if v == best]
            o["value"] = best
            o["tie"] = len(o["winners"]) > 1
        labels.append(o)
    flats = [_flatten(r["config"]) for r in records]
    keys = sorted({k for f in flats for k in f})
    differing = [k for k in keys if any(f.get(k) != flats[0].get(k) for f in flats)]
    ctrls = [r["config"]["controller"]["type"] for r in records]
    is_set = len(records) >= 2 and differing == ["controller.type"] and len(set(ctrls)) == len(ctrls)
    research = []
    versions = set()
    for r in records:
        rr = (r.get("research") or {})
        mv = (rr.get("metrics_version") or (r.get("reproduction") or {}).get("metrics_version") or "1") if rr else None
        if mv:
            versions.add(mv)
        ae = rr.get("attitude_error") or {}
        research.append({"id": r["id"], "experiment_id": r.get("experiment_id"), "engine": r["origin"]["engine"], "metrics_version": mv,
                         "recovered_research": (rr.get("recovery") or {}).get("recovered"), "recovery_t_s": (rr.get("recovery") or {}).get("t_s"),
                         "sustained": (rr.get("recovery") or {}).get("sustained"),
                         "attitude_rms_deg": ae.get("rms"), "attitude_iae_deg_s": ae.get("iae"), "attitude_ise_deg2_s": ae.get("ise") if mv != "1" else None,
                         "termination": (r.get("termination") or {}).get("reason")})
    research_note = None
    if len(versions) > 1:
        research_note = (f"These runs carry research metrics of different definition versions ({', '.join(sorted(versions))}); they are not comparable. "
                         "Version-1 ISE values are withheld here (they were rad²·s labelled deg²·s); reanalyse the older runs (POST /runs/{id}/reanalyze).")
    return {"runs": [{"id": r["id"], "experiment_id": r.get("experiment_id"), "outcome": r["outcome"]["code"],
                      "metrics": {L["metric"]: r["metrics"].get(L["metric"]) for L in LABELS}} for r in records],
            "labels": labels, "differing_paths": differing, "controller_set": is_set, "research": research, "research_note": research_note,
            "research_units": {"attitude_rms_deg": "deg", "attitude_iae_deg_s": "deg·s", "attitude_ise_deg2_s": "deg²·s", "recovery_t_s": "s"},
            "note": "Labels name the best run on ONE metric for these runs under their setups; there is no overall winner."}

"""Parameter provenance (docs/PARAMETERS.md): which model inputs of a run come from measurements.

A parameter set (aeris-parameter-set/1, revision 2) maps configuration paths to measured values, each
with its unit, method, date, evidence reference and optional uncertainty. Supported paths cover every
measurable input of the model:

  mass and geometry   params.m, params.a, params.kJ, comOffset_m, comShift_m, plant.base_com_m,
                      plant.base_inertia_kgm2 (full tensor), plant.components.<i>.mass_kg|com_m|inertia_kgm2,
                      attachments.<i>.mass_kg|pos_m
  wheels and motors   params.Jw|KV|R|Vs|Imax|wmaxRpm|cv|cc (shared) or wheels.<i>.<same fields>|axis (per wheel)
  sensing             params.rImu, sensor.imu_position_m, sensor.gyro_noise_dps, gyro_bias_dps,
                      gyro_bias_walk_dps, accel_noise_mps2, gyro_quant_dps, accel_quant_deg, dropout
  timing              params.fs, sensor.rate_hz, sensor.latency_ms, actuator.motor_lag_ms

g is a physical constant (params.g), not a measured property of the cube. Wheel health, events,
disturbances and initial conditions describe the experiment, not the build.

Coverage is computed for every run on the configuration it actually simulated: an input is
MEASURED when the set has its path and the run used exactly that value, OVERRIDDEN when the set has
the path but the run used another value (e.g. a sweep varied it), and NOMINAL when the set does not
cover it. A run is labelled MEASURED only when every input it uses is measured; otherwise it is
NOMINAL and the record lists the nominal and overridden inputs. Nothing here can mark a model
VALIDATED: that needs admissible hardware evidence reviewed by a person (docs/HARDWARE_HANDOFF.md).
"""
from __future__ import annotations

import copy
import math
import re

import numpy as np

from ..constants import PARAM_SPEC, SENSOR_SPEC

PS_REVISION = 2
WHEEL_FIELDS = {"Jw": "kg·m²", "KV": "rpm/V", "R": "Ω", "Vs": "V", "Imax": "A", "wmaxRpm": "rpm", "cv": "N·m·s/rad", "cc": "N·m", "axis": "–"}
SENSOR_UNITS = {k: v["unit"] for k, v in SENSOR_SPEC.items()}
SENSOR_UNITS.update({"rate_hz": "Hz", "imu_position_m": "m"})
FIXED = {"comOffset_m": ("m", "scalar"), "comShift_m": ("m", "vec3"), "plant.base_com_m": ("m", "vec3"),
         "plant.base_inertia_kgm2": ("kg·m²", "mat3"), "actuator.motor_lag_ms": ("ms", "scalar")}
PATTERNS = [
    (re.compile(r"^params\.(\w+)$"), lambda m: (PARAM_SPEC[m.group(1)]["unit"], "scalar") if m.group(1) in PARAM_SPEC and m.group(1) != "g" else None),
    (re.compile(r"^sensor\.(\w+)$"), lambda m: (SENSOR_UNITS[m.group(1)], "vec3" if m.group(1) == "imu_position_m" else "scalar") if m.group(1) in SENSOR_UNITS else None),
    (re.compile(r"^wheels\.(\w+)\.(\w+)$"), lambda m: (WHEEL_FIELDS[m.group(2)], "vec3" if m.group(2) == "axis" else "scalar") if m.group(2) in WHEEL_FIELDS else None),
    (re.compile(r"^plant\.components\.(\w+)\.(mass_kg|com_m|inertia_kgm2)$"), lambda m: {"mass_kg": ("kg", "scalar"), "com_m": ("m", "vec3"), "inertia_kgm2": ("kg·m²", "mat3")}[m.group(2)]),
    (re.compile(r"^attachments\.(\w+)\.(mass_kg|pos_m)$"), lambda m: {"mass_kg": ("kg", "scalar"), "pos_m": ("m", "vec3")}[m.group(2)]),
]


def canonical_path(key: str) -> str:
    """Legacy bare parameter names (v4 sets: 'Jw') are params paths."""
    return f"params.{key}" if key in PARAM_SPEC else key


def spec_of(path: str):
    if path in FIXED:
        return FIXED[path]
    for rx, fn in PATTERNS:
        m = rx.match(path)
        if m:
            return fn(m)
    return None


def check_value(path: str, value, unit: str) -> list[str]:
    spec = spec_of(path)
    if spec is None:
        return [f"'{path}' is not a measurable model input (docs/PARAMETERS.md lists the supported paths; params.g is a constant)."]
    want_unit, shape = spec
    errs = []
    if unit != want_unit:
        errs.append(f"unit '{unit}' — expected '{want_unit}'")
    if shape == "scalar":
        if not (isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)):
            errs.append("must be a finite number")
        elif path.startswith("params.") and path[7:] in PARAM_SPEC:
            sp = PARAM_SPEC[path[7:]]
            if not (sp["min"] <= value <= sp["max"]):
                errs.append(f"outside {sp['min']}–{sp['max']} {sp['unit']}")
    elif shape == "vec3":
        if not (isinstance(value, list) and len(value) == 3 and all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in value)):
            errs.append("must be a list of 3 finite numbers")
    elif shape == "mat3":
        if not (isinstance(value, list) and len(value) == 3 and all(isinstance(r, list) and len(r) == 3 and all(isinstance(x, (int, float)) and math.isfinite(x) for x in r) for r in value)):
            errs.append("must be a 3×3 list of finite numbers")
        else:
            from ..physics.mass import check_tensor
            errs += check_tensor(np.array(value, dtype=float), path)
    return errs


def _get(cfg, path):
    cur = cfg
    for k in path.split("."):
        if isinstance(cur, list):
            if cur and isinstance(cur[0], dict) and "id" in cur[0] and not k.isdigit():
                cur = next((x for x in cur if x.get("id") == k), None)
            else:
                try:
                    cur = cur[int(k)]
                except (ValueError, IndexError):
                    return None
        elif isinstance(cur, dict):
            cur = cur.get(k)
        else:
            return None
        if cur is None:
            return None
    return cur


def _set(cfg, path, value):
    ks = path.split(".")
    cur = cfg
    for i, k in enumerate(ks[:-1]):
        nxt = ks[i + 1]
        if isinstance(cur, list):
            if k.isdigit():
                cur = cur[int(k)]
            else:
                cur = next(x for x in cur if x.get("id") == k)
            continue
        if cur.get(k) is None:
            cur[k] = [] if nxt.isdigit() else {}
        cur = cur[k]
    last = ks[-1]
    if isinstance(cur, list):
        cur[int(last)] = value
    else:
        cur[last] = value


def model_inputs(cfg: dict) -> dict:
    """path → value of every measurable input this (normalised) configuration's run uses."""
    from ..config.normalize import effective_wheels
    out = {}
    p = cfg["params"]
    plant = cfg.get("plant") or {}
    custom_wheels = cfg.get("wheels") is not None
    for k in PARAM_SPEC:
        if k == "g":
            continue
        if k == "kJ" and plant.get("base_inertia_kgm2") is not None:
            continue
        if custom_wheels and k in WHEEL_FIELDS:
            continue
        out[f"params.{k}"] = p[k]
    out["comOffset_m"] = cfg.get("comOffset_m") or 0.0
    out["comShift_m"] = list(cfg.get("comShift_m") or [0, 0, 0])
    if plant.get("base_com_m") is not None:
        out["plant.base_com_m"] = list(plant["base_com_m"])
    if plant.get("base_inertia_kgm2") is not None:
        out["plant.base_inertia_kgm2"] = [list(r) for r in plant["base_inertia_kgm2"]]
    for i, c in enumerate(plant.get("components") or []):
        key = c.get("id") or str(i)
        out[f"plant.components.{key}.mass_kg"] = c["mass_kg"]
        out[f"plant.components.{key}.com_m"] = list(c["com_m"])
        if c.get("inertia_kgm2") is not None:
            out[f"plant.components.{key}.inertia_kgm2"] = [list(r) for r in c["inertia_kgm2"]]
    for i, a in enumerate(cfg.get("attachments") or []):
        key = a.get("id") or str(i)
        out[f"attachments.{key}.mass_kg"] = a["mass_kg"]
        out[f"attachments.{key}.pos_m"] = list(a["pos_m"])
    if custom_wheels:
        for w in effective_wheels(cfg):
            for f in WHEEL_FIELDS:
                if f == "axis":
                    out[f"wheels.{w['id']}.axis"] = list(w["axis"])
                elif w.get(f) is not None:
                    out[f"wheels.{w['id']}.{f}"] = w[f]
    if cfg["estimator"]["type"] != "ideal":
        S = cfg["sensor"]
        for k in SENSOR_SPEC:
            out[f"sensor.{k}"] = S[k]
        out["sensor.rate_hz"] = S.get("rate_hz") if S.get("rate_hz") is not None else p["fs"]
        if S.get("imu_position_m") is not None:
            out["sensor.imu_position_m"] = list(S["imu_position_m"])
    else:
        out.pop("params.rImu", None)       # the IMU position matters only when an estimator reads the IMU
    out["actuator.motor_lag_ms"] = cfg["actuator"]["motor_lag_ms"]
    return out


def _equal(a, b) -> bool:
    try:
        return bool(np.allclose(np.asarray(a, dtype=float), np.asarray(b, dtype=float), rtol=1e-12, atol=0.0))
    except (TypeError, ValueError):
        return a == b


def coverage(cfg: dict, ps: dict | None) -> dict:
    """Which inputs of this run are measured, overridden or nominal under the parameter set ps."""
    inputs = model_inputs(cfg)
    values = {canonical_path(k): v["value"] for k, v in ((ps or {}).get("values") or {}).items()}
    measured, overridden, nominal = [], [], []
    for path, val in inputs.items():
        if path in values:
            (measured if _equal(val, values[path]) else overridden).append(path)
        elif path == "sensor.rate_hz" and "params.fs" in values and cfg["sensor"].get("rate_hz") is None and _equal(val, values["params.fs"]):
            measured.append(path)
        else:
            nominal.append(path)
    unused = sorted(p for p in values if p not in inputs)
    if not ps or not values:
        status = "nominal"
    elif not nominal and not overridden:
        status = "measured"
    elif measured:
        status = "partially-measured"
    else:
        status = "nominal"
    return {"status": status, "inputs": len(inputs), "measured": sorted(measured), "overridden": sorted(overridden), "nominal": sorted(nominal),
            "unused_in_set": unused,
            "rule": "MEASURED only when every model input the run uses comes from the parameter set with exactly the set's value; "
                    "an input the run changed (e.g. a sweep variable) is OVERRIDDEN; inputs the set does not cover are NOMINAL."}


def apply_parameter_set(cfg: dict, ps: dict) -> tuple[dict, list]:
    """Write the set's values into a raw configuration (per-wheel paths create the wheel list when needed).
    Returns (config, replacements)."""
    from ..config.normalize import normalize
    out = copy.deepcopy(cfg) if isinstance(cfg, dict) else cfg
    if not isinstance(out, dict):
        return out, []
    replaced = []
    vals = {canonical_path(k): v["value"] for k, v in ps["values"].items()}
    if any(p.startswith("wheels.") for p in vals) and out.get("wheels") is None:
        from ..config.normalize import default_wheels
        base, _ = normalize(out)
        out["wheels"] = default_wheels(base["params"], base["actuator"]["wheel_health"])
    for path, v in vals.items():
        before = _get(out, path)
        if before is None and path.startswith("params."):
            from ..constants import NOMINAL
            before = NOMINAL.get(path[7:])
        if before is None or not _equal(before, v):
            replaced.append({"param": path, "config_value": before, "measured_value": v})
        try:
            _set(out, path, copy.deepcopy(v))
        except (StopIteration, IndexError, KeyError, TypeError):
            replaced.append({"param": path, "config_value": None, "measured_value": v, "error": "path not present in this configuration"})
    return out, replaced


REQUIRED_FOR_COMPLETE = ("params.m", "params.a", "params.Jw", "params.KV", "params.R", "params.Vs", "params.Imax", "params.wmaxRpm",
                         "params.cv", "params.cc", "params.fs", "params.rImu", "comOffset_m", "comShift_m", "actuator.motor_lag_ms")


def set_status(values: dict) -> dict:
    """Status of a set on its own (before any run): 'complete for the standard build' needs the standard
    inputs, a full inertia (tensor or k_J) and the sensor model; everything else is partial."""
    paths = {canonical_path(k) for k in values}
    missing = [p for p in REQUIRED_FOR_COMPLETE if p not in paths]
    if "params.kJ" not in paths and "plant.base_inertia_kgm2" not in paths:
        missing.append("params.kJ | plant.base_inertia_kgm2")
    sens = [f"sensor.{k}" for k in SENSOR_SPEC]
    missing_sensor = [p for p in sens if p not in paths]
    return {"status": "measured" if not missing and not missing_sensor else "partially-measured",
            "missing": missing + missing_sensor,
            "note": "A set is 'measured' only when it covers every standard model input including the sensor model; each run still "
                    "reports its own coverage (per-wheel or component inputs, overrides by sweeps)."}

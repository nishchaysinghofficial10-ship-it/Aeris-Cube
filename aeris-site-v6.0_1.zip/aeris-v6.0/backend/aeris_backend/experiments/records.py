"""aeris-run/1 revision 1.2 records produced by the backend.

Revision 1.2 only ADDS fields to revision 1.1 (browser records): `research` (research metrics and
recovery evaluation), `termination`, `executed` (the methods actually run, rates, solver, the
executed disturbance/event schedule), `reproduction` (config hash, seed strategy, versions) and
`definitions.research`. Everything a revision-1.1 reader needs is present with the same meaning.
Derived mass properties and the controller design are the backend's own values; the browser
never regenerates them for a backend record (site/js/runs.js)."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import math
import uuid

import numpy as np

from ..constants import ASSESS, EVENT_DEFS, METRIC_DEFS, OUTCOMES, RPM
from ..metrics.research import DEFINITIONS as RESEARCH_DEFS, METRICS_VERSION, UNITS as RESEARCH_UNITS
from .provenance import coverage
from ..version import (API_PREFIX, BACKEND_NAME, BACKEND_VERSION, ENGINE_VERSION, PARITY_TARGET, RUN_REVISION,
                       RUN_SCHEMA, software_versions)

RESEARCH_EVENT_DEFS = {
    "impulse": "Impulse: an instantaneous angular (or linear, at a point) impulse from the configuration, applied as a momentum jump at the first integration step at or after its time.",
    "wheel_degradation": "Wheel degradation: a scheduled reduction of the wheel's health factor (torque capability) for the stated duration.",
    "wheel_torque_limit": "Imposed torque limit: a scheduled cap on the wheel's deliverable torque.",
    "wheel_speed_limit": "Imposed speed limit: a scheduled reduction of the wheel's speed cut-off.",
    "wheel_clearance": "Fault cleared: the end of a wheel failure with a stated duration; motor torque is available again.",
    "yaw_objective": "Yaw objective relinquished: after a wheel failure the controller gave up yaw control, so the research recovery criteria apply to tilt only from this time.",
    "research_recovery": "Research recovery: the research criteria (attitude error, body rate, hold time, maximum time; see definitions.research.recovery) were met from this time.",
    "estimator_init": "Estimator initialised: the first IMU sample was delivered and processed; before it the controller received the nominal attitude, flagged invalid (docs/ESTIMATION_TIMING.md).",
    "estimate_stale": "Estimate stale: the newest sensor sample behind the controller-facing estimate was older than estimator.stale_after_s; the controller acted on the prediction from the last update, flagged invalid.",
}

NOMINAL_PARAMETER_SET = "nominal-design-v1"
PROVENANCE = {
    "nominal": "Simulation by the AERIS research backend with nominal (unvalidated) parameters. Not a hardware measurement.",
    "measured": "Simulation by the AERIS research backend with parameters measured on the physical cube ({ps}); the model itself is not yet validated against hardware runs. Not a hardware measurement.",
}


def now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def jsonable(o):
    """Tuples → lists, numpy scalars/arrays → Python, NaN/inf → None (JSON has no NaN)."""
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    if isinstance(o, (np.floating,)):
        o = float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, float) and not math.isfinite(o):
        return None
    return o


def canonical_hash(obj) -> str:
    txt = json.dumps(jsonable(obj), sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(txt.encode("utf-8")).hexdigest()


def summarize_mp(res: dict) -> dict:
    """derived: the same keys as the browser's summarizeMP plus the backend's full properties."""
    from ..physics.mass import nominal_bare
    from ..simulation.setup import initial_state
    cfg, mp, d = res["config"], res["mp"], res["design"]
    p = cfg["params"]
    w0 = res["wheels"][0]
    bare = nominal_bare(cfg)
    a = p["a"]
    le, lc = math.sqrt(2) / 2 * a, math.sqrt(3) / 2 * a
    Jc = p["kJ"] * p["m"] * a * a
    out = {k: mp[k] for k in ("M", "rc", "r0", "m0", "Jc0", "ThO", "ThC", "baseCenter", "baseInertia")}
    out["parts"] = mp["parts"]
    out["edge"] = dict(mp["edge"])
    out["corner"] = {k: mp["corner"][k] for k in ("l", "u", "beta", "eig", "ThPar", "ThPerp", "edgeClear", "Thh", "minEig")}
    out["motor"] = {"kt": w0["kt"], "ke": w0["ke"], "taumax": w0["taumax_nominal"], "taumaxRun": w0["taumax"], "wnl": w0["wnl"],
                    "wmax": w0["wmax"], "hmax": w0["hmax"], "R": w0["R"], "Vs": w0["Vs"]}
    out["bare"] = {"Jc": Jc, "le": le, "lc": lc, "Th0e": Jc + p["m"] * le * le, "Thhe": Jc + p["m"] * le * le - p["Jw"],
                   "mgle": p["m"] * p["g"] * le, "Th0c": Jc + p["m"] * lc * lc, "mglc": p["m"] * p["g"] * lc,
                   "ThO": bare["ThO"]}
    out["initial"] = initial_state(cfg, mp)
    out["wheels"] = res["wheels"]
    out["plant"] = {"ThO_true": d["plant"]["Th0"] if cfg["mode"] == "corner" else None, "inertiaScale": cfg["uncertainty"]["inertiaScale"],
                    "inertia_perturbation_kgm2": cfg["uncertainty"].get("inertia_perturbation_kgm2"),
                    "note": "The plant uses Θ_O × inertiaScale (+ perturbation); the controller's model is design.model_mass."}
    out["source"] = BACKEND_NAME
    return out


def summarize_design(d: dict) -> dict:
    keep = ("mode", "model", "structure", "controller", "betaRef", "uRef", "tilt", "yaw", "mimo", "actuator", "plant", "model_mass",
            "edge_model_Thh", "edge_model_mgl")
    out = {k: d[k] for k in keep if k in d}
    if "plant" in out and "Thhi" in out["plant"]:
        out["plant"] = {k: v for k, v in out["plant"].items() if k != "Thhi"}
    return out


def build_record(res: dict, meta: dict | None = None, *, experiment_id: str | None = None, run_id: str | None = None,
                 parameter_set: dict | None = None, seed_strategy: dict | None = None) -> dict:
    meta = meta or {}
    cfg = res["config"]
    ps = parameter_set or {"id": NOMINAL_PARAMETER_SET, "status": "nominal"}
    # v5: the label follows THIS run's coverage (docs/PARAMETERS.md), not the set's own status
    cov = coverage(cfg, ps) if ps.get("values") else None
    status = cov["status"] if cov else "nominal"
    if status not in ("nominal", "measured"):
        status = "nominal"   # 'validated' is never assigned automatically; a partially measured run counts as nominal
    note = ("Design values; not yet compared with measurements from the physical cube." if status == "nominal"
            else "Every model input of this run comes from a measured parameter set; the model itself has not been validated against hardware runs.")
    if cov and cov["status"] != "measured":
        note = (f"Parameter set {ps['id']} covers {len(cov['measured'])} of {cov['inputs']} model inputs of this run; "
                + (f"nominal: {', '.join(cov['nominal'][:12])}{' …' if len(cov['nominal']) > 12 else ''}; " if cov["nominal"] else "")
                + (f"overridden by this run: {', '.join(cov['overridden'])}; " if cov["overridden"] else "")
                + "so the run is labelled NOMINAL.")
    validation = {"status": status, "parameter_set": ps["id"], "note": note}
    rid = run_id or ("run-" + uuid.uuid4().hex)
    sw = software_versions()
    sw.update({"site": meta.get("client_site"), "model": ENGINE_VERSION, "parity_target": PARITY_TARGET,
               "solver": f"Fixed-step RK4 at Δt = 1/{res['executed']['rates']['integration_hz']:g} s; controller at {cfg['params']['fs']:g} Hz with a zero-order hold",
               "configSchema": "aeris-config/1", "configRevision": cfg.get("config_revision", "1.1")})
    rec = {
        "schema": RUN_SCHEMA, "schema_revision": RUN_REVISION,
        "id": rid, "experiment_id": experiment_id, "name": meta.get("name") or auto_name(cfg), "created": now_iso(),
        "note": meta.get("note", ""), "source": "simulation", "collection": "user",
        "origin": {"kind": "simulation", "engine": BACKEND_NAME, "engine_version": ENGINE_VERSION, "adapter": "research-api", "mode": "simulation",
                   "backend_version": BACKEND_VERSION, "api": API_PREFIX},
        "validation": validation, "group": meta.get("group"),
        "software": sw,
        "provenance": PROVENANCE[status].format(ps=ps["id"]),
        "config": cfg,
        "derived": summarize_mp(res), "design": summarize_design(res["design"]),
        "warnings": [{"path": w["path"], "message": w["message"]} for w in res.get("warnings", [])], "errors": [],
        "samples": res["samples"], "metrics": res["metrics"],
        "definitions": {"metrics": METRIC_DEFS, "assessment": ASSESS, "outcomes": OUTCOMES,
                        "events": dict(EVENT_DEFS, **RESEARCH_EVENT_DEFS), "research": RESEARCH_DEFS, "research_units": RESEARCH_UNITS},
        "outcome": res["outcome"], "timeline": res["timeline"],
        "events": {"fellAt": res["fellAt"], "contactAt": res["contactAt"], "fallCause": res["fallCause"], "failedWheels": res["failedWheels"]},
        "research": res["research"], "termination": res["termination"], "executed": res["executed"],
        "reproduction": {"config_hash": canonical_hash(cfg), "seed": cfg["seed"], "seed_strategy": seed_strategy or {"kind": "single", "seed": cfg["seed"]},
                         "metrics_version": METRICS_VERSION,
                         "software": {k: sw[k] for k in ("backend", "engine", "python", "numpy", "scipy")},
                         "parameter_set": dict({k: ps[k] for k in ("id", "status", "revision", "applied", "missing", "replaced") if k in ps},
                                               **({"coverage": {k: cov[k] for k in ("status", "inputs", "measured", "overridden", "nominal", "unused_in_set")}} if cov else {})),
                         "solver": res["executed"]["solver"], "rates": res["executed"]["rates"],
                         "determinism": "Same configuration + same software versions on the same platform reproduce the samples exactly; across platforms results agree to floating-point tolerance (not promised bit-identical)."},
        "demo": False, "mock": False,
    }
    return jsonable(rec)


CTRL_NAMES = {"pid": "PID", "lqr": "LQR", "adp": "COM-adaptive LQR", "nlpd": "Nonlinear PD", "none": "No control"}


def auto_name(cfg: dict) -> str:
    c = cfg["controller"]
    bits = ["Edge" if cfg["mode"] == "edge" else "Corner", CTRL_NAMES.get(c["type"], c["type"]) + (" (MIMO)" if c.get("structure") == "mimo-lqr" else "")]
    if cfg.get("comOffset_m"):
        bits.append(f"COM {cfg['comOffset_m'] * 1000:+.1f} mm")
    bits.append(f"tilt {cfg['initial']['tilt_deg']:g}°" if cfg["initial"].get("tilt_deg") is not None else "explicit initial q")
    if cfg["disturbances"]:
        bits.append(f"{len(cfg['disturbances'])} load" + ("s" if len(cfg["disturbances"]) > 1 else ""))
    if cfg["events"]:
        bits.append("wheel events " + "/".join(str(e["wheel"]).upper() for e in cfg["events"]))
    if cfg["estimator"]["type"] != "ideal":
        bits.append(cfg["estimator"]["type"].upper())
    bits.append(f"{cfg['duration_s']:g} s")
    return " · ".join(bits)


def to_csv(rec: dict) -> str:
    if not rec.get("samples"):
        return f"# This run has no samples (outcome: {rec['outcome']['label']})\n"
    S = rec["samples"]
    cols = list(S["cols"].keys())
    n = len(S["cols"]["t"])
    c = rec["config"]
    ec = (rec.get("executed") or {}).get("controller") or {}
    ee = (rec.get("executed") or {}).get("estimator") or {}
    lines = ["# AERIS run export (aeris-run/1 revision " + rec["schema_revision"] + ")", "# " + rec["provenance"], "# name: " + rec["name"],
             f"# experiment: {rec.get('experiment_id')} ; id: {rec['id']} ; created: {rec['created']}",
             f"# source: simulation ({rec['origin']['engine']}, {rec['origin']['engine_version']}) ; validation: {rec['validation']['status']} ({rec['validation']['parameter_set']})",
             f"# mode: {c['mode']} ; controller (executed): {ec.get('type', c['controller']['type'])} ({ec.get('structure', c['controller'].get('structure', 'decoupled'))}) ; "
             f"estimator (executed): {ee.get('type', c['estimator']['type'])}{' (perfect-state baseline)' if ee.get('truth_access') else ''} ; seed: {c['seed']} ; control loop: {c['params']['fs']:g} Hz ; recorded at {S['rate_hz']:g} Hz",
             f"# outcome: {rec['outcome']['label']} — {rec['outcome']['reason']}",
             f"# termination: {rec['termination']['reason']} — {rec['termination']['detail']}"]
    sch = S.get("schedule") or {}
    if sch:
        lines.append(f"# recording: {sch.get('text')} ; requested {sch.get('requested_hz'):g} Hz, realized {sch.get('realized_hz'):g} Hz")
    R = rec.get("research") or {}
    if R:
        mv = R.get("metrics_version") or (rec.get("reproduction") or {}).get("metrics_version") or "1"
        ae = R.get("attitude_error") or {}
        lines.append(f"# research metrics version {mv}" + (" (pre-v5 definitions; reanalyse, docs/METRICS.md)" if mv == "1" else "")
                     + (f" ; attitude error RMS {ae.get('rms'):.6g} deg, IAE {ae.get('iae'):.6g} deg·s, ISE {ae.get('ise'):.6g} " + ("deg²·s" if mv != "1" else "(v1 value; unit as saved)") if ae else ""))
    if rec.get("lineage"):
        L = rec["lineage"]
        lines.append(f"# lineage: {L.get('relation')} of {L.get('derived_from_experiment') or L.get('derived_from') or L.get('retry_of_job')}")
    lines += ["# full configuration, research metrics and definitions are in the JSON export of this run",
             ",".join(f"{k} [{S['units'].get(k, '')}]" for k in cols)]
    for i in range(n):
        lines.append(",".join(str(S["cols"][k][i]) for k in cols))
    return "\n".join(lines) + "\n"


__all__ = ["build_record", "to_csv", "jsonable", "canonical_hash", "RPM"]

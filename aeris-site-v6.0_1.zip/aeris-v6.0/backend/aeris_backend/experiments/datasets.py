"""Dataset integrity helpers shared by the API (finalise, export) and the database tool (verify)."""
from __future__ import annotations

from .records import canonical_hash


def member_hashes(repo, members) -> dict:
    """Content hash of every member as stored now (runs: the record; sweeps: definition + rows; recordings: the
    stored content hash), so that a final dataset can be checked against the hashes taken when it was finalised."""
    out = {}
    for m in members:
        if m["kind"] == "run":
            r = repo.get_run(m["id"])
            out[m["id"]] = canonical_hash(r) if r else None
        elif m["kind"] == "sweep":
            sw = repo.get_sweep(m["id"])
            out[m["id"]] = canonical_hash({"definition": sw["definition"], "rows": sw["rows"]}) if sw else None
        elif m["kind"] == "hardware-run":
            h = repo.get("recordings", m["id"])
            out[m["id"]] = h.get("content_hash") if h else None
    return out


def check_final(repo, doc) -> dict | None:
    """Integrity of a final dataset: its member list and every member's content against the finalisation hashes."""
    if doc.get("status") != "final":
        return None
    fin = doc.get("finalized") or {}
    now_h = member_hashes(repo, doc["members"])
    then_h = fin.get("member_hashes")
    changed = sorted(k for k in (then_h or {}) if then_h.get(k) != now_h.get(k))
    return {"members_hash_ok": canonical_hash(doc["members"]) == fin.get("content_hash"),
            "member_content_ok": (not changed) if then_h is not None else None,
            "changed_members": changed,
            "note": None if then_h is not None else "finalised before v5: only the member list was hashed"}

"""Reproduction and reanalysis of stored runs (docs/REPRODUCIBILITY.md, docs/MIGRATION_V5.md).

A stored record is immutable. Reproducing it simulates its saved configuration again as a NEW
record whose reproduction.reproduces block compares the two; reanalysing an old record (metrics
version older than the current one) is a reproduction with lineage: its samples hold the state at
the recording rate only, while the research metrics are integrals over every integration step, so
they cannot be recomputed exactly from the samples.

Configuration changes a reproduction needs are explicit and listed (config_changes):
  record_hz   v4 accepted recording rates that do not divide the integration rate and recorded every
              round(f_int / record_hz) steps while labelling the requested rate. v5 rejects such rates;
              the reproduction uses the rate v4 actually executed (same samples, correct label).

Verdicts (compare_reproduction):
  identical         same number of rows, every shared sample column bit-identical, same outcome
  within_tolerance  every shared numeric sample differs by at most TOL_REL·max(1, |x|) (the 6-significant-
                    digit recording rounding can flip on another platform), same outcome
  different         otherwise; 'expected' reasons (engine version, metric version, changed configuration)
                    are listed when they explain the difference
"""
from __future__ import annotations

import copy
import math

from ..version import ENGINE_VERSION

TOL_REL = 2e-5          # relative, per sample value (records keep 6 significant digits)

# Engine changes that alter trajectories, with the configurations they affect (CHANGELOG.md, site/docs/MIGRATION_V5.md §3).
ENGINE_CHANGES = {
    "aeris-research-engine 1.1.0": {
        "affects": "runs with the cf3d or mekf estimator (controller-facing prediction to the control time, MEKF reset Jacobian, "
                   "compensated alignment); the recorded est_* columns of every estimator run",
        "estimators": ("cf3d", "mekf"),
    },
}


def reproduction_config(orig: dict) -> tuple[dict, list]:
    """The configuration to simulate again, and the explicit changes applied to it."""
    cfg = copy.deepcopy(orig["config"])
    notes = []
    rates = ((orig.get("executed") or {}).get("rates") or {})
    f_int = (cfg.get("solver") or {}).get("integration_hz") or (cfg.get("params") or {}).get("fs") or 500
    rec = cfg.get("record_hz")
    if isinstance(rec, (int, float)) and rec > 0:
        stride = max(1, int(round(f_int / rec)))
        realized = f_int / stride
        if abs(realized - rec) > 1e-9 * max(1.0, rec):
            cfg["record_hz"] = realized
            notes.append({"path": "record_hz", "from": rec, "to": realized,
                          "reason": f"The original run recorded every {stride} integration steps ({realized:g} Hz) while labelling {rec:g} Hz "
                                    f"(AERIS v4 recording defect). The reproduction records at the executed rate; the samples are the same instants.",
                          "original_label_hz": rates.get("record_hz", rec)})
    return cfg, notes


def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def compare_reproduction(orig: dict | None, rec: dict, orig_id: str) -> dict:
    rep = {"of_run": orig_id}
    if not orig:
        rep.update({"verdict": "original_missing", "identical": False, "notes": ["The original run is not stored here."]})
        return rep
    a, b = orig["samples"]["cols"], rec["samples"]["cols"]
    rows = [len(a.get("t", [])), len(b.get("t", []))]
    same_rows = rows[0] == rows[1]
    cols = [k for k in a if k in b]
    max_abs = 0.0
    max_rel_excess = 0.0
    worst = None
    if same_rows:
        for k in cols:
            for x, y in zip(a[k], b[k]):
                if _num(x) and _num(y):
                    d = abs(x - y)
                    if d > max_abs:
                        max_abs = d
                    lim = TOL_REL * max(1.0, abs(x))
                    if d > lim and d / lim > max_rel_excess:
                        max_rel_excess, worst = d / lim, k
    same_outcome = (orig.get("outcome") or {}).get("code") == (rec.get("outcome") or {}).get("code")
    o_rep, n_rep = orig.get("reproduction") or {}, rec.get("reproduction") or {}
    o_eng = (orig.get("origin") or {}).get("engine_version") or (o_rep.get("software") or {}).get("engine")
    n_eng = (rec.get("origin") or {}).get("engine_version") or ENGINE_VERSION
    identical = same_rows and max_abs == 0.0 and same_outcome
    within = same_rows and max_rel_excess == 0.0 and same_outcome
    verdict = "identical" if identical else ("within_tolerance" if within else "different")
    expected = []
    if verdict == "different":
        if o_eng != n_eng:
            ch = ENGINE_CHANGES.get(n_eng)
            est = ((orig.get("config") or {}).get("estimator") or {}).get("type")
            if ch and est in ch["estimators"]:
                expected.append(f"engine changed ({o_eng} → {n_eng}): {ch['affects']}")
            else:
                expected.append(f"engine changed ({o_eng} → {n_eng})")
        if not same_rows:
            expected.append(f"row count differs ({rows[0]} vs {rows[1]})")
    rep.update({"of_experiment": orig.get("experiment_id"), "verdict": verdict, "identical": identical, "within_tolerance": within,
                "tolerance": {"relative": TOL_REL, "applies_to": "every numeric sample value in the shared columns"},
                "same_outcome": same_outcome, "rows": rows, "max_abs_diff": max_abs, "columns_compared": len(cols),
                "first_column_over_tolerance": worst,
                "columns_only_in_original": [k for k in a if k not in b], "columns_only_in_reproduction": [k for k in b if k not in a],
                "same_config_hash": o_rep.get("config_hash") == n_rep.get("config_hash"),
                "same_software": o_rep.get("software") == n_rep.get("software"),
                "engine_versions": [o_eng, n_eng],
                "metrics_versions": [o_rep.get("metrics_version") or "1", n_rep.get("metrics_version")],
                "explanations": expected})
    return rep

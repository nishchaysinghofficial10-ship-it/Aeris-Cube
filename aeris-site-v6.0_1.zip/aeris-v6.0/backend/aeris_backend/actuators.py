"""Reaction-wheel actuators: motor limits, friction, lag, health, wheel events, allocation.

Sign convention (browser engine): T_i is the motor torque applied TO wheel i about its spin axis
a_i; the body receives −T_i·a_i. The wheel speed Ω_i is RELATIVE to the body.

Torque the driver can deliver (AERIS_TWIN.tauAvail, per wheel):
    |T| ≤ τ_max·h                                     (current limit k_t·I_max, torque scale, health h)
    if T·Ω > 0 (driving the wheel faster):
        |T| ≤ h·max(0, k_t (V_s − k_e|Ω|)/R)          (back-EMF / supply-voltage limit)
        T = 0 once |Ω| ≥ Ω_max                        (speed cut-off: a loss of authority in that
                                                        direction, not a clamp on the speed state)
A braking torque (T·Ω ≤ 0) is limited by the current limit only (the driver can regenerate).
Friction on the wheel: f(Ω) = c_v Ω + c_c tanh(Ω).

Research extensions: per-wheel parameters and axes (`wheels`), wheel events (failure with an
optional clearance time, degradation of the health factor, an imposed torque limit, an imposed
speed limit, each with an optional duration), first-order torque lag, and the electrical limit
applied either to the command at each control update ('command', browser behaviour) or also
continuously to the lagged torque at every integration step ('continuous').
"""
from __future__ import annotations

import math

import numpy as np

from .config.normalize import effective_wheels
from .constants import RPM


class Wheel:
    __slots__ = ("id", "axis", "Jw", "kt", "ke", "R", "Vs", "taumax", "taumax_nominal", "wnl", "wmax", "cv", "cc",
                 "health", "failed", "deg_health", "torque_cap", "speed_cap", "lag_state")

    def __init__(self, spec: dict, torque_scale: float):
        ax = np.array(spec["axis"], dtype=float)
        ax = ax / np.linalg.norm(ax)
        self.id = spec["id"]
        self.axis = (float(ax[0]), float(ax[1]), float(ax[2]))
        self.Jw = float(spec["Jw"])
        self.kt = 60.0 / (2 * math.pi * spec["KV"])
        self.ke = self.kt
        self.R = float(spec["R"])
        self.Vs = float(spec["Vs"])
        self.taumax_nominal = self.kt * spec["Imax"]
        self.taumax = self.taumax_nominal * torque_scale
        self.wnl = self.Vs / self.ke
        self.wmax = spec["wmaxRpm"] * RPM
        self.cv = float(spec["cv"])
        self.cc = float(spec["cc"])
        self.health = float(spec.get("health", 1))
        self.failed = False
        self.deg_health = None    # health factor imposed by an active degradation event
        self.torque_cap = None    # torque limit imposed by an active event [N·m]
        self.speed_cap = None     # speed limit imposed by an active event [rad/s]
        self.lag_state = 0.0

    def eff_health(self):
        h = self.health if self.deg_health is None else self.health * self.deg_health
        return h

    def eff_wmax(self):
        return self.wmax if self.speed_cap is None else min(self.wmax, self.speed_cap)

    def avail(self, T: float, ww: float) -> float:
        """AERIS_TWIN.tauAvail with the wheel's health and any active event caps."""
        h = self.eff_health()
        tm = self.taumax if h == 1 else self.taumax * h
        if self.torque_cap is not None and self.torque_cap < tm:
            tm = self.torque_cap
        if T > tm:
            T = tm
        elif T < -tm:
            T = -tm
        if T * ww > 0:
            wmax = self.eff_wmax()
            lim = 0.0 if abs(ww) >= wmax else max(0.0, self.kt * (self.Vs - self.ke * abs(ww)) / self.R)
            if h != 1:
                lim *= h
            if abs(T) > lim:
                T = lim if T > 0 else -lim
        return T

    def bounds(self, ww: float) -> tuple[float, float]:
        """Deliverable torque interval [lo, hi] at wheel speed ww (0 for a failed wheel)."""
        if self.failed:
            return (0.0, 0.0)
        return (self.avail(-1e9, ww), self.avail(1e9, ww))

    def friction(self, ww: float) -> float:
        return self.cv * ww + self.cc * math.tanh(ww)


class WheelSet:
    def __init__(self, cfg: dict):
        specs = effective_wheels(cfg)
        self.wheels = [Wheel(s, cfg["torqueScale"]) for s in specs]
        self.n = len(self.wheels)
        self.ids = [w.id for w in self.wheels]
        self.axes = [w.axis for w in self.wheels]
        self.A = np.array(self.axes).T                 # 3 × n, columns are spin axes (body frame)
        lag_ms = cfg["actuator"]["motor_lag_ms"]
        self.lag_ms = lag_ms
        self.electrical = cfg["actuator"].get("electrical_limit", "command")
        self.standard = self.n == 3 and all(abs(self.A[i, j] - (1.0 if i == j else 0.0)) < 1e-12 for i in range(3) for j in range(3))

    def index(self, wid: str) -> int:
        return self.ids.index(wid) if wid in self.ids else -1

    def lag_factor(self, dt: float) -> float:
        return 1 - math.exp(-dt / (self.lag_ms / 1000.0)) if self.lag_ms > 0 else 1.0

    def summary(self) -> list[dict]:
        return [{"id": w.id, "axis": list(w.axis), "Jw": w.Jw, "kt": w.kt, "ke": w.ke, "R": w.R, "Vs": w.Vs,
                 "taumax_nominal": w.taumax_nominal, "taumax": w.taumax, "wnl": w.wnl, "wmax": w.wmax,
                 "hmax": w.Jw * w.wmax, "cv": w.cv, "cc": w.cc, "health": w.health} for w in self.wheels]


# ---------------------------------------------------------------------------------------
# Allocation: requested wheel-torque vector u (body frame, u = Σ T_i a_i) → per-wheel commands
# ---------------------------------------------------------------------------------------
def least_squares_plane(cols: list, target, u_ref) -> list:
    """Browser reconfiguration after a failure: fit the healthy wheels' axes, projected on the
    tilt plane (⟂ u_ref), to the projected request in the least-squares sense; yaw is given up."""
    from .physics.quaternion import dot, proj_on
    P = [proj_on(c, u_ref) for c in cols]
    tp = proj_on(target, u_ref)
    if len(P) == 2:
        a11, a12, a22 = dot(P[0], P[0]), dot(P[0], P[1]), dot(P[1], P[1])
        b1, b2 = dot(P[0], tp), dot(P[1], tp)
        dd = a11 * a22 - a12 * a12
        return [(a22 * b1 - a12 * b2) / dd, (a11 * b2 - a12 * b1) / dd]
    if len(P) == 1:
        return [dot(P[0], tp) / max(1e-12, dot(P[0], P[0]))]
    M = np.array(P).T
    return list(np.linalg.lstsq(M, np.array(tp), rcond=None)[0])


def allocate_bounded(A: np.ndarray, u, lo, hi, weights=None):
    """Bounded least squares min ‖W(A T − u)‖ s.t. lo ≤ T ≤ hi (scipy.optimize.lsq_linear)."""
    from scipy.optimize import lsq_linear
    W = np.eye(3) if weights is None else np.diag(weights)
    lo = np.array(lo, dtype=float)
    hi = np.array(hi, dtype=float)
    fixed = hi - lo < 1e-15
    if fixed.all():
        return lo.copy()
    res = lsq_linear(W @ A[:, ~fixed], W @ (np.array(u, dtype=float) - A[:, fixed] @ lo[fixed]),
                     bounds=(lo[~fixed], hi[~fixed] + 1e-15), method="bvls")
    T = lo.copy()
    T[~fixed] = res.x
    return T

"""Research metrics and recovery criteria, computed from the per-integration-step arrays (never
from the recorded plot samples). Every value is stored with its unit and definition.

Metric definitions version 2 (METRICS_VERSION). Version 1 (v4 records, no `metrics_version`
field) had two defects: ISE of angles was divided by the rad→deg factor once instead of squared,
and the time integrals gave full step weight to both end samples (n + 1 weights for n intervals).
Version-1 values are never rewritten; a reanalysis re-runs the saved configuration under a new
record with lineage (docs/METRICS.md).

Time grid and integration rule (version 2)
  A signal x is known at the integration instants t_k = k·Δt, k = 0 … n, where n is the number of
  integration steps actually executed (early termination shortens n). Integrals use the
  trapezoidal rule over the n intervals:  ∫x dt ≈ Δt·(x_0/2 + x_1 + … + x_{n−1} + x_n/2).
  RMS = sqrt(∫x² dt / T) with T = n·Δt, so a constant x gives RMS = |x|, IAE = |x|·T, ISE = x²·T.
  With n = 0 (nothing executed) the integrals are 0 and RMS = |x_0|.
  Quantities that are constant over each integration step (applied/requested torque, saturation
  flags, the authority residual) are integrated exactly with one weight per step (k = 0 … n−1).
  Estimator errors are evaluated at the start of every step (the estimate the controller used for
  that step) and time-weighted per step.
Units: angles in degrees; RMS, peak, final [deg]; IAE [deg·s]; ISE [deg²·s]; rates [deg/s].
"""
from __future__ import annotations

import math

from ..constants import ASSESS, DEG, RPM

METRICS_VERSION = "2"
METRICS_ID = "aeris-research-metrics/2"
SUPERSEDED = {
    "1": ["ISE of angles was converted with the rad→deg factor once instead of squared (values too small by 180/π ≈ 57.3)",
          "IAE/ISE gave full step weight to both end samples (n + 1 weights for n intervals); RMS was the plain mean over n + 1 samples"],
}

DEFINITIONS = {
    "metrics_version": "Research metric definitions version 2 (aeris-research-metrics/2): time-weighted trapezoidal integrals over the executed integration steps. See the module docstring / docs/METRICS.md.",
    "recovery": "Research recovery: the first time t_r at which the attitude error stays ≤ the attitude threshold AND the body rate stays ≤ the rate threshold continuously for hold_s, with t_r ≤ max_time_s (default: the observation window). Attitude error: the quaternion geodesic angle between the attitude and the target attitude (centre of mass above the pivot at the commanded heading, or the explicit reference) when the yaw objective is 'hold'; the COM lean (reduced attitude, tilt only) when it is 'free', in edge mode, and after yaw control has been given up following a wheel failure. Body rate: |ω| ('hold'), or the tilt-rate component |ω − (ω·û)û| ('free'). Reported separately: first recovery, sustained recovery (criteria held from t_r to the end without exits and no fall), exits after recovery and a fall after recovery. This is separate from the legacy 'Recovered' outcome (COM lean within ±0.25° held to the end of the window).",
    "attitude_error": "Research attitude error (see 'recovery' for the target). RMS = sqrt(ISE/T), IAE = ∫|err| dt [deg·s], ISE = ∫err² dt [deg²·s] (trapezoidal rule over the executed integration steps, T = executed duration), peak and final value [deg].",
    "lean": "COM lean e (same quantity as the legacy metrics, research definitions): RMS, IAE [deg·s], ISE [deg²·s] with the trapezoidal rule over the executed integration steps; peak and final [deg].",
    "body_rate": "Body angular velocity magnitude |ω| (edge: |θ̇|): time-weighted RMS (trapezoidal) and peak [deg/s].",
    "wheel_speed": "Peak |Ω_i| per wheel (relative to the body) over every integration step.",
    "torque": "Requested torque: the allocated per-wheel command before the driver limits; applied torque: after the limits and the motor lag. Peaks of |T| per wheel over the executed steps.",
    "effort": "Control effort ∫ Σ|T_i| dt of the applied torque [N·m·s] (the applied torque is constant over each integration step).",
    "energy": "Electrical energy MODEL: ∫ Σ max(0, (T_i/k_t)²R + T_i Ω_i) dt (copper loss plus mechanical power, no regeneration credit, no driver or supply losses). A model estimate, not a measurement.",
    "saturation": "Torque-saturated time: integration steps at which any wheel's command exceeded what its driver could deliver (per wheel as well), one step weight each.",
    "speed_limited": "Speed-limited time: steps at which a wheel was at ≥ 98 % of its speed limit at the start of the step (per wheel as well).",
    "estimator": "Estimator accuracy against the true state, for the estimate the controller used at each integration step (the prediction to the control time, see docs/ESTIMATION.md): attitude RMSE (geodesic angle; edge: estimated minus true tilt), tilt RMSE (angle between the estimated and true vertical in body axes: the part gravity makes observable), gyro-bias error |b̂ − b| (final value and RMS), and the timing of the estimate (docs/ESTIMATION_TIMING.md): age of the newest measurement behind it (mean, max over the steps with an estimate), time before the first measurement (uninitialised_s), time flagged stale (age > estimator.stale_after_s) and their sum (invalid_s). Per-step quantities, one weight per integration step k = 0 … n−1. Absent for the perfect-state baseline.",
    "termination": "Why the run stopped (separate from the outcome): duration, recovery (only with termination.stop_on_recovery), fall, loss_of_support, invalid_state, numerical_failure, safety_limit, cancelled.",
    "event_counts": "Number of timeline events of each type.",
    "authority": "Actuator authority: the body torque the controller requested minus the body torque the wheels applied, r = u_req − Σ T_i a_i (after allocation, driver limits, speed limits, failures and motor lag; edge: about the support axis). Time-weighted RMS and peak |r|, and the time during which |r| exceeded 5 % of |u_req| (at least 1e-4 N·m): the time without full authority.",
}
UNITS = {"metrics_version": "–",
         "attitude_error.rms": "deg", "attitude_error.peak": "deg", "attitude_error.final": "deg", "attitude_error.iae": "deg·s", "attitude_error.ise": "deg²·s",
         "attitude_error.duration_s": "s",
         "lean.rms": "deg", "lean.peak": "deg", "lean.final": "deg", "lean.iae": "deg·s", "lean.ise": "deg²·s", "lean.duration_s": "s",
         "body_rate.rms": "deg/s", "body_rate.peak": "deg/s", "wheel_speed.peak_rpm": "rpm", "torque": "N·m", "effort_Nms": "N·m·s",
         "energy_model_J": "J", "saturation_s": "s", "speed_limited_s": "s", "authority.residual": "N·m",
         "authority.residual_rms_Nm": "N·m", "authority.residual_peak_Nm": "N·m",
         "authority.deficit_s": "s", "estimator.attitude_rmse_deg": "deg", "estimator.tilt_rmse_deg": "deg", "estimator.bias_error_final_dps": "deg/s",
         "estimator.bias_error_rms_dps": "deg/s", "estimator.age_mean_s": "s", "estimator.age_max_s": "s", "estimator.stale_s": "s",
         "estimator.uninitialised_s": "s", "estimator.invalid_s": "s",
         "recovery.t_s": "s", "resolution_s": "s"}


def time_stats(arr, n, dt):
    """Time-weighted statistics of |x| from the samples x_0 … x_n at t_k = k·dt (version-2 rule):
    trapezoidal IAE = ∫|x| dt and ISE = ∫x² dt over [0, n·dt], RMS = sqrt(ISE / (n·dt)), peak and final.
    Values are in the units of the samples (the caller converts angles; ISE converts with the square)."""
    x0 = abs(arr[0])
    if n <= 0:
        return {"rms": x0, "iae": 0.0, "ise": 0.0, "peak": x0, "final": x0, "duration_s": 0.0}
    ia = 0.5 * (x0 + abs(arr[n]))
    ss = 0.5 * (x0 * x0 + arr[n] * arr[n])
    pk = max(x0, abs(arr[n]))
    for i in range(1, n):
        v = abs(arr[i])
        ia += v
        ss += v * v
        if v > pk:
            pk = v
    T = n * dt
    return {"rms": math.sqrt(ss * dt / T), "iae": ia * dt, "ise": ss * dt, "peak": pk, "final": abs(arr[n]), "duration_s": T}


def angle_stats(arr, n, dt):
    """time_stats of an angle signal [rad] converted to degrees by dimension: RMS, peak, final ÷ DEG;
    IAE [deg·s] ÷ DEG; ISE [deg²·s] ÷ DEG²."""
    s = time_stats(arr, n, dt)
    return {"rms": s["rms"] / DEG, "iae": s["iae"] / DEG, "ise": s["ise"] / (DEG * DEG), "peak": s["peak"] / DEG,
            "final": s["final"] / DEG, "duration_s": s["duration_s"]}


def _authority(full, ctx, n, dt):
    """Requested body torque minus the body torque actually applied by the wheels (every integration step)."""
    if full.get("ureq") is None or ctx.get("axes") is None:
        return None
    axes, edge = ctx["axes"], ctx["mode"] == "edge"
    nw = len(axes)
    ss = pk = 0.0
    deficit = 0
    for k in range(n):
        if edge:
            u = full["ureq"][0][k]
            ap = sum(full["Tapp"][i][k] * axes[i][0] for i in range(nw))
            r = abs(u - ap)
            un = abs(u)
        else:
            u = (full["ureq"][0][k], full["ureq"][1][k], full["ureq"][2][k])
            ap = [sum(full["Tapp"][i][k] * axes[i][j] for i in range(nw)) for j in range(3)]
            r = math.sqrt(sum((u[j] - ap[j]) ** 2 for j in range(3)))
            un = math.sqrt(sum(x * x for x in u))
        ss += r * r
        pk = max(pk, r)
        if r > max(0.05 * un, 1e-4):
            deficit += 1
    # the residual is constant over each integration step: one step weight each (k = 0 … n−1)
    return {"residual_rms_Nm": math.sqrt(ss / n) if n else 0.0, "residual_peak_Nm": pk, "deficit_s": deficit * dt}


class RecoveryMonitor:
    """Online form of the research recovery test (used for termination.stop_on_recovery); the
    post-run evaluation below uses the same rule on the same per-step arrays."""

    def __init__(self, crit: dict, dt: float, edge: bool):
        self.thr_a = crit["attitude_error_deg"] * DEG
        self.thr_r = crit["rate_dps"] * DEG
        self.hold = max(1, int(round(crit["hold_s"] / dt)))
        self.t_max = crit["max_time_s"]
        self.dt = dt
        self.run = 0
        self.t_rec = None

    def update(self, k: int, att: float, rate: float) -> bool:
        if self.t_rec is not None:
            return True
        if abs(att) <= self.thr_a and rate <= self.thr_r:
            self.run += 1
            if self.run >= self.hold + 1:
                t = (k - self.hold) * self.dt
                if self.t_max is None or t <= self.t_max + 1e-12:
                    self.t_rec = t
                    return True
        else:
            self.run = 0
        return False


def recovery(full, ctx) -> dict:
    """Research recovery against the saved criteria, evaluated on the per-step arrays.

    first recovery   t_r: the first time from which both thresholds hold for hold_s (hold+1 samples)
    recovered        t_r exists and t_r ≤ max_time_s
    exits            later samples at which the criteria stop holding after t_r
    sustained        recovered, no exit after t_r and no fall after t_r (criteria held to the end)
    sustained_from_s the start of the final uninterrupted interval in which the criteria hold (≥ hold_s),
                     if the run ends inside such an interval
    """
    crit = dict(ctx["recovery"])
    n, dt = full["nSteps"], ctx["dt"]
    edge = ctx["mode"] == "edge"
    att = full["e"] if edge else full["att"]
    thr_a = crit["attitude_error_deg"] * DEG
    thr_r = crit["rate_dps"] * DEG
    hold = max(1, int(round(crit["hold_s"] / dt)))
    t_max = crit["max_time_s"] if crit["max_time_s"] is not None else ctx["window_s"]
    given_up = ctx.get("yaw_given_up_at")
    declared = "n/a (edge: single tilt axis)" if edge else crit["yaw_objective"]
    free_from = 0 if (edge or crit["yaw_objective"] == "free") else (int(round(given_up / dt)) if given_up is not None else None)

    def ok(k):
        rate = full["rate"][k] if (free_from is None or k < free_from or edge) else full["rate_tilt"][k]
        if edge:
            rate = full["rate"][k]
        return abs(att[k]) <= thr_a and rate <= thr_r
    run = 0
    t_rec = None
    for k in range(n + 1):
        if ok(k):
            run += 1
            if run >= hold + 1:
                t_rec = (k - hold) * dt
                break
        else:
            run = 0
    recovered = t_rec is not None and t_rec <= t_max + 1e-12
    held = False
    exits = 0
    last_exit = None
    sustained_from = None
    if t_rec is not None:
        k0 = int(round(t_rec / dt))
        state = True
        held = True
        seg_start = k0
        for k in range(k0, n + 1):
            o = ok(k)
            if state and not o:
                exits += 1
                last_exit = k * dt
                held = False
            if o and not state:
                seg_start = k
            state = o
        if state and (n - seg_start) >= hold:
            sustained_from = seg_start * dt
    fell_after = ctx.get("fellAt") is not None and t_rec is not None and ctx["fellAt"] >= t_rec
    effective = declared
    note = None
    if given_up is not None and not edge and crit["yaw_objective"] == "hold":
        effective = "free after a wheel failure"
        note = f"Yaw objective relinquished at t = {given_up:.3f} s (wheel failure; the controller gave up yaw control). From then on the criteria apply to tilt only."
    summary = (f"attitude error ≤ {crit['attitude_error_deg']:g}° and body rate ≤ {crit['rate_dps']:g}°/s held for {crit['hold_s']:g} s"
               + (f" by t = {crit['max_time_s']:g} s" if crit.get("max_time_s") is not None else "")
               + (f" (objective: {effective})" if not edge else ""))
    target = ctx.get("target") or ("COM above the support edge (tilt about the hinge)" if edge else
                                  ("balance attitude (COM above the pivot) at the commanded heading" if crit["yaw_objective"] == "hold"
                                   else "balance attitude (COM above the pivot), any heading"))
    sustained = bool(recovered and held and not fell_after)
    return {"criteria": crit, "target": target, "objective": declared, "objective_effective": effective, "objective_note": note,
            "recovered": bool(recovered), "t_s": t_rec if recovered else None, "first_entry_s": t_rec, "first_recovery_s": t_rec if recovered else None,
            "within_max_time": (t_rec is not None and t_rec <= t_max + 1e-12), "max_time_s": t_max,
            "held_to_end": held, "sustained": sustained, "sustained_from_s": sustained_from,
            "exits_after_recovery": exits, "last_exit_s": last_exit, "fell_after": bool(fell_after), "fell_after_recovery": bool(fell_after and recovered),
            "summary": summary}


def research_metrics(full, ctx, timeline=None) -> dict:
    n, dt = full["nSteps"], ctx["dt"]
    edge = ctx["mode"] == "edge"
    wn = ctx["wheel_names"]
    rec = recovery(full, ctx)
    out = {"metrics_version": METRICS_VERSION, "recovery": rec}
    out["attitude_error"] = angle_stats(full["e"] if edge else full["att"], n, dt)
    out["lean"] = angle_stats(full["e"], n, dt)
    r = time_stats(full["rate"], n, dt)
    out["body_rate"] = {"rms": r["rms"] / DEG, "peak": r["peak"] / DEG}
    out["wheel_speed"] = {"peak_rpm": {wn[i]: max(abs(x) for x in full["om"][i][: n + 1]) / RPM for i in range(len(wn))}}
    ns = max(1, n)   # per-step quantities exist for k = 0 … n−1
    out["torque"] = {"peak_requested_Nm": {wn[i]: max(abs(x) for x in full["Treq"][i][:ns]) for i in range(len(wn))},
                     "peak_applied_Nm": {wn[i]: max(abs(x) for x in full["Tapp"][i][:ns]) for i in range(len(wn))}}
    out["authority"] = _authority(full, ctx, n, dt)
    out["effort_Nms"] = full["effort"]
    out["energy_model_J"] = full["E"]
    out["saturation_s"] = {"any": sum(full["sat"][i] for i in range(n)) * dt, "per_wheel": {wn[i]: sum(full["satW"][i][k] for k in range(n)) * dt for i in range(len(wn))}}
    wmax = ctx["wmax_list"]
    lim = [ASSESS["satSpeedFrac"] * w for w in wmax]
    per = {}
    for i in range(len(wn)):
        per[wn[i]] = sum(1 for k in range(n) if abs(full["om"][i][k]) >= lim[i]) * dt
    out["speed_limited_s"] = {"per_wheel": per}
    if full.get("estAtt") is not None:
        ss = sum(full["estAtt"][k] ** 2 for k in range(n)) / max(1, n)
        st = sum(full["estTilt"][k] ** 2 for k in range(n)) / max(1, n)
        be = full["biasErr"]
        out["estimator"] = {"attitude_rmse_deg": math.sqrt(ss) / DEG, "tilt_rmse_deg": math.sqrt(st) / DEG,
                            "attitude_error_final_deg": full["estAtt"][n - 1] / DEG if n else None,
                            "bias_error_final_dps": be[n - 1] / DEG if n else None,
                            "bias_error_rms_dps": math.sqrt(sum(be[k] ** 2 for k in range(n)) / max(1, n)) / DEG,
                            "note": "Tilt (the gravity-observable part) is reported separately: with gravity-only correction the heading is unobservable, so the full attitude error includes the heading drift."}
        out["estimator"].update(_age_stats(full, n, dt))
    elif full.get("estErr") is not None:
        ss = sum(full["estErr"][k] ** 2 for k in range(n)) / max(1, n)
        out["estimator"] = {"attitude_rmse_deg": math.sqrt(ss) / DEG, "bias_error_final_dps": ctx.get("edge_bias_err_final_dps"),
                            "bias_error_rms_dps": None}
        out["estimator"].update(_age_stats(full, n, dt))
    else:
        out["estimator"] = None
    fall = ASSESS["fallEdgeDeg"] if edge else ASSESS["fallCornerDeg"]
    out["final"] = {"attitude_error_deg": out["attitude_error"]["final"], "lean_deg": out["lean"]["final"],
                    "lean_margin_deg": (fall - out["lean"]["peak"]) if ctx.get("fellAt") is None else None,
                    "wheel_speed_margin_frac": min(1 - abs(full["om"][i][n]) / wmax[i] for i in range(len(wn)))}
    out["termination"] = ctx["termination"]
    if timeline is not None:
        counts = {}
        for e in timeline["events"]:
            counts[e["type"]] = counts.get(e["type"], 0) + 1
        out["event_counts"] = counts
    out["resolution_s"] = dt
    out["units"] = UNITS
    return out


def _age_stats(full, n, dt):
    """Timing of the controller-facing estimate over the steps k = 0 … n−1 (one weight per step):
    the age of the newest observation behind it, the time before the first observation
    (uninitialised) and the time it was flagged stale (age > estimator.stale_after_s)."""
    age = full.get("estAge")
    if age is None or n <= 0:
        return {}
    stale = full.get("estStale")
    vals = [age[k] for k in range(n) if age[k] == age[k]]
    uninit = (n - len(vals)) * dt
    stale_s = (sum(stale[k] for k in range(n)) * dt) if stale is not None else 0.0
    return {"age_mean_s": (sum(vals) / len(vals)) if vals else None, "age_max_s": max(vals) if vals else None,
            "uninitialised_s": uninit, "stale_s": stale_s, "invalid_s": uninit + stale_s}

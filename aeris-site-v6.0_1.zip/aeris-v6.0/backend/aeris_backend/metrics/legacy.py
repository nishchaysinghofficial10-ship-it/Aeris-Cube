"""Legacy assessment and event timeline: a line-by-line port of AERIS_TWIN.assess and
AERIS_TWIN.buildTimeline (site/js/core.js), so backend runs carry the same outcome codes,
metric names and meanings as browser runs. The legacy 'Recovered' outcome is COM-lean recovery
(|e| within ±0.25° held to the end of the window, no drift); it can coexist with yaw rotation.
The research recovery criteria are separate (metrics/research.py)."""
from __future__ import annotations

import math

from ..constants import ASSESS, DEG, EVENT_RULES, OUTCOMES, RPM


def linfit(ts, ys):
    n = len(ts)
    if n < 3:
        return {"slope": 0.0, "r2": 0.0}
    mt = sum(ts) / n
    my = sum(ys) / n
    sxy = sxx = syy = 0.0
    for i in range(n):
        a, b = ts[i] - mt, ys[i] - my
        sxy += a * b
        sxx += a * a
        syy += b * b
    slope = sxy / sxx if sxx > 0 else 0.0
    r2 = (sxy * sxy) / (sxx * syy) if sxx > 0 and syy > 0 else 0.0
    return {"slope": slope, "r2": r2}


def settle_time(vals, dt, n, tol, hold):
    last = -1
    for i in range(n + 1):
        if abs(vals(i)) > tol:
            last = i
    t_start = 0.0 if last < 0 else (last + 1) * dt
    t_end = n * dt
    if last >= n:
        return None
    if t_end - t_start + 1e-12 < hold:
        return None
    return t_start


def assess(full: dict, ctx: dict) -> dict:
    n = full["nSteps"]
    dt = ctx["dt"]
    t_end = n * dt
    e = full["e"]
    wheel_names = ctx["wheel_names"]
    active = ctx["active"]
    tol = ASSESS["settleTolDeg"] * DEG
    hold = ASSESS["holdMinS"]
    wtol = ASSESS["momentumTolRpm"] * RPM
    m = {"window_s": ctx.get("window_s", t_end), "recorded_s": t_end, "e0_deg": e[0] / DEG}
    peak = peakT = os_ = 0.0
    sgn = 1 if e[0] >= 0 else -1
    edge = ctx["mode"] == "edge"
    for i in range(n + 1):
        ae = abs(e[i])
        if ae > peak:
            peak, peakT = ae, i * dt
        if edge:
            ov = -sgn * e[i]
            if ov > os_:
                os_ = ov
    m["peakLean_deg"] = peak / DEG
    m["peakLean_t"] = peakT
    m["overshoot_deg"] = os_ / DEG if edge and abs(e[0]) > tol else None
    fell = ctx["fellAt"]
    m["settle_s"] = settle_time(lambda k: e[k], dt, n, tol, hold) if fell is None else None
    om = full["om"]

    def maxw(k):
        mx = 0.0
        for a in active:
            v = abs(om[a][k])
            if v > mx:
                mx = v
        return mx
    m["tOmega_s"] = settle_time(maxw, dt, n, wtol, hold) if fell is None else None
    fw = min(ASSESS["finalWindowMaxS"], ASSESS["finalWindowFrac"] * t_end)
    k0 = max(0, js_round((t_end - fw) / dt))
    s = c = 0
    for i in range(k0, n + 1):
        s += abs(e[i])
        c += 1
    m["finalLean_deg"] = s / c / DEG if c else None
    m["finalWindow_s"] = fw
    pk = 0.0
    pk_wheel = None
    pk_t = 0.0
    for j in range(len(om)):
        for i in range(n + 1):
            aw = abs(om[j][i])
            if aw > pk:
                pk, pk_wheel, pk_t = aw, wheel_names[j], i * dt
    wmax = ctx["wmax"]
    m["peakOmega_rpm"] = pk / RPM
    m["peakOmega_wheel"] = pk_wheel
    m["peakOmega_t"] = pk_t
    m["peakOmega_frac"] = pk / wmax
    m["finalOmega_rpm"] = {wheel_names[j]: om[j][n] / RPM for j in range(len(om))}
    satN = sum(full["sat"][i] for i in range(n))
    m["torqueLimited_s"] = satN * dt
    reached = pk >= ASSESS["satSpeedFrac"] * wmax
    m["wheelAtLimit"] = reached
    m["energy_J"] = full["E"]
    m["fellAt_s"] = fell
    m["contactAt_s"] = ctx["contactAt"]
    ss = 0.0
    for i in range(n + 1):
        ss += e[i] * e[i]
    m["rmsLean_deg"] = math.sqrt(ss / (n + 1)) / DEG
    m["effort_Nms"] = full["effort"]
    spN = 0
    sp_lim = ASSESS["satSpeedFrac"] * wmax
    for i in range(n):
        for a in active:
            if abs(om[a][i]) >= sp_lim:
                spN += 1
                break
    m["speedLimited_s"] = spN * dt
    m["leanMargin_deg"] = ((ASSESS["fallEdgeDeg"] if edge else ASSESS["fallCornerDeg"]) - m["peakLean_deg"]) if fell is None else None
    m["omegaMargin_frac"] = 1 - m["peakOmega_frac"]
    dw = max(ASSESS["driftWindowMinS"], min(ASSESS["driftWindowMaxS"], ASSESS["driftWindowFrac"] * t_end))
    d0 = max(0, js_round((t_end - dw) / dt))

    def trend(getter):
        ts = [k * dt for k in range(d0, n + 1)]
        ys = [getter(k) for k in range(d0, n + 1)]
        h = len(ts) // 2
        al = linfit(ts, ys)
        a = linfit(ts[:h], ys[:h])
        b = linfit(ts[h:], ys[h:])
        return {"slope": al["slope"], "r2": al["r2"], "s1": a["slope"], "s2": b["slope"], "end": ys[-1]}
    drift = None
    if fell is None and t_end >= 2 * ASSESS["driftWindowMinS"]:
        for a in active:
            tr = trend(lambda k, a=a: abs(om[a][k]))
            steady = tr["s1"] > 0 and tr["s2"] >= ASSESS["driftPersist"] * tr["s1"]
            if tr["slope"] >= ASSESS["driftWheelSlopeFrac"] * wmax and tr["r2"] >= ASSESS["driftR2"] and steady and tr["end"] > wtol:
                proj = t_end + (wmax - tr["end"]) / tr["slope"]
                if drift is None or proj < drift["projected_s"]:
                    drift = {"kind": "wheel", "wheel": wheel_names[a], "slope_rpm_s": tr["slope"] / RPM, "r2": tr["r2"], "end_rpm": tr["end"] / RPM, "projected_s": proj}
        if drift is None:
            tl = trend(lambda k: abs(e[k]))
            steadyL = tl["s1"] > 0 and tl["s2"] >= ASSESS["driftPersist"] * tl["s1"]
            if tl["slope"] >= ASSESS["driftLeanSlopeDps"] * DEG and tl["r2"] >= ASSESS["driftR2"] and steadyL and tl["end"] > tol:
                drift = {"kind": "lean", "slope_dps": tl["slope"] / DEG, "r2": tl["r2"], "end_deg": tl["end"] / DEG}
    m["drift"] = drift
    m["driftWindow_s"] = dw
    if not edge and full.get("psi") is not None:
        ty = [i * dt for i in range(d0, n + 1)]
        yy = [full["psi"][i] for i in range(d0, n + 1)]
        m["yawFinal_deg"] = full["psi"][n] / DEG
        m["yawErrFinal_deg"] = (full["psi"][n] - full["psiRef"][n]) / DEG
        m["yawRate_dps"] = linfit(ty, yy)["slope"] / DEG
    else:
        m["yawFinal_deg"] = m["yawErrFinal_deg"] = m["yawRate_dps"] = None
    endW, endV = None, 0.0
    for a in active:
        v = abs(om[a][n])
        if v >= endV:
            endV, endW = v, wheel_names[a]
    m["endOmega_rpm"] = endV / RPM
    m["endOmega_wheel"] = endW
    m["endOmega_frac"] = endV / wmax
    notes = []
    failed_wheels = ctx.get("failedWheels") or []
    if failed_wheels:
        notes.append("Wheel " + ", ".join(w.upper() for w in failed_wheels) + " failed during the run.")
    fall_deg = ASSESS["fallEdgeDeg"] if edge else ASSESS["fallCornerDeg"]
    if fell is not None:
        code = "fallen"
        cause = ctx.get("fallCause")
        if cause == "contact":
            reason = f"The cube touched the floor at t = {fell:.2f} s"
        elif cause == "lift_off":
            reason = f"The pivot lost contact (lift-off: the support would have had to pull the cube down) at t = {fell:.2f} s"
        else:
            reason = f"COM lean passed the {fall_deg:g}° fall threshold at t = {fell:.2f} s"
        reason += (f" after a wheel reached {js_round(m['peakOmega_frac'] * 100)} % of its speed limit" if reached else "") + "."
    elif drift is not None:
        code = "drifting"
        if drift["kind"] == "wheel":
            reason = (f"Wheel {drift['wheel'].upper()} speed is still rising steadily at {js_round(drift['slope_rpm_s'])} rpm/s at the end of the window "
                      f"({js_round(drift['end_rpm'])} rpm); at that rate it reaches its {js_round(wmax / RPM)} rpm limit at about t = {drift['projected_s']:.1f} s."
                      + (f" The COM lean is also outside ±{ASSESS['settleTolDeg']:g}°." if m["settle_s"] is None else ""))
        else:
            reason = f"The COM lean is still growing at {drift['slope_dps']:.2f} °/s at the end of the window (|e| = {drift['end_deg']:.2f}°)."
    elif m["settle_s"] is not None:
        code = "recovered"
        reason = (f"|e| stayed within ±{ASSESS['settleTolDeg']:g}° from t = {m['settle_s']:.2f} s to the end of the window "
                  f"({t_end - m['settle_s']:.2f} s ≥ {ASSESS['holdMinS']:g} s), and no wheel is trending toward its limit.")
        if m["tOmega_s"] is None and endW:
            notes.append(f"Wheel momentum has not returned to within ±{ASSESS['momentumTolRpm']:g} rpm: wheel {endW.upper()} ends at {js_round(m['endOmega_rpm'])} rpm "
                         f"({js_round(m['endOmega_frac'] * 100)} % of its limit)" + (", leaving little margin for another disturbance in the same direction." if m["endOmega_frac"] > 0.8 else "."))
    else:
        code = "not_settled"
        reason = (f"The run did not fall and nothing is drifting, but |e| was not within ±{ASSESS['settleTolDeg']:g}° for the final {ASSESS['holdMinS']:g} s "
                  f"(final-window mean {(m['finalLean_deg'] or 0):.2f}°). A longer window may show whether it settles.")
    if code != "fallen" and not edge and m["yawFinal_deg"] is not None:
        turning = abs(m["yawRate_dps"]) > 1
        if failed_wheels and (turning or abs(m["yawFinal_deg"]) > 5):
            notes.append(f"Yaw is not controlled after a wheel failure (balance has priority): it ended at {m['yawFinal_deg']:.0f}°"
                         + (f", still turning at {m['yawRate_dps']:.1f} °/s." if turning else "."))
        elif turning:
            notes.append(f"Yaw is still turning at {m['yawRate_dps']:.1f} °/s at the end of the window.")
        elif ctx.get("hasYawCmd") and abs(m["yawErrFinal_deg"]) > 2:
            notes.append(f"Yaw ends {m['yawErrFinal_deg']:.1f}° from the commanded heading.")
    return {"metrics": m, "outcome": {"code": code, "label": OUTCOMES[code]["label"], "tone": OUTCOMES[code]["tone"], "reason": reason, "notes": notes}}


def js_round(x: float) -> int:
    """JavaScript Math.round."""
    return int(math.floor(x + 0.5))


# ---------------------------------------------------------------------------------------
# Event timeline (AERIS_TWIN.buildTimeline), extended with the research event types
# ---------------------------------------------------------------------------------------
def intervals_of(flag_at, n, t_at, gap):
    raw = []
    on = False
    t0 = 0.0
    for i in range(n + 1):
        f = bool(flag_at(i))
        if f and not on:
            on, t0 = True, t_at(i)
        elif not f and on:
            on = False
            raw.append({"t0": t0, "t1": t_at(i), "open": False})
    if on:
        raw.append({"t0": t0, "t1": t_at(n), "open": True})
    out = []
    for iv in raw:
        if out and iv["t0"] - out[-1]["t1"] < gap:
            out[-1]["t1"] = iv["t1"]
            out[-1]["open"] = iv["open"]
        else:
            out.append(iv)
    return out


def r4(x):
    return js_round(x * 1e4) / 1e4


def build_timeline(x: dict) -> dict:
    ev = []
    cfg = x["cfg"]
    edge = x["mode"] == "edge"
    R = EVENT_RULES
    n = x["n"]
    t_at = x["tAt"]
    wn = x["wheel_names"]
    fail_t = [None] * len(wn)
    for e in cfg.get("events") or []:
        if e["type"] != "wheel_failure":
            continue
        w = wn.index(e["wheel"]) if e["wheel"] in wn else -1
        if w >= 0 and (not edge or w == x.get("drive", 0)) and (fail_t[w] is None or e["t_s"] < fail_t[w]):
            fail_t[w] = e["t_s"]

    def push(o):
        o["t"] = r4(o["t"])
        if o.get("t_end") is not None:
            o["t_end"] = r4(o["t_end"])
        ev.append(o)

    def capped(lst, kind, mk):
        if len(lst) <= R["maxPerKind"]:
            for iv in lst:
                mk(iv)
            return
        for iv in lst[:R["maxPerKind"] - 1]:
            mk(iv)
        rest = lst[R["maxPerKind"] - 1:]
        tot = sum(iv["t1"] - iv["t0"] for iv in rest)
        noun = {"saturation": "saturation", "estimate_stale": "stale-estimate"}.get(kind, "speed-limit")
        push({"t": rest[0]["t0"], "t_end": rest[-1]["t1"], "type": kind, "severity": "warning", "source": "detected",
              "label": f"… {len(rest)} more {noun} intervals",
              "detail": f"Combined {tot:.2f} s; listed individually up to {R['maxPerKind'] - 1}."})
    we = x["windowEnd"]
    for L in cfg.get("disturbances") or []:
        if L["type"] in ("impulse", "force_impulse"):
            if L["t_s"] < we:
                push({"t": L["t_s"], "type": "impulse", "severity": "info", "source": "input", "ref": L["id"],
                      "label": ("Impulse " if L["type"] == "impulse" else "Force impulse ") + L["id"] + " applied",
                      "detail": (f"{L['magnitude_Nms']} N·m·s" if L["type"] == "impulse" else f"{L['impulse_Ns']} N·s at ({', '.join(str(js_round(v * 1000)) for v in L['point_m'])}) mm")
                      + f", {L['frame']} frame, applied as an instantaneous momentum change."})
            continue
        if not L["t_start_s"] < we:
            continue
        dur = L.get("duration_s")
        t_end = we if dur is None else min(we, L["t_start_s"] + dur)
        if L["type"] == "force":
            det = f"{L['magnitude_N']} N at ({', '.join(str(js_round(v * 1000)) for v in L['point_m'])}) mm"
        else:
            det = f"{L['magnitude_Nm']} N·m"
        push({"t": L["t_start_s"], "t_end": t_end, "type": "disturbance", "severity": "info", "source": "input", "ref": L["id"],
              "label": ("Force " if L["type"] == "force" else "Torque bias " if L["type"] == "bias" else "Torque ") + L["id"] + " applied",
              "detail": det + f", {L['frame']} frame, " + ("until the end of the run." if dur is None else f"for {dur} s.")})
    for e in cfg.get("events") or []:
        if not e["t_s"] < we:
            continue
        idx = wn.index(e["wheel"]) if e["wheel"] in wn else -1
        used = (not edge) or idx == x.get("drive", 0)
        label_w = str(e["wheel"]).upper()
        if e["type"] == "wheel_failure":
            push({"t": e["t_s"], "type": "wheel_failure", "severity": "failure" if used else "info", "source": "input", "wheel": e["wheel"], "ref": e["id"],
                  "label": f"Wheel {label_w} failed", "detail": "No motor torque from this wheel from now on." if used and e.get("duration_s") is None
                  else (f"No motor torque from this wheel for {e['duration_s']} s." if used else "Edge mode does not drive this wheel, so the failure has no effect.")})
            if used and not edge and cfg["controller"].get("reconfigureOnFailure"):
                push({"t": e["t_s"], "type": "controller_mode", "severity": "warning", "source": "detected", "label": "Controller reconfigured",
                      "detail": x.get("reconfig_detail") or "Torque reallocated to the healthy wheels (least squares); yaw control given up."})
            if e.get("duration_s") is not None and e["t_s"] + e["duration_s"] < we:
                push({"t": e["t_s"] + e["duration_s"], "type": "wheel_clearance", "severity": "info", "source": "input", "wheel": e["wheel"], "ref": e["id"],
                      "label": f"Wheel {label_w} fault cleared", "detail": "Motor torque available again."})
        else:
            what = {"wheel_degradation": f"health × {e.get('health')}", "wheel_torque_limit": f"torque limited to {e.get('limit_Nm')} N·m",
                    "wheel_speed_limit": f"speed limited to {e.get('limit_rpm')} rpm"}[e["type"]]
            dur = e.get("duration_s")
            push({"t": e["t_s"], "t_end": None if dur is None else min(we, e["t_s"] + dur), "type": e["type"], "severity": "warning", "source": "input",
                  "wheel": e["wheel"], "ref": e["id"], "label": f"Wheel {label_w}: {what}", "detail": ("Until the end of the run." if dur is None else f"For {dur} s.")})
    for c in cfg.get("commands") or []:
        if c["type"] == "yaw_step" and c["t_s"] < we:
            push({"t": c["t_s"], "type": "yaw_command", "severity": "info", "source": "input", "ref": c["id"], "label": f"Yaw command {c['angle_deg']:g}°",
                  "detail": "Commanded heading about the balance axis."})
    for y in x.get("yaw_objective_changes") or []:
        push({"t": y["t"], "type": "yaw_objective", "severity": "warning", "source": "detected", "label": "Yaw objective relinquished",
              "detail": "From here the research recovery criteria apply to tilt only: " + y["reason"] + "."})
    satW = x.get("satW") or []
    for w in range(len(satW)):
        arr = satW[w]
        fw = fail_t[w]
        if edge and w != x.get("drive", 0):
            continue
        ivs = intervals_of(lambda i, arr=arr, fw=fw: arr[i] and (fw is None or t_at(i) < fw), n, t_at, R["mergeGapS"])
        wl = "Wheel " + wn[w].upper() + " "
        capped(ivs, "saturation", lambda iv, w=w, wl=wl: push({"t": iv["t0"], "t_end": iv["t1"], "type": "saturation", "severity": "warning", "source": "detected",
                                                               "wheel": wn[w], "label": wl + "torque saturated",
                                                               "detail": "Commanded torque above what the driver can deliver" + ("; still saturated at the end of the recording." if iv["open"] else ".") + f" Duration {iv['t1'] - iv['t0']:.3f} s."}))
    wmax = x["wmax"]
    for wi, om in enumerate(x.get("om") or []):
        if edge and wi != x.get("drive", 0):
            continue
        wmx = wmax[wi] if isinstance(wmax, (list, tuple)) else wmax
        risk = intervals_of(lambda i, om=om: abs(om[i]) >= R["speedRiskFrac"] * wmx, n, t_at, R["mergeGapS"])
        capped(risk, "speed_risk", lambda iv, wi=wi: push({"t": iv["t0"], "t_end": iv["t1"], "type": "speed_risk", "severity": "warning", "source": "detected", "wheel": wn[wi],
                                                           "label": f"Wheel {wn[wi].upper()} saturation risk",
                                                           "detail": f"Speed at or above {js_round(R['speedRiskFrac'] * 100)} % of the {js_round(wmx / RPM)} rpm limit for {iv['t1'] - iv['t0']:.2f} s."}))
        lim = intervals_of(lambda i, om=om: abs(om[i]) >= R["speedLimitFrac"] * wmx, n, t_at, R["mergeGapS"])
        capped(lim, "speed_limit", lambda iv, wi=wi: push({"t": iv["t0"], "t_end": iv["t1"], "type": "speed_limit", "severity": "warning", "source": "detected", "wheel": wn[wi],
                                                           "label": f"Wheel {wn[wi].upper()} at its speed limit",
                                                           "detail": f"Speed at or above {js_round(R['speedLimitFrac'] * 100)} % of the limit for {iv['t1'] - iv['t0']:.2f} s."}))
    est_err = x.get("estErr")
    if est_err is not None:
        tol = R["estErrDeg"] * DEG
        first = since = None
        for i in range(n + 1):
            if abs(est_err[i]) > tol:
                if since is None:
                    since = t_at(i)
                if t_at(i) - since >= R["estErrHoldS"]:
                    first = since
                    break
            else:
                since = None
        if first is not None:
            push({"t": first, "type": "estimator_warning", "severity": "warning", "source": "detected", "label": "Estimator warning",
                  "detail": f"Estimated attitude more than {R['estErrDeg']:g}° from the true attitude for at least {R['estErrHoldS']:g} s (first occurrence)."})
    # estimate timing (research engine, docs/ESTIMATION_TIMING.md): initialisation and stale intervals
    ei = x.get("est_init_t")
    if ei is not None and ei > 0:
        push({"t": ei, "type": "estimator_init", "severity": "info", "source": "detected", "label": "Estimator initialised",
              "detail": "First IMU sample delivered and processed (tilt from its accelerometer, heading from the nominal attitude); before it the controller received the nominal attitude with zero rate, flagged invalid."})
    est_stale = x.get("estStale")
    if est_stale is not None and x.get("stale_after_s") is not None:
        lim_ms = x["stale_after_s"] * 1000
        ivs = intervals_of(lambda i: i < n and est_stale[i], n, t_at, 0.0)
        capped(ivs, "estimate_stale", lambda iv: push({"t": iv["t0"], "t_end": iv["t1"], "type": "estimate_stale", "severity": "warning", "source": "detected",
                                                     "label": "Estimate stale",
                                                     "detail": f"No new sensor sample for longer than the {lim_ms:.3g} ms age limit (estimator.stale_after_s); the controller acted on the prediction from the last update, flagged invalid. Duration {iv['t1'] - iv['t0']:.3f} s."}))
    M = x.get("metrics") or {}
    if M.get("settle_s") is not None:
        push({"t": M["settle_s"], "type": "recovered", "severity": "stable", "source": "detected", "label": "Stability recovered",
              "detail": f"|e| within ±{ASSESS['settleTolDeg']:g}° from here to the end of the window."})
    rr = x.get("research_recovery")
    if rr and rr.get("recovered"):
        push({"t": rr["t_s"], "type": "research_recovery", "severity": "stable", "source": "detected", "label": "Research recovery criteria met",
              "detail": rr["summary"]})
    fell = x.get("fellAt")
    if fell is not None:
        cause = x.get("fallCause")
        push({"t": fell, "type": "fall", "severity": "failure", "source": "detected",
              "label": "Fall: floor contact" if cause == "contact" else "Loss of support: lift-off" if cause == "lift_off" else "Fall: lean threshold passed",
              "detail": "Part of the cube reached the floor; motors stop." if cause == "contact" else "The pivot would have had to pull the cube down; the fixed-pivot model ends here." if cause == "lift_off"
              else f"COM lean passed {ASSESS['fallEdgeDeg'] if edge else ASSESS['fallCornerDeg']:g}°; motors stop."})
    if x.get("contactAt") is not None and x.get("contactAt") != fell:
        push({"t": x["contactAt"], "type": "floor_contact", "severity": "failure", "source": "detected", "label": "Floor contact", "detail": "Part of the cube reached the floor."})
    term = x.get("termination") or {}
    push({"t": x["recordedEnd"], "type": "termination", "severity": "info", "source": "detected",
          "label": "Recording stopped after the fall" if fell is not None else ("Run stopped: " + term.get("reason", "")) if term.get("reason") not in (None, "duration") else "End of observation window",
          "detail": ("Recorded until floor contact or " + f"{x.get('post_fall_s', 1.5):g} s after the fall.") if fell is not None else (term.get("detail") or f"Window {x['windowEnd']:g} s.")})
    order = {"input": 0, "detected": 1}
    ev.sort(key=lambda a: (a["t"], order[a["source"]]))
    return {"rules": EVENT_RULES, "resolution_s": x["resolution_s"], "events": ev}

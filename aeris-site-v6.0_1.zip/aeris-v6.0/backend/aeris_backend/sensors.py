"""Sensor models. They read the TRUE state (that is what a sensor does) and produce time-stamped
observations; estimators and controllers only ever see these observations (plus wheel encoders).

Two IMU models exist:

EdgeImuLegacy   the browser engine's edge-mode sensor, reproduced draw for draw (same RNG stream
                and order): one gyro axis about the hinge and an accelerometer tilt angle
                    ω_m = θ̇ + b + σ_g n,   b ← b + σ_bw √Δt n,
                    a_m = θ − r_IMU θ̈/g + σ_a n    (small-angle tilt from the accelerometer,
                                                    θ̈ = the previous step's angular acceleration)
                then angle/rate quantisation, a latency of round(latency·f_s) samples and packet
                dropout (a dropped packet repeats the previous one). Sampled at the control rate.

Imu3D           a three-axis IMU for the research estimators, sampled at sensor.rate_hz:
                    gyro  = ω + b + σ_g n                       (per axis; b walks with σ_bw √Δt)
                    accel = a_IMU − g  in body axes (specific force) + bias + σ_a n
                    a_IMU = ω̇ × r + ω × (ω × r)                 (pivot fixed; r = IMU position)
                with sensor.accel_dynamic = false the accelerometer measures gravity only (a
                documented approximation). Quantisation: gyro step in °/s; accelerometer step
                g·(accel_quant_deg in rad) m/s². Latency delays delivery (the sample keeps its
                measurement time stamp); dropout loses the sample (the estimator coasts).
"""
from __future__ import annotations

import math
from collections import deque

from .constants import CH, DEG, SENSOR_DEFAULTS
from .physics.quaternion import add, cross, up_in_body
from .rng import Rng


class EdgeImuLegacy:
    def __init__(self, cfg: dict, dt_ctrl: float, rng: Rng):
        S = cfg["sensor"]
        p = cfg["params"]
        self.rng = rng
        self.dt = dt_ctrl
        self.sg = S["gyro_noise_dps"] * DEG
        self.sbw = S["gyro_bias_walk_dps"] * DEG
        self.sa = S["accel_noise_mps2"] / 9.81
        self.qG = S["gyro_quant_dps"] * DEG
        self.qA = S["accel_quant_deg"] * DEG
        self.lagK = int(round(S["latency_ms"] / 1000.0 * p["fs"]))
        self.pDrop = S["dropout"]
        self.b = S["gyro_bias_dps"] * DEG
        self.rImu = p["rImu"]
        self.g = p["g"]
        self.buf = deque()
        self.lastM = None
        self.true_bias = self.b
        self.t_meas = None
        self.repeated = 0

    def sample(self, th: float, thd: float, thdd_prev: float, t: float | None = None) -> tuple[float, float]:
        """One packet at control time t. The random draws and their order are the browser's; the
        measurement time of the packet actually returned is kept in t_meas (a delayed packet keeps
        its own time; a dropped packet repeats the previous one, time stamp included)."""
        N = self.rng
        self.b += self.sbw * math.sqrt(self.dt) * N.n()
        self.true_bias = self.b
        wm = thd + self.b + self.sg * N.n()
        am = th - self.rImu * thdd_prev / self.g + self.sa * N.n()
        if self.qG > 0:
            wm = round_half_up(wm / self.qG) * self.qG
        if self.qA > 0:
            am = round_half_up(am / self.qA) * self.qA
        tm = t
        if self.lagK > 0:
            self.buf.append((wm, am, t))
            if len(self.buf) > self.lagK + 1:
                self.buf.popleft()
            wm, am, tm = self.buf[0]
        if self.pDrop > 0:
            if self.lastM is not None and N.u() < self.pDrop:
                wm, am, tm = self.lastM
                self.repeated += 1
            self.lastM = (wm, am, tm)
        self.t_meas = tm
        return wm, am


def round_half_up(x: float) -> float:
    """JavaScript Math.round (halves round toward +∞)."""
    return math.floor(x + 0.5)


class ImuSample:
    __slots__ = ("t", "gyro", "accel")

    def __init__(self, t, gyro, accel):
        self.t = t
        self.gyro = gyro
        self.accel = accel


class Imu3D:
    def __init__(self, cfg: dict, rng: Rng, period: float):
        S = cfg["sensor"]
        p = cfg["params"]
        self.rng = rng
        self.period = period
        self.sg = S["gyro_noise_dps"] * DEG
        self.sbw = S["gyro_bias_walk_dps"] * DEG
        self.sa = S["accel_noise_mps2"]
        self.qG = S["gyro_quant_dps"] * DEG
        self.qA = S["accel_quant_deg"] * DEG * p["g"]
        self.latency = S["latency_ms"] / 1000.0
        self.pDrop = S["dropout"]
        b0 = S["gyro_bias_dps"] * DEG
        self.b = [b0, b0, b0]
        self.abias = list(S.get("accel_bias_mps2") or [0.0, 0.0, 0.0])
        pos = S.get("imu_position_m")
        from .constants import D_EDGE
        base = D_EDGE if cfg["mode"] == "edge" else CH
        self.r = tuple(pos) if pos is not None else tuple(c * p["rImu"] for c in base)
        self.dynamic = S.get("accel_dynamic", True)
        self.g = p["g"]
        self.pending = deque()
        self.delivered = 0
        self.dropped = 0

    def measure(self, t, q, w, wd) -> None:
        """Take a sample of the true state at time t (queued for delivery after the latency)."""
        N = self.rng
        sq = math.sqrt(self.period)
        for i in range(3):
            self.b[i] += self.sbw * sq * N.n()
        gyro = [w[i] + self.b[i] + self.sg * N.n() for i in range(3)]
        up = up_in_body(q)
        f = [self.g * up[0], self.g * up[1], self.g * up[2]]
        if self.dynamic:
            a = add(cross(wd, self.r), cross(w, cross(w, self.r)))
            f = [f[i] + a[i] for i in range(3)]
        accel = [f[i] + self.abias[i] + self.sa * N.n() for i in range(3)]
        if self.qG > 0:
            gyro = [round_half_up(x / self.qG) * self.qG for x in gyro]
        if self.qA > 0:
            accel = [round_half_up(x / self.qA) * self.qA for x in accel]
        if self.pDrop > 0 and N.u() < self.pDrop:
            self.dropped += 1
            return
        self.pending.append(ImuSample(t, tuple(gyro), tuple(accel)))

    def deliver(self, t_now: float) -> list:
        """Samples whose measurement time + latency has passed (in time-stamp order)."""
        out = []
        while self.pending and self.pending[0].t + self.latency <= t_now + 1e-12:
            out.append(self.pending.popleft())
        self.delivered += len(out)
        return out


def nominal_sensor_for(cfg: dict) -> dict:
    """Noise levels the 3-D estimators assume when their own settings are None: the configured
    sensor (a matched filter). Set estimator.mekf.* to study a mismatched filter."""
    S = cfg["sensor"]
    return {k: S.get(k, SENSOR_DEFAULTS.get(k)) for k in ("gyro_noise_dps", "gyro_bias_walk_dps", "accel_noise_mps2")}

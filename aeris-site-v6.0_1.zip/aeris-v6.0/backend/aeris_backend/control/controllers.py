"""Controllers. One interface: a controller reads the Estimate, the wheel-encoder speeds and the
reference, and returns requested torques. It never reads or changes the plant state.

    request(t, est, wheel_speeds, ctx) → Request(per_wheel | body_vector, info)
    after(sat, failed_any, wheel_speeds, dt)   (adaptation / anti-windup bookkeeping)

Sign convention: a request is the motor torque on the wheels (T_i on wheel i; body vector
u = Σ T_i a_i). The body receives −u.

Laws
  edge  pid | lqr | adp   the browser's single-axis laws (AERIS_TWIN.simEdge), e = θ̂ + β_ref
  corner pid | lqr | adp  the browser's decoupled laws: one tilt design on the averaged
                          perpendicular inertia acting on each tilt axis, plus a yaw loop about
                          the balance axis (AERIS_TWIN.simCorner)
  corner lqr + structure 'mimo-lqr'   coupled MIMO LQR on the full inertia tensor (design.py)
  edge/corner nlpd        nonlinear model-compensated quaternion PD (docs/CONTROLLERS.md §5)
"""
from __future__ import annotations

import math

import numpy as np

from ..constants import CH, DEG
from ..physics.quaternion import (axis_angle, cross, dot, from_to, log_vec, mtv, mv, proj_on, qconj, qmul,
                                  up_in_body)
from .design import DesignError, design_mimo_cached


class YawTracker:
    """Unwrapped heading about the balance axis u_ref (AERIS_TWIN.simCorner sense())."""

    def __init__(self, q_ref, u_ref):
        self.qRefC = qconj(q_ref)
        self.u = u_ref
        self.prev = 0.0
        self.turns = 0.0

    def psi(self, q):
        qe = qmul(self.qRefC, q)
        p = 2 * math.atan2(qe[1] * self.u[0] + qe[2] * self.u[1] + qe[3] * self.u[2], qe[0])
        d = p - self.prev
        if d > math.pi:
            self.turns -= 2 * math.pi
        elif d < -math.pi:
            self.turns += 2 * math.pi
        self.prev = p
        return p + self.turns


class Request:
    __slots__ = ("per_wheel", "body", "bh", "info", "yaw_given_up")

    def __init__(self, per_wheel=None, body=None, bh=None, info=None, yaw_given_up=False):
        self.per_wheel = per_wheel
        self.body = body
        self.bh = bh
        self.info = info
        self.yaw_given_up = yaw_given_up


class Controller:
    type = "none"
    structure = "none"      # 'decoupled' (browser per-axis laws), 'mimo-lqr', 'nonlinear-full-tensor' or 'none'
    law = "no control (motors off)"

    def __init__(self, ctx):
        self.ctx = ctx
        self.fell = False

    def reset(self):
        pass

    def request(self, t, est, ww, failed):
        return Request(per_wheel=[0.0] * self.ctx.n)

    def after(self, sat, failed_any, ww, dt, T_des=None, T_lim=None):
        pass

    def on_event(self, t, what):
        """Called at wheel events and yaw-command steps; controllers with integrators may reset (see PID)."""
        pass

    def summary(self):
        return {"type": self.type, "structure": self.structure, "law": self.law}


# ---------------------------------------------------------------------------------------
# Edge (hinge) controllers — browser laws
# ---------------------------------------------------------------------------------------
class EdgeLegacy(Controller):
    structure = "decoupled"

    def __init__(self, ctx, kind):
        super().__init__(ctx)
        self.type = kind
        d = ctx.design["tilt"]
        self.K = d["K"]
        self.pid = d["pid"]
        self.gam = ctx.adaptive["gamma"]
        self.clamp = ctx.adaptive["clamp_deg"] * DEG
        self.betaRef = ctx.design["betaRef"]
        self.I = 0.0
        self.bh = 0.0
        self.aw = ctx.pid_cfg.get("anti_windup", "clamp")
        self.reset_on_events = bool(ctx.pid_cfg.get("reset_on_events", False))
        self.last_sat_dir = 0.0
        self.resets = []
        self.law = {"pid": "T = Kp·e + Ki·∫e + Kd·θ̂̇ (integral clamped at τmax/Ki)",
                    "lqr": "T = −(K₁·e + K₂·θ̂̇ + K₃·Ω)", "adp": "T = −(K₁·(e + β̂) + K₂·θ̂̇ + K₃·Ω), dβ̂/dt = γ·Ω"}[kind]

    def reset(self):
        self.I = 0.0

    def on_event(self, t, what):
        """Wheel event or yaw-command step: PID integrators restart from zero when configured (never by default)."""
        if self.type == "pid" and self.reset_on_events:
            self.reset()
            self.resets.append({"t": t, "reason": what})

    def summary(self):
        s = super().summary()
        if self.type == "pid":
            s["anti_windup"] = self.aw
            s["reset_on_events"] = self.reset_on_events
            s["integrator_resets"] = self.resets
        return s

    def request(self, t, est, ww, failed):
        err = est.theta + self.betaRef
        Om = ww[self.ctx.drive]
        dt = self.ctx.dt
        Tc = 0.0
        if not self.fell:
            if self.type == "pid":
                if not (self.aw == "conditional" and self.last_sat_dir * err > 0):
                    self.I += err * dt
                Il = self.ctx.taumax_act / self.pid["Ki"]
                if self.I > Il:
                    self.I = Il
                elif self.I < -Il:
                    self.I = -Il
                Tc = self.pid["Kp"] * err + self.pid["Ki"] * self.I + self.pid["Kd"] * est.thetadot
            elif self.type == "lqr":
                Tc = -(self.K[0] * err + self.K[1] * est.thetadot + self.K[2] * Om)
            elif self.type == "adp":
                Tc = -(self.K[0] * (err + self.bh) + self.K[1] * est.thetadot + self.K[2] * Om)
        return Request(per_wheel=self.ctx.edge_alloc(Tc), bh=self.bh)

    def after(self, sat, failed_any, ww, dt, T_des=None, T_lim=None):
        if self.type == "pid" and T_des is not None:
            self.last_sat_dir = (T_des - T_lim) if sat else 0.0
        if self.type == "adp" and not self.fell and not sat and not failed_any:
            self.bh += self.gam * ww[self.ctx.drive] * dt
            if self.bh > self.clamp:
                self.bh = self.clamp
            elif self.bh < -self.clamp:
                self.bh = -self.clamp


# ---------------------------------------------------------------------------------------
# Corner controllers — browser decoupled laws
# ---------------------------------------------------------------------------------------
class CornerLegacy(Controller):
    structure = "decoupled"

    def __init__(self, ctx, kind):
        super().__init__(ctx)
        self.type = kind
        self.D = ctx.design["tilt"]
        self.Y = ctx.design["yaw"]
        self.uRef = ctx.uRef
        self.yaw = YawTracker(ctx.qRef, ctx.uRef)
        self.I = [0.0, 0.0, 0.0]
        self.Iy = 0.0
        self.bh = [0.0, 0.0, 0.0]
        self.gam = ctx.adaptive["gamma"]
        self.clamp = ctx.adaptive["clamp_deg"] * DEG
        self.aw = ctx.pid_cfg.get("anti_windup", "clamp")
        self.reset_on_events = bool(ctx.pid_cfg.get("reset_on_events", False))
        self.sat = False
        self.Tp_prev = (0.0, 0.0, 0.0)
        self.Tc_prev = 0.0
        self.resets = []
        self.law = {"pid": "per tilt axis T = Kp·θ + Ki·∫θ + Kd·ω⊥ (integral clamped by norm), yaw PID about the balance axis",
                    "lqr": "per tilt axis T = −(K₁·θ + K₂·ω⊥ + K₃·Ω⊥), yaw LQR about the balance axis",
                    "adp": "as LQR with θ → θ + β̂ (vector in the tilt plane), dβ̂/dt = γ·Ω⊥"}[kind]

    def reset(self):
        self.I = [0.0, 0.0, 0.0]
        self.Iy = 0.0

    def on_event(self, t, what):
        if self.type == "pid" and self.reset_on_events:
            self.reset()
            self.resets.append({"t": t, "reason": what})

    def summary(self):
        s = super().summary()
        if self.type == "pid":
            s["anti_windup"] = self.aw
            s["reset_on_events"] = self.reset_on_events
            s["integrator_resets"] = self.resets
        return s

    def request(self, t, est, ww, failed):
        u = self.uRef
        q = est.q
        uB = up_in_body(q)
        tht = cross(uB, u)
        psi = self.yaw.psi(q)
        if self.ctx.psi0 is None:
            self.ctx.psi0 = psi
        psid = dot(est.w, u)
        Pw = proj_on(est.w, u)
        Pww = proj_on(tuple(ww[:3]), u)
        dt = self.ctx.dt
        Tp = (0.0, 0.0, 0.0)
        Tc = 0.0
        bhUsed = tuple(self.bh)
        if not self.fell:
            if self.type == "pid":
                # conditional anti-windup: while saturated, do not integrate an error that pushes the tilt torque
                # further in the direction it is already demanded (browser default 'clamp' always integrates)
                if not (self.aw == "conditional" and self.sat and dot(tht, self.Tp_prev) > 0):
                    self.I = [self.I[i] + tht[i] * dt for i in range(3)]
                In = math.sqrt(sum(x * x for x in self.I))
                Il = self.ctx.taumax_act / self.D["pid"]["Ki"]
                if In > Il:
                    self.I = [x * Il / In for x in self.I]
                P = self.D["pid"]
                Tp = tuple(P["Kp"] * tht[j] + P["Ki"] * self.I[j] + P["Kd"] * Pw[j] for j in range(3))
            else:
                K = self.D["K"]
                bb = self.bh if self.type == "adp" else (0.0, 0.0, 0.0)
                Tp = tuple(-(K[0] * (tht[j] + bb[j]) + K[1] * Pw[j] + K[2] * Pww[j]) for j in range(3))
            ey = psi - self.ctx.psi_ref(t)
            if self.ctx.heading_free:          # reference.heading = 'free': no heading objective, the yaw rate is still damped
                Tc = self.Y["pid"]["Kd"] * psid if self.type == "pid" else -(self.Y["K"][1] * psid)
            elif self.type == "pid":
                if not (self.aw == "conditional" and self.sat and ey * self.Tc_prev > 0):
                    self.Iy += ey * dt
                Tc = self.Y["pid"]["Kp"] * ey + self.Y["pid"]["Ki"] * self.Iy + self.Y["pid"]["Kd"] * psid
            else:
                Tc = -(self.Y["K"][0] * ey + self.Y["K"][1] * psid)
        TpP = proj_on(Tp, u)
        self.Tp_prev, self.Tc_prev = Tp, Tc
        self._Pww = Pww
        per, given_up = self.ctx.corner_alloc_legacy(TpP, Tc, failed, self.fell)
        return Request(per_wheel=per, bh=bhUsed, yaw_given_up=given_up)

    def after(self, sat, failed_any, ww, dt, T_des=None, T_lim=None):
        self.sat = bool(sat)
        if self.type == "adp" and not self.fell and (not sat or failed_any):
            Pww = self._Pww
            bh = [self.bh[i] + self.gam * Pww[i] * dt for i in range(3)]
            bh = list(proj_on(tuple(bh), self.uRef))
            nb = math.sqrt(sum(x * x for x in bh))
            if nb > self.clamp:
                bh = [x * self.clamp / nb for x in bh]
            self.bh = bh


# ---------------------------------------------------------------------------------------
# Coupled MIMO LQR (corner)
# ---------------------------------------------------------------------------------------
class CornerMimo(Controller):
    type = "lqr"
    structure = "mimo-lqr"
    law = "T = −K·[φ; ω̂; Ω], K (n×(6+n)) from the LQR on the controllable subspace of the full-tensor linearisation"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.design = ctx.design["mimo"]
        self.K = np.array(self.design["K"])
        self.yaw = YawTracker(ctx.qRef, ctx.uRef)
        self.active = list(range(ctx.n))
        self.redesigns = []

    def reference(self, t):
        psi_r = self.ctx.psi_ref(t)
        return qmul(axis_angle((0.0, 0.0, 1.0), psi_r), self.ctx.qRef)

    def request(self, t, est, ww, failed):
        if self.ctx.psi0 is None:
            self.ctx.psi0 = self.yaw.psi(est.q)
        else:
            self.yaw.psi(est.q)
        if self.fell:
            return Request(per_wheel=[0.0] * self.ctx.n)
        failed_now = [i for i in range(self.ctx.n) if failed[i]]
        if failed_now and self.ctx.reconfigure and set(failed_now) & set(self.active):
            self._reconfigure(t, failed)
        phi = log_vec(qmul(qconj(self.reference(t)), est.q))
        x = np.concatenate([phi, est.w, np.array([ww[i] for i in self.active])])
        Tsub = -(self.K @ x)
        per = [0.0] * self.ctx.n
        for k, i in enumerate(self.active):
            per[i] = float(Tsub[k])
        return Request(per_wheel=per)

    def _reconfigure(self, t, failed):
        keep = [i for i in range(self.ctx.n) if not failed[i]]
        try:
            d = self.ctx.mimo_design(keep)
            self.K = np.array(d["K"])
            self.active = keep
            self.redesigns.append({"t": t, "wheels": [self.ctx.ids[i] for i in keep], "ok": True,
                                   "controllable_rank": d["controllable_rank"], "state_dim": d["state_dim"],
                                   "cl_reduced": d["cl_reduced"]})
        except DesignError as ex:
            # keep the full gain; the failed wheel simply produces no torque (reported, not hidden)
            self.redesigns.append({"t": t, "wheels": [self.ctx.ids[i] for i in keep], "ok": False, "error": str(ex)})
            self.active = list(range(self.ctx.n))
            self.ctx.reconfigure = False

    def summary(self):
        s = super().summary()
        s["redesigns"] = self.redesigns
        return s


# ---------------------------------------------------------------------------------------
# Nonlinear model-compensated quaternion PD (edge and corner)
# ---------------------------------------------------------------------------------------
class NonlinearPD(Controller):
    """u = τ_g,model(q̂) − ω̂×(Θ_O,m ω̂ + Σ J_i Ω_i a_i) − Θ̂_m α_d + f_model(Ω)
       with u = Σ T_i a_i the torque the motors apply to the wheels (the body receives −u), so that
       with an exact model Θ̂ ω̇ = −ω×H + τ_g − u reduces to ω̇ = α_d;
       α_d = −K_p φ_e − K_d ω̂_e,  φ_e = 2·sgn(q_e0)·vec(q_e),  q_e = q_r⁻¹ ⊗ q̂.
    Tilt and yaw gains differ (ω_n, ζ per direction). The reference q_r is the model's upright
    attitude (COM above the pivot) at the commanded heading, tilted by the momentum loop
    δ = −(k₁ h⊥ + k₂ ∫h⊥ dt), h⊥ the horizontal wheel momentum, which drives the wheels back to
    rest by using gravity (integral action removes a constant COM offset)."""
    type = "nlpd"
    structure = "nonlinear-full-tensor"   # one coupled law using the full inertia tensor; no per-axis loops

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx.nonlinear
        self.c = c
        m = ctx.model
        self.M = m["M"]
        self.rc = tuple(m["rc"])
        self.ThO = [list(r) for r in m["ThO"]]
        self.Thh = np.array(m["Thh"])
        self.g = ctx.cfg["params"]["g"]
        l = math.sqrt(dot(self.rc, self.rc))
        self.l = l
        wn, z = c["omega_n"], c["zeta"]
        self.kp, self.kd = wn * wn, 2 * z * wn
        self.kpy, self.kdy = c["yaw_omega_n"] ** 2, 2 * c["yaw_zeta"] * c["yaw_omega_n"]
        wo = c["momentum_omega"]
        # outer momentum loop: gravity torque ≈ m g l δ drains the wheel momentum, so
        # s² + m g l k₁ s + m g l k₂ = (s + ω_o)² with k₁ = 2ω_o/(m g l), k₂ = ω_o²/(m g l).
        # Edge mode uses the model's lever arm about the support edge, corner mode |r_c|.
        mgl = ctx.design["edge_model_mgl"] if ctx.mode == "edge" else self.M * self.g * l
        self.mgl = mgl
        self.k1 = 2 * wo / mgl
        self.k2 = wo * wo / mgl
        self.maxref = c["max_ref_tilt_deg"] * DEG
        self.hint = [0.0, 0.0, 0.0]
        self.delta = (0.0, 0.0, 0.0) if ctx.mode == "corner" else 0.0
        self.yaw = YawTracker(ctx.qRef, ctx.uRef) if ctx.mode == "corner" else None
        self.law = ("u = τ_g,m(q̂) − ω̂×H − Θ̂_m(−K_p φ_e − K_d ω̂) + f_m(Ω), u = Σ T_i a_i; reference tilted by −(k₁h⊥ + k₂∫h⊥)"
                    if ctx.mode == "corner" else "T = m g l_m sin(θ̂+β_m) − Θ̂_m(−k_p(θ̂+β_m−δ) − k_d θ̂̇) + f_m(Ω); δ = −(k₁h + k₂∫h)")

    def reset(self):
        self.hint = [0.0, 0.0, 0.0]

    def summary(self):
        """The gains and model actually used, persisted with the run (executed.controller)."""
        s = super().summary()
        corner = self.ctx.mode == "corner"
        s["gains"] = {"kp_tilt_per_s2": self.kp, "kd_tilt_per_s": self.kd,
                      "kp_yaw_per_s2": self.kpy if corner else None, "kd_yaw_per_s": self.kdy if corner else None,
                      "k1_momentum_rad_per_Nms": self.k1, "k2_momentum_rad_per_Nms2": self.k2, "max_ref_tilt_deg": self.c["max_ref_tilt_deg"]}
        s["settings"] = dict(self.c)
        s["model_used"] = {"M_kg": self.M, "rc_m": list(self.rc), "mgl_Nm": self.mgl,
                           "source": (self.ctx.model or {}).get("source")}
        return s

    def request(self, t, est, ww, failed):
        ctx = self.ctx
        if ctx.mode == "edge":
            return self._edge(t, est, ww)
        if ctx.psi0 is None:
            ctx.psi0 = self.yaw.psi(est.q)
        else:
            self.yaw.psi(est.q)
        if self.fell:
            return Request(body=(0.0, 0.0, 0.0))
        u = ctx.uRef
        h = [0.0, 0.0, 0.0]
        for i, ax in enumerate(ctx.axes):
            if not failed[i]:
                for k in range(3):
                    h[k] += ctx.Jws[i] * ww[i] * ax[k]
        hp = proj_on(tuple(h), u)
        delta = [-(self.k1 * hp[k] + self.k2 * self.hint[k]) for k in range(3)]
        dn = math.sqrt(sum(x * x for x in delta))
        if dn > self.maxref:
            delta = [x * self.maxref / dn for x in delta]
        self._hp = hp
        q_r = qmul(qmul(axis_angle((0.0, 0.0, 1.0), ctx.psi_ref(t)), ctx.qRef), _exp(delta))
        qe = qmul(qconj(q_r), est.q)
        s = 1.0 if qe[0] >= 0 else -1.0
        phi = (2 * s * qe[1], 2 * s * qe[2], 2 * s * qe[3])
        w = est.w
        # tilt / yaw split of the error about the balance axis u
        pe, we = dot(phi, u), dot(w, u)
        kpy = 0.0 if ctx.heading_free else self.kpy     # reference.heading = 'free': yaw rate damped, no heading angle
        alpha = [-(self.kp * (phi[k] - pe * u[k]) + self.kd * (w[k] - we * u[k])) - (kpy * pe + self.kdy * we) * u[k] for k in range(3)]
        body = [0.0, 0.0, 0.0]
        if self.c["compensate_gravity"]:
            upb = up_in_body(est.q)
            gB = (-self.g * upb[0], -self.g * upb[1], -self.g * upb[2])
            tg = cross(self.rc, gB)
            body = [self.M * tg[k] for k in range(3)]
        if self.c["compensate_gyroscopic"]:
            H = list(mv(self.ThO, w))
            for i, ax in enumerate(ctx.axes):
                for k in range(3):
                    H[k] += ctx.Jws[i] * ww[i] * ax[k]
            gy = cross(w, tuple(H))
            body = [body[k] - gy[k] for k in range(3)]
        Ta = self.Thh @ np.array(alpha)
        body = [body[k] - float(Ta[k]) for k in range(3)]
        self.delta = tuple(delta)
        return Request(body=tuple(body))

    def _edge(self, t, est, ww):
        ctx = self.ctx
        if self.fell:
            return Request(per_wheel=[0.0] * ctx.n)
        h = sum(ctx.Jws[i] * ww[i] * ctx.axes[i][0] for i in range(ctx.n))
        delta = -(self.k1 * h + self.k2 * self.hint[0])
        delta = max(-self.maxref, min(self.maxref, delta))
        self._hp = (h, 0.0, 0.0)
        beta_m = ctx.design["betaRef"]
        e = est.theta + beta_m
        alpha = -(self.kp * (e - delta) + self.kd * est.thetadot)
        Th = ctx.design["edge_model_Thh"]
        mgl = ctx.design["edge_model_mgl"]
        tau = (mgl * math.sin(e) if self.c["compensate_gravity"] else 0.0) - Th * alpha
        self.delta = delta
        return Request(per_wheel=ctx.edge_alloc(tau))

    def after(self, sat, failed_any, ww, dt, T_des=None, T_lim=None):
        if self.fell:
            return
        hp = getattr(self, "_hp", (0.0, 0.0, 0.0))
        self.hint = [self.hint[k] + hp[k] * dt for k in range(3)]
        # anti-windup on the momentum integral: never command more than the tilt limit
        lim = self.maxref / max(1e-12, self.k2)
        n = math.sqrt(sum(x * x for x in self.hint))
        if n > lim:
            self.hint = [x * lim / n for x in self.hint]


def _exp(v):
    from ..physics.quaternion import exp_vec
    return exp_vec(tuple(v))


def make_controller(ctx):
    c = ctx.cfg["controller"]
    typ, st = c["type"], c.get("structure", "decoupled")
    if typ == "none":
        return Controller(ctx)
    if typ == "nlpd":
        return NonlinearPD(ctx)
    if ctx.mode == "edge":
        return EdgeLegacy(ctx, typ)
    if st == "mimo-lqr":
        return CornerMimo(ctx)
    return CornerLegacy(ctx, typ)


__all__ = ["make_controller", "Controller", "Request", "YawTracker", "CH", "mtv", "from_to"]

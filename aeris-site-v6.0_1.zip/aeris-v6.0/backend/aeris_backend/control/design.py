"""Controller design: LQR (continuous algebraic Riccati equation), PID by pole placement, and the
coupled three-axis MIMO LQR on the controllable subspace.

All designs are for the linearisation about the upright equilibrium (centre of mass straight
above the pivot, body at rest, wheels at rest). Designs are cached by their numerical inputs
(gain caching), so a sweep that repeats a model does not re-solve the Riccati equation.
"""
from __future__ import annotations

import functools
import math

import numpy as np
from scipy import linalg as sla

from ..constants import DEG


class DesignError(ValueError):
    """The requested design does not exist (not stabilisable, not physical, …)."""


def _sorted_eigs(M) -> list[list[float]]:
    ev = np.linalg.eigvals(np.asarray(M, dtype=float))
    out = []
    for z in ev:
        re, im = float(z.real), float(z.imag)
        if abs(im) < 1e-9 * max(1.0, abs(re)):
            im = 0.0
        out.append([re, im])
    out.sort(key=lambda r: (r[0], r[1]))
    return out


def pbh(A, B, tol=1e-9) -> list[dict]:
    """Popov–Belevitch–Hautus test: for each eigenvalue λ of A, rank [A − λI, B]."""
    A = np.asarray(A, dtype=float)
    B = np.asarray(B, dtype=float)
    n = A.shape[0]
    out = []
    for lam in np.linalg.eigvals(A):
        M = np.hstack([A - lam * np.eye(n), B.astype(complex)])
        s = np.linalg.svd(M, compute_uv=False)
        r = int(np.sum(s > tol * max(1.0, s[0])))
        out.append({"eigenvalue": [float(lam.real), float(lam.imag)], "rank": r, "controllable": r == n})
    return out


def lqr(A, B, Q, R) -> dict:
    """Infinite-horizon LQR. Raises DesignError when (A, B) is not stabilisable."""
    A = np.asarray(A, dtype=float)
    B = np.asarray(B, dtype=float)
    Q = np.asarray(Q, dtype=float)
    R = np.asarray(R, dtype=float)
    unstab = [r for r in pbh(A, B) if not r["controllable"] and r["eigenvalue"][0] >= -1e-12]
    if unstab:
        raise DesignError("(A, B) is not stabilisable: uncontrollable modes at "
                          + ", ".join(f"{u['eigenvalue'][0]:.3g}{u['eigenvalue'][1]:+.3g}j" for u in unstab))
    try:
        P = sla.solve_continuous_are(A, B, Q, R)
    except (np.linalg.LinAlgError, ValueError) as ex:
        raise DesignError(f"Riccati solver failed: {ex}") from ex
    P = 0.5 * (P + P.T)
    K = np.linalg.solve(R, B.T @ P)
    res = A.T @ P + P @ A - P @ B @ np.linalg.solve(R, B.T @ P) + Q
    rel = float(np.max(np.abs(res)) / max(1e-300, np.max(np.abs(Q))))
    if not np.all(np.isfinite(K)):
        raise DesignError("LQR gain is not finite")
    cl = _sorted_eigs(A - B @ K)
    if any(r[0] >= 0 for r in cl):
        raise DesignError("the LQR closed loop is not stable")
    return {"K": K, "P": P, "residual": rel, "cl": cl}


def poly_from_roots(rs) -> list[float]:
    return [float(c.real) for c in np.poly([complex(r[0], r[1]) for r in rs])]


@functools.lru_cache(maxsize=4096)
def _design_tilt_cached(Thh, Th0, mgl, Jw, taumax, th_w, thd_w, ww_w, r_scale, pint, gam):
    if not (Thh > 0 and Th0 > 0 and Jw > 0 and mgl > 0 and taumax > 0):
        raise DesignError("tilt model is not physical (non-positive inertia, gravity stiffness or torque limit)")
    A = np.array([[0, 1, 0], [mgl / Thh, 0, 0], [-mgl / Thh, 0, 0]], dtype=float)
    B = np.array([[0], [-1 / Thh], [Th0 / (Jw * Thh)]], dtype=float)
    Q = np.diag([1 / th_w ** 2, 1 / thd_w ** 2, 1 / ww_w ** 2])
    R = np.array([[1 / (taumax * taumax) * r_scale]])
    L = lqr(A, B, Q, R)
    K = L["K"][0]
    Acl = A - B @ K.reshape(1, 3)
    cl = L["cl"]
    fast = [r for r in cl if abs(r[1]) > 1e-9]
    if len(fast) < 2:
        fast = cl[:2]
    poly = poly_from_roots(fast + [[pint, 0.0]])
    pid = {"Kd": Thh * poly[1], "Kp": mgl + Thh * poly[2], "Ki": Thh * poly[3]}
    Aa = np.zeros((4, 4))
    Aa[:3, :3] = Acl
    Aa[:3, 3] = -B[:, 0] * K[0]
    Aa[3, 2] = gam
    PIDA = np.array([[0, 1, 0], [(mgl - pid["Kp"]) / Thh, -pid["Kd"] / Thh, -pid["Ki"] / Thh], [1, 0, 0]])
    return {"M": {"A": A.tolist(), "B": B.tolist(), "Thh": Thh, "Th0": Th0, "mgl": mgl}, "Q": Q.tolist(), "R": R.tolist(),
            "K": K.tolist(), "P": L["P"].tolist(), "riccati_residual": L["residual"], "cl": cl, "ol": _sorted_eigs(A),
            "pid": pid, "pidPoles": _sorted_eigs(PIDA), "gam": gam, "adpPoles": _sorted_eigs(Aa),
            "controllability": pbh(A, B),
            "state": ["e = θ + β_ref [rad]", "θ̇ [rad/s]", "Ω [rad/s] (wheel speed relative to the body)"], "input": "T [N·m] (motor torque on the wheel)",
            "operating_point": {"e_rad": 0.0, "thetadot_rad_s": 0.0, "Omega_rad_s": 0.0, "note": "COM above the support axis at rest; sin e ≈ e"}}


def design_tilt(Thh, Th0, mgl, Jw, taumax, lqr_w: dict, pid_w: dict, gam: float) -> dict:
    """Browser designTilt: single-axis tilt model x = [θ, θ̇, Ω], u = T (motor torque on the wheel)."""
    return _design_tilt_cached(float(Thh), float(Th0), float(mgl), float(Jw), float(taumax),
                               lqr_w["tilt_deg"] * DEG, lqr_w["rate_dps"] * DEG, float(lqr_w["wheel_rad_s"]),
                               float(lqr_w["r_scale"]), float(pid_w["integrator_pole"]), float(gam))


@functools.lru_cache(maxsize=4096)
def _design_yaw_cached(Thy, taumax, psi_w, psid_w, r_scale, pinty):
    if not Thy > 0:
        raise DesignError("yaw inertia is not positive")
    Ay = np.array([[0, 1], [0, 0]], dtype=float)
    By = np.array([[0], [-1 / Thy]], dtype=float)
    Qy = np.diag([1 / psi_w ** 2, 1 / psid_w ** 2])
    Ry = np.array([[1 / (3 * taumax * taumax) * r_scale]])
    L = lqr(Ay, By, Qy, Ry)
    Ky = L["K"][0]
    poly = poly_from_roots(L["cl"] + [[pinty, 0.0]])
    return {"A": Ay.tolist(), "B": By.tolist(), "Q": Qy.tolist(), "R": Ry.tolist(), "K": Ky.tolist(), "cl": L["cl"],
            "P": L["P"].tolist(), "riccati_residual": L["residual"], "controllability": pbh(Ay, By),
            "state": ["ψ − ψ_ref [rad] (yaw about the balance axis)", "ψ̇ [rad/s]"], "input": "T_ψ [N·m] along the balance axis",
            "operating_point": {"psi_err_rad": 0.0, "psidot_rad_s": 0.0, "note": "balanced at the commanded heading"},
            "pid": {"Kd": Thy * poly[1], "Kp": Thy * poly[2], "Ki": Thy * poly[3]}}


def design_yaw(Thy, taumax, lqr_w: dict, pid_w: dict) -> dict:
    return _design_yaw_cached(float(Thy), float(taumax), lqr_w["yaw_deg"] * DEG, lqr_w["yaw_rate_dps"] * DEG,
                              float(lqr_w["r_scale"]), float(pid_w["yaw_integrator_pole"]))


# ---------------------------------------------------------------------------------------
# Coupled three-axis MIMO LQR (corner mode)
# ---------------------------------------------------------------------------------------
def corner_linearization(ThO, M, rc, g, axes, Jw) -> dict:
    """Linearisation of the corner model about the upright equilibrium.

    State x = [φ (3), ω (3), Ω (n)]: φ is the small rotation vector from the equilibrium attitude
    (body frame, R = R_eq·exp([φ]×)), ω the body rate, Ω the relative wheel speeds. Input u = T
    (motor torques on the wheels). With u_c = r_c/|r_c| vertical at equilibrium, gravity gives
    τ_g ≈ M g l (I − u_c u_cᵀ) φ; the gyroscopic term ω×H is second order at rest.
        φ̇ = ω
        Θ̂ ω̇ = M g l (I − u_c u_cᵀ) φ − A_w T              Θ̂ = Θ_O − Σ J_i a_i a_iᵀ
        Ω̇ = J⁻¹ T − A_wᵀ ω̇
    """
    ThO = np.asarray(ThO, dtype=float)
    rc = np.asarray(rc, dtype=float)
    Aw = np.array(axes, dtype=float).T
    Aw = Aw / np.linalg.norm(Aw, axis=0)
    n = Aw.shape[1]
    J = np.asarray(Jw, dtype=float)
    Thh = ThO - sum(J[i] * np.outer(Aw[:, i], Aw[:, i]) for i in range(n))
    if np.linalg.eigvalsh(Thh)[0] <= 0:
        raise DesignError("the model inertia minus the wheel spin inertias is not positive definite")
    l = float(np.linalg.norm(rc))
    u = rc / l
    G = M * g * l * (np.eye(3) - np.outer(u, u))
    Ti = np.linalg.inv(Thh)
    N = 6 + n
    A = np.zeros((N, N))
    B = np.zeros((N, n))
    A[0:3, 3:6] = np.eye(3)
    A[3:6, 0:3] = Ti @ G
    A[6:, 0:3] = -Aw.T @ Ti @ G
    B[3:6, :] = -Ti @ Aw
    B[6:, :] = np.diag(1 / J) + Aw.T @ Ti @ Aw
    return {"A": A, "B": B, "u": u, "l": l, "Thh": Thh, "Aw": Aw, "n": n}


def controllable_subspace(A, B, tol=1e-9):
    """Orthonormal bases (Vc, Vu) of the controllable subspace and its orthogonal complement."""
    N = A.shape[0]
    lam = max(1.0, float(np.max(np.abs(np.linalg.eigvals(A)))))
    As = A / lam
    blocks, X = [], B
    for _ in range(N):
        blocks.append(X)
        X = As @ X
    C = np.hstack(blocks)
    U, s, _ = np.linalg.svd(C)
    r = int(np.sum(s > tol * s[0]))
    return U[:, :r], U[:, r:], r, s.tolist()


def design_mimo(ThO, M, rc, g, axes, Jw, taumax, weights: dict) -> dict:
    """Coupled MIMO LQR on the full inertia tensor.

    The linearised corner model always has an uncontrollable mode: the angular momentum about the
    vertical, u_cᵀ(Θ_O ω + Σ J_i Ω_i a_i), is conserved (gravity has no vertical moment and the
    wheels only exchange momentum with the body), so its eigenvalue is 0 and (A, B) is not
    stabilisable in the strict sense. The gain is therefore designed on the controllable subspace
    (Kalman decomposition with an orthonormal basis V_c): K_c from the CARE for
    (V_cᵀAV_c, V_cᵀB, V_cᵀQV_c, R), and K = K_c V_cᵀ (n × (6+n)). Any other uncontrollable mode
    with Re λ ≥ 0 makes the design fail with an error.
    """
    L = corner_linearization(ThO, M, rc, g, axes, Jw)
    A, B, u, n = L["A"], L["B"], L["u"], L["n"]
    P = np.eye(3) - np.outer(u, u)
    th, thd, ww = weights["tilt_deg"] * DEG, weights["rate_dps"] * DEG, weights["wheel_rad_s"]
    psi, psid = weights["yaw_deg"] * DEG, weights["yaw_rate_dps"] * DEG
    N = 6 + n
    Q = np.zeros((N, N))
    Q[0:3, 0:3] = P / th ** 2 + np.outer(u, u) / psi ** 2
    Q[3:6, 3:6] = P / thd ** 2 + np.outer(u, u) / psid ** 2
    Q[6:, 6:] = np.eye(n) / ww ** 2
    tm = np.asarray(taumax, dtype=float)
    R = np.diag(weights["r_scale"] / tm ** 2)
    Vc, Vu, r, sv = controllable_subspace(A, B)
    Au = Vu.T @ A @ Vu if Vu.shape[1] else np.zeros((0, 0))
    unc = _sorted_eigs(Au) if Vu.shape[1] else []
    if any(e[0] > 1e-9 for e in unc):
        raise DesignError("uncontrollable unstable mode(s): " + ", ".join(f"{e[0]:.3g}" for e in unc))
    Ac, Bc, Qc = Vc.T @ A @ Vc, Vc.T @ B, Vc.T @ Q @ Vc
    Lr = lqr(Ac, Bc, Qc, R)
    K = Lr["K"] @ Vc.T
    cl_full = _sorted_eigs(A - B @ K)
    # the conserved quantity (left null vector of the uncontrollable part), for documentation
    h_dir = None
    if Vu.shape[1] == 1:
        h_dir = Vu[:, 0].tolist()
    return {"structure": "mimo-lqr", "state": ["phi_x", "phi_y", "phi_z", "w_x", "w_y", "w_z"] + [f"Omega_{i}" for i in range(n)],
            "operating_point": {"u_com_body": u.tolist(), "omega": [0, 0, 0], "wheel_speeds": [0] * n, "l": L["l"]},
            "A": A.tolist(), "B": B.tolist(), "Q": Q.tolist(), "R": R.tolist(), "K": K.tolist(),
            "K_reduced": Lr["K"].tolist(), "Vc": Vc.tolist(), "controllable_rank": r, "state_dim": N,
            "controllability_singular_values": sv, "uncontrollable_eigenvalues": unc,
            "uncontrollable_direction": h_dir, "riccati_residual": Lr["residual"],
            "cl_reduced": Lr["cl"], "cl": cl_full, "ol": _sorted_eigs(A), "Thh": L["Thh"].tolist(),
            "gain_shape": [int(K.shape[0]), int(K.shape[1])]}


def design_mimo_cached(ThO, M, rc, g, axes, Jw, taumax, weights) -> dict:
    key = (tuple(np.round(np.asarray(ThO, float).ravel(), 15)), float(M), tuple(np.round(np.asarray(rc, float), 15)), float(g),
           tuple(tuple(a) for a in axes), tuple(Jw), tuple(np.asarray(taumax, float).ravel()), tuple(sorted(weights.items())))
    return _mimo_cache(key)


@functools.lru_cache(maxsize=1024)
def _mimo_cache(key):
    ThO, M, rc, g, axes, Jw, taumax, w = key
    return design_mimo(np.array(ThO).reshape(3, 3), M, np.array(rc), g, [list(a) for a in axes], list(Jw), np.array(taumax), dict(w))

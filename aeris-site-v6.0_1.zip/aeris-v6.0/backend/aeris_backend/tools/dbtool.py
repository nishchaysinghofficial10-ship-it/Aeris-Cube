"""AERIS database tool (docs/DATABASE.md §5). Every command prints one JSON object.

    python -m aeris_backend.tools.dbtool backup  --db data/aeris.sqlite3 [--out backups/NAME.sqlite3]
    python -m aeris_backend.tools.dbtool restore --backup backups/NAME.sqlite3 --db data/restored.sqlite3
    python -m aeris_backend.tools.dbtool verify  --db data/aeris.sqlite3
    python -m aeris_backend.tools.dbtool info    --db data/aeris.sqlite3
    python -m aeris_backend.tools.dbtool export-audit --db data/aeris.sqlite3

backup   a consistent copy while the backend may be running: the source is opened READ-ONLY (it takes no lock
         and writes nothing) and copied with SQLite's online backup API; the copy is then verified. An existing
         output file is never overwritten.
restore  copies a backup to a NEW database file (the target must not exist: nothing is ever overwritten or
         erased), migrates it to the current schema if it is older (the backup file itself is not changed),
         and verifies it. Start the backend on the restored file (AERIS_DB or --db).
verify   integrity check, schema version and migrations, row counts, job states, and the integrity of every
         final dataset (member list and member content against the hashes taken at finalisation). Opens the
         database read-only.
export-audit  (v5.2, review finding G1 of v5.1; transitive since v6, review finding V52-4 of v5.2) lists, READ-ONLY,
         the stored recordings whose NDJSON export by v5 or v5.1 was wrong — columns stored in units other than the
         stream's wire units were streamed unconverted (and omega_* wheel speeds left out) — and EVERY stored recording
         descended from such an export, through any number of generations and any later export version (a v5.2+ export
         of a corrupted copy stays corrupted), following lineage (also v5.1 nested ancestors when an intermediate is no
         longer stored) and replayed-recording transports. Each copy is 'affected' (confirmed, with its chain to the
         original), 'unresolved' (a missing source, an ambiguous reference, a cycle — never reported as clear) or clear.
         Those copies carry raw numbers under wire-unit labels; their original units cannot be inferred from them.
         Regenerate any copy you need from the ORIGINAL recording with v5.2 or later. Nothing is changed.
Exit code 0 when everything checked is consistent, 1 otherwise, 2 for a usage error (export-audit: 0 always; it
reports).
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import shutil
import sqlite3
import sys
import tempfile

TABLES = ("jobs", "runs", "sweeps", "sweep_rows", "docs", "devices", "pairings", "leases", "commands")   # the last four: schema 3 (v6.0)


def _ro(path: str) -> sqlite3.Connection:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"no database file '{path}'")
    c = sqlite3.connect(f"file:{os.path.abspath(path)}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    return c


def _stats(c: sqlite3.Connection) -> dict:
    names = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    counts = {t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in TABLES if t in names}
    docs = {}
    if "docs" in names:
        docs = {r[0]: r[1] for r in c.execute("SELECT tbl, COUNT(*) FROM docs GROUP BY tbl")}
    states = {}
    if "jobs" in names:
        states = {r[0]: r[1] for r in c.execute("SELECT state, COUNT(*) FROM jobs GROUP BY state")}
    ver = None
    if "meta" in names:
        r = c.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
        ver = int(r[0]) if r else None
    return {"schema_version": ver, "tables": counts, "documents": docs, "job_states": states}


def verify(path: str) -> dict:
    c = _ro(path)
    try:
        integ = c.execute("PRAGMA integrity_check").fetchone()[0]
        st = _stats(c)
    finally:
        c.close()
    out = {"db": os.path.abspath(path), "integrity": integ, **st, "datasets": []}
    # dataset checks need the repository's readers (decompression, sweep assembly): use a read-only copy so the
    # original is never locked or migrated by this command
    tmpdir = tempfile.mkdtemp(prefix="aeris-verify-")
    try:
        copy = os.path.join(tmpdir, "copy.sqlite3")
        _backup_file(path, copy)
        from ..experiments.datasets import check_final
        from ..storage.sqlite import SqliteRepository
        repo = SqliteRepository(copy, exclusive=False)
        try:
            for d in repo.list("datasets", limit=100000):
                doc = repo.get("datasets", d["id"])
                out["datasets"].append({"id": d["id"], "status": doc.get("status"), "members": len(doc.get("members", [])), "integrity": check_final(repo, doc)})
            out["schema"] = repo.schema_info()
        finally:
            repo.close()
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
    bad = [d["id"] for d in out["datasets"] if d["integrity"] and (not d["integrity"]["members_hash_ok"] or d["integrity"]["member_content_ok"] is False)]
    out["ok"] = integ == "ok" and not bad
    out["problems"] = ([] if integ == "ok" else [f"integrity_check: {integ}"]) + [f"final dataset {i}: content differs from its finalisation hashes" for i in bad]
    return out


def _backup_file(src: str, dest: str) -> None:
    if os.path.exists(dest):
        raise FileExistsError(f"'{dest}' exists; the tool never overwrites a file")
    s = _ro(src)
    d = sqlite3.connect(dest)
    try:
        s.backup(d)
    finally:
        d.close()
        s.close()


def backup(db: str, out: str | None) -> dict:
    if out is None:
        stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        out = os.path.join(os.path.dirname(os.path.abspath(db)), "backups", f"aeris-{stamp}.sqlite3")
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    _backup_file(db, out)
    v = verify(out)
    return {"backup": os.path.abspath(out), "source": os.path.abspath(db), "bytes": os.path.getsize(out), "verified": v["ok"], "verify": v}


def restore(backup_path: str, db: str) -> dict:
    if os.path.exists(db):
        raise FileExistsError(f"'{db}' exists; restore only creates a new database file (nothing is overwritten or erased)")
    os.makedirs(os.path.dirname(os.path.abspath(db)) or ".", exist_ok=True)
    _backup_file(backup_path, db)
    from ..storage.sqlite import SqliteRepository
    repo = SqliteRepository(db, exclusive=True)      # opening migrates an older schema in place (the new file only)
    try:
        info = repo.schema_info()
    finally:
        repo.close()
    v = verify(db)
    return {"restored": os.path.abspath(db), "from": os.path.abspath(backup_path), "schema": info, "verified": v["ok"], "verify": v}


def export_audit(path: str) -> dict:
    """See the module docstring (export-audit) and tools/export_audit.py. Reads the recordings table only; writes nothing."""
    from .export_audit import audit
    return audit(path)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m aeris_backend.tools.dbtool", description="AERIS database backup, restore and verification")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("backup")
    b.add_argument("--db", required=True)
    b.add_argument("--out")
    r = sub.add_parser("restore")
    r.add_argument("--backup", required=True)
    r.add_argument("--db", required=True)
    for name in ("verify", "info", "export-audit"):
        x = sub.add_parser(name)
        x.add_argument("--db", required=True)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "backup":
            res = backup(a.db, a.out)
            ok = res["verified"]
        elif a.cmd == "restore":
            res = restore(a.backup, a.db)
            ok = res["verified"]
        elif a.cmd == "verify":
            res = verify(a.db)
            ok = res["ok"]
        elif a.cmd == "export-audit":
            res = export_audit(a.db)
            ok = True
        else:
            c = _ro(a.db)
            try:
                res = dict(_stats(c), db=os.path.abspath(a.db))
            finally:
                c.close()
            ok = True
    except (FileExistsError, FileNotFoundError) as e:
        print(json.dumps({"ok": False, "error": str(e)}))
        return 2
    print(json.dumps(res, indent=1, default=str))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

"""Read-only audit of copies corrupted by the v5/v5.1 NDJSON export (v6, review finding V52-4 of v5.2).

Background (review finding G1 of v5.1). v5 and v5.1 streamed stored sample values without reading samples.units: a
recording kept in ms, deg, deg/s, g, mN·m … (or with omega_* wheel speeds) was exported with its raw numbers under the
stream's wire units (s, rad, rad/s …), and omega_* was left out. A recording made from such an export (a replay of the
NDJSON file, or v5's replay of the stored recording) holds raw numbers under wire-unit labels; nothing in the copy says
what the units were. v5.2's export converts correctly — but exporting an ALREADY corrupted copy again, with any version,
carries the corruption on: a new export version does not cure old data.

The v5.2 audit only checked a copy's immediate parent (review finding V52-4: the second legacy generation was missed).
This audit follows every provenance relation the database holds, transitively:

  links of a recording R    each lineage object its hellos recorded (provenance.lineage, the hellos' and segments'
                            lineage): derived_from names the recording it was exported from; a lineage WITHOUT
                            "generation"/"export" was written by a v5/v5.1 export (legacy); v5.1 nested "ancestors"
                            describe the earlier export steps (legacy or not, by the same rule) — so a chain can be
                            followed even when an intermediate recording is no longer in the database; v5.2+
                            "ancestry" references name earlier generations; a transport "recording:<id>" names the
                            stored recording that was replayed.
  confirmed affected        a legacy export step from a recording stored in non-wire units, or any copy (any export
                            version) of a recording that is itself confirmed affected; with the chain down to the
                            original and the original's unit issues. Intermediates missing from the database are named
                            when the chain was inferred from nested lineage.
  unresolved risk           the chain cannot be decided: a legacy step from a recording that is not in the database, an
                            ancestor stored in non-wire units behind a missing intermediate whose export version is not
                            recorded, an ambiguous reference (several recordings match), a cycle, or a parent that is
                            itself unresolved. Never reported as clear, never as confirmed.
  clear                     every link was followed and none leads to corrupted data (e.g. a fresh v5.2+ export of a
                            correct original; legacy copies of a recording already in wire units).

Limits (reported with every result): only relations recorded in this database are followed. A copy imported from a file
whose lineage was removed, or made in another database, cannot be traced; a recording without any lineage is treated
as an original. The audit opens the database read-only and changes nothing — it never rewrites numbers, units or
originals (the corrupted values cannot be repaired: regenerate copies from the original with v5.2 or later)."""
from __future__ import annotations

import json
import os
import sqlite3

WIRE = {"time": "s", "angle": "rad", "rate": "rad/s", "wheel": "rpm", "torque": "N·m", "accel": "m/s²"}
MAX_DEPTH = 10000          # links followed from one recording before the walk is reported as unresolved


def _ro(path: str) -> sqlite3.Connection:
    if not os.path.isfile(path):
        raise FileNotFoundError(f"no database file '{path}'")
    c = sqlite3.connect(f"file:{os.path.abspath(path)}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    return c


def unit_issues(doc: dict) -> list:
    """Columns a v5/v5.1 export got wrong: non-wire units streamed unconverted, omega_* left out."""
    from ..hardware.ingest import UNITS, family
    units = ((doc.get("samples") or {}).get("units")) or {}
    out = []
    for col, u in sorted(units.items()):
        fam = family(col)
        if col.startswith("omega_"):
            out.append(f"{col} [{u}] (wheel speed) was left out of the stream")
        elif fam in WIRE and fam in UNITS and u in UNITS[fam] and UNITS[fam][u] != UNITS[fam][WIRE[fam]]:
            out.append(f"{col} [{u}] was streamed as {WIRE[fam]} without conversion")
    return out


def is_legacy(lin: dict) -> bool:
    """A lineage written by the v5/v5.1 export (v5.2+ always writes 'generation' and 'export')."""
    return "generation" not in lin and "export" not in lin


def lineage_objects(doc: dict) -> list:
    """The distinct top-level lineage objects a recording carries (its own lineage list and its hellos' lineage)."""
    prov = doc.get("provenance") if isinstance(doc.get("provenance"), dict) else {}
    found = [l for l in (prov.get("lineage") or []) if isinstance(l, dict)]
    for h in (prov.get("hellos") or []):
        if isinstance(h, dict) and isinstance(h.get("lineage"), dict):
            found.append(h["lineage"])
    for s in (prov.get("segments") or []):
        if isinstance(s, dict) and isinstance((s.get("hello") or {}).get("lineage"), dict):
            found.append(s["hello"]["lineage"])
    seen, out = set(), []
    for l in found:
        k = json.dumps(l, sort_keys=True, default=str)
        if k not in seen:
            seen.add(k)
            out.append(l)
    return out


class _Graph:
    def __init__(self, docs: dict):
        self.docs = docs
        self.issues = {rid: unit_issues((st or {}).get("document") or {}) for rid, st in docs.items()}
        self.by_notes = {}
        for rid, st in docs.items():
            n = (((st or {}).get("document") or {}).get("recording") or {}).get("notes")
            if isinstance(n, str) and n:
                self.by_notes.setdefault(n, []).append(rid)
        self.memo = {}
        self.cycles = []

    def resolve(self, ref):
        """'found' [id] | 'missing' [] | 'ambiguous' [ids] for a derived_from / transport reference."""
        if not isinstance(ref, str) or not ref:
            return "missing", []
        if ref in self.docs:
            return "found", [ref]
        cands = self.by_notes.get(ref, [])
        if len(cands) == 1:
            return "found", cands
        return ("ambiguous", sorted(cands)) if cands else ("missing", [])

    def links(self, rid: str) -> list:
        """[(parent reference, legacy step?, lineage object or None, how)] for one recording."""
        doc = (self.docs[rid] or {}).get("document") or {}
        lins = lineage_objects(doc)
        out = [(l.get("derived_from"), is_legacy(l), l, "lineage") for l in lins if l.get("derived_from") is not None]
        addr = str((((doc.get("provenance") or {}).get("transport")) or {}).get("address") or "")
        if addr.startswith("recording:"):
            out.append((addr[len("recording:"):], not any(not is_legacy(l) for l in lins), None, "replayed stored recording"))
        return out

    # ------------------------------------------------------------------ classification
    def status(self, rid: str, stack=()) -> dict:
        if rid in self.memo:
            return self.memo[rid]
        if rid in stack:
            cyc = list(stack[stack.index(rid):]) + [rid]
            self.cycles.append(cyc)
            return {"status": "unresolved", "reasons": ["a cycle in the recorded lineage: " + " → ".join(cyc)], "cycle": cyc}
        if len(stack) > MAX_DEPTH:
            return {"status": "unresolved", "reasons": [f"the lineage is deeper than {MAX_DEPTH} links"]}
        stack = stack + (rid,)
        confirmed, risks = None, []
        for ref, legacy, lin, how in self.links(rid):
            r = self._link(rid, ref, legacy, lin, how, stack)
            if r["status"] == "confirmed" and confirmed is None:
                confirmed = r
            elif r["status"] == "unresolved":
                risks.append(r)
        if confirmed is not None:
            res = confirmed
        elif risks:
            res = {"status": "unresolved", "reasons": list(dict.fromkeys(x for r in risks for x in r["reasons"])),
                   "missing": sorted({m for r in risks for m in r.get("missing", [])}),
                   "ambiguous": {k: v for r in risks for k, v in (r.get("ambiguous") or {}).items()},
                   "cycle": next((r["cycle"] for r in risks if r.get("cycle")), None)}
        else:
            res = {"status": "clear"}
        # a cycle found below this node is not cached as a final answer for the nodes on it (each reports it)
        self.memo[rid] = res
        return res

    def _link(self, rid, ref, legacy, lin, how, stack) -> dict:
        kind, ids = self.resolve(ref)
        if kind == "ambiguous":
            return {"status": "unresolved", "reasons": [f"its source '{ref}' matches {len(ids)} recordings ({', '.join(ids)})"], "ambiguous": {str(ref): ids}}
        if kind == "found":
            p = ids[0]
            if legacy and self.issues.get(p):
                return {"status": "confirmed", "how": "copied by a v5/v5.1 export from a recording stored in non-wire units",
                        "chain": [rid, p], "original": p, "issues_of_the_original": self.issues[p], "missing": [], "export": "v5/v5.1"}
            ps = self.status(p, stack)
            if ps["status"] == "confirmed":
                return {"status": "confirmed", "how": "copied (" + ("v5/v5.1" if legacy else "v5.2 or later") + " export) from a corrupted copy: a new export version does not repair it",
                        "chain": [rid] + ps["chain"], "original": ps["original"], "issues_of_the_original": ps["issues_of_the_original"],
                        "missing": ps.get("missing", []), "export": "v5/v5.1" if legacy else "v5.2+"}
            if ps["status"] == "unresolved":
                return {"status": "unresolved", "reasons": [f"its source {p} is unresolved: " + "; ".join(ps["reasons"])],
                        "missing": ps.get("missing", []), "ambiguous": ps.get("ambiguous"), "cycle": ps.get("cycle")}
            return {"status": "clear"}
        # the source is not in this database: decide from the lineage the copy recorded, if it can be decided
        inferred = self._infer(rid, ref, lin, stack)
        if inferred is not None:
            return inferred
        if legacy:
            return {"status": "unresolved", "reasons": [f"it was copied by a v5/v5.1 export from '{ref}', which is not in this database: "
                                                        "that export corrupted the copy if the source was stored in non-wire units"], "missing": [str(ref)]}
        return {"status": "clear", "note": f"source '{ref}' not in this database; the export was v5.2 or later"}

    def _infer(self, rid, ref, lin, stack):
        """The source is missing: follow the earlier export steps recorded inside the copy's lineage (v5.1 nested
        ancestors: each step's legacy/non-legacy version is known) and v5.2+ ancestry references (versions unknown)."""
        if not isinstance(lin, dict):
            return None
        missing = [str(ref)]
        # v5.1 nested ancestors: [{derived_from: G, legacy step G → ref?, ancestors: [...]}]
        anc = [a for a in (lin.get("ancestors") or []) if isinstance(a, dict)]
        step_legacy_into_ref = None
        for a in anc:
            g = a.get("derived_from")
            kind, ids = self.resolve(g)
            if kind == "found":
                gid = ids[0]
                legacy_g = is_legacy(a)            # the export G → ref
                if legacy_g and self.issues.get(gid):
                    return {"status": "confirmed", "how": f"inferred from the lineage recorded in {rid}: the missing intermediate {ref} was copied by a v5/v5.1 export from {gid} (non-wire units)",
                            "chain": [rid, str(ref), gid], "original": gid, "issues_of_the_original": self.issues[gid], "missing": missing, "export": "v5/v5.1"}
                gs = self.status(gid, stack)
                if gs["status"] == "confirmed":
                    return {"status": "confirmed", "how": f"inferred from the lineage recorded in {rid}: the missing intermediate {ref} was copied from the corrupted {gid}",
                            "chain": [rid, str(ref)] + gs["chain"], "original": gs["original"], "issues_of_the_original": gs["issues_of_the_original"],
                            "missing": missing + gs.get("missing", []), "export": "v5/v5.1" if legacy_g else "v5.2+"}
                if gs["status"] == "unresolved":
                    return {"status": "unresolved", "reasons": [f"the missing intermediate {ref} derives from {gid}, which is unresolved: " + "; ".join(gs["reasons"])], "missing": missing + gs.get("missing", [])}
                step_legacy_into_ref = legacy_g
            elif kind == "missing" and isinstance(a.get("ancestors"), list):
                deeper = self._infer(rid, g, a, stack)
                if deeper is not None:
                    deeper = dict(deeper)
                    deeper["missing"] = sorted(set(missing + deeper.get("missing", [])))
                    if deeper["status"] == "confirmed":
                        deeper["chain"] = [rid, str(ref)] + deeper["chain"][1:]
                    return deeper
        # v5.2+ flattened ancestry: earlier generations by id, export versions not recorded
        refs = [r for r in (lin.get("ancestry") or []) if isinstance(r, dict)]
        for r in refs:
            kind, ids = self.resolve(r.get("derived_from"))
            if kind != "found":
                continue
            gid = ids[0]
            if self.issues.get(gid):
                return {"status": "unresolved", "reasons": [f"an earlier generation, {gid}, is stored in non-wire units and the intermediate {ref} is not in this database: "
                                                            "whether a v5/v5.1 export was involved cannot be decided"], "missing": missing}
            gs = self.status(gid, stack)
            if gs["status"] == "confirmed":
                return {"status": "confirmed", "how": f"its lineage names {gid}, a corrupted copy, as an earlier generation (intermediate {ref} not in this database)",
                        "chain": [rid, str(ref)] + gs["chain"], "original": gs["original"], "issues_of_the_original": gs["issues_of_the_original"], "missing": missing, "export": "unknown"}
        if step_legacy_into_ref is False:
            return None
        return None


def audit(path: str) -> dict:
    """See the module docstring. Reads the recordings table only; writes nothing."""
    from ..storage.sqlite import _unz
    c = _ro(path)
    try:
        rows = c.execute("SELECT id, doc FROM docs WHERE tbl='recordings' ORDER BY id").fetchall()
    finally:
        c.close()
    docs = {r["id"]: _unz(r["doc"]) for r in rows}
    g = _Graph(docs)
    originals = [{"id": k, "issues": v} for k, v in sorted(g.issues.items()) if v and not g.links(k)]
    affected, unresolved, clear = [], [], 0
    for rid in sorted(docs):
        if not g.links(rid):
            continue                                   # an original (or an untraceable copy: see limits)
        s = g.status(rid)
        if s["status"] == "confirmed":
            affected.append({"id": rid, "status": "confirmed", "how": s["how"], "chain": s["chain"], "original": s["original"],
                             "issues_of_the_original": s["issues_of_the_original"], "missing_intermediates": s.get("missing", []), "export": s.get("export")})
        elif s["status"] == "unresolved":
            unresolved.append({"id": rid, "status": "unresolved", "reasons": s["reasons"], "missing": s.get("missing", []),
                               "ambiguous": s.get("ambiguous") or {}, "cycle": s.get("cycle")})
        else:
            clear += 1
    copies = [{"id": a["id"], "copied_from": [a["chain"][1]], "issues_of_the_original": a["issues_of_the_original"], "original": a["original"], "chain": a["chain"]}
              for a in affected]
    cycles = []
    for cyc in g.cycles:
        key = sorted(set(cyc))
        if key not in [sorted(set(x)) for x in cycles]:
            cycles.append(cyc)
    return {"schema": "aeris-export-audit/2", "db": os.path.abspath(path), "read_only": True, "recordings": len(docs),
            "originals_whose_v5_v51_ndjson_export_was_wrong": originals,
            "copies_recorded_from_such_an_export": copies,                     # v5.2 key, now transitive
            "affected": affected, "unresolved": unresolved, "clear_copies": clear, "cycles": cycles,
            "limits": ["Only relations recorded in this database (lineage, transport) are followed; a copy imported from a file whose lineage "
                       "was removed, or made in another database, cannot be traced, and a recording without any lineage counts as an original.",
                       "'unresolved' means the chain could not be decided from what is stored; it is not a statement that the data are correct."],
            "what_to_do": ("Originals listed here are correct and unchanged; their NDJSON export by v5.2 or later is in wire units. Every "
                           "'affected' recording holds raw numbers under wire-unit labels (or lacks the omega_* wheel speeds) and cannot be "
                           "repaired: its original units are not recorded in it. Export the ORIGINAL again with v5.2 or later and record that "
                           "replay instead; check each 'unresolved' copy against its source by hand. This tool changes nothing.")}

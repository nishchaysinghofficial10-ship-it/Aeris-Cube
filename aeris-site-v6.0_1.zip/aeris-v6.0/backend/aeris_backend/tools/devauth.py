"""Development identity fixture for exercising AERIS_AUTH=jwt on THIS computer (never for a public deployment).

    python -m aeris_backend.tools.devauth init  [--dir data/dev-auth]
    python -m aeris_backend.tools.devauth token --sub alice [--dir data/dev-auth] [--ttl 3600]
    python -m aeris_backend.tools.devauth env   [--dir data/dev-auth]     (the environment for the backend)

`init` creates an ECDSA P-256 key pair (private key PEM, mode 0600) and the public JWKS in --dir; `token` signs an
ES256 access token for a subject with issuer "aeris-dev-issuer" and audience "aeris-dev". The backend refuses tokens
of this issuer unless its public origin is a loopback origin (devices/auth.py), so the fixture cannot secure a
public site. The directory is git-ignored; nothing here ships credentials.
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import time
import uuid

ISSUER = "aeris-dev-issuer"
AUDIENCE = "aeris-dev"


def _b64(n: int, length: int) -> str:
    return base64.urlsafe_b64encode(n.to_bytes(length, "big")).rstrip(b"=").decode()


def init(d: str) -> dict:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    os.makedirs(d, exist_ok=True)
    key = ec.generate_private_key(ec.SECP256R1())
    pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    kp = os.path.join(d, "dev-issuer-key.pem")
    with open(kp, "wb") as f:
        f.write(pem)
    os.chmod(kp, 0o600)
    nums = key.public_key().public_numbers()
    kid = "dev-" + uuid.uuid4().hex[:12]
    jwks = {"keys": [{"kty": "EC", "crv": "P-256", "x": _b64(nums.x, 32), "y": _b64(nums.y, 32), "use": "sig", "alg": "ES256", "kid": kid}]}
    with open(os.path.join(d, "jwks.json"), "w", encoding="utf-8") as f:
        json.dump(jwks, f, indent=1)
    with open(os.path.join(d, "README.txt"), "w", encoding="utf-8") as f:
        f.write("AERIS development identity fixture: for AERIS_AUTH=jwt on localhost only. Never use these keys for a public deployment.\n")
    return {"dir": d, "kid": kid}


def token(d: str, sub: str, ttl: int = 3600) -> str:
    import jwt
    with open(os.path.join(d, "dev-issuer-key.pem"), "rb") as f:
        pem = f.read()
    kid = json.load(open(os.path.join(d, "jwks.json"), encoding="utf-8"))["keys"][0]["kid"]
    now = int(time.time())
    return jwt.encode({"iss": ISSUER, "aud": AUDIENCE, "sub": sub, "iat": now, "exp": now + ttl}, pem, algorithm="ES256", headers={"kid": kid})


def env(d: str) -> dict:
    return {"AERIS_AUTH": "jwt", "AERIS_JWT_ISSUER": ISSUER, "AERIS_JWT_AUDIENCE": AUDIENCE, "AERIS_JWT_JWKS_FILE": os.path.abspath(os.path.join(d, "jwks.json")),
            "AERIS_JWT_ALGORITHMS": "ES256", "AERIS_PUBLIC_ORIGIN": "http://127.0.0.1:8750"}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("cmd", choices=("init", "token", "env"))
    ap.add_argument("--dir", default="data/dev-auth")
    ap.add_argument("--sub", default="dev-user")
    ap.add_argument("--ttl", type=int, default=3600)
    a = ap.parse_args(argv)
    if a.cmd == "init":
        print(json.dumps(init(a.dir)))
    elif a.cmd == "token":
        print(token(a.dir, a.sub, a.ttl))
    else:
        for k, v in env(a.dir).items():
            print(f"export {k}={v}")


if __name__ == "__main__":
    main()

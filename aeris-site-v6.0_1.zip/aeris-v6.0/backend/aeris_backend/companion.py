"""aeris-companion: relays a cube's USB serial link to the AERIS backend (route "companion").

    python -m aeris_backend.companion --backend http://127.0.0.1:8750 --serial /dev/ttyACM0 [--pair --name "My cube"]
    python -m aeris_backend.companion --backend http://127.0.0.1:8750 --tcp 127.0.0.1:47201      (the synthetic device)

The companion is a pipe: it writes what the backend sends to the serial port unchanged and sends what the port reads
(aeris-device-link/1 bytes; the backend's link host frames, checks and interprets them). Because it is attached to the
cube's USB port, the device treats the session as LOCAL: it supervises, and a network session of the same device
becomes an observer. It never invents or edits link messages.

Authentication: in AERIS_AUTH=jwt mode the companion sends `Authorization: Bearer <token>` (--token-file, or the
AERIS_TOKEN environment variable); in local mode nothing is needed (the backend accepts this computer only).
Control messages from the backend (the device it sees, pairing progress) are printed as JSON lines on stdout.
--pair asks the backend to pair the device it sees with your account: press ARM on the cube when told to.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import threading
import urllib.parse


def relay_url(backend: str, route: str = "companion") -> str:
    u = urllib.parse.urlparse(backend.rstrip("/"))
    if u.scheme not in ("http", "https"):
        raise ValueError("--backend: http://… or https://…")
    scheme = "wss" if u.scheme == "https" else "ws"
    return f"{scheme}://{u.netloc}{u.path}/api/v6/relay?route={route}"


class SerialPort:
    """A blocking pyserial port read by a thread; bytes are handed to the event loop."""

    def __init__(self, device: str, loop, on_bytes):
        import serial                       # pyserial (pip install aeris-backend[companion])
        self.port = serial.Serial(device, 115200, timeout=0.05)
        self.loop, self.on_bytes = loop, on_bytes
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        while not self.stop.is_set():
            try:
                b = self.port.read(4096)
            except Exception as e:          # unplugged
                self.loop.call_soon_threadsafe(self.on_bytes, None, f"serial port error: {e}")
                return
            if b:
                self.loop.call_soon_threadsafe(self.on_bytes, b, None)

    async def write(self, b: bytes):
        await asyncio.get_running_loop().run_in_executor(None, self.port.write, b)

    def close(self):
        self.stop.set()
        try:
            self.port.close()
        except Exception:
            pass


class TcpPort:
    """The synthetic device's USB link over TCP (firmware/host/hostsim --usb-tcp PORT)."""

    def __init__(self, reader, writer, on_bytes):
        self.reader, self.writer, self.on_bytes = reader, writer, on_bytes
        self.task = asyncio.get_running_loop().create_task(self._run())

    @classmethod
    async def open(cls, hostport: str, on_bytes):
        host, port = hostport.rsplit(":", 1)
        r, w = await asyncio.open_connection(host, int(port))
        return cls(r, w, on_bytes)

    async def _run(self):
        while True:
            b = await self.reader.read(4096)
            if not b:
                self.on_bytes(None, "the device closed the connection")
                return
            self.on_bytes(b, None)

    async def write(self, b: bytes):
        self.writer.write(b)
        await self.writer.drain()

    def close(self):
        self.task.cancel()
        try:
            self.writer.close()
        except Exception:
            pass


async def run(args) -> int:
    from websockets.asyncio.client import connect
    token = None
    if args.token_file:
        with open(args.token_file, encoding="utf-8") as f:
            token = f.read().strip()
    token = token or os.environ.get("AERIS_TOKEN")
    headers = {"Authorization": "Bearer " + token} if token else {}
    loop = asyncio.get_running_loop()
    inbox: asyncio.Queue = asyncio.Queue()

    def on_bytes(b, err):
        inbox.put_nowait((b, err))

    port = SerialPort(args.serial, loop, on_bytes) if args.serial else await TcpPort.open(args.tcp, on_bytes)
    out = sys.stdout

    def say(obj):
        out.write(json.dumps(obj) + "\n")
        out.flush()

    try:
        async with connect(relay_url(args.backend), additional_headers=headers, max_size=2**20, open_timeout=10) as ws:
            say({"type": "companion", "status": "connected", "backend": args.backend})
            paired_asked = False

            async def from_device():
                while True:
                    b, err = await inbox.get()
                    if b is None:
                        say({"type": "companion", "status": "device_gone", "reason": err})
                        return 3
                    await ws.send(b)

            async def from_backend():
                nonlocal paired_asked
                from websockets.exceptions import ConnectionClosed
                try:
                    return await relay_messages()
                except ConnectionClosed:
                    say({"type": "companion", "status": "backend_closed", "code": ws.close_code, "reason": ws.close_reason})
                    return 5

            async def relay_messages():
                nonlocal paired_asked
                async for msg in ws:
                    if isinstance(msg, bytes):
                        await port.write(msg)
                        continue
                    try:
                        m = json.loads(msg)
                    except ValueError:
                        continue
                    say(m)
                    if args.pair and not paired_asked and m.get("type") == "device":
                        paired_asked = True
                        if m.get("paired_to_you"):
                            say({"type": "companion", "status": "already_paired", "device_id": m.get("device_id")})
                        else:
                            await ws.send(json.dumps({"op": "pair", "name": args.name}))
                    if args.pair and m.get("type") == "pairing" and m.get("status") in ("paired", "failed") and args.exit_after_pair:
                        return 0 if m["status"] == "paired" else 4
                say({"type": "companion", "status": "backend_closed", "code": ws.close_code, "reason": ws.close_reason})
                return 0

            tasks = [asyncio.create_task(from_device()), asyncio.create_task(from_backend())]
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for t in pending:
                t.cancel()
            rc = 0
            for t in done:
                if t.exception() is None and isinstance(t.result(), int):
                    rc = t.result()
            return rc
    finally:
        port.close()


def main(argv=None):
    ap = argparse.ArgumentParser(description="Relay a cube's USB serial link to the AERIS backend (route: companion).")
    ap.add_argument("--backend", default="http://127.0.0.1:8750", help="the backend's origin (https:// for a remote backend)")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--serial", help="the cube's serial port (e.g. /dev/ttyACM0, COM5)")
    src.add_argument("--tcp", help="HOST:PORT of a synthetic device's USB link (firmware/host aeris-hostsim --usb-tcp)")
    ap.add_argument("--token-file", help="a file holding the access token (jwt mode); or set AERIS_TOKEN")
    ap.add_argument("--pair", action="store_true", help="pair the device with your account (press ARM on the cube when asked)")
    ap.add_argument("--name", default=None, help="a name for the device when pairing")
    ap.add_argument("--exit-after-pair", action="store_true", help="exit when the pairing finished (exit code 0 when paired)")
    a = ap.parse_args(argv)
    try:
        sys.exit(asyncio.run(run(a)))
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    main()

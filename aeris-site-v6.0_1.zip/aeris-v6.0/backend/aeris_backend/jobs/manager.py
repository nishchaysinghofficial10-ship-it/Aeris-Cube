"""Job manager: runs simulations and sweeps in a process pool so the API event loop never does
CPU-heavy work, persists every state change, and keeps the aeris-job/1 rules:

  QUEUED → INITIALIZING → RUNNING (done / total) → ANALYZING → COMPLETE;  any non-terminal → FAILED | CANCELLED
  - progress.done only increases and only counts finished simulations; progress.total is fixed once RUNNING
  - terminal states never change (the repository enforces it)
  - CANCELLED keeps finished runs: result_ref names the (partial) sweep, or the run of a single job
  - every update increments job.seq; WebSocket messages carry it so clients can drop stale/duplicate updates

Persistence boundaries (docs/JOBS_AND_RECOVERY.md):
  single run  the identifiers (experiment and run id) are stored with the → RUNNING transition; the run
              record, progress done = 1, result_ref and → ANALYZING are ONE transaction
              (Repository.save_single_result); → COMPLETE follows. A job never has two runs.
  sweep       each row and its run record (store_runs) are ONE transaction; rows are keyed by their index,
              so a row is never stored twice; run ids of sweep rows are derived from (sweep id, row index);
              → ANALYZING only after every row is stored; the analysis is a deterministic function of the rows.

Restart recovery (recover(), at start-up, before dispatching), for every non-terminal job:
  single, run saved          finish it: the legal path to COMPLETE (or CANCELLED if cancellation had been
                             requested), result_ref = the saved run. Nothing is recomputed. (Both policies.)
  single, ANALYZING, no run  impossible under the rules above: FAILED with code 'inconsistent_state'.
  single, no run             resume: recomputed with the stored identifiers; fail: FAILED 'interrupted'.
  sweep, ANALYZING           all rows are stored: the analysis is computed again from them (both policies).
  sweep, earlier state       resume: continues, skipping stored rows; fail: FAILED 'interrupted', the sweep is
                             marked interrupted and partial (its analysis can be computed on request).
  cancellation requested     the job ends CANCELLED (finished work kept), whatever the policy.
Every dispatch is counted (jobs.attempts, persisted); a job dispatched more than AERIS_MAX_JOB_ATTEMPTS
times (default 3; e.g. a job that crashes the process at every restart) is FAILED with code 'retry_limit'.
Errors are never swallowed: an exception in a job handler becomes a FAILED job with the error code and
message; if even that cannot be written, the job is quarantined for this process (never re-dispatched)
and reported by /health. A job handler that returns without reaching a terminal state is FAILED
('not_finalized').

Cancellation is cooperative: each running job owns a slot in a shared byte array; workers check
it every 1024 integration steps and stop with termination reason 'cancelled' (such a run is not
counted as a finished run). Queued work is dropped immediately.

Deterministic fault injection (tests; docs/JOBS_AND_RECOVERY.md): fault_hook(point, job_id, info) is called
at every persistence boundary; with AERIS_ALLOW_FAULT_INJECTION=1 the environment variable
AERIS_FAULT_INJECT="point[@n][,point…]:exit|raise" makes the process exit (os._exit(86), like a crash)
or raise at the n-th occurrence of that point.
"""
from __future__ import annotations

import asyncio
import concurrent.futures as cf
import logging
import multiprocessing as mp
import os
import threading
import time
import traceback
import uuid

from ..config.validate import validate_config
from ..experiments import sweeps as SW
from ..experiments.records import build_record, jsonable, now_iso
from ..storage.base import PATH_TO_COMPLETE, TERMINAL, IntegrityError, TransitionError
from ..version import BACKEND_NAME, ENGINE_VERSION

log = logging.getLogger("aeris.jobs")

SLOTS = 256
_FLAGS = None
FAULT_POINTS = ("single.before_compute", "single.before_save", "single.after_save", "single.before_complete",
                "sweep.row_saved", "sweep.before_analyzing", "sweep.after_analyzing", "sweep.analysis_saved",
                "recover.before_finalize")
ROW_RUN_NS = uuid.UUID("5c0f2d4e-7a61-4c38-9d0b-3a1f2e6b8c90")


def _init_worker(flags, parent_pid=None):
    global _FLAGS
    _FLAGS = flags
    if parent_pid:
        threading.Thread(target=_watch_parent, args=(parent_pid,), daemon=True, name="aeris-parent-watch").start()


def _watch_parent(parent_pid, period_s=0.5):
    """A worker exits when its backend process is gone (killed or crashed) instead of lingering as an orphan that
    holds memory and keeps computing work nobody will collect; the restarted backend starts its own workers and
    recovers the jobs from the database (docs/JOBS_AND_RECOVERY.md). POSIX: the orphan is re-parented, so its
    parent id changes. (On Windows the parent id does not change; there the pool's own shutdown applies.)"""
    while True:
        time.sleep(period_s)
        if os.getppid() != parent_pid:
            os._exit(0)


def _cancelled(slot):
    return _FLAGS is not None and _FLAGS[slot] == 1


def row_run_id(sweep_id: str, index: int) -> str:
    """Stable run id of a sweep row (the same after any restart)."""
    return "run-" + uuid.uuid5(ROW_RUN_NS, f"{sweep_id}#{index}").hex


def work_single(slot, cfg, meta, ids):
    """Worker: one simulation → aeris-run/1 record (or the invalid/cancelled result)."""
    from ..simulation import simulate
    try:
        res = simulate(cfg, cancel_check=lambda: _cancelled(slot))
        if res.get("cancelled"):
            return {"status": "cancelled"}
        if not res["ok"]:
            return {"status": "invalid", "errors": jsonable(res["errors"]), "outcome": jsonable(res["outcome"]), "termination": jsonable(res.get("termination"))}
        rec = build_record(res, meta, experiment_id=ids.get("experiment_id"), run_id=ids.get("run_id"),
                           parameter_set=ids.get("parameter_set"), seed_strategy=ids.get("seed_strategy"))
        return {"status": "ok", "record": rec}
    except Exception as ex:  # noqa: BLE001 - reported to the client as a failed run, never hidden
        return {"status": "error", "error": f"{type(ex).__name__}: {ex}", "trace": traceback.format_exc(limit=6)}


def work_row(slot, spec, store_run, ids, parameter_set):
    from ..simulation import simulate
    if spec.get("out_of_range"):
        return {"status": "ok", "row": jsonable(SW.row_of(spec, None)), "record": None, "index": spec["index"]}
    try:
        res = simulate(spec["config"], cancel_check=lambda: _cancelled(slot))
        if res.get("cancelled"):
            return {"status": "cancelled", "index": spec["index"]}
        rec = None
        if store_run and res["ok"]:
            rec = build_record(res, {"name": f"Sweep {ids['sweep_id']} · run {spec['index']}"}, experiment_id=None, run_id=ids.get("run_id"),
                               parameter_set=parameter_set, seed_strategy={"kind": "sweep", "sweep_id": ids["sweep_id"], "row": spec["index"]})
        row = SW.row_of(spec, res, run_id=rec["id"] if rec else None)
        if (parameter_set or {}).get("values") and res.get("ok"):
            from ..experiments.provenance import coverage
            cov = coverage(res["config"], parameter_set)
            row["parameters"] = {"set": parameter_set["id"], "status": cov["status"], "overridden": cov["overridden"], "nominal_inputs": len(cov["nominal"])}
        return {"status": "ok", "row": jsonable(row), "record": rec, "index": spec["index"]}
    except Exception as ex:  # noqa: BLE001
        return {"status": "ok", "row": jsonable(SW.row_of(spec, None, error=f"{type(ex).__name__}: {ex}")), "record": None, "index": spec["index"]}


def work_analyze(defn, rows):
    return jsonable(SW.analyze(defn, rows))


class SimulatedCrash(BaseException):
    """Raised by test fault hooks: stops a job handler at a persistence boundary without any cleanup
    write (as a process crash would). BaseException, so no `except Exception` handler catches it."""


def env_fault_hook():
    """AERIS_FAULT_INJECT (only with AERIS_ALLOW_FAULT_INJECTION=1): 'point[@n][,point[@n]…]:exit|raise'."""
    spec = os.environ.get("AERIS_FAULT_INJECT")
    if not spec or os.environ.get("AERIS_ALLOW_FAULT_INJECTION") != "1":
        return None
    points, _, action = spec.partition(":")
    want = {}
    for p in points.split(","):
        name, _, nth = p.strip().partition("@")
        if name not in FAULT_POINTS:
            raise ValueError(f"unknown fault point {name!r}; known: {', '.join(FAULT_POINTS)}")
        want[name] = int(nth) if nth else 1
    seen = {}

    def hook(point, job_id, info=None):
        if point not in want:
            return
        seen[point] = seen.get(point, 0) + 1
        if seen[point] != want[point]:
            return
        log.warning("fault injection: %s at %s (job %s)", action or "exit", point, job_id)
        if action == "raise":
            raise RuntimeError(f"injected fault at {point}")
        os._exit(86)
    return hook


def _retrieve(fut):
    """Mark a finished future's exception as retrieved (used when a sweep stops because the pool broke)."""
    if not fut.cancelled():
        fut.exception()


class JobManager:
    def __init__(self, repo, *, workers: int | None = None, max_jobs: int = 2, restart_policy: str | None = None,
                 limits: dict | None = None, parameter_set: dict | None = None, start_method: str = "spawn",
                 fault_hook=None, max_attempts: int | None = None):
        self.repo = repo
        self.workers = workers or max(1, min(4, (os.cpu_count() or 2)))
        self.max_jobs = max_jobs
        self.restart_policy = restart_policy or os.environ.get("AERIS_RESTART_POLICY", "resume")
        if self.restart_policy not in ("resume", "fail"):
            raise ValueError("restart_policy must be 'resume' or 'fail'")
        self.limits = limits or {}
        self.parameter_set = parameter_set or {"id": "nominal-design-v1", "status": "nominal"}
        self.ctx = mp.get_context(start_method)
        self.flags = self.ctx.Array("b", SLOTS, lock=False)
        self.free_slots = list(range(SLOTS))
        self.slots = {}
        self.pool = None
        self.subs: dict[str, list] = {}
        self.cancel_events: dict[str, asyncio.Event] = {}
        self.done_events: dict[str, asyncio.Event] = {}
        self.active: dict[str, asyncio.Task] = {}
        self.quarantine: dict[str, str] = {}
        self.wake = None
        self.loop = None
        self.dispatcher = None
        self.fault_hook = fault_hook if fault_hook is not None else env_fault_hook()
        self.max_attempts = max_attempts or int(os.environ.get("AERIS_MAX_JOB_ATTEMPTS", "3"))
        self.recovery_report = {"at": None, "policy": self.restart_policy, "jobs": []}
        self.stats = {"runs_completed": 0, "steps_completed": 0, "wall_s": 0.0}
        self.queue_limit = int(os.environ.get("AERIS_SUBSCRIBER_QUEUE", "256"))

    # ------------------------------------------------------------------ lifecycle
    def _new_pool(self):
        return cf.ProcessPoolExecutor(max_workers=self.workers, mp_context=self.ctx, initializer=_init_worker, initargs=(self.flags, os.getpid()))

    async def start(self):
        self.loop = asyncio.get_running_loop()
        self.wake = asyncio.Event()
        self.pool = self._new_pool()
        self.recover()
        self.dispatcher = asyncio.create_task(self._dispatch())

    async def stop(self):
        if self.dispatcher:
            self.dispatcher.cancel()
        for t in list(self.active.values()):
            t.cancel()
        if self.pool:
            self.pool.shutdown(wait=False, cancel_futures=True)

    def _point(self, name, job_id, info=None):
        if self.fault_hook is not None:
            self.fault_hook(name, job_id, info)

    # ------------------------------------------------------------------ restart recovery
    def recover(self):
        """Reconcile jobs left unfinished by a previous process (module docstring). Returns the report."""
        report = []
        for job in self.repo.list_jobs(states=["queued", "initializing", "running", "analyzing"], limit=100000):
            try:
                action = self._recover_one(job)
            except SimulatedCrash:
                raise
            except Exception as ex:  # noqa: BLE001 - never silently skip a job
                log.exception("restart recovery of job %s failed", job["id"])
                action = self._fail_visible(job["id"], "recovery_error", f"Restart recovery failed: {type(ex).__name__}: {ex}")
            if action:
                report.append({"job": job["id"], "kind": job["kind"], "state_before": job["state"], "action": action})
        self.recovery_report = {"at": now_iso(), "policy": self.restart_policy, "jobs": report}
        for r in report:
            log.info("restart recovery: job %s (%s, was %s): %s", r["job"], r["kind"], r["state_before"], r["action"])
        return self.recovery_report

    def _recover_one(self, job):
        jid, state = job["id"], job["state"]
        if state == "queued":
            return None
        if job["kind"] != "sweep":
            run_id = self.repo.run_for_job(jid)
            if run_id is not None:
                self._point("recover.before_finalize", jid)
                runs = self.repo.runs_of_job(jid) if hasattr(self.repo, "runs_of_job") else [run_id]
                extra = f" {len(runs)} runs were saved for this job before v5; the first is its result, the others are kept." if len(runs) > 1 else ""
                self._finalize_single(jid, run_id, "Completed after a backend restart: the run had been saved before the interruption; nothing was recomputed." + extra)
                return "finalized (run saved before the restart)"
            if state == "analyzing":
                self._fail_visible(jid, "inconsistent_state", "The job was 'analyzing' but no run is saved for it; it cannot be finished. Submit the configuration again.")
                return "failed: inconsistent_state"
            if job["cancel_requested"]:
                self._finish_cancel(jid, "Cancelled (requested before the backend restarted); no run had been saved.")
                return "cancelled (requested before the restart)"
            if self.restart_policy == "fail":
                self._update(jid, state="failed", error={"code": "interrupted", "message": f"The backend restarted while this job was {state}; no run had been saved.", "retryable": True},
                             message="Interrupted by a backend restart (restart policy 'fail').")
                return "failed: interrupted"
            self._update(jid, restarts=job.get("restarts", 0) + 1,
                         message=f"Resumed after a backend restart at {now_iso()}: the run is recomputed with its stored identifiers.")
            return "resumed (recompute)"
        # sweeps
        ref = job.get("result_ref") or {}
        stored = len(self.repo.row_indices(ref["id"])) if ref.get("kind") == "sweep" else 0
        total = job["progress"]["total"]
        if job["cancel_requested"]:
            self._update(jid, message="Cancellation was requested before the backend restarted; finishing as cancelled.")
            return "cancel pending (dispatched to finish as cancelled)"
        if state == "analyzing":
            self._update(jid, restarts=job.get("restarts", 0) + 1,
                         message=f"Resumed after a backend restart at {now_iso()}: all {stored} runs are stored; the analysis is computed from them.")
            return "resumed (analysis from stored rows)"
        if self.restart_policy == "fail":
            self._update(jid, state="failed", error={"code": "interrupted", "message": f"The backend restarted while this job was {state}; {stored} finished run(s) were kept.", "retryable": True},
                         message=f"Interrupted by a backend restart ({stored} of {total} runs stored).")
            if ref.get("kind") == "sweep":
                self.repo.update_sweep(ref["id"], status="interrupted", partial=True)
            return "failed: interrupted"
        self._update(jid, restarts=job.get("restarts", 0) + 1,
                     message=f"Resumed after a backend restart at {now_iso()}: {stored} of {total} runs were already stored; the rest are computed.")
        return "resumed (continue sweep)"

    def _walk_to(self, job_id, target, **final_kw):
        """Apply the legal transitions from the current state to target ('complete'), the last one with final_kw."""
        j = self.repo.get_job(job_id)
        if j["state"] == target:
            return j
        path = PATH_TO_COMPLETE[j["state"]]
        for st in path:
            kw = dict(final_kw) if st == target else {}
            if st == "running":
                kw.setdefault("progress", {"total": max(1, j["progress"]["total"]), "done": 0})
            j = self._update(job_id, state=st, **kw)
            if st == target:
                break
        return j

    def _finalize_single(self, job_id, run_id, message):
        j = self.repo.get_job(job_id)
        ref = {"kind": "run", "id": run_id}
        if j["cancel_requested"]:
            return self._finish_cancel(job_id, "Cancelled during analysis; the finished run is kept.", ref=ref)
        if j["state"] in ("queued", "initializing", "running"):
            if j["state"] != "running":
                self._walk_to(job_id, "running")
            self._update(job_id, state="analyzing", progress={"done": 1}, result_ref=ref, message="Assessing the run.")
        rec = self.repo.get_run(run_id) or {}
        label = (rec.get("outcome") or {}).get("label", "")
        return self._update(job_id, state="complete", result_ref=ref, progress={"done": 1},
                            message=message if message else f"Finished: {rec.get('experiment_id') or run_id} ({label}).")

    # ------------------------------------------------------------------ submission
    def submit_simulation(self, config, meta=None, *, kind="single", extra=None, parameter_set=None) -> dict:
        v = validate_config(config, self.limits)
        if not v.ok:
            raise InvalidRequest("invalid_config", "The configuration is not valid.", v.errors, v.warnings)
        extra = dict(extra or {})
        if parameter_set:
            extra["parameter_set"] = parameter_set
        job = {"id": "job-" + uuid.uuid4().hex[:16], "kind": kind, "created": now_iso(), "total": 1,
               "message": "Waiting to start.", "request": {"config": v.config, "meta": meta or {}, "workload": v.workload}, "extra": extra}
        j = self.repo.create_job(job)
        self._kick()
        return j

    def submit_sweep(self, definition, parameter_set=None) -> dict:
        vr = SW.validate_def(definition, self.limits)
        if not vr["ok"]:
            raise InvalidRequest("invalid_sweep", "The sweep is not valid.", vr["errors"], vr["warnings"])
        d = vr["def"]
        # the backend numbers its own sweeps (AERIS-SWP-1xxxxx); an id chosen by a client is kept only as a reference
        client_ref = d.get("id") if isinstance(d.get("id"), str) and d.get("id") else None
        sid = "AERIS-SWP-%06d" % self.repo.next_id("sweep")
        d["id"] = sid
        if client_ref and client_ref != sid:
            d["client_ref"] = client_ref
        job_id = "job-" + uuid.uuid4().hex[:16]
        ps = parameter_set or self.parameter_set
        from ..experiments.provenance import canonical_path
        measured_paths = {canonical_path(k) for k in (ps.get("values") or {})}
        var_paths = [SW.variable_config_path(v) for v in d["variables"]]
        overridden = sorted({p for p in var_paths if p and any(p == m or p.startswith(m + ".") or m.startswith(p + ".") for m in measured_paths)})
        sweep_status = "measured" if ps.get("status") == "measured" and not overridden else "nominal"
        self.repo.create_sweep({"id": sid, "created": now_iso(), "name": d.get("name") or "Research sweep", "job_id": job_id, "status": "queued",
                                "total": vr["total"], "definition": d, "engine": {"engine": BACKEND_NAME, "engine_version": ENGINE_VERSION, "adapter": "research-api"},
                                "provenance": {"source": "simulation", "demo": False, "mock": False, "validation": {"status": sweep_status, "parameter_set": ps["id"],
                                                                                                                  "overridden_by_variables": overridden,
                                                                                                                  "note": "Each row reports its own parameter coverage (row.parameters)." + (f" The sweep varies measured inputs ({', '.join(overridden)}): rows that change them are NOMINAL." if overridden else "")},
                                               "parameter_set": ps,
                                               "note": "Computed by the AERIS research backend on nominal (unvalidated) parameters unless a measured parameter set is named. Recovery rates are simulated, not hardware reliability."},
                                "extra": {"workload": vr["workload"], "warnings": vr["warnings"], "seed_strategy": {"name": d["seed_strategy"], "text": SW.SEED_STRATEGIES[d["seed_strategy"]]},
                                          "distributions": {v.get("key") or v.get("path"): SW.DISTRIBUTIONS[v["dist"]] for v in d["variables"]},
                                          "sampling_notes": d.get("sampling_notes") or []}})
        job = {"id": job_id, "kind": "sweep", "created": now_iso(), "total": vr["total"], "message": "Waiting to start.",
               "request": {"sweep_id": sid}, "extra": {"workload": vr["workload"]}}
        self.repo.create_job(job)
        j = self.repo.update_job(job_id, result_ref={"kind": "sweep", "id": sid})
        self._kick()
        return j

    def _kick(self):
        if self.loop is not None and self.wake is not None:
            self.loop.call_soon_threadsafe(self.wake.set)

    # ------------------------------------------------------------------ cancellation
    async def cancel(self, job_id: str, wait_s: float = 5.0) -> dict | None:
        job = self.repo.get_job(job_id)
        if job is None:
            return None
        if job["state"] in TERMINAL:
            return job
        if job["state"] == "queued" and job_id not in self.active:
            try:
                job = self.repo.update_job(job_id, state="cancelled", message="Cancelled before it started; no runs were computed.", cancel_requested=1)
            except TransitionError:
                return self.repo.get_job(job_id)
            ref = job.get("result_ref")
            if ref and ref.get("kind") == "sweep":
                self.repo.update_sweep(ref["id"], status="cancelled", partial=True)
            self._publish(job)
            return job
        try:
            self.repo.update_job(job_id, cancel_requested=1, message="Cancellation requested; stopping the running simulations.")
        except TransitionError:        # it reached a terminal state in the meantime: that state stands
            return self.repo.get_job(job_id)
        self._publish(self.repo.get_job(job_id))
        slot = self.slots.get(job_id)
        if slot is not None:
            self.flags[slot] = 1
        ev = self.cancel_events.get(job_id)
        if ev:
            ev.set()
        done = self.done_events.get(job_id)
        if done:
            try:
                await asyncio.wait_for(done.wait(), timeout=wait_s)
            except asyncio.TimeoutError:
                pass
        else:
            self._kick()
        return self.repo.get_job(job_id)

    # ------------------------------------------------------------------ live updates
    def subscribe(self, job_id: str) -> asyncio.Queue:
        """A bounded queue of updates. A subscriber that falls behind loses intermediate job updates
        (the newest state is always delivered: it replaces the oldest queued message) and log lines."""
        q = asyncio.Queue(maxsize=self.queue_limit)
        self.subs.setdefault(job_id, []).append(q)
        return q

    def unsubscribe(self, job_id: str, q):
        lst = self.subs.get(job_id) or []
        if q in lst:
            lst.remove(q)
        if not lst:
            self.subs.pop(job_id, None)

    @staticmethod
    def _offer(q, msg, droppable):
        if q.full():
            if droppable:
                return
            try:
                q.get_nowait()          # drop the oldest message; job updates carry the full state, so none is needed later
            except asyncio.QueueEmpty:
                pass
        q.put_nowait(msg)

    def _publish(self, job):
        for q in list(self.subs.get(job["id"], [])):
            self._offer(q, {"type": "job", "seq": job["seq"], "job": job}, droppable=False)

    def _update(self, job_id, **kw):
        j = self.repo.update_job(job_id, **kw)
        self._publish(j)
        return j

    def log(self, job_id, text, level="info"):
        for q in list(self.subs.get(job_id, [])):
            self._offer(q, {"type": "log", "level": level, "text": text}, droppable=True)

    # ------------------------------------------------------------------ dispatcher
    async def _dispatch(self):
        while True:
            try:
                await asyncio.wait_for(self.wake.wait(), timeout=1.0)
            except asyncio.TimeoutError:
                pass
            self.wake.clear()
            for t in [k for k, v in self.active.items() if v.done()]:
                del self.active[t]
            if len(self.active) >= self.max_jobs:
                continue
            pending = self.repo.list_jobs(states=["queued", "initializing", "running", "analyzing"], limit=1000)
            for job in pending:
                if len(self.active) >= self.max_jobs:
                    break
                if job["id"] in self.active or job["id"] in self.quarantine:
                    continue
                self.active[job["id"]] = asyncio.create_task(self._execute(job["id"]))

    def _fail_visible(self, job_id, code, message, retryable=False):
        """Record an unexpected condition as a FAILED job (never swallowed). Returns a short action text."""
        log.error("job %s failed: %s: %s", job_id, code, message)
        try:
            j = self.repo.get_job(job_id)
            if j is None:
                return "unknown job"
            if j["state"] in TERMINAL:
                return f"already {j['state']}"
            self._update(job_id, state="failed", error={"code": code, "message": message, "retryable": retryable}, message="Failed: " + message)
            ref = j.get("result_ref") or {}
            if ref.get("kind") == "sweep":
                self.repo.update_sweep(ref["id"], status="failed", partial=True)
            return f"failed: {code}"
        except SimulatedCrash:
            raise
        except Exception as ex:  # noqa: BLE001 - the database refused the failure itself: keep the job out of dispatch
            log.exception("could not record the failure of job %s", job_id)
            self.quarantine[job_id] = f"{code}: {message} (recording the failure failed: {type(ex).__name__}: {ex})"
            return "quarantined"

    async def _execute(self, job_id):
        slot = self.free_slots.pop(0)
        self.flags[slot] = 0
        self.slots[job_id] = slot
        self.cancel_events[job_id] = asyncio.Event()
        self.done_events[job_id] = asyncio.Event()
        try:
            attempts = self.repo.increment_attempts(job_id)
            job = self.repo.get_job(job_id)
            if job["state"] in TERMINAL:
                return
            if attempts > self.max_attempts:
                self._fail_visible(job_id, "retry_limit", f"The job was dispatched {attempts} times without finishing (limit {self.max_attempts}); it is not retried again.", retryable=True)
                return
            if job["cancel_requested"]:
                self.cancel_events[job_id].set()
                self.flags[slot] = 1
            if job["kind"] == "sweep":
                await self._run_sweep(job, slot)
            else:
                await self._run_single(job, slot)
            j = self.repo.get_job(job_id)
            if j is not None and j["state"] not in TERMINAL:
                self._fail_visible(job_id, "not_finalized", f"The job handler returned while the job was {j['state']} (an internal error).")
        except SimulatedCrash:
            raise
        except asyncio.CancelledError:
            raise
        except cf.process.BrokenProcessPool as ex:
            self._replace_pool()
            self._fail_visible(job_id, "worker_crashed", f"A simulation worker process terminated unexpectedly ({ex}); stored results are kept.", retryable=True)
        except TransitionError as ex:
            j = self.repo.get_job(job_id)
            if j is not None and j["state"] in TERMINAL:
                log.info("job %s reached %s concurrently: %s", job_id, j["state"], ex)
            else:
                self._fail_visible(job_id, "illegal_transition", str(ex))
        except IntegrityError as ex:
            self._fail_visible(job_id, "inconsistent_state", str(ex))
        except Exception as ex:  # noqa: BLE001
            log.exception("job %s raised", job_id)
            self._fail_visible(job_id, "internal", f"{type(ex).__name__}: {ex}")
        finally:
            self.flags[slot] = 0
            self.free_slots.append(slot)
            self.slots.pop(job_id, None)
            ev = self.done_events.pop(job_id, None)
            if ev:
                ev.set()
            self.cancel_events.pop(job_id, None)
            self._kick()

    def _replace_pool(self):
        old = self.pool
        self.pool = self._new_pool()
        try:
            old.shutdown(wait=False, cancel_futures=True)
        except Exception:  # noqa: BLE001
            pass

    def _cancel_requested(self, job_id):
        ev = self.cancel_events.get(job_id)
        return ev is not None and ev.is_set()

    # ------------------------------------------------------------------ single runs
    async def _run_single(self, job, slot):
        job_id = job["id"]
        req = self.repo.get_job_request(job_id)
        saved = self.repo.run_for_job(job_id)
        if saved is not None:          # finished and saved before an interruption: finish without recomputing
            return self._finalize_single(job_id, saved, "Completed: the run had been saved before; nothing was recomputed.")
        if job["state"] == "analyzing":
            raise IntegrityError("the job is 'analyzing' but no run is saved for it")
        if job["state"] == "queued":
            self._update(job_id, state="initializing", message="Validating the configuration.")
        if self._cancel_requested(job_id):
            return self._finish_cancel(job_id, "Cancelled before the simulation started; no run was computed.")
        extra = dict(self.repo.get_job(job_id).get("extra") or {})
        ids = extra.get("ids")
        if not ids:
            ids = {"experiment_id": "AERIS-EXP-%06d" % self.repo.next_id("experiment"), "run_id": "run-" + uuid.uuid4().hex}
            extra["ids"] = ids
            self._update(job_id, state="running", message="Simulating.", progress={"total": 1, "done": 0}, extra=extra)
        else:
            self._update(job_id, state="running", message="Simulating (resumed with the stored identifiers).", progress={"total": 1})
        wids = dict(ids, parameter_set=extra.get("parameter_set") or self.parameter_set, seed_strategy=extra.get("seed_strategy"))
        meta = dict(req.get("meta") or {})
        t0 = self.loop.time()
        self._point("single.before_compute", job_id)
        out = await self.loop.run_in_executor(self.pool, work_single, slot, req["config"], meta, wids)
        if out["status"] == "cancelled" or self._cancel_requested(job_id):
            return self._finish_cancel(job_id, "Cancelled while simulating; the unfinished run was discarded.")
        if out["status"] == "invalid":
            return self._update(job_id, state="failed", progress={"done": 1, "failed": 1},
                                error={"code": "invalid_config" if (out.get("termination") or {}).get("reason") == "invalid_config" else "simulation_invalid",
                                       "message": out["outcome"]["reason"], "details": out.get("errors") or [], "retryable": False})
        if out["status"] == "error":
            return self._update(job_id, state="failed", progress={"done": 1, "failed": 1}, error={"code": "simulation_error", "message": out["error"], "retryable": False})
        rec = out["record"]
        if extra.get("reproduction_of"):
            rec = self._attach_reproduction(rec, extra["reproduction_of"], extra.get("config_changes") or [])
        if extra.get("lineage"):
            rec["lineage"] = extra["lineage"]
            if extra["lineage"].get("relation") == "reanalysis":
                rec["name"] = meta.get("name") or rec["name"]
        elif extra.get("retry_of"):
            rec["lineage"] = {"relation": "retry", "retry_of_job": extra["retry_of"]}
        if extra.get("twin"):
            rec["twin"] = extra["twin"]       # v6.0: a simulation of a device profile (Simulate My Cube); the record says which
        if extra.get("owner"):
            rec["owner"] = extra["owner"]     # v6.0: owned runs are visible to their owner only (jwt mode)
        self._point("single.before_save", job_id)
        j, run_id, inserted = self.repo.save_single_result(job_id, rec, message="Assessing the run.")
        self._publish(j)
        self._point("single.after_save", job_id)
        if inserted:
            self.stats["runs_completed"] += 1
            self.stats["wall_s"] += self.loop.time() - t0
            self.stats["steps_completed"] += int(rec["executed"].get("steps") or 0)
        if self._cancel_requested(job_id):
            return self._finish_cancel(job_id, "Cancelled during analysis; the finished run is kept.", ref={"kind": "run", "id": run_id})
        self._point("single.before_complete", job_id)
        self._update(job_id, state="complete", result_ref={"kind": "run", "id": run_id}, message=f"Finished: {rec['experiment_id']} ({rec['outcome']['label']}).")

    def _attach_reproduction(self, rec, orig_id, config_changes):
        from ..experiments.reproduce import compare_reproduction
        orig = self.repo.get_run(orig_id)
        rep = compare_reproduction(orig, rec, orig_id)
        rep["config_changes"] = config_changes
        if config_changes and rep.get("verdict") == "different":
            rep["explanations"] = rep.get("explanations", []) + ["configuration changed for the reproduction: " + ", ".join(c["path"] for c in config_changes)]
        rec["reproduction"]["reproduces"] = rep
        rec["name"] = "Reproduction of " + ((orig or {}).get("experiment_id") or orig_id)
        return rec

    def _finish_cancel(self, job_id, message, ref=None):
        kw = {"state": "cancelled", "message": message}
        if ref:
            kw["result_ref"] = ref
        try:
            return self._update(job_id, **kw)
        except TransitionError:
            return self.repo.get_job(job_id)

    # ------------------------------------------------------------------ sweeps
    async def _run_sweep(self, job, slot):
        job_id = job["id"]
        sid = job["result_ref"]["id"]
        sw = self.repo.get_sweep(sid, with_rows=False)
        d = sw["definition"]
        total = sw["total"]
        state = job["state"]
        if state == "analyzing":
            return await self._analyze_sweep(job_id, sid, d, total, resumed=True)
        if state == "queued":
            self._update(job_id, state="initializing", message="Expanding the sweep into runs.")
        if self._cancel_requested(job_id):
            return await self._cancel_sweep(job_id, sid, d, total)
        self.repo.update_sweep(sid, status="running")
        specs = await self.loop.run_in_executor(None, SW.expand, d)
        if len(specs) != total:
            raise IntegrityError(f"the sweep expands to {len(specs)} runs, but {total} were planned (definition changed?)")
        if self._cancel_requested(job_id):
            return await self._cancel_sweep(job_id, sid, d, total)
        if self.repo.get_job(job_id)["state"] == "initializing":
            self._update(job_id, state="running", progress={"total": total, "done": 0}, message=f"Simulating {total} runs.")
        done_idx = self.repo.row_indices(sid)
        todo = [s for s in specs if s["index"] not in done_idx]
        store = bool(d.get("store_runs"))
        window = max(1, self.workers * 2)
        pending: set = set()
        it = iter(todo)
        rows_now = self.repo.sweep_rows(sid) if done_idx else []
        failed_n = sum(1 for r in rows_now if r["status"] != "ok" or r["outcome"] == "invalid")
        done_n = len(done_idx)
        if done_idx:
            self._update(job_id, progress={"done": done_n, "failed": failed_n})
        pset = (sw.get("provenance") or {}).get("parameter_set") or self.parameter_set
        while True:
            while len(pending) < window and not self._cancel_requested(job_id):
                sp = next(it, None)
                if sp is None:
                    break
                ids = {"sweep_id": sid, "run_id": row_run_id(sid, sp["index"]) if store else None}
                fut = self.loop.run_in_executor(self.pool, work_row, slot, sp, store, ids, pset)
                fut.spec = sp
                pending.add(fut)
            if not pending:
                break
            finished, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED, timeout=0.5)
            for f in finished:
                if not f.cancelled() and f.exception() is not None:
                    # e.g. a broken process pool: every other future fails the same way; retrieve their exceptions
                    # (no 'never retrieved' noise) and let the job fail with this one, visibly
                    for g in pending | finished:
                        g.add_done_callback(_retrieve)
                    raise f.exception()
                out = f.result()
                if out["status"] == "cancelled":
                    continue
                d_n, f_n = self._store_row(job_id, sid, out, f.spec)
                done_n += d_n
                failed_n += f_n
            if finished:
                self._update(job_id, progress={"done": done_n, "failed": failed_n})
            if self._cancel_requested(job_id):
                for f in pending:
                    f.cancel()
                # in-flight runs see the flag and return quickly; collect them so nothing is written after the job ends
                if pending:
                    rest, _ = await asyncio.wait(pending, timeout=10)
                    for f in rest:
                        if not f.cancelled() and f.exception() is None:
                            out = f.result()
                            if out["status"] == "ok":
                                d_n, f_n = self._store_row(job_id, sid, out, f.spec)
                                done_n += d_n
                                failed_n += f_n
                    self._update(job_id, progress={"done": done_n, "failed": failed_n})
                return await self._cancel_sweep(job_id, sid, d, total)
        if self._cancel_requested(job_id):
            return await self._cancel_sweep(job_id, sid, d, total)
        stored = self.repo.row_indices(sid)
        if len(stored) != total:
            raise IntegrityError(f"{len(stored)} of {total} rows are stored after the last run finished")
        self._point("sweep.before_analyzing", job_id)
        self._update(job_id, state="analyzing", progress={"done": total}, message="Computing maps, distributions and statistics from the saved rows.")
        self._point("sweep.after_analyzing", job_id)
        return await self._analyze_sweep(job_id, sid, d, total, resumed=False)

    def _store_row(self, job_id, sid, out, spec):
        row = out["row"]
        rec = out.get("record")
        if self.repo.add_sweep_row(sid, row, spec["config"], record=rec, job_id=job_id):
            self._point("sweep.row_saved", job_id, {"index": row["index"]})
            return 1, (1 if (row["status"] != "ok" or row["outcome"] == "invalid") else 0)
        return 0, 0

    async def _analyze_sweep(self, job_id, sid, d, total, resumed):
        rows = self.repo.sweep_rows(sid)
        if len(rows) != total:
            raise IntegrityError(f"the sweep is being analysed with {len(rows)} of {total} rows stored")
        self.repo.update_sweep(sid, status="analyzing")
        fut = self.loop.run_in_executor(self.pool, work_analyze, d, rows)
        cancel_wait = asyncio.create_task(self.cancel_events[job_id].wait())
        doneset, _ = await asyncio.wait({fut, cancel_wait}, return_when=asyncio.FIRST_COMPLETED)
        if cancel_wait in doneset and not fut.done():
            fut.cancel()
            self.repo.update_sweep(sid, status="cancelled", partial=False, extra_merge={"analysis_cancelled": True})
            return self._finish_cancel(job_id, f"Cancelled during analysis: all {total} runs finished and are kept; the analysis was not computed (it can be recomputed from the rows).")
        cancel_wait.cancel()
        analysis = fut.result()
        self.repo.update_sweep(sid, status="complete", partial=False, analysis=analysis)
        self._point("sweep.analysis_saved", job_id)
        failed_n = sum(1 for r in rows if r["status"] != "ok" or r["outcome"] == "invalid")
        self._update(job_id, state="complete", message=f"Finished {total} runs ({failed_n} invalid or failed)." + (" Analysis computed after a backend restart." if resumed else ""))

    async def _cancel_sweep(self, job_id, sid, d, total):
        rows = self.repo.sweep_rows(sid)
        done_n = len(rows)
        partial = done_n < total
        analysis = None
        if done_n:
            # the analysis of the runs that finished (the same function as for a complete sweep, on the saved rows only)
            try:
                analysis = await asyncio.wait_for(self.loop.run_in_executor(self.pool, work_analyze, d, rows), timeout=120)
                if partial:
                    analysis["partial"] = True
                    analysis["notes"].insert(0, f"PARTIAL: computed from the {len(rows)} of {total} runs that finished before the sweep was cancelled. "
                                                "Points that were not run are absent, so rates, maps and observed limits describe the finished runs only.")
            except Exception as ex:  # noqa: BLE001 - the rows are kept either way; a missing analysis is reported as null with the reason
                log.warning("analysis of the cancelled sweep %s failed: %s", sid, ex)
                analysis = None
        self.repo.update_sweep(sid, status="cancelled", partial=partial, analysis=analysis)
        return self._finish_cancel(job_id, (f"Cancelled after {done_n} of {total} runs; the finished runs are kept (partial sweep)" if done_n else
                                            "Cancelled before any run finished; the (empty) partial sweep is kept")
                                   + ("; the analysis covers the finished runs only." if analysis else "."))

    async def analyze_stored(self, sid) -> dict:
        """Analysis of the rows stored for a finished (complete, cancelled, interrupted, failed) sweep. Used by
        POST /sweeps/{id}/analyze; returns the analysis without changing the stored sweep."""
        sw = self.repo.get_sweep(sid, with_rows=False)
        rows = self.repo.sweep_rows(sid)
        analysis = await self.loop.run_in_executor(self.pool, work_analyze, sw["definition"], rows)
        if len(rows) < sw["total"]:
            analysis["partial"] = True
            analysis["notes"].insert(0, f"PARTIAL: computed from the {len(rows)} of {sw['total']} runs that were stored. Points that were not run are absent.")
        return analysis


class InvalidRequest(Exception):
    def __init__(self, code, message, details, warnings=None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details
        self.warnings = warnings or []

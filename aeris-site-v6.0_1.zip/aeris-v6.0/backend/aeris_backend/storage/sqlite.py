"""SQLite repository (the supported deployment: one local research workstation, one backend
process per database). One connection guarded by a lock, WAL journal, every write in a
transaction. Large JSON documents (run records, row configurations) are stored zlib-compressed.

Schema versions and migrations (docs/DATABASE.md):
  1  AERIS v4 tables (meta, counters, jobs, runs, sweeps, sweep_rows, docs)
  2  v5: jobs.attempts (dispatch counter), at most one run per single-run job and per sweep row
     (partial unique indexes when the existing data allow them; duplicates written by v4 are kept
     and listed in the migration notes, and the code enforces uniqueness for new writes), a
     migrations table that records what was applied and when.
A database is migrated in place when it is opened (each step in one transaction); a database
written by a NEWER schema is refused rather than modified. Take a backup first
(python -m aeris_backend.tools.dbtool backup) when upgrading a database you care about.

Single-process rule: the backend takes an exclusive advisory lock on <db>.lock while it has the
database open (released by the operating system if the process dies), so two backend processes
never dispatch the same jobs.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import sqlite3
import threading
import zlib

from .base import NEXT, TERMINAL, IntegrityError, Repository, TransitionError
from .devices_sql import DeviceTablesMixin

SCHEMA_SQL_V1 = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS counters (name TEXT PRIMARY KEY, value INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, state TEXT NOT NULL, created TEXT, updated TEXT, started TEXT, finished TEXT,
  done INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL DEFAULT 0, failed INTEGER NOT NULL DEFAULT 0,
  message TEXT, error TEXT, result_ref TEXT, request TEXT, seq INTEGER NOT NULL DEFAULT 0, restarts INTEGER NOT NULL DEFAULT 0,
  cancel_requested INTEGER NOT NULL DEFAULT 0, extra TEXT);
CREATE INDEX IF NOT EXISTS jobs_state ON jobs(state);
CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY, experiment_id TEXT UNIQUE, created TEXT, name TEXT, mode TEXT, controller TEXT, outcome TEXT,
  job_id TEXT, sweep_id TEXT, row_index INTEGER, config_hash TEXT, record BLOB NOT NULL);
CREATE INDEX IF NOT EXISTS runs_created ON runs(created);
CREATE TABLE IF NOT EXISTS sweeps (
  id TEXT PRIMARY KEY, created TEXT, name TEXT, job_id TEXT, status TEXT, partial INTEGER NOT NULL DEFAULT 0,
  total INTEGER, definition TEXT, analysis TEXT, engine TEXT, provenance TEXT, extra TEXT);
CREATE TABLE IF NOT EXISTS sweep_rows (
  sweep_id TEXT NOT NULL, idx INTEGER NOT NULL, row TEXT NOT NULL, config BLOB, PRIMARY KEY (sweep_id, idx));
CREATE TABLE IF NOT EXISTS docs (
  tbl TEXT NOT NULL, id TEXT NOT NULL, created TEXT, doc BLOB NOT NULL, idx TEXT, PRIMARY KEY (tbl, id));
"""
SCHEMA_SQL = SCHEMA_SQL_V1   # kept for tools that print the v1 layout
SCHEMA_VERSION = "3"


class SchemaError(RuntimeError):
    pass


class DatabaseInUse(RuntimeError):
    pass


def now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _z(obj) -> bytes:
    return zlib.compress(json.dumps(obj, separators=(",", ":")).encode("utf-8"), 6)


def _unz(b):
    return json.loads(zlib.decompress(b).decode("utf-8")) if b is not None else None


def _j(x):
    return None if x is None else json.dumps(x, separators=(",", ":"))


def _uj(x):
    return None if x is None else json.loads(x)


# ------------------------------------------------------------------------------------------ migrations
def _migrate_2(c) -> dict:
    notes = {"duplicates_single_job": [], "duplicates_sweep_row": []}
    cols = {r[1] for r in c.execute("PRAGMA table_info(jobs)").fetchall()}
    if "attempts" not in cols:
        c.execute("ALTER TABLE jobs ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0")
    c.execute("CREATE INDEX IF NOT EXISTS runs_job ON runs(job_id)")
    dup = c.execute("SELECT job_id, COUNT(*) AS n FROM runs WHERE sweep_id IS NULL AND job_id IS NOT NULL GROUP BY job_id HAVING n > 1").fetchall()
    if dup:
        notes["duplicates_single_job"] = [{"job_id": r[0], "runs": r[1]} for r in dup]
    else:
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS runs_one_per_job ON runs(job_id) WHERE sweep_id IS NULL AND job_id IS NOT NULL")
    dup = c.execute("SELECT sweep_id, row_index, COUNT(*) AS n FROM runs WHERE sweep_id IS NOT NULL GROUP BY sweep_id, row_index HAVING n > 1").fetchall()
    if dup:
        notes["duplicates_sweep_row"] = [{"sweep_id": r[0], "row_index": r[1], "runs": r[2]} for r in dup]
    else:
        c.execute("CREATE UNIQUE INDEX IF NOT EXISTS runs_one_per_row ON runs(sweep_id, row_index) WHERE sweep_id IS NOT NULL")
    notes["unique_indexes"] = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='index' AND name IN ('runs_one_per_job', 'runs_one_per_row')").fetchall()]
    return notes


def _migrate_3(c) -> dict:
    """v6.0 (additive): devices and their owners, pairing sessions, control leases and the command log. Profiles,
    calibrations, recipes, kits and approved configurations live in the document table (immutable revisions)."""
    # one statement at a time: executescript() would commit the migration transaction half-way
    for stmt in """
CREATE TABLE IF NOT EXISTS devices (
  id TEXT PRIMARY KEY, owner TEXT NOT NULL, name TEXT, pubkey TEXT NOT NULL, board TEXT, firmware TEXT, synthetic INTEGER NOT NULL DEFAULT 0,
  paired TEXT NOT NULL, revoked TEXT, profile_id TEXT, profile_revision INTEGER, last_seen TEXT, extra TEXT);
CREATE INDEX IF NOT EXISTS devices_owner ON devices(owner);
CREATE TABLE IF NOT EXISTS pairings (
  session TEXT PRIMARY KEY, owner TEXT NOT NULL, nonce TEXT NOT NULL, created TEXT NOT NULL, expires TEXT NOT NULL, used TEXT,
  device_id TEXT, outcome TEXT);
CREATE TABLE IF NOT EXISTS leases (
  device_id TEXT PRIMARY KEY, owner TEXT NOT NULL, holder TEXT NOT NULL, epoch INTEGER NOT NULL, acquired TEXT NOT NULL, expires TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS commands (
  id TEXT PRIMARY KEY, device_id TEXT NOT NULL, owner TEXT NOT NULL, holder TEXT, action TEXT NOT NULL, params TEXT, config_hash TEXT,
  created TEXT NOT NULL, ttl_ms INTEGER NOT NULL, status TEXT NOT NULL, history TEXT NOT NULL, result TEXT, route TEXT, lease_epoch INTEGER);
CREATE INDEX IF NOT EXISTS commands_device ON commands(device_id, created);
""".split(";"):
        if stmt.strip():
            c.execute(stmt)
    # runs of a twin (Simulate My Cube) belong to the owner of the profile they simulate (jwt mode: hidden from others)
    if "owner" not in {r[1] for r in c.execute("PRAGMA table_info(runs)").fetchall()}:
        c.execute("ALTER TABLE runs ADD COLUMN owner TEXT")
    return {"tables": ["devices", "pairings", "leases", "commands"], "columns": ["runs.owner"]}


MIGRATIONS = [
    (2, "v5: jobs.attempts; at most one run per single-run job and per sweep row; migration log", _migrate_2),
    (3, "v6.0: devices, pairing sessions, control leases, command log (additive)", _migrate_3),
]


class _FileLock:
    """Exclusive advisory lock on <db>.lock (POSIX flock; Windows msvcrt). Released on process exit."""

    def __init__(self, path):
        self.path = path
        self.fh = None

    def acquire(self):
        self.fh = open(self.path, "a+")
        try:
            try:
                import fcntl
                fcntl.flock(self.fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except ImportError:            # pragma: no cover - Windows
                import msvcrt
                msvcrt.locking(self.fh.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            self.fh.seek(0)
            holder = self.fh.read().strip()
            self.fh.close()
            self.fh = None
            raise DatabaseInUse(f"The database is in use by another AERIS backend process ({holder or 'unknown holder'}); "
                                "one backend process per database. Stop the other process or use another AERIS_DB.")
        self.fh.seek(0)
        self.fh.truncate()
        self.fh.write(f"pid {os.getpid()} since {now_iso()}\n")
        self.fh.flush()

    def release(self):
        if self.fh is not None:
            try:
                self.fh.seek(0)
                self.fh.truncate()
                self.fh.flush()
            except OSError:
                pass
            self.fh.close()
            self.fh = None


class SqliteRepository(DeviceTablesMixin, Repository):
    def __init__(self, path: str, *, exclusive: bool = False):
        self.path = path
        self.file_lock = None
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
            if exclusive:
                self.file_lock = _FileLock(os.path.abspath(path) + ".lock")
                self.file_lock.acquire()
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.migration_report = []
        try:
            with self.lock:
                self.db.execute("PRAGMA journal_mode=WAL")
                self.db.execute("PRAGMA synchronous=NORMAL")
                self.db.execute("PRAGMA busy_timeout=5000")
                self.db.executescript(SCHEMA_SQL_V1)
                self.db.execute("INSERT OR IGNORE INTO meta(key, value) VALUES ('schema_version', '1')")
            self._migrate()
        except BaseException:
            self.close()
            raise

    # ------------------------------------------------------------------ schema
    def schema_version(self) -> int:
        with self.lock:
            r = self.db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
        return int(r["value"]) if r else 1

    def _migrate(self):
        cur = self.schema_version()
        target = int(SCHEMA_VERSION)
        if cur > target:
            raise SchemaError(f"The database has schema version {cur}; this backend knows versions up to {target}. "
                              "It was written by a newer AERIS backend; it is not modified. Use that version (or a backup).")
        with self.lock:
            self.db.execute("CREATE TABLE IF NOT EXISTS migrations (version INTEGER PRIMARY KEY, description TEXT, applied TEXT, notes TEXT)")
        for ver, desc, fn in MIGRATIONS:
            if ver <= cur:
                continue
            with self._tx() as c:
                notes = fn(c)
                c.execute("INSERT OR REPLACE INTO migrations(version, description, applied, notes) VALUES (?,?,?,?)", (ver, desc, now_iso(), _j(notes)))
                c.execute("UPDATE meta SET value=? WHERE key='schema_version'", (str(ver),))
            self.migration_report.append({"version": ver, "description": desc, "notes": notes})
            cur = ver

    def schema_info(self) -> dict:
        with self.lock:
            rows = self.db.execute("SELECT version, description, applied, notes FROM migrations ORDER BY version").fetchall()
        mig = [{"version": r["version"], "description": r["description"], "applied": r["applied"], "notes": _uj(r["notes"])} for r in rows]
        warnings = []
        for m in mig:
            n = m["notes"] or {}
            if n.get("duplicates_single_job"):
                warnings.append(f"{len(n['duplicates_single_job'])} single-run job(s) have more than one saved run (written before v5); all runs are kept, the first is the job's result.")
            if n.get("duplicates_sweep_row"):
                warnings.append(f"{len(n['duplicates_sweep_row'])} sweep row(s) have more than one saved run (written before v5); all runs are kept.")
        return {"schema_version": self.schema_version(), "target_version": int(SCHEMA_VERSION), "migrations": mig, "warnings": warnings}

    def integrity_check(self) -> str:
        with self.lock:
            return self.db.execute("PRAGMA integrity_check").fetchone()[0]

    def backup_to(self, dest_path: str) -> None:
        """A consistent copy of the database (SQLite online backup API) while it is in use."""
        if os.path.exists(dest_path):
            raise FileExistsError(dest_path)
        dst = sqlite3.connect(dest_path)
        try:
            with self.lock:
                self.db.backup(dst)
        finally:
            dst.close()

    def _tx(self):
        return _Tx(self)

    def close(self):
        with self.lock:
            try:
                self.db.close()
            finally:
                if self.file_lock is not None:
                    self.file_lock.release()
                    self.file_lock = None

    # ---- ids ----
    def next_id(self, counter: str) -> int:
        start = {"experiment": 100000, "sweep": 100000, "dataset": 100000, "recording": 1, "protocol": 1, "comparison": 1, "paramset": 1,
                 "calibration": 1, "devconfig": 1}.get(counter, 1)
        with self._tx() as c:
            row = c.execute("SELECT value FROM counters WHERE name=?", (counter,)).fetchone()
            v = (row["value"] + 1) if row else start
            c.execute("INSERT INTO counters(name, value) VALUES (?, ?) ON CONFLICT(name) DO UPDATE SET value=excluded.value", (counter, v))
            return v

    # ---- jobs ----
    def create_job(self, job: dict) -> dict:
        with self._tx() as c:
            c.execute("INSERT INTO jobs(id, kind, state, created, updated, done, total, failed, message, request, seq, extra) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                      (job["id"], job["kind"], "queued", job["created"], job["created"], 0, job.get("total", 0), 0, job.get("message", ""),
                       _j(job.get("request")), 1, _j(job.get("extra") or {})))
        return self.get_job(job["id"])

    def _job_row(self, r) -> dict:
        tot = r["total"]
        extra = _uj(r["extra"]) or {}
        return {"schema": "aeris-job/1", "id": r["id"], "kind": r["kind"], "state": r["state"], "created": r["created"], "updated": r["updated"],
                "started": r["started"], "finished": r["finished"],
                "progress": {"done": r["done"], "total": tot, "failed": r["failed"], "fraction": (min(1.0, r["done"] / tot) if tot else 0.0)},
                "adapter": "research-api", "mode": "simulation", "demo": False, "mock": False, "message": r["message"] or "",
                "error": _uj(r["error"]), "result_ref": _uj(r["result_ref"]), "seq": r["seq"], "restarts": r["restarts"],
                "attempts": r["attempts"] if "attempts" in r.keys() else 0,
                "cancel_requested": bool(r["cancel_requested"]), "engine": "aeris-research-backend", **({"extra": extra} if extra else {})}

    def get_job(self, job_id: str):
        with self.lock:
            r = self.db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return self._job_row(r) if r else None

    def get_job_request(self, job_id: str):
        with self.lock:
            r = self.db.execute("SELECT request FROM jobs WHERE id=?", (job_id,)).fetchone()
        return _uj(r["request"]) if r else None

    def _update_job_tx(self, c, job_id, state=None, progress=None, **fields):
        r = c.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if r is None:
            raise KeyError(job_id)
        cur = r["state"]
        if cur in TERMINAL:
            raise TransitionError(f"job {job_id} is {cur}; terminal states never change")
        sets, vals = [], []
        ts = now_iso()
        if state is not None and state != cur:
            if state not in NEXT[cur]:
                raise TransitionError(f"illegal job transition {cur} → {state}")
            sets.append("state=?")
            vals.append(state)
            if state == "initializing" and not r["started"]:
                sets.append("started=?")
                vals.append(ts)
            if state in TERMINAL:
                sets.append("finished=?")
                vals.append(ts)
        if progress:
            done = max(r["done"], min(progress.get("total", r["total"]) or r["total"], progress.get("done", r["done"])))
            failed = max(r["failed"], progress.get("failed", r["failed"]))
            if "total" in progress and progress["total"] != r["total"]:
                if cur in ("running", "analyzing") and r["total"]:
                    raise TransitionError("progress.total is fixed once the job is running")
                sets.append("total=?")
                vals.append(progress["total"])
            sets += ["done=?", "failed=?"]
            vals += [done, failed]
        for k in ("message", "restarts", "cancel_requested"):
            if k in fields:
                sets.append(f"{k}=?")
                vals.append(fields[k])
        for k in ("error", "result_ref", "extra"):
            if k in fields:
                sets.append(f"{k}=?")
                vals.append(_j(fields[k]))
        sets += ["updated=?", "seq=seq+1"]
        vals.append(ts)
        c.execute(f"UPDATE jobs SET {', '.join(sets)} WHERE id=?", (*vals, job_id))

    def update_job(self, job_id: str, *, state=None, progress=None, **fields) -> dict:
        with self._tx() as c:
            self._update_job_tx(c, job_id, state=state, progress=progress, **fields)
        return self.get_job(job_id)

    def increment_attempts(self, job_id: str) -> int:
        with self._tx() as c:
            c.execute("UPDATE jobs SET attempts=attempts+1 WHERE id=?", (job_id,))
            r = c.execute("SELECT attempts FROM jobs WHERE id=?", (job_id,)).fetchone()
        return r["attempts"] if r else 0

    def list_jobs(self, states=None, limit=100, *, viewer: str | None = None):
        """viewer (jwt mode): only jobs without an owner and the viewer's own (twin simulations carry their owner)."""
        own = ""
        args = []
        if viewer is not None:
            own = " AND (json_extract(extra, '$.owner') IS NULL OR json_extract(extra, '$.owner') = ?)"
            args.append(viewer)
        with self.lock:
            if states:
                q = f"SELECT * FROM jobs WHERE state IN ({','.join('?' * len(states))}){own} ORDER BY created LIMIT ?"
                rows = self.db.execute(q, (*states, *args, limit)).fetchall()
            else:
                rows = self.db.execute(f"SELECT * FROM jobs WHERE 1=1{own} ORDER BY created DESC LIMIT ?", (*args, limit)).fetchall()
        return [self._job_row(r) for r in rows]

    # ---- runs ----
    @staticmethod
    def _insert_run(c, record, job_id=None, sweep_id=None, row_index=None):
        c_ = record.get("config") or {}
        c.execute("INSERT INTO runs(id, experiment_id, created, name, mode, controller, outcome, job_id, sweep_id, row_index, config_hash, record, owner) "
                  "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (record["id"], record.get("experiment_id"), record.get("created"), record.get("name"), c_.get("mode"),
                   (c_.get("controller") or {}).get("type"), (record.get("outcome") or {}).get("code"), job_id, sweep_id, row_index,
                   (record.get("reproduction") or {}).get("config_hash"), _z(record), record.get("owner")))

    def save_run(self, record, *, job_id=None, sweep_id=None, row_index=None):
        with self._tx() as c:
            self._insert_run(c, record, job_id, sweep_id, row_index)

    def run_for_job(self, job_id):
        with self.lock:
            r = self.db.execute("SELECT id FROM runs WHERE job_id=? AND sweep_id IS NULL ORDER BY created, rowid LIMIT 1", (job_id,)).fetchone()
        return r["id"] if r else None

    def save_single_result(self, job_id, record, *, message):
        with self._tx() as c:
            j = c.execute("SELECT state FROM jobs WHERE id=?", (job_id,)).fetchone()
            if j is None:
                raise KeyError(job_id)
            if j["state"] != "running":
                raise TransitionError(f"a run is saved only for a running job; job {job_id} is {j['state']}")
            ex = c.execute("SELECT id FROM runs WHERE job_id=? AND sweep_id IS NULL ORDER BY created, rowid LIMIT 1", (job_id,)).fetchone()
            inserted = ex is None
            run_id = record["id"] if inserted else ex["id"]
            if inserted:
                self._insert_run(c, record, job_id=job_id)
            self._update_job_tx(c, job_id, state="analyzing", progress={"done": 1}, result_ref={"kind": "run", "id": run_id}, message=message)
        return self.get_job(job_id), run_id, inserted

    def get_run(self, run_id):
        with self.lock:
            r = self.db.execute("SELECT record FROM runs WHERE id=? OR experiment_id=?", (run_id, run_id)).fetchone()
        return _unz(r["record"]) if r else None

    def list_runs(self, limit=100, offset=0, *, viewer: str | None = None):
        """viewer (jwt mode): only runs without an owner (the shared research workspace) and the viewer's own."""
        q = "SELECT id, experiment_id, created, name, mode, controller, outcome, job_id, sweep_id FROM runs"
        args = []
        if viewer is not None:
            q += " WHERE owner IS NULL OR owner = ?"
            args.append(viewer)
        with self.lock:
            rows = self.db.execute(q + " ORDER BY created DESC LIMIT ? OFFSET ?", (*args, limit, offset)).fetchall()
        return [dict(r) for r in rows]

    def count(self, table: str) -> int:
        if table not in ("runs", "jobs", "sweeps", "sweep_rows", "docs"):
            raise ValueError(table)
        with self.lock:
            return self.db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

    def runs_of_job(self, job_id):
        with self.lock:
            return [r["id"] for r in self.db.execute("SELECT id FROM runs WHERE job_id=? ORDER BY created, rowid", (job_id,)).fetchall()]

    # ---- sweeps ----
    def create_sweep(self, sweep):
        with self._tx() as c:
            c.execute("INSERT INTO sweeps(id, created, name, job_id, status, partial, total, definition, analysis, engine, provenance, extra) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                      (sweep["id"], sweep["created"], sweep.get("name"), sweep.get("job_id"), sweep.get("status", "running"), 0, sweep.get("total"),
                       _j(sweep["definition"]), None, _j(sweep.get("engine")), _j(sweep.get("provenance")), _j(sweep.get("extra") or {})))

    def add_sweep_row(self, sweep_id, row, config, *, record=None, job_id=None):
        with self._tx() as c:
            cur = c.execute("INSERT OR IGNORE INTO sweep_rows(sweep_id, idx, row, config) VALUES (?,?,?,?)",
                            (sweep_id, row["index"], _j(row), _z(config) if config is not None else None))
            new = cur.rowcount == 1
            if new and record is not None:
                ex = c.execute("SELECT id FROM runs WHERE sweep_id=? AND row_index=?", (sweep_id, row["index"])).fetchone()
                if ex is None:
                    self._insert_run(c, record, job_id=job_id, sweep_id=sweep_id, row_index=row["index"])
                elif ex["id"] != record["id"]:
                    raise IntegrityError(f"sweep {sweep_id} row {row['index']} already has run {ex['id']}")
            return new

    def sweep_rows(self, sweep_id, *, offset=0, limit=None, include_config=False):
        q = "SELECT row, config FROM sweep_rows WHERE sweep_id=? ORDER BY idx LIMIT ? OFFSET ?"
        with self.lock:
            rows = self.db.execute(q, (sweep_id, -1 if limit is None else limit, offset)).fetchall()
        out = []
        for r in rows:
            d = _uj(r["row"])
            if include_config:
                d["config"] = _unz(r["config"])
            out.append(d)
        return out

    def sweep_row(self, sweep_id, index, *, include_config=True):
        """One saved row by its run index (rows of a partial sweep need not be contiguous)."""
        with self.lock:
            r = self.db.execute("SELECT row, config FROM sweep_rows WHERE sweep_id=? AND idx=?", (sweep_id, int(index))).fetchone()
        if not r:
            return None
        d = _uj(r["row"])
        if include_config:
            d["config"] = _unz(r["config"])
        return d

    def row_indices(self, sweep_id):
        with self.lock:
            return {r[0] for r in self.db.execute("SELECT idx FROM sweep_rows WHERE sweep_id=?", (sweep_id,)).fetchall()}

    def update_sweep(self, sweep_id, **fields):
        with self._tx() as c:
            if "extra_merge" in fields:
                r = c.execute("SELECT extra FROM sweeps WHERE id=?", (sweep_id,)).fetchone()
                cur = (_uj(r["extra"]) if r else None) or {}
                cur.update(fields.pop("extra_merge"))
                fields["extra"] = cur
            sets, vals = [], []
            for k, v in fields.items():
                sets.append(f"{k}=?")
                vals.append(_j(v) if k in ("analysis", "engine", "provenance", "definition", "extra") else (int(v) if isinstance(v, bool) else v))
            if sets:
                c.execute(f"UPDATE sweeps SET {', '.join(sets)} WHERE id=?", (*vals, sweep_id))

    def get_sweep(self, sweep_id, *, with_rows=True):
        with self.lock:
            r = self.db.execute("SELECT * FROM sweeps WHERE id=?", (sweep_id,)).fetchone()
        if not r:
            return None
        definition = _uj(r["definition"])
        rev = (definition or {}).get("revision") or "1.1"
        sw = {"schema": "aeris-sweep/1", "revision": rev, "kind": "result", "id": r["id"], "name": r["name"], "created": r["created"],
              "definition": definition, "engine": _uj(r["engine"]), "provenance": _uj(r["provenance"]), "status": r["status"],
              "partial": bool(r["partial"]), "total": r["total"], "analysis": _uj(r["analysis"]), "job_id": r["job_id"], **(_uj(r["extra"]) or {})}
        if with_rows:
            sw["rows"] = self.sweep_rows(sweep_id)
        with self.lock:
            sw["rows_stored"] = self.db.execute("SELECT COUNT(*) FROM sweep_rows WHERE sweep_id=?", (sweep_id,)).fetchone()[0]
        return sw

    # ---- generic documents ----
    # A document whose stored status is 'final' in one of these tables can never be replaced (finalised datasets).
    FINAL_IS_IMMUTABLE = ("datasets",)

    def put(self, table, doc_id, doc, **index):
        with self._tx() as c:
            if table in self.FINAL_IS_IMMUTABLE:
                r = c.execute("SELECT doc FROM docs WHERE tbl=? AND id=?", (table, doc_id)).fetchone()
                if r is not None and (_unz(r["doc"]) or {}).get("status") == "final":
                    raise IntegrityError(f"{table} {doc_id} is final; a final document is never changed")
            c.execute("INSERT INTO docs(tbl, id, created, doc, idx) VALUES (?,?,?,?,?) ON CONFLICT(tbl, id) DO UPDATE SET doc=excluded.doc, idx=excluded.idx",
                      (table, doc_id, doc.get("created") or now_iso(), _z(doc), _j(index)))

    def put_new(self, table, doc_id, doc, **index) -> bool:
        """Insert only (never replaces an existing document). Returns False if the id exists."""
        with self._tx() as c:
            cur = c.execute("INSERT OR IGNORE INTO docs(tbl, id, created, doc, idx) VALUES (?,?,?,?,?)",
                            (table, doc_id, doc.get("created") or now_iso(), _z(doc), _j(index)))
            return cur.rowcount == 1

    def get(self, table, doc_id):
        with self.lock:
            r = self.db.execute("SELECT doc FROM docs WHERE tbl=? AND id=?", (table, doc_id)).fetchone()
        return _unz(r["doc"]) if r else None

    def list(self, table, limit=100):
        with self.lock:
            rows = self.db.execute("SELECT id, created, idx FROM docs WHERE tbl=? ORDER BY created DESC LIMIT ?", (table, limit)).fetchall()
        return [{"id": r["id"], "created": r["created"], **(_uj(r["idx"]) or {})} for r in rows]

    def list_where(self, table, limit=100, **eq):
        """Documents whose index fields equal the given values (v6: owner-scoped listings, filtered in SQL so that
        another owner's documents never take up the limit). A value None matches a missing field."""
        q = "SELECT id, created, idx FROM docs WHERE tbl=?"
        args = [table]
        for k, v in eq.items():
            if not k.isidentifier():
                raise ValueError(f"bad index field {k!r}")
            if v is None:
                q += f" AND json_extract(idx, '$.{k}') IS NULL"
            else:
                q += f" AND json_extract(idx, '$.{k}') = ?"
                args.append(v)
        q += " ORDER BY created DESC LIMIT ?"
        args.append(limit)
        with self.lock:
            rows = self.db.execute(q, args).fetchall()
        return [{"id": r["id"], "created": r["created"], **(_uj(r["idx"]) or {})} for r in rows]


class _Tx:
    def __init__(self, repo):
        self.repo = repo

    def __enter__(self):
        self.repo.lock.acquire()
        try:
            self.repo.db.execute("BEGIN IMMEDIATE")
        except BaseException:
            self.repo.lock.release()
            raise
        return self.repo.db

    def __exit__(self, et, ev, tb):
        try:
            if et is None:
                self.repo.db.execute("COMMIT")
            else:
                self.repo.db.execute("ROLLBACK")
        finally:
            self.repo.lock.release()
        return False

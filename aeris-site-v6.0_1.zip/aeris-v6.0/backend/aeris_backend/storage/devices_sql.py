"""v6.0 device tables (schema 3) for the SQLite repository: devices, pairing sessions, control leases, commands.

Every query is scoped by owner where the data belongs to an owner; a row of another owner is indistinguishable from a
missing row for the caller (the API answers 404 for both). Leases and pairing sessions change in single transactions
so two clients cannot both win.
"""
from __future__ import annotations

import datetime as _dt
import json


def _now():
    return _dt.datetime.now(_dt.timezone.utc)


def _iso(t: _dt.datetime) -> str:
    return t.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _parse(s: str) -> _dt.datetime:
    return _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))


def _row(r):
    if r is None:
        return None
    d = dict(r)
    for k in ("extra", "params", "history", "result"):
        if k in d and d[k] is not None:
            d[k] = json.loads(d[k])
    if "synthetic" in d:
        d["synthetic"] = bool(d["synthetic"])
    return d


class DeviceTablesMixin:
    """Requires self.db, self.lock and self._tx() (SqliteRepository)."""

    # ------------------------------------------------------------------ devices
    def device_get(self, device_id: str, owner: str | None = None):
        with self.lock:
            if owner is None:
                r = self.db.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()
            else:
                r = self.db.execute("SELECT * FROM devices WHERE id=? AND owner=?", (device_id, owner)).fetchone()
        return _row(r)

    def device_list(self, owner: str, include_revoked: bool = False) -> list:
        q = "SELECT * FROM devices WHERE owner=?" + ("" if include_revoked else " AND revoked IS NULL") + " ORDER BY paired DESC"
        with self.lock:
            return [_row(r) for r in self.db.execute(q, (owner,)).fetchall()]

    def device_register(self, dev: dict) -> dict:
        """Pair (or re-pair) a device to an owner with its public key. A device paired to another owner that has not
        been revoked cannot be taken over (IntegrityError-like ValueError)."""
        with self._tx() as c:
            cur = c.execute("SELECT owner, revoked FROM devices WHERE id=?", (dev["id"],)).fetchone()
            if cur is not None and cur["owner"] != dev["owner"] and cur["revoked"] is None:
                raise ValueError("this device is paired to another account; that owner must revoke it first")
            c.execute("INSERT INTO devices(id, owner, name, pubkey, board, firmware, synthetic, paired, revoked, profile_id, profile_revision, last_seen, extra) "
                      "VALUES (?,?,?,?,?,?,?,?,NULL,?,?,NULL,?) ON CONFLICT(id) DO UPDATE SET owner=excluded.owner, name=excluded.name, "
                      "pubkey=excluded.pubkey, board=excluded.board, firmware=excluded.firmware, synthetic=excluded.synthetic, paired=excluded.paired, "
                      "revoked=NULL, extra=excluded.extra",
                      (dev["id"], dev["owner"], dev.get("name"), dev["pubkey"], dev.get("board"), dev.get("firmware"), 1 if dev.get("synthetic") else 0,
                       dev.get("paired") or _iso(_now()), dev.get("profile_id"), dev.get("profile_revision"), json.dumps(dev.get("extra") or {})))
        return self.device_get(dev["id"], dev["owner"])

    def device_update(self, device_id: str, owner: str, **fields) -> dict | None:
        allowed = {"name", "profile_id", "profile_revision", "last_seen", "firmware"}
        sets = [(k, v) for k, v in fields.items() if k in allowed]
        if sets:
            with self._tx() as c:
                c.execute("UPDATE devices SET " + ", ".join(f"{k}=?" for k, _ in sets) + " WHERE id=? AND owner=?", [v for _, v in sets] + [device_id, owner])
        return self.device_get(device_id, owner)

    def device_revoke(self, device_id: str, owner: str) -> dict | None:
        with self._tx() as c:
            c.execute("UPDATE devices SET revoked=? WHERE id=? AND owner=? AND revoked IS NULL", (_iso(_now()), device_id, owner))
            c.execute("DELETE FROM leases WHERE device_id=?", (device_id,))
        return self.device_get(device_id, owner)

    # ------------------------------------------------------------------ pairing sessions
    def pairing_create(self, session: str, owner: str, nonce: str, ttl_s: float) -> dict:
        now = _now()
        with self._tx() as c:
            c.execute("INSERT INTO pairings(session, owner, nonce, created, expires) VALUES (?,?,?,?,?)",
                      (session, owner, nonce, _iso(now), _iso(now + _dt.timedelta(seconds=ttl_s))))
        return {"session": session, "nonce": nonce, "expires": _iso(now + _dt.timedelta(seconds=ttl_s))}

    def pairing_consume(self, session: str, owner: str, nonce: str, device_id: str, outcome: str) -> tuple[bool, str]:
        """Use a pairing session exactly once (atomic). Returns (ok, reason)."""
        with self._tx() as c:
            r = c.execute("SELECT * FROM pairings WHERE session=? AND owner=?", (session, owner)).fetchone()
            if r is None:
                return False, "unknown pairing session"
            if r["used"] is not None:
                return False, "this pairing session was already used"
            if r["nonce"] != nonce:
                return False, "nonce does not match the pairing session"
            if _parse(r["expires"]) < _now():
                return False, "the pairing session expired"
            c.execute("UPDATE pairings SET used=?, device_id=?, outcome=? WHERE session=?", (_iso(_now()), device_id, outcome, session))
        return True, "ok"

    # ------------------------------------------------------------------ leases
    def lease_get(self, device_id: str):
        with self.lock:
            r = self.db.execute("SELECT * FROM leases WHERE device_id=?", (device_id,)).fetchone()
        return _row(r)

    def lease_acquire(self, device_id: str, owner: str, holder: str, ttl_s: float, *, takeover: bool = False) -> tuple[dict | None, str]:
        """One controlling client per device. The same holder renews (same epoch); another holder of the same owner gets
        it only when the lease expired or with takeover=True (a new epoch: commands of the previous holder become
        stale on the device). Returns (lease, reason)."""
        now = _now()
        with self._tx() as c:
            r = c.execute("SELECT * FROM leases WHERE device_id=?", (device_id,)).fetchone()
            if r is not None and r["owner"] != owner:
                return None, "the device is leased by another account"
            if r is not None and r["holder"] == holder:
                c.execute("UPDATE leases SET expires=? WHERE device_id=?", (_iso(now + _dt.timedelta(seconds=ttl_s)), device_id))
            elif r is not None and _parse(r["expires"]) > now and not takeover:
                return None, "another session holds the control lease (it can be taken over explicitly)"
            else:
                epoch = (r["epoch"] + 1) if r is not None else 1
                c.execute("INSERT INTO leases(device_id, owner, holder, epoch, acquired, expires) VALUES (?,?,?,?,?,?) "
                          "ON CONFLICT(device_id) DO UPDATE SET owner=excluded.owner, holder=excluded.holder, epoch=excluded.epoch, "
                          "acquired=excluded.acquired, expires=excluded.expires",
                          (device_id, owner, holder, epoch, _iso(now), _iso(now + _dt.timedelta(seconds=ttl_s))))
        return self.lease_get(device_id), "ok"

    def lease_release(self, device_id: str, owner: str, holder: str) -> bool:
        """Releasing keeps the epoch (the next holder gets epoch + 1); returns True when this holder held it."""
        with self._tx() as c:
            r = c.execute("SELECT * FROM leases WHERE device_id=? AND owner=? AND holder=?", (device_id, owner, holder)).fetchone()
            if r is None:
                return False
            c.execute("UPDATE leases SET expires=? WHERE device_id=?", (_iso(_now() - _dt.timedelta(seconds=1)), device_id))
        return True

    # ------------------------------------------------------------------ commands
    def command_insert(self, cmd: dict) -> None:
        with self._tx() as c:
            c.execute("INSERT INTO commands(id, device_id, owner, holder, action, params, config_hash, created, ttl_ms, status, history, result, route, lease_epoch) "
                      "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (cmd["id"], cmd["device_id"], cmd["owner"], cmd.get("holder"), cmd["action"], json.dumps(cmd.get("params")), cmd.get("config_hash"),
                       cmd["created"], cmd["ttl_ms"], cmd["status"], json.dumps(cmd.get("history") or []), json.dumps(cmd.get("result")),
                       cmd.get("route"), cmd.get("lease_epoch")))

    def command_update(self, cmd_id: str, status: str, event: dict, result=None) -> dict | None:
        with self._tx() as c:
            r = c.execute("SELECT history FROM commands WHERE id=?", (cmd_id,)).fetchone()
            if r is None:
                return None
            hist = json.loads(r["history"])
            hist.append(event)
            if result is not None:
                c.execute("UPDATE commands SET status=?, history=?, result=? WHERE id=?", (status, json.dumps(hist), json.dumps(result), cmd_id))
            else:
                c.execute("UPDATE commands SET status=?, history=? WHERE id=?", (status, json.dumps(hist), cmd_id))
        return self.command_get(cmd_id)

    def command_get(self, cmd_id: str, owner: str | None = None):
        with self.lock:
            if owner is None:
                r = self.db.execute("SELECT * FROM commands WHERE id=?", (cmd_id,)).fetchone()
            else:
                r = self.db.execute("SELECT * FROM commands WHERE id=? AND owner=?", (cmd_id, owner)).fetchone()
        return _row(r)

    def command_list(self, device_id: str, owner: str, limit: int = 100) -> list:
        with self.lock:
            rows = self.db.execute("SELECT * FROM commands WHERE device_id=? AND owner=? ORDER BY created DESC LIMIT ?", (device_id, owner, limit)).fetchall()
        return [_row(r) for r in rows]

    def commands_open(self) -> list:
        """Commands that have not reached a final status (used at start-up: they are expired, never resent)."""
        with self.lock:
            rows = self.db.execute("SELECT * FROM commands WHERE status NOT IN ('completed','failed','rejected','expired','cancelled')").fetchall()
        return [_row(r) for r in rows]

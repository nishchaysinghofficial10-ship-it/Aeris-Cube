"""Repository interface. The job manager and the API only talk to this interface; the SQLite
implementation (sqlite.py) serves local development. A PostgreSQL implementation maps the same
methods onto the same tables (JSON columns → JSONB, BLOB → BYTEA, INTEGER PRIMARY KEY counters →
sequences); nothing above this layer uses SQL."""
from __future__ import annotations

from abc import ABC, abstractmethod

JOB_STATES = ("queued", "initializing", "running", "analyzing", "complete", "failed", "cancelled")
TERMINAL = ("complete", "failed", "cancelled")
NEXT = {"queued": ("initializing", "failed", "cancelled"), "initializing": ("running", "failed", "cancelled"),
        "running": ("running", "analyzing", "failed", "cancelled"), "analyzing": ("complete", "failed", "cancelled"),
        "complete": (), "failed": (), "cancelled": ()}


class TransitionError(ValueError):
    pass


class IntegrityError(RuntimeError):
    """A persisted state that the job rules do not allow (reported as a failed job, never ignored)."""


# The legal path from each non-terminal state to COMPLETE (used to finish saved work after a restart).
PATH_TO_COMPLETE = {"queued": ("initializing", "running", "analyzing", "complete"), "initializing": ("running", "analyzing", "complete"),
                    "running": ("analyzing", "complete"), "analyzing": ("complete",)}


class Repository(ABC):
    # ---- ids ----
    @abstractmethod
    def next_id(self, counter: str) -> int: ...

    # ---- jobs ----
    @abstractmethod
    def create_job(self, job: dict) -> dict: ...

    @abstractmethod
    def get_job(self, job_id: str) -> dict | None: ...

    @abstractmethod
    def update_job(self, job_id: str, *, state: str | None = None, progress: dict | None = None, **fields) -> dict:
        """Apply a legal transition and/or monotone progress; bumps the job's update sequence.
        Terminal jobs are immutable (TransitionError)."""

    @abstractmethod
    def list_jobs(self, states=None, limit: int = 100) -> list: ...

    # ---- runs ----
    @abstractmethod
    def save_run(self, record: dict, *, job_id=None, sweep_id=None, row_index=None) -> None: ...

    @abstractmethod
    def save_single_result(self, job_id: str, record: dict, *, message: str) -> tuple[dict, str, bool]:
        """One transaction: store the run of a single-run job (unless the job already has one) and move
        the job RUNNING → ANALYZING with progress done = 1 and result_ref = the run. Returns
        (job, run_id, inserted). Idempotent: a job never gets a second run."""

    @abstractmethod
    def run_for_job(self, job_id: str) -> str | None:
        """Id of the run saved by a single-run job (None if it has none)."""

    @abstractmethod
    def get_run(self, run_id: str) -> dict | None: ...

    @abstractmethod
    def list_runs(self, limit: int = 100, offset: int = 0) -> list: ...

    # ---- sweeps ----
    @abstractmethod
    def create_sweep(self, sweep: dict) -> None: ...

    @abstractmethod
    def add_sweep_row(self, sweep_id: str, row: dict, config: dict | None, *, record: dict | None = None, job_id: str | None = None) -> bool:
        """One transaction: store a row (and the run record of that row, if any) unless the row exists.
        Returns True when the row was new."""

    @abstractmethod
    def increment_attempts(self, job_id: str) -> int:
        """Count a dispatch of the job (persisted, so crash loops across restarts are bounded)."""

    @abstractmethod
    def sweep_rows(self, sweep_id: str, *, offset: int = 0, limit: int | None = None, include_config: bool = False) -> list: ...

    @abstractmethod
    def sweep_row(self, sweep_id: str, index: int, *, include_config: bool = True) -> dict | None: ...

    @abstractmethod
    def row_indices(self, sweep_id: str) -> set: ...

    @abstractmethod
    def update_sweep(self, sweep_id: str, **fields) -> None: ...

    @abstractmethod
    def get_sweep(self, sweep_id: str, *, with_rows: bool = True) -> dict | None: ...

    # ---- datasets, parameter sets, hardware, protocols, comparisons ----
    @abstractmethod
    def put(self, table: str, doc_id: str, doc: dict, **index) -> None: ...

    @abstractmethod
    def get(self, table: str, doc_id: str) -> dict | None: ...

    @abstractmethod
    def list(self, table: str, limit: int = 100) -> list: ...

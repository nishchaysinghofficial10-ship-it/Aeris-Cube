"""The reference documents shipped with v6.0.

REFERENCE_PROFILE is the experimental profile of the candidate reference build (ESP32-S3-DevKitC-1-N8R8 controller,
LSM6DSOX IMU, three ODrive CANSimple wheel drivers). Its mass, inertia, wheel and motor values are the AERIS engine's
NOMINAL MODEL values (constants.NOMINAL): no motor has been selected and nothing here was measured. It is published as
'experimental': release firmware never drives motors with it, and it is the profile the synthetic device and the twin
use by default. A real build replaces these values with its own (a new profile revision) and its own calibration.

The recipes are the first experiments of the build guide: a short edge hold, then (only after a completed edge trial)
a short corner hold. Their limits are deliberately conservative starting values for a cube in a fall-catching fixture;
they are not qualified limits.
"""
from __future__ import annotations

import copy
import math

from . import schemas

_R3 = 0.09 / math.sqrt(3.0)

REFERENCE_PROFILE = {
    "schema": schemas.PROFILE_SCHEMA,
    "id": "aeris-ref-a1",
    "name": "AERIS reference cube A1 (experimental, nominal-model values)",
    "description": ("Candidate reference build: ESP32-S3-DevKitC-1-N8R8 controller, LSM6DSOX IMU on I2C (address 0x6A), three "
                    "current-controlled wheel drivers on CAN (ODrive CANSimple, nodes 1-3). Mass, inertia, wheel and motor values are the "
                    "engine's nominal model; no motor or rotor has been selected or measured."),
    "kit": {"id": "aeris-kit-a1", "revision": "A1-candidate"},
    "qualification": {"status": "experimental", "evidence": [],
                      "note": "Not qualified: no physical build has been assembled, measured or balanced. Release firmware keeps motor actuation disabled."},
    "g_mps2": 9.81,
    "body": {"edge_m": 0.18, "mass_kg": 1.8, "inertia_factor": 0.2, "com_m": None, "components": []},
    "wheels": [
        {"id": "x", "axis": [1.0, 0.0, 0.0], "Jw_kgm2": 5e-4,
         "motor": {"KV_rpm_per_V": 500.0, "R_ohm": 0.4, "Imax_A": 8.0, "supply_V": 11.1, "speed_max_rpm": 5000.0},
         "friction": {"cv": 1e-5, "cc": 0.002}, "driver": {"kind": "odrive-cansimple", "node": 1, "sign": 1}},
        {"id": "y", "axis": [0.0, 1.0, 0.0], "Jw_kgm2": 5e-4,
         "motor": {"KV_rpm_per_V": 500.0, "R_ohm": 0.4, "Imax_A": 8.0, "supply_V": 11.1, "speed_max_rpm": 5000.0},
         "friction": {"cv": 1e-5, "cc": 0.002}, "driver": {"kind": "odrive-cansimple", "node": 2, "sign": 1}},
        {"id": "z", "axis": [0.0, 0.0, 1.0], "Jw_kgm2": 5e-4,
         "motor": {"KV_rpm_per_V": 500.0, "R_ohm": 0.4, "Imax_A": 8.0, "supply_V": 11.1, "speed_max_rpm": 5000.0},
         "friction": {"cv": 1e-5, "cc": 0.002}, "driver": {"kind": "odrive-cansimple", "node": 3, "sign": 1}},
    ],
    "imu": {"driver": "lsm6dsox", "i2c_address": 0x6A, "position_m": [_R3, _R3, _R3], "to_body": [1, 0, 0, 0, 1, 0, 0, 0, 1],
            "odr_hz": 833, "accel_range_g": 8, "gyro_range_dps": 2000, "noise": {"gyro_dps": 0.16, "accel_mps2": 0.047}},
    "board": {"id": "esp32-s3-devkitc-1"},
    "electrical": {"vbus_min_V": 9.9, "vbus_max_V": 12.6, "current_abort_A": 9.0, "temperature_abort_C": 80.0},
    "value_sources": {"body": "nominal-model", "wheels": "nominal-model", "motor": "nominal-model", "imu.noise": "nominal-model",
                      "imu.placement": "nominal-model", "electrical": "nominal-model"},
}

EDGE_RECIPE = {
    "schema": schemas.RECIPE_SCHEMA,
    "id": "edge-hold-10s",
    "name": "Edge hold, 10 s (first trial)",
    "description": "Balance on the support edge for 10 s from a hand-held start within 3° of the balance line, then a normal stop.",
    "mode": "edge",
    "duration_s": 10,
    "controller": {"type": "lqr", "weights": {}},
    "estimator": {"type": "cf3d", "tau_s": 0.5, "accel_gate_mps2": 0.5, "bias_gain": 0.0, "tau_alpha_s": 0.02, "compensate_dynamic": True},
    "limits": {"tilt_start_deg": 3.0, "tilt_abort_deg": 12.0, "link_loss_max_s": 0.5, "stop_torque_Nm": 0.05, "arm_window_s": 30,
               "wheel_speed_abort_factor": 1.05},
    "rates": {"control_hz": 500, "telemetry_hz": 50},
    "start": {"tilt_deg": 1.0},
    "requires": [],
}

CORNER_RECIPE = {
    "schema": schemas.RECIPE_SCHEMA,
    "id": "corner-hold-10s",
    "name": "Corner hold, 10 s (after a completed edge trial)",
    "description": "Balance on the pivot corner for 10 s from a hand-held start within 3° of the balance attitude, then a normal stop.",
    "mode": "corner",
    "duration_s": 10,
    "controller": {"type": "lqr", "weights": {}},
    "estimator": {"type": "cf3d", "tau_s": 0.5, "accel_gate_mps2": 0.5, "bias_gain": 0.0, "tau_alpha_s": 0.02, "compensate_dynamic": True},
    "limits": {"tilt_start_deg": 3.0, "tilt_abort_deg": 12.0, "link_loss_max_s": 0.5, "stop_torque_Nm": 0.05, "arm_window_s": 30,
               "wheel_speed_abort_factor": 1.05},
    "rates": {"control_hz": 500, "telemetry_hz": 50},
    "start": {"tilt_deg": 1.0},
    "requires": ["edge-trial-completed"],
}

RECIPES = {r["id"]: r for r in (EDGE_RECIPE, CORNER_RECIPE)}


def reference_profile() -> dict:
    return copy.deepcopy(REFERENCE_PROFILE)


def recipe(rid: str) -> dict:
    return copy.deepcopy(RECIPES[rid])


def kits() -> list:
    """The kit documents (aeris-kit/1) shipped with the backend: a copy of site/data/kits (the drift test keeps them
    identical). Each is validated when read; an invalid file is reported, never served."""
    import json
    import os
    d = os.path.join(os.path.dirname(__file__), "data", "kits")
    out = []
    if not os.path.isdir(d):
        return out
    for name in sorted(os.listdir(d)):
        if not name.endswith(".json"):
            continue
        with open(os.path.join(d, name), encoding="utf-8") as f:
            doc = json.load(f)
        res = schemas.validate_kit(doc)
        if not res["ok"]:
            raise ValueError(f"kit {name}: " + "; ".join(f"{e['path']}: {e['message']}" for e in res["errors"][:5]))
        out.append(doc)
    return out

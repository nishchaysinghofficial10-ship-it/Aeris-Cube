"""Devices (AERIS v6.0 "Build & Connect"): versioned device profiles, kits, calibrations and experiment recipes, the
approved device configuration a cube runs, the plant model of the synthetic device, and (in later modules) owners,
pairing, connections, leases and bounded commands.

Everything here is additive: the research engine, its configuration schema and its records are unchanged. A device
profile is turned into an ordinary engine configuration (configgen.engine_config) so "Simulate My Cube" runs the same
engine as every other simulation, and the gains a cube receives are designed by the same code (control/design.py).

Nothing in this package can mark a profile, a calibration or a run as qualified, MEASURED or VALIDATED by itself:
qualification states are declared by people with evidence and are never promoted by the software.
"""

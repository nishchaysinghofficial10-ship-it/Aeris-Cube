"""Calibration revisions (aeris-calibration/1) from what a device MEASURED (site/docs/CONNECT.md §Calibration).

The device measures; it never decides that a calibration is good enough. This module turns device results into an
immutable calibration document, or refuses with the reason:

  imu       one calibrate_imu result (the cube completely still): the gyroscope bias in the SENSOR frame (mean of the
            raw readings) and its spread; the device subtracts it after rotating it into the body frame (configgen)
  axes      two or more calibrate_axes results, each taken with the cube resting so that a known BODY axis points up;
            params.face names that axis: "+x", "-x", "+y", "-y", "+z" or "-z". At rest the accelerometer reads the
            reaction to gravity, i.e. +g along "up", so up_sensor = accel_mean / |accel_mean| and body = to_body · sensor
            must map it onto the named body axis. imu.to_body is found by trying all 24 axis-aligned rotations (signed
            permutations with determinant +1); the best one must fit every face within 10° and the faces must include
            two different axes (one axis alone leaves the rotation about it undetermined)
  encoders  optionally, one check_encoders result taken while a person turned each wheel by hand in its MARKED positive
            direction. The device reports velocities with the configured wheel sign, so a correctly declared sign reads
            positive. A wheel whose reading is negative has the wrong driver.sign in the profile (a new profile revision
            fixes it); a wheel that was not turned is "not checked". The backend refuses to START an experiment on a
            physical device whose applied configuration was built from a calibration without three confirmed
            directions (service.py) — the device's own gates (build, self-test, ARM) apply in addition.

The same algorithm runs in the browser for the Web Serial path (site/js/connect/calib.js); tests compare both.
"""
from __future__ import annotations

import itertools
import math
import re

from ..experiments.records import now_iso
from . import schemas

FACE_RE = re.compile(r"^[+-][xyz]$")
FIT_MAX_DEG = 10.0
G0 = 9.80665
GRAVITY_TOL = 0.8                    # m/s² (the device already refuses |a| outside g ± 0.6)
STILL_GYRO = 0.02                    # rad/s (norm of the per-axis standard deviations; the device's own threshold)
STILL_ACCEL = 0.15                   # m/s²
WHEEL_MIN_TRAVEL_REV = 0.25          # a wheel turned by hand at least a quarter turn
WHEEL_MIN_SPEED = 0.5                # rad/s peak in the turned direction
WHEEL_BACKLASH_RATIO = 0.5           # the opposite peak may reach half the forward peak (a hand lets go, the wheel rocks back)


class CalibrationError(ValueError):
    def __init__(self, message: str, details=None):
        super().__init__(message)
        self.details = details or []


def rotations() -> list:
    """The 24 axis-aligned rotations as row-major 9-lists (signed permutations, determinant +1)."""
    out = []
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product((1, -1), repeat=3):
            m = [0] * 9
            for r in range(3):
                m[3 * r + perm[r]] = signs[r]
            if schemas.signed_permutation(m):
                out.append(m)
    return out


ROTATIONS = rotations()


def face_vector(face: str) -> list:
    if not isinstance(face, str) or not FACE_RE.match(face):
        raise CalibrationError(f"face {face!r}: name the body axis pointing up as +x, -x, +y, -y, +z or -z")
    v = [0.0, 0.0, 0.0]
    v["xyz".index(face[1])] = 1.0 if face[0] == "+" else -1.0
    return v


def _mv(m, v):
    return [m[3 * r] * v[0] + m[3 * r + 1] * v[1] + m[3 * r + 2] * v[2] for r in range(3)]


def _angle_deg(a, b) -> float:
    cx = a[1] * b[2] - a[2] * b[1]
    cy = a[2] * b[0] - a[0] * b[2]
    cz = a[0] * b[1] - a[1] * b[0]
    return math.degrees(math.atan2(math.sqrt(cx * cx + cy * cy + cz * cz), a[0] * b[0] + a[1] * b[1] + a[2] * b[2]))


def _vec3(r: dict, key: str, what: str) -> list:
    v = r.get(key)
    if not (isinstance(v, list) and len(v) == 3 and all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in v)):
        raise CalibrationError(f"{what}: {key} must be three finite numbers")
    return [float(x) for x in v]


def _norm(v) -> float:
    return math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])


def _check_still(r: dict, what: str):
    if r.get("still") is not True:
        raise CalibrationError(f"{what}: the device reported that the cube moved during the measurement")
    gs = r.get("gyro_std_radps")
    as_ = r.get("accel_std_mps2")
    if gs is not None and _norm(_vec3(r, "gyro_std_radps", what)) >= STILL_GYRO:
        raise CalibrationError(f"{what}: the gyroscope spread shows motion")
    if as_ is not None and _norm(_vec3(r, "accel_std_mps2", what)) >= STILL_ACCEL:
        raise CalibrationError(f"{what}: the accelerometer spread shows motion")


def solve_to_body(axes: list) -> dict:
    """axes: [{"face": "+z", "accel_mean_mps2": [ax, ay, az]}, …] (sensor frame). Returns the best rotation and the fit."""
    if not isinstance(axes, list) or len(axes) < 2:
        raise CalibrationError("at least two calibrate_axes measurements are needed (the cube resting with two different body axes up)")
    ups, faces = [], []
    for i, r in enumerate(axes):
        what = f"axes[{i}]"
        if not isinstance(r, dict):
            raise CalibrationError(f"{what}: a calibrate_axes result object is required")
        if r.get("measurement") not in (None, "calibrate_axes"):
            raise CalibrationError(f"{what}: not a calibrate_axes result")
        e = face_vector(r.get("face"))
        _check_still(r, what)
        a = _vec3(r, "accel_mean_mps2", what)
        n = _norm(a)
        if not abs(n - G0) <= GRAVITY_TOL:
            raise CalibrationError(f"{what}: the measured gravity magnitude {n:.3f} m/s² is not plausible")
        ups.append([x / n for x in a])
        faces.append((r["face"], e))
    if len({f[0][1] for f in faces}) < 2:          # the axis letters: +z and -z name one axis
        raise CalibrationError("the measurements must include two different body axes (for example +z and +x): one axis leaves the rotation about it undetermined")
    fits = []
    for m in ROTATIONS:
        res = [_angle_deg(_mv(m, u), e) for u, (_, e) in zip(ups, faces)]
        fits.append((max(res), m, res))
    fits.sort(key=lambda t: t[0])
    best, m, res = fits[0]
    if best > FIT_MAX_DEG:
        raise CalibrationError(f"no axis-aligned mounting fits the measurements within {FIT_MAX_DEG:g}° (best {best:.1f}°): check the face labels "
                               "and that the IMU is mounted along the body axes", [{"face": f, "residual_deg": round(x, 3)} for (f, _), x in zip(faces, res)])
    second = fits[1][0]
    return {"to_body": m, "max_residual_deg": best, "faces": [{"face": f, "residual_deg": round(x, 4)} for (f, _), x in zip(faces, res)],
            "next_best_deg": second}


def gyro_bias(r: dict) -> dict:
    what = "imu"
    if not isinstance(r, dict):
        raise CalibrationError("a calibrate_imu result (the cube completely still) is required for the gyroscope bias")
    if r.get("measurement") not in (None, "calibrate_imu"):
        raise CalibrationError("imu: not a calibrate_imu result")
    _check_still(r, what)
    b = _vec3(r, "gyro_mean_radps", what)
    if any(abs(x) > 0.2 for x in b):
        raise CalibrationError("imu: a gyroscope bias above 0.2 rad/s is not plausible for this sensor: check the mounting and repeat")
    out = {"gyro_bias_radps": b}
    if r.get("gyro_std_radps") is not None:
        out["gyro_std_radps"] = _vec3(r, "gyro_std_radps", what)
    if r.get("accel_mean_mps2") is not None:
        out["accel_norm_mps2"] = _norm(_vec3(r, "accel_mean_mps2", what))
    if isinstance(r.get("samples"), int) and not isinstance(r.get("samples"), bool):
        out["samples"] = r["samples"]
    if isinstance(r.get("seconds"), (int, float)) and not isinstance(r.get("seconds"), bool):
        out["seconds"] = float(r["seconds"])
    if isinstance(r.get("temp_c"), (int, float)) and not isinstance(r.get("temp_c"), bool):
        out["temp_c"] = float(r["temp_c"])
    return out


def wheel_checks(r: dict, profile: dict) -> list:
    if not isinstance(r, dict) or not isinstance(r.get("wheels"), list) or len(r["wheels"]) != 3:
        raise CalibrationError("encoders: a check_encoders result with three wheels is required")
    out = []
    for i, w in enumerate(r["wheels"]):
        if not isinstance(w, dict):
            raise CalibrationError(f"encoders.wheels[{i}]: an object is required")
        node = ((profile.get("wheels") or [{}] * 3)[i].get("driver") or {}).get("node")
        item = {"index": i, "node": w.get("node", node), "encoder_updates": int(w.get("encoder_updates") or 0)}
        if node is not None and w.get("node") is not None and w.get("node") != node:
            raise CalibrationError(f"encoders.wheels[{i}]: CAN node {w.get('node')} does not match the profile's node {node}")
        if not item["encoder_updates"]:
            item.update(direction_ok=False, checked=False, note="no encoder estimates from this wheel's driver")
            out.append(item)
            continue
        travel = float(w.get("travel_rev") or 0.0)
        vmax = float(w.get("vel_rads_max") or 0.0)
        vmin = float(w.get("vel_rads_min") or 0.0)
        item.update(travel_rev=travel, vel_rads_max=vmax, vel_rads_min=vmin)
        if travel < WHEEL_MIN_TRAVEL_REV:
            item.update(direction_ok=False, checked=False, note="the wheel was not turned (less than a quarter turn): not checked")
        elif vmax >= WHEEL_MIN_SPEED and -vmin <= WHEEL_BACKLASH_RATIO * vmax:
            item.update(direction_ok=True, checked=True, note="turned in the marked positive direction: the reading is positive")
        elif -vmin >= WHEEL_MIN_SPEED and vmax <= WHEEL_BACKLASH_RATIO * -vmin:
            item.update(direction_ok=False, checked=True, note="the reading is NEGATIVE for the marked positive direction: the profile's driver.sign "
                                                               "for this wheel is wrong (create a profile revision with the opposite sign)")
        else:
            item.update(direction_ok=False, checked=True, note="the wheel moved both ways: repeat, turning it in one direction only")
        out.append(item)
    return out


def build_calibration(device_id: str, profile_ref: dict, profile_doc: dict, measurements: dict, *, source: str, evidence: list | None = None) -> dict:
    """measurements = {"imu": <calibrate_imu result>, "axes": [<calibrate_axes result>, …], "encoders": <check_encoders result> | None}.
    Every result is the object the device returned in its cmd_result (sensor frame, unprocessed)."""
    if not isinstance(measurements, dict):
        raise CalibrationError("measurements must be an object {imu, axes, encoders}")
    bias = gyro_bias(measurements.get("imu"))
    fit = solve_to_body(measurements.get("axes"))
    declared = list((profile_doc.get("imu") or {}).get("to_body") or [])
    imu = {"to_body": fit["to_body"], "gyro_bias_radps": bias["gyro_bias_radps"], "to_body_fit": {"max_residual_deg": round(fit["max_residual_deg"], 4),
           "faces": fit["faces"], "next_best_deg": round(fit["next_best_deg"], 3)},
           "declared_to_body": declared, "matches_declared": declared == fit["to_body"]}
    for k in ("gyro_std_radps", "accel_norm_mps2", "samples", "seconds", "temp_c"):
        if k in bias:
            imu[k] = bias[k]
    doc = {"schema": schemas.CALIBRATION_SCHEMA, "device_id": device_id, "profile": {"id": profile_ref["id"], "revision": int(profile_ref["revision"])},
           "source": source, "created": now_iso(), "imu": imu, "evidence": list(evidence or [])}
    notes = []
    if not imu["matches_declared"]:
        notes.append("the measured IMU mounting differs from the profile's declared imu.to_body: configurations built from this calibration use the "
                     "MEASURED mounting; consider a profile revision that declares it")
    enc = measurements.get("encoders")
    if enc is not None:
        doc["wheels"] = wheel_checks(enc, profile_doc)
        bad = [w["index"] for w in doc["wheels"] if not w["direction_ok"]]
        if bad:
            notes.append("wheel direction not confirmed for wheel(s) " + ", ".join(map(str, bad)) + ": experiments stay blocked for a physical device")
    else:
        notes.append("wheel directions were not checked: experiments stay blocked for a physical device until a calibration includes them")
    doc["wheel_directions_confirmed"] = bool(enc is not None and all(w["direction_ok"] for w in doc["wheels"]))
    doc["notes"] = notes
    res = schemas.validate_calibration(doc)
    if not res["ok"]:
        raise CalibrationError("the calibration failed validation", res["errors"])
    return doc

"""The backend's side of aeris-device-link/1 (site/docs/DEVICE_LINK.md): one LinkHost per connection to a device.

Routes (how the bytes reach the device):
  gateway        the device's own outbound WebSocket over TLS (/api/v6/device-link): the backend challenges it and
                 checks the signature against the credential registered at pairing before anything else
  companion      a local process connected to the device's USB port relays the bytes (/api/v6/relay)
  browser-relay  the owner's browser relays a Web Serial port the same way
For the companion and browser routes the device sees a local (USB) host: those sessions supervise, network sessions
observe (the device enforces it).

The host never closes the stabilising loop and never retries a command on its own: a command is sent once with its id,
the device answers cmd_ack / cmd_result, and the outcome is recorded. A command without an answer before its ttl is
recorded as expired ("no answer"); sending the same id again is safe (the device answers with the cached status).
"""
from __future__ import annotations

import base64
import json
import secrets
import time
import zlib

LINK = "aeris-device-link/1"
MAX_LINE = 4096
HEARTBEAT_S = 0.5


def frame(obj) -> bytes:
    js = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return js + b"\t%08x\n" % zlib.crc32(js)


def frame_text(js_text: str) -> bytes:
    b = js_text.encode("utf-8")
    return b + b"\t%08x\n" % zlib.crc32(b)


def b64url_decode(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def verify_es256_raw(pub65: bytes, msg: bytes, sig64: bytes) -> bool:
    """ECDSA P-256 / SHA-256 with a raw r || s signature (cryptography / OpenSSL)."""
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
    if len(pub65) != 65 or pub65[0] != 4 or len(sig64) != 64:
        return False
    try:
        pub = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), pub65)
        pub.verify(encode_dss_signature(int.from_bytes(sig64[:32], "big"), int.from_bytes(sig64[32:], "big")), msg, ec.ECDSA(hashes.SHA256()))
        return True
    except (InvalidSignature, ValueError):
        return False


def pair_message(p: dict) -> bytes:
    return ("AERIS-PAIR-V1\n" + "\n".join([p["session"], p["nonce"], p["device_id"], p["pubkey"], p["board_id"], p["firmware"]]) + "\nlocal-confirmed").encode()


def auth_message(gateway_id: str, gw_session: str, nonce: str, device_id: str, boot_id: str) -> bytes:
    return "\n".join(["AERIS-AUTH-V1", gateway_id, gw_session, nonce, device_id, boot_id]).encode()


class LinkHost:
    """Protocol state for one connection. `send(bytes)` writes to the transport; `on_*` callbacks report to the
    device service. Feed received bytes with receive(); call tick() periodically (≥ 10 Hz)."""

    def __init__(self, route: str, send, *, gateway_id: str = "aeris-backend", clock=time.monotonic):
        self.route = route
        self._send = send
        self.gateway_id = gateway_id
        self.clock = clock
        self.buf = b""
        self.discarding = False
        self.stats = {"lines": 0, "unframed": 0, "bad_crc": 0, "too_long": 0, "not_json": 0, "link_errors": 0, "telemetry": 0}
        self.dev_hello = None
        self.tlm_hello = None                        # the device's latest telemetry hello on this connection (kept also
                                                     # before authentication: the service feeds it when this route starts
                                                     # feeding the device's stream)
        self.state = None
        self.device_id = None
        self.authenticated = route != "gateway"      # USB-side routes are authenticated by the owner's own session
        self.auth_challenge = None
        self.link_session = None
        self.lease_epoch = 0
        self.session_ok = False
        self.role = None
        self.seq = 0
        self.pending = {}                            # command id → {deadline, sent}
        self.last_hb = 0.0
        self.closed = False
        # callbacks (set by the service)
        self.on_dev_hello = None
        self.on_authenticated = None
        self.on_state = None
        self.on_telemetry = None
        self.on_command = None                        # (cmd_id, kind, msg)
        self.on_pairing = None                        # (msg)
        self.on_event = None                          # (kind, msg) everything else (link_error, session_expired, tlm_gap, …)

    # ------------------------------------------------------------------ output
    def send(self, obj):
        if not self.closed:
            self._send(frame(obj))

    def send_raw_json(self, text: str):
        if not self.closed:
            self._send(frame_text(text))

    def start(self):
        self.send({"kind": "host_hello", "versions": [1], "host": self.route})
        if self.route == "gateway":
            self.auth_challenge = {"gateway_id": self.gateway_id, "gw_session": "gws-" + secrets.token_hex(8), "nonce": secrets.token_urlsafe(24)}
            self.send(dict(kind="auth_challenge", **self.auth_challenge))

    def open_session(self, lease_epoch: int):
        self.link_session = "ls-" + secrets.token_hex(10)
        self.lease_epoch = int(lease_epoch)
        self.seq = 0
        self.session_ok = False
        self.send({"kind": "session", "link_session": self.link_session, "lease_epoch": self.lease_epoch})

    def set_lease_epoch(self, epoch: int):
        if epoch > self.lease_epoch and self.link_session:
            self.lease_epoch = int(epoch)
            self.send({"kind": "heartbeat", "link_session": self.link_session, "lease_epoch": self.lease_epoch})

    def send_command(self, cmd_id: str, action: str, params, ttl_ms: int, config_hash: str | None = None, raw_params_text: str | None = None) -> dict:
        """Frame and send one command. raw_params_text carries a params object whose exact bytes matter (apply_config:
        the device hashes the configuration as received)."""
        if not self.link_session:
            raise RuntimeError("no session on this link yet")
        seq = self.seq + 1                           # consumed only when the command is sent
        head = {"kind": "cmd", "id": cmd_id, "v": 1, "link_session": self.link_session, "lease_epoch": self.lease_epoch, "seq": seq,
                "action": action, "ttl_ms": int(ttl_ms)}
        if config_hash:
            head["config_hash"] = config_hash
        text = json.dumps(head, separators=(",", ":"), ensure_ascii=False)
        if raw_params_text is not None:
            text = text[:-1] + ',"params":' + raw_params_text + "}"
        elif params is not None:
            text = text[:-1] + ',"params":' + json.dumps(params, separators=(",", ":"), ensure_ascii=False) + "}"
        if len(text.encode("utf-8")) + 10 > MAX_LINE:
            raise ValueError("command too long for one link line")
        self.seq = seq
        self.pending[cmd_id] = {"deadline": self.clock() + ttl_ms / 1000.0 + 2.0, "sent": self.clock()}
        self.send_raw_json(text)
        return {"seq": self.seq, "lease_epoch": self.lease_epoch, "link_session": self.link_session}

    def resend_command_text(self, text: str):
        self.send_raw_json(text)

    def pair_begin(self, session: str, nonce: str):
        self.send({"kind": "pair_begin", "session": session, "nonce": nonce})

    def tlm_resume(self, session: str, after: int):
        self.send({"kind": "tlm_resume", "session": session, "after": int(after)})

    # ------------------------------------------------------------------ input
    def receive(self, data: bytes):
        self.buf += data
        while True:
            i = self.buf.find(b"\n")
            if i < 0:
                if len(self.buf) > MAX_LINE:
                    self.buf = b""
                    self.discarding = True
                return
            line, self.buf = self.buf[:i], self.buf[i + 1:]
            if self.discarding or len(line) > MAX_LINE:
                self.discarding = False
                self.stats["too_long"] += 1      # a line longer than the protocol allows is dropped whole, never parsed
                continue
            self._line(line.rstrip(b"\r"))

    def _line(self, line: bytes):
        if not line:
            return
        self.stats["lines"] += 1
        if len(line) < 10 or line[-9:-8] != b"\t":
            self.stats["unframed"] += 1           # e.g. the chip's ROM boot text: ignored
            return
        js, crc = line[:-9], line[-8:]
        try:
            if int(crc, 16) != zlib.crc32(js):
                self.stats["bad_crc"] += 1
                return
            msg = json.loads(js.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            self.stats["not_json"] += 1
            return
        if not isinstance(msg, dict):
            self.stats["not_json"] += 1
            return
        if "type" in msg and "kind" not in msg:
            self.stats["telemetry"] += 1
            if msg.get("type") == "hello":
                self.tlm_hello = msg
            elif msg.get("type") == "bye":
                self.tlm_hello = None
            if self.authenticated and self.on_telemetry:
                self.on_telemetry(msg)
            return
        k = msg.get("kind")
        if k == "dev_hello":
            self.dev_hello = msg
            self.device_id = msg.get("device_id")
            if self.on_dev_hello:
                self.on_dev_hello(msg)
        elif k == "auth":
            self._on_auth(msg)
        elif k == "state":
            self.state = msg
            if self.authenticated and self.on_state:
                self.on_state(msg)
        elif k == "session_ok":
            if msg.get("link_session") == self.link_session:
                self.session_ok = True
                self.role = msg.get("role")
            if self.on_event:
                self.on_event(k, msg)
        elif k in ("cmd_ack", "cmd_result"):
            cid = msg.get("id")
            if msg.get("status") in ("completed", "failed", "rejected", "expired"):
                self.pending.pop(cid, None)
            elif cid in self.pending and msg.get("status") in ("accepted", "executing"):
                self.pending[cid]["deadline"] = self.clock() + 3600.0      # the device owns it now (experiments last longer than a ttl)
            if self.authenticated and self.on_command:
                self.on_command(cid, k, msg)
        elif k in ("pair_ready", "pair_proof", "pair_rejected"):
            if self.on_pairing:
                self.on_pairing(msg)
        else:
            if k == "link_error":
                self.stats["link_errors"] += 1
            if k == "session_expired":
                self.session_ok = False
                # the device dropped the session (no heartbeat within 1.5 s; it has stopped anything that was running):
                # open a new one at once; commands of the old session are never resent
                if self.link_session and msg.get("link_session") == self.link_session and not self.closed:
                    self.open_session(self.lease_epoch)
                    self.stats["sessions_reopened"] = self.stats.get("sessions_reopened", 0) + 1
            if self.on_event:
                self.on_event(k, msg)

    def _on_auth(self, msg):
        ch = self.auth_challenge
        if self.route != "gateway" or ch is None or self.authenticated:
            return
        if self.on_authenticated is None:
            return
        self.on_authenticated(msg, ch)               # the service checks the credential and calls accept_auth()

    def accept_auth(self, device_id: str):
        self.authenticated = True
        self.device_id = device_id

    # ------------------------------------------------------------------ time
    def tick(self):
        now = self.clock()
        if self.link_session and now - self.last_hb >= HEARTBEAT_S:
            self.last_hb = now
            self.send({"kind": "heartbeat", "link_session": self.link_session, "lease_epoch": self.lease_epoch})
        for cid, p in list(self.pending.items()):
            if now > p["deadline"]:
                self.pending.pop(cid, None)
                if self.on_command:
                    self.on_command(cid, "host_timeout", {"id": cid, "status": "expired", "reason": "no answer from the device before the command's ttl (never resent automatically)"})

    def close(self):
        self.closed = True

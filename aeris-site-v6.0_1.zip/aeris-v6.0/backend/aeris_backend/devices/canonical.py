"""Canonical JSON and content hashes for device documents.

A document's hash is the SHA-256 of its canonical JSON text: keys sorted, no insignificant whitespace, UTF-8, no
NaN/Infinity, Python's shortest round-trip number formatting. The approved device configuration is sent to the device
as exactly these bytes inside the command, and the device hashes the bytes it received (firmware command.c
run_apply_config), so the hash the backend records is the hash the device reports.
"""
from __future__ import annotations

import hashlib
import json
import math


def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if hasattr(o, "tolist"):
        return _clean(o.tolist())
    if isinstance(o, bool) or o is None or isinstance(o, str):
        return o
    if isinstance(o, int):
        return int(o)
    if isinstance(o, float):
        if not math.isfinite(o):
            raise ValueError("non-finite number in a device document")
        return float(o)
    if hasattr(o, "item"):
        return _clean(o.item())
    raise TypeError(f"not JSON-serialisable: {type(o).__name__}")


def canonical_text(obj) -> str:
    return json.dumps(_clean(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def canonical_bytes(obj) -> bytes:
    return canonical_text(obj).encode("utf-8")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def content_hash(obj) -> str:
    """Hex SHA-256 of the canonical text (no prefix: the device reports the same 64 hex characters)."""
    return sha256_hex(canonical_bytes(obj))

"""DeviceService: devices, pairing, connections, leases, bounded commands, approved configurations, calibrations,
per-device telemetry and recordings (site/docs/CONNECT.md, site/docs/DEVICE_LINK.md).

Ownership: a device belongs to the owner who paired it (proof: the device's signature over the owner's single-use
pairing nonce, given only after a press of the cube's ARM control). Every query is scoped by owner; another owner's
device is "not found". A device can be re-paired by another owner only after its owner revoked it.

Control: one control lease per device (owner + holder, an epoch that increases on every change of holder). Commands
that change the device carry the holder's lease; the device refuses a command whose epoch is not current. stop is
accepted from any session of the owner and needs no lease. Nothing is ever resent automatically, and after a backend
restart every open command is closed as expired: a restart never resurrects a request.

Telemetry: each connected device has its own TelemetryHub (a stream identity, contiguous frame index, recording to
aeris-hardware-run/1). Provenance comes from the device's own hello: a synthetic device declares itself an emulator;
a board declares "physical" — DECLARED, never verified by the software.
"""
from __future__ import annotations

import asyncio
import json
import secrets
import time

from ..experiments.records import now_iso
from ..telemetry.stream import TelemetryHub
from . import calibration as CAL
from . import compat, configgen, reference, schemas
from .canonical import content_hash
from .linkhost import LinkHost, auth_message, b64url_decode, pair_message, verify_es256_raw

PAIR_TTL_S = 300
LEASE_TTL_S = 30.0
CATCHUP_S = 3.0                 # how long live frames wait for the device's backfill (tlm_resume → tlm_resumed)
CATCHUP_MAX = 4096              # live frames held during a catch-up at most (the device's ring holds 512)
REF_OWNER = "aeris"          # built-in reference documents, readable by every owner
MUTATING = {"identify", "self_test", "calibrate_imu", "calibrate_axes", "check_encoders", "apply_config", "start_experiment", "clear_faults",
            "set_telemetry", "reboot", "commission", "motor_test", "unpair"}
REMOTE_ACTIONS = {"identify", "diagnostics", "self_test", "calibrate_imu", "calibrate_axes", "check_encoders", "apply_config", "start_experiment", "stop",
                  "clear_faults", "set_telemetry", "reboot"}       # never: set_network, unpair, enter_update, commission, motor_test (USB-local only)
FINAL = ("completed", "failed", "rejected", "expired", "cancelled")


class ServiceError(Exception):
    def __init__(self, status: int, code: str, message: str, details=None):
        super().__init__(message)
        self.status, self.code, self.message, self.details = status, code, message, details


class Connection:
    """One transport to a device (a WebSocket from the device, the companion or a browser relay).

    out      link bytes for the device (the transport writes them)
    ctl      control messages for a relaying client (pairing progress, the device it is attached to); never sent to
             the device
    closed   set when the service ends the connection (failed authentication, revoked credential, replaced route)"""

    def __init__(self, route: str, owner: str | None, gateway_id: str):
        self.route = route
        self.owner = owner                     # None for the gateway until the device authenticated
        self.out = asyncio.Queue(maxsize=2048)
        self.ctl = asyncio.Queue(maxsize=64)
        self.closed = asyncio.Event()
        self.close_reason = None
        self.host = LinkHost(route, self._queue, gateway_id=gateway_id)
        self.opened = now_iso()
        self.device_id = None
        self.unpaired_hello = None
        self.pair_outcome = None
        self.dropped_bytes = 0

    def _queue(self, b: bytes):
        try:
            self.out.put_nowait(b)
        except asyncio.QueueFull:
            self.dropped_bytes += len(b)        # a stalled transport loses bytes; the CRC framing rejects partial lines

    def close(self, reason: str = "closed"):
        if self.close_reason is None:
            self.close_reason = reason
        self.host.close()
        self.closed.set()

    def notify(self, msg: dict):
        try:
            self.ctl.put_nowait(msg)
        except asyncio.QueueFull:
            pass


class DeviceRuntime:
    def __init__(self, device_id: str, owner: str):
        self.device_id = device_id
        self.owner = owner
        self.hub = TelemetryHub()
        self.routes = {}                        # route name → Connection
        self.state = None
        self.dev_hello = None
        self.subscribers = set()                # asyncio.Queue of owner UI sockets
        self.events = []
        self.last_tlm = {"session": None, "seq": 0}   # the device's telemetry session and the last frame the hub accepted
        self.feeder = None                      # the Connection whose telemetry feeds the hub (the preferred route)
        self.catchup = None                     # backfill in progress after a reconnect or a route change (see _tlm_start)
        self.catchups = []                      # the last 20 completed catch-ups (device view: what was resent or missing)
        self.compat = None                      # compat.negotiate() of the latest hello

    def usb(self):
        for r in ("companion", "browser-relay"):
            c = self.routes.get(r)
            if c is not None:
                return c
        return None

    def preferred(self):
        return self.usb() or self.routes.get("gateway")


class DeviceService:
    def __init__(self, repo, auth, *, store_recording=None, gateway_id: str = "aeris-backend"):
        self.repo = repo
        self.auth = auth
        self.store_recording = store_recording
        self.gateway_id = gateway_id
        self.runtimes = {}                      # device_id → DeviceRuntime
        self.pending_pairs = {}                 # pairing session → (owner, Connection)
        self._tick_task = None
        self._closed_on_start = self._close_open_commands()

    # ------------------------------------------------------------------ start-up
    def _close_open_commands(self) -> int:
        n = 0
        for c in self.repo.commands_open():
            self.repo.command_update(c["id"], "expired", {"t": now_iso(), "status": "expired", "by": "backend",
                                                          "reason": "the backend restarted before a final status arrived; the command is never resent"})
            n += 1
        return n

    async def start(self):
        if self._tick_task is None:
            self._tick_task = asyncio.get_running_loop().create_task(self._ticker())

    async def stop(self):
        if self._tick_task:
            self._tick_task.cancel()
            try:
                await self._tick_task
            except (asyncio.CancelledError, Exception):
                pass
            self._tick_task = None

    async def _ticker(self):
        while True:
            await asyncio.sleep(0.1)
            self.tick(time.monotonic())

    def tick(self, now: float):
        """Periodic work (10 Hz): catch-up deadlines, telemetry staleness, heartbeats and command deadlines per route."""
        for rt in list(self.runtimes.values()):
            if rt.catchup is not None and now > rt.catchup["deadline"]:
                self._catchup_end(rt, now, "the device did not finish resending within %g s" % CATCHUP_S)
            rt.hub.tick(now)
            for c in list(rt.routes.values()):
                c.host.tick()

    def status(self) -> dict:
        return {"devices_connected": len([r for r in self.runtimes.values() if r.routes]), "auth": self.auth.cfg.summary(),
                "commands_closed_at_start": self._closed_on_start}

    # ------------------------------------------------------------------ documents: profiles, recipes, kits, calibrations
    def _profile_key(self, owner, pid, rev):
        return f"{owner}:{pid}@{rev}"

    def profile_get(self, owner: str, pid: str, rev: int | None = None) -> dict:
        if pid == reference.REFERENCE_PROFILE["id"] and rev in (None, 1):
            p = reference.reference_profile()
            return {"owner": REF_OWNER, "id": pid, "revision": 1, "hash": content_hash(p), "document": p, "reference": True}
        for o in (owner, REF_OWNER):
            head = self.repo.get("profile_heads", f"{o}:{pid}")
            if head:
                r = rev or head["latest"]
                d = self.repo.get("profiles", self._profile_key(o, pid, r))
                if d:
                    return d
        raise ServiceError(404, "not_found", f"profile {pid} not found")

    def profile_list(self, owner: str) -> list:
        out = [{"id": reference.REFERENCE_PROFILE["id"], "revision": 1, "name": reference.REFERENCE_PROFILE["name"], "reference": True,
                "qualification": reference.REFERENCE_PROFILE["qualification"]["status"]}]
        for h in self.repo.list_where("profile_heads", 1000, owner=owner):
            out.append({"id": h.get("profile_id"), "revision": h.get("latest"), "name": h.get("name"), "reference": False, "qualification": h.get("qualification")})
        return out

    def profile_create_revision(self, owner: str, doc: dict) -> dict:
        res = schemas.validate_profile(doc, author_is_user=True)
        if not res["ok"]:
            raise ServiceError(422, "invalid_profile", "The profile failed validation.", res["errors"])
        pid = doc["id"]
        if pid == reference.REFERENCE_PROFILE["id"]:
            raise ServiceError(409, "reserved", "the reference profile id is reserved; copy it under your own id")
        head = self.repo.get("profile_heads", f"{owner}:{pid}")
        rev = (head["latest"] + 1) if head else 1
        h = content_hash(doc)
        if head:
            prev = self.repo.get("profiles", self._profile_key(owner, pid, head["latest"]))
            if prev and prev["hash"] == h:
                return dict(prev, unchanged=True)
        stored = {"owner": owner, "id": pid, "revision": rev, "hash": h, "created": now_iso(), "document": doc, "validation": res}
        if not self.repo.put_new("profiles", self._profile_key(owner, pid, rev), stored, owner=owner, profile_id=pid, revision=rev, hash=h):
            raise ServiceError(409, "conflict", "that revision exists already (concurrent write); retry")
        self.repo.put("profile_heads", f"{owner}:{pid}", {"owner": owner, "profile_id": pid, "latest": rev, "created": now_iso()},
                      owner=owner, profile_id=pid, latest=rev, name=doc.get("name"), qualification=doc["qualification"]["status"])
        return stored

    def recipe_get(self, owner: str, rid: str) -> dict:
        if rid in reference.RECIPES:
            r = reference.recipe(rid)
            return {"owner": REF_OWNER, "id": rid, "hash": content_hash(r), "document": r, "reference": True}
        d = self.repo.get("recipes", f"{owner}:{rid}")
        if not d:
            raise ServiceError(404, "not_found", f"recipe {rid} not found")
        return d

    def recipe_list(self, owner: str) -> list:
        out = [{"id": r["id"], "name": r["name"], "mode": r["mode"], "reference": True, "requires": r.get("requires", [])} for r in reference.RECIPES.values()]
        out += [{"id": x.get("recipe_id"), "name": x.get("name"), "mode": x.get("mode"), "reference": False} for x in self.repo.list_where("recipes", 1000, owner=owner)]
        return out

    def recipe_create(self, owner: str, doc: dict) -> dict:
        res = schemas.validate_recipe(doc)
        if not res["ok"]:
            raise ServiceError(422, "invalid_recipe", "The recipe failed validation.", res["errors"])
        if doc["id"] in reference.RECIPES:
            raise ServiceError(409, "reserved", "a reference recipe id is reserved")
        stored = {"owner": owner, "id": doc["id"], "hash": content_hash(doc), "created": now_iso(), "document": doc, "validation": res}
        if not self.repo.put_new("recipes", f"{owner}:{doc['id']}", stored, owner=owner, recipe_id=doc["id"], name=doc.get("name"), mode=doc["mode"]):
            raise ServiceError(409, "exists", "a recipe with that id exists; recipes are immutable — use a new id")
        return stored

    def _calibration_inputs(self, owner: str, device_id: str, body: dict):
        """The measurements of a calibration and the evidence for each: either the ids of completed device commands
        (the backend received their results itself: origin backend-command-log) or results relayed by the client
        from a Web Serial session the backend did not see (origin client-reported)."""
        cmds, raw = body.get("commands"), body.get("measurements")
        if (cmds is None) == (raw is None):
            raise ServiceError(422, "calibration_inputs", "give either 'commands' (ids of completed device commands) or 'measurements' (device results)")
        want = {"imu": "calibrate_imu", "axes": "calibrate_axes", "encoders": "check_encoders"}
        meas, evidence = {}, []
        if cmds is not None:
            if not isinstance(cmds, dict):
                raise ServiceError(422, "calibration_inputs", "commands: {imu: id, axes: [id, …], encoders: id}")

            def take(cid, action):
                c = self.repo.command_get(cid, owner) if isinstance(cid, str) else None
                if c is None or c["device_id"] != device_id:
                    raise ServiceError(422, "calibration_inputs", f"command {cid!r}: no such command of this device")
                if c["action"] != action or c["status"] != "completed" or not isinstance(c.get("result"), dict):
                    raise ServiceError(422, "calibration_inputs", f"command {cid}: a completed {action} with a result is required (it is {c['action']}, {c['status']})")
                done = [h.get("t") for h in c.get("history") or [] if h.get("status") == "completed"]
                evidence.append({"command": cid, "action": action, "origin": "backend-command-log", "completed": done[-1] if done else None,
                                 "result_sha256": content_hash(c["result"]), "route": c.get("route")})
                return c["result"]
            meas["imu"] = take(cmds.get("imu"), "calibrate_imu")
            axes = cmds.get("axes")
            if not isinstance(axes, list):
                raise ServiceError(422, "calibration_inputs", "commands.axes: a list of calibrate_axes command ids")
            meas["axes"] = [take(a, "calibrate_axes") for a in axes]
            if cmds.get("encoders") is not None:
                meas["encoders"] = take(cmds["encoders"], "check_encoders")
        else:
            if not isinstance(raw, dict):
                raise ServiceError(422, "calibration_inputs", "measurements: {imu: result, axes: [result, …], encoders: result}")
            meas = {"imu": raw.get("imu"), "axes": raw.get("axes"), "encoders": raw.get("encoders")}
            for k, act in want.items():
                items = meas.get(k) if k == "axes" else [meas.get(k)]
                for it in (items or []):
                    if it is not None:
                        evidence.append({"action": act, "origin": "client-reported", "result_sha256": content_hash(it),
                                         "note": "relayed by the owner's client from a session the backend did not observe"})
        return meas, evidence

    def calibration_create(self, owner: str, device_id: str, body: dict) -> dict:
        dev = self.device_get(owner, device_id)
        prof_ref = body.get("profile") or {"id": dev.get("profile_id") or reference.REFERENCE_PROFILE["id"], "revision": dev.get("profile_revision") or 1}
        prof = self.profile_get(owner, prof_ref["id"], prof_ref.get("revision"))
        meas, evidence = self._calibration_inputs(owner, device_id, body)
        try:
            cal = CAL.build_calibration(device_id, {"id": prof["id"], "revision": prof["revision"]}, prof["document"], meas,
                                        source="synthetic-device" if dev.get("synthetic") else "device-measurement", evidence=evidence)
        except CAL.CalibrationError as e:
            raise ServiceError(422, "calibration_rejected", str(e), getattr(e, "details", None))
        res = schemas.validate_calibration(cal)
        if not res["ok"]:
            raise ServiceError(422, "invalid_calibration", "The calibration failed validation.", res["errors"])
        cid = "AERIS-CAL-%06d" % self.repo.next_id("calibration")
        stored = {"owner": owner, "id": cid, "device_id": device_id, "created": now_iso(), "hash": content_hash(cal), "document": cal}
        self.repo.put_new("calibrations", cid, stored, owner=owner, device_id=device_id, profile_id=prof["id"], profile_revision=prof["revision"], hash=stored["hash"])
        return stored

    def calibration_get(self, owner: str, cid: str) -> dict:
        d = self.repo.get("calibrations", cid)
        if not d or d.get("owner") != owner:
            raise ServiceError(404, "not_found", f"calibration {cid} not found")
        return d

    def calibration_list(self, owner: str, device_id: str) -> list:
        self.device_get(owner, device_id)
        return self.repo.list_where("calibrations", 1000, owner=owner, device_id=device_id)

    # ------------------------------------------------------------------ approved configurations
    def build_config(self, owner: str, device_id: str, recipe_id: str, calibration_id: str | None, profile_ref: dict | None = None) -> dict:
        dev = self.device_get(owner, device_id)
        pr = profile_ref or {"id": dev.get("profile_id") or reference.REFERENCE_PROFILE["id"], "revision": dev.get("profile_revision")}
        prof = self.profile_get(owner, pr["id"], pr.get("revision"))
        rec = self.recipe_get(owner, recipe_id)
        cal = self.calibration_get(owner, calibration_id) if calibration_id else None
        if cal and cal["device_id"] != device_id:
            raise ServiceError(409, "calibration_device", "that calibration belongs to another device")
        if cal and (cal["document"]["profile"]["id"] != prof["id"] or cal["document"]["profile"]["revision"] != prof["revision"]):
            raise ServiceError(409, "calibration_profile", "that calibration was made for another profile revision")
        if not dev.get("synthetic") and cal is None:
            raise ServiceError(409, "calibration_required", "a physical device needs a calibration of its own before an approved configuration is built")
        rt = self.runtimes.get(device_id)
        if rt is not None and rt.dev_hello:
            why = compat.profile_fits(rt.dev_hello, prof["document"], rec["document"])
            if why:
                raise ServiceError(409, "incompatible", "the profile or recipe does not fit the connected device", why)
        try:
            built = configgen.device_config(prof["document"], rec["document"], cal["document"] if cal else None,
                                            profile_ref={"id": prof["id"], "revision": prof["revision"], "hash": prof["hash"]},
                                            calibration_ref={"id": cal["id"], "hash": cal["hash"]} if cal else None)
        except configgen.ConfigError as e:
            raise ServiceError(422, "config_error", str(e), e.errors)
        doc = {"owner": owner, "id": built["hash"], "device_id": device_id, "created": now_iso(), "text": built["text"], "config": built["config"],
               "profile": {"id": prof["id"], "revision": prof["revision"], "hash": prof["hash"]}, "recipe": {"id": rec["id"], "hash": rec["hash"], "mode": rec["document"]["mode"]},
               "calibration": {"id": cal["id"], "hash": cal["hash"]} if cal else None, "engine_config": built["engine_config"], "design": built["design_summary"]}
        self.repo.put_new("device_configs", f"{owner}:{built['hash']}", doc, owner=owner, device_id=device_id, recipe=rec["id"], hash=built["hash"])
        return doc

    def config_get(self, owner: str, h: str) -> dict:
        d = self.repo.get("device_configs", f"{owner}:{h}")
        if not d:
            raise ServiceError(404, "not_found", "configuration not found")
        return d

    # ------------------------------------------------------------------ devices
    def device_get(self, owner: str, device_id: str) -> dict:
        d = self.repo.device_get(device_id, owner)
        if d is None or d.get("revoked"):
            raise ServiceError(404, "not_found", f"device {device_id} not found")
        return d

    def device_view(self, owner: str, device_id: str) -> dict:
        d = self.device_get(owner, device_id)
        rt = self.runtimes.get(device_id)
        lease = self.repo.lease_get(device_id)
        return dict(d, connected=bool(rt and rt.routes), routes=sorted(rt.routes) if rt else [], state=rt.state if rt else None,
                    dev_hello=rt.dev_hello if rt else None, compat=rt.compat if rt else None, lease=lease,
                    telemetry=rt.hub.status(time.monotonic()) if rt else None,
                    telemetry_route=rt.feeder.route if rt and rt.feeder else None,
                    telemetry_catchups=list(rt.catchups) if rt else [])

    def device_list(self, owner: str) -> list:
        return [dict(d, connected=bool(self.runtimes.get(d["id"]) and self.runtimes[d["id"]].routes)) for d in self.repo.device_list(owner)]

    def device_set_profile(self, owner: str, device_id: str, pid: str, rev: int) -> dict:
        self.device_get(owner, device_id)
        p = self.profile_get(owner, pid, rev)
        return self.repo.device_update(device_id, owner, profile_id=p["id"], profile_revision=p["revision"])

    def device_revoke(self, owner: str, device_id: str) -> dict:
        self.device_get(owner, device_id)
        d = self.repo.device_revoke(device_id, owner)
        rt = self.runtimes.get(device_id)
        if rt:
            for c in list(rt.routes.values()):
                c.close("the device was revoked by its owner")   # a revoked credential loses every connection at once
            self.runtimes.pop(device_id, None)
        return d

    # ------------------------------------------------------------------ pairing
    def pairing_start(self, owner: str) -> dict:
        session = "pair-" + secrets.token_hex(10)
        nonce = secrets.token_urlsafe(24)
        return self.repo.pairing_create(session, owner, nonce, PAIR_TTL_S)

    def pairing_complete(self, owner: str, proof: dict, *, name: str | None = None) -> dict:
        """Check a pair_proof (from the owner's browser, the companion or a relay) and register the device."""
        need = ("session", "nonce", "device_id", "pubkey", "board_id", "firmware", "sig")
        if not isinstance(proof, dict) or any(not isinstance(proof.get(k), str) or not proof.get(k) for k in need):
            raise ServiceError(422, "invalid_proof", "pair_proof needs " + ", ".join(need))
        if proof.get("local_confirmed") is not True:
            raise ServiceError(422, "invalid_proof", "the proof does not state a local confirmation")
        try:
            pub = b64url_decode(proof["pubkey"])
            sig = b64url_decode(proof["sig"])
        except (ValueError, TypeError):
            raise ServiceError(422, "invalid_proof", "pubkey and sig must be base64url")
        if not verify_es256_raw(pub, pair_message(proof), sig):
            raise ServiceError(422, "invalid_signature", "the pairing signature does not verify with the presented key")
        ok, why = self.repo.pairing_consume(proof["session"], owner, proof["nonce"], proof["device_id"], "paired")
        if not ok:
            raise ServiceError(409, "pairing_refused", why)
        try:
            dev = self.repo.device_register({"id": proof["device_id"], "owner": owner, "pubkey": proof["pubkey"], "board": proof["board_id"],
                                             "firmware": proof["firmware"], "synthetic": bool(proof.get("synthetic")), "name": name or proof["device_id"],
                                             "profile_id": reference.REFERENCE_PROFILE["id"], "profile_revision": 1,
                                             "extra": {"build": proof.get("build"), "paired_via": proof.get("via")}})
        except ValueError as e:
            raise ServiceError(409, "owned_elsewhere", str(e))
        return dev

    # ------------------------------------------------------------------ connections
    def connection_open(self, route: str, owner: str | None) -> Connection:
        c = Connection(route, owner, self.gateway_id)
        h = c.host
        h.on_dev_hello = lambda m, c=c: self._on_dev_hello(c, m)
        h.on_authenticated = lambda m, ch, c=c: self._on_auth(c, m, ch)
        h.on_state = lambda m, c=c: self._on_state(c, m)
        h.on_telemetry = lambda m, c=c: self._on_telemetry(c, m)
        h.on_command = lambda cid, k, m, c=c: self._on_command(c, cid, k, m)
        h.on_pairing = lambda m, c=c: self._on_pairing(c, m)
        h.on_event = lambda k, m, c=c: self._on_event(c, k, m)
        h.start()
        return c

    def connection_closed(self, c: Connection, reason: str):
        c.host.close()
        rt = self.runtimes.get(c.device_id) if c.device_id else None
        if rt and rt.routes.get(c.route) is c:
            del rt.routes[c.route]
            if rt.feeder is c:
                # the stream's carrier is gone: the hub's session ends here; another route (or this one, reconnected)
                # continues the device's telemetry session and asks the device for what was missed (_tlm_start)
                now = time.monotonic()
                if rt.catchup is not None:
                    self._catchup_end(rt, now, "the route closed during the catch-up")
                rt.feeder = None
                rt.hub.on_disconnect(reason, now)
            self._publish(rt, {"type": "route", "route": c.route, "connected": False, "reason": reason})
            for p, (o, cc) in list(self.pending_pairs.items()):
                if cc is c:
                    del self.pending_pairs[p]

    def _runtime_for(self, c: Connection, device_id: str, owner: str) -> DeviceRuntime:
        rt = self.runtimes.get(device_id)
        if rt is None or rt.owner != owner:
            if rt is not None:
                for oc in list(rt.routes.values()):
                    oc.close("the device now belongs to another account")
            rt = DeviceRuntime(device_id, owner)
            self.runtimes[device_id] = rt
        old = rt.routes.get(c.route)
        if old is not None and old is not c:
            old.close("replaced by a newer connection on the same route")
        rt.routes[c.route] = c
        c.device_id = device_id
        # the hub's connection follows the route that FEEDS it (_tlm_start), not every route that attaches: a second
        # route (the gateway while the companion carries the stream) must not end the current telemetry session
        return rt

    def _on_dev_hello(self, c: Connection, m: dict):
        did = m.get("device_id")
        if not isinstance(did, str) or not did:
            return
        if c.route == "gateway":
            if c.device_id and c.device_id != did:
                c.close("the device identity changed inside an authenticated connection")
            return
        # USB-side routes: the owner's own computer is attached to this device; it supervises once it is paired to them
        if c.device_id and c.device_id != did:
            old = self.runtimes.get(c.device_id)
            if old and old.routes.get(c.route) is c:
                del old.routes[c.route]
                if old.feeder is c:
                    if old.catchup is not None:
                        self._catchup_end(old, time.monotonic(), "another device was attached to this relay")
                    old.feeder = None
                    old.hub.on_disconnect("another device was attached to this relay", time.monotonic())
        dev = self.repo.device_get(did, c.owner)
        c.device_id = did
        board = m.get("board") if isinstance(m.get("board"), dict) else {}
        info = {"type": "device", "device_id": did, "board": board, "fw": m.get("fw"), "device_kind": board.get("kind"),
                "synthetic": bool(board.get("synthetic")), "paired_to_you": bool(dev and not dev.get("revoked")), "dev_hello": m,
                "declared": "board, kind and synthetic are what the device declares; the software never verifies them"}
        if dev is None or dev.get("revoked"):
            c.unpaired_hello = m
            c.notify(dict(info, note="this device is not paired to your account: pair it (press ARM on the cube when asked)"))
            return
        rt = self._runtime_for(c, did, c.owner)
        rt.dev_hello = m
        rt.compat = compat.negotiate(m)
        info["compat"] = rt.compat
        self.repo.device_update(did, c.owner, last_seen=now_iso(), firmware=(m.get("fw") or {}).get("version"))
        lease = self.repo.lease_get(did)
        c.host.open_session(lease["epoch"] if lease else 0)
        c.notify(info)
        self._publish(rt, {"type": "route", "route": c.route, "connected": True, "dev_hello": m})

    def _on_auth(self, c: Connection, m: dict, ch: dict):
        did = m.get("device_id")
        dev = self.repo.device_get(did) if isinstance(did, str) else None
        if m.get("error") or dev is None or dev.get("revoked") or not isinstance(m.get("sig"), str) or not isinstance(m.get("boot_id"), str):
            c.close("authentication refused (unknown, revoked or unpaired device)")
            return
        if c.host.dev_hello and c.host.dev_hello.get("device_id") != did:
            c.close("authentication refused (identity differs from the device's hello)")
            return
        try:
            ok = verify_es256_raw(b64url_decode(dev["pubkey"]), auth_message(ch["gateway_id"], ch["gw_session"], ch["nonce"], did, m["boot_id"]), b64url_decode(m["sig"]))
        except (ValueError, TypeError):
            ok = False
        if not ok:
            c.close("authentication refused (the signature does not verify with the registered key)")
            return
        c.owner = dev["owner"]
        c.host.accept_auth(did)
        rt = self._runtime_for(c, did, dev["owner"])
        rt.dev_hello = c.host.dev_hello
        rt.compat = compat.negotiate(rt.dev_hello)
        self.repo.device_update(did, dev["owner"], last_seen=now_iso())
        lease = self.repo.lease_get(did)
        c.host.open_session(lease["epoch"] if lease else 0)
        self._publish(rt, {"type": "route", "route": "gateway", "connected": True, "dev_hello": c.host.dev_hello})

    def _on_state(self, c: Connection, m: dict):
        rt = self.runtimes.get(c.device_id or "")
        if rt and rt.routes.get(c.route) is c:
            rt.state = dict(m, route=c.route)
            self._publish(rt, {"type": "state", "state": rt.state})

    # ------------------------------------------------------------------ telemetry continuity (v6)
    # The device keeps ONE telemetry session (until a reboot, a new configuration or a rate change) and sends it on
    # every active link; the hub takes one copy, from the preferred route (USB-side first, then the gateway). When the
    # carrier changes — the route closed and another continues, or the same route reconnected — the new carrier's
    # telemetry hello opens a hub session and, if it is the SAME device session, the device is asked to resend what
    # came after the last frame the hub accepted (tlm_resume; its ring holds the last 512 frames). Live frames wait
    # (bounded, CATCHUP_S) until the resent ones have been fed, so the hub receives each frame once and in order.
    # What the device no longer holds comes back as tlm_gap and is recorded as a gap (TelemetryHub.source_gap), never
    # filled in or skipped silently. Nothing is ever resent to the device.
    def _on_telemetry(self, c: Connection, m: dict):
        rt = self.runtimes.get(c.device_id or "")
        if not rt or rt.routes.get(c.route) is not c:
            return
        if rt.preferred() is not c:
            return                              # one copy of the stream: the preferred route's
        now = time.monotonic()
        typ = m.get("type")
        if typ == "hello":
            self._tlm_start(rt, c, m, now)
            return
        if rt.feeder is not c:
            if c.host.tlm_hello is None:
                rt.hub.feed_message(m, now)     # nothing to open a session with: the hub refuses and counts it
                return
            self._tlm_start(rt, c, c.host.tlm_hello, now)
        cu = rt.catchup
        if cu is not None and cu["conn"] is c and typ != "frame":
            self._catchup_end(rt, now, f"the device sent a telemetry '{typ}' message")     # e.g. bye: frames first, then the end
            cu = None
        if cu is not None and cu["conn"] is c and isinstance(m.get("seq"), int):
            seq = m["seq"]
            if seq < cu["next"]:
                cu["late"] += 1                 # already fed (or reported missing): never fed twice
                return
            cu["buf"][seq] = m
            self._catchup_drain(rt, now)
            if rt.catchup is not None and len(cu["buf"]) > CATCHUP_MAX:
                self._catchup_end(rt, now, f"more than {CATCHUP_MAX} live frames waited")
            return
        self._tlm_feed(rt, m, now)

    def _tlm_feed(self, rt: DeviceRuntime, m: dict, now: float):
        r = rt.hub.feed_message(m, now)
        if r == "frame" and isinstance(m.get("seq"), int):
            rt.last_tlm["seq"] = max(rt.last_tlm["seq"], m["seq"])

    def _tlm_start(self, rt: DeviceRuntime, c: Connection, hello: dict, now: float):
        """Connection c carries the device's stream from this telemetry hello on (a new device session, or the same one
        on another route / after a reconnection: then the frames since the last accepted one are requested)."""
        if rt.catchup is not None:
            self._catchup_end(rt, now, "the device sent a new telemetry hello")
        if rt.feeder is not c and rt.hub.connected:
            rt.hub.on_disconnect(f"telemetry continues on the {c.route} route", now)
        rt.feeder = c
        if not rt.hub.connected:
            rt.hub.on_connect({"kind": "device-link", "route": c.route, "device": rt.device_id}, now)
        sess = hello.get("session")
        same = isinstance(sess, str) and sess and sess == rt.last_tlm["session"]
        after = rt.last_tlm["seq"] if same else 0
        if rt.hub.feed_message(hello, now) != "hello":
            return
        if not same:
            rt.last_tlm = {"session": sess, "seq": 0}
        if after > 0:
            rt.catchup = {"conn": c, "session": sess, "after": after, "next": after + 1, "buf": {}, "late": 0, "missing": 0, "through": None,
                          "deadline": now + CATCHUP_S}
            c.host.tlm_resume(sess, after)
            self._publish(rt, {"type": "event", "event": {"t": now_iso(), "kind": "tlm_catchup", "route": c.route,
                                                         "message": {"session": sess, "after": after, "status": "requested"}}})

    def _catchup_drain(self, rt: DeviceRuntime, now: float):
        cu = rt.catchup
        while cu["next"] in cu["buf"]:
            self._tlm_feed(rt, cu["buf"].pop(cu["next"]), now)
            cu["next"] += 1
        if cu["through"] is not None and cu["next"] > cu["through"]:
            self._catchup_end(rt, now, None)

    def _catchup_event(self, rt: DeviceRuntime, kind: str, m: dict, now: float):
        cu = rt.catchup
        if m.get("session") != cu["session"]:
            return
        if kind == "tlm_gap":
            a, b = m.get("from"), m.get("to")
            if isinstance(a, int) and isinstance(b, int) and b >= cu["next"] and a <= cu["next"]:
                missing = b - cu["next"] + 1
                cu["missing"] += missing
                rt.hub.source_gap(missing, now, f"{missing} frame(s) {cu['next']}…{b} of telemetry session {cu['session']} were no longer "
                                                f"held by the device ({m.get('reason')})")
                cu["next"] = b + 1
                self._catchup_drain(rt, now)
            elif m.get("reason") == "session-ended":
                self._catchup_end(rt, now, "the device's telemetry session had ended")
        elif kind == "tlm_resumed" and isinstance(m.get("through"), int):
            cu["through"] = m["through"]
            self._catchup_drain(rt, now)

    def _catchup_end(self, rt: DeviceRuntime, now: float, reason: str | None):
        cu, rt.catchup = rt.catchup, None
        if cu is None:
            return
        # frames after 'after' fed in order during the catch-up (up to the device's 'through' when it said how far it resent)
        fed = cu["next"] - 1 - cu["after"] - cu["missing"]
        recovered = fed if cu["through"] is None else max(0, min(cu["next"] - 1, cu["through"]) - cu["after"] - cu["missing"])
        expect = cu["next"]
        for seq in sorted(cu["buf"]):           # whatever waited is fed in order; a hole left is recorded as a gap
            if seq > expect:
                why = reason or "the device's resend ended before them"
                rt.hub.source_gap(seq - expect, now, f"{seq - expect} frame(s) {expect}…{seq - 1} of telemetry session {cu['session']} did not arrive ({why})")
            self._tlm_feed(rt, cu["buf"][seq], now)
            expect = seq + 1
        rt.catchups.append({"session": cu["session"], "after": cu["after"], "through": cu["through"], "recovered": recovered, "missing": cu["missing"],
                            "late": cu["late"], "ended": reason or "complete", "route": cu["conn"].route})
        del rt.catchups[:-20]
        self._publish(rt, {"type": "event", "event": {"t": now_iso(), "kind": "tlm_catchup", "route": cu["conn"].route,
                                                     "message": dict(rt.catchups[-1], status="done" if reason is None else "ended")}})

    def _on_command(self, c: Connection, cid: str, kind: str, m: dict):
        cmd = self.repo.command_get(cid) if isinstance(cid, str) else None
        if cmd is None or cmd["device_id"] != c.device_id:
            return                              # not a command of this device (never another device's or owner's)
        st = m.get("status")
        if kind == "host_timeout":
            if cmd["status"] in FINAL:
                return
        elif cmd["status"] in FINAL:
            last = (cmd.get("history") or [{}])[-1]
            if last.get("kind") in ("cmd_ack", "cmd_result") and last.get("status") == st:
                return                          # the device repeated what it said (a duplicate id): nothing new
            # otherwise the device's own later word is recorded: e.g. a result that arrived after the host gave up
        ev = {"t": now_iso(), "status": st, "kind": kind, "reason": m.get("reason"), "device_state": m.get("state"), "route": c.route}
        if m.get("duplicate"):
            ev["duplicate"] = True
        result = m.get("result") if isinstance(m.get("result"), (dict, list)) else None
        self.repo.command_update(cid, st if st else cmd["status"], ev, result)
        rt = self.runtimes.get(c.device_id or "")
        if rt:
            self._publish(rt, {"type": "command", "id": cid, "status": st, "event": ev, "result": result})

    def _on_pairing(self, c: Connection, m: dict):
        k = m.get("kind")
        sess = m.get("session")
        pend = self.pending_pairs.get(sess)
        if pend is None:
            return
        owner, cc = pend
        if cc is not c:
            return                              # a proof must come back over the connection the pairing was started on
        if k == "pair_proof":
            try:
                dev = self.pairing_complete(owner, dict(m, via=c.route), name=getattr(c, "pair_name", None))
                outcome = {"type": "pairing", "status": "paired", "device": {k2: dev.get(k2) for k2 in ("id", "name", "board", "firmware", "synthetic", "paired")}}
            except ServiceError as e:
                outcome = {"type": "pairing", "status": "failed", "reason": e.message}
            del self.pending_pairs[sess]
            c.pair_outcome = outcome
            c.notify(outcome)
            if outcome["status"] == "paired":
                hello = c.host.dev_hello or c.unpaired_hello
                if hello:
                    self._on_dev_hello(c, hello)
        elif k == "pair_rejected":
            del self.pending_pairs[sess]
            c.pair_outcome = {"type": "pairing", "status": "failed", "reason": m.get("reason")}
            c.notify(c.pair_outcome)
        else:
            c.pair_outcome = {"type": "pairing", "status": "waiting_for_local_confirmation", "expires_in_ms": m.get("expires_in_ms"),
                              "instruction": "press ARM on the cube to confirm the pairing"}
            c.notify(c.pair_outcome)

    def _on_event(self, c: Connection, kind: str, m: dict):
        rt = self.runtimes.get(c.device_id or "")
        if rt and rt.routes.get(c.route) is c and rt.catchup is not None and rt.catchup["conn"] is c and kind in ("tlm_gap", "tlm_resumed"):
            self._catchup_event(rt, kind, m, time.monotonic())
        if rt:
            ev = {"t": now_iso(), "kind": kind, "route": c.route, "message": m}
            rt.events.append(ev)
            del rt.events[:-200]
            self._publish(rt, {"type": "event", "event": ev})

    def pair_via_connection(self, owner: str, c: Connection, name: str | None = None) -> dict:
        """Start a pairing over a USB-side route (companion, browser relay): the device then waits for its ARM press."""
        if c.route == "gateway":
            raise ServiceError(409, "pairing_needs_usb", "pairing needs the local USB link (press ARM on the cube)")
        if c.owner != owner:
            raise ServiceError(403, "forbidden", "this relay belongs to another account")
        if not (c.host.dev_hello or c.unpaired_hello):
            raise ServiceError(409, "no_device", "no device has introduced itself on this relay yet (is the cube connected and powered?)")
        for s, (_o, cc) in list(self.pending_pairs.items()):
            if cc is c:
                del self.pending_pairs[s]          # one pairing at a time per relay; a newer request replaces it
        p = self.pairing_start(owner)
        self.pending_pairs[p["session"]] = (owner, c)
        c.pair_name = name if isinstance(name, str) and 0 < len(name) <= 80 else None
        c.pair_outcome = {"type": "pairing", "status": "started", "session": p["session"], "expires": p["expires"]}
        c.notify(c.pair_outcome)
        c.host.pair_begin(p["session"], p["nonce"])
        return p

    # ------------------------------------------------------------------ leases
    def lease_acquire(self, owner: str, device_id: str, holder: str, takeover: bool = False) -> dict:
        self.device_get(owner, device_id)
        lease, why = self.repo.lease_acquire(device_id, owner, holder, LEASE_TTL_S, takeover=takeover)
        if lease is None:
            raise ServiceError(409, "lease_held", why)
        rt = self.runtimes.get(device_id)
        if rt:
            for c in rt.routes.values():
                c.host.set_lease_epoch(lease["epoch"])
        return lease

    def lease_release(self, owner: str, device_id: str, holder: str) -> dict:
        self.device_get(owner, device_id)
        return {"released": self.repo.lease_release(device_id, owner, holder)}

    # ------------------------------------------------------------------ commands
    def command_submit(self, owner: str, device_id: str, holder: str | None, action: str, params=None, ttl_ms: int = 5000,
                       config_hash: str | None = None, route: str | None = None) -> dict:
        dev = self.device_get(owner, device_id)
        if action not in REMOTE_ACTIONS:
            raise ServiceError(422, "action_not_available", f"'{action}' is not available through the backend (USB-local actions are offered by the Connect page over Web Serial)")
        if not isinstance(ttl_ms, int) or not 100 <= ttl_ms <= 10000:
            raise ServiceError(422, "ttl", "ttl_ms: 100…10000")
        rt = self.runtimes.get(device_id)
        conn = (rt.routes.get(route) if (rt and route) else (rt.preferred() if rt else None))
        if conn is None or not conn.host.link_session:
            raise ServiceError(409, "not_connected", "the device is not connected (or its session is not open yet)")
        cp = rt.compat or compat.negotiate(rt.dev_hello)
        if action not in cp["actions"]:
            raise ServiceError(409, "not_offered", f"the device does not offer '{action}'"
                               + (" — it is connected read-only: " + "; ".join(cp["reasons"]) if not cp["supported"] else ""))
        if action in MUTATING:
            lease = self.repo.lease_get(device_id)
            import datetime as _dt
            if not lease or lease["owner"] != owner or lease["holder"] != holder or \
                    _dt.datetime.fromisoformat(lease["expires"].replace("Z", "+00:00")) < _dt.datetime.now(_dt.timezone.utc):
                raise ServiceError(409, "lease_required", "this action needs the control lease (acquire it first)")
            if lease["epoch"] != conn.host.lease_epoch:
                conn.host.set_lease_epoch(lease["epoch"])
        raw_text = None
        if action == "apply_config":
            cfgdoc = self.config_get(owner, config_hash or "")
            if cfgdoc["device_id"] != device_id:
                raise ServiceError(409, "config_device", "that configuration was built for another device")
            why = compat.profile_fits(rt.dev_hello, self.profile_get(owner, cfgdoc["profile"]["id"], cfgdoc["profile"]["revision"])["document"],
                                      self.recipe_get(owner, cfgdoc["recipe"]["id"])["document"])
            if why:
                raise ServiceError(409, "incompatible", "this configuration does not fit the connected device", why)
            raw_text = '{"config":' + cfgdoc["text"] + "}"
            params = None
        if action == "start_experiment":
            cfgdoc = self.config_get(owner, config_hash or "")
            st = (rt.state or {}) if rt else {}
            if st.get("config_hash") != config_hash:
                raise ServiceError(409, "config_not_applied", "the device does not report this configuration as applied")
            rec = self.recipe_get(owner, cfgdoc["recipe"]["id"])
            # the corner trial follows a completed edge trial of the same device and profile revision; a device that
            # declares itself synthetic has no hardware to protect (its plant is fixed to one mode) and needs none
            if "edge-trial-completed" in (rec["document"].get("requires") or []) and not dev.get("synthetic") \
                    and not self._edge_trial_done(owner, device_id, cfgdoc["profile"]):
                raise ServiceError(409, "prerequisite", "this recipe needs a completed edge trial on this device with the same profile revision")
            if not dev.get("synthetic"):
                cref = cfgdoc.get("calibration")
                cal = self.calibration_get(owner, cref["id"]) if cref else None
                if cal is None or not cal["document"].get("wheel_directions_confirmed"):
                    raise ServiceError(409, "wheel_directions_unconfirmed", "the applied configuration was built from a calibration without three "
                                       "confirmed wheel directions (check_encoders, each wheel turned by hand in its marked direction): a wrong "
                                       "driver sign makes the controller push the cube over")
            params = dict(params or {})
            params.setdefault("duration_s", rec["document"]["duration_s"])
        cid = "c-" + secrets.token_hex(8)
        cmd = {"id": cid, "device_id": device_id, "owner": owner, "holder": holder, "action": action, "params": params if raw_text is None else {"config_hash": config_hash},
               "config_hash": config_hash, "created": now_iso(), "ttl_ms": ttl_ms, "status": "queued",
               "history": [{"t": now_iso(), "status": "queued", "by": "backend"}], "route": conn.route, "lease_epoch": conn.host.lease_epoch}
        self.repo.command_insert(cmd)
        try:
            info = conn.host.send_command(cid, action, params, ttl_ms, config_hash, raw_params_text=raw_text)
        except (RuntimeError, ValueError) as e:
            self.repo.command_update(cid, "failed", {"t": now_iso(), "status": "failed", "by": "backend", "reason": str(e)})
            raise ServiceError(409, "send_failed", str(e))
        self.repo.command_update(cid, "sent", {"t": now_iso(), "status": "sent", "by": "backend", "seq": info["seq"], "lease_epoch": info["lease_epoch"]})
        return self.repo.command_get(cid, owner)

    def _edge_trial_done(self, owner, device_id, profile_ref) -> bool:
        for c in self.repo.command_list(device_id, owner, 500):
            if c["action"] != "start_experiment" or c["status"] != "completed":
                continue
            res = c.get("result") or {}
            if res.get("ended") != "duration reached":
                continue
            try:
                cfg = self.config_get(owner, c.get("config_hash") or "")
            except ServiceError:
                continue
            if cfg["recipe"]["mode"] == "edge" and cfg["profile"]["id"] == profile_ref["id"] and cfg["profile"]["revision"] == profile_ref["revision"]:
                return True
        return False

    def command_get(self, owner: str, cid: str) -> dict:
        c = self.repo.command_get(cid, owner)
        if c is None:
            raise ServiceError(404, "not_found", "command not found")
        return c

    # ------------------------------------------------------------------ telemetry and recordings
    def runtime(self, owner: str, device_id: str) -> DeviceRuntime:
        self.device_get(owner, device_id)
        rt = self.runtimes.get(device_id)
        if rt is None:
            raise ServiceError(409, "not_connected", "the device has not connected since the backend started")
        return rt

    def recording_start(self, owner: str, device_id: str, name: str) -> dict:
        rt = self.runtime(owner, device_id)
        try:
            return rt.hub.start_recording(name, time.monotonic())
        except RuntimeError as e:
            raise ServiceError(409, "recording_state", str(e))

    def recording_stop(self, owner: str, device_id: str) -> dict:
        rt = self.runtime(owner, device_id)
        try:
            doc = rt.hub.stop_recording(time.monotonic())
        except RuntimeError as e:
            raise ServiceError(409, "recording_state", str(e))
        st = rt.state or {}
        extra = {"owner": owner, "device_id": device_id, "config_hash": st.get("config_hash"), "boot_id": st.get("boot_id"),
                 "route": (rt.preferred().route if rt.preferred() else None)}
        if self.store_recording is None:
            return {"document": doc, "device": extra}
        return self.store_recording(doc, "device-link", extra)

    # ------------------------------------------------------------------ owner UI subscriptions
    def subscribe(self, owner: str, device_id: str):
        """An owner UI's subscription to one device: (queue of service messages, the device runtime). Works before
        the device connects (the runtime is created and waits for it)."""
        self.device_get(owner, device_id)
        rt = self.runtimes.get(device_id)
        if rt is None or rt.owner != owner:
            rt = DeviceRuntime(device_id, owner)
            self.runtimes[device_id] = rt
        q = asyncio.Queue(maxsize=512)
        rt.subscribers.add(q)
        return q, rt

    def unsubscribe(self, device_id: str, q):
        rt = self.runtimes.get(device_id)
        if rt:
            rt.subscribers.discard(q)

    def _publish(self, rt: DeviceRuntime, msg: dict):
        for q in list(rt.subscribers):
            try:
                q.put_nowait(msg)
            except asyncio.QueueFull:
                pass

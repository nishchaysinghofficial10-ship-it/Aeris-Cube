"""Owners and authentication of the device API (site/docs/CONNECT.md §Security).

Modes (AERIS_AUTH):
  local (default)  a single owner, "local": for a backend on this computer. Refused when the backend is bound to a
                   non-loopback address (AERIS_BIND_HOST) or when a public origin is configured: the device endpoints
                   are then disabled rather than exposed without authentication.
  jwt              every device request carries `Authorization: Bearer <access token>` issued by the configured
                   identity provider (OAuth 2.0 / OpenID Connect). Verified with PyJWT against the issuer's JWKS:
                     AERIS_JWT_ISSUER      the exact `iss`
                     AERIS_JWT_AUDIENCE    the exact `aud` this backend accepts
                     AERIS_JWT_JWKS_URL    the issuer's JWKS endpoint (https), or AERIS_JWT_JWKS_FILE (a JWKS file)
                     AERIS_JWT_ALGORITHMS  default "RS256,ES256" (never "none", never HS*)
                     AERIS_PUBLIC_ORIGIN   https://… the TLS origin the site and the devices use (TLS is terminated by
                                           the reverse proxy in front of this process); http:// only for loopback
                   The owner of everything a request creates or reads is "<iss>|<sub>".
The development fixture (python -m aeris_backend.tools.devauth) creates a local issuer key and JWKS under
data/dev-auth for exercising jwt mode on this computer. Tokens of its issuer ("aeris-dev-issuer") are refused whenever
the public origin is not a loopback origin, so the fixture can never secure a public deployment.
No credentials are built into this code; no custom cryptography is used (PyJWT, cryptography).
"""
from __future__ import annotations

import json
import os
import urllib.parse

DEV_ISSUER = "aeris-dev-issuer"
LOCAL_OWNER = "local"


class AuthConfigError(ValueError):
    """An unsafe or incomplete configuration: the device API is not offered."""


class AuthError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def _is_loopback_host(h: str) -> bool:
    return h in ("127.0.0.1", "::1", "localhost") or h.startswith("127.")


def _is_loopback_origin(origin: str) -> bool:
    try:
        u = urllib.parse.urlparse(origin)
    except ValueError:
        return False
    return _is_loopback_host(u.hostname or "")


class AuthConfig:
    def __init__(self, env=None):
        env = os.environ if env is None else env
        self.mode = (env.get("AERIS_AUTH") or "local").strip().lower()
        self.bind_host = (env.get("AERIS_BIND_HOST") or "127.0.0.1").strip()
        self.public_origin = (env.get("AERIS_PUBLIC_ORIGIN") or "").strip().rstrip("/")
        self.issuer = (env.get("AERIS_JWT_ISSUER") or "").strip()
        self.audience = (env.get("AERIS_JWT_AUDIENCE") or "").strip()
        self.jwks_url = (env.get("AERIS_JWT_JWKS_URL") or "").strip()
        self.jwks_file = (env.get("AERIS_JWT_JWKS_FILE") or "").strip()
        self.algorithms = [a.strip() for a in (env.get("AERIS_JWT_ALGORITHMS") or "RS256,ES256").split(",") if a.strip()]
        self.problem = None
        try:
            self._check()
        except AuthConfigError as e:
            self.problem = str(e)

    def _check(self):
        if self.mode not in ("local", "jwt"):
            raise AuthConfigError(f"AERIS_AUTH={self.mode!r}: use 'local' or 'jwt'")
        if self.mode == "local":
            if not _is_loopback_host(self.bind_host):
                raise AuthConfigError(f"the backend is bound to {self.bind_host}: the device API needs AERIS_AUTH=jwt (local mode is for this computer only)")
            if self.public_origin and not _is_loopback_origin(self.public_origin):
                raise AuthConfigError("AERIS_PUBLIC_ORIGIN is a public origin: the device API needs AERIS_AUTH=jwt")
            return
        bad = [a for a in self.algorithms if a.lower() == "none" or a.upper().startswith("HS")]
        if bad:
            raise AuthConfigError(f"AERIS_JWT_ALGORITHMS: {', '.join(bad)} not allowed (asymmetric signatures only)")
        if not self.issuer or not self.audience:
            raise AuthConfigError("jwt mode needs AERIS_JWT_ISSUER and AERIS_JWT_AUDIENCE")
        if not (self.jwks_url or self.jwks_file):
            raise AuthConfigError("jwt mode needs AERIS_JWT_JWKS_URL (the issuer's key set) or AERIS_JWT_JWKS_FILE")
        if self.jwks_url and not self.jwks_url.startswith("https://") and not _is_loopback_origin(self.jwks_url):
            raise AuthConfigError("AERIS_JWT_JWKS_URL must be https://")
        if not self.public_origin:
            raise AuthConfigError("jwt mode needs AERIS_PUBLIC_ORIGIN (the https:// origin served by the TLS-terminating proxy)")
        loop = _is_loopback_origin(self.public_origin)
        if not loop and not self.public_origin.startswith("https://"):
            raise AuthConfigError("AERIS_PUBLIC_ORIGIN must be https:// (devices and browsers reach the backend over TLS only)")
        if self.issuer == DEV_ISSUER and not loop:
            raise AuthConfigError("the development identity fixture (issuer aeris-dev-issuer) cannot secure a public origin")

    @property
    def ok(self) -> bool:
        return self.problem is None

    def summary(self) -> dict:
        return {"mode": self.mode, "enabled": self.ok, "problem": self.problem, "public_origin": self.public_origin or None,
                "issuer": self.issuer or None, "audience": self.audience or None,
                "development_fixture": self.mode == "jwt" and self.issuer == DEV_ISSUER}


class Authenticator:
    def __init__(self, cfg: AuthConfig):
        self.cfg = cfg
        self._jwk_client = None
        self._jwks = None

    def _key_for(self, token: str):
        import jwt
        if self.cfg.jwks_file:
            if self._jwks is None:
                with open(self.cfg.jwks_file, encoding="utf-8") as f:
                    self._jwks = jwt.PyJWKSet.from_dict(json.load(f))
            kid = jwt.get_unverified_header(token).get("kid")
            for k in self._jwks.keys:
                if kid is None or k.key_id == kid:
                    return k.key
            raise AuthError(401, "unknown signing key (kid)")
        if self._jwk_client is None:
            self._jwk_client = jwt.PyJWKClient(self.cfg.jwks_url, cache_keys=True, lifespan=600)
        return self._jwk_client.get_signing_key_from_jwt(token).key

    def owner_from_token(self, token: str) -> str:
        import jwt
        if not token:
            raise AuthError(401, "a bearer token is required")
        try:
            key = self._key_for(token)
            claims = jwt.decode(token, key, algorithms=self.cfg.algorithms, audience=self.cfg.audience, issuer=self.cfg.issuer,
                                options={"require": ["exp", "iat", "sub", "iss", "aud"]}, leeway=30)
        except AuthError:
            raise
        except Exception as e:                      # jwt.PyJWTError, key fetch errors
            raise AuthError(401, f"invalid token: {type(e).__name__}") from None
        sub = claims.get("sub")
        if not isinstance(sub, str) or not sub:
            raise AuthError(401, "invalid token: no subject")
        return f"{claims['iss']}|{sub}"

    def owner(self, authorization: str | None) -> str:
        """The owner of a request (raises AuthError). local mode: always 'local'."""
        if not self.cfg.ok:
            raise AuthError(503, "the device API is disabled: " + str(self.cfg.problem))
        if self.cfg.mode == "local":
            return LOCAL_OWNER
        if not authorization or not authorization.lower().startswith("bearer "):
            raise AuthError(401, "Authorization: Bearer <token> required")
        return self.owner_from_token(authorization[7:].strip())

    def check_origin(self, origin: str | None, allowed: list) -> bool:
        """Browser WebSocket origin check (devices and the companion send no Origin header)."""
        if origin is None:
            return True
        if self.cfg.mode == "jwt":
            return origin == self.cfg.public_origin or origin in allowed
        return origin in allowed or _is_loopback_origin(origin)

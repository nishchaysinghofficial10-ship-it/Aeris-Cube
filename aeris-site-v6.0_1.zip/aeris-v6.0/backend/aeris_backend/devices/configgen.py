"""From a device profile, an experiment recipe and (optionally) a calibration to:

  engine_config()   an ordinary aeris-config/1 engine configuration of the same cube and experiment
                    ("Simulate My Cube" runs exactly this through the research engine)
  device_config()   the approved configuration aeris-device-config/1 the firmware applies (gains designed by
                    control/design.py on the profile's model; limits from the profile and the recipe), as canonical
                    text and its SHA-256 (the hash the device reports back)
  plant_model()     aeris-plant-model/1: the plant of the synthetic device (firmware/sim) for the same profile — the
                    engine's own plant matrices, so the synthetic device and the twin share one model
  profile_parameter_set()  the parameter-set identity of a "Simulate My Cube" run: the profile's value groups declared
                    measured, at the engine's parameter-set paths, so the run is labelled by the same coverage rule as
                    every other run (docs/PARAMETERS.md: MEASURED only when every model input is measured)

The gains are design outputs, not tuning: a configuration is regenerated (never edited) when the profile, the
calibration or the recipe changes, and its hash changes with it.
"""
from __future__ import annotations

import copy
import math

import numpy as np

from ..actuators import WheelSet
from ..config.normalize import default_config
from ..config.validate import validate_config
from ..constants import CF3D_DEFAULTS, LQR_DEFAULTS, QEQ
from ..physics.quaternion import edge_quat, from_to
from ..simulation.setup import design_for_config, edge_drive_index
from . import schemas
from .canonical import canonical_text, content_hash, sha256_hex

DEG = math.pi / 180.0
RPM = math.pi / 30.0


class ConfigError(ValueError):
    def __init__(self, message, errors=None):
        super().__init__(message)
        self.errors = errors or []


def _require_valid(profile, recipe, calibration):
    E = []
    for name, res in (("profile", schemas.validate_profile(profile, author_is_user=False)), ("recipe", schemas.validate_recipe(recipe))):
        E += [dict(e, document=name) for e in res["errors"]]
    if calibration is not None:
        E += [dict(e, document="calibration") for e in schemas.validate_calibration(calibration)["errors"]]
    if E:
        raise ConfigError("invalid input documents: " + "; ".join(f"{e['document']}.{e['path']}: {e['message']}" for e in E[:6]), E)


def kt_of(w) -> float:
    return 60.0 / (2 * math.pi * w["motor"]["KV_rpm_per_V"])


def to_body_of(profile, calibration):
    """The IMU mounting used: a calibration's measured orientation overrides the profile's declared one."""
    if calibration is not None and (calibration.get("imu") or {}).get("to_body") is not None:
        return list(calibration["imu"]["to_body"])
    return list(profile["imu"]["to_body"])


def engine_config(profile: dict, recipe: dict, calibration: dict | None = None, *, seed: int = 7) -> dict:
    """The engine configuration of this cube running this recipe (raw aeris-config/1, validated by the engine)."""
    mode = recipe["mode"]
    cfg = default_config(mode)
    p = cfg["params"]
    body = profile["body"]
    w0 = profile["wheels"][0]
    p["a"] = body["edge_m"]
    p["m"] = body["mass_kg"]
    if body.get("inertia_factor") is not None:
        p["kJ"] = body["inertia_factor"]
    p["g"] = profile.get("g_mps2", 9.81)
    p["fs"] = recipe["rates"]["control_hz"]
    p["Jw"] = w0["Jw_kgm2"]
    p["KV"] = w0["motor"]["KV_rpm_per_V"]
    p["R"] = w0["motor"]["R_ohm"]
    p["Vs"] = w0["motor"]["supply_V"]
    p["Imax"] = w0["motor"]["Imax_A"]
    p["wmaxRpm"] = w0["motor"]["speed_max_rpm"]
    p["cv"] = w0["friction"]["cv"]
    p["cc"] = w0["friction"]["cc"]
    pos = profile["imu"]["position_m"]
    p["rImu"] = math.sqrt(sum(x * x for x in pos))
    cfg["wheels"] = [{"id": w["id"], "axis": list(w["axis"]), "Jw": w["Jw_kgm2"], "KV": w["motor"]["KV_rpm_per_V"], "R": w["motor"]["R_ohm"],
                      "Vs": w["motor"]["supply_V"], "Imax": w["motor"]["Imax_A"], "wmaxRpm": w["motor"]["speed_max_rpm"],
                      "cv": w["friction"]["cv"], "cc": w["friction"]["cc"]} for w in profile["wheels"]]
    plant = {}
    if body.get("com_m") is not None:
        plant["base_com_m"] = list(body["com_m"])
    if body.get("inertia_kgm2") is not None:
        plant["base_inertia_kgm2"] = copy.deepcopy(body["inertia_kgm2"])
    if body.get("components"):
        plant["components"] = [{"id": c["id"], "label": c.get("label", c["id"]), "mass_kg": c["mass_kg"], "com_m": list(c["com_m"]),
                                **({"inertia_kgm2": c["inertia_kgm2"]} if c.get("inertia_kgm2") is not None else {})} for c in body["components"]]
    if plant:
        cfg["plant"] = plant
    weights = dict(LQR_DEFAULTS)
    weights.update((recipe["controller"].get("weights") or {}))
    cfg["controller"] = {"type": "lqr", "knowsAttachments": True, "reconfigureOnFailure": False,
                         "structure": "decoupled" if mode == "edge" else "mimo-lqr", "lqr": weights}
    est = recipe["estimator"]
    cf = {k: est.get(k, CF3D_DEFAULTS[k]) for k in CF3D_DEFAULTS}
    cfg["estimator"] = {"type": "cf3d", "cf3d": cf}
    if est.get("stale_after_s") is not None:
        cfg["estimator"]["stale_after_s"] = est["stale_after_s"]
    nz = profile["imu"].get("noise") or {}
    cfg["sensor"]["gyro_noise_dps"] = nz.get("gyro_dps", cfg["sensor"]["gyro_noise_dps"])
    cfg["sensor"]["accel_noise_mps2"] = nz.get("accel_mps2", cfg["sensor"]["accel_noise_mps2"])
    # the device removes its calibrated bias; what is left for the twin is the calibration residual (not modelled: 0)
    cfg["sensor"]["gyro_bias_dps"] = 0.0
    cfg["sensor"]["imu_position_m"] = list(pos)
    cfg["sensor"]["rate_hz"] = None
    cfg["initial"] = {"tilt_deg": float((recipe.get("start") or {}).get("tilt_deg", 1.0)), "rate_dps": 0, "azimuth_deg": 0, "reference": "balance"}
    cfg["duration_s"] = recipe["duration_s"]
    cfg["seed"] = seed
    return cfg


def design(profile: dict, recipe: dict, calibration: dict | None = None) -> dict:
    _require_valid(profile, recipe, calibration)
    raw = engine_config(profile, recipe, calibration)
    v = validate_config(raw)
    if v.errors:
        raise ConfigError("the engine refuses this profile/recipe: " + "; ".join(f"{e['path']}: {e['message']}" for e in v.errors[:6]), v.errors)
    cfg = v.config
    wheels = WheelSet(cfg)
    d = design_for_config(cfg, v.mp, wheels)
    return {"engine_config": raw, "config": cfg, "mp": v.mp, "design": d, "wheels": wheels}


def device_config(profile: dict, recipe: dict, calibration: dict | None = None, *, profile_ref: dict | None = None,
                  calibration_ref: dict | None = None) -> dict:
    """The approved device configuration. profile_ref = {"id", "revision", "hash"} of the stored profile revision."""
    D = design(profile, recipe, calibration)
    cfg, d, W = D["config"], D["design"], D["wheels"]
    mode = recipe["mode"]
    if profile_ref is None:
        profile_ref = {"id": profile["id"], "revision": 0, "hash": content_hash(profile)}
    est = recipe["estimator"]
    imu = profile["imu"]
    odr = imu["odr_hz"]
    stale = est.get("stale_after_s")
    if stale is None:
        stale = round(4.0 / odr + 1.0 / recipe["rates"]["control_hz"], 6)       # four samples plus one control period
    if mode == "edge":
        drive = edge_drive_index(W)
        K = [float(x) for x in d["tilt"]["K"]]
        controller = {"type": "edge-lqr", "K": K, "beta_ref_rad": float(d.get("betaRef", 0.0)), "drive_wheel": int(drive)}
        q_nom = list(edge_quat(0.0))
    else:
        u = [float(x) for x in d["uRef"]]
        controller = {"type": "corner-mimo-lqr", "K": [[float(x) for x in row] for row in d["mimo"]["K"]],
                      "q_eq": [float(x) for x in from_to(tuple(u), (0.0, 0.0, 1.0))], "u_ref": u}
        q_nom = list(QEQ)
    gb = [0.0, 0.0, 0.0]
    if calibration is not None:
        # the calibration measured the bias in the SENSOR frame; the device subtracts it after to_body
        tb = np.array(to_body_of(profile, calibration), dtype=float).reshape(3, 3)
        gb = [float(x) for x in tb @ np.array(calibration["imu"]["gyro_bias_radps"], dtype=float)]
    lim = recipe["limits"]
    el = profile["electrical"]
    factor = lim.get("wheel_speed_abort_factor", 1.05)
    wheels = []
    for w, ws in zip(profile["wheels"], W.wheels):
        kt = kt_of(w)
        wheels.append({"axis": [float(x) for x in ws.axis], "sign": int(w["driver"]["sign"]), "driver": w["driver"]["kind"],
                       "node": int(w["driver"]["node"]), "Jw_kgm2": float(w["Jw_kgm2"]), "kt_NmA": kt,
                       "current_max_A": float(w["motor"]["Imax_A"]), "torque_max_Nm": kt * float(w["motor"]["Imax_A"]),
                       "speed_max_rpm": float(w["motor"]["speed_max_rpm"])})
    doc = {
        "schema": schemas.DEVICE_CONFIG_SCHEMA,
        "profile": {"id": profile_ref["id"], "revision": int(profile_ref["revision"]), "hash": profile_ref["hash"]},
        "calibration": calibration_ref,
        "recipe": recipe["id"],
        "mode": mode,
        "controller": controller,
        "estimator": {"type": "cf3d", "tau_s": float(est["tau_s"]), "accel_gate_mps2": float(est["accel_gate_mps2"]),
                      "bias_gain": float(est["bias_gain"]), "tau_alpha_s": float(est["tau_alpha_s"]), "stale_after_s": float(stale),
                      "g_mps2": float(profile.get("g_mps2", 9.81)), "imu_position_m": [float(x) for x in imu["position_m"]],
                      "q_nominal": [float(x) for x in q_nom], "compensate_dynamic": bool(est.get("compensate_dynamic", True))},
        "imu": {"driver": imu["driver"], "i2c_address": int(imu["i2c_address"]), "odr_hz": int(odr), "accel_range_g": int(imu["accel_range_g"]),
                "gyro_range_dps": int(imu["gyro_range_dps"]), "to_body": [int(x) for x in to_body_of(profile, calibration)], "gyro_bias_radps": gb},
        "wheels": wheels,
        "limits": {"tilt_start_deg": float(lim["tilt_start_deg"]), "tilt_abort_deg": float(lim["tilt_abort_deg"]),
                   "wheel_speed_abort_rpm": float(max(w["speed_max_rpm"] for w in wheels) * factor),
                   "current_abort_A": float(el["current_abort_A"]), "temperature_abort_C": float(el["temperature_abort_C"]),
                   "vbus_min_V": float(el["vbus_min_V"]), "vbus_max_V": float(el["vbus_max_V"]),
                   "link_loss_max_s": float(lim["link_loss_max_s"]), "duration_max_s": float(recipe["duration_s"]),
                   "stop_torque_Nm": float(lim["stop_torque_Nm"]), "arm_window_s": float(lim["arm_window_s"])},
        "rates": {"control_hz": int(recipe["rates"]["control_hz"]), "imu_hz": int(odr), "telemetry_hz": int(recipe["rates"]["telemetry_hz"])},
        "allocation": "clip",
    }
    doc = _round_floats(doc)
    text = canonical_text(doc)
    return {"config": doc, "text": text, "hash": sha256_hex(text.encode("utf-8")), "engine_config": D["engine_config"],
            "design_summary": _design_summary(d, mode)}


def _f32(x) -> float:
    """A number as the device will hold it: 9 significant digits identify a single-precision value exactly, so the
    configuration carries no digits the device would discard (and the canonical text stays short)."""
    return float(f"{float(x):.9g}")


def _round_floats(o):
    if isinstance(o, dict):
        return {k: _round_floats(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_round_floats(v) for v in o]
    if isinstance(o, float):
        return _f32(o)
    return o


def _design_summary(d, mode):
    if mode == "edge":
        t = d["tilt"]
        return {"mode": "edge", "K": [float(x) for x in t["K"]], "betaRef": float(d.get("betaRef", 0.0)),
                "closed_loop_poles": [str(x) for x in (t.get("poles") or t.get("cl") or [])][:6]}
    m = d["mimo"]
    return {"mode": "corner", "controllable_rank": m.get("controllable_rank"), "state_dim": m.get("state_dim"), "uRef": [float(x) for x in d["uRef"]]}


def plant_model(profile: dict, recipe: dict, calibration: dict | None = None, *, seed: int = 7, synthetic_bias_dps: float = 0.5,
                start_tilt_deg: float | None = None) -> dict:
    """aeris-plant-model/1 for the synthetic device: the engine's plant for this profile plus a synthetic sensor
    (gyro bias, noise) whose imperfections the calibration flow then measures. Everything in it is a MODEL."""
    D = design(profile, recipe, calibration)
    d, W, cfg = D["design"], D["wheels"], D["config"]
    mode = recipe["mode"]
    pl = d["plant"]
    imu = profile["imu"]
    tb = np.array(profile["imu"]["to_body"], dtype=float).reshape(3, 3)
    to_sensor = tb.T.reshape(-1).tolist()
    nz = imu.get("noise") or {}
    tilt = start_tilt_deg if start_tilt_deg is not None else float((recipe.get("start") or {}).get("tilt_deg", 1.0))
    out = {"schema": schemas.PLANT_SCHEMA, "mode": mode, "g": float(cfg["params"]["g"]), "synthetic": True,
           "wheels": [{"axis": [float(x) for x in w.axis], "Jw": w.Jw, "kt": w.kt, "R": w.R, "Vs": w.Vs, "Imax": w.taumax_nominal / w.kt,
                       "wmax_rads": w.wmax, "cv": w.cv, "cc": w.cc, "mount_sign": int(pw["driver"]["sign"]), "node": int(pw["driver"]["node"])}
                      for w, pw in zip(W.wheels, profile["wheels"])],
           "imu": {"present": True, "address": int(imu["i2c_address"]), "who_am_i": 0x6C, "position_m": [float(x) for x in imu["position_m"]],
                   "to_sensor": to_sensor, "gyro_bias_radps": [synthetic_bias_dps * DEG, -0.6 * synthetic_bias_dps * DEG, 0.4 * synthetic_bias_dps * DEG],
                   "accel_bias_mps2": [0.0, 0.0, 0.0], "gyro_noise_radps": float(nz.get("gyro_dps", 0.16)) * DEG,
                   "accel_noise_mps2": float(nz.get("accel_mps2", 0.047))},
           "power": {"vbus_V": 0.5 * (profile["electrical"]["vbus_min_V"] + profile["electrical"]["vbus_max_V"]), "batt_R": 0.05},
           "seed": int(seed)}
    if mode == "edge":
        out["edge"] = {"Thh": float(pl["Thh"]), "mgl": float(pl["mgl"]), "beta": float(pl["beta"])}
        out["start"] = {"theta": -float(pl["beta"]) + tilt * DEG, "catch_deg": 20.0, "release_delay_s": 0.05}
    else:
        out["corner"] = {"Th0": [[float(x) for x in r] for r in pl["Th0"]], "Thhi": [[float(x) for x in r] for r in pl["Thhi"]],
                         "M": float(pl["M"]), "rc": [float(x) for x in pl["rc"]]}
        rc = np.array(pl["rc"], dtype=float)
        rcu = rc / np.linalg.norm(rc)
        qb = from_to(tuple(rcu), (0.0, 0.0, 1.0))
        # tilt the balance attitude by `tilt` about a horizontal body direction ⟂ rcu
        h = np.cross(rcu, [0.0, 0.0, 1.0]) if abs(rcu[2]) < 0.9 else np.cross(rcu, [1.0, 0.0, 0.0])
        h = h / np.linalg.norm(h)
        s, c = math.sin(tilt * DEG / 2), math.cos(tilt * DEG / 2)
        qt = (c, s * h[0], s * h[1], s * h[2])
        from ..physics.quaternion import qmul, qnorm
        out["start"] = {"q": [float(x) for x in qnorm(qmul(qb, qt))], "catch_deg": 20.0, "release_delay_s": 0.05}
    return out


# ------------------------------------------------------------------------------------------------ one parameter source
# value_sources groups of a profile → the engine inputs (aeris-parameter-set/1 paths) they determine. Groups without
# engine inputs (electrical: the device's abort limits) or unknown groups determine none.
GROUP_PATHS = {
    "body": lambda p: p in ("params.m", "params.a", "params.kJ", "plant.base_com_m", "plant.base_inertia_kgm2") or p.startswith("plant.components."),
    "wheels": lambda p: p.startswith("wheels.") and p.rsplit(".", 1)[1] in ("Jw", "axis", "cv", "cc"),
    "motor": lambda p: p.startswith("wheels.") and p.rsplit(".", 1)[1] in ("KV", "R", "Vs", "Imax", "wmaxRpm"),
    "imu.noise": lambda p: p in ("sensor.gyro_noise_dps", "sensor.accel_noise_mps2"),
    "imu.placement": lambda p: p in ("params.rImu", "sensor.imu_position_m"),
}


def profile_parameter_set(profile: dict, ref: dict, engine_cfg: dict | None) -> dict:
    """The parameter-set identity of a Simulate My Cube run of this profile revision (acceptance PRF-5).

    Only groups whose value_sources entry is 'measured' contribute values ('nominal-model', 'datasheet' and 'estimated'
    are not measurements), each at its parameter-set path with exactly the value the engine configuration uses, so the
    run's coverage (experiments/provenance.py) is computed by the same rule as for a stored parameter set: inputs no
    group covers (the rates, the sensor timing and quantisation, actuator lag, …) stay NOMINAL, and the run is MEASURED
    only when every input it uses is covered. Nothing here can make a model VALIDATED. engine_cfg is the NORMALISED
    configuration (validate_config(...).config); without it the identity carries no values."""
    from ..experiments.provenance import PS_REVISION, model_inputs, set_status, spec_of
    vs = profile.get("value_sources") or {}
    measured = sorted(g for g, src in vs.items() if src == "measured" and g in GROUP_PATHS)
    values = {}
    if engine_cfg is not None and measured:
        for path, val in model_inputs(engine_cfg).items():
            g = next((g for g in measured if GROUP_PATHS[g](path)), None)
            spec = spec_of(path)
            if g is None or spec is None:
                continue
            values[path] = {"value": copy.deepcopy(val), "unit": spec[0], "method": f"declared measured in the profile (value_sources.{g})",
                            "date": None, "evidence": f"aeris-device-profile/1 {ref['id']} revision {ref['revision']} (sha256 {ref['hash']})"}
    return {"id": f"profile:{ref['id']}:r{ref['revision']}", "status": set_status(values)["status"] if values else "nominal", "revision": PS_REVISION,
            "source": {"profile": dict(ref), "measured_groups": measured, "other_groups": {g: src for g, src in sorted(vs.items()) if g not in measured}},
            "applied": sorted(values), "values": values or None}


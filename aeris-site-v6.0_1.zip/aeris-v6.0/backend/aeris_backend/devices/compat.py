"""Capability negotiation (site/docs/DEVICE_LINK.md §2): what a connected device offers, and whether a profile and a
recipe fit it. Nothing is substituted: a device that does not advertise a controller, an estimator, a driver or an
action never receives it, and an unknown link or configuration format is offered read-only (telemetry, diagnostics,
stop) with the reasons stated.
"""
from __future__ import annotations

LINK = "aeris-device-link/1"
CONFIG_SCHEMA = "aeris-device-config/1"
READ_ONLY_ACTIONS = ("identify", "diagnostics", "stop")
CONTROLLER_FOR_MODE = {"edge": "edge-lqr", "corner": "corner-mimo-lqr"}


def negotiate(hello: dict | None) -> dict:
    """The support decision for one device hello (declared capabilities, not verified)."""
    if not isinstance(hello, dict):
        return {"supported": False, "mode": "unknown", "reasons": ["the device has not introduced itself"], "actions": []}
    reasons = []
    if hello.get("link") != LINK or 1 not in (hello.get("versions") or []):
        reasons.append(f"link protocol {hello.get('link')!r} versions {hello.get('versions')!r}: this backend speaks {LINK} version 1")
    caps = hello.get("caps") if isinstance(hello.get("caps"), dict) else {}
    if caps.get("config_schema") != CONFIG_SCHEMA:
        reasons.append(f"configuration format {caps.get('config_schema')!r}: this backend writes {CONFIG_SCHEMA}")
    actions = [a for a in (caps.get("actions") or []) if isinstance(a, str)]
    fw = hello.get("fw") if isinstance(hello.get("fw"), dict) else {}
    board = hello.get("board") if isinstance(hello.get("board"), dict) else {}
    out = {"supported": not reasons, "mode": "full" if not reasons else "read-only", "reasons": reasons,
           "actions": actions if not reasons else [a for a in actions if a in READ_ONLY_ACTIONS],
           "controllers": [c for c in (caps.get("controllers") or []) if isinstance(c, str)],
           "estimators": [e for e in (caps.get("estimators") or []) if isinstance(e, str)],
           "imu": caps.get("imu"), "motor": caps.get("motor"), "max_control_hz": caps.get("max_control_hz"),
           "actuation_build": bool(fw.get("actuation_build")), "firmware": fw.get("version"), "build": fw.get("build"),
           "board": board.get("id"), "device_kind": board.get("kind"), "synthetic": bool(board.get("synthetic")),
           "hard_limits": hello.get("limits") if isinstance(hello.get("limits"), dict) else {}}
    if not out["actuation_build"]:
        out["note"] = "this firmware build never drives motors (sensing, calibration and telemetry only)"
    return out


def profile_fits(hello: dict | None, profile: dict, recipe: dict | None = None) -> list:
    """Reasons why this device cannot run this profile (and recipe); empty when it can (as far as it declares)."""
    c = negotiate(hello)
    if not c["supported"]:
        return list(c["reasons"])
    why = []
    imu = (profile.get("imu") or {}).get("driver")
    if imu != c["imu"]:
        why.append(f"the profile's IMU driver {imu!r} is not the device's ({c['imu']!r})")
    for i, w in enumerate(profile.get("wheels") or []):
        kind = ((w or {}).get("driver") or {}).get("kind")
        if kind != c["motor"]:
            why.append(f"wheel {i}: driver {kind!r} is not the device's ({c['motor']!r})")
    lim = c["hard_limits"]
    for i, w in enumerate(profile.get("wheels") or []):
        mo = (w or {}).get("motor") or {}
        if isinstance(lim.get("hard_max_current_A"), (int, float)) and isinstance(mo.get("Imax_A"), (int, float)) and mo["Imax_A"] > lim["hard_max_current_A"]:
            why.append(f"wheel {i}: current limit {mo['Imax_A']} A above the firmware's hard limit {lim['hard_max_current_A']} A")
        if isinstance(lim.get("hard_max_speed_rpm"), (int, float)) and isinstance(mo.get("speed_max_rpm"), (int, float)) and mo["speed_max_rpm"] > lim["hard_max_speed_rpm"]:
            why.append(f"wheel {i}: speed limit {mo['speed_max_rpm']} rpm above the firmware's hard limit {lim['hard_max_speed_rpm']} rpm")
        kv, imax = mo.get("KV_rpm_per_V"), mo.get("Imax_A")
        if isinstance(lim.get("hard_max_torque_Nm"), (int, float)) and isinstance(kv, (int, float)) and kv > 0 and isinstance(imax, (int, float)):
            tmax = 60.0 / (2 * 3.141592653589793 * kv) * imax
            if tmax > lim["hard_max_torque_Nm"]:
                why.append(f"wheel {i}: torque limit {tmax:.3f} N·m above the firmware's hard limit {lim['hard_max_torque_Nm']} N·m")
    if recipe is not None:
        ctl = CONTROLLER_FOR_MODE.get(recipe.get("mode"))
        if ctl not in c["controllers"]:
            why.append(f"the device does not implement the {recipe.get('mode')!r} controller ({ctl}); it offers {', '.join(c['controllers']) or 'none'}")
        est = (recipe.get("estimator") or {}).get("type")
        if est not in c["estimators"]:
            why.append(f"the device does not implement the estimator {est!r}")
        hz = (recipe.get("rates") or {}).get("control_hz")
        if isinstance(c["max_control_hz"], int) and isinstance(hz, int) and hz > c["max_control_hz"]:
            why.append(f"control rate {hz} Hz above the device's {c['max_control_hz']} Hz")
    return why

"""Validation of the device documents (site/docs/DEVICES.md):

  aeris-device-profile/1     what a cube IS: body mass model, wheels (axes, inertias, motors, drivers, signs), IMU
                             (driver, address, placement, orientation, noise), board, electrical limits, value sources
  aeris-experiment-recipe/1  what an experiment ASKS for: mode, LQR weights, estimator, duration, limits, rates
  aeris-calibration/1        what was MEASURED on one device: IMU orientation (to_body), gyroscope bias, wheel checks
  aeris-kit/1                a buildable kit revision: readiness, BOM reference, downloads, guide steps

Validation never coerces: a wrong type, a non-finite number, a value outside its range or an unknown enum is an error
with its path. Unknown fields are reported as warnings and kept (documents may carry notes). Qualification and
value-source fields are DECLARATIONS: the software accepts "experimental"/"unqualified" from users and never sets or
upgrades a qualification itself.
"""
from __future__ import annotations

import math
import re

from ..physics.mass import check_tensor

PROFILE_SCHEMA = "aeris-device-profile/1"
RECIPE_SCHEMA = "aeris-experiment-recipe/1"
CALIBRATION_SCHEMA = "aeris-calibration/1"
KIT_SCHEMA = "aeris-kit/1"
DEVICE_CONFIG_SCHEMA = "aeris-device-config/1"
PLANT_SCHEMA = "aeris-plant-model/1"

ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{2,63}$")
LSM_ODR = (12, 26, 52, 104, 208, 416, 833, 1666, 3332, 6664)
VALUE_SOURCES = ("nominal-model", "datasheet", "estimated", "measured")
# what a USER may declare; "qualified" exists only for profiles published by the project with reviewed evidence
USER_QUALIFICATION = ("experimental", "unqualified")
QUALIFICATION = USER_QUALIFICATION + ("qualified",)
KIT_READINESS = ("concept", "candidate", "engineered", "manufactured", "bench-tested", "beginner-validated")
IMU_DRIVERS = ("lsm6dsox",)
MOTOR_DRIVERS = ("odrive-cansimple",)


class Issues(list):
    def err(self, path, msg):
        self.append({"path": path, "message": msg, "severity": "error"})

    def warn(self, path, msg):
        self.append({"path": path, "message": msg, "severity": "warning"})

    @property
    def errors(self):
        return [i for i in self if i["severity"] == "error"]

    def result(self):
        return {"ok": not self.errors, "errors": self.errors, "warnings": [i for i in self if i["severity"] == "warning"]}


def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _int(x):
    return isinstance(x, int) and not isinstance(x, bool)


def num(iss, d, k, path, lo, hi, required=True):
    if k not in d or d[k] is None:
        if required:
            iss.err(path, "required number")
        return None
    v = d[k]
    if not _num(v):
        iss.err(path, f"must be a finite number (got {v!r})")
        return None
    if v < lo or v > hi:
        iss.err(path, f"{v} is outside {lo}…{hi}")
        return None
    return v


def vec(iss, d, k, path, n=3, required=True, lo=-1e9, hi=1e9):
    if k not in d or d[k] is None:
        if required:
            iss.err(path, f"required list of {n} numbers")
        return None
    v = d[k]
    if not (isinstance(v, list) and len(v) == n and all(_num(x) for x in v)):
        iss.err(path, f"must be {n} finite numbers")
        return None
    if any(x < lo or x > hi for x in v):
        iss.err(path, f"values must lie in {lo}…{hi}")
        return None
    return v


def mat3(iss, d, k, path, required=True):
    if k not in d or d[k] is None:
        if required:
            iss.err(path, "required 3×3 matrix")
        return None
    v = d[k]
    if not (isinstance(v, list) and len(v) == 3 and all(isinstance(r, list) and len(r) == 3 and all(_num(x) for x in r) for r in v)):
        iss.err(path, "must be a 3×3 list of finite numbers")
        return None
    return v


def string(iss, d, k, path, maxlen=200, required=True, pattern=None):
    if k not in d or d[k] is None:
        if required:
            iss.err(path, "required string")
        return None
    v = d[k]
    if not isinstance(v, str) or not v or len(v) > maxlen:
        iss.err(path, f"must be a non-empty string of at most {maxlen} characters")
        return None
    if pattern is not None and not pattern.match(v):
        iss.err(path, "has an invalid format")
        return None
    return v


def enum(iss, d, k, path, allowed, required=True):
    if k not in d or d[k] is None:
        if required:
            iss.err(path, f"required: one of {', '.join(map(str, allowed))}")
        return None
    if d[k] not in allowed:
        iss.err(path, f"{d[k]!r} is not one of {', '.join(map(str, allowed))}")
        return None
    return d[k]


def obj(iss, d, k, path, required=True):
    if k not in d or d[k] is None:
        if required:
            iss.err(path, "required object")
        return None
    if not isinstance(d[k], dict):
        iss.err(path, "must be an object")
        return None
    return d[k]


def unknown(iss, d, allowed, path):
    for k in d:
        if k not in allowed:
            iss.warn(f"{path}.{k}" if path else k, "unknown field (kept, not used)")


def signed_permutation(m) -> bool:
    if not (isinstance(m, list) and len(m) == 9 and all(x in (-1, 0, 1) for x in m)):
        return False
    rows = [m[0:3], m[3:6], m[6:9]]
    if any(sum(1 for x in r if x != 0) != 1 for r in rows):
        return False
    if any(sum(1 for r in rows if r[c] != 0) != 1 for c in range(3)):
        return False
    det = (m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6]))
    return det == 1


def _unit(v, tol=1e-3):
    n = math.sqrt(sum(x * x for x in v))
    return abs(n - 1) <= tol


def _det3(a, b, c):
    return (a[0] * (b[1] * c[2] - b[2] * c[1]) - a[1] * (b[0] * c[2] - b[2] * c[0]) + a[2] * (b[0] * c[1] - b[1] * c[0]))


# ------------------------------------------------------------------------------------------------ profile
PROFILE_KEYS = ("schema", "id", "name", "description", "kit", "qualification", "body", "wheels", "imu", "board", "electrical",
                "value_sources", "parameter_set_id", "g_mps2", "notes")


def validate_profile(p, *, author_is_user: bool = True) -> dict:
    iss = Issues()
    if not isinstance(p, dict):
        iss.err("", "a device profile must be a JSON object")
        return iss.result()
    if p.get("schema") != PROFILE_SCHEMA:
        iss.err("schema", f"must be {PROFILE_SCHEMA!r}")
    string(iss, p, "id", "id", 64, pattern=ID_RE)
    string(iss, p, "name", "name", 120)
    if p.get("description") is not None:
        string(iss, p, "description", "description", 2000)
    kit = p.get("kit")
    if kit is not None:
        if not isinstance(kit, dict):
            iss.err("kit", "must be an object {id, revision} or null")
        else:
            string(iss, kit, "id", "kit.id", 64, pattern=ID_RE)
            string(iss, kit, "revision", "kit.revision", 32)
    q = obj(iss, p, "qualification", "qualification")
    if q is not None:
        st = enum(iss, q, "status", "qualification.status", QUALIFICATION)
        if author_is_user and st not in (None,) + USER_QUALIFICATION:
            iss.err("qualification.status", "a profile created through the API is 'experimental' or 'unqualified'; qualification needs reviewed hardware evidence and is not granted by the software")
        if q.get("evidence") is not None and not isinstance(q.get("evidence"), list):
            iss.err("qualification.evidence", "must be a list of evidence references")
    g = p.get("g_mps2", 9.81)
    if not _num(g) or not 9.7 <= g <= 9.9:
        iss.err("g_mps2", "local gravitational acceleration must lie in 9.7…9.9 m/s²")
    b = obj(iss, p, "body", "body")
    if b is not None:
        a = num(iss, b, "edge_m", "body.edge_m", 0.05, 0.5)
        num(iss, b, "mass_kg", "body.mass_kg", 0.1, 20.0)
        if b.get("inertia_kgm2") is None:
            num(iss, b, "inertia_factor", "body.inertia_factor", 0.05, 0.5)
        else:
            m = mat3(iss, b, "inertia_kgm2", "body.inertia_kgm2")
            if m is not None:
                # symmetric, positive definite, principal moments satisfying the triangle inequality (a rigid body)
                for e in check_tensor(m, "body.inertia_kgm2"):
                    iss.err("body.inertia_kgm2", e)
        com = vec(iss, b, "com_m", "body.com_m", required=False, lo=-0.5, hi=0.5)
        if com is not None and a is not None and any(not (0 <= c <= a) for c in com):
            iss.warn("body.com_m", "the base centre of mass lies outside the cube volume")
        comps = b.get("components", [])
        if not isinstance(comps, list):
            iss.err("body.components", "must be a list")
        else:
            for i, c in enumerate(comps):
                pth = f"body.components.{i}"
                if not isinstance(c, dict):
                    iss.err(pth, "must be an object")
                    continue
                string(iss, c, "id", pth + ".id", 64)
                num(iss, c, "mass_kg", pth + ".mass_kg", 0.0, 10.0)
                vec(iss, c, "com_m", pth + ".com_m", lo=-0.5, hi=0.5)
                if c.get("inertia_kgm2") is not None:
                    cm = mat3(iss, c, "inertia_kgm2", pth + ".inertia_kgm2")
                    if cm is not None:          # a component may be a point mass (zero inertia): semi-definite allowed
                        for e in check_tensor(cm, pth + ".inertia_kgm2", allow_zero=True):
                            iss.err(pth + ".inertia_kgm2", e)
        unknown(iss, b, ("edge_m", "mass_kg", "inertia_factor", "inertia_kgm2", "com_m", "components", "notes"), "body")
    ws = p.get("wheels")
    if not isinstance(ws, list) or len(ws) != 3:
        iss.err("wheels", "exactly three wheels (the supported topology)")
    else:
        nodes, axes = [], []
        for i, w in enumerate(ws):
            pth = f"wheels.{i}"
            if not isinstance(w, dict):
                iss.err(pth, "must be an object")
                continue
            string(iss, w, "id", pth + ".id", 16)
            ax = vec(iss, w, "axis", pth + ".axis")
            if ax is not None:
                if not _unit(ax):
                    iss.err(pth + ".axis", "must be a unit vector")
                axes.append(ax)
            num(iss, w, "Jw_kgm2", pth + ".Jw_kgm2", 1e-6, 0.05)
            mo = obj(iss, w, "motor", pth + ".motor")
            if mo is not None:
                num(iss, mo, "KV_rpm_per_V", pth + ".motor.KV_rpm_per_V", 10, 5000)
                num(iss, mo, "R_ohm", pth + ".motor.R_ohm", 0.01, 20)
                num(iss, mo, "Imax_A", pth + ".motor.Imax_A", 0.1, 60)
                num(iss, mo, "supply_V", pth + ".motor.supply_V", 3, 60)
                num(iss, mo, "speed_max_rpm", pth + ".motor.speed_max_rpm", 100, 30000)
            fr = obj(iss, w, "friction", pth + ".friction")
            if fr is not None:
                num(iss, fr, "cv", pth + ".friction.cv", 0, 0.01)
                num(iss, fr, "cc", pth + ".friction.cc", 0, 0.1)
            dr = obj(iss, w, "driver", pth + ".driver")
            if dr is not None:
                enum(iss, dr, "kind", pth + ".driver.kind", MOTOR_DRIVERS)
                nd = dr.get("node")
                if not _int(nd) or not 1 <= nd <= 62:
                    iss.err(pth + ".driver.node", "CANSimple node id 1…62")
                else:
                    nodes.append(nd)
                if dr.get("sign") not in (1, -1) or isinstance(dr.get("sign"), bool):
                    iss.err(pth + ".driver.sign", "+1 or -1 (the motor's positive direction relative to the axis)")
        if len(set(nodes)) != len(nodes):
            iss.err("wheels", "driver node ids must be distinct")
        if len(axes) == 3 and abs(_det3(*axes)) < 0.5:
            iss.err("wheels", "the three axes are (nearly) coplanar")
    imu = obj(iss, p, "imu", "imu")
    if imu is not None:
        enum(iss, imu, "driver", "imu.driver", IMU_DRIVERS)
        ad = imu.get("i2c_address")
        if ad not in (0x6A, 0x6B) or isinstance(ad, bool):
            iss.err("imu.i2c_address", "0x6A (106) or 0x6B (107)")
        pos = vec(iss, imu, "position_m", "imu.position_m", lo=-0.5, hi=0.5)
        if pos is not None and math.sqrt(sum(x * x for x in pos)) > 0.5:
            iss.err("imu.position_m", "further than 0.5 m from the pivot")
        if not signed_permutation(imu.get("to_body")):
            iss.err("imu.to_body", "a 3×3 signed permutation (9 numbers, row-major) with determinant +1: body = to_body · sensor")
        if imu.get("odr_hz") not in LSM_ODR:
            iss.err("imu.odr_hz", f"an LSM6DSOX output data rate: {', '.join(map(str, LSM_ODR))}")
        if imu.get("accel_range_g") not in (2, 4, 8, 16):
            iss.err("imu.accel_range_g", "2, 4, 8 or 16")
        if imu.get("gyro_range_dps") not in (125, 250, 500, 1000, 2000):
            iss.err("imu.gyro_range_dps", "125, 250, 500, 1000 or 2000")
        nz = obj(iss, imu, "noise", "imu.noise")
        if nz is not None:
            num(iss, nz, "gyro_dps", "imu.noise.gyro_dps", 0, 5)
            num(iss, nz, "accel_mps2", "imu.noise.accel_mps2", 0, 2)
    bd = obj(iss, p, "board", "board")
    if bd is not None:
        string(iss, bd, "id", "board.id", 64)
    el = obj(iss, p, "electrical", "electrical")
    if el is not None:
        lo = num(iss, el, "vbus_min_V", "electrical.vbus_min_V", 1, 60)
        hi = num(iss, el, "vbus_max_V", "electrical.vbus_max_V", 1, 60)
        if lo is not None and hi is not None and lo >= hi:
            iss.err("electrical.vbus_min_V", "must be below vbus_max_V")
        ca = num(iss, el, "current_abort_A", "electrical.current_abort_A", 0.1, 60)
        num(iss, el, "temperature_abort_C", "electrical.temperature_abort_C", 20, 120)
        if ca is not None and isinstance(ws, list):
            for i, w in enumerate(ws):
                im = ((w or {}).get("motor") or {}).get("Imax_A") if isinstance(w, dict) else None
                if _num(im) and ca < im:
                    iss.err("electrical.current_abort_A", f"below wheel {i}'s motor current limit")
    vs = p.get("value_sources")
    if vs is not None:
        if not isinstance(vs, dict):
            iss.err("value_sources", "must map value groups to a source")
        else:
            for k, v in vs.items():
                if v not in VALUE_SOURCES:
                    iss.err(f"value_sources.{k}", f"one of {', '.join(VALUE_SOURCES)}")
    unknown(iss, p, PROFILE_KEYS, "")
    return iss.result()


# ------------------------------------------------------------------------------------------------ recipe
LQR_KEYS = ("tilt_deg", "rate_dps", "wheel_rad_s", "yaw_deg", "yaw_rate_dps", "r_scale")


def validate_recipe(r) -> dict:
    iss = Issues()
    if not isinstance(r, dict):
        iss.err("", "a recipe must be a JSON object")
        return iss.result()
    if r.get("schema") != RECIPE_SCHEMA:
        iss.err("schema", f"must be {RECIPE_SCHEMA!r}")
    string(iss, r, "id", "id", 39, pattern=ID_RE)
    string(iss, r, "name", "name", 120)
    mode = enum(iss, r, "mode", "mode", ("edge", "corner"))
    num(iss, r, "duration_s", "duration_s", 1, 300)
    c = obj(iss, r, "controller", "controller")
    if c is not None:
        enum(iss, c, "type", "controller.type", ("lqr",))
        wts = c.get("weights") or {}
        if not isinstance(wts, dict):
            iss.err("controller.weights", "must be an object")
        else:
            for k, v in wts.items():
                if k not in LQR_KEYS:
                    iss.err(f"controller.weights.{k}", f"unknown weight; allowed: {', '.join(LQR_KEYS)}")
                elif not _num(v) or v <= 0:
                    iss.err(f"controller.weights.{k}", "must be a positive number")
    e = obj(iss, r, "estimator", "estimator")
    if e is not None:
        enum(iss, e, "type", "estimator.type", ("cf3d",))
        num(iss, e, "tau_s", "estimator.tau_s", 0.01, 10)
        num(iss, e, "accel_gate_mps2", "estimator.accel_gate_mps2", 0.01, 5)
        num(iss, e, "bias_gain", "estimator.bias_gain", 0, 1)
        num(iss, e, "tau_alpha_s", "estimator.tau_alpha_s", 0.001, 1)
        if e.get("stale_after_s") is not None:
            num(iss, e, "stale_after_s", "estimator.stale_after_s", 0.0005, 1)
        if not isinstance(e.get("compensate_dynamic", True), bool):
            iss.err("estimator.compensate_dynamic", "true or false")
    lim = obj(iss, r, "limits", "limits")
    if lim is not None:
        ts = num(iss, lim, "tilt_start_deg", "limits.tilt_start_deg", 0.1, 15)
        ta = num(iss, lim, "tilt_abort_deg", "limits.tilt_abort_deg", 0.5, 30)
        if ts is not None and ta is not None and ts >= ta:
            iss.err("limits.tilt_start_deg", "must be below tilt_abort_deg")
        num(iss, lim, "link_loss_max_s", "limits.link_loss_max_s", 0, 30)
        num(iss, lim, "stop_torque_Nm", "limits.stop_torque_Nm", 0, 1)
        num(iss, lim, "arm_window_s", "limits.arm_window_s", 5, 120)
        num(iss, lim, "wheel_speed_abort_factor", "limits.wheel_speed_abort_factor", 1.0, 1.5)
    rt = obj(iss, r, "rates", "rates")
    if rt is not None:
        ch = rt.get("control_hz")
        if not _int(ch) or not 100 <= ch <= 1000:
            iss.err("rates.control_hz", "integer 100…1000")
        th = rt.get("telemetry_hz")
        if not _int(th) or not 1 <= th <= 500 or (_int(ch) and ch % th):
            iss.err("rates.telemetry_hz", "integer 1…500 dividing control_hz")
    st = r.get("start")
    if st is not None:
        if not isinstance(st, dict):
            iss.err("start", "must be an object")
        else:
            num(iss, st, "tilt_deg", "start.tilt_deg", 0, 10)
    req = r.get("requires", [])
    if not isinstance(req, list) or any(x not in ("edge-trial-completed",) for x in req):
        iss.err("requires", "a list of prerequisites: 'edge-trial-completed'")
    if mode == "corner" and "edge-trial-completed" not in (req if isinstance(req, list) else []):
        iss.warn("requires", "a corner recipe normally requires a completed edge trial on the same device and profile revision")
    unknown(iss, r, ("schema", "id", "name", "description", "mode", "duration_s", "controller", "estimator", "limits", "rates", "start",
                     "requires", "notes"), "")
    return iss.result()


# ------------------------------------------------------------------------------------------------ calibration
def validate_calibration(c) -> dict:
    iss = Issues()
    if not isinstance(c, dict):
        iss.err("", "a calibration must be a JSON object")
        return iss.result()
    if c.get("schema") != CALIBRATION_SCHEMA:
        iss.err("schema", f"must be {CALIBRATION_SCHEMA!r}")
    string(iss, c, "device_id", "device_id", 64)
    pr = obj(iss, c, "profile", "profile")
    if pr is not None:
        string(iss, pr, "id", "profile.id", 64, pattern=ID_RE)
        if not _int(pr.get("revision")) or pr.get("revision") < 1:
            iss.err("profile.revision", "integer ≥ 1")
    enum(iss, c, "source", "source", ("device-measurement", "synthetic-device", "manual-entry"))
    imu = obj(iss, c, "imu", "imu")
    if imu is not None:
        if not signed_permutation(imu.get("to_body")):
            iss.err("imu.to_body", "a signed permutation with determinant +1")
        gb = vec(iss, imu, "gyro_bias_radps", "imu.gyro_bias_radps", lo=-0.2, hi=0.2)
        del gb
        if imu.get("gyro_std_radps") is not None:
            vec(iss, imu, "gyro_std_radps", "imu.gyro_std_radps", lo=0, hi=1)
        if imu.get("accel_norm_mps2") is not None:
            num(iss, imu, "accel_norm_mps2", "imu.accel_norm_mps2", 8, 12)
    wh = c.get("wheels")
    if wh is not None:
        if not isinstance(wh, list) or len(wh) != 3:
            iss.err("wheels", "three wheel check results")
        else:
            for i, w in enumerate(wh):
                if not isinstance(w, dict) or not isinstance(w.get("direction_ok"), bool):
                    iss.err(f"wheels.{i}", "{direction_ok: bool, …}")
    ev = c.get("evidence", [])
    if not isinstance(ev, list):
        iss.err("evidence", "a list of the device measurement results (command ids and hashes)")
    return iss.result()


# ------------------------------------------------------------------------------------------------ kit
def validate_kit(k) -> dict:
    iss = Issues()
    if not isinstance(k, dict):
        iss.err("", "a kit must be a JSON object")
        return iss.result()
    if k.get("schema") != KIT_SCHEMA:
        iss.err("schema", f"must be {KIT_SCHEMA!r}")
    string(iss, k, "id", "id", 64, pattern=ID_RE)
    string(iss, k, "revision", "revision", 32)
    string(iss, k, "name", "name", 120)
    enum(iss, k, "readiness", "readiness", KIT_READINESS)
    if not isinstance(k.get("steps", []), list):
        iss.err("steps", "must be a list")
    for i, s in enumerate(k.get("steps") or []):
        pth = f"steps.{i}"
        if not isinstance(s, dict):
            iss.err(pth, "must be an object")
            continue
        string(iss, s, "id", pth + ".id", 64)
        string(iss, s, "title", pth + ".title", 160)
        for f in ("expected_result", "checkpoint"):
            string(iss, s, f, f"{pth}.{f}", 2000)
        if not isinstance(s.get("troubleshooting", []), list):
            iss.err(pth + ".troubleshooting", "must be a list")
    for i, d in enumerate(k.get("downloads") or []):
        pth = f"downloads.{i}"
        if not isinstance(d, dict):
            iss.err(pth, "must be an object")
            continue
        string(iss, d, "id", pth + ".id", 64)
        st = enum(iss, d, "status", pth + ".status", ("available", "unavailable"))
        if st == "available":
            string(iss, d, "path", pth + ".path", 300)
            h = d.get("sha256")
            if not (isinstance(h, str) and re.fullmatch(r"[0-9a-f]{64}", h)):
                iss.err(pth + ".sha256", "64 lower-case hex characters for an available download")
        else:
            string(iss, d, "reason", pth + ".reason", 400)
    return iss.result()

# AERIS v4 · technical report

Research backend implemented, integration gaps A–G fixed, complete system connected and tested.
Starting point: `aeris-site-v3.zip` (sha256 `c3d2f8f21446d672edfe786491a17e186c327abb4d2b9da53420f8a703d943e1`),
extracted to a working copy; the ZIP itself is unchanged (hash re-checked at packaging).
Every simulated number in this repository uses **nominal design parameters**; nothing is a hardware
measurement and no model has been validated against the physical cube.

## 1. What was delivered

| Item | Where |
|---|---|
| Repository | this folder: `site/` (frontend), `backend/` (Python research backend), `build/` (page and schema builders) |
| Archive | `aeris-site-v4.zip` (next to `aeris-site-v3.zip`, which is untouched) |
| Backend install and run | `backend/README.md` |
| Enabling SIMULATION while keeping DEMO | `site/docs/BACKEND_INTEGRATION.md` §2, `backend/README.md`, `site/README.md` |
| Example configurations and commands | `backend/examples/` (5 configurations, 2 sweeps, parameter-set template, draft protocol, client, demo) |
| Physics, controller, estimator, schema docs | `site/docs/PHYSICS.md`, `CONTROLLERS.md`, `ESTIMATION.md`, `SCHEMA_EXTENSIONS.md` |
| Integration, platform, hardware, roadmap docs | `site/docs/BACKEND_INTEGRATION.md`, `RESEARCH_PLATFORM.md`, `HARDWARE_NEXT_STEPS.md`, `ROADMAP.md`, `site/CHANGES.md` |
| Test counts, benchmarks, checklist, limitations | §3–§7 below |

## 2. Architecture in one screen

```
site/ (static)  UI → AERIS_SERVICE → LocalSimulatorAdapter (DEMO, browser engine AERIS Twin 0.3.0)
                                   → ResearchApiAdapter    (SIMULATION, REST + WebSocket, probe: configured ≠ reachable)
                                   → HardwareTelemetryAdapter (unavailable, with its reason) · ReplayAdapter
                validation layers: structure → engine capability (browser / reported backend caps) → backend → strict records
backend/aeris_backend
  physics · actuators · sensors · estimation · control (design + laws + allocation) · simulation (RK4 + ZOH)
  metrics (legacy rules + research metrics/recovery) · experiments (records rev 1.2, sweeps rev 1.1, compare)
  jobs (process pool, cooperative cancel, restart policy) · storage (SQLite) · hardware (ingest, compare, bridge)
  api (FastAPI /api/v1, WebSocket /live/{job} with seq, CORS + origin check, CLI)
```

Key decisions:

* **Parity first.** The backend reproduces the browser engine for every configuration the browser can
  run (constants exported from `core.js`, the same RNG stream, the same laws). 25 browser-generated
  fixtures; without sensor noise 446 of 463 recorded columns are bit-identical on the test machine and
  every sample agrees within one unit of its 6th significant digit; outcomes, timelines and metrics
  (1e-9 relative) match. Noisy cases differ only through last-bit `log/cos` differences between V8
  and glibc in the Gaussian draws (identical outcomes and timelines, integral metrics within 0.1 %).
* **Extensions are additive and explicit.** `aeris-config/1` rev 1.1, `aeris-run/1` rev 1.2 and
  `aeris-sweep/1` rev 1.1 only add fields; the browser refuses what it cannot run instead of dropping
  it; the executed method is saved and shown; unsupported requests are errors.
* **Genuine MIMO.** The coupled LQR is designed on the controllable subspace of the full-tensor
  linearisation (rank 8 of 9: vertical angular momentum is conserved), `K = K_c V_cᵀ`, and is saved
  with A, B, Q, R, K, P and the operating point.
* **Nonlinear controller** (model-compensated quaternion PD with a momentum loop): the law, model
  knowledge and limits are documented; an exact-model test confirms the designed error dynamics.
* **Estimation honesty.** The MEKF observes tilt and horizontal bias; heading is unobservable from
  gravity. The records report tilt and full-attitude errors separately and the MEKF's final heading
  and tilt uncertainty (ESTIMATION.md §8 shows a 20 s run where the true heading drifts −17.4° while
  the controller holds its estimate; the legacy outcome says *recovered*, the heading-hold research
  criterion correctly fails).

## 3. Tests — exact counts (final code)

Environment: 2-vCPU Linux VM, Python 3.12.3, Node 22.22.2, Playwright + Chromium. Every suite below was
executed on the delivered code; none was skipped or left unrun.

| Suite | Passed | Failed | Skipped | Notes |
|---|---:|---:|---:|---|
| backend `test_physics.py` | 16 | 0 | 0 | quaternions, mass properties, dynamics, RK4 order vs DOP853 |
| backend `test_parity.py` | 51 | 0 | 0 | 25 browser fixtures (designs, deterministic samples, noisy cases, constants file) |
| backend `test_actuators_estimation.py` | 17 | 0 | 0 | limits, friction, lag, faults, allocation, IMU, MEKF, CF, truth isolation |
| backend `test_control_metrics.py` | 25 | 0 | 0 | LQR/MIMO designs, nonlinear PD, PID anti-windup/reset, authority, recovery, termination, CSV |
| backend `test_sweeps.py` | 12 | 0 | 0 | distributions, seed strategies, paths, limits, analysis |
| backend `test_service.py` | 14 | 0 | 0 | repository, restart policies, API, cancellation ×4 phases, WebSocket, parameter sets |
| backend `test_hardware.py` | 5 | 0 | 0 | frames, recordings, gaps, comparison, acceptance rules |
| backend `test_schemas.py` | 4 | 0 | 0 | real backend output validated against the published JSON Schemas |
| **backend total** | **144** | 0 | 0 | also 144/144 in a fresh virtual environment installed from `pyproject.toml` (newer FastAPI 0.141, Pydantic 2.13) |
| JS `numerics` | 38 | 0 | 0 | v3 suite, unchanged |
| JS `runs` | 14 | 0 | 0 | v3 suite, unchanged |
| JS `assistant` | 9 | 0 | 0 | v3 suite, unchanged |
| JS `platform` | 16 | 0 | 0 | v3 suite, unchanged |
| JS `engine` | 9 | 0 | 0 | v3 suite, unchanged |
| JS `service` | 19 | 0 | 0 | v3 suite; the availability test was strengthened (configured ≠ reachable) |
| JS `ui` | 16 | 0 | 0 | v3 suite; one expectation updated: MIMO LQR is now "research backend only" (still asserted not to run in the browser engine) |
| JS `schema` | 7 | 0 | 0 | 6 v3 tests (expected lists extended by the additive revisions: two new schemas, research event types, path variables) + 1 new (real backend records conform) |
| JS `v4` | 27 | 0 | 0 | new: validation layers, preserved fields, backend records, cancellation, connection, recovery, hardware, sampling, views |
| JS `live_backend` | 12 | 0 | 0 | new: the real `ResearchApiAdapter` against a running uvicorn backend |
| **JS total** | **167** | 0 | 0 | the 127 tests the review confirmed all still pass |
| Browser `browser_check.py` | 50 | 0 | 0 | v2 behaviour in Chromium (executed, not assumed) |
| Browser `browser_v3.py` | 47 | 0 | 0 | v3 platform in Chromium (executed) |
| Browser `browser_v4.py` | 24 | 0 | 0 | new: the site against the running backend, then DEMO without it |
| **Browser total** | **121** | 0 | 0 | |
| Demonstration client | 7 | 0 | 0 | `backend/examples/aeris_client.py demo` against a fresh server (§4) |

No assertion was removed or loosened. Three v3 test files were edited where v4 changes behaviour on
purpose: `service.test.js` (stricter: SIMULATION needs a successful probe, not only a URL — the v3
behaviour was the reported defect), `ui.test.js` (MIMO LQR moved from "planned" to "research backend
only") and `schema.test.js` (the exact expected lists now include the additive revision-1.1/1.2
content). `numerics`, `runs`, `assistant`, `platform`, `engine`, `browser_check.py` and
`browser_v3.py` are byte-identical to v3.

## 4. Required demonstrations (all on the real backend)

| Demonstration | Evidence |
|---|---|
| Real backend single run | demo step 2 (`AERIS-EXP-100000`, edge LQR, revision-1.0 configuration, nominal, 5000 steps); `live_backend` L2 (parity with the browser engine); `browser_v4` "Backend run opened" |
| Advanced controller/estimator run | demo step 3 (corner nonlinear PD + MEKF, IMU 1 kHz, RK4 2 kHz, angular impulse, temporary wheel degradation; executed `nlpd / nonlinear-full-tensor`, `mekf`, truth access false; research recovery at 0.833 s; final heading σ 10.5°, tilt σ 0.022°); L3; `browser_v4` results/Maths checks |
| Persisted result retrieval | demo step 4 (list, re-fetch identical by canonical hash, CSV export with provenance header); L4 (browser save/load/export/import keep backend metadata); `browser_v4` reload check |
| Sweep | demo step 6 (36 runs: LQR, MIMO LQR, nonlinear PD with MEKF, paired seeds, McNemar comparisons, row 0 configuration fetched); L7; `browser_v4` 147-run sweep in the UI |
| Cancellation with partial results | demo step 7 (9000-run sweep cancelled while running: finished rows kept, `partial: true`, analysis of those rows labelled PARTIAL); L8 (during) and L9 (before execution); `test_service` covers before / during / during analysis / after completion; `browser_v4` PARTIAL in the UI |
| Reproduction | demo step 5 (identical, max \|Δ\| = 0); L5; `browser_v4` "reproduces every sample exactly" |
| Frontend replay | `browser_v4`: a backend run is opened in the Lab, seeking to t = 1 s moves the 3-D view and telemetry, playback advances, the Maths panel renders and names the executed method; screenshots in `site/tests/screenshots/` |

The demonstration output (`backend/examples/demo_output/`) is the client's verbatim log of these
steps; every number in it came from the backend's responses.

## 5. Benchmarks (software speed only)

`backend/benchmarks/run_benchmarks.py`, final code, Intel Xeon @ 2.80 GHz, 2 logical CPUs, Python
3.12.3, NumPy 2.5.3, SciPy 1.18.1, Node 22.22.2; medians of 5 repeats, 10 s simulated, fixed seeds, all
runs recovered. Raw numbers: `backend/benchmarks/results/benchmarks-20260927-145416.{json,md}`.

| Case | Executed | Wall (median) | Steps/s | Real-time factor |
|---|---|---:|---:|---:|
| edge LQR (legacy) | lqr/decoupled · ideal | 194 ms | 25,791 | 51.6× |
| edge LQR + Kalman (legacy) | lqr/decoupled · kf | 202 ms | 24,811 | 49.6× |
| corner LQR (legacy) | lqr/decoupled · ideal | 533 ms | 9,376 | 18.8× |
| corner MIMO LQR | lqr/mimo-lqr · ideal | 516 ms | 9,697 | 19.4× |
| corner nonlinear PD + MEKF | nlpd · mekf | 2290 ms | 2,184 | 4.4× |
| corner custom plant, 4 wheels | lqr/mimo-lqr · ideal | 574 ms | 8,716 | 17.4× |
| corner LQR at 500 / 1000 / 2000 Hz | integration rate | 512 / 805 / 1494 ms | 9,768 / 12,416 / 13,390 | 19.5 / 12.4 / 6.7× |
| sweep, 100 runs × 5 s, 1 worker | job manager + SQLite | 24.5 s | — | 4.08 runs/s |
| sweep, 100 runs × 5 s, 2 workers | job manager + SQLite | 13.0 s | — | 7.71 runs/s |
| browser engine, edge LQR (Node) | — | 21.8 ms | 229,332 | 459× |
| browser engine, corner LQR (Node) | — | 82.1 ms | 60,923 | 122× |

Absolute times depend on the host: an earlier run of the same script on another 2-vCPU VM
(2.1 GHz, before the last engine changes; `benchmarks-20260927-070018.*`) measured 30–40 % lower wall
times for both engines.
Per integration step the backend is about 6.5–9× slower than the browser engine because its inner
loop is plain Python (NumPy is used for designs and the MEKF); it still runs faster than real time in
every case and scales with worker processes (1.9× with 2 workers).

## 6. Requirement → implementation → tests

| Requirement | Implementation | Tests |
|---|---|---|
| §1 inspect, baseline, keep the ZIP | `V4_PLAN.md` (map, baseline 127 JS + 50 + 47 browser), hash check at packaging | baseline re-run |
| §2 preserve design, DEMO, browser engine, replay, exports, labels; reuse conventions | browser engine unchanged in behaviour (only capability tags and messages); backend reuses its conventions | all v3 suites; `test_parity.py` |
| A validation layers | `js/platform/config.js`, `service.js`, `core.js` tags; backend `config/normalize.py`, `validate.py`, `POST /validate` | v4 A1–A3; L10; `browser_v4` sweep validation |
| B preserve research fields; no disguise; no substitution | preserving normaliser, sweep/controller-set/import/export paths; `executed` block; Maths panel, assistant, CSV name the executed method | v4 B1–B4, C3, V1–V2; `test_no_silent_controller_substitution`, `test_executed_method_is_persisted…`, `test_mimo_rejected_where_it_does_not_apply`, `test_csv_export_names_the_executed_method`; L6 |
| C backend metadata | `runs.js` `validateBackendRecord`, `completeRecord` | v4 C1–C2; L4 |
| D remote cancellation (before / during / analysis / after) | `jobs/manager.py`, `research-api.js` (result_ref, partial fetch, retry) | `test_cancel_before_during_after_and_during_analysis`; v4 D1–D5; L8–L9; `browser_v4` |
| E connection behaviour; no guessed limits | probe (health + capabilities), re-probe, Check backend, WebSocket with `seq` + polling fallback; guessed `LIMITS.backend` removed | v4 E1–E3; L1, L12; `test_websocket_and_polling_agree`, `test_websocket_rejects_foreign_origin`; `browser_v4` |
| F recovery criteria | `metrics/research.py` (RecoveryMonitor), `config.recovery`, UI results | v4 F1–F2; `test_research_recovery_criteria_saved_and_evaluated`, `test_yaw_objective_relinquished…`, `test_legacy_recovered_can_coexist…` |
| G strict hardware validation | `hardware-telemetry.js`, `validation.js`; `hardware/ingest.py`, `compare.py` | v4 G1–G3; `test_hardware.py`; L11 |
| §4 stack | Python 3.12, FastAPI, Pydantic v2, NumPy, SciPy, SQLite, pytest (`pyproject.toml`, lock file) | fresh-install run 144/144 |
| §5 physics | `physics/`, `simulation/engine.py` (corner Euler equation with locked-wheel inertia, hinge, lift-off, RK4 + ZOH, rates) | `test_physics.py`, `test_parity.py` |
| §6 actuators, disturbances | `actuators.py`, `simulation/disturbances.py` (limits, friction, lag, health, events with durations, impulses, bias) | 9 actuator tests; `test_lift_off_is_loss_of_support`; L3 |
| §7 sensors, estimation | `sensors.py`, `estimation/` (IMU at its own rate, latency, dropout; MEKF; CF3D; browser estimators) | 8 sensor/estimator tests; parity noise cases |
| §8 controllers, allocation | `control/design.py`, `controllers.py`, bounded-LS allocation, authority metric | `test_control_metrics.py`: LQR design ×2, MIMO ×5, nonlinear PD ×3, PID ×2, authority, no substitution, executed method; allocation tests in `test_actuators_estimation.py` |
| §9 runs, metrics, termination | `metrics/`, `experiments/records.py`, termination reasons | termination, numerical-failure, cancellation, metric-definition, recording-rate tests |
| §10 sweeps | `experiments/sweeps.py` (no clipping of normal samples; exact bounded-normal) | `test_sweeps.py` (12), L7, `browser_v4` |
| §11 persistence, jobs | `storage/sqlite.py`, `jobs/manager.py` (restart never looks complete) | repository, idempotent rows, restart resume/fail tests |
| §12 API | `api/app.py`, `main.py`; no credentials in the frontend | `test_service.py`, `live_backend.test.js` (real adapter), `browser_v4.py` |
| §13 hardware | parameter sets with evidence, protocols before data, strict ingest, comparison; supplied material checked | `test_hardware.py`, parameter-set tests; blocked items in §7 |
| §14 tests | all suites executed, counts above | — |
| §15 benchmarks, docs, delivery | `backend/benchmarks/`, docs, examples, this report, ZIP | benchmark run above |

## 7. Limitations and externally blocked work

Blocked by missing material (checked: `aeris-site-v3.zip` contains site code and generated visuals
only — no recordings, measured parameters, firmware, CAD, schematics or BOM):

* **Measured parameters** → runs stay NOMINAL; MEASURED needs a complete parameter set with evidence.
* **Hardware recordings** → no simulation ↔ hardware comparison exists; nothing is VALIDATED.
* **Firmware / telemetry protocol** → HARDWARE mode stays unavailable (bridge interface only).
* **CAD, schematics, BOM** → inertia, electrical limits and component masses are design values.
* **Acceptance thresholds** → a DRAFT protocol is provided; the project must confirm it before recording.

Software limitations:

* Heading is unobservable with gravity-only attitude correction (no magnetometer model).
* Ideal pivot contact (no slip, compliance or impacts); lift-off ends the run.
* The backend is pure Python per step (§5); single-host SQLite deployment; authentication is left to a
  reverse proxy.
* The browser engine keeps its v3 scope (DEMO): corner mode with ideal state feedback, decoupled designs.
* Mobile widths: the status strip scrolls horizontally (v3 design); from 900 px up every item fits.

## 8. Defects found and fixed during v4 (beyond gaps A–G)

* Corner-mode PID ignored `anti_windup: conditional` (a silently ignored input) and missed wheel
  events applied inside the integration loop — implemented and forwarded; tested.
* The nonlinear law was printed with the wrong sign of the gyroscopic term in two UI texts — corrected
  (the code was right; an exact-model test pins it).
* CSV headers showed the configured structure (`nlpd (decoupled)`) instead of the executed one — fixed
  in both engines' exports; tested.
* A guessed "backend" sweep limit remained in the frontend — removed; only reported limits are used.
* A cancelled backend sweep had no backend analysis (the browser recomputed a reduced one) — the
  backend now analyses the finished rows and labels the analysis PARTIAL; tested.
* Stale "planned" texts (MIMO, EKF, research backend) — updated to what is implemented.
* Long SIMULATION values pushed the VALIDATION label out of the status strip — spacing, breakpoints
  and ellipsis with full text in titles; tested in the browser.

# Changelog

All versions use nominal design parameters; no version has been validated against the physical cube.

## v6.0 — Build Your Own Cube and Connect My Cube (backend 1.2.0, aeris-research-engine 1.1.0 unchanged, firmware aeris-fw 0.1.0)

Built on the delivered v5.2 (tag `aeris-v5.2` = `c285000`, `aeris-site-v5.2.zip` verified against it, 781 files
equal) after an independent review on macOS, following `evidence/v6.0-inputs/AERIS-Claude-Implementation-Prompt.md`.
The virtual cube stays the default; the research engine, its numerical behaviour (32 sampled campaign rows re-run
identical), stored records and their schemas, `aeris-telemetry-ndjson/1`, `/api/v1` in local mode and
`LocalSimulatorAdapter` are unchanged. Everything new is tested with **synthetic** devices and labelled test doubles;
nothing has run on a physical board or cube. Report: `SOFTWARE_COMPLETION_REPORT.md`; acceptance criteria and
evidence: `ACCEPTANCE_MATRIX_V6.md`; migration: `site/docs/MIGRATION_V6.md`; before/after evidence:
`evidence/v6.0-verification/`.

### Fixed (review findings V52-1 … V52-4, reproduced on unmodified v5.2 first)

- **V52-1 — telemetry reconnect gap.** `HardwareTelemetryAdapter.live` reads the backend's retained history for every
  range it has not received after each (re)connection or stream change, holds live frames until that catch-up is in,
  and delivers each frame once and in order; frames no longer retained are reported as a `gap` event (stream, range,
  count), never skipped silently. Deterministic live test L15 (fails with v5.2's adapter).
- **V52-2 — synthetic ancestry shown as a live physical device.** One conservative classifier for the live status,
  `/capabilities`, WebSocket batches, recordings, exports and comparisons; `unknown` is its own trust class
  (`trust: "unknown"`, never live, distinct from synthetic).
- **V52-3 — a stop timer could kill the replacement backend in the live suites.** `site/tests/lib/procs.js`: each
  stop is bound to its own child, cleared on exit, idempotent and leak-free.
- **V52-4 — the legacy export audit looked one generation deep.** `dbtool export-audit` (`aeris-export-audit/2`)
  follows lineage and replay links transitively, read-only: confirmed copies with their chains, unresolved ones,
  cycles and missing intermediates.

### Added

- **Build Your Own Cube** (`#build`): kit A1 (`A1-candidate`, readiness *candidate*), the provisional BOM with every
  published fact's source and check date (`hardware/bom/`), downloads only for files that exist (with SHA-256), missing
  assets listed with the reason, guided steps with checkpoints and blocked steps, per-revision progress notes in the
  browser (never a qualification), the sizing calculation (`hardware/tools/sizing.py`), `hardware/BUILD_GUIDE.md`,
  `INTEGRATION.md`, `COMMISSIONING.md`.
- **Connect My Cube** (`#connect`): the synthetic device in the page (firmware core + models as WebAssembly), Web
  Serial, the signed-firmware installer (esptool-js; development-key manifests only after consent; images that can
  drive motors are never installed), pairing with a local press, diagnostics, calibration (gyroscope bias, IMU
  mounting from two or more faces, wheel directions by hand), approved configurations, bounded experiments that wait
  for ARM on the cube, recordings, export, Simulate My Cube and comparison (never validation evidence). Loaded only
  when opened; "Try the Virtual Cube" stays the primary action.
- **Device API `/api/v6`** (backend 1.2.0, database schema 3, additive): owners and authentication (`local` on
  loopback; `jwt` with an external identity provider via PyJWT and JWKS; a loopback-only development identity
  fixture), pairing proofs (ECDSA P-256 via `cryptography`), revocation, profiles and revisions, recipes, kits,
  calibrations from the command log, approved configurations bound by SHA-256, the control lease with epochs, bounded
  commands with their status history, per-device telemetry hubs with continuity across routes (the device resends from
  its ring), device recordings, the twin (simulate, compare), WebSocket tickets; the companion
  (`python -m aeris_backend.companion`), the browser relay and the device gateway route.
- **Firmware** (`firmware/`, `aeris-fw 0.1.0`): the portable C11 core (states, sensing, the cf3d estimator, edge LQR
  and corner MIMO LQR with backend-designed gains, allocation, protection, `aeris-device-link/1`, bounded commands,
  telemetry with resend, calibration tasks, commissioning), the ESP32-S3 board layer (ESP-IDF v6.0.3: I2C IMU, TWAI
  CAN, local controls, USB link, Wi-Fi + outbound TLS WebSocket, NVS, PSA crypto), the synthetic device's models, host
  tests, a QEMU target test, host timing, release signing (`make_release.py`; development test key, empty production
  trust list) and source hashes tying every built artifact to its sources.
- **Acceptance gaps closed before release** (found while filling the matrix): the experiment's result reports the
  control steps in which each wheel's torque was limited (`saturated_steps`); host tests inject every protection fault
  into the models (temperature, current, voltage, driver, encoder, IMU, late control steps, a failed check in READY),
  with a negative control that removes each check (13 of 13 detected); profile validation checks the inertia's
  triangle inequality; Simulate My Cube labels its run through the parameter-set coverage rule from the profile's value
  sources; the companion is tested on a real pseudo-terminal and, with the gateway, over TLS on loopback.
- **Tests and tooling**: runner suites `drift`, `firmware:host`, `firmware:qemu`; `scripts/check_drift.py`; generators
  with `--check`; JavaScript suites `connect`, `procs`, `resume`; `browser_v6.py`; backend device, telemetry
  continuity, authentication and end-to-end tests; release-validation steps `device-journey`, `drift`,
  `firmware-host`, `browser-v6`; CI jobs `drift` and `firmware`.
- Documentation: `site/docs/CONNECT.md`, `DEVICES.md`, `DEVICE_LINK.md`, `FIRMWARE_INSTALL.md`, `MIGRATION_V6.md`;
  `firmware/README.md`, `hardware/README.md`; updates to TELEMETRY, DATABASE, SCHEMA_EXTENSIONS, HARDWARE_HANDOFF,
  HARDWARE_NEXT_STEPS and the backend README.

### Not done (requires hardware or decisions outside software)

No motor, rotor, frame, harness or power system has been selected or designed; no cube has been assembled, measured or
balanced; no firmware has run on a physical board; the ESP32-S3's control-loop timing is unmeasured; there is no
production signing key, no public deployment and no identity provider. `hardware/COMMISSIONING.md` lists the
engineering work and measurements in order.

## v5.2 — focused correction pass (backend 1.1.2, aeris-research-engine 1.1.0 unchanged)

Built on the delivered v5.1 (tag `aeris-v5.1` = `f76d632`, `aeris-site-v5.1.zip` SHA-256 `c1e4138d…6c638ad4`) after
an independent review on macOS (755 passed, 1 failed, 1 skipped of 757; fresh-install release validation 14/14; 32
sampled campaign reruns within tolerance). Numerical behaviour, records, the database, schemas, the frozen frontend
design, `LocalSimulatorAdapter`'s contract and the v5.1 fixes F1–F5 are unchanged. Report: `SOFTWARE_COMPLETION_REPORT.md`;
migration: `site/docs/MIGRATION_V5_2.md`; before/after evidence: `evidence/v5.2-verification/`.

### Fixed (review findings G1–G4, reproduced on unmodified v5.1 first)

- **G1 — imported units silently changed by the NDJSON export (P1).** Every exported signal is converted to the
  stream's wire unit with the importer's own factors (time → s, angles → rad, rates → rad/s, wheel speed → rpm,
  including `omega_*` columns v5.1 left out, torque → N·m, acceleration → m/s²); wire-unit columns are copied exactly;
  conversions are recorded in the lineage. Incomplete vectors, unmapped columns, undeclared or unknown status codes,
  ambiguous wheel sets, negative time or sequence numbers, edge recordings without theta and broken segment tables
  are HTTP 422 `export_not_possible` naming the column (v5.1: HTTP 500, silent omission, or a status relabelled
  "ok"); `omit_unmapped=true` leaves out what can be left out, recorded in the export. A recording without `seq`
  states that its row index stands in. The stored original and its JSON export are unchanged. Copies exported by
  v5/v5.1 cannot be repaired: regenerate them from the original (`dbtool export-audit` lists them, read-only).
- **G2 — repeated export/replay created an invalid hello (P2).** The lineage is flat and bounded: at most 12
  deduplicated references (parents and original sources kept, middle generations dropped first and counted),
  `generation`, and `ancestry_trust` — the least trustworthy status of every ancestor, kept independently of the
  listed history. v5.1 nested lineage is still read (and flattened); a synthetic or unknown ancestor anywhere,
  including nested, can only lower trust. Every export is replayed through a scratch hub before it is returned.
- **G3 — skipped test cases could produce `full_validation: true` (P2).** `run_tests.py` counts test cases: new
  statuses `incomplete` and `passed with exclusions`, skipped cases listed by name and reason in JSON, Markdown and
  console, `complete` (every case executed) separated from `all_applicable_passed`, `all_tests_executed` and an
  unqualified `full_validation`. Exit codes 0 / 1 / 2 / 3 (passed with a declared platform exclusion) / 64. The only
  declared exclusion (`scripts/platform_exclusions.json`) is the `/proc` orphan check on macOS, accepted only while its
  portable `ps` counterpart passes. `--timeout`, `--exclusions`.
- **G4 — the browser cancellation check depended on a 300 ms race (P2).** The check now cancels from the real job's
  own progress event while 0 < done < total, with bounded waits; `site/tests/browser_v52.py` tests before start,
  during execution (rows compared with an independent recomputation), at the last run, during analysis, after
  completion and the next sweep, at full speed and with the CPU throttled 4× (three attempts each, no retries). It
  exposed three product defects, corrected minimally: the Cancel button stayed visible during the browser engine's
  analysis but did nothing (now hidden there; a late request is reported and the complete result kept); a cancel in
  the same update as the last run labelled the complete set PARTIAL; and after one cancellation the button stayed
  disabled as "Cancelling…", so the next sweep could not be cancelled.

### Added

- `backend/aeris_backend/telemetry/export.py`; `backend/tests/test_export_units.py`, `test_lineage_bounded.py`;
  `site/tests/browser_v52.py`; `scripts/platform_exclusions.json`; `site/docs/MIGRATION_V5_2.md`;
  `dbtool export-audit`; release-validation steps for G1–G4; `evidence/v5.2-verification/`,
  `evidence/v5.1-independent-review/` (the review pack as supplied).

## v5.1 — focused completion pass (backend 1.1.1, aeris-research-engine 1.1.0 unchanged)

Built on the delivered v5 (git `1023e09`, `aeris-site-v5.zip` SHA-256 `11312c94…9deb33`) after an independent
review on macOS (682 passed, 2 failed, 1 skipped of 685; fresh-install release validation 11/11; 32 sampled campaign
reruns within tolerance). Numerical behaviour, records, the database, the frozen frontend design and
`LocalSimulatorAdapter` are unchanged. Contract changes are additive. Report: `V5_1_SOFTWARE_COMPLETION_REPORT.md`
(`SOFTWARE_COMPLETION_REPORT.md` when v5.1 was delivered); migration: `site/docs/MIGRATION_V5_1.md`; before/after
evidence: `evidence/v5.1-verification/`.

### Fixed (review findings F1–F5, reproduced on unmodified v5 first)

- **F1 — synthetic provenance lost across mixed-source export and replay.** Recordings keep their source segments;
  one synthetic, test or undeclared segment or ancestor makes the recording and everything derived from it
  synthetic (trust classes `synthetic` / `declared-physical` / `unknown`, `telemetry/lineage.py`). NDJSON exports
  write one hello per segment, the protocol-valid synthetic replay identity (`file-replay`, `synthetic: true`) for
  every segment of a non-physical recording, and `lineage`. Replay copies are `derived` (never evidence); a mode
  change closes the recording; old records are classified, never rewritten.
- **F2 — telemetry froze after a backend restart.** Every backend process has a `stream_id` (status, poll answers,
  live batches); cursors and de-duplication are per stream; the Telemetry tab resets its frame state on a new
  stream and shows the new process's frames as they arrive; stale answers are ignored; v5 backends fall back to
  counter regression; a WebSocket that reports only `error` (Node) or never opens no longer stalls the stream; an
  unreachable backend is re-probed every 3 s while the tab is open.
- **F3 — the CI browser command crashed before running a test.** `scripts/run_tests.py` resolves interpreters
  before suites change directory (no symlink resolution), never replaces an explicit interpreter, catches launch
  failures, reports `passed` / `failed` / `not run` / `skipped` with a verdict and `full_validation`, and exits
  non-zero when anything selected did not run. CI uses `--only` and absolute paths. `scripts/ci_local.py` runs the
  workflow's steps locally from clean clones (not a CI service run).
- **F4 — the reproduction test demanded bit-equality across platforms.** Same-environment reruns must be
  bit-identical; the stored fixtures from another machine meet the predeclared 2e-5 rule with equal outcomes, rows,
  columns and units; negative controls prove meaningful deviations still fail.
- **F5 — the COM-preview browser check read an unfinished update.** Bounded wait until input, draft, validated
  draft, label and the 3-D view's COM vector agree; the vector is asserted; 4 mm, 5 mm, replay → setup, 0 mm.

### Fixed (found while completing v5.1)

- Exporting or replaying an uploaded recording without a `seq` column failed with HTTP 500; the row index stands in.
- The published `aeris-dataset/1` schema did not list `provenance.source: "synthetic-telemetry"`, which the backend
  wrote since v5; a backend test now validates recorder output and recording datasets against the schemas.
- The orphan-worker check ran only on Linux (`/proc`); a portable POSIX `ps` version also runs on macOS.

### Added

- `backend/tests/test_provenance.py`, `test_stream_identity.py`, `test_run_tests.py`; `site/tests/v51.test.js`;
  `site/tests/browser_v51.py` (two tabs across a real backend restart; provenance in the Telemetry tab); live test
  L14 (a real backend restart).

## v5 — software completion (backend 1.1.0, aeris-research-engine 1.1.0)

Built on an untouched copy of `aeris-site-v4.zip` (git baseline commit `06056ea`). The design, navigation, DEMO
mode, the browser engine (AERIS Twin 0.3.0), replay, exports and saved-record compatibility are preserved.
Evidence for every item: `SOFTWARE_COMPLETION_REPORT.md`. Migration notes: `site/docs/MIGRATION_V5.md`.

### Fixed (review findings A–E, reproduced first: `evidence/`)

- **A — research metrics.** RMS, IAE and ISE are time-weighted (trapezoidal) integrals at the integration step
  with units by dimension (a constant 1° for 1 s now gives RMS 1°, IAE 1.0 °·s, ISE 1.0 °²·s; v4 gave IAE 1.1 and
  ISE 0.0192). Records carry `research.metrics_version` (v5 = 2); v4 records stay version 1 and are never
  relabelled; `POST /runs/{id}/reanalyze` creates a new record with lineage; comparisons (backend and compare
  panel) name the versions and withhold a version-1 ISE. (`site/docs/METRICS.md`)
- **B — job recovery.** Result and state are saved atomically; restart recovery is decided per persisted state;
  an inconsistent job fails visibly once (`inconsistent_state`) instead of being re-dispatched forever; attempt
  limit (`AERIS_MAX_JOB_ATTEMPTS`), `POST /jobs/{id}/retry`, one backend process per database (lock), database
  schema 2 with recorded migrations, test-only fault injection. (`site/docs/JOBS_AND_RECOVERY.md`, `DATABASE.md`)
- **C — estimator timing.** Time-stamped estimator lifecycle: the controller receives the estimate predicted to
  the control time with its age and validity; stale estimates are detected (`estimator.stale_after_s`), samples
  are sequenced (duplicates and out-of-order samples counted); MEKF reset Jacobian; compensated alignment.
  (`site/docs/ESTIMATION_TIMING.md`)
- **D — recording rate.** A `record_hz` that does not divide the integration rate (backend) or loop rate
  (browser) is refused with a field error naming the nearest valid rates; the executed schedule is saved in the
  record; stored v4 records with the defect are detected and explained, and reproduced at the rate v4 executed.
  (`site/docs/RECORDING.md`)
- **E — replay race.** A pending setup preview is cancelled and guarded by view generation, so it can no longer
  overwrite a replay; the timeline exposes its cursor; assistant answers stay with their run.

### Fixed (found while completing v5)

- Worker processes of a killed or crashed backend process kept running as orphans (with the multiprocessing
  helper process), holding memory and computing work nobody would collect; each worker now exits when its
  backend process is gone (POSIX). Test: `test_process_restart.py::test_worker_processes_exit_when_the_backend_process_is_killed`.
- A site connected to an older (v4) backend could send configuration-revision-1.2 features or a declared sweep
  criterion that such a backend does not implement; the site now refuses them with a capability error per feature
  unless the backend reports revision 1.2 (`/capabilities` now reports the experiment contract, metric version and
  sweep criteria). Test: `site/tests/v5.test.js` C1.
- Telemetry stream-quality counters accumulated over every source since start-up, so replaying a recording after
  a live emulator session showed the emulator's frames, duplicates and connects as the replay's; `/telemetry/status`
  now reports `counters` for the current source (with `counters_total` since start-up) and the Telemetry tab says
  so. Test: `backend/tests/test_telemetry.py::test_api_live_stream_record_export_replay_dataset_compare`.
- The Lab's compare panel showed no research metrics; it now lists them with their definition version, flags
  mixed versions as not comparable and withholds a version-1 ISE.

### Added

- **Experiment contract** (config revision 1.2): explicit initial state (`initial.attitude_q`, `body_rate_dps`),
  a `reference` block (heading objective, commands), requested vs controller target vs plant equilibrium saved in
  `executed.reference`; unsupported combinations refused with field errors. (`site/docs/EXPERIMENT_CONTRACT.md`)
- **Telemetry path** (`aeris-telemetry-ndjson/1`, read-only): NDJSON over TCP and file replay, a standalone
  **synthetic** emulator with deterministic faults, validation (rejections by reason, duplicates, out-of-order,
  gaps, stale), bounded live subscribers with a polling fallback, recordings (`aeris-hardware-run/1`) with
  provenance, export, replay and offline comparison; a device adapter interface with JSON field mapping
  (`AERIS_TELEMETRY_ADAPTERS`). Synthetic provenance survives recording, datasets and comparisons, and a
  synthetic recording can never promote a model to validated. Loopback by default. The Lab's **Telemetry tab**;
  HARDWARE mode is selectable when a backend reports telemetry. (`site/docs/TELEMETRY.md`, `HARDWARE_HANDOFF.md`)
- **Parameter provenance** (parameter sets revision 2): configuration paths, unit/shape checks, immutable sets
  with `supersedes`, per-run coverage (MEASURED / OVERRIDDEN / NOMINAL). (`site/docs/PARAMETERS.md`)
- **Persistence**: final datasets immutable at the repository level with member hashes; dataset export bundle;
  `aeris_backend.tools.dbtool` backup / restore / verify / info. (`site/docs/DATABASE.md`)
- **Reproduction**: `POST /runs/{id}/reproduce` verdicts (identical / within tolerance / different, with the
  reasons); sweep criterion declared (sweep revision 1.2); `POST /sweeps/{id}/analyze`.
  (`site/docs/REPRODUCIBILITY.md`)
- **Engine audit** tests: mechanical energy with gravity, renormalisation monitor, off-diagonal inertia coupling,
  LQR model consistency, actuator limits, identical rows with 1 and 3 workers and after crash-and-resume.
  (`site/docs/ENGINE_AUDIT.md`)
- **Studies**: nominal campaign (8 studies, 1 668 runs, raw rows, analyses, figures, reproduction check) and a
  solver verification study (`studies/`); v5 software benchmarks (`backend/benchmarks/results/`).
- **Operations**: `scripts/install.sh`, `start.sh` (same-origin site serving with `--serve-site`, optional
  emulator), `stop.sh`, `run_tests.py` (all suites, exact counts, logs), `validate_release.py` (fresh-directory
  check of a packaged release); CI workflow `.github/workflows/ci.yml`.
- **Tests**: backend suites for the contract, estimator timing, recording, recovery, process restart,
  persistence, telemetry, engine audit, reproduction and startup; `site/tests/v5.test.js`; live telemetry checks
  in `live_backend.test.js`; `site/tests/browser_v5.py`; bounded waits in the browser suites.

### Changed

- `/capabilities`: `hardware.bridge` is the bridge name; `hardware.live` is true only for a declared physical
  source that is streaming; new `telemetry` block. `/hardware/status` returns the telemetry status (old fields
  kept).
- The reference-sheet controller benchmark on the Results page is labelled **UNVERIFIED HISTORICAL**.
- The v4 benchmark results are kept under `backend/benchmarks/results/v4-engine-1.0.0/` as history.
- Test expectations changed deliberately where behaviour changed (listed in `MIGRATION_V5.md` §8).

### Not done (see the completion report)

- No physical hardware was connected; the telemetry path has carried only synthetic data. Device-specific
  steps are listed in `site/docs/HARDWARE_HANDOFF.md`.
- Only Linux x86-64 was tested; the CI workflow was written but not executed on a CI service.

## v4 and earlier

See `site/CHANGES.md`, `V4_REPORT.md` and `V4_PLAN.md`.

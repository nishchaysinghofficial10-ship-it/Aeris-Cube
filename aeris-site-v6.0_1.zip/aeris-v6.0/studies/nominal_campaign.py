"""AERIS v5 nominal simulation campaign (studies/README.md).

    cd studies && ../backend/.venv/bin/python nominal_campaign.py [--workers 2] [--out results/nominal-v5] [--only S2-doa-edge,...]

Runs a fixed set of research sweeps through the backend's own job manager (worker processes, SQLite, the same
code path as POST /sweeps), then writes for every study:
    definition.json   the exact aeris-sweep/1 definition that was submitted (seeds, criterion, workload)
    rows.csv          every row as stored — including failed and invalid runs — with its seed and config hash
    rows.json         the same rows with the full executed configuration of each run
    analysis.json     the backend's analysis of the stored rows (declared criterion, Wilson intervals, McNemar)
    summary.md        per-controller tables computed from rows.json by this script (nothing interpolated): criterion met with
                      Wilson intervals, and the recovery breakdown (first, sustained, later exits, falls after recovery)
and campaign.json (software versions, machine, wall times, sweep ids, SHA-256 of every file).

These are NOMINAL SIMULATION results: nominal design parameters, a model that has not been validated against the
physical cube. A simulated recovery rate is not hardware reliability. Plots: plot_campaign.py. Reproduction of a
sample of rows: verify_campaign.py.
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import hashlib
import json
import math
import os
import platform
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "backend"))

from aeris_backend.experiments import sweeps as SW  # noqa: E402
from aeris_backend.jobs.manager import JobManager  # noqa: E402
from aeris_backend.storage.sqlite import SqliteRepository  # noqa: E402
from aeris_backend.version import software_versions  # noqa: E402

LABEL = "NOMINAL SIMULATION (nominal parameters, model not validated against the physical cube; not hardware reliability)"

# Every study: one aeris-sweep/1 definition. Seeds are fixed; 'paired' gives every controller the same noise at a point.
STUDIES = [
    {"id": "S1-controllers-corner", "question": "How do the five corner controllers compare on the same initial tilts and tilt directions (ideal sensing)?",
     "sweep": {"name": "S1 controller comparison (corner)", "revision": "1.2", "mode": "grid", "seed": 101, "seed_strategy": "paired", "criterion": "research",
               "base": {"mode": "corner", "recovery": {"attitude_error_deg": 0.5, "rate_dps": 2.0, "hold_s": 1.0, "max_time_s": None, "yaw_objective": "free"}},
               "controllers": ["pid", "lqr", "adp", "lqr-mimo", "nlpd"],
               "variables": [{"key": "tilt_deg", "min": 0.5, "max": 5.0, "steps": 10}, {"path": "initial.azimuth_deg", "label": "Tilt direction", "unit": "°", "min": 0, "max": 60, "steps": 3}],
               "duration_s": 6, "record_hz": 10}},
    {"id": "S2-doa-edge", "question": "Domain-of-attraction slice in the (initial tilt, initial rate) plane, edge mode, ideal sensing.",
     "sweep": {"name": "S2 DOA slice (edge)", "revision": "1.2", "mode": "grid", "seed": 202, "seed_strategy": "paired", "criterion": "research",
               "base": {"mode": "edge"}, "controllers": ["pid", "lqr", "adp"],
               "variables": [{"key": "tilt_deg", "min": -8, "max": 8, "steps": 17}, {"key": "rate_dps", "min": -60, "max": 60, "steps": 13}],
               "duration_s": 4, "record_hz": 10}},
    {"id": "S2b-doa-corner", "question": "DOA slice in corner mode: decoupled LQR, coupled MIMO LQR and the nonlinear controller (initial tilt × rate about the tilt axis).",
     "sweep": {"name": "S2b DOA slice (corner)", "revision": "1.2", "mode": "grid", "seed": 203, "seed_strategy": "paired", "criterion": "research",
               "base": {"mode": "corner", "recovery": {"attitude_error_deg": 0.5, "rate_dps": 2.0, "hold_s": 1.0, "max_time_s": None, "yaw_objective": "free"}},
               "controllers": ["lqr", "lqr-mimo", "nlpd"],
               "variables": [{"key": "tilt_deg", "min": 0.5, "max": 5.5, "steps": 11}, {"key": "rate_dps", "min": 0, "max": 20, "steps": 5}],
               "duration_s": 5, "record_hz": 10}},
    {"id": "S3-com-edge", "question": "Sensitivity to a centre-of-mass shift the controllers do not know about (edge mode).",
     "sweep": {"name": "S3 COM shift map (edge)", "revision": "1.2", "mode": "grid", "seed": 303, "seed_strategy": "paired", "criterion": "research",
               "base": {"mode": "edge", "initial": {"tilt_deg": 1}}, "controllers": ["pid", "lqr", "adp"],
               "variables": [{"key": "com_y_mm", "min": -8, "max": 8, "steps": 9}, {"key": "com_z_mm", "min": -8, "max": 8, "steps": 9}],
               "duration_s": 5, "record_hz": 10}},
    {"id": "S4a-saturation-edge", "question": "Where do the torque limits decide the outcome? Torque limit (% of nominal) × initial tilt, edge mode.",
     "sweep": {"name": "S4a saturation map (edge)", "revision": "1.2", "mode": "grid", "seed": 404, "seed_strategy": "paired", "criterion": "research",
               "base": {"mode": "edge"}, "controllers": ["pid", "lqr", "adp"],
               "variables": [{"key": "torque_pct", "min": 20, "max": 100, "steps": 9}, {"key": "tilt_deg", "min": 1, "max": 5, "steps": 5}],
               "duration_s": 5, "record_hz": 10}},
    {"id": "S4b-degradation-corner", "question": "Wheel X degradation (health factor) × initial tilt in corner mode for LQR, MIMO LQR and the nonlinear controller.",
     "sweep": {"name": "S4b wheel degradation (corner)", "revision": "1.2", "mode": "grid", "seed": 405, "seed_strategy": "paired", "criterion": "research",
               "base": {"mode": "corner", "recovery": {"attitude_error_deg": 0.5, "rate_dps": 2.0, "hold_s": 1.0, "max_time_s": None, "yaw_objective": "free"}},
               "controllers": ["lqr", "lqr-mimo", "nlpd"],
               "variables": [{"path": "actuator.wheel_health.x", "label": "Wheel X health", "unit": "–", "min": 0.2, "max": 1.0, "steps": 5}, {"key": "tilt_deg", "min": 1, "max": 4, "steps": 4}],
               "duration_s": 6, "record_hz": 10}},
    {"id": "S5-montecarlo-sensing-edge", "question": "Monte Carlo over sensor noise, gyro bias, initial tilt and a push with the Kalman filter (edge mode).",
     "sweep": {"name": "S5 Monte Carlo sensing (edge, KF)", "revision": "1.2", "mode": "montecarlo", "samples": 60, "seed": 505, "seed_strategy": "paired", "criterion": "research",
               "base": {"mode": "edge", "estimator": {"type": "kf"}}, "controllers": ["pid", "lqr", "adp"],
               "variables": [{"path": "sensor.gyro_noise_dps", "label": "Gyro noise", "unit": "°/s", "min": 0.05, "max": 0.6, "dist": "uniform"},
                             {"path": "sensor.gyro_bias_dps", "label": "Gyro bias", "unit": "°/s", "min": 0.0, "max": 1.5, "dist": "uniform"},
                             {"key": "tilt_deg", "min": 0.5, "max": 3, "dist": "uniform"},
                             {"key": "disturbance_N", "min": 0, "max": 0.6, "dist": "uniform"}],
               "duration_s": 6, "record_hz": 10}},
    {"id": "S6-advanced-mekf-corner", "question": "Advanced case: quaternion MEKF with the decoupled LQR, the coupled MIMO LQR and the nonlinear controller, Monte Carlo over gyro noise, IMU latency and the initial tilt (corner).",
     "sweep": {"name": "S6 MEKF + advanced controllers (corner)", "revision": "1.2", "mode": "montecarlo", "samples": 24, "seed": 606, "seed_strategy": "paired", "criterion": "research",
               "base": {"mode": "corner", "estimator": {"type": "mekf"}, "recovery": {"attitude_error_deg": 1.0, "rate_dps": 3.0, "hold_s": 1.0, "max_time_s": None, "yaw_objective": "free"}},
               "controllers": ["lqr", "lqr-mimo", "nlpd"],
               "variables": [{"path": "sensor.gyro_noise_dps", "label": "Gyro noise", "unit": "°/s", "min": 0.05, "max": 0.5, "dist": "uniform"},
                             {"path": "sensor.latency_ms", "label": "IMU latency", "unit": "ms", "min": 0, "max": 10, "dist": "uniform"},
                             {"key": "tilt_deg", "min": 1, "max": 4, "dist": "uniform"},
                             {"path": "initial.azimuth_deg", "label": "Tilt direction", "unit": "°", "min": 0, "max": 360, "dist": "uniform"}],
               "duration_s": 6, "record_hz": 10}},
]


def wilson(k, n, z=1.959963984540054):
    if n == 0:
        return None, None
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return max(0.0, c - h), min(1.0, c + h)


def success(row, criterion):
    return SW.success_of(criterion)(row)


def summarize(rows, criterion):
    """Per-controller counts computed from the stored rows only (failed and invalid rows are counted, never dropped)."""
    out = {}
    for r in rows:
        c = r["controller"]
        s = out.setdefault(c, {"runs": 0, "valid": 0, "invalid_or_failed": 0, "success": 0, "legacy_recovered": 0, "fell": 0,
                               "research_first_recovery": 0, "research_sustained": 0, "runs_with_exits_after_recovery": 0,
                               "exits_after_recovery_total": 0, "fell_after_recovery": 0, "rms_att": []})
        s["runs"] += 1
        if r.get("status") != "ok" or r.get("outcome") == "invalid":
            s["invalid_or_failed"] += 1
            continue
        s["valid"] += 1
        if success(r, criterion):
            s["success"] += 1
        if r.get("outcome") == "recovered":
            s["legacy_recovered"] += 1
        if r.get("outcome") == "fallen":
            s["fell"] += 1
        rr = r.get("research") or {}
        if rr.get("recovered"):                        # first recovery under the research criteria (by the deadline)
            s["research_first_recovery"] += 1
        if rr.get("sustained"):                        # recovered, no later exit, no fall afterwards
            s["research_sustained"] += 1
        if (rr.get("exits_after_recovery") or 0) > 0:
            s["runs_with_exits_after_recovery"] += 1
            s["exits_after_recovery_total"] += rr["exits_after_recovery"]
        if rr.get("fell_after_recovery"):
            s["fell_after_recovery"] += 1
        ae = rr.get("attitude_rms_deg")
        if ae is not None:
            s["rms_att"].append(ae)
    for c, s in out.items():
        lo, hi = wilson(s["success"], s["valid"])
        s["rate"] = s["success"] / s["valid"] if s["valid"] else None
        s["ci95"] = [lo, hi]
        v = sorted(s.pop("rms_att"))
        s["rms_attitude_error_deg_median"] = v[len(v) // 2] if v else None
    return out


def summary_md(study, sw, summ, criterion, wall):
    lines = [f"# {study['id']} — {sw['name']}", "", f"**{LABEL}**", "", f"Question: {study['question']}", "",
             f"Sweep {sw['id']} · {len(sw['rows'])} rows (of {sw['total']}) · status {sw['status']} · criterion `{criterion}`: {SW.CRITERIA[criterion]}",
             f"Engine {sw['engine'].get('engine')} {sw['engine'].get('engine_version')} · seed {sw['definition'].get('seed')} ({sw['definition'].get('seed_strategy')}) · wall time {wall:.1f} s", "",
             "| Controller | Runs | Valid | Invalid/failed | Criterion met | Rate | 95 % Wilson CI | Legacy 'Recovered' | Fell | Median RMS attitude error [°] |",
             "|---|---:|---:|---:|---:|---:|---|---:|---:|---:|"]
    for c, s in summ.items():
        rate = "—" if s["rate"] is None else f"{100 * s['rate']:.1f} %"
        ci = "—" if s["ci95"][0] is None else f"{100 * s['ci95'][0]:.1f}–{100 * s['ci95'][1]:.1f} %"
        med = "—" if s["rms_attitude_error_deg_median"] is None else f"{s['rms_attitude_error_deg_median']:.3f}"
        lines.append(f"| {c} | {s['runs']} | {s['valid']} | {s['invalid_or_failed']} | {s['success']} | {rate} | {ci} | {s['legacy_recovered']} | {s['fell']} | {med} |")
    lines += ["", "Recovery breakdown (research criteria of each run; valid runs): first recovery by the deadline, sustained recovery",
              "(held to the end with no later exit and no fall), runs that left the criteria again after recovering (and the",
              "number of such exits), and falls after a recovery.", "",
              "| Controller | Valid | First recovery | Sustained | Runs with later exits (exits) | Fell after recovery |",
              "|---|---:|---:|---:|---:|---:|"]
    for c, s in summ.items():
        lines.append(f"| {c} | {s['valid']} | {s['research_first_recovery']} | {s['research_sustained']} | {s['runs_with_exits_after_recovery']} ({s['exits_after_recovery_total']}) | {s['fell_after_recovery']} |")
    an = sw.get("analysis") or {}
    if an.get("paired"):
        lines += ["", "Paired comparisons (same points and seeds; exact McNemar test on discordant pairs):", "",
                  "| Pair | Pairs | Both | Only first | Only second | Neither | p |", "|---|---:|---:|---:|---:|---:|---:|"]
        for q in an["paired"]:
            p = "—" if q.get("mcnemar_exact_p") is None else f"{q['mcnemar_exact_p']:.3g}"
            lines.append(f"| {q['a']} vs {q['b']} | {q['pairs']} | {q['both']} | {q['only_a']} | {q['only_b']} | {q['neither']} | {p} |")
    lines += ["", "Rates describe these sampled points only (their ranges, base setup and nominal parameters). Overlapping intervals mean the",
              "difference may not be meaningful; no significance is claimed beyond the tests shown. Not hardware reliability."]
    return "\n".join(lines) + "\n"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 16), b""):
            h.update(b)
    return h.hexdigest()


async def run(out_dir: Path, workers: int, only):
    out_dir.mkdir(parents=True, exist_ok=True)
    db = os.path.join(tempfile.mkdtemp(prefix="aeris-campaign-"), "campaign.sqlite3")   # working database, not shipped
    repo = SqliteRepository(db)
    m = JobManager(repo, workers=workers, max_jobs=1)
    await m.start()
    manifest = {"campaign": "AERIS v5 nominal simulation campaign", "label": LABEL, "software": software_versions(),
                "machine": {"python": platform.python_version(), "platform": platform.platform(), "processor": platform.processor() or platform.machine(), "cpus": os.cpu_count()},
                "workers": workers, "started": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "studies": []}
    try:
        for st in STUDIES:
            if only and st["id"] not in only:
                continue
            v = SW.validate_def(st["sweep"])
            if not v["ok"]:
                raise SystemExit(f"{st['id']}: invalid sweep definition: {v['errors']}")
            t0 = time.time()
            job = m.submit_sweep(st["sweep"])
            while repo.get_job(job["id"])["state"] not in ("complete", "failed", "cancelled"):
                await asyncio.sleep(0.1)
            wall = time.time() - t0
            j = repo.get_job(job["id"])
            sid = j["result_ref"]["id"]
            sw = repo.get_sweep(sid)
            rows_cfg = repo.sweep_rows(sid, include_config=True)
            d = out_dir / st["id"]
            d.mkdir(exist_ok=True)
            crit = sw["definition"].get("criterion", "legacy")
            (d / "definition.json").write_text(json.dumps(dict(sw["definition"], question=st["question"]), indent=1))
            (d / "rows.json").write_text(json.dumps(rows_cfg, separators=(",", ":")))
            (d / "rows.csv").write_text(SW.to_csv(sw))
            (d / "analysis.json").write_text(json.dumps(sw["analysis"], indent=1))
            summ = summarize(sw["rows"], crit)
            (d / "summary.md").write_text(summary_md(st, sw, summ, crit, wall))
            (d / "summary.json").write_text(json.dumps({"study": st["id"], "criterion": crit, "per_controller": summ, "label": LABEL}, indent=1))
            files = {f.name: sha256(f) for f in sorted(d.iterdir()) if f.is_file() and f.suffix in (".json", ".csv", ".md")}
            entry = {"id": st["id"], "question": st["question"], "sweep_id": sid, "job_state": j["state"], "rows": len(sw["rows"]), "total": sw["total"],
                     "criterion": crit, "seed": sw["definition"].get("seed"), "seed_strategy": sw["definition"].get("seed_strategy"),
                     "wall_s": round(wall, 2), "files": files}
            manifest["studies"].append(entry)
            print(f"{st['id']}: {len(sw['rows'])}/{sw['total']} rows, {j['state']}, {wall:.1f} s", flush=True)
    finally:
        await m.stop()
        repo.close()
    manifest["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    prev = out_dir / "campaign.json"
    if only and prev.exists():                         # a partial re-run keeps the other studies' entries
        old = json.loads(prev.read_text())
        keep = [s for s in old.get("studies", []) if s["id"] not in {e["id"] for e in manifest["studies"]}]
        manifest["studies"] = sorted(keep + manifest["studies"], key=lambda s: [x["id"] for x in STUDIES].index(s["id"]))
    prev.write_text(json.dumps(manifest, indent=1))
    return manifest


def main():
    ap = argparse.ArgumentParser(description="AERIS v5 nominal simulation campaign")
    ap.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    ap.add_argument("--out", default=str(HERE / "results" / "nominal-v5"))
    ap.add_argument("--only", default="", help="comma-separated study ids")
    a = ap.parse_args()
    only = {x.strip() for x in a.only.split(",") if x.strip()}
    man = asyncio.run(run(Path(a.out), a.workers, only))
    tot = sum(s["rows"] for s in man["studies"])
    print(f"\n{len(man['studies'])} studies, {tot} rows → {a.out}")


if __name__ == "__main__":
    main()

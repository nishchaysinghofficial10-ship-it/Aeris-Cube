"""Figures for the AERIS v5 nominal campaign, drawn ONLY from the stored rows (rows.json) and summaries.

    cd studies && ../backend/.venv/bin/python plot_campaign.py [--in results/nominal-v5]

Needs matplotlib (studies/requirements-plots.txt). Writes PNG files to <in>/plots/ and plots.json (file → study,
what it shows, SHA-256). Every figure carries the label NOMINAL SIMULATION; nothing is interpolated between
sampled points: map cells are the sampled grid points, empty where no run exists.

Colours: controller identity uses the site's controller tokens (css/base.css) with a marker per controller
(● PID, ■ LQR, ▲ COM-adaptive LQR, ◆ coupled MIMO LQR, ★ nonlinear PD) because two of the hues are close for
colour-vision deficiencies; outcome maps use one blue ramp (criterion met → not met) and a hatched light grey
for runs that fell, so they read in grey-scale and print.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import math
from pathlib import Path

import matplotlib
import matplotlib.ticker

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

HERE = Path(__file__).resolve().parent
CTL = {"pid": ("PID", "#3175a4", "o"), "lqr": ("LQR", "#37a69a", "s"), "adp": ("COM-adaptive LQR", "#9c84c7", "^"),
       "lqr-mimo": ("MIMO LQR (coupled)", "#37a69a", "D"), "nlpd": ("Nonlinear PD", "#b98a3e", "*")}
MET, NOTMET, FELL = "#1f5f8b", "#9cc3de", "#ececec"
INK, INK2, GRID = "#1d1f23", "#5b6068", "#e3e5e8"
LABEL = "NOMINAL SIMULATION · nominal parameters · model not validated against the cube · not hardware reliability"

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9.5, "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
                     "axes.spines.top": False, "axes.spines.right": False, "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white"})


def wilson(k, n, z=1.959963984540054):
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return max(0.0, c - h), min(1.0, c + h)


def succ(row, crit):
    if row.get("status") != "ok" or row.get("outcome") == "invalid":
        return None
    r = row.get("research") or {}
    if crit == "legacy":
        return row["outcome"] == "recovered"
    if crit == "research_sustained":
        return bool(r.get("recovered") and r.get("sustained"))
    return bool(r.get("recovered"))


def state(row, crit):
    s = succ(row, crit)
    if s is None:
        return "invalid"
    if s:
        return "met"
    return "fell" if row["outcome"] == "fallen" else "notmet"


def footer(fig, extra=""):
    fig.text(0.01, 0.01, LABEL + (" · " + extra if extra else ""), fontsize=7.2, color=INK2, ha="left", va="bottom")


def var_label(defn, key):
    for v in defn["variables"]:
        k = v.get("key") or v.get("path")
        if k == key:
            if v.get("label"):
                return f"{v['label']} [{v.get('unit', '')}]".replace(" []", "")
            return {"tilt_deg": "Initial tilt [°]", "rate_dps": "Initial rate [°/s]", "com_y_mm": "COM shift y [mm]", "com_z_mm": "COM shift z [mm]",
                    "torque_pct": "Torque limit [% of nominal]", "disturbance_N": "Push [N]"}.get(k, k)
    return key


def outcome_maps(study, rows, defn, crit, out):
    xk = defn["variables"][0].get("key") or defn["variables"][0]["path"]
    yk = defn["variables"][1].get("key") or defn["variables"][1]["path"]
    ctls = defn["controllers"]
    xs = sorted({r["values"][xk] for r in rows})
    ys = sorted({r["values"][yk] for r in rows})
    fig, axes = plt.subplots(1, len(ctls), figsize=(3.3 * len(ctls) + 0.6, 3.6), squeeze=False, sharey=True)
    counts = {}
    for ax, c in zip(axes[0], ctls):
        cells = {(r["values"][xk], r["values"][yk]): state(r, crit) for r in rows if r["controller"] == c}
        dx = (xs[1] - xs[0]) if len(xs) > 1 else 1
        dy = (ys[1] - ys[0]) if len(ys) > 1 else 1
        n = collections.Counter(cells.values())
        counts[c] = dict(n)
        for (x, y), s in cells.items():
            face = {"met": MET, "notmet": NOTMET, "fell": FELL, "invalid": "white"}[s]
            ax.add_patch(plt.Rectangle((x - dx / 2 + dx * 0.04, y - dy / 2 + dy * 0.04), dx * 0.92, dy * 0.92, facecolor=face,
                                       edgecolor="#c9ccd1" if s == "fell" else face, hatch="////" if s == "fell" else ("xx" if s == "invalid" else None), linewidth=0.6))
        ax.set_xlim(xs[0] - dx / 2, xs[-1] + dx / 2)
        ax.set_ylim(ys[0] - dy / 2, ys[-1] + dy / 2)
        name = CTL.get(c, (c,))[0]
        ax.set_title(f"{name}\n{n.get('met', 0)} of {sum(n.values())} met the criterion", fontsize=9.5, color=INK)
        ax.set_xlabel(var_label(defn, xk))
        ax.grid(False)
    axes[0][0].set_ylabel(var_label(defn, yk))
    handles = [Patch(facecolor=MET, label="criterion met"), Patch(facecolor=NOTMET, label="not met (did not fall)"),
               Patch(facecolor=FELL, edgecolor="#c9ccd1", hatch="////", label="fell")]
    fig.legend(handles=handles, loc="upper right", ncol=3, frameon=False, fontsize=8.5, bbox_to_anchor=(0.995, 1.0))
    fig.suptitle(f"{study}: outcome at each sampled point (criterion: {crit})", x=0.01, ha="left", fontsize=10.5, color=INK, y=0.995)
    fig.tight_layout(rect=(0, 0.04, 1, 0.93))
    footer(fig, "cells = sampled grid points; nothing interpolated")
    fig.savefig(out, dpi=150)
    plt.close(fig)
    return counts


def rate_dots(study, summ, out, crit):
    items = list(summ["per_controller"].items())
    fig, ax = plt.subplots(figsize=(7.6, 0.55 * len(items) + 1.4))
    for i, (c, s) in enumerate(items):
        name, col, mk = CTL.get(c, (c, INK, "o"))
        y = len(items) - 1 - i
        lo, hi = s["ci95"]
        ax.plot([100 * lo, 100 * hi], [y, y], color=col, linewidth=2.2, solid_capstyle="round")
        ax.plot(100 * s["rate"], y, marker=mk, markersize=9 if mk != "*" else 12, color=col, markerfacecolor=col, markeredgewidth=1.6, linestyle="none")
        ax.text(101.5, y, f"{s['success']}/{s['valid']}  ({100 * s['rate']:.1f} %, CI {100 * lo:.0f}–{100 * hi:.0f} %)", va="center", fontsize=8.5, color=INK)
    ax.set_yticks(range(len(items)))
    ax.set_yticklabels([CTL.get(c, (c,))[0] for c, _ in reversed(items)])
    ax.set_xlim(0, 100)
    ax.set_xlabel(f"Runs meeting the criterion [%]\nmarker: rate · bar: 95 % Wilson interval · criterion: {crit}")
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.set_title(f"{study}: criterion met per controller", loc="left", fontsize=10.5, color=INK)
    fig.tight_layout(rect=(0, 0.06, 0.70, 1))
    footer(fig)
    fig.savefig(out, dpi=150)
    plt.close(fig)


def metric_strips(study, rows, defn, crit, out, metric, label, note=""):
    ctls = defn["controllers"]
    fig, ax = plt.subplots(figsize=(6.8, 0.6 * len(ctls) + 1.4))
    for i, c in enumerate(ctls):
        name, col, mk = CTL.get(c, (c, INK, "o"))
        vals = [((r.get("research") or {}).get(metric), succ(r, crit)) for r in rows if r["controller"] == c]
        vals = [(v, s) for v, s in vals if v is not None]
        y = len(ctls) - 1 - i
        for k, (v, s) in enumerate(vals):
            jitter = ((k * 0.6180339887) % 1 - 0.5) * 0.36
            ax.plot(v, y + jitter, marker=mk, markersize=5.5 if mk != "*" else 8, linestyle="none", color=col,
                    markerfacecolor=(col if s else "white"), markeredgewidth=1.0, alpha=0.9)
        if vals:
            med = sorted(v for v, _ in vals)[len(vals) // 2]
            ax.plot([med, med], [y - 0.3, y + 0.3], color=INK, linewidth=1.6)
    ax.set_yticks(range(len(ctls)))
    ax.set_yticklabels([CTL.get(c, (c,))[0] for c in reversed(ctls)])
    ax.set_xscale("log")
    fmt = matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}")
    ax.xaxis.set_major_formatter(fmt)
    ax.xaxis.set_minor_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}" if str(f"{v:g}")[0] in "25" else ""))
    ax.set_xlabel(label + ", log scale\nfilled: criterion met · hollow: not met · black bar: median")
    ax.grid(axis="x", color=GRID, linewidth=0.8, which="both")
    ax.set_axisbelow(True)
    ax.set_title(f"{study}: {label.split(' [')[0]} of every run", loc="left", fontsize=10.5, color=INK)
    fig.tight_layout(rect=(0, 0.07 if not note else 0.15, 1, 1))
    if note:
        fig.text(0.01, 0.05, note, fontsize=7.6, color=INK, va="bottom")
    footer(fig, "one marker per run")
    fig.savefig(out, dpi=150)
    plt.close(fig)


def sha256(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default=str(HERE / "results" / "nominal-v5"))
    a = ap.parse_args()
    base = Path(a.inp)
    pdir = base / "plots"
    pdir.mkdir(exist_ok=True)
    made = []
    for sdir in sorted(p for p in base.iterdir() if p.is_dir() and p.name.startswith("S")):
        rows = json.loads((sdir / "rows.json").read_text())
        defn = json.loads((sdir / "definition.json").read_text())
        summ = json.loads((sdir / "summary.json").read_text())
        crit = defn.get("criterion", "legacy")
        sid = sdir.name
        f = pdir / f"{sid}-rates.png"
        rate_dots(sid, summ, f, crit)
        made.append({"file": f.name, "study": sid, "shows": "criterion met per controller with 95 % Wilson intervals"})
        if defn["mode"] == "grid" and len(defn["variables"]) == 2:
            f = pdir / f"{sid}-map.png"
            outcome_maps(sid, rows, defn, crit, f)
            made.append({"file": f.name, "study": sid, "shows": "outcome at each sampled grid point, per controller"})
        if defn["mode"] == "montecarlo":
            f = pdir / f"{sid}-attitude-rms.png"
            metric_strips(sid, rows, defn, crit, f, "attitude_rms_deg", "RMS attitude error [°]")
            made.append({"file": f.name, "study": sid, "shows": "RMS attitude error of every run"})
            if any((r.get("research") or {}).get("estimator_tilt_rmse_deg") is not None for r in rows):
                f = pdir / f"{sid}-estimator-tilt-rmse.png"
                metric_strips(sid, rows, defn, crit, f, "estimator_tilt_rmse_deg", "Estimator tilt RMSE [°]")
                made.append({"file": f.name, "study": sid, "shows": "estimator tilt error (estimate vs simulated truth) of every run"})
            if defn["base"]["mode"] == "corner" and any((r.get("research") or {}).get("estimator_attitude_rmse_deg") is not None for r in rows):
                f = pdir / f"{sid}-estimator-attitude-rmse.png"
                metric_strips(sid, rows, defn, crit, f, "estimator_attitude_rmse_deg", "Estimator attitude RMSE [°]",
                              note="Full attitude includes the heading, which an accelerometer and a gyro cannot observe: it drifts,\nso this error is dominated by the heading, not the tilt (see the tilt RMSE figure).")
                made.append({"file": f.name, "study": sid, "shows": "estimator full-attitude error (includes the unobservable heading) of every run"})
    for m in made:
        m["sha256"] = sha256(pdir / m["file"])
    (pdir / "plots.json").write_text(json.dumps({"label": LABEL, "figures": made}, indent=1))
    print(f"{len(made)} figures → {pdir}")


if __name__ == "__main__":
    main()

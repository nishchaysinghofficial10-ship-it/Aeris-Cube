# S1-controllers-corner — S1 controller comparison (corner)

**NOMINAL SIMULATION (nominal parameters, model not validated against the physical cube; not hardware reliability)**

Question: How do the five corner controllers compare on the same initial tilts and tilt directions (ideal sensing)?

Sweep AERIS-SWP-100000 · 150 rows (of 150) · status complete · criterion `research`: the research recovery criteria of each run (attitude error and body rate within their thresholds for hold_s, reached by max_time_s): first recovery
Engine aeris-research-backend aeris-research-engine 1.1.0 · seed 101 (paired) · wall time 32.0 s

| Controller | Runs | Valid | Invalid/failed | Criterion met | Rate | 95 % Wilson CI | Legacy 'Recovered' | Fell | Median RMS attitude error [°] |
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| pid | 30 | 30 | 0 | 24 | 80.0 % | 62.7–90.5 % | 24 | 6 | 0.478 |
| lqr | 30 | 30 | 0 | 24 | 80.0 % | 62.7–90.5 % | 24 | 6 | 0.509 |
| adp | 30 | 30 | 0 | 24 | 80.0 % | 62.7–90.5 % | 24 | 6 | 0.544 |
| lqr-mimo | 30 | 30 | 0 | 26 | 86.7 % | 70.3–94.7 % | 26 | 4 | 0.493 |
| nlpd | 30 | 30 | 0 | 24 | 80.0 % | 62.7–90.5 % | 24 | 6 | 0.490 |

Recovery breakdown (research criteria of each run; valid runs): first recovery by the deadline, sustained recovery
(held to the end with no later exit and no fall), runs that left the criteria again after recovering (and the
number of such exits), and falls after a recovery.

| Controller | Valid | First recovery | Sustained | Runs with later exits (exits) | Fell after recovery |
|---|---:|---:|---:|---:|---:|
| pid | 30 | 24 | 24 | 0 (0) | 0 |
| lqr | 30 | 24 | 24 | 0 (0) | 0 |
| adp | 30 | 24 | 24 | 0 (0) | 0 |
| lqr-mimo | 30 | 26 | 26 | 0 (0) | 0 |
| nlpd | 30 | 24 | 24 | 0 (0) | 0 |

Paired comparisons (same points and seeds; exact McNemar test on discordant pairs):

| Pair | Pairs | Both | Only first | Only second | Neither | p |
|---|---:|---:|---:|---:|---:|---:|
| pid vs lqr | 30 | 24 | 0 | 0 | 6 | — |
| pid vs adp | 30 | 24 | 0 | 0 | 6 | — |
| pid vs lqr-mimo | 30 | 24 | 0 | 2 | 4 | 0.5 |
| pid vs nlpd | 30 | 24 | 0 | 0 | 6 | — |
| lqr vs adp | 30 | 24 | 0 | 0 | 6 | — |
| lqr vs lqr-mimo | 30 | 24 | 0 | 2 | 4 | 0.5 |
| lqr vs nlpd | 30 | 24 | 0 | 0 | 6 | — |
| adp vs lqr-mimo | 30 | 24 | 0 | 2 | 4 | 0.5 |
| adp vs nlpd | 30 | 24 | 0 | 0 | 6 | — |
| lqr-mimo vs nlpd | 30 | 24 | 2 | 0 | 4 | 0.5 |

Rates describe these sampled points only (their ranges, base setup and nominal parameters). Overlapping intervals mean the
difference may not be meaningful; no significance is claimed beyond the tests shown. Not hardware reliability.

# S4a-saturation-edge — S4a saturation map (edge)

**NOMINAL SIMULATION (nominal parameters, model not validated against the physical cube; not hardware reliability)**

Question: Where do the torque limits decide the outcome? Torque limit (% of nominal) × initial tilt, edge mode.

Sweep AERIS-SWP-100004 · 135 rows (of 135) · status complete · criterion `research`: the research recovery criteria of each run (attitude error and body rate within their thresholds for hold_s, reached by max_time_s): first recovery
Engine aeris-research-backend aeris-research-engine 1.1.0 · seed 404 (paired) · wall time 2.8 s

| Controller | Runs | Valid | Invalid/failed | Criterion met | Rate | 95 % Wilson CI | Legacy 'Recovered' | Fell | Median RMS attitude error [°] |
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| pid | 45 | 45 | 0 | 16 | 35.6 % | 23.2–50.2 % | 16 | 29 | 15.429 |
| lqr | 45 | 45 | 0 | 15 | 33.3 % | 21.4–47.9 % | 15 | 30 | 15.429 |
| adp | 45 | 45 | 0 | 15 | 33.3 % | 21.4–47.9 % | 15 | 30 | 15.429 |

Recovery breakdown (research criteria of each run; valid runs): first recovery by the deadline, sustained recovery
(held to the end with no later exit and no fall), runs that left the criteria again after recovering (and the
number of such exits), and falls after a recovery.

| Controller | Valid | First recovery | Sustained | Runs with later exits (exits) | Fell after recovery |
|---|---:|---:|---:|---:|---:|
| pid | 45 | 16 | 16 | 0 (0) | 0 |
| lqr | 45 | 15 | 15 | 0 (0) | 0 |
| adp | 45 | 15 | 15 | 0 (0) | 0 |

Paired comparisons (same points and seeds; exact McNemar test on discordant pairs):

| Pair | Pairs | Both | Only first | Only second | Neither | p |
|---|---:|---:|---:|---:|---:|---:|
| pid vs lqr | 45 | 15 | 1 | 0 | 29 | 1 |
| pid vs adp | 45 | 15 | 1 | 0 | 29 | 1 |
| lqr vs adp | 45 | 15 | 0 | 0 | 30 | — |

Rates describe these sampled points only (their ranges, base setup and nominal parameters). Overlapping intervals mean the
difference may not be meaningful; no significance is claimed beyond the tests shown. Not hardware reliability.

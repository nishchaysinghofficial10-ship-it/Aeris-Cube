# S3-com-edge — S3 COM shift map (edge)

**NOMINAL SIMULATION (nominal parameters, model not validated against the physical cube; not hardware reliability)**

Question: Sensitivity to a centre-of-mass shift the controllers do not know about (edge mode).

Sweep AERIS-SWP-100003 · 243 rows (of 243) · status complete · criterion `research`: the research recovery criteria of each run (attitude error and body rate within their thresholds for hold_s, reached by max_time_s): first recovery
Engine aeris-research-backend aeris-research-engine 1.1.0 · seed 303 (paired) · wall time 9.1 s

| Controller | Runs | Valid | Invalid/failed | Criterion met | Rate | 95 % Wilson CI | Legacy 'Recovered' | Fell | Median RMS attitude error [°] |
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| pid | 81 | 81 | 0 | 9 | 11.1 % | 6.0–19.8 % | 9 | 42 | 6.495 |
| lqr | 81 | 81 | 0 | 61 | 75.3 % | 64.9–83.4 % | 61 | 20 | 0.580 |
| adp | 81 | 81 | 0 | 61 | 75.3 % | 64.9–83.4 % | 61 | 20 | 0.607 |

Recovery breakdown (research criteria of each run; valid runs): first recovery by the deadline, sustained recovery
(held to the end with no later exit and no fall), runs that left the criteria again after recovering (and the
number of such exits), and falls after a recovery.

| Controller | Valid | First recovery | Sustained | Runs with later exits (exits) | Fell after recovery |
|---|---:|---:|---:|---:|---:|
| pid | 81 | 9 | 9 | 0 (0) | 0 |
| lqr | 81 | 61 | 61 | 0 (0) | 0 |
| adp | 81 | 61 | 61 | 0 (0) | 0 |

Paired comparisons (same points and seeds; exact McNemar test on discordant pairs):

| Pair | Pairs | Both | Only first | Only second | Neither | p |
|---|---:|---:|---:|---:|---:|---:|
| pid vs lqr | 81 | 9 | 0 | 52 | 20 | 4.44e-16 |
| pid vs adp | 81 | 9 | 0 | 52 | 20 | 4.44e-16 |
| lqr vs adp | 81 | 61 | 0 | 0 | 20 | — |

Rates describe these sampled points only (their ranges, base setup and nominal parameters). Overlapping intervals mean the
difference may not be meaningful; no significance is claimed beyond the tests shown. Not hardware reliability.

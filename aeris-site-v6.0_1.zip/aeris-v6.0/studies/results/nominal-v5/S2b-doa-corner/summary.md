# S2b-doa-corner — S2b DOA slice (corner)

**NOMINAL SIMULATION (nominal parameters, model not validated against the physical cube; not hardware reliability)**

Question: DOA slice in corner mode: decoupled LQR, coupled MIMO LQR and the nonlinear controller (initial tilt × rate about the tilt axis).

Sweep AERIS-SWP-100002 · 165 rows (of 165) · status complete · criterion `research`: the research recovery criteria of each run (attitude error and body rate within their thresholds for hold_s, reached by max_time_s): first recovery
Engine aeris-research-backend aeris-research-engine 1.1.0 · seed 203 (paired) · wall time 22.1 s

| Controller | Runs | Valid | Invalid/failed | Criterion met | Rate | 95 % Wilson CI | Legacy 'Recovered' | Fell | Median RMS attitude error [°] |
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| lqr | 55 | 55 | 0 | 26 | 47.3 % | 34.7–60.2 % | 26 | 29 | 9.039 |
| lqr-mimo | 55 | 55 | 0 | 29 | 52.7 % | 39.8–65.3 % | 29 | 26 | 1.155 |
| nlpd | 55 | 55 | 0 | 28 | 50.9 % | 38.1–63.6 % | 28 | 27 | 1.324 |

Recovery breakdown (research criteria of each run; valid runs): first recovery by the deadline, sustained recovery
(held to the end with no later exit and no fall), runs that left the criteria again after recovering (and the
number of such exits), and falls after a recovery.

| Controller | Valid | First recovery | Sustained | Runs with later exits (exits) | Fell after recovery |
|---|---:|---:|---:|---:|---:|
| lqr | 55 | 26 | 26 | 0 (0) | 0 |
| lqr-mimo | 55 | 29 | 29 | 0 (0) | 0 |
| nlpd | 55 | 28 | 28 | 0 (0) | 0 |

Paired comparisons (same points and seeds; exact McNemar test on discordant pairs):

| Pair | Pairs | Both | Only first | Only second | Neither | p |
|---|---:|---:|---:|---:|---:|---:|
| lqr vs lqr-mimo | 55 | 26 | 0 | 3 | 26 | 0.25 |
| lqr vs nlpd | 55 | 26 | 0 | 2 | 27 | 0.5 |
| lqr-mimo vs nlpd | 55 | 28 | 1 | 0 | 26 | 1 |

Rates describe these sampled points only (their ranges, base setup and nominal parameters). Overlapping intervals mean the
difference may not be meaningful; no significance is claimed beyond the tests shown. Not hardware reliability.

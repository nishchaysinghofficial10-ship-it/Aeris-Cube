# S2-doa-edge — S2 DOA slice (edge)

**NOMINAL SIMULATION (nominal parameters, model not validated against the physical cube; not hardware reliability)**

Question: Domain-of-attraction slice in the (initial tilt, initial rate) plane, edge mode, ideal sensing.

Sweep AERIS-SWP-100001 · 663 rows (of 663) · status complete · criterion `research`: the research recovery criteria of each run (attitude error and body rate within their thresholds for hold_s, reached by max_time_s): first recovery
Engine aeris-research-backend aeris-research-engine 1.1.0 · seed 202 (paired) · wall time 13.3 s

| Controller | Runs | Valid | Invalid/failed | Criterion met | Rate | 95 % Wilson CI | Legacy 'Recovered' | Fell | Median RMS attitude error [°] |
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| pid | 221 | 221 | 0 | 87 | 39.4 % | 33.2–45.9 % | 87 | 134 | 16.895 |
| lqr | 221 | 221 | 0 | 87 | 39.4 % | 33.2–45.9 % | 87 | 134 | 16.895 |
| adp | 221 | 221 | 0 | 87 | 39.4 % | 33.2–45.9 % | 87 | 134 | 16.895 |

Recovery breakdown (research criteria of each run; valid runs): first recovery by the deadline, sustained recovery
(held to the end with no later exit and no fall), runs that left the criteria again after recovering (and the
number of such exits), and falls after a recovery.

| Controller | Valid | First recovery | Sustained | Runs with later exits (exits) | Fell after recovery |
|---|---:|---:|---:|---:|---:|
| pid | 221 | 87 | 87 | 0 (0) | 0 |
| lqr | 221 | 87 | 87 | 0 (0) | 0 |
| adp | 221 | 87 | 87 | 0 (0) | 0 |

Paired comparisons (same points and seeds; exact McNemar test on discordant pairs):

| Pair | Pairs | Both | Only first | Only second | Neither | p |
|---|---:|---:|---:|---:|---:|---:|
| pid vs lqr | 221 | 87 | 0 | 0 | 134 | — |
| pid vs adp | 221 | 87 | 0 | 0 | 134 | — |
| lqr vs adp | 221 | 87 | 0 | 0 | 134 | — |

Rates describe these sampled points only (their ranges, base setup and nominal parameters). Overlapping intervals mean the
difference may not be meaningful; no significance is claimed beyond the tests shown. Not hardware reliability.

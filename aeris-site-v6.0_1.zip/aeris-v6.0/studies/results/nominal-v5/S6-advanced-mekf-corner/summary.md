# S6-advanced-mekf-corner — S6 MEKF + advanced controllers (corner)

**NOMINAL SIMULATION (nominal parameters, model not validated against the physical cube; not hardware reliability)**

Question: Advanced case: quaternion MEKF with the decoupled LQR, the coupled MIMO LQR and the nonlinear controller, Monte Carlo over gyro noise, IMU latency and the initial tilt (corner).

Sweep AERIS-SWP-100007 · 72 rows (of 72) · status complete · criterion `research`: the research recovery criteria of each run (attitude error and body rate within their thresholds for hold_s, reached by max_time_s): first recovery
Engine aeris-research-backend aeris-research-engine 1.1.0 · seed 606 (paired) · wall time 89.2 s

| Controller | Runs | Valid | Invalid/failed | Criterion met | Rate | 95 % Wilson CI | Legacy 'Recovered' | Fell | Median RMS attitude error [°] |
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| lqr | 24 | 24 | 0 | 24 | 100.0 % | 86.2–100.0 % | 24 | 0 | 0.361 |
| lqr-mimo | 24 | 24 | 0 | 24 | 100.0 % | 86.2–100.0 % | 24 | 0 | 0.358 |
| nlpd | 24 | 24 | 0 | 24 | 100.0 % | 86.2–100.0 % | 24 | 0 | 0.363 |

Recovery breakdown (research criteria of each run; valid runs): first recovery by the deadline, sustained recovery
(held to the end with no later exit and no fall), runs that left the criteria again after recovering (and the
number of such exits), and falls after a recovery.

| Controller | Valid | First recovery | Sustained | Runs with later exits (exits) | Fell after recovery |
|---|---:|---:|---:|---:|---:|
| lqr | 24 | 24 | 24 | 0 (0) | 0 |
| lqr-mimo | 24 | 24 | 24 | 0 (0) | 0 |
| nlpd | 24 | 24 | 24 | 0 (0) | 0 |

Paired comparisons (same points and seeds; exact McNemar test on discordant pairs):

| Pair | Pairs | Both | Only first | Only second | Neither | p |
|---|---:|---:|---:|---:|---:|---:|
| lqr vs lqr-mimo | 24 | 24 | 0 | 0 | 0 | — |
| lqr vs nlpd | 24 | 24 | 0 | 0 | 0 | — |
| lqr-mimo vs nlpd | 24 | 24 | 0 | 0 | 0 | — |

Rates describe these sampled points only (their ranges, base setup and nominal parameters). Overlapping intervals mean the
difference may not be meaningful; no significance is claimed beyond the tests shown. Not hardware reliability.

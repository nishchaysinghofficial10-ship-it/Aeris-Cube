# S4b-degradation-corner — S4b wheel degradation (corner)

**NOMINAL SIMULATION (nominal parameters, model not validated against the physical cube; not hardware reliability)**

Question: Wheel X degradation (health factor) × initial tilt in corner mode for LQR, MIMO LQR and the nonlinear controller.

Sweep AERIS-SWP-100005 · 60 rows (of 60) · status complete · criterion `research`: the research recovery criteria of each run (attitude error and body rate within their thresholds for hold_s, reached by max_time_s): first recovery
Engine aeris-research-backend aeris-research-engine 1.1.0 · seed 405 (paired) · wall time 11.9 s

| Controller | Runs | Valid | Invalid/failed | Criterion met | Rate | 95 % Wilson CI | Legacy 'Recovered' | Fell | Median RMS attitude error [°] |
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| lqr | 20 | 20 | 0 | 10 | 50.0 % | 29.9–70.1 % | 10 | 10 | 9.749 |
| lqr-mimo | 20 | 20 | 0 | 10 | 50.0 % | 29.9–70.1 % | 10 | 10 | 8.173 |
| nlpd | 20 | 20 | 0 | 14 | 70.0 % | 48.1–85.5 % | 14 | 6 | 0.533 |

Recovery breakdown (research criteria of each run; valid runs): first recovery by the deadline, sustained recovery
(held to the end with no later exit and no fall), runs that left the criteria again after recovering (and the
number of such exits), and falls after a recovery.

| Controller | Valid | First recovery | Sustained | Runs with later exits (exits) | Fell after recovery |
|---|---:|---:|---:|---:|---:|
| lqr | 20 | 10 | 10 | 0 (0) | 0 |
| lqr-mimo | 20 | 10 | 10 | 0 (0) | 0 |
| nlpd | 20 | 14 | 14 | 0 (0) | 0 |

Paired comparisons (same points and seeds; exact McNemar test on discordant pairs):

| Pair | Pairs | Both | Only first | Only second | Neither | p |
|---|---:|---:|---:|---:|---:|---:|
| lqr vs lqr-mimo | 20 | 10 | 0 | 0 | 10 | — |
| lqr vs nlpd | 20 | 10 | 0 | 4 | 6 | 0.125 |
| lqr-mimo vs nlpd | 20 | 10 | 0 | 4 | 6 | 0.125 |

Rates describe these sampled points only (their ranges, base setup and nominal parameters). Overlapping intervals mean the
difference may not be meaningful; no significance is claimed beyond the tests shown. Not hardware reliability.

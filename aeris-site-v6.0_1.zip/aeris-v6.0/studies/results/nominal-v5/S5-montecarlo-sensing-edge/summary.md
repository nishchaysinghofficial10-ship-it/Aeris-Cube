# S5-montecarlo-sensing-edge — S5 Monte Carlo sensing (edge, KF)

**NOMINAL SIMULATION (nominal parameters, model not validated against the physical cube; not hardware reliability)**

Question: Monte Carlo over sensor noise, gyro bias, initial tilt and a push with the Kalman filter (edge mode).

Sweep AERIS-SWP-100006 · 180 rows (of 180) · status complete · criterion `research`: the research recovery criteria of each run (attitude error and body rate within their thresholds for hold_s, reached by max_time_s): first recovery
Engine aeris-research-backend aeris-research-engine 1.1.0 · seed 505 (paired) · wall time 14.0 s

| Controller | Runs | Valid | Invalid/failed | Criterion met | Rate | 95 % Wilson CI | Legacy 'Recovered' | Fell | Median RMS attitude error [°] |
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| pid | 60 | 60 | 0 | 34 | 56.7 % | 44.1–68.4 % | 34 | 26 | 1.049 |
| lqr | 60 | 60 | 0 | 60 | 100.0 % | 94.0–100.0 % | 60 | 0 | 0.387 |
| adp | 60 | 60 | 0 | 60 | 100.0 % | 94.0–100.0 % | 60 | 0 | 0.401 |

Recovery breakdown (research criteria of each run; valid runs): first recovery by the deadline, sustained recovery
(held to the end with no later exit and no fall), runs that left the criteria again after recovering (and the
number of such exits), and falls after a recovery.

| Controller | Valid | First recovery | Sustained | Runs with later exits (exits) | Fell after recovery |
|---|---:|---:|---:|---:|---:|
| pid | 60 | 34 | 34 | 0 (0) | 0 |
| lqr | 60 | 60 | 60 | 0 (0) | 0 |
| adp | 60 | 60 | 60 | 0 (0) | 0 |

Paired comparisons (same points and seeds; exact McNemar test on discordant pairs):

| Pair | Pairs | Both | Only first | Only second | Neither | p |
|---|---:|---:|---:|---:|---:|---:|
| pid vs lqr | 60 | 34 | 0 | 26 | 0 | 2.98e-08 |
| pid vs adp | 60 | 34 | 0 | 26 | 0 | 2.98e-08 |
| lqr vs adp | 60 | 60 | 0 | 0 | 0 | — |

Rates describe these sampled points only (their ranges, base setup and nominal parameters). Overlapping intervals mean the
difference may not be meaningful; no significance is claimed beyond the tests shown. Not hardware reliability.

# AERIS studies (v5)

Four kinds of evidence are kept apart here and everywhere they are cited:

| Kind | What it shows | Where |
|---|---|---|
| **Solver verification** | the model's equations are integrated correctly (RK4 order ≈ 4 against an independent DOP853 solution; conservation of momentum) | `solver_verification.py` → `results/solver-verification/`; also `backend/tests/test_physics.py`, `test_engine_audit.py` |
| **Software benchmarks** | how fast the software runs on one machine | `backend/benchmarks/run_benchmarks.py` → `backend/benchmarks/results/` |
| **Nominal research results** | what the MODEL does with NOMINAL parameters in a stated set of experiments | `nominal_campaign.py` → `results/nominal-v5/` |
| **Hardware validation** | whether the model describes the physical cube | **not done** — needs measured parameters and real recordings ([HARDWARE_HANDOFF.md](../site/docs/HARDWARE_HANDOFF.md)) |

A simulated recovery rate is not hardware reliability. None of the results below is a claim about the physical
cube, and none is a global stability or robustness claim: every number describes the sampled points of one study.

The controller benchmark printed on the earlier project reference sheet (settling 6.21 / 3.02 / 1.85 s, shown on
the site's Results page) has no traces and was not produced by this software: it is kept as **unverified
historical material** and is not used here.

## Reproduce

```bash
cd studies
../backend/.venv/bin/python nominal_campaign.py --workers 2          # 2–4 min on 2 CPUs (machine-dependent): 8 studies, 1 668 runs
../backend/.venv/bin/python verify_campaign.py                       # re-runs a fixed sample of rows one by one
../backend/.venv/bin/pip install -r requirements-plots.txt           # matplotlib, only for the figures
../backend/.venv/bin/python plot_campaign.py                         # figures from the stored rows
../backend/.venv/bin/python solver_verification.py
```

The campaign uses the backend's own job manager (worker processes and SQLite, the same path as `POST /sweeps`),
fixed seeds (`paired`: every controller sees the same noise at a point) and the declared success criterion of
each sweep (`research`: attitude error ≤ threshold and body rate ≤ threshold held for `hold_s`). Failed and
invalid runs stay in the rows and are counted and reported separately; rates and tests use the valid runs (no run in this campaign was invalid or failed). `--only S2-doa-edge,…` re-runs selected studies.

## Studies (`results/nominal-v5/`)

| Id | Question | Mode · controllers · design | Runs |
|---|---|---|---:|
| S1-controllers-corner | the five corner controllers on the same initial tilts and tilt directions | corner, ideal sensing · PID, LQR, COM-adaptive LQR, coupled MIMO LQR, nonlinear PD · grid tilt 0.5–5° (10) × direction 0–60° (3) | 150 |
| S2-doa-edge | domain-of-attraction slice (initial tilt × initial rate) | edge · PID, LQR, COM-adaptive LQR · grid tilt −8…8° (17) × rate −60…60 °/s (13) | 663 |
| S2b-doa-corner | DOA slice in corner mode | corner · LQR, MIMO LQR, nonlinear PD · tilt 0.5–5.5° (11) × rate 0–20 °/s (5) | 165 |
| S3-com-edge | a centre-of-mass shift the controllers do not know | edge, tilt 1° · PID, LQR, COM-adaptive LQR · COM y × z −8…8 mm (9 × 9) | 243 |
| S4a-saturation-edge | where the torque limit decides | edge · PID, LQR, COM-adaptive LQR · torque limit 20–100 % (9) × tilt 1–5° (5) | 135 |
| S4b-degradation-corner | wheel X degradation | corner · LQR, MIMO LQR, nonlinear PD · wheel X health 0.2–1 (5) × tilt 1–4° (4) | 60 |
| S5-montecarlo-sensing-edge | sensor noise, gyro bias, tilt and a push with the Kalman filter | edge, KF · PID, LQR, COM-adaptive LQR · Monte Carlo, 60 samples | 180 |
| S6-advanced-mekf-corner | advanced estimator/controller case | corner, quaternion MEKF · LQR, MIMO LQR, nonlinear PD · Monte Carlo over gyro noise, IMU latency 0–10 ms, tilt, direction; 24 samples | 72 |

Each study directory holds `definition.json` (the exact submitted sweep, seeds and criterion), `rows.csv` and
`rows.json` (every stored row with its seed, configuration hash and, in JSON, the full executed configuration),
`analysis.json` (the backend's analysis: Wilson intervals, exact McNemar tests on paired points, maps),
`summary.md`/`summary.json` (per-controller tables from the rows: criterion met with Wilson intervals, and the recovery
breakdown — first recovery, sustained recovery, later exits, falls after recovery). `campaign.json` lists software versions, the
machine, wall times, sweep ids and SHA-256 hashes of every file; `plots/plots.json` the figures and their
hashes; `verification.json` the reproduction check; `rerun-comparison.json` three complete re-runs of the campaign
(on a later machine session) compared file by file with the original run: definitions, rows (JSON and CSV) and
analyses **identical** (SHA-256) for all 8 studies; the figures regenerated from the rows are byte-identical too.

## Observations (nominal model, these sampled points only)

Read these with the tables and figures; overlapping intervals mean a difference may not be meaningful.

* **S2 (edge DOA).** The recoverable set is a diagonal band: an initial rate *towards* the upright extends the
  tilt that can be recovered. On this grid PID, LQR and COM-adaptive LQR recover exactly the same 87 of 221
  points. At every failing point all three are torque-limited from the first control step until the fall
  (402/402 fallen rows flagged `saturated`, identical metrics), so the boundary here is set by the actuator
  limit, not by the control law; inside the band they differ (settling time, RMS error).
* **S4a (torque limit).** Recovery from 3° needs ≥ 80 % of the nominal torque limit with PID and ≥ 90 % with
  LQR/COM-adaptive LQR on this grid; 1° is recovered down to 30 %.
* **S3 (unknown COM shift, edge).** LQR and COM-adaptive LQR meet the criterion at 61/81 points, PID at 9/81
  (exact McNemar p ≈ 4e-16 on 52 discordant pairs). PID's failing runs end with large wheel speeds (median peak
  3 640 rpm, against 756 rpm in the LQR's successful runs; 30 are still drifting at the end of the window, 22
  reach the speed limit): holding the geometric upright with a shifted COM needs a steady torque, which spins the
  wheel up. The LQR also feeds back the wheel speed.
* **S1 / S2b / S4b (corner).** The corner DOA is small with nominal parameters: at zero initial rate LQR and the
  nonlinear PD recover up to 4.0° and the MIMO LQR up to 4.5°; at 20 °/s only up to 1.0–1.5° (S2b). The coupled
  MIMO LQR and the nonlinear PD recover a few points the
  decoupled LQR does not (e.g. S2b: 29 and 28 vs 26 of 55; McNemar p = 0.25 and 0.5 — not significant with
  this sample). With wheel X degraded (S4b) the nonlinear PD met the criterion at 14/20 points vs 10/20 for
  both LQRs (p = 0.125).
* **S5 (KF, Monte Carlo).** LQR and COM-adaptive LQR 60/60, PID 34/60 on the same samples (p ≈ 3e-8).
* **S6 (MEKF).** All three controllers met the criterion in all 24 samples (95 % interval 86–100 % each). The
  estimator tilt RMSE is 0.08–0.16° (median 0.11°); the full-attitude RMSE (1.3–6.5°) is dominated by the
  heading, which gravity and gyro cannot observe.
* **Recovery breakdown (all studies).** In every study, each run that recovered (first recovery under the
  research criteria) stayed within the criteria to the end of its window: first recovery = sustained recovery, no
  later exits and no falls after recovery (the second table of each `summary.md`). This describes these runs with
  their thresholds, disturbances and windows only.

## Tolerances

On the platform that produced the rows, re-running a row gives identical numbers (`verify_campaign.py`: 32 of 32
sampled rows identical), and three complete re-runs of the campaign in a later session reproduced every rows,
analysis and definition file byte for byte (`rerun-comparison.json`). Across platforms or Python/NumPy builds, metrics may differ in the last digits; the
documented tolerance is a relative 2e-5 (1e-9 absolute), and a run whose outcome flips is a boundary case to be
reported, not hidden ([REPRODUCIBILITY.md](../site/docs/REPRODUCIBILITY.md)).

"""SOLVER VERIFICATION (separate from the nominal research results): convergence of the engine's fixed-step RK4
against an independent high-accuracy solution (SciPy DOP853, rtol 1e-12) of the documented corner equations,
and the drift of conserved quantities (torque-free momentum, lossless mechanical energy) versus the step.

    cd studies && ../backend/.venv/bin/python solver_verification.py [--out results/solver-verification]

Writes solver_verification.json and .md, and a log-log figure when matplotlib is available. This verifies the
numerical integration of the MODEL; it says nothing about how well the model describes the physical cube.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "backend"))

from aeris_backend.config.validate import validate_config  # noqa: E402
from aeris_backend.physics import quaternion as Q  # noqa: E402
from aeris_backend.physics.mass import mass_properties  # noqa: E402
from aeris_backend.simulation.engine import Engine  # noqa: E402
from aeris_backend.simulation.setup import initial_state  # noqa: E402
from aeris_backend.version import software_versions  # noqa: E402

RPM = math.pi / 30
BASE = {"mode": "corner", "controller": {"type": "none"}, "params": {"cv": 0, "cc": 0},
        "initial": {"tilt_deg": 2, "rate_dps": 10, "azimuth_deg": 20, "wheel_speeds_rpm": [800, -300, 200]},
        "duration_s": 0.25, "record_hz": 20, "termination": {"check_lift_off": False}}
RATES = [500, 1000, 2000, 4000, 8000]


def engine(raw, g=None):
    v = validate_config(raw, {"minDuration_s": 0.005})
    assert v.ok, v.errors
    cfg = v.config
    if g is not None:
        cfg["params"]["g"] = g
    return Engine(cfg, mass_properties(cfg), precise=True)


def reference_rhs(eng):
    """Independent implementation of the corner equations (docs/PHYSICS.md §3) in NumPy."""
    Th0, Thh = np.array(eng.design["plant"]["Th0"]), np.array(eng.design["plant"]["Thh"])
    M, rc, g = eng.design["plant"]["M"], np.array(eng.design["plant"]["rc"]), eng.cfg["params"]["g"]
    A = np.array([w.axis for w in eng.wheels.wheels]).T
    J = np.array([w.Jw for w in eng.wheels.wheels])

    def f(t, x):
        q, w, Om = x[:4] / np.linalg.norm(x[:4]), x[4:7], x[7:]
        R = np.array(Q.rot(tuple(q)))
        gB = R.T @ np.array([0, 0, -g])
        H = Th0 @ w + A @ (J * Om)
        wd = np.linalg.solve(Thh, -np.cross(w, H) + M * np.cross(rc, gB))
        Omd = -A.T @ wd
        return np.concatenate([0.5 * np.array(Q.qmul(tuple(q), (0, *w))), wd, Omd])
    return f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(HERE / "results" / "solver-verification"))
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    ref = None
    for hz in RATES:
        eng = engine(dict(BASE, solver={"integration_hz": hz}))
        S = eng.run()["samples"]["cols"]
        if ref is None:
            ini = initial_state(eng.cfg, eng.mp)
            x0 = np.concatenate([ini["q"], ini["w"], np.array([800, -300, 200]) * RPM])
            sol = solve_ivp(reference_rhs(eng), (0, BASE["duration_s"]), x0, method="DOP853", rtol=1e-12, atol=1e-14)
            ref = sol.y[:, -1]
            ref_q = ref[:4] / np.linalg.norm(ref[:4])
        qe = np.array([S[f"q{j}"][-1] for j in range(4)])
        we = np.array([S["wx"][-1], S["wy"][-1], S["wz"][-1]])
        rows.append({"integration_hz": hz, "dt_s": 1 / hz, "quaternion_error": float(np.linalg.norm(qe - ref_q)), "body_rate_error_rad_s": float(np.linalg.norm(we - ref[4:7]))})
    for i in range(1, len(rows)):
        a_, b_ = rows[i - 1], rows[i]
        b_["observed_order_q"] = math.log2(a_["quaternion_error"] / b_["quaternion_error"]) if b_["quaternion_error"] > 0 else None
    # conserved quantities (g = 0, no losses): momentum; with gravity: mechanical energy
    cons = []
    for hz in (500, 2000):
        free = dict(BASE, duration_s=0.5, record_hz=500, solver={"integration_hz": hz}, initial={"tilt_deg": 3, "rate_dps": 20, "azimuth_deg": 30, "wheel_speeds_rpm": [3000, -1500, 800]})
        eng = engine(free, g=0.0)
        S = eng.run()["samples"]["cols"]
        Th0 = np.array(eng.design["plant"]["Th0"])
        A = np.array([w.axis for w in eng.wheels.wheels]).T
        J = np.array([w.Jw for w in eng.wheels.wheels])

        def Hw(i):
            R = np.array(Q.rot((S["q0"][i], S["q1"][i], S["q2"][i], S["q3"][i])))
            w = np.array([S["wx"][i], S["wy"][i], S["wz"][i]])
            Om = np.array([S["omega_x"][i], S["omega_y"][i], S["omega_z"][i]])
            return R @ (Th0 @ w + A @ (J * Om))
        H0 = Hw(0)
        dH = max(float(np.linalg.norm(Hw(i) - H0) / np.linalg.norm(H0)) for i in range(len(S["t"])))
        cons.append({"case": "torque-free, g = 0: world angular momentum", "integration_hz": hz, "max_relative_drift": dH})
    report = {"what": "numerical verification of the model's integration (not a validation of the model against the cube)", "software": software_versions(),
              "convergence": {"setup": BASE, "reference": "SciPy solve_ivp DOP853, rtol 1e-12, atol 1e-14, independent NumPy implementation of the equations",
                              "rows": rows}, "conservation": cons,
              "tests": "backend/tests/test_physics.py (order 3.6–4.4, momentum/energy ≤ 1e-9) and backend/tests/test_engine_audit.py (energy with gravity, coupling, LQR model consistency)"}
    (out / "solver_verification.json").write_text(json.dumps(report, indent=1))
    md = ["# Solver verification (model integration, not hardware validation)", "", f"Engine {report['software'].get('engine')}", "",
          "| Integration rate [Hz] | Δt [ms] | ‖q − q_ref‖ at t = 0.25 s | ‖ω − ω_ref‖ [rad/s] | observed order |", "|---:|---:|---:|---:|---:|"]
    for r in rows:
        o = r.get("observed_order_q")
        md.append(f"| {r['integration_hz']} | {1000 * r['dt_s']:.3g} | {r['quaternion_error']:.3e} | {r['body_rate_error_rad_s']:.3e} | {'—' if o is None else f'{o:.2f}'} |")
    md += ["", "RK4 is fourth order: halving the step divides the error by about 16 (order ≈ 4) until round-off (~1e-13) is reached.", "",
           "| Conserved quantity | Rate [Hz] | Largest relative drift over 0.5 s |", "|---|---:|---:|"]
    md += [f"| {c['case']} | {c['integration_hz']} | {c['max_relative_drift']:.2e} |" for c in cons]
    (out / "solver_verification.md").write_text("\n".join(md) + "\n")
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6, 4))
        dts = [r["dt_s"] * 1000 for r in rows]
        ax.loglog(dts, [r["quaternion_error"] for r in rows], marker="o", color="#3175a4", label="engine RK4 vs DOP853 reference")
        c = rows[0]["quaternion_error"] / dts[0] ** 4
        ax.loglog(dts, [c * d ** 4 for d in dts], linestyle="--", color="#8a93a0", label="slope 4 (reference line)")
        ax.set_xlabel("Integration step Δt [ms]")
        ax.set_ylabel("Quaternion error at t = 0.25 s")
        ax.set_title("Solver verification: RK4 convergence (model integration only)", loc="left", fontsize=10)
        ax.legend(frameon=False, fontsize=8.5)
        ax.grid(True, which="both", color="#e3e5e8", linewidth=0.6)
        fig.tight_layout()
        fig.savefig(out / "rk4_convergence.png", dpi=150)
    except ImportError:
        pass
    print((out / "solver_verification.md").read_text())


if __name__ == "__main__":
    main()

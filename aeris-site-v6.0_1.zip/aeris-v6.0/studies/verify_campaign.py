"""Re-run a fixed sample of campaign rows one by one (outside the job manager) from the executed configuration
stored with each row, and compare with the stored row (docs/REPRODUCIBILITY.md).

    cd studies && ../backend/.venv/bin/python verify_campaign.py [--in results/nominal-v5] [--per-study 4] [--out FILE]

Tolerances: on the platform and software versions that produced the rows the results must be IDENTICAL
(outcome, research recovery, every metric). On another platform or Python/NumPy build, metrics may differ in the
last digits; the documented cross-platform tolerance is a relative difference of 2e-5 (1e-9 absolute near zero),
and a run whose outcome differs is reported as a boundary case, not hidden. Writes <in>/verification.json, or --out
(v5.1: so a later check does not overwrite the stored verification of the campaign's own release).
"""
from __future__ import annotations

import argparse
import json
import math
import random
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "backend"))

from aeris_backend.experiments.sweeps import MEASURES, row_of  # noqa: E402
from aeris_backend.simulation import simulate  # noqa: E402
from aeris_backend.version import software_versions  # noqa: E402

TOL_REL, TOL_ABS = 2e-5, 1e-9


def rel(a, b):
    if a is None or b is None:
        return 0.0 if a is b else math.inf
    if a == b:
        return 0.0
    return abs(a - b) / max(abs(a), abs(b), TOL_ABS / TOL_REL)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default=str(HERE / "results" / "nominal-v5"))
    ap.add_argument("--per-study", type=int, default=4)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--out", default=None, help="where to write the result (default: <in>/verification.json)")
    a = ap.parse_args()
    base = Path(a.inp)
    rng = random.Random(a.seed)
    report = {"software": software_versions(), "tolerance": {"same_platform": "identical", "cross_platform_rel": TOL_REL, "abs": TOL_ABS}, "rows": []}
    for sdir in sorted(p for p in base.iterdir() if p.is_dir() and p.name.startswith("S")):
        rows = json.loads((sdir / "rows.json").read_text())
        for r in rng.sample(rows, min(a.per_study, len(rows))):
            spec = {k: r[k] for k in ("index", "point", "controller", "mass_config", "estimator", "values", "seed")}
            spec["config"] = r["config"]
            res = simulate(r["config"])
            again = row_of(spec, res)
            diffs = {k: rel((r.get("metrics") or {}).get(k), (again.get("metrics") or {}).get(k)) for k in MEASURES}
            rd = {k: rel((r.get("research") or {}).get(k), (again.get("research") or {}).get(k)) for k in ("attitude_rms_deg", "attitude_iae_deg_s", "attitude_final_deg")}
            same_outcome = r["outcome"] == again["outcome"] and bool((r.get("research") or {}).get("recovered")) == bool((again.get("research") or {}).get("recovered"))
            worst = max(list(diffs.values()) + list(rd.values()) + [0.0])
            identical = same_outcome and worst == 0.0 and r["config_hash"] == again["config_hash"]
            report["rows"].append({"study": sdir.name, "index": r["index"], "controller": r["controller"], "values": r["values"], "outcome": r["outcome"],
                                   "same_outcome": same_outcome, "same_config_hash": r["config_hash"] == again["config_hash"], "max_rel_diff": worst,
                                   "identical": identical, "within_tolerance": same_outcome and worst <= TOL_REL})
    n = len(report["rows"])
    report["summary"] = {"rows_checked": n, "identical": sum(x["identical"] for x in report["rows"]),
                         "within_tolerance": sum(x["within_tolerance"] for x in report["rows"]),
                         "outcome_changed": sum(not x["same_outcome"] for x in report["rows"])}
    (Path(a.out) if a.out else base / "verification.json").write_text(json.dumps(report, indent=1))
    s = report["summary"]
    print(f"{s['rows_checked']} rows re-run: {s['identical']} identical, {s['within_tolerance']} within tolerance, {s['outcome_changed']} outcome changes")
    return 0 if s["within_tolerance"] == n else 1


if __name__ == "__main__":
    sys.exit(main())

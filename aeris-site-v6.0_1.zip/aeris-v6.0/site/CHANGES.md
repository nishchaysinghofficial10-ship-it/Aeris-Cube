# AERIS v4: research backend and integration fixes

v4 adds the Python research backend (`../backend/`) behind SIMULATION mode and fixes the frontend
integration gaps found in the v3 review. It was built on an untouched copy of `aeris-site-v3.zip`
(the ZIP itself is unchanged). The design, DEMO mode and the browser engine (AERIS Twin 0.3.0),
replay, exports, labels and saved-record compatibility are preserved; every v3 test still passes
(three test files were updated where v4 changes behaviour on purpose; `V4_REPORT.md` §3).

## Research backend (new)

- **Engine** (`aeris-research-engine 1.0.0`): the browser's conventions and physics reproduced and
  parity-tested on 25 browser-generated cases; integration rate independent of the loop rate;
  explicit plant (base inertia tensor, rigid components), up to six wheels on arbitrary axes;
  per-wheel electrical limits (per control period or per step), degradation, torque and speed limits
  with durations, faults that clear; angular and linear impulses as momentum jumps, torque bias;
  lift-off detection; termination reasons separate from the outcome.
- **Sensing and estimation**: three-axis IMU at its own rate with dynamic acceleration at the IMU
  position, bias walk, quantisation, latency (time-stamped) and dropout; quaternion MEKF and 3-D
  complementary filter; the browser's edge estimators; the perfect-state baseline is labelled.
- **Control**: PID with integral limit, conditional anti-windup and reset on events; decoupled LQR
  with the design saved (A, B, Q, R, K, P, operating point, Riccati residual, poles); coupled MIMO LQR
  on the full-tensor linearisation (controllable subspace); COM-adaptive LQR; nonlinear
  model-compensated quaternion PD with a momentum loop; clip or bounded least-squares allocation with
  requested-vs-applied authority metrics. The method that ran is saved in `executed`; unsupported
  requests are errors, never substitutions.
- **Research metrics** at every integration step and **research recovery criteria** (attitude error,
  body rate, hold time, deadline, yaw objective), reported next to the unchanged legacy outcome.
- **Sweeps** (`aeris-sweep/1` rev 1.1): path variables; uniform, untruncated normal (out-of-range
  samples are invalid rows), exact bounded-normal, categorical; paired / legacy / fixed / independent
  seeds; estimators × controllers; McNemar paired comparisons; per-row configurations.
- **Service**: SQLite storage, process-pool jobs, cancellation before, during, during analysis and
  after completion (partial sweeps keep their rows and an analysis labelled PARTIAL), restart policy
  (`resume` / `fail`), reproduction with an identity report, datasets (exploratory → final),
  measured parameter sets with evidence, validation protocols, hardware recording ingest and
  comparison, a telemetry bridge interface (no device link exists). FastAPI REST + WebSocket (`seq`
  numbers), CORS and origin checks, CLI options.

## Frontend integration fixes

- **A · Validation layers**: structure → engine capability (DEMO: the browser engine's limits;
  SIMULATION: only what the backend reported) → the backend's authoritative validation → strict
  record checks. The browser engine refuses research features with the reason instead of dropping them.
- **B · Research fields preserved** through forms, controller sets, sweeps, save/load, import/export,
  submission and reproduction; default-only blocks are not research features; the executed method is
  shown (a nonlinear controller is never shown as LQR, three scalar loops are never called MIMO).
- **C · Backend metadata**: backend records keep their own derived values, design, definitions and
  research results; incomplete ones are rejected; the browser never rebuilds them with its model.
- **D · Remote sweep cancellation**: before, during, during analysis and after completion; partial
  results fetched and labelled PARTIAL; failed cancel requests reported and retried.
- **E · Connection behaviour**: configured ≠ reachable (health and capability probe, re-probe,
  **Check backend**); WebSocket updates with sequence numbers and polling fallback; no guessed limits.
- **F · Recovery criteria** saved with each experiment and shown next to the legacy outcome; yaw
  objective changes after a wheel failure are recorded.
- **G · Hardware data**: strict frame and recording validation; synthetic data is never evidence;
  acceptance only against thresholds registered before the data.
- Also: custom wheel sets replay with their own wheels; the Maths panel and assistant name the
  executed method; CSV headers name the executed controller and estimator; stale "planned" texts
  updated to what is implemented.

## Documentation, tests, benchmarks

- New docs: `PHYSICS.md`, `CONTROLLERS.md`, `ESTIMATION.md`, `SCHEMA_EXTENSIONS.md`,
  `HARDWARE_NEXT_STEPS.md`; `BACKEND_INTEGRATION.md` rewritten for the implemented contract;
  `RESEARCH_PLATFORM.md`, `ROADMAP.md` and the READMEs updated; `backend/README.md` and
  `backend/examples/`.
- New tests: backend pytest suites (physics, parity, actuators and estimation, control and metrics,
  sweeps, service, hardware, schemas); `tests/v4.test.js`; `tests/live_backend.test.js` (the real
  adapter against a running backend); `tests/browser_v4.py` (the site against the running backend).
- Software benchmarks (`backend/benchmarks/`), labelled as software speed only.

## Limitations

- Nominal parameters only: no measured parameters, hardware recordings, firmware, CAD, schematics or
  BOM were supplied, so HARDWARE mode and hardware validation remain blocked (`docs/HARDWARE_NEXT_STEPS.md`).
- Heading is unobservable with gravity-only attitude correction (`docs/ESTIMATION.md` §8).
- The browser engine keeps its v3 scope (DEMO mode); research features run on the backend only.

# AERIS v3: research-platform frontend

v3 turns the v2 site into the frontend foundation of a research-grade attitude-control platform. It was built as a refactor of the v2 working copy (v2 package kept unchanged): the black/lime identity, the three.js cube, the workspace, controllers, saved runs, JSON/CSV export, maths panels, compare, the simulator and all v2 tests are preserved.

## What changed

**Identity and pages.** AERIS (Autonomous Experimental Reaction-wheel Inertial Stabilization) with AERIS Cube (hardware), AERIS Twin (physics-based digital model) and AERIS Lab (research environment); STABLIX only as the umbrella; ARC removed. New pages: Cube, Research, Results, Validation. The home page tells the RWIP → Cube → Twin → Lab story with the author's four lines and shows the project's evolution. The former "Lab" physics page is now AERIS Twin; the "Use the Cube" workspace is now AERIS Lab. Old links redirect.

**Colour semantics.** One token set (`js/platform/tokens.js`, mirrored in `css/base.css`): lime for brand and active UI only; stable / warning / failure for status with icons and labels; cyan / blue / violet for physical / model / research; neutral, equally weighted controller colours with marker shapes (validated for colour-vision deficiency with markers as the second channel). Small and medium radii, no pills.

**Claims.** Labels SIMULATION / HARDWARE / REPLAY, SIMULATED / MEASURED / NOMINAL / VALIDATED / HARDWARE DATA PENDING / SIM ↔ HARDWARE VALIDATION PENDING, and DEMO MODE / MOCK DATA / EXAMPLE / PARTIAL on every result; a system status strip (AERIS SYSTEM · SOURCE · MODEL · CONTROLLER · EXPERIMENT · VALIDATION) on every page but home.

**Architecture.** UI → `AERIS_SERVICE` → adapters (LocalSimulator, ResearchApi, HardwareTelemetry, Replay). System modes DEMO / SIMULATION / HARDWARE with honest availability (no backend configured, telemetry not implemented). Job state machine. Experiment IDs `AERIS-EXP-######` (legacy ARC ids migrated). Formats `aeris-config/1`, `aeris-run/1` rev 1.1 (additive), `aeris-sweep/1`, `aeris-dataset/1`, `aeris-hardware-run/1`, `aeris-job/1`, `aeris-telemetry-frame/1`, with JSON Schemas and migration of v2 records. Type declarations in `types/aeris.d.ts`.

**AERIS Twin 0.3.0.** Sensor model (edge), motor torque lag, wheel health, COM shift, new metrics (RMS error, control effort, time at the speed limit, lean margin), an event timeline at every integration step. With default inputs the engine is bit-identical to 0.2.0 (13 stored cases). MIMO structure recognised and rejected with an explanation.

**AERIS Lab.** Mode selector; Single experiment ↔ Research sweep; event timeline synchronised with the 3-D view, plots, telemetry and scrubber; amber saturation gauges ("WHEEL X … RPM / … RPM · SATURATION RISK" → "SATURATED") and saturation marks on plots; true-vs-estimated tilt and the adapted β̂ against its true target; mass-asymmetry panel (Δr_COM, part contributions, inertia tensors about the COM and the pivot); nominal-COM ghost and magnified Δr arrow in 3-D; wheel rings neutral → amber → red; sensor and actuator settings in BASIC / ADVANCED / EXPERT tiers; controller cards (measures / assumes / adapts); "Run PID · LQR · Adaptive" on one setup with computed per-metric labels and no overall winner; plot legends, hover values and per-plot CSV.

**Research sweeps.** Grid, random or Monte Carlo over COM x/y/z, initial tilt and rate, torque and speed limits, pushes, sensor noise and inertia mismatch; controllers and mass configurations; the same points for every controller; real progress through the job states; cancel with partial results; outcome maps, recovery probability with Wilson intervals, histograms and observed limits, computed only from the runs; exports as sweep JSON, CSV and `aeris-dataset/1`. Loaded on demand.

**Validation.** A comparison tool for real hardware recordings (RMSE, mean and peak error, peak difference, time offset); the page says "Hardware dataset pending" until such data exists.

**Docs.** `docs/BACKEND_INTEGRATION.md`, `docs/RESEARCH_PLATFORM.md`, `docs/ROADMAP.md`.

## Fixes found on the way

- Exports and saved records no longer carry view caches (fields starting with "_", such as cumulative wheel angles).
- The controller chip class no longer collides with the Twin page's slider styles.
- Histograms use whole-number count axes.

## Verification

See the final report for exact counts. All v2 suites pass unchanged in substance (numerics 38, runs 14, assistant 9, browser 50; the browser test was only updated for renamed routes and ids). New suites: platform, engine, service, UI data, schemas, and `tests/browser_v3.py`.

## Limitations

- Every simulated number uses nominal parameters; the model is not validated against the cube.
- No research backend exists yet; SIMULATION mode is unavailable unless one is configured (or the labelled MOCK backend is switched on).
- HARDWARE mode is not implemented; only offline recordings can be compared.
- Corner mode uses ideal state feedback and decoupled per-axis designs; no EKF, no MIMO, no nonlinear controllers in the browser engine.
- Browser sweeps are limited to 400 runs and 10 s windows.
- Failed hardware iterations and RWIP status are not documented on the site yet (shown as such).

---

# v2 (previous release): changes, verification and remaining work

v2 was built from the supplied `aeris-cube-site.zip`, which is unchanged. The look is carried over: the STABLIX/AERIS branding, the black, white and lime design, the Exo 2, Inter and JetBrains Mono fonts, the pill buttons, the detailed 3-D cube, the assembly video, the Lab mathematics and the experiments.

### 1. Defects reproduced first, then fixed

I ran the original code before changing anything (`repro/` in the working copy, not shipped).

| Case | Original behaviour | v2 |
|---|---|---|
| PID, tilt 0, rate 0, COM +3 mm, full torque, ideal sensing, no push, no failure, 4 s | The header said **Recovered** while the log said **DRIFTING**. The settling time was reported as **4.000 s**, the final timestamp. At the end the wheel was at 4135 rpm and still speeding up. | One outcome everywhere: **Drifting**. The reason given is "wheel X still rising at 1013 rpm/s … reaches its 5000 rpm limit at about t = 4.9 s". Settling time: **not settled**. |
| a = 0.08 m, m = 0.3 kg, k_J = 0.1, J_w = 0.005 kg·m² | Effective inertias were negative (Θ̂ = −3.8×10⁻³ kg·m²), yet a controller was still designed and the simulation "ran". | **Invalid configuration**, rejected before any design or integration. Two plain-language reasons are given: J_w must stay below m·a²/12, and J_c must be at least 2·J_w. No recording is created. |
| Clear log | The table was cleared, but the replay, plots and selection stayed on screen. | **Delete all** (and deleting the open run) resets the replay, 3-D view, plots, telemetry, playback, outcome and maths together. |

### 2. What changed

**One outcome calculation** (`ARC.assess`, used by the workspace, the Lab and the home page):

- COM lean e = 0 means the centre of mass is directly above the pivot.
- Settling band: ±0.25°, held for at least 0.5 s. The settling time is the start of the final in-band stretch and is never the final timestamp.
- Momentum band: ±50 rpm.
- Fall thresholds: 30° (edge) or 20° (corner), or floor contact.
- Drift: a linear fit over the final window with R² ≥ 0.9, a slope that is not decaying, and a slope of at least 0.5 % Ω_max/s or 0.05 °/s.
- Priority order: Invalid configuration → Fallen → Drifting → Recovered → Not settled within the observation window.
- Notes flag wheel momentum left in the wheel, a failed wheel, and yaw drift.
- The definitions are saved inside every run.

**Validation before design or integration:**

- Ranges, and non-numeric input.
- Physical combinations:
  - J_w < m·a²/12 and J_c ≥ 2·J_w;
  - positive effective inertias;
  - edge mode: centre of mass within the edge and off the hinge;
  - a balance attitude that does not touch the floor.
- Initial attitude through the floor.
- Loop rate too slow for the dynamics.
- Controller design failure.
- Non-finite states during integration.
- Warnings for loads or failures after the run ends, a wheel that edge mode does not use, large forces, a centre of mass near the end of the edge, and an initial state already past the fall threshold.

**Reproducible runs:**

- Schema `aeris-run/1`. Each run stores the full configuration, parameters with units, geometry, mode, masses, mass properties and inertia, initial conditions, controller and estimator settings, and a serialisable schedule of loads and wheel failures.
- It also stores the seed, time step, model and solver version, timestamped samples, metrics, metric definitions and the outcome.
- Runs persist in the browser and export as JSON (one run or all) and CSV. Where a host blocks downloads, Export offers the text to copy instead of a Download button that does nothing.
- Imports are validated with specific error messages. A reproducibility check re-runs the saved setup and compares every sample.

**Use the Cube workspace** (primary navigation and the homepage hero):

- Two entry points: Replay a recording, and Create an experiment.
- The corner demo and the edge runner are merged into one workspace, with edge and corner modes and their assumptions stated.
- Desktop layout: setup on the left; 3-D view, playback, telemetry and plots in the centre; Results, Maths, Compare and Assistant tabs on the right. On small screens the three panels become accessible tabs.
- Controls: play, pause, restart, scrub (click the plots too), speed, camera views, zoom and reset. There is keyboard access.
- The 3-D view, telemetry, plot cursors and maths all read the same sample.

**Masses and forces:**

- Base mass and dimensions can be edited.
- Point masses can be added, moved, edited and removed, either by clicking the 3-D cube or by entering body coordinates.
- Forces are set by magnitude, application point, direction, start and duration, in the body frame or the world frame. Pure torques are also available.
- The 3-D view shows the COM, the pivot-to-COM line, body and world axes, force arrows and the applied-torque arrow.
- Combined mass, COM and inertia use parallel-axis terms, and r × F is computed about the pivot in consistent frames. All of these feed the simulation.

**Maths panel.** For the selected run, each equation is shown with its variables, units, numeric substitutions, values, a plain explanation and its assumptions. Fixed setup quantities are kept separate from time-varying ones. It covers mass properties, gravity torque, applied-force torque, wheel momentum, actuator limits, controller output and the dynamics.

**Compare.** Up to four runs share aligned time axes and matching units. A table shows which conditions differ, and there is a caveat against declaring a controller best in general.

**Assistant.** Fixed-rule explanations built only from run data, each listing the data it used. It is labelled "no AI service connected". There is a documented integration point for a server-side endpoint, and numbers that do not appear in the run data are flagged. No keys are stored in the site.

**Homepage:**

- Shorter opening.
- Status split into completed, next and planned.
- Placeholders for hardware footage, measured specs and sim-vs-hardware comparisons, all driven by `js/site-content.js`.
- The `YourUsername` GitHub links are removed, and the site says "Repository forthcoming".
- Generated visuals are labelled as generated.
- The benchmark values from earlier project runs are kept with their provenance ("traces pending import; not produced by this site's simulator"). The "BEST" badge is replaced by highlighting the lowest value in each column.

**Lab:**

- Uses the same simulator and outcome rules. §09 is rewritten to the new definitions.
- Invalid parameter edits are rejected with an explanation instead of being recomputed.
- The old runner is replaced by a pointer to the workspace, and every experiment has "Open in workspace" buttons.

**Offline.** three.js, KaTeX and the fonts are bundled, so there are no CDN requests.

**Assembly video.** The same clip now also ships as WebM (VP9) alongside the MP4 (H.264), so browsers without H.264 support can still play it.

### 3. Calculation changes, with the reasons

- **COM offset angle.** β = atan2(δ, l_e) and l = √(l_e² + δ²) exactly, instead of β ≈ δ/l_e with the bare-cube lever arm. This changes the 3 mm results by ≤0.1 %: the PID fall moves from 5.372 s to 5.366 s, and the LQR parked speed from 819.2 to 819.1 rpm.
- **Corner floor contact.** The test is now exact: one of the three edges at the pivot reaches the floor, min(u_B) ≤ 0. Before, it was a fixed 35.26° tilt, which is exact only when tilting toward an edge.
- **Wheel-speed clamp removed.** The corner model had a clamp that reset a wheel to its no-load speed, which does not conserve momentum. The motor model already limits torque. None of the reference results changed.
- **Recording convention.** Each sample holds the state at t and the command computed from that same state (zero-order hold), so the maths panel's substitutions reproduce the recorded values exactly. This is tested.
- **Capture-region grid.** It now uses the same band, hold and fall rules as every run, and is labelled "captured".
- **Formulas.** No model formula was changed to improve results. The dynamics, controllers and estimators are the same as in v1, and the reference energies and wheel speeds match the independent Python model to 10⁻⁴.

### 4. Verification

Numerical tests are kept separate from browser checks. All pass.

- `node tests/numerics.test.js`: **38/38**. Covers:
  - the regression case, and the same case over 20 s;
  - settling semantics on synthetic signals, drift and not-drift;
  - invalid and non-numeric inputs, unknown names, the floor, and the loop rate;
  - mass properties checked independently (COM, Θ_C, the Steiner identity, single point masses);
  - r × F in body and world frames, forces through the pivot or along the edge having no effect, force effects, and corner force direction;
  - LQR/PID gains and E1/E3 energies and wheel speeds against the Python reference (≤10⁻⁴ relative), and E2 against v1;
  - corner wheel failure with and without reallocation;
  - determinism and seeds, a JSON round trip, and the independence of old configurations;
  - samples agreeing with the maths panel equations.
- `node tests/runs.test.js`: **14/14**. Covers:
  - self-contained records, and save, list and load;
  - persistence across a module reload, and old runs staying independent;
  - JSON and bundle round trips, broken-file errors, setup-only import, duplicates;
  - imported runs with missing derived data rebuilt from their saved setup, and runs with non-numeric metrics or no outcome reason rejected;
  - CSV, delete all, a full storage quota, reproducibility, and invalid runs never being recorded.
- `node tests/assistant.test.js`: **9/9**. Answers quote the run's own values, contain no NaN in edge or corner mode, and the rules for honest non-answers and unverified numbers hold.
- `python3 tests/browser_check.py`: **50/50** in headless Chromium, desktop 1440×900 and phone 390×844. Covers:
  - the assembly video loading, playing and pausing;
  - the regression outcome everywhere, invalid rejection, and delete-all resetting every view;
  - persistence after reload, including the open run and time;
  - the export text and import round trip, and import rejection;
  - export on hosts that block downloads (Copy only) and through a host's save prompt (accepted, declined, unavailable);
  - 3-D, telemetry, scrubber, plots and maths staying in sync at several times, and plot click-to-seek;
  - play, pause and speed;
  - click-to-place a mass on the cube surface and its effect on mass properties, a force acting only in its window, and old runs keeping their own setup;
  - the Compare caveat and the assistant labels;
  - every example free of NaN and KaTeX errors, and the Lab and home equations;
  - arrow-key tabs, the keyboard slider and Space;
  - no horizontal scroll at 390 px, one panel per tab on phones, and the honesty and provenance labels.

### 5. Not tested

- **Real GPUs and browsers.** Only headless Chromium with software WebGL was checked. Safari, Firefox, iOS and Android, and real GPUs were not run. The 3-D frame rate on low-end phones is also unmeasured. The test browser has no H.264 decoder, so it played the WebM copy of the video; the MP4 was not played in testing.
- **Screen readers.** Only the ARIA structure and keyboard operation were checked. Other assistive technology may behave differently.
- **Downloads.** The **Download** buttons use the browser's download mechanism, which headless tests cannot observe. The text shown in the export dialog was tested instead.
- **AI endpoint.** The optional AI-service endpoint path was not exercised against a real server.
- **Storage limits.** A full browser storage was simulated only in the unit test. On a real browser, very long corner runs recorded at 200 Hz can reach the quota sooner.
- **Hardware.** Nothing has been checked against the physical cube, because no hardware data was available.

### 6. Remaining backend and physics-engine work

- **Measured parameters.** Replace the nominal values with measurements (mass, trifilar inertia, motor k_t and k_e, friction spin-down), then re-run the Lab and the benchmarks.
- **Hardware data.**
  - A telemetry link into the workspace (serial, WebSerial or a small bridge).
  - A hardware-log import format that matches `aeris-run/1` samples, so real runs can be compared with simulated ones.
  - Import of the traces behind the earlier benchmark.
- **Estimation.** A 3-D attitude estimator for corner mode; corner runs currently use ideal state feedback.
- **Corner control.** Full MIMO LQR for anisotropic inertia when masses are added; corner mode currently uses a tilt/yaw split designed on averaged inertias.
- **Contact modelling.** Slip, lift-off, rolling on the edge or corner, and tipping over the end of the edge, none of which are modelled yet. Also frame flexibility, motor electrical dynamics and sensor delay.
- **Storage and backend.**
  - IndexedDB, or a small backend, for large run libraries and sharing.
  - A server-side AI proxy, if the assistant should answer free-form questions; the site's endpoint hook is already in place.
  - A Python or offline batch engine for parameter sweeps and capture-region maps, using the same `aeris-config/1` files.

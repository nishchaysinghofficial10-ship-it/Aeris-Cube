"""Browser checks for v5.2: research-sweep cancellation in every job state (review finding G4 of v5.1).

Run:   python3 tests/browser_v52.py        (file://…/index.html, Playwright + Chromium; DEMO mode, the browser engine)

v5.1's check waited 300 ms after starting a 390-run sweep and then clicked Cancel; on a fast machine every run had
already finished and the job completed — a timing race, not a test of cancellation. Here nothing waits for a timer:
the actual Cancel button is clicked from inside the real job's own progress events (AERIS_JOBS.subscribe), at a chosen
state, and every wait for the end of a job is bounded. All sweeps are real simulations of the AERIS Twin engine;
nothing is mocked. Each case is separate:

  before start      Run, then Cancel in the same task (QUEUED): cancelled, nothing computed, labelled PARTIAL
  during execution  Cancel at the first progress event with 0 < done < total: cancelled with exactly those rows, each
                    equal to an independent recomputation of the same configuration, labelled PARTIAL
  last run          Cancel at the progress event that reports done == total: too late — complete, never PARTIAL,
                    and the job says the request came after the last run
  analysing         when the job enters ANALYZING the Cancel button is hidden (the browser engine does not interrupt
                    its analysis); a request sent anyway is reported and the complete result is kept
  after completion  Cancel on a finished job changes nothing
  next sweep        after a cancelled sweep the next sweep's Cancel button is usable again (v5.1 left it disabled as
                    "Cancelling…") and cancels it

The during-execution, analysing and next-sweep cases run REPEATS times at full speed and REPEATS times with Chromium's
CPU throttled THROTTLE× (DevTools Emulation.setCPUThrottlingRate). Every attempt is a separate check; nothing is
retried.
"""
import asyncio
import json
import pathlib
import sys

from playwright.async_api import async_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
URL = (ROOT / "index.html").as_uri() + "#lab/sweep"
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
REPEATS = 3
THROTTLE = 4
WAIT_MS = 120000                        # bound for one job to end (390 ten-second runs at THROTTLE× take ~10 s here)
results = []

DEF_390 = ("d.mode = 'grid'; d.variables = [{key: 'tilt_deg', min: -6, max: 6, steps: 13}, {key: 'rate_dps', min: -60, max: 60, steps: 10}];"
           " d.duration_s = 10; d.controllers = ['pid', 'lqr', 'adp']; d.mass_configs = ['base'];")
DEF_12 = ("d.mode = 'grid'; d.variables = [{key: 'tilt_deg', min: -6, max: 6, steps: 2}, {key: 'rate_dps', min: -60, max: 60, steps: 2}];"
          " d.duration_s = 2; d.controllers = ['pid', 'lqr', 'adp']; d.mass_configs = ['base'];")
BUTTON = "(() => { const b = document.getElementById('swCancel'); return {hidden: b.hidden, disabled: b.disabled, text: b.textContent}; })()"
STATE = """(() => { const s = AERIS_SWEEP_UI._state, j = s.job, r = s.result, out = document.getElementById('swOut').innerText;
  return {state: j.state, done: j.progress.done, total: j.progress.total, message: j.message, label: (document.querySelector('#swJob .job-st') || {}).textContent || '',
          rows: r ? r.rows.length : null, partial: r ? r.partial : null, analysis: r ? !!r.analysis : null, ordered: r ? r.rows.every((x, i) => x.index === i) : null,
          banner: out.includes('PARTIAL sweep'), button: %s}; })()""" % BUTTON


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else "  →  " + str(detail)[:600]), flush=True)


async def fresh(browser, throttle=1):
    ctx = await browser.new_context(viewport={"width": 1440, "height": 900})
    page = await ctx.new_page()
    page.errs = []
    page.on("pageerror", lambda e: page.errs.append(str(e)))
    page.on("console", lambda m: page.errs.append(m.text) if m.type == "error" else None)
    if throttle != 1:
        cdp = await ctx.new_cdp_session(page)
        await cdp.send("Emulation.setCPUThrottlingRate", {"rate": throttle})
    await page.goto(URL, wait_until="load")
    await page.wait_for_function("typeof AERIS_SWEEP_UI !== 'undefined' && !!document.getElementById('swRun')", timeout=30000)
    await page.click('[data-preset="sat"]')
    await page.wait_for_function("!document.getElementById('swRun').disabled", timeout=30000)
    return ctx, page


async def start_armed(page, definition, when):
    """Start a sweep and arm a one-shot cancel: inside the job's own update callback, when `when` holds, the actual
    Cancel button's state is recorded and it is clicked (in the same task, so the moment is exact)."""
    return await page.evaluate("""(() => { const d = AERIS_SWEEP_UI._state.def; %s document.getElementById('swRun').click();
      const job = AERIS_SWEEP_UI._state.job; window.__g4 = null;
      AERIS_JOBS.subscribe(job, j => { if (!window.__g4 && (%s)) { const b = document.getElementById('swCancel');
        window.__g4 = {state: j.state, done: j.progress.done, total: j.progress.total, button: {hidden: b.hidden, disabled: b.disabled, text: b.textContent}};
        b.click(); } });
      return {state: job.state, total: job.progress.total}; })()""" % (definition, when))


async def ended(page):
    try:
        await page.wait_for_function("AERIS_SWEEP_UI._state.job && ['complete', 'cancelled', 'failed'].includes(AERIS_SWEEP_UI._state.job.state)", timeout=WAIT_MS)
        return True
    except Exception:  # noqa: BLE001 — a job that does not end within the bound is a failed check, reported below
        return False


USABLE = lambda b: b and not b["hidden"] and not b["disabled"] and b["text"] == "Cancel"      # noqa: E731
RESET = lambda b: b["hidden"] and not b["disabled"] and b["text"] == "Cancel"                 # noqa: E731


async def during_execution(page, tag):
    await start_armed(page, DEF_390, "j.state === 'running' && j.progress.done > 0 && j.progress.done < j.progress.total")
    fin = await ended(page)
    at, st = await page.evaluate("window.__g4"), await page.evaluate(STATE)
    ok = (fin and at and at["state"] == "running" and 0 < at["done"] < at["total"] == 390 and USABLE(at["button"]) and st["state"] == "cancelled"
          and st["rows"] == at["done"] == st["done"] and st["partial"] is True and st["ordered"] and st["banner"] and st["label"] == "CANCELLED"
          and f"Cancelled after {at['done']} of 390 runs" in st["message"])
    check(f"[{tag}] Cancel while running ({at and at['done']}/390 done): CANCELLED with exactly those rows, PARTIAL, bounded wait", ok, (fin, at, st))
    check(f"[{tag}] After the cancellation the Cancel button is hidden and reset ('Cancel', enabled) for the next sweep", RESET(st["button"]), st["button"])
    # the kept rows are the real results: recomputed here from the same configurations by the same engine, identical
    same = await page.evaluate("""(() => { const r = AERIS_SWEEP_UI._state.result, specs = AERIS_SWEEP.expand(r.definition);
      const bad = r.rows.filter((row, i) => JSON.stringify(row) !== JSON.stringify(AERIS_SWEEP.rowOf(specs[i], AERIS_TWIN.simulate(specs[i].config))));
      const an = r.analysis, n = an ? Object.values(an.controllers).reduce((a, c) => a + c.n, 0) : -1;
      return {rows: r.rows.length, differing: bad.length, analysed: n, controllers: an ? Object.keys(an.controllers) : []}; })()""")
    check(f"[{tag}] The cancelled sweep's rows equal an independent recomputation, and its analysis uses only those rows",
          same["rows"] == at["done"] and same["differing"] == 0 and same["analysed"] == same["rows"], same)
    return at, st


async def analysing(page, tag):
    await start_armed(page, DEF_390, "j.state === 'analyzing'")
    fin = await ended(page)
    at, st = await page.evaluate("window.__g4"), await page.evaluate(STATE)
    check(f"[{tag}] ANALYZING: the Cancel button is hidden when the job enters it (the browser engine does not interrupt its analysis)",
          bool(at) and at["state"] == "analyzing" and at["done"] == at["total"] == 390 and at["button"]["hidden"], at)
    ok = (fin and at and st["state"] == "complete" and st["rows"] == 390 and st["partial"] is False and st["analysis"] and not st["banner"]
          and st["label"] == "COMPLETE" and "cancel request arrived after the last run" in st["message"] and RESET(st["button"]))
    check(f"[{tag}] ANALYZING: a request sent anyway is reported on the job and the complete result is kept (not PARTIAL)", ok, (fin, st))


async def next_sweep(page, tag):
    """after a cancelled sweep, in the same page: the next sweep's Cancel button is usable and cancels it"""
    await during_execution(page, tag + " first sweep")
    await start_armed(page, DEF_390, "j.state === 'running' && j.progress.done > 0 && j.progress.done < j.progress.total")
    fin = await ended(page)
    at, st = await page.evaluate("window.__g4"), await page.evaluate(STATE)
    check(f"[{tag}] After a cancelled sweep, the next sweep's Cancel button is usable ('Cancel', enabled) and cancels it",
          fin and at and USABLE(at["button"]) and st["state"] == "cancelled" and st["rows"] == at["done"] < 390 and st["partial"] is True, (fin, at, st))


async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch(args=ARGS)
        print(f"Chromium {br.version}; REPEATS={REPEATS}, THROTTLE={THROTTLE}x", flush=True)

        # ---- before start: Run then Cancel in one task, while the job is still QUEUED
        ctx, page = await fresh(br)
        b0 = await page.evaluate("(() => { const d = AERIS_SWEEP_UI._state.def; %s document.getElementById('swRun').click(); const s = AERIS_SWEEP_UI._state.job.state, b = %s;"
                                 " document.getElementById('swCancel').click(); return {state: s, button: b}; })()" % (DEF_390, BUTTON))
        fin = await ended(page)
        st = await page.evaluate(STATE)
        out = await page.evaluate("document.getElementById('swOut').innerText")
        check("Before start (QUEUED): Cancel is offered; the job ends CANCELLED with no run computed, labelled PARTIAL, nothing analysed",
              fin and b0["state"] == "queued" and USABLE(b0["button"]) and st["state"] == "cancelled" and st["done"] == 0 and st["rows"] == 0
              and st["partial"] is True and st["banner"] and "No runs finished" in out, (b0, st))
        check("Before start: after the cancellation the Cancel button is hidden and reset", RESET(st["button"]), st["button"])
        check("No script errors (before start)", not page.errs, page.errs[:3])
        await ctx.close()

        # ---- during execution, analysing and next sweep: full speed and throttled, REPEATS times each, no retries
        for throttle in (1, THROTTLE):
            tag = "full speed" if throttle == 1 else f"CPU {throttle}x slower"
            for k in range(1, REPEATS + 1):
                ctx, page = await fresh(br, throttle)
                await during_execution(page, f"{tag} #{k}")
                check(f"[{tag} #{k}] No script errors", not page.errs, page.errs[:3])
                await ctx.close()
            ctx, page = await fresh(br, throttle)
            await analysing(page, tag)
            await next_sweep(page, tag)
            check(f"[{tag}] No script errors (analysing, next sweep)", not page.errs, page.errs[:3])
            await ctx.close()

        # ---- the last progress event (done == total, still RUNNING): too late; the job completes
        ctx, page = await fresh(br)
        await start_armed(page, DEF_390, "j.state === 'running' && j.progress.done === j.progress.total")
        fin = await ended(page)
        at, st = await page.evaluate("window.__g4"), await page.evaluate(STATE)
        check("At the last run (done == total, still running): the request is too late — COMPLETE with every row, never PARTIAL, and said so",
              fin and at and at["state"] == "running" and at["done"] == at["total"] == 390 and st["state"] == "complete" and st["rows"] == 390
              and st["partial"] is False and not st["banner"] and "cancel request arrived after the last run" in st["message"] and RESET(st["button"]), (fin, at, st))
        await ctx.close()

        # ---- after completion: Cancel changes nothing
        ctx, page = await fresh(br)
        await page.evaluate("(() => { const d = AERIS_SWEEP_UI._state.def; %s document.getElementById('swRun').click(); })()" % DEF_12)
        fin = await ended(page)
        before = await page.evaluate("JSON.stringify(AERIS_SWEEP_UI._state.result)")
        b1 = await page.evaluate(BUTTON)
        await page.evaluate("document.getElementById('swCancel').click()")
        await page.wait_for_function("true")
        after = await page.evaluate("JSON.stringify(AERIS_SWEEP_UI._state.result)")
        st = await page.evaluate(STATE)
        check("After completion: the Cancel button is hidden and a request changes nothing (result identical, COMPLETE, not PARTIAL)",
              fin and b1["hidden"] and before == after and st["state"] == "complete" and st["rows"] == 12 and st["partial"] is False, (b1, st, before == after))
        check("After completion: a request sent anyway leaves the hidden button reset (not 'Cancelling…')", RESET(st["button"]), st["button"])
        check("No script errors (last run, after completion)", not page.errs, page.errs[:3])
        await ctx.close()
        await br.close()
    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n{passed} / {len(results)} v5.2 browser checks passed")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))

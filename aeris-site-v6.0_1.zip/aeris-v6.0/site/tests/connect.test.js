/* The Connect stack in Node: link framing and negotiation, calibration parity with the backend, the WebAssembly
   synthetic device driven by the page's own link host (pairing with the local press, measurements, a calibration,
   an approved configuration bound by its hash, self-test, an experiment that starts only after the local enable,
   the browser recorder), and the installer's manifest/trust/image checks with a SCRIPTED flasher (no board).

     node tests/connect.test.js

   Everything the synthetic device produces is synthetic; the flasher here is a test double. */
"use strict";
var path = require("path"), fs = require("fs"), vm = require("vm"), crypto = require("crypto");
var ROOT = path.join(__dirname, "..");
vm.runInThisContext(fs.readFileSync(path.join(ROOT, "vendor", "noble-p256-sha256.min.js"), "utf8"));
global.AERIS_LINK = require(path.join(ROOT, "js", "connect", "link.js"));
var L = global.AERIS_LINK;
var SY = require(path.join(ROOT, "js", "connect", "synthetic.js"));
var CAL = require(path.join(ROOT, "js", "connect", "calib.js"));
var SES = require(path.join(ROOT, "js", "connect", "session.js"));
var REC = require(path.join(ROOT, "js", "connect", "recorder.js"));
var STORE = require(path.join(ROOT, "js", "connect", "store.js"));
var INST = require(path.join(ROOT, "js", "connect", "installer.js"));

var results = [], queue = [];
function test(n, f) { queue.push({ n: n, f: f }); }
function run() {
  var i = 0;
  (function next() {
    if (i >= queue.length) return report();
    var t = queue[i++], cur = { name: t.n, ok: true, msgs: [] };
    function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
    var p; try { p = t.f(check); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); }
    Promise.resolve(p).then(function () { results.push(cur); next(); }, function (e) { cur.ok = false; cur.msgs.push("rejected: " + (e && (e.stack || e.message) || e)); results.push(cur); next(); });
  })();
}
function report() {
  var pass = results.filter(function (r) { return r.ok; }).length;
  results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
  console.log("\n" + pass + " / " + results.length + " connect tests passed");
  process.exit(pass === results.length ? 0 : 1);
}
var TE = new TextEncoder();
function tick() { return new Promise(function (r) { setImmediate(r); }); }

/* ---------------- link ---------------- */
test("CRC-32 is zlib's (check value of '123456789')", function (check) {
  check(L.crc32(TE.encode("123456789")) === 0xcbf43926, "crc " + L.crc32(TE.encode("123456789")).toString(16));
  var js = '{"kind":"x"}', f = L.frame({ kind: "x" });
  var zl = require("zlib").crc32 ? require("zlib").crc32(Buffer.from(js)) : null;
  check(zl == null || Buffer.from(f).toString().endsWith("\t" + zl.toString(16).padStart(8, "0") + "\n"), "zlib parity");
});
test("framing: boot text ignored, split lines joined, bad CRC and over-long lines dropped", function (check) {
  var sent = [], got = [], h = new L.Host({ send: function (b) { sent.push(b); } });
  h.on("dev_hello", function (m) { got.push(m); });
  h.start();
  check(JSON.parse(Buffer.from(sent[0]).toString().split("\t")[0]).kind === "host_hello", "host_hello first");
  var line = L.frame({ kind: "dev_hello", device_id: "d1", link: L.LINK, versions: [1] });
  h.receive(TE.encode("ESP-ROM:esp32s3-20210327\r\n")); h.receive(line.slice(0, 9)); h.receive(line.slice(9));
  check(got.length === 1 && h.stats.unframed === 1, "hello + unframed " + JSON.stringify(h.stats));
  var bad = Buffer.from(line); bad[bad.length - 2] = bad[bad.length - 2] === 48 ? 49 : 48; h.receive(bad);
  check(h.stats.bad_crc === 1 && got.length === 1, "bad crc");
  h.receive(new Uint8Array(5000).fill(120)); h.receive(TE.encode("\n")); h.receive(line);
  check(h.stats.too_long === 1 && got.length === 2, "too long " + JSON.stringify(h.stats));
  var thrown = false; try { h.command("identify"); } catch (e) { thrown = true; }
  check(thrown, "no command before a session");
  h.openSession(1);
  var id = h.command("apply_config", null, { rawParamsText: '{"config":{"b":1,"a":2}}', config_hash: "ab" });
  check(Buffer.from(sent[sent.length - 1]).toString().indexOf(',"params":{"config":{"b":1,"a":2}}}\t') > 0 && h.pending[id].status === "sent", "raw params sent as bytes");
  thrown = false; try { h.command("apply_config", null, { rawParamsText: '{"config":"' + "x".repeat(5000) + '"}' }); } catch (e) { thrown = true; }
  check(thrown && h.seq === 1, "over-long command refused, sequence unchanged");
});
test("negotiation: full support, read-only for an unknown protocol, no substituted controller", function (check) {
  var hello = { link: L.LINK, versions: [1], fw: { actuation_build: false }, board: { id: "esp32-s3-devkitc-1", kind: "physical" },
    caps: { actions: ["identify", "diagnostics", "apply_config", "start_experiment", "stop"], controllers: ["edge-lqr"], estimators: ["cf3d"], imu: "lsm6dsox", motor: "odrive-cansimple", config_schema: "aeris-device-config/1", max_control_hz: 1000 },
    limits: { hard_max_current_A: 10, hard_max_torque_Nm: 1, hard_max_speed_rpm: 8000 } };
  var c = L.negotiate(hello);
  check(c.supported && c.mode === "full" && /never drives motors/.test(c.note), JSON.stringify(c));
  var old = L.negotiate(Object.assign({}, hello, { link: "aeris-device-link/0", versions: [0] }));
  check(!old.supported && old.mode === "read-only" && old.actions.join() === "identify,diagnostics,stop", JSON.stringify(old));
  var prof = JSON.parse(fs.readFileSync(path.join(ROOT, "data", "profiles", "aeris-ref-a1.r1.json"))).document;
  var corner = JSON.parse(fs.readFileSync(path.join(ROOT, "data", "recipes", "corner-hold-10s.json"))).document;
  check(L.profileFits(hello, prof, corner).some(function (w) { return /corner-mimo-lqr/.test(w); }), "corner controller not offered → refused");
  check(!L.profileFits(hello, prof).some(function (w) { return /torque limit/.test(w); }), "the reference motor model is within the hard torque cap");
  var strong = JSON.parse(JSON.stringify(prof)); strong.wheels[1].motor.KV_rpm_per_V = 50;
  check(L.profileFits(hello, strong).some(function (w) { return /wheel 1: torque limit 1\.528 N·m above the firmware's hard limit 1 N·m/.test(w); }), "torque above the hard cap → refused (the rule of devices/compat.py)");
});

/* ---------------- calibration parity with the backend ---------------- */
test("calibration: the 24 rotations and every shared case agree with the backend", function (check) {
  check(CAL.ROTATIONS.length === 24, "24 rotations");
  var fx = JSON.parse(fs.readFileSync(path.join(__dirname, "fixtures", "calibration_parity.json")));
  fx.axes_cases.forEach(function (c, i) {
    var got;
    try { var f = CAL.solveToBody(c.axes); got = { ok: true, to_body: f.to_body, max_residual_deg: f.max_residual_deg }; } catch (e) { got = { ok: false, error: e.message.slice(0, 40) }; }
    check(got.ok === c.expected.ok, "case " + i + ": ok " + got.ok + " vs " + c.expected.ok + " " + (got.error || c.expected.error || ""));
    if (got.ok && c.expected.ok) {
      check(JSON.stringify(got.to_body) === JSON.stringify(c.expected.to_body), "case " + i + ": to_body");
      check(Math.abs(got.max_residual_deg - c.expected.max_residual_deg) < 1e-6, "case " + i + ": residual " + got.max_residual_deg + " vs " + c.expected.max_residual_deg);
    } else if (!got.ok && !c.expected.ok) check(got.error === c.expected.error, "case " + i + ": message '" + got.error + "' vs '" + c.expected.error + "'");
  });
  var prof = JSON.parse(fs.readFileSync(path.join(ROOT, "data", "profiles", "aeris-ref-a1.r1.json"))).document;
  fx.wheel_cases.forEach(function (c, i) {
    var w = CAL.wheelChecks(c.encoders, prof);
    check(JSON.stringify(w.map(function (x) { return { direction_ok: x.direction_ok, checked: x.checked }; })) === JSON.stringify(c.expected), "wheel case " + i);
  });
});

/* ---------------- the synthetic device with the page's own link host ---------------- */
function makeSynthetic(id, mode) {
  var wasm = fs.readFileSync(path.join(ROOT, "firmware", "synthetic", "aeris-device.wasm"));
  var plant = fs.readFileSync(path.join(ROOT, "firmware", "synthetic", "plant_" + (mode || "edge") + ".json"), "utf8");
  var transport = null, logs = [];
  return SY.create({ wasm: wasm, plant: plant, deviceId: id, noble: global.AERIS_NOBLE, onOut: function (link, b) { if (transport) transport.deliver(b); }, onLog: function (l, m) { logs.push(m); } })
    .then(function (dev) { transport = new SY.Transport(dev, SY.USB); return { dev: dev, transport: transport, logs: logs }; });
}
function driver(dev, session) {
  return function until(pred, simSeconds) {
    var limit = dev.timeUs() + (simSeconds || 10) * 1e6;
    return (function loop() {
      if (pred()) return Promise.resolve(true);
      if (dev.timeUs() > limit) return Promise.resolve(false);
      dev.advance(5000); if (session) session.host.tick();
      return tick().then(loop);
    })();
  };
}
test("synthetic device: pairing needs the press of ARM; measurements; calibration; approved configuration; local enable", function (check) {
  var store = STORE;
  return makeSynthetic("synthetic-node-0001", "edge").then(function (S) {
    var dev = S.dev, sess = new SES.Local(S.transport, { store: store, manualTick: true, now: function () { return dev.timeUs() / 1000; } });
    var until = driver(dev, sess), hello = null, states = [], frames = [];
    sess.on("state", function (s) { states.push(s.state); });
    sess.on("telemetry", function (m) { frames.push(m); });
    var startP = sess.start().then(function (h) { hello = h; });
    return until(function () { return !!hello; }, 2).then(function () {
      check(hello && hello.board.kind === "emulator" && hello.board.synthetic === true && hello.paired === false, "hello: synthetic, unpaired");
      check(!sess.host.linkSession, "no session before pairing");
      var waiting = false, rec = null, err = null;
      sess.on("pair_wait", function () { waiting = true; });
      var pp = sess.pair("node synthetic").then(function (r) { rec = r; }, function (e) { err = e; });
      return until(function () { return waiting; }, 2).then(function () {
        check(waiting && !rec, "pair_ready: waiting for the local press");
        return until(function () { return false; }, 1);                 // nothing happens without the press
      }).then(function () {
        check(!rec && !err, "still waiting without a press");
        dev.armPress();
        return until(function () { return !!rec || !!err; }, 3);
      }).then(function () {
        check(rec && !err && rec.pubkey && L.verifyPairProof(Object.assign({ session: rec.proof.session, nonce: rec.proof.nonce, device_id: rec.id, pubkey: rec.pubkey, board_id: rec.board, firmware: rec.firmware, sig: rec.proof.sig })), "paired and the proof verifies: " + (err && err.message));
        return until(function () { return sess.host.sessionOk; }, 2);
      }).then(function () {
        check(sess.host.sessionOk && sess.host.role === "supervisor", "USB session supervises");
        function cmd(action, params, o) { var p = sess.run(action, params, o), out = null; p.then(function (c) { out = c; }, function (e) { out = { status: "error", error: e }; }); return until(function () { return !!out; }, 30).then(function () { return out; }); }
        var M = {};
        return cmd("identify").then(function (c) { check(c.status === "completed", "identify " + c.status); return cmd("calibrate_imu", { seconds: 2 }); })
          .then(function (c) { check(c.status === "completed", "calibrate_imu " + c.status); M.imu = c.result; dev.face("+z"); return until(function () { return false; }, 0.3); })
          .then(function () { return cmd("calibrate_axes", { seconds: 1, face: "+z" }); })
          .then(function (c) { check(c.status === "completed", "+z " + c.status); M.axes = [c.result]; dev.face("-x"); return until(function () { return false; }, 0.3); })
          .then(function () { return cmd("calibrate_axes", { seconds: 1, face: "-x" }); })
          .then(function (c) { check(c.status === "completed", "-x " + c.status); M.axes.push(c.result); dev.hold();
            var p = cmd("check_encoders", { seconds: 2 });
            return until(function () { return false; }, 0.5).then(function () { dev.spin(0, 20); dev.spin(1, 20); dev.spin(2, 20); return p; }); })
          .then(function (c) {
            check(c.status === "completed", "encoders " + c.status); M.encoders = c.result;
            var prof = JSON.parse(fs.readFileSync(path.join(ROOT, "data", "profiles", "aeris-ref-a1.r1.json"))).document;
            var cal = CAL.build("synthetic-node-0001", { id: "aeris-ref-a1", revision: 1 }, prof, M, { source: "synthetic-device" });
            check(JSON.stringify(cal.imu.to_body) === JSON.stringify([1, 0, 0, 0, 1, 0, 0, 0, 1]) && cal.wheel_directions_confirmed, "calibration: identity mounting, directions confirmed");
            var ref = JSON.parse(fs.readFileSync(path.join(ROOT, "data", "configs", "aeris-ref-a1.r1.edge-hold-10s.json")));
            var calRef = { id: "LOCAL-CAL-test", hash: SES.sha256hex(SES.canonicalText(cal)) };
            var built = SES.composeConfig(ref, cal, calRef, global.AERIS_NOBLE);
            check(built.hash === crypto.createHash("sha256").update(built.text).digest("hex") && built.hash !== ref.hash, "composed configuration hashed over its text");
            check(SES.composeConfig(ref, cal, calRef, global.AERIS_NOBLE).hash === built.hash, "composition is deterministic");
            var bad = null, p0 = sess.run("apply_config", null, { rawParamsText: '{"config":' + built.text.replace('"edge"', '"corner"') + "}", config_hash: built.hash }).then(function (c) { bad = c; });
            return until(function () { return !!bad; }, 3).then(function () {
              check(bad.status === "rejected" && /SHA-256|config_hash/.test(bad.history[bad.history.length - 1].reason || ""), "an altered configuration is refused: " + JSON.stringify(bad.history.slice(-1)));
              return p0.then(function () { return cmd("apply_config", null, { rawParamsText: '{"config":' + built.text + "}", config_hash: built.hash }); });
            }).then(function (c) {
              check(c.status === "completed", "apply_config " + c.status);
              return until(function () { return sess.host.state && sess.host.state.config_hash === built.hash; }, 2).then(function () { return built; });
            });
          })
          .then(function (built) {
            check(sess.host.state.config_hash === built.hash, "the device reports the composed hash");
            return cmd("self_test", null, { ttl_ms: 8000 }).then(function (c) { check(c.status === "completed" && sess.host.state.state === "READY", "self-test → READY (" + c.status + ", " + sess.host.state.state + ")"); return built; });
          })
          .then(function (built) {
            var r = new REC.Recorder("node test", { profile: { id: "aeris-ref-a1", revision: 1 }, transport: "synthetic" });
            check(sess.tlmHello && sess.tlmHello.config_hash === built.hash, "the telemetry session names the applied configuration");
            r.feed(sess.tlmHello);
            sess.on("telemetry", function (m) { r.feed(m); });
            var ex = null, p = sess.run("start_experiment", { duration_s: 2 }, { config_hash: built.hash, ttl_ms: 4000, until: ["executing", "completed", "failed", "rejected", "expired"] }).then(function (c) { ex = c; });
            return until(function () { return !!ex; }, 2).then(function () {
              check(ex.status === "executing" && /local enable/.test(ex.history[ex.history.length - 1].reason || ""), "waits for the local enable: " + JSON.stringify(ex.history.slice(-1)));
              var id = Object.keys(sess.host.pending).filter(function (k) { return sess.host.pending[k].action === "start_experiment"; })[0];
              return until(function () { return sess.host.pending[id].final; }, 6).then(function () {
                var lapsed = sess.host.pending[id];
                check(["failed", "expired"].indexOf(lapsed.status) >= 0 && lapsed.history.some(function (h) { return h.kind === "cmd_result" && (h.status === "failed" || h.status === "expired"); }) && states.indexOf("BALANCING") < 0,
                      "without the press the device lets the request lapse; nothing balanced (" + JSON.stringify(lapsed.history.slice(-1)) + ")");
                var ex2 = null, p2 = sess.run("start_experiment", { duration_s: 2 }, { config_hash: built.hash, ttl_ms: 8000 }).then(function (c) { ex2 = c; });
                return until(function () { return false; }, 0.5).then(function () { dev.armPress(); return until(function () { return !!ex2; }, 8); }).then(function () {
                  check(ex2 && ex2.status === "completed" && ex2.result && ex2.result.ended === "duration reached", "with the press: balanced for the duration " + JSON.stringify(ex2 && ex2.result));
                  check(states.indexOf("BALANCING") >= 0, "BALANCING was reported");
                  var doc = r.document();
                  check(doc.synthetic === true && doc.device.kind === "emulator" && doc.mode === "edge" && doc.provenance.device_link.config_hash === built.hash, "recording: synthetic, edge, bound to the configuration");
                  check(["q0", "q1", "q2", "q3", "w_x", "torque_cmd_x", "gyro_x", "status"].every(function (k) { return Array.isArray(doc.samples.cols[k]); }), "recording columns " + Object.keys(doc.samples.cols).join(","));
                  check(r.ndjson().split("\n")[0].indexOf('"type":"hello"') >= 0, "NDJSON starts with the hello");
                  return Promise.all([p, p2]);
                });
              });
            });
          })
          .then(function () { return sess.close(); });
      });
    }).then(function () { return startP; });
  });
});

test("link session: dropped by the device after 1.5 s without heartbeats, re-opened by the page; old commands are never resent", function (check) {
  return makeSynthetic("synthetic-node-0002", "edge").then(function (S) {
    var dev = S.dev, sess = new SES.Local(S.transport, { store: STORE, manualTick: true, now: function () { return dev.timeUs() / 1000; } });
    var until = driver(dev, sess), hello = null, events = [];
    sess.on("event", function (k) { events.push(k); });
    sess.start().then(function (h) { hello = h; });
    return until(function () { return !!hello; }, 2).then(function () {
      var rec = null; sess.pair("session test").then(function (r) { rec = r; });
      return until(function () { return false; }, 0.3).then(function () { dev.armPress(); return until(function () { return !!rec && sess.host.sessionOk; }, 3); });
    }).then(function () {
      check(sess.host.sessionOk, "paired, session open");
      var first = sess.host.linkSession, before = null, sentIds = [];
      sess.on("sent", function (c) { sentIds.push(c.id); });
      sess.run("calibrate_imu", { seconds: 5 }, { ttl_ms: 2000 }).then(function (c) { before = c; }, function (e) { before = { status: "error", e: e }; });
      return until(function () { var p = Object.keys(sess.host.pending).map(function (k) { return sess.host.pending[k]; }).filter(function (p) { return p.action === "calibrate_imu"; })[0]; return p && p.status !== "sent"; }, 1).then(function () {
        for (var i = 0; i < 400; i++) dev.advance(5000);                     // the page stalls: 2 s of device time without a heartbeat
        return until(function () { return events.indexOf("session_reopened") >= 0 && sess.host.sessionOk; }, 2);
      }).then(function () {
        check(events.indexOf("session_expired") >= 0 && events.indexOf("session_reopened") >= 0 && sess.reopened === 1, "expired, then re-opened: " + events.join(","));
        check(sess.host.linkSession !== first && sess.host.sessionOk, "a new link session is open");
        return until(function () { return !!before; }, 8);
      }).then(function () {
        var cal = before && before.id;
        check(before && ["completed", "failed", "expired"].indexOf(before.status) >= 0 && sentIds.filter(function (x) { return x === cal; }).length === 1 && sentIds.length === 1,
              "the command of the old session was sent once and never again (its own result: " + JSON.stringify(before && before.history.slice(-1)) + ")");
        var after = null; sess.run("identify").then(function (c) { after = c; });
        return until(function () { return !!after; }, 3).then(function () { check(after.status === "completed", "commands work in the new session: " + after.status + " " + JSON.stringify(after.history.slice(-1))); });
      }).then(function () { return sess.close(); });
    });
  });
});

/* ---------------- installer ---------------- */
var REL = path.join(ROOT, "firmware", "releases", "0.1.0");
function fileFetch(base) {
  return function (url) {
    var p = path.join(ROOT, url.replace(/^\.?\//, ""));
    if (!fs.existsSync(p)) return Promise.resolve({ ok: false, status: 404 });
    var buf = fs.readFileSync(p);
    return Promise.resolve({ ok: true, status: 200, json: function () { return Promise.resolve(JSON.parse(buf)); }, arrayBuffer: function () { return Promise.resolve(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length)); } });
  };
}
test("installer: manifest canonical form, trust levels, tampering, image hashes", function (check) {
  var m = JSON.parse(fs.readFileSync(path.join(REL, "manifest.json"))), trust = JSON.parse(fs.readFileSync(path.join(ROOT, "firmware", "trust.json")));
  var v = INST.verifyManifest(m, trust, global.AERIS_NOBLE, false);
  check(!v.ok && v.level === "development" && v.needsConsent, "a development build needs explicit consent: " + JSON.stringify(v));
  v = INST.verifyManifest(m, trust, global.AERIS_NOBLE, true);
  check(v.ok && v.level === "development", "verifies with the development key: " + JSON.stringify(v));
  var t = JSON.parse(JSON.stringify(m)); t.parts[2].sha256 = "0".repeat(64);
  check(!INST.verifyManifest(t, trust, global.AERIS_NOBLE, true).ok, "an altered manifest fails");
  var noKey = JSON.parse(JSON.stringify(trust)); noKey.development = [];
  check(/does not trust/.test(INST.verifyManifest(m, noKey, global.AERIS_NOBLE, true).reason), "an unknown key fails");
  var act = JSON.parse(JSON.stringify(m)); act.capabilities.actuation = true;
  check(!INST.verifyManifest(act, trust, global.AERIS_NOBLE, true).ok, "a manifest describing an actuating build is refused even if it verified");
  return INST.fetchParts(m, "firmware/releases/0.1.0", fileFetch(), global.AERIS_NOBLE).then(function (parts) {
    check(parts.length === 3 && parts[0].offset === 0 && parts[2].offset === 0x10000, "three verified parts at their offsets");
    var t2 = JSON.parse(JSON.stringify(m)); t2.parts[0].sha256 = "f".repeat(64);
    return INST.fetchParts(t2, "firmware/releases/0.1.0", fileFetch(), global.AERIS_NOBLE).then(function () { check(false, "a hash mismatch must throw"); }, function (e) { check(/does not match/.test(e.message), e.message); });
  });
});
function fakeEsptool(chipName, flashSize, failOnWrite) {
  var calls = { written: null, after: null, disconnected: 0 };
  function Transport(port) { this.port = port; }
  Transport.prototype.disconnect = function () { calls.disconnected++; return Promise.resolve(); };
  function ESPLoader(o) { this.o = o; this.chip = { CHIP_NAME: chipName }; }
  ESPLoader.prototype.main = function () { return Promise.resolve(chipName + " (QFN56) (revision v0.2)"); };
  ESPLoader.prototype.detectFlashSize = function () { return Promise.resolve(flashSize); };
  ESPLoader.prototype.writeFlash = function (opt) { if (failOnWrite) return Promise.reject(new Error("write timeout: the port was lost")); calls.written = opt; opt.reportProgress(0, 1, 1); return Promise.resolve(); };
  ESPLoader.prototype.after = function (m) { calls.after = m; return Promise.resolve(); };
  return { Transport: Transport, ESPLoader: ESPLoader, calls: calls };
}
test("installer: chip and flash checks before writing, interruption reported, identity afterwards (scripted flasher)", function (check) {
  var m = JSON.parse(fs.readFileSync(path.join(REL, "manifest.json")));
  return INST.fetchParts(m, "firmware/releases/0.1.0", fileFetch(), global.AERIS_NOBLE).then(function (parts) {
    var ok = fakeEsptool("ESP32-S3", "4MB");
    return INST.flash({}, parts, m, { esptool: ok }).then(function (rep) {
      check(rep.written && ok.calls.written.fileArray.map(function (f) { return f.address; }).join() === "0,32768,65536" && ok.calls.written.flashMode === "dio" && ok.calls.after === "hard_reset", "written at the manifest's offsets: " + JSON.stringify(rep));
      var wrong = fakeEsptool("ESP32-C3", "4MB");
      return INST.flash({}, parts, m, { esptool: wrong }).then(function () { check(false, "wrong chip must fail"); }, function (e) { check(/ESP32-C3/.test(e.message) && wrong.calls.written === null && wrong.calls.disconnected === 1, "wrong chip: nothing written: " + e.message); });
    }).then(function () {
      var small = fakeEsptool("ESP32-S3", "2MB");
      return INST.flash({}, parts, m, { esptool: small }).then(function () { check(false, "small flash must fail"); }, function (e) { check(/at least 4 MB/.test(e.message) && small.calls.written === null, e.message); });
    }).then(function () {
      var cut = fakeEsptool("ESP32-S3", "8MB", true);
      return INST.flash({}, parts, m, { esptool: cut }).then(function () { check(false, "interrupted write must fail"); }, function (e) { check(e.interrupted === true, "an interrupted write is reported as such: " + e.message); });
    }).then(function () {
      check(INST.preflight({ board: { id: "esp32-s3-devkitc-1", kind: "physical" } }, { state: "BALANCING" }, m).length === 1, "never during BALANCING");
      check(INST.preflight({ board: { id: "esp32-s3-devkitc-1", kind: "physical" } }, { state: "DISARMED" }, m).length === 0, "DISARMED may be updated");
      check(/synthetic/.test(INST.preflight({ board: { id: "aeris-synthetic", kind: "emulator" } }, { state: "DISARMED" }, m)[0]), "nothing to install on a synthetic device");
      var good = { fw: { version: m.version, build: m.build, actuation_build: false }, board: { id: "esp32-s3-devkitc-1" } };
      check(INST.verifyAfter(good, m).ok, "identity matches");
      var r = INST.verifyAfter({ fw: { version: "0.0.9", build: "x", actuation_build: false }, board: { id: "esp32-s3-devkitc-1" } }, m);
      check(!r.ok && r.mismatches.length === 2, "version/build mismatch reported: " + JSON.stringify(r.mismatches));
    });
  });
});

/* ---------------- build progress across kit revisions ---------------- */
test("build progress: kept within a revision; a revision change explains what it invalidates", function (check) {
  var kit = JSON.parse(fs.readFileSync(path.join(ROOT, "data", "kits", "aeris-kit-a1.json")));
  var p = STORE.loadProgress(kit);
  check(p.changed === null && p.progress.revision === kit.revision, "fresh progress");
  p.progress.done["plan-readiness"] = "2026-10-10"; p.progress.done["profile"] = "2026-10-10"; STORE.saveProgress(kit, p.progress);
  check(STORE.loadProgress(kit).progress.done["profile"] === "2026-10-10", "kept");
  var next = JSON.parse(JSON.stringify(kit)); next.revision = "A2-test";
  next.revision_history = kit.revision_history.concat([{ revision: "A2-test", date: "2026-12-01", changes: "test revision", invalidates: { steps: ["profile"], calibration: true } }]);
  var q = STORE.loadProgress(next);
  check(q.changed && q.changed.from === kit.revision && q.changed.to === "A2-test" && q.changed.invalidated.join() === "profile" && q.changed.calibration === true, JSON.stringify(q.changed));
  check(q.progress.done["plan-readiness"] && !q.progress.done["profile"], "unaffected steps carried over, invalidated steps cleared");
  var unknown = JSON.parse(JSON.stringify(kit)); unknown.revision = "Z9"; unknown.revision_history = [{ revision: "Z9", invalidates: { steps: [], calibration: false } }];
  var u = STORE.loadProgress(unknown);
  check(u.changed && u.changed.known === false && Object.keys(u.progress.done).length === 0, "progress of an unknown revision does not carry over");
});

run();

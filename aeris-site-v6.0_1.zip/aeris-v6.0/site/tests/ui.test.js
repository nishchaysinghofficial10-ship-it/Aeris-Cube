/* Tests for the platform's UI data modules (no DOM needed): source / claim
   badges, the system status strip, controller descriptions and colours, the
   computed comparison labels, run-plot definitions, the event-timeline
   lanes, the sensor/actuator form metadata, the mass-asymmetry numbers and
   the sim ↔ hardware validation metrics.   Run with:  node tests/ui.test.js */
"use strict";
var path = require("path");
global.window = {};
var J = function (p) { return path.join(__dirname, "..", "js", p); };
var TOK = require(J("platform/tokens.js")); global.AERIS_TOKENS = TOK;
var IDS = require(J("platform/ids.js")); global.AERIS_IDS = IDS;
var TWIN = require(J("core.js")); global.AERIS_TWIN = TWIN;
var SCHEMA = require(J("platform/schema.js")); global.AERIS_SCHEMA = SCHEMA;
var EVENTS = require(J("platform/events.js")); global.AERIS_EVENTS = EVENTS;
var CTRL = require(J("platform/controllers.js")); global.AERIS_CONTROLLERS = CTRL;
var CMP = require(J("platform/compare.js"));
var RUNS = require(J("runs.js")); global.AERIS_RUNS = RUNS;
var VAL = require(J("platform/validation.js"));
var BADGES = require(J("ui/badges.js")); global.AERIS_BADGES = BADGES;
var STATUS = require(J("ui/status.js"));
var PLOTS = require(J("ui/run-plots.js"));
var TL = require(J("ui/timeline.js"));
var SETUP = require(J("ui/setup-panels.js"));
var MASS = require(J("ui/mass-panel.js"));
var results = [], cur;
function test(n, f) { cur = { name: n, ok: true, msgs: [] }; try { RUNS.useStorage(RUNS.memoryStore(), false); f(); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); } results.push(cur); }
function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
function cfg(mode, o) { var c = TWIN.defaultConfig(mode); Object.keys(o || {}).forEach(function (k) { c[k] = o[k]; }); return c; }
function run(c, meta) { var r = TWIN.simulate(c); if (!r.ok) throw new Error("simulation rejected: " + JSON.stringify(r.errors)); return RUNS.fromSimulation(r, meta || {}); }
function text(html) { return String(html).replace(/<[^>]+>/g, ""); }

/* ------------------------------------------------------------ badges */
test("Source badges: SIMULATION for a fresh run, REPLAY for a saved one, HARDWARE only for hardware data", function () {
  var r = run(cfg("edge", { duration_s: 2 }));
  var fresh = BADGES.keysForRecord(r, "fresh"), saved = BADGES.keysForRecord(r, "saved");
  check(fresh[0].family === "source" && fresh[0].key === "simulation", "fresh → " + JSON.stringify(fresh[0]));
  check(saved[0].key === "replay", "saved → " + JSON.stringify(saved[0]));
  check(fresh.some(function (k) { return k.key === "simulated"; }) && fresh.some(function (k) { return k.key === "nominal"; }), "claims SIMULATED + NOMINAL");
  check(!fresh.some(function (k) { return k.key === "validated" || k.key === "measured" || k.key === "hardware"; }), "a simulation never claims VALIDATED, MEASURED or HARDWARE");
  var html = BADGES.forRecord(r, "fresh");
  ["SIMULATION", "SIMULATED", "NOMINAL"].forEach(function (w) { check(text(html).indexOf(w) >= 0, "badge text " + w); });
  var hw = JSON.parse(JSON.stringify(r)); hw.origin = { kind: "hardware", engine: "hardware" };
  var hk = BADGES.keysForRecord(hw, "fresh");
  check(hk[0].key === "hardware" && hk.some(function (k) { return k.key === "measured"; }), "hardware record → HARDWARE + MEASURED");
});
test("Claim labels: the six research-claim labels exist with the exact wording", function () {
  var want = { simulated: "SIMULATED", nominal: "NOMINAL", measured: "MEASURED", validated: "VALIDATED", hwPending: "HARDWARE DATA PENDING", valPending: "SIM ↔ HARDWARE VALIDATION PENDING" };
  Object.keys(want).forEach(function (k) { check(BADGES.CLAIM[k] && BADGES.CLAIM[k].text === want[k], k + " → " + (BADGES.CLAIM[k] && BADGES.CLAIM[k].text)); });
  ["DEMO DATA", "MOCK DATA", "EXAMPLE"].forEach(function (t) { check(Object.keys(BADGES.MARK).some(function (k) { return BADGES.MARK[k].text === t; }), "mark " + t); });
});
test("Marks: examples say EXAMPLE, mock-backend runs say MOCK DATA, local sweeps say DEMO MODE, cancelled sweeps say PARTIAL", function () {
  var ex = run(cfg("edge", { duration_s: 2 }), { id: "example-edge-recovery", collection: "example" });
  check(BADGES.keysForRecord(ex, "saved").some(function (k) { return k.key === "example"; }), "example mark");
  var mock = run(cfg("edge", { duration_s: 2 }), { origin: { kind: "simulation", engine: "mock-research-backend", adapter: "research-api", mode: "simulation" } });
  check(BADGES.keysForRecord(mock, "fresh").some(function (k) { return k.key === "mockData"; }), "mock mark");
  var sw = { provenance: { demo: true, mock: false, validation: { status: "nominal" } }, partial: true };
  var sk = BADGES.keysForSweep(sw).map(function (k) { return k.key; });
  check(sk.indexOf("demoMode") >= 0 && sk.indexOf("partial") >= 0 && sk.indexOf("mockData") < 0, "sweep marks " + sk.join(","));
});
test("Controller chips: colour from tokens, marker glyph, full name available; no controller uses lime", function () {
  ["pid", "lqr", "adp"].forEach(function (k) {
    var h = BADGES.controller(k, { long: true }), c = TOK.controller(k);
    check(h.indexOf(c.color) >= 0 && h.indexOf(c.glyph) >= 0, k + " chip must carry its colour and glyph");
    check(text(h).indexOf(c.name) >= 0, k + " long label " + c.name);
    check(c.color.toLowerCase() !== TOK.color.brand.toLowerCase(), k + " uses the brand colour");
  });
  check(text(BADGES.controller("adp")).indexOf("Adaptive") >= 0 && text(BADGES.controller("adp", { long: true })).indexOf("COM-adaptive LQR") >= 0, "adaptive short and long names");
});
test("Outcome badges keep the label as their only text (the icon comes from CSS)", function () {
  var h = BADGES.outcome({ code: "drifting", label: "Drifting" });
  check(text(h) === "Drifting" && /data-icon="↗"/.test(h) && /oc-badge warn/.test(h), h);
  check(/oc-badge ok/.test(BADGES.outcome({ code: "recovered", label: "Recovered" })) && /oc-badge bad/.test(BADGES.outcome({ code: "fallen", label: "Fallen" })), "tones");
});
test("Variable roles: CONTROLLED · FIXED, CHANGED · INDEPENDENT, MEASURED · DEPENDENT", function () {
  check(text(BADGES.role("controlled")) === "CONTROLLED · FIXED" && text(BADGES.role("independent")) === "CHANGED · INDEPENDENT" && text(BADGES.role("dependent")) === "MEASURED · DEPENDENT", "role texts");
});

/* ------------------------------------------------------------ status strip */
test("Status strip: six fields; never says HARDWARE or VALIDATED without cause", function () {
  var m = STATUS.model("lab", { source: "replay", controller: "LQR", experiment: "AERIS-EXP-000123" }, "demo");
  check(m.map(function (x) { return x.label; }).join("|") === "AERIS SYSTEM|SOURCE|MODEL|CONTROLLER|EXPERIMENT|VALIDATION", m.map(function (x) { return x.label; }).join("|"));
  var by = {}; m.forEach(function (x) { by[x.key] = x.value; });
  check(by.system === "DEMO" && by.source === "REPLAY" && by.experiment === "AERIS-EXP-000123", JSON.stringify(by));
  check(/AERIS Twin 0\.3\.0 · NOMINAL/.test(by.model), "model " + by.model);
  check(by.validation === "SIM ↔ HW PENDING", "validation " + by.validation);
  var cube = STATUS.model("cube", {}, "demo"), c = {}; cube.forEach(function (x) { c[x.key] = x.value; });
  check(c.source === "HARDWARE DATA PENDING", "cube page source " + c.source);
  check(STATUS.model("lab", { source: "bogus" }, "simulation")[1].value === "—", "unknown sources are not echoed");
});

/* ------------------------------------------------------------ controllers */
test("Controller descriptions match the engine: weights, clamp, and what COM-adaptive LQR adapts", function () {
  var W = TWIN.WEIGHTS, lqr = CTRL.get("lqr"), adp = CTRL.get("adp"), pid = CTRL.get("pid");
  check(lqr.design.indexOf(String(W.ww)) >= 0 && lqr.design.indexOf(Math.round(W.th / TWIN.DEG) + "°") >= 0, "LQR weights in the text");
  check(adp.name === "COM-adaptive LQR" && /balance-angle offset/.test(adp.adapts) && adp.adapts.indexOf(String(W.gam)) >= 0 && /±6°/.test(adp.adapts), "adaptation law");
  check(/does not adapt inertia/.test(adp.limits) && /not a general adaptive or nonlinear/.test(adp.limits), "states what it is not");
  check(/does not feed back wheel speed/i.test(pid.summary), "PID limitation stated");
  // v4: the MIMO LQR exists on the research backend; the browser engine still does not run it (and must say so)
  check(CTRL.PLANNED.some(function (p) { return p.key === "mimo-lqr" && p.browser === false && p.status === "research-backend"; }), "MIMO LQR listed as not implemented in this engine (research backend only)");
  var v = TWIN.validateConfig(cfg("corner", { controller: { type: "lqr", knowsAttachments: false, reconfigureOnFailure: true, structure: "mimo-lqr" } }));
  check(!v.ok, "the engine must reject the planned MIMO structure");
});

/* ------------------------------------------------------------ compare labels */
test("Computed labels: one best run per metric, fallen runs excluded, no overall winner", function () {
  var base = cfg("edge", { duration_s: 6, initial: { tilt_deg: 2, rate_dps: 0, azimuth_deg: 0, reference: "geometric" } });
  var recs = ["pid", "lqr", "adp"].map(function (c) { var x = TWIN.clone(base); x.controller.type = c; return run(x); });
  check(CMP.isControllerSet(recs), "a set that differs only in controller.type is a controller set");
  var L = CMP.labels(recs), keys = L.map(function (l) { return l.label; });
  ["Lowest settling time", "Lowest control effort", "Largest recovery margin"].forEach(function (k) { check(keys.indexOf(k) >= 0, "label " + k); });
  check(!L.some(function (l) { return /best|winner|overall/i.test(l.label); }), "no overall-winner label");
  L.forEach(function (l) {
    if (!l.winners.length) return;
    var vals = l.winners.map(function (i) { return recs[i].metrics[l.metric]; });
    recs.forEach(function (r, i) { if (l.excluded.indexOf(i) >= 0) return; var v = r.metrics[l.metric]; vals.forEach(function (w) { check(l.key === "margin" ? v <= w + 1e-6 : v >= w - 1e-3 * Math.abs(w) - 1e-9 || l.key === "wheel", l.label + ": winner is not extreme"); }); });
  });
  var fell = TWIN.clone(base); fell.controller.type = "none"; var f = run(fell);
  check(f.outcome.code === "fallen", "uncontrolled run falls");
  var L2 = CMP.labels([recs[1], f]), m = L2.filter(function (l) { return l.key === "margin"; })[0], s = L2.filter(function (l) { return l.key === "settle"; })[0];
  check(m.excluded.indexOf(1) >= 0 && s.excluded.indexOf(1) >= 0 && !m.winners.length, "fallen runs have no margin or settling time and cannot win");
  var diff = TWIN.clone(base); diff.controller.type = "pid"; diff.duration_s = 5;
  check(!CMP.isControllerSet([recs[1], run(diff)]), "a second difference means it is not a controller set");
});

/* ------------------------------------------------------------ run plots */
test("Run plots: neutral inks for series, amber limits, magenta loads, no brand lime anywhere", function () {
  var r = run(cfg("corner", { duration_s: 4, initial: { tilt_deg: 2, rate_dps: 0, azimuth_deg: 30, reference: "geometric" }, disturbances: [{ id: "F1", type: "force", magnitude_N: 0.2, point_m: [0.18, 0.18, 0.18], direction: [1, 0, 0], frame: "world", t_start_s: 1, duration_s: 0.5 }] }));
  var D = PLOTS.defs(r), all = JSON.stringify(D).toLowerCase();
  check(all.indexOf(TOK.color.brand.toLowerCase()) < 0 && all.indexOf("192,255,0") < 0, "brand lime used in a plot");
  var wheel = D.filter(function (d) { return d.id === "wheel"; })[0];
  check(wheel.series.length === 3 && new Set(wheel.series.map(function (s) { return JSON.stringify(s.dash); })).size === 3, "wheels X/Y/Z told apart by dash pattern");
  check(wheel.series.every(function (s) { return [TOK.color.ink.primary, TOK.color.ink.secondary, TOK.color.ink.tertiary].indexOf(s.color) >= 0; }), "wheel series use neutral inks");
  check(wheel.hlines.some(function (h) { return h.color.indexOf("255,176,32") >= 0; }), "speed limit drawn in amber");
  check(D[0].xbands.some(function (b) { return b.kind === "disturbance" && b.color.indexOf("224,99,167") >= 0; }), "disturbance band in load magenta");
  check(D.length === 4 && D.map(function (d) { return d.id; }).join() === "lean,wheel,torque,yaw", "corner plots " + D.map(function (d) { return d.id; }).join());
});
test("Run plots: true vs estimated tilt for non-ideal edge sensing, β̂ with its true target for COM-adaptive LQR", function () {
  var kf = run(cfg("edge", { duration_s: 3, estimator: { type: "kf" } }));
  check(PLOTS.defs(kf).some(function (d) { return d.id === "est"; }), "estimate plot for the Kalman filter");
  var id = run(cfg("edge", { duration_s: 3, estimator: { type: "ideal" } }));
  check(!PLOTS.defs(id).some(function (d) { return d.id === "est"; }), "no estimate plot for ideal sensing (θ̂ = θ)");
  var a = run(cfg("edge", { duration_s: 8, comOffset_m: 0.002, controller: { type: "adp", knowsAttachments: false, reconfigureOnFailure: true } }));
  var ad = PLOTS.defs(a).filter(function (d) { return d.id === "adapt"; })[0];
  check(!!ad, "adaptation plot for adp");
  var target = (a.derived.edge.beta - a.design.betaRef) / TWIN.DEG, last = a.samples.cols.betahat[a.samples.cols.betahat.length - 1] / TWIN.DEG;
  check(Math.abs(ad.hlines[0].y - target) < 1e-12, "target line = β − β_ref");
  check(Math.abs(last - target) < 0.25 * Math.abs(target) + 0.02, "β̂ converges toward the true offset (" + last.toFixed(3) + "° vs " + target.toFixed(3) + "°)");
  var csv = PLOTS.toCSV(a, ad);
  check(/^# AERIS AERIS-EXP-\d{6} · Adapted balance offset/.test(csv) && csv.split("\n")[1] === "t [s],β̂ [°]", csv.slice(0, 90));
});

/* ------------------------------------------------------------ timeline lanes */
test("Timeline lanes: every event type belongs to exactly one lane", function () {
  var types = Object.keys(TWIN.EVENT_DEFS), seen = {};
  TL.LANES.forEach(function (L) { L.types.forEach(function (t) { check(!seen[t], t + " in two lanes"); seen[t] = L.key; }); });
  types.forEach(function (t) { check(!!seen[t], "event type " + t + " has no lane"); });
  var r = run(cfg("edge", { duration_s: 20, comOffset_m: 0.003, controller: { type: "pid", knowsAttachments: false, reconfigureOnFailure: true } }));
  var L = TL.lanes(r.timeline), n = Object.keys(L).reduce(function (s, k) { return s + L[k].length; }, 0);
  check(n === r.timeline.events.length, "all events placed");
  check(L.actuator.some(function (o) { return o.e.type === "speed_risk"; }) && L.outcome.some(function (o) { return o.e.type === "fall"; }), "regression case: risk in actuators, fall in outcome");
});

/* ------------------------------------------------------------ setup form metadata */
test("Sensor/actuator form: fields come from the engine's spec; tiers nest; hidden settings are counted", function () {
  var f = SETUP.fields();
  Object.keys(TWIN.SENSOR_SPEC).forEach(function (k) { check(f.some(function (x) { return x.path === "sensor." + k && x.tier === TWIN.SENSOR_SPEC[k].tier; }), "field for sensor." + k); });
  check(f.some(function (x) { return x.path === "sensor.rate_hz"; }) && f.some(function (x) { return x.path === "actuator.motor_lag_ms"; }) && f.filter(function (x) { return /wheel_health/.test(x.path); }).length === 3, "rate, lag and wheel health present");
  var b = SETUP.visible("basic").length, a = SETUP.visible("advanced").length, e = SETUP.visible("expert").length;
  check(b > 0 && b < a && a < e && e === f.length, "tiers " + [b, a, e, f.length].join("/"));
  check(SETUP.effectNotes(cfg("corner")).some(function (t) { return /no effect/.test(t); }), "corner mode says sensor settings have no effect");
  check(SETUP.effectNotes(cfg("edge", { estimator: { type: "ideal" } })).some(function (t) { return /Ideal state/.test(t); }), "ideal sensing note");
  var card = SETUP.controllerCard("adp");
  check(text(card).indexOf("COM-adaptive LQR") >= 0 && /Adapts/.test(card) && /Assumes/.test(card) && /Measures/.test(card), "controller card sections");
});

/* ------------------------------------------------------------ mass asymmetry */
test("Mass asymmetry: Δr_COM from the nominal centre equals the sum of the part contributions", function () {
  var c = TWIN.normalizeConfig(cfg("corner", { comOffset_m: 0.002, comShift_m: [0.001, -0.002, 0.0005], attachments: [{ id: "m1", label: "Clip", mass_kg: 0.06, pos_m: [0.09, 0.03, 0.18] }, { id: "m2", label: "Nut", mass_kg: 0.02, pos_m: [0.18, 0.1, 0.02] }] }));
  var mp = TWIN.massProps(c), A = MASS.asymmetry(c, mp);
  [0, 1, 2].forEach(function (k) { var sum = A.parts.reduce(function (s, p) { return s + p.contrib[k]; }, 0); check(Math.abs(sum - A.dr[k]) < 1e-12, "axis " + k + ": " + sum + " vs " + A.dr[k]); });
  check(Math.abs(A.rNom[0] - c.params.a / 2) < 1e-15 && A.drNorm > 0, "nominal centre and non-zero shift");
  [A.ThC, A.ThO].forEach(function (M) { check(Math.abs(M[0][1] - M[1][0]) < 1e-15 && Math.abs(M[0][2] - M[2][0]) < 1e-15 && Math.abs(M[1][2] - M[2][1]) < 1e-15, "tensor symmetric"); });
  check(A.maxProduct > 0, "asymmetric masses give non-zero products of inertia");
  var tr = A.ThC[0][0] + A.ThC[1][1] + A.ThC[2][2], ps = A.principal[0] + A.principal[1] + A.principal[2];
  check(Math.abs(tr - ps) < 1e-12 * Math.max(1, tr), "principal moments sum to the trace");
  var bare = TWIN.normalizeConfig(cfg("edge")), B0 = MASS.asymmetry(bare, TWIN.massProps(bare));
  check(B0.drNorm < 1e-15 && B0.maxProduct < 1e-15, "the bare cube has no shift and a diagonal tensor about its COM");
  check(/Δr/.test(MASS.render(c, mp)) && /10⁻³ kg·m²/.test(MASS.render(c, mp)), "panel shows Δr and tensor units");
});

/* ------------------------------------------------------------ sim ↔ hardware validation */
function fakeHardwareFrom(rec, shift, gain) {
  /* TEST FIXTURE ONLY: a synthetic "hardware" file made from a simulation, to check the metric maths.
     It is never shown on the site and is not a measurement. */
  var S = rec.samples.cols;
  return { schema: "aeris-hardware-run/1", device: { id: "test-fixture", firmware: "n/a" }, recording: { started: "2026-01-01T00:00:00Z" }, mode: rec.config.mode, parameters: { parameter_set: "test" },
    samples: { cols: { t: S.t.map(function (t) { return t + shift; }), theta: S.theta.map(function (v) { return v * 180 / Math.PI * (gain || 1); }), wheel_rpm_x: S.omega_x.map(function (v) { return v * 30 / Math.PI; }) }, units: { t: "s", theta: "deg", wheel_rpm_x: "rpm" } } };
}
test("Validation metrics: identical data gives zero error; a time shift is found; units are converted", function () {
  var r = run(cfg("edge", { duration_s: 4, initial: { tilt_deg: 2, rate_dps: 0, azimuth_deg: 0, reference: "geometric" } }));
  var same = VAL.compare(r, fakeHardwareFrom(r, 0));
  check(same.ok && same.signals.length === 2, JSON.stringify(same.errors));
  same.signals.forEach(function (s) { check(s.rmse < 1e-9 && s.peakErr < 1e-9 && s.lag_s === 0, s.key + " rmse " + s.rmse); });
  var sh = VAL.compare(r, fakeHardwareFrom(r, 0.05), { maxLag_s: 0.2 }), th = sh.signals.filter(function (s) { return s.key === "theta"; })[0];
  check(th && Math.abs(th.lag_s - 0.05) < 0.011 && th.rmseAfterLag < th.rmse, "lag " + (th && th.lag_s));
  var g = VAL.compare(r, fakeHardwareFrom(r, 0, 1.1)), tg = g.signals.filter(function (s) { return s.key === "theta"; })[0];
  check(tg.rmse > 0.01 && tg.peakDiff > 0, "a 10 % gain error shows up in degrees");
});
test("Validation: missing or mismatched hardware data is refused, never compared", function () {
  var r = run(cfg("edge", { duration_s: 2 }));
  check(!VAL.compare(r, null).ok, "no file");
  var hw = fakeHardwareFrom(r, 0); hw.mode = "corner";
  check(!VAL.compare(r, hw).ok, "mode mismatch");
  var hw2 = fakeHardwareFrom(r, 100);
  check(!VAL.compare(r, hw2).ok && /overlap/.test(VAL.compare(r, hw2).errors.join(" ")), "no time overlap");
  var hw3 = fakeHardwareFrom(r, 0); hw3.samples.units.theta = "furlongs";
  var c3 = VAL.compare(r, hw3);
  check(c3.warnings.some(function (w) { return /not supported/.test(w); }) && !c3.signals.some(function (s) { return s.key === "theta"; }), "unknown units are reported and skipped");
});

var pass = results.filter(function (r) { return r.ok; }).length;
results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
console.log("\n" + pass + " / " + results.length + " UI data tests passed");
process.exit(pass === results.length ? 0 : 1);

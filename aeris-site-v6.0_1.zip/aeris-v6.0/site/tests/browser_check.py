"""Browser checks for the AERIS site (Playwright + Chromium).

Run:   python3 tests/browser_check.py            (uses file://…/index.html)
       python3 tests/browser_check.py --shots    (also writes screenshots to tests/screenshots/)

These are behaviour and layout checks in a real browser. The numerical checks of
the physics live separately in tests/numerics.test.js and tests/runs.test.js.
"""
import asyncio, json, os, sys, pathlib
from playwright.async_api import async_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
URL = (ROOT / "index.html").as_uri()
SHOTS = "--shots" in sys.argv
SHOT_DIR = ROOT / "tests" / "screenshots"
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
results = []

def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else "  →  " + str(detail)))

async def shot(page, name):
    if SHOTS:
        SHOT_DIR.mkdir(parents=True, exist_ok=True)
        await page.screenshot(path=str(SHOT_DIR / (name + ".png")))

async def new_page(browser, w=1440, h=900, scale=1):
    ctx = await browser.new_context(viewport={"width": w, "height": h}, device_scale_factor=scale)
    page = await ctx.new_page()
    page.errors = []
    page.on("console", lambda m: page.errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: page.errors.append("PAGEERROR " + str(e)))
    return ctx, page

async def snap(page):
    return await page.evaluate("AERIS_DEBUG.snapshot()")

async def wait_for(page, js, timeout=20000, step=100):
    """Bounded wait for a condition in the page (the check fails if it is not reached in time)."""
    t = 0
    while t < timeout:
        if await page.evaluate(js):
            return True
        await page.wait_for_timeout(step); t += step
    return False

async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch(args=ARGS)
        ctx, page = await new_page(br)
        await page.goto(URL, wait_until="load"); await page.wait_for_timeout(2500)
        await page.add_style_tag(content="html{scroll-behavior:auto!important}")
        # ---------------- honesty / content checks ----------------
        html = await page.content()
        check("No placeholder 'YourUsername' links anywhere", "YourUsername" not in html)
        repo = await page.evaluate("[...document.querySelectorAll('[data-repo]')].map(e=>e.textContent.trim())")
        check("Repository marked forthcoming (no real URL supplied)", all("forthcoming" in r.lower() for r in repo) and len(repo) >= 2, repo)
        labels = await page.evaluate("({hero:document.querySelector('.hero-tag').textContent, poster:document.querySelector('#posterFig .cap').textContent, foot:document.querySelector('.foot-base').textContent})")
        check("Generated visuals are labelled as generated", "AI-generated" in labels["hero"] and "AI-generated" in labels["poster"] and "AI-generated" in labels["foot"], labels)
        bench = await page.evaluate("document.getElementById('benchSrc').textContent")
        check("Benchmark keeps its provenance, says traces are pending and is labelled UNVERIFIED HISTORICAL", "earlier" in bench.lower() and "pending import" in bench.lower() and "not produced by this site" in bench.lower() and "UNVERIFIED HISTORICAL" in bench and "not a finding" in bench, bench)
        btxt = await page.evaluate("document.getElementById('benchBody').textContent")
        check("Benchmark values preserved (6.21 / 3.02 / 1.85 s)", all(v in btxt for v in ["6.21", "3.02", "1.85", "24.6", "18.7", "15.3"]), btxt)
        spec = await page.evaluate("document.getElementById('hwSpecs').textContent")
        check("Hardware measurements shown as pending, not invented", spec.count("Pending measurement") == 9, spec[:200])
        await page.wait_for_timeout(600)
        tel = await page.evaluate("document.getElementById('tS').textContent")
        check("Hero telemetry replays an example recording", tel.strip() not in ("", "—"), tel)
        vid = await page.evaluate("""async () => { const v = document.getElementById('heroVid'), tg = document.getElementById('vidToggle');
            for (let i = 0; i < 40 && !(v.readyState >= 2 && v.currentTime > 0); i++) await new Promise(r => setTimeout(r, 100));
            const r = { src: v.currentSrc.split('/').pop(), ready: v.readyState, err: v.error && v.error.code, t: v.currentTime, playing: !v.paused };
            tg.click(); await new Promise(r => setTimeout(r, 150)); r.pausedByToggle = v.paused;
            tg.click(); await new Promise(r => setTimeout(r, 300)); r.resumed = !v.paused; return r; }""")
        check("Assembly video loads, plays and the toggle pauses/resumes it", vid["src"].startswith("aeris-assembly.") and vid["err"] is None and vid["ready"] >= 2 and vid["t"] > 0 and vid["pausedByToggle"] and vid["resumed"], vid)
        await shot(page, "01-home-desktop")
        check("Home loads without script errors", not page.errors, page.errors[:3])

        # ---------------- AERIS Lab: regression example ----------------
        await page.click("a.use-link"); await page.wait_for_timeout(800)
        check("'AERIS Lab' is in the primary navigation and opens the workspace", await page.evaluate("!document.getElementById('view-lab').hidden"))
        await page.click("#lt-rec"); await page.click('[data-ex="example-regression"]')
        await wait_for(page, "!!(AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === 'example-regression' && document.querySelector('#ocCard .oc-l') && document.querySelector('.rec.on .oc-badge'))")
        s = await snap(page)
        oc = await page.evaluate("document.querySelector('#ocCard .oc-l').textContent")
        badge = await page.evaluate("document.querySelector('.rec.on .oc-badge').textContent")
        settle = await page.evaluate("[...document.querySelectorAll('.mt tr')].find(r=>r.textContent.includes('Settling time')).querySelector('td').textContent")
        check("Regression case (PID, COM +3 mm, 4 s) reported as Drifting everywhere", s["outcome"] == "drifting" and oc == "Drifting" and badge.lower() == "drifting", (s["outcome"], oc, badge))
        check("Regression case: settling time is 'not settled', not the 4 s end time", "not settled" in settle, settle)
        await shot(page, "02-regression")
        # ---------------- sync of 3-D, telemetry, plots and maths ----------------
        await page.click("#rt-math"); await page.wait_for_timeout(300)
        ok_all, bad = True, []
        for i in [0, 37, 120, 199, 200]:
            await page.evaluate(f"AERIS_DEBUG.setIndex({i})"); await page.wait_for_timeout(120)
            s = await snap(page)
            t = s["t"]
            cond = s["viewer"]["idx"] == s["idx"] == s["scrub"] and s["viewer"]["runId"] == s["runId"] and abs(float(s["teleT"]) - t) < 1e-9 and s["mathsT"] == "t = %.3f s" % t and s["mathsRun"] == s["runId"]
            if not cond: ok_all = False; bad.append(s)
        check("3-D view, telemetry, scrubber and maths show the same run and sample", ok_all, bad[:1])
        cur = await page.evaluate("(()=>{const r=AERIS_DEBUG.W.run, i=AERIS_DEBUG.W.idx; return {pv: document.getElementById('pv-lean').textContent, e: r.samples.cols.e[i]*180/Math.PI}})()")
        check("Plot cursor readout matches the sample value", ("%.2f" % cur["e"]).replace("-", "−") in cur["pv"] or ("%.4f" % cur["e"]).replace("-", "−") in cur["pv"], cur)
        await shot(page, "03-maths")
        # plot click seeks
        box = await page.evaluate("(()=>{const r=document.getElementById('pk-wheel').getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()")
        await page.evaluate("document.getElementById('pk-wheel').scrollIntoView({block:'center'})"); await page.wait_for_timeout(200)
        box = await page.evaluate("(()=>{const r=document.getElementById('pk-wheel').getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()")
        await page.mouse.click(box["x"] + box["w"] * 0.55, box["y"] + box["h"] * 0.5); await page.wait_for_timeout(150)
        s = await snap(page)
        check("Clicking a plot moves playback to that time", 1.5 < s["t"] < 3.0 and s["viewer"]["idx"] == s["idx"], s["t"])
        # playback
        # bounded wait on the actual condition (playback reached t > 0.2 s) instead of a fixed pause: how fast frames
        # arrive depends on the machine (software WebGL here), not on the behaviour under test
        await page.evaluate("AERIS_DEBUG.setIndex(0)"); await page.click("#pbPlay")
        await wait_for(page, "AERIS_DEBUG.snapshot().t > 0.2", 15000)
        s1 = await snap(page); await page.click("#pbPlay"); s2 = await snap(page)
        await page.wait_for_timeout(400); s3 = await snap(page)          # after Pause the time must not move
        check("Play advances time and Pause stops it", s1["playing"] and s1["t"] > 0.2 and not s2["playing"] and s3["t"] == s2["t"] and not s3["playing"],
              (s1["t"], s1["playing"], s2["playing"], s2["t"], s3["t"]))
        async def advance(speed):
            await page.select_option("#pbSpeed", speed); await page.evaluate("AERIS_DEBUG.setIndex(0)")
            await page.evaluate("AERIS_DEBUG.advanceBy(0.2)"); return (await snap(page))["t"]
        t1, t4 = await advance("1"), await advance("4")
        check("Speed control: 0.2 s of wall time moves playback 0.2 s at 1× and 0.8 s at 4×", abs(t1 - 0.2) < 0.021 and abs(t4 - 0.8) < 0.021, (t1, t4))
        await page.select_option("#pbSpeed", "1")

        # ---------------- every example: clean numbers in all panels ----------------
        exids = await page.evaluate("Workspace.EXAMPLES.map(e=>e.id)")
        bad_ex = []
        for ex in exids:
            await page.evaluate(f"Workspace.openExample('{ex}')")
            await wait_for(page, f"!!(AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === '{ex}' && AERIS_DEBUG.snapshot().plots > 0)")
            await page.evaluate("AERIS_DEBUG.setIndex(Math.floor(AERIS_DEBUG.W.run.samples.cols.t.length*0.6))")
            await page.click("#rt-math"); await page.wait_for_timeout(250)
            txt = await page.evaluate("['rp-res','rp-math','tele','plots'].map(id=>document.getElementById(id).textContent).join(' ') + ' ' + [...document.querySelectorAll('#rp-res .oc-l')].map(e=>e.textContent).join(' ')")
            kerr = await page.evaluate("document.querySelectorAll('#rp-math .katex-error, #rp-math .tex-err').length")
            if kerr: bad_ex.append((ex, "katex errors: %d" % kerr))
            await page.click("#rt-res")
            s = await snap(page)
            if any(w in txt for w in ["NaN", "undefined", "Infinity", "null"]) or s["viewer"]["idx"] != s["idx"]: bad_ex.append((ex, [w for w in ["NaN", "undefined", "Infinity", "null"] if w in txt]))
        check("All examples (edge and corner) render results, maths, telemetry and plots without NaN/undefined", not bad_ex, bad_ex)
        await page.evaluate("Workspace.openExample('example-corner-failure')")
        await wait_for(page, "!!(AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === 'example-corner-failure' && AERIS_DEBUG.snapshot().plots === 4)")
        cf = await page.evaluate("({oc: AERIS_DEBUG.W.run.outcome.code, notes: AERIS_DEBUG.W.run.outcome.notes.join(' '), plots: AERIS_DEBUG.snapshot().plots, mode: AERIS_DEBUG.snapshot().viewer.mode})")
        check("Corner wheel-failure example: recovered, yaw caveat noted, four plots, corner 3-D pose", cf["oc"] == "recovered" and "Yaw is not controlled" in cf["notes"] and cf["plots"] == 4 and cf["mode"] == "corner", cf)
        await shot(page, "02b-corner-failure")
        await page.evaluate("Workspace.openExample('example-regression')")
        await wait_for(page, "!!(AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === 'example-regression')")

        # ---------------- invalid configuration ----------------
        await page.click("#lt-create"); await page.wait_for_timeout(200)
        n_before = await page.evaluate("AERIS_RUNS.list().length")
        await page.evaluate("document.querySelector('#setupForm details.sub').open=true")
        for path, val in [("params.a", "80"), ("params.m", "0.3"), ("params.kJ", "0.1"), ("params.Jw", "0.005")]:
            await page.fill(f'[data-path="{path}"]', val)
        await page.wait_for_timeout(400)
        vb = await page.evaluate("document.getElementById('valBox').textContent")
        dis = await page.evaluate("document.getElementById('btnRun').getAttribute('aria-disabled')")
        check("Invalid combination is flagged before running, with plain explanations", "Invalid configuration" in vb and "negative" in vb and dis == "true", vb[:160])
        await page.click("#btnRun", force=True); await page.wait_for_timeout(300)
        res = await page.evaluate("document.getElementById('rp-res').textContent")
        s = await snap(page)
        n_after = await page.evaluate("AERIS_RUNS.list().length")
        check("Running it shows 'Invalid configuration', creates no recording and clears the replay", "Invalid configuration" in res and n_after == n_before and s["runId"] is None and s["plots"] == 0, (res[:120], n_before, n_after, s["runId"]))
        await shot(page, "04-invalid")
        await page.click("#btnResetSetup"); await page.wait_for_timeout(300)

        # ---------------- masses and forces ----------------
        m0 = await page.evaluate("AERIS_TWIN.validateConfig(AERIS_DEBUG.W.draft).mp.M")
        await page.click("#btnPlaceMass"); await page.wait_for_timeout(300)
        st = await page.evaluate("(()=>{const r=document.getElementById('vwStage').getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()")
        placed = False
        for fx, fy in [(0.5, 0.52), (0.5, 0.6), (0.45, 0.55), (0.55, 0.45)]:
            await page.mouse.click(st["x"] + st["w"] * fx, st["y"] + st["h"] * fy); await page.wait_for_timeout(250)
            if await page.evaluate("AERIS_DEBUG.W.draft.attachments.length") > 0: placed = True; break
        att = await page.evaluate("AERIS_DEBUG.W.draft.attachments")
        m1 = await page.evaluate("AERIS_TWIN.validateConfig(AERIS_DEBUG.W.draft).mp.M")
        a = 0.18
        onSurface = placed and all(-1e-6 <= v <= a + 1e-6 for v in att[0]["pos_m"]) and any(abs(v) < 1e-3 or abs(v - a) < 1e-3 for v in att[0]["pos_m"])
        check("Clicking the 3-D cube places a mass on its surface (body coordinates)", onSurface, att)
        check("Added mass changes the combined mass properties", abs(m1 - m0 - 0.05) < 1e-9, (m0, m1))
        await shot(page, "05-mass-placed")
        await page.click("#btnAddForce"); await page.wait_for_timeout(300)
        await page.fill('[data-path="disturbances.0.magnitude_N"]', "0.4"); await page.fill('[data-path="disturbances.0.t_start_s"]', "1"); await page.fill('[data-path="disturbances.0.duration_s"]', "1.5")
        await page.fill('[data-path="duration_s"]', "5"); await page.wait_for_timeout(300)
        prev = await page.evaluate("AERIS_DEBUG.W.run ? AERIS_DEBUG.W.run.id : null")
        await page.click("#btnRun")
        await wait_for(page, "!!(AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id !== %s && !AERIS_DEBUG.W.busy)" % json.dumps(prev))
        info = await page.evaluate("(()=>{const r=AERIS_DEBUG.W.run, S=r.samples.cols; const i=S.t.findIndex(t=>t>=1.5); return {att:r.config.attachments.length, M:r.derived.M, tauF:S.tauF[i], tauF0:S.tauF[5], name:r.name, loads:r.config.disturbances.length}})()")
        check("The run stores the added mass and force in its configuration", info["att"] == 1 and info["loads"] == 1 and abs(info["M"] - m1) < 1e-9, info)
        check("The force acts during its window and not before", abs(info["tauF"]) > 1e-3 and abs(info["tauF0"]) < 1e-12, info)
        await page.evaluate("AERIS_DEBUG.setIndex(AERIS_DEBUG.W.run.samples.cols.t.findIndex(t=>t>=1.6))"); await page.wait_for_timeout(200)
        s = await snap(page)
        check("3-D view shows the active force at that time", s["viewer"]["loads"] == 1 and s["viewer"]["attachments"] == 1, s["viewer"])
        await shot(page, "06-mass-force-run")
        runB = await page.evaluate("AERIS_DEBUG.W.run.id")

        # ---------------- old-run independence ----------------
        regA = await page.evaluate("JSON.stringify(AERIS_RUNS.load('example-regression').record.metrics)")
        await page.click("#lt-rec"); await page.wait_for_timeout(200)
        await page.click('.rec-open[data-id="example-regression"]')
        await wait_for(page, "!!(AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === 'example-regression')")
        reA = await page.evaluate("JSON.stringify(AERIS_DEBUG.W.run.metrics)")
        cfgA = await page.evaluate("({att: AERIS_DEBUG.W.run.config.attachments.length, M: AERIS_DEBUG.W.run.derived.M, draftAtt: AERIS_DEBUG.W.draft.attachments.length})")
        check("Reopening an old run uses its own saved setup, not the current draft", regA == reA and cfgA["att"] == 0 and abs(cfgA["M"] - 1.8) < 1e-12 and cfgA["draftAtt"] == 1, cfgA)

        # ---------------- compare ----------------
        await page.check('[data-cmp="example-regression"]'); await page.check(f'[data-cmp="{runB}"]')
        await page.click("#rt-cmp"); await page.wait_for_timeout(500)
        cmpt = await page.evaluate("document.getElementById('rp-cmp').textContent")
        check("Compare lists differing conditions and avoids declaring a winner", "Conditions that differ" in cmpt and "not show that one controller is better" in cmpt and "Attached masses" in cmpt, cmpt[:200])
        await shot(page, "07-compare")
        await page.click("#rt-ask"); await page.click('[data-q="diffRuns"]'); await page.wait_for_timeout(300)
        ans = await page.evaluate("document.getElementById('asOut').textContent")
        badge = await page.evaluate("document.querySelector('.as-badge').textContent")
        check("Assistant is labelled local, uses only run data and lists what it used", "no AI service connected" in badge and "Data used" in ans and "Source: local rules" in ans, (badge, ans[:120]))

        # ---------------- export / import round trip ----------------
        await page.click("#rt-res"); await page.click('.acts2 [data-a="json"]'); await page.wait_for_timeout(300)
        exported = await page.evaluate("document.querySelector('.ws-ta').value")
        await page.keyboard.press("Escape")
        check("Export shows the run JSON (download plus copy fallback)", '"schema": "aeris-run/1"' in exported, exported[:80])
        await page.evaluate("window.AERIS_ENV = { downloads: false }")
        await page.click('.acts2 [data-a="json"]'); await page.wait_for_timeout(300)
        nodl = await page.evaluate("({btns:[...document.querySelectorAll('.ws-modal-acts button')].map(b=>b.textContent), p:document.querySelector('.ws-modal-p').textContent, same:document.querySelector('.ws-ta').value.length})")
        await page.keyboard.press("Escape"); await page.evaluate("delete window.AERIS_ENV")
        check("Hosts that block downloads get Copy only, with no dead Download button", not any(b.startswith("Download") for b in nodl["btns"]) and "Copy text" in nodl["btns"] and "can't start downloads" in nodl["p"] and nodl["same"] == len(exported), nodl)
        hs = await page.evaluate("""async () => {
            const calls = [], out = {}; let answer = 'accept';
            window.AERIS_ENV = { save: (name, text) => { calls.push([name, text.length]); return answer === 'accept' ? Promise.resolve({ status: 'saved' }) : Promise.reject({ code: answer, message: answer }); } };
            const run = async () => { document.querySelector('.acts2 [data-a="json"]').click(); await new Promise(r => setTimeout(r, 200));
                const b = [...document.querySelectorAll('.ws-modal-acts button')].find(x => x.textContent.startsWith('Download')); b.click();
                await new Promise(r => setTimeout(r, 200)); const t = b.textContent; document.querySelector('.ws-modal-acts button:last-child').click(); return t; };
            out.accepted = await run(); answer = 'declined'; out.declined = await run(); answer = 'unavailable'; out.unavailable = await run();
            document.querySelector('.acts2 [data-a="json"]').click(); await new Promise(r => setTimeout(r, 200));
            out.after = [...document.querySelectorAll('.ws-modal-acts button')].map(x => x.textContent); document.querySelector('.ws-modal-acts button:last-child').click();
            delete window.AERIS_ENV; out.calls = calls; return out; }""")
        check("Host save prompt: accepted, declined and unavailable are reported, and an unavailable host falls back to Copy only", hs["accepted"] == "Download started" and hs["declined"] == "Not saved" and "copy instead" in hs["unavailable"] and not any(b.startswith("Download") for b in hs["after"]) and len(hs["calls"]) == 3 and hs["calls"][0][1] == len(exported), hs)
        await page.click('.acts2 [data-a="csv"]'); await page.wait_for_timeout(200)
        csv = await page.evaluate("document.querySelector('.ws-ta').value"); await page.keyboard.press("Escape")
        check("CSV export has metadata comments and unit-labelled columns", csv.startswith("# AERIS run export") and "t [s]" in csv, csv[:80])
        before = await page.evaluate("JSON.stringify(AERIS_RUNS.load('example-regression').record.samples)")
        await page.click("#lt-rec"); await page.click("#btnClearAll"); await page.wait_for_timeout(200)
        await page.click(".ws-modal .btn-solid"); await page.wait_for_timeout(400)
        s = await snap(page)
        st = await page.evaluate("({n: AERIS_RUNS.list().length, tele: document.getElementById('tele').textContent, plots: document.getElementById('plots').children.length, play: document.getElementById('pbPlay').disabled, res: document.getElementById('rp-res').textContent.slice(0,60), mode: AERIS_DEBUG.W.viewMode})")
        check("Delete all clears recordings, replay, plots, telemetry, playback and outcome", st["n"] == 0 and st["plots"] == 0 and st["play"] and s["runId"] is None and "No run selected" in st["res"] and st["mode"] == "setup" and "deleted" in st["tele"], st)
        await shot(page, "08-cleared")
        await page.click("#btnImport"); await page.wait_for_timeout(200)
        # set the pasted text directly: Playwright's fill() types large JSON too slowly under software rendering
        await page.evaluate("t => { const ta = document.querySelector('.ws-modal .ws-ta'); ta.value = t; ta.dispatchEvent(new Event('input', {bubbles: true})); }", exported)
        await page.click(".ws-modal .btn-solid")
        await wait_for(page, "!!(document.querySelector('.imp-out') && document.querySelector('.imp-out').textContent.trim())")
        imp = await page.evaluate("document.querySelector('.imp-out').textContent"); await page.keyboard.press("Escape")
        after = await page.evaluate("JSON.stringify(AERIS_RUNS.load('example-regression').record.samples)")
        check("Import restores the exported run with identical samples", "Imported 1 run" in imp and before == after, imp)
        await page.click("#btnImport"); await page.fill(".ws-modal .ws-ta", '{"schema":"aeris-run/1","id":"x","config":{"mode":"edge","params":{"Jw":0.5}},"outcome":{"code":"recovered"}}'); await page.click(".ws-modal .btn-solid"); await page.wait_for_timeout(300)
        bad = await page.evaluate("document.querySelector('.imp-out').textContent"); await page.keyboard.press("Escape")
        check("Import rejects a physically invalid file with a helpful message", "Not imported" in bad and "Jw" in bad, bad[:160])

        # ---------------- persistence after reload ----------------
        await page.click('.rec-open[data-id="example-regression"]'); await page.wait_for_timeout(300)
        await page.evaluate("AERIS_DEBUG.setIndex(77)"); await page.wait_for_timeout(100)
        await page.reload(wait_until="load")
        await wait_for(page, "!!(window.AERIS_DEBUG && AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === 'example-regression')")
        s = await snap(page)
        n = await page.evaluate("AERIS_RUNS.list().length")
        check("Recordings and the open run survive a page reload", n >= 1 and s["runId"] == "example-regression" and s["idx"] == 77, (n, s["runId"], s["idx"]))
        check("Workspace loads without script errors", not page.errors, page.errors[:3])

        # ---------------- keyboard ----------------
        await page.focus("#rt-res"); await page.keyboard.press("ArrowRight"); sel = await page.evaluate("document.activeElement.id")
        check("Tabs work with the arrow keys", sel == "rt-math" and await page.evaluate("!document.getElementById('rp-math').hidden"), sel)
        await page.focus("#pbScrub"); await page.keyboard.press("ArrowRight"); s = await snap(page)
        check("The playback slider responds to the keyboard", s["idx"] == 78, s["idx"])
        await page.focus("#vwStage"); await page.keyboard.press("Space"); await page.wait_for_timeout(400); s = await snap(page); await page.keyboard.press("Space")
        check("Space toggles playback from the 3-D view", s["playing"] or s["t"] > 1.6, s)
        await ctx.close()

        # ---------------- AERIS Twin (the former Lab page: derivations and reference experiments) ----------------
        ctx, page = await new_page(br)
        await page.goto(URL + "#twin", wait_until="load")
        await wait_for(page, "(document.getElementById('e1t') || {}).textContent && /Recovered|Fallen|Drifting/.test(document.getElementById('e1t').textContent)", 30000)
        rows = await page.evaluate("document.getElementById('e1t').textContent")
        check("Twin reference experiments use the shared outcome labels", "Recovered" in rows and "RECOVERED" not in rows, rows[:120])
        check("Twin page has no separate runner (points to AERIS Lab)", await page.evaluate("!document.getElementById('twin-runner') && !!document.getElementById('twin-use')"))
        await page.fill("#p_Jw", "0.0049"); await page.wait_for_timeout(900)
        pv = await page.evaluate("document.getElementById('pValid').textContent")
        check("Twin page rejects inconsistent parameters instead of recomputing", "not physically consistent" in pv, pv[:120])
        await page.click("#pReset"); await page.wait_for_timeout(1500)
        await page.evaluate("document.getElementById('exp2').scrollIntoView()"); await page.wait_for_timeout(300)
        # v5: a bounded wait for the actual completion condition (a NEW run of exactly this setup is open in the Lab)
        # instead of a fixed pause: the Lab opens, runs the setup and shows it asynchronously
        key = await page.evaluate("document.querySelector('[data-ws=\"e2\"] [data-wscfg$=\":3\"]').getAttribute('data-wscfg')")
        before = await page.evaluate("window.AERIS_DEBUG && AERIS_DEBUG.W.run ? AERIS_DEBUG.W.run.id : null")
        await page.click('[data-ws="e2"] [data-wscfg$=":3"]')
        done = await wait_for(page, "(() => { const W = window.AERIS_DEBUG && AERIS_DEBUG.W; return !!(W && W.run && W.run.id !== %s && !W.busy && !document.getElementById('view-lab').hidden); })()" % json.dumps(before), 20000)
        same = await page.evaluate("(() => { const want = AERIS_CFG.normalize(TwinPage.workspaceConfig(%s)), got = AERIS_CFG.normalize(AERIS_DEBUG.W.run.config); return JSON.stringify(want) === JSON.stringify(got); })()" % json.dumps(key))
        s = await snap(page)
        check("'Open in AERIS Lab' from the Twin page runs that exact setup", done and same and s["outcome"] == "drifting" and s["fresh"], (done, same, s["outcome"], s.get("fresh")))
        check("Twin page loads without script errors", not page.errors, page.errors[:3])
        await page.goto(URL + "#twin", wait_until="load"); await page.wait_for_timeout(3500)
        kl = await page.evaluate("document.querySelectorAll('#view-twin .katex-error, #view-twin .tex-err').length")
        kh = await page.evaluate("document.querySelectorAll('#view-home .katex-error, #view-home .tex-err').length")
        check("All Twin and home equations render (no KaTeX errors)", kl == 0 and kh == 0, (kl, kh))
        await ctx.close()

        # ---------------- narrow screens ----------------
        ctx, page = await new_page(br, 390, 844, 2)
        overflow = {}
        for h in ["", "#lab", "#twin"]:
            await page.goto(URL + h, wait_until="load"); await page.wait_for_timeout(1500)
            if h == "#lab":
                for tab in ["mt-left", "mt-center", "mt-right"]:
                    await page.click("#" + tab); await page.wait_for_timeout(300)
                    overflow[h + ":" + tab] = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
                    await shot(page, "10-mobile-" + tab)
            else:
                overflow[h or "home"] = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
                await shot(page, "09-mobile-" + (h[1:] or "home"))
        check("No horizontal scrolling at 390 px (home, AERIS Lab panels, Twin)", all(v <= 0 for v in overflow.values()), overflow)
        await page.goto(URL + "#lab", wait_until="load"); await page.wait_for_timeout(800)
        vis = await page.evaluate("(()=>{const v=id=>getComputedStyle(document.getElementById(id)).display!=='none'; return [v('wsLeft'),v('wsCenter'),v('wsRight')]})()")
        await page.click("#mt-right"); await page.wait_for_timeout(200)
        vis2 = await page.evaluate("(()=>{const v=id=>getComputedStyle(document.getElementById(id)).display!=='none'; return [v('wsLeft'),v('wsCenter'),v('wsRight')]})()")
        check("Small screens show one workspace panel at a time via tabs", vis.count(True) == 1 and vis2 == [False, False, True], (vis, vis2))
        check("AERIS Lab stays visible in the nav on a phone", await page.evaluate("getComputedStyle(document.querySelector('.nav-links .use-link')).display !== 'none'"))
        await ctx.close()
        await br.close()
    passed = sum(1 for r in results if r[1])
    print(f"\n{passed} / {len(results)} browser checks passed")
    sys.exit(0 if passed == len(results) else 1)

asyncio.run(main())

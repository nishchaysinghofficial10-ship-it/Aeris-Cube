"""Browser checks for the AERIS v3 research-platform features (Playwright + Chromium).

Run:   python3 tests/browser_v3.py            (file://…/index.html)
       python3 tests/browser_v3.py --shots    (also writes screenshots to tests/screenshots/)

Covers: branding and routes, the system status strip, system modes (no fake hardware),
source badges, the event timeline, saturation gauges, controller sets and computed
labels, sensor tiers, mass asymmetry, research sweeps (run, cancel, export), the
Cube / Research / Results / Validation pages, mobile layout and basic accessibility.
The v2 behaviour checks remain in tests/browser_check.py.
"""
import asyncio, json, sys, pathlib
from playwright.async_api import async_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
URL = (ROOT / "index.html").as_uri()
SHOTS = "--shots" in sys.argv
SHOT_DIR = ROOT / "tests" / "screenshots"
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
results = []

def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else "  →  " + str(detail)[:400]))

async def shot(page, name):
    if SHOTS:
        SHOT_DIR.mkdir(parents=True, exist_ok=True)
        await page.screenshot(path=str(SHOT_DIR / (name + ".png")))

async def new_page(browser, w=1440, h=900, scale=1):
    ctx = await browser.new_context(viewport={"width": w, "height": h}, device_scale_factor=scale)
    page = await ctx.new_page()
    page.errors = []
    page.on("console", lambda m: page.errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: page.errors.append("PAGEERROR " + str(e)))
    return ctx, page

async def status(page):
    return await page.evaluate("Object.fromEntries(AERIS_STATUS.snapshot().map(x => [x.key, x.value]))")

async def wait_for(page, js, timeout=30000, step=250):
    t = 0
    while t < timeout:
        if await page.evaluate(js): return True
        await page.wait_for_timeout(step); t += step
    return False

# The COM-shift preview's state as the page shows it (v5.1, F5): the input, the draft, the validated draft, the
# mass-asymmetry label and the 3-D view's COM shift vector [mm] (null when the COM is the nominal one)
COM_STATE = """(() => { const W = AERIS_DEBUG.W, v = W.viewer && W.viewer.snapshot(), el = document.querySelector('[data-path="comShift_m.1"]');
  return { input: el ? el.value : null, draft: W.draft.comShift_m, validated: W.draftVal && W.draftVal.config.comShift_m,
           label: (document.getElementById('asymCnt') || {}).textContent || '', com: v && v.comShift, viewMode: W.viewMode, viewRun: v && v.runId }; })()"""


def com_agree(mm):
    return ("(() => { const s = %s; const want = %r; if (!s.com || !s.draft || !s.validated) return false;"
            " return Number(s.input) === want && Math.abs(s.draft[1] - want / 1000) < 1e-12 && Math.abs(s.validated[1] - want / 1000) < 1e-12"
            " && s.draft[0] === 0 && s.draft[2] === 0 && s.label === '|\\u0394r| ' + want.toFixed(2) + ' mm' && Math.abs(s.com.dr_mm[1] - want) < 1e-6"
            " && Math.abs(s.com.dr_mm[0]) < 1e-6 && Math.abs(s.com.dr_mm[2]) < 1e-6 && s.viewMode === 'setup'; })()") % (COM_STATE, float(mm))


# in replay: the view shows the run (its id) and the run's own COM shift (from its derived centre of mass); the draft keeps 5 mm
RUN_COM = """(() => { const W = AERIS_DEBUG.W, v = W.viewer.snapshot(); if (W.viewMode !== 'replay' || !W.run || v.runId !== W.run.id) return false;
  const a = W.run.config.params.a, want = W.run.derived.rc.map(x => (x - a / 2) * 1000), n = Math.hypot(want[0], want[1], want[2]);
  const got = v.comShift && v.comShift.dr_mm, draftOk = Math.abs(W.draft.comShift_m[1] - 0.005) < 1e-12;
  return draftOk && (n < 0.05 ? got === null : !!got && got.every((g, i) => Math.abs(g - want[i]) < 1e-6)); })()"""
COM_ZERO = """(() => { const s = %s; return Number(s.input) === 0 && s.draft[1] === 0 && s.validated && s.validated[1] === 0 && s.label === '|\\u0394r| 0.00 mm'
  && s.com === null && s.viewMode === 'setup'; })()""" % COM_STATE


async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch(args=ARGS)
        ctx, page = await new_page(br)
        await page.goto(URL, wait_until="load"); await page.wait_for_timeout(2000)
        await page.add_style_tag(content="html{scroll-behavior:auto!important}")

        # ---------------- branding, routes, story ----------------
        nav = await page.evaluate("[...document.querySelectorAll('.nav-links a')].map(a => a.textContent.trim())")
        # v6.0: the optional Build and Connect journeys follow the six v3 entries (narrow update of this check)
        check("Navigation: Cube · Twin · Lab · Research · Results · Validation (v6.0: then Build · Connect)", nav == ["Cube", "Twin", "Lab", "Research", "Results", "Validation", "Build", "Connect"], nav)
        txt = await page.evaluate("document.body.innerText")
        html = await page.content()
        check("No ARC branding or ARC-EXP ids anywhere", "ARC-EXP" not in html and " ARC " not in (" " + txt + " ") and "ARC Attitude" not in html, [w for w in ["ARC-EXP", "ARC Attitude"] if w in html])
        stab = await page.evaluate("[...document.querySelectorAll('body *')].filter(e => e.children.length === 0 && /STABLIX/i.test(e.textContent)).map(e => e.closest('footer, .overlay, #twin-refs') ? 'ok' : e.textContent.trim().slice(0, 60))")
        check("STABLIX appears only as the umbrella (footer, menu footer, reference list)", all(s == "ok" for s in stab), stab)
        quotes = await page.evaluate("[...document.querySelectorAll('#storyList .story-q p')].map(e => e.textContent)")
        want = ["“I learned feedback control.”", "“I extended the concept into a three-axis physical system.”", "“I reconstructed the cube's dynamics computationally.”", "“I turned the digital model into an experimental attitude-control research platform.”"]
        titles = await page.evaluate("[...document.querySelectorAll('#storyList h3')].map(e => e.textContent)")
        check("Home story 01–04: RWIP → AERIS Cube → AERIS Twin → AERIS Lab with the author's lines", quotes == want and titles == ["RWIP", "AERIS Cube", "AERIS Twin", "AERIS Lab"], (titles, quotes))
        sysbar_home = await page.evaluate("getComputedStyle(document.getElementById('sysbar')).display")
        check("System status strip is hidden on the home page", sysbar_home == "none", sysbar_home)
        for old, new in [("#use", "#lab"), ("#lab-results", "#twin-results"), ("#hardware", "#cube")]:
            await page.goto(URL + old, wait_until="load"); await page.wait_for_timeout(700)
            h = await page.evaluate("location.hash")
            check("Old link " + old + " lands on " + new, h == new, h)

        # ---------------- AERIS Lab: modes, status, badges ----------------
        await page.goto(URL + "#lab", wait_until="load"); await page.wait_for_timeout(1500)
        st = await status(page)
        check("Status strip shows the six fields on the Lab", list(st.keys()) == ["system", "source", "model", "controller", "experiment", "validation"] and st["system"] == "DEMO" and st["validation"] == "SIM ↔ HW PENDING", st)
        modes = await page.evaluate("[...document.querySelectorAll('.wm-b')].map(b => [b.textContent, b.getAttribute('aria-pressed'), b.getAttribute('aria-disabled')])")
        check("Modes: DEMO selected; SIMULATION and HARDWARE disabled (no backend, no telemetry)", modes == [["DEMO", "true", None], ["SIMULATION", "false", "true"], ["HARDWARE", "false", "true"]], modes)
        await page.click('.wm-b[data-mode="hardware"]', force=True); await page.wait_for_timeout(300)
        m = await page.evaluate("AERIS_SERVICE.getMode()")
        why = await page.evaluate("document.getElementById('wmOff').textContent")
        # v5: HARDWARE is telemetry through the research backend; without one it is refused with that reason
        check("Choosing HARDWARE is refused with the reason; no fake connection", m == "demo" and "Telemetry reaches this site through the AERIS research backend" in why and "No research backend is configured" in why, (m, why[:260]))
        await page.evaluate("Workspace.openExample('example-regression')"); await page.wait_for_timeout(800)
        st = await status(page)
        badges = await page.evaluate("document.querySelector('#rp-res .rid').textContent")
        check("A saved example is a REPLAY with its experiment ID", st["source"] == "REPLAY" and st["experiment"] == "AERIS-EXP-000010" and "REPLAY" in badges and "SIMULATED" in badges and "NOMINAL" in badges and "EXAMPLE" in badges, (st, badges))
        await page.click("#lt-create"); await page.click("#btnRun"); await page.wait_for_timeout(1800)
        st = await status(page); snap = await page.evaluate("AERIS_DEBUG.snapshot()")
        badges = await page.evaluate("document.querySelector('#rp-res .rid').textContent")
        check("A fresh run is SIMULATION with a new AERIS-EXP-###### id", st["source"] == "SIMULATION" and snap["fresh"] and snap["experimentId"].startswith("AERIS-EXP-000") and int(snap["experimentId"][-6:]) >= 100 and "SIMULATION" in badges, (st, snap["experimentId"], badges))
        plots = await page.evaluate("JSON.stringify(AERIS_DEBUG.W.plotDefs || [])")
        check("Run plots never use the brand lime", "#c0ff00" not in plots.lower() and "192,255,0" not in plots, "lime found")

        # ---------------- timeline and gauges ----------------
        cfg = "(()=>{const c=AERIS_TWIN.defaultConfig('edge'); c.controller={type:'pid',knowsAttachments:false,reconfigureOnFailure:true}; c.comOffset_m=0.003; c.duration_s=20; c.record_hz=50; return c})()"
        await page.evaluate("Workspace.openConfig(" + cfg + ", {run:true})"); await page.wait_for_timeout(2500)
        ev = await page.evaluate("AERIS_EVENTS.timelineOf(AERIS_DEBUG.W.run).events.map(e => e.type)")
        check("Timeline of the 20 s regression case: saturation risk, speed limit, saturation, fall", all(k in ev for k in ["speed_risk", "speed_limit", "saturation", "fall"]), ev)
        await page.evaluate("document.querySelector('.tl-more').open = true")
        risk_t = await page.evaluate("AERIS_EVENTS.timelineOf(AERIS_DEBUG.W.run).events.find(e => e.type === 'speed_risk').t")
        await page.evaluate("[...document.querySelectorAll('.tl-go')].find(b => Math.abs(+b.dataset.t - %f) < 1e-9).click()" % risk_t); await page.wait_for_timeout(300)
        s = await page.evaluate("AERIS_DEBUG.snapshot()")
        g = await page.evaluate("[...document.querySelectorAll('.gauge')].map(x => [x.className, x.textContent])")
        now = await page.evaluate("document.getElementById('tlNow').textContent")
        check("Clicking an event seeks every view to it", abs(s["t"] - risk_t) < 0.03 and s["viewer"]["idx"] == s["idx"] == s["scrub"], (s["t"], risk_t))
        check("Wheel gauge in amber: 'WHEEL X … RPM / … RPM · SATURATION RISK' at that time", any(("g-risk" in c or "g-sat" in c) and "RPM /" in t and ("SATURATION RISK" in t or "SATURATED" in t) for c, t in g) and "saturation risk" in now.lower(), (g, now))
        ring = await page.evaluate("AERIS_DEBUG.snapshot().viewer.wheelStates")
        check("3-D wheel ring turns amber (risk/saturated), not red, while the wheel is healthy", ring[0] in ("risk", "sat"), ring)
        fall_t = await page.evaluate("AERIS_DEBUG.W.run.metrics.fellAt_s")
        await page.evaluate("AERIS_DEBUG.seekTime(%f)" % (fall_t + 0.05)); await page.wait_for_timeout(250)
        tl_on = await page.evaluate("[...document.querySelectorAll('.tl-track .on')].length")
        check("Timeline cursor and active markers follow playback", tl_on >= 1, tl_on)
        await shot(page, "v3-timeline")

        # ---------------- controller set and computed labels ----------------
        await page.evaluate("Workspace.openConfig((()=>{const c=AERIS_TWIN.defaultConfig('edge'); c.initial.tilt_deg=2; c.duration_s=6; return c})(), {})"); await page.wait_for_timeout(400)
        await page.click("#btnRunSet")
        ok = await wait_for(page, "!AERIS_DEBUG.W.busy && AERIS_DEBUG.W.compare.length === 3", 20000)
        await page.wait_for_timeout(500)
        cmp = await page.evaluate("document.getElementById('rp-cmp').innerText")
        ctls = await page.evaluate("AERIS_DEBUG.W.compare.map(id => AERIS_RUNS.load(id).record.config.controller.type).sort().join()")
        check("'Run PID · LQR · Adaptive' runs one setup with each controller and opens Compare", ok and ctls == "adp,lqr,pid" and "Controller set" in cmp, (ok, ctls))
        check("Computed labels per metric, no overall winner", all(k in cmp for k in ["Lowest settling time", "Lowest control effort", "Largest recovery margin"]) and "no overall winner" in cmp and "not show that one controller is better" in cmp, cmp[:300])
        same_group = await page.evaluate("new Set(AERIS_DEBUG.W.compare.map(id => AERIS_RUNS.load(id).record.group && AERIS_RUNS.load(id).record.group.id)).size")
        check("The three runs share one controller-set group", same_group == 1, same_group)
        await shot(page, "v3-controller-set")

        # ---------------- sensor tiers, mass asymmetry ----------------
        await page.click("#lt-create"); await page.evaluate("document.getElementById('grpSensors').open = true")
        await page.click('input[name="sensorTier"][value="basic"]', force=True); await page.wait_for_timeout(300)
        basic = await page.evaluate("[...document.querySelectorAll('#grpSensors [data-path]')].map(e => e.dataset.path)")
        await page.click('input[name="sensorTier"][value="expert"]', force=True); await page.wait_for_timeout(300)
        expert = await page.evaluate("[...document.querySelectorAll('#grpSensors [data-path]')].map(e => e.dataset.path)")
        check("Sensor settings: BASIC shows noise only, EXPERT adds bias walk, quantisation, lag and wheel health", "sensor.gyro_noise_dps" in basic and "sensor.gyro_quant_dps" not in basic and "sensor.gyro_quant_dps" in expert and "actuator.wheel_health.y" in expert and len(expert) > len(basic), (basic, len(expert)))
        # COM-shift preview (v5.1, review finding F5 of v5). The edit is applied by debounced steps (validation 120 ms,
        # preview 90 ms, the preview again after validation); v5 read the page after a fixed 500 ms and only checked
        # that SOME arrow existed, which failed under load and could pass on the previous value's arrow. Now: a bounded
        # wait until the input, the draft, the validated draft, the mass-asymmetry label and the 3-D view's COM vector
        # all show the new value, and the vector itself is asserted — 4 mm, then 5 mm, then replay → setup.
        await page.click("#vmSetup")
        com = {}
        for mm in (4, 5):
            await page.fill('[data-path="comShift_m.1"]', str(mm))
            ok = await wait_for(page, com_agree(mm), 15000, 50)
            com[f"{mm} mm"] = {"agree": ok, "state": await page.evaluate(COM_STATE)}
        check("COM shift updates the mass-asymmetry panel and the Δr arrow in the 3-D view: 4 mm, then 5 mm — input, draft, validated draft, label '|Δr| … mm' and the view's COM vector (0, Δr, 0) agree",
              all(v["agree"] for v in com.values()), com)
        # replay ↔ setup: the replay shows the RUN's centre of mass (not the draft's 5 mm); back in setup, the draft's again
        has_run = await page.evaluate("!!AERIS_DEBUG.W.run")
        await page.click("#vmReplay")
        ok_r = await wait_for(page, RUN_COM, 15000, 50)
        in_replay = await page.evaluate(COM_STATE)
        await page.click("#vmSetup")
        ok_s = await wait_for(page, com_agree(5), 15000, 50)
        check("Replay ↔ setup: the replay shows the run's own centre of mass, the setup preview the draft's 5 mm again (the draft is unchanged)",
              has_run and ok_r and ok_s, {"replay": in_replay, "setup": await page.evaluate(COM_STATE)})
        await page.fill('[data-path="comShift_m.1"]', "0")
        ok0 = await wait_for(page, COM_ZERO, 15000, 50)
        check("COM shift back to 0 mm: label 0.00 mm and no Δr arrow (the view's COM is the nominal one)", ok0, await page.evaluate(COM_STATE))

        # ---------------- research sweep ----------------
        await page.click("#wk-sweep"); ok = await wait_for(page, "typeof AERIS_SWEEP_UI !== 'undefined' && !!document.getElementById('swRun')", 8000)
        check("Research sweep module loads on demand", ok and await page.evaluate("location.hash") == "#lab/sweep", await page.evaluate("location.hash"))
        await page.click('[data-preset="sat"]'); await page.wait_for_timeout(300)
        val = await page.evaluate("document.getElementById('swVal').textContent")
        check("Sweep validation shows the run count and the engine limit", "60 runs" in val and "limit 400" in val, val[:160])
        roles = await page.evaluate("document.getElementById('swDef').innerText")
        check("Sweep design tags CONTROLLED · FIXED, CHANGED · INDEPENDENT, MEASURED · DEPENDENT", all(k in roles for k in ["CONTROLLED · FIXED", "CHANGED · INDEPENDENT", "MEASURED · DEPENDENT"]), "")
        await page.click("#swRun")
        states = set()
        for _ in range(160):
            s_ = await page.evaluate("AERIS_SWEEP_UI._state.job && AERIS_SWEEP_UI._state.job.state")
            states.add(s_)
            if s_ in ("complete", "failed", "cancelled"): break
            await page.wait_for_timeout(250)
        prog = await page.evaluate("(()=>{const b=document.querySelector('.job-bar'); return b && [b.getAttribute('role'), b.getAttribute('aria-valuenow'), b.getAttribute('aria-valuemax')]})()")
        res = await page.evaluate("(()=>{const s=AERIS_SWEEP_UI._state.result; return s && {id:s.id, rows:s.rows.length, maps:s.analysis.maps.length, demo:s.provenance.demo, mock:s.provenance.mock}})()")
        check("Sweep job runs through the states to COMPLETE with real progress", "complete" in states and prog == ["progressbar", "60", "60"], (states, prog))
        check("Sweep result: 60 rows, a saturation map, labelled DEMO (not MOCK), AERIS-SWP id", res and res["rows"] == 60 and res["maps"] >= 1 and res["demo"] and not res["mock"] and res["id"].startswith("AERIS-SWP-"), res)
        out = await page.evaluate("document.getElementById('swOut').innerText")
        check("Sweep results say what they are: this sweep only, nominal, not the final dataset", "not a general ranking" in out and "not the project's final research dataset" in out and "DEMO MODE" in out, out[:200])
        cells = await page.evaluate("document.querySelectorAll('#swOut canvas').length")
        check("Maps, probability curves and histograms are drawn", cells >= 6, cells)
        st = await status(page)
        check("Status strip names the sweep", st["experiment"].startswith("AERIS-SWP-"), st)
        await page.click('[data-sw="exportDataset"]'); await page.wait_for_timeout(300)
        ds = json.loads(await page.evaluate("document.querySelector('.ws-modal .ws-ta').value")); await page.keyboard.press("Escape")
        check("Dataset export is aeris-dataset/1, marked exploratory and DEMO", ds["schema"] == "aeris-dataset/1" and ds["status"] == "exploratory" and ds["title"].startswith("DEMO") and ds["provenance"]["demo"] is True, (ds["schema"], ds["title"]))
        await shot(page, "v3-sweep")
        # v5.2 (review G4): no timer. The actual Cancel button is clicked from the real job's own progress event while it is
        # RUNNING with 0 < done < total (v5.1 clicked after 300 ms; a fast machine had already finished all 390 runs),
        # then a bounded wait for the terminal state. Completion is never accepted as a cancellation.
        await page.evaluate("""(() => { const d = AERIS_SWEEP_UI._state.def; d.mode = 'grid';
            d.variables = [{key: 'tilt_deg', min: -6, max: 6, steps: 13}, {key: 'rate_dps', min: -60, max: 60, steps: 10}];
            d.duration_s = 10; d.controllers = ['pid', 'lqr', 'adp']; d.mass_configs = ['base'];
            document.getElementById('swRun').click(); const job = AERIS_SWEEP_UI._state.job; window.__cancelAt = null;
            AERIS_JOBS.subscribe(job, j => { if (!window.__cancelAt && j.state === 'running' && j.progress.done > 0 && j.progress.done < j.progress.total) {
              const b = document.getElementById('swCancel');
              window.__cancelAt = {done: j.progress.done, total: j.progress.total, usable: !b.hidden && !b.disabled && b.textContent === 'Cancel'};
              b.click(); } }); })()""")
        ended = await wait_for(page, "['cancelled','complete','failed'].includes(AERIS_SWEEP_UI._state.job.state)", 30000)
        at = await page.evaluate("window.__cancelAt")
        got = await page.evaluate("(()=>{const s=AERIS_SWEEP_UI._state, r=s.result; return {state: s.job.state, done: s.job.progress.done, rows: r ? r.rows.length : null, partial: r ? r.partial : null, ordered: r ? r.rows.every((x, i) => x.index === i) : null}})()")
        badge = await page.evaluate("document.getElementById('swOut').innerText")
        check("Cancelling a sweep while it runs (0 < done < total) stops it and keeps exactly the finished runs as PARTIAL",
              ended and at and at["usable"] and 0 < at["done"] < at["total"] == 390 and got["state"] == "cancelled" and got["rows"] == at["done"] == got["done"]
              and got["partial"] is True and got["ordered"] and "PARTIAL sweep" in badge and f"was cancelled after {at['done']} " in badge, (at, got, ended))
        await page.click("#wk-single"); await page.wait_for_timeout(300)
        check("Lab loads without script errors", not page.errors, page.errors[:3])
        await ctx.close()

        # ---------------- content pages ----------------
        ctx, page = await new_page(br)
        await page.goto(URL + "#cube", wait_until="load"); await page.wait_for_timeout(1200)
        cube = await page.evaluate("({subs: document.querySelectorAll('#cubeSubsystems .sub-c').length, names: [...document.querySelectorAll('#cubeSubsystems h3')].map(e=>e.textContent).join('|'), rows: document.querySelectorAll('#hwSpecs tr').length, nominal: [...document.querySelectorAll('#hwSpecs .bdg')].filter(b => b.textContent === 'NOMINAL').length, pend: document.getElementById('hwSpecs').textContent.split('Pending measurement').length - 1, st: AERIS_STATUS.snapshot()[1].value})")
        check("Cube page: wheels X/Y/Z, motors, IMU, MCU, PCB, battery, frame; 9 parameters NOMINAL and pending", cube["subs"] >= 9 and all(k in cube["names"] for k in ["Reaction wheel X", "Reaction wheel Y", "Reaction wheel Z", "Motor drivers", "IMU", "MCU", "Control board (PCB)", "Battery and power", "Frame"]) and cube["rows"] == 9 and cube["nominal"] == 9 and cube["pend"] == 9 and cube["st"] == "HARDWARE DATA PENDING", cube)
        await page.goto(URL + "#research", wait_until="load"); await page.wait_for_timeout(1000)
        rq = await page.evaluate("document.getElementById('rqText').textContent")
        check("Research question verbatim", rq == "How do PID, LQR, and adaptive/nonlinear attitude controllers differ in their ability to stabilize a three-axis reaction-wheel system as center-of-mass displacement, inertia uncertainty, disturbances and actuator saturation increase?", rq)
        rs = await page.evaluate("({h: document.querySelectorAll('#rhList .hyp').length, tested: document.getElementById('rhList').textContent.split('NOT YET TESTED').length - 1, roles: document.getElementById('rvList').textContent, ctl: document.getElementById('rcTable').textContent, secs: [...document.querySelectorAll('#view-research .pg-h')].map(h => h.textContent.replace(/^\\d+/, '')), res: document.getElementById('research-results').textContent})")
        check("Research page: hypotheses marked as untested predictions; variables tagged; controllers accurate", rs["h"] >= 3 and rs["tested"] == rs["h"] and all(k in rs["roles"] for k in ["CHANGED · INDEPENDENT", "CONTROLLED · FIXED", "MEASURED · DEPENDENT"]) and "COM-adaptive LQR" in rs["ctl"] and "does not adapt inertia" in rs["ctl"], rs)
        check("Research page sections: question … future work, and evolution", rs["secs"] == ["Research question", "Hypotheses", "Variables", "Controllers", "Methodology", "Metrics", "Results", "Limitations", "Future work", "Evolution"] and "Final dataset not yet generated." in rs["res"], rs["secs"])
        evo = await page.evaluate("[...document.querySelectorAll('#evoFull .evo-i')].map(e => e.querySelector('.evo-stage').textContent + ':' + e.querySelector('.evo-st').textContent)")
        check("Evolution: RWIP first, undocumented iterations shown as such, validation and final results not claimed", evo[0].startswith("RWIP") and any("NOT YET DOCUMENTED" in e for e in evo) and any(e.startswith("Validation:PLANNED") for e in evo) and evo[-1] == "Final results:PLANNED", evo)
        await page.goto(URL + "#results", wait_until="load"); await page.wait_for_timeout(1000)
        rt = await page.evaluate("document.getElementById('results-findings').textContent")
        check("Results page: 'Final dataset not yet generated.' and an empty template, no findings", "Final dataset not yet generated." in rt and "TEMPLATE · NO DATA" in rt and not await page.evaluate("document.querySelectorAll('#resFindings .finding:not(.tpl)').length"), rt[:120])
        await page.goto(URL + "#validation", wait_until="load"); await page.wait_for_timeout(1000)
        vt = await page.evaluate("document.getElementById('view-validation').textContent")
        await page.click("#valGo"); await page.wait_for_timeout(200)
        vo = await page.evaluate("document.getElementById('valOut').textContent")
        check("Validation page: 'Hardware dataset pending'; comparing without a recording computes nothing", "Hardware dataset pending." in vt and "not called a validated digital twin" in vt and "Nothing is compared" in vo and "RMSE" not in vo, vo)
        await page.goto(URL + "#twin", wait_until="load"); await page.wait_for_timeout(3500)
        tw = await page.evaluate("({h1: document.getElementById('twinTitle').textContent, note: document.querySelector('#view-twin .notice').textContent, ctl: document.querySelector('#ctlSummary tbody').textContent})")
        check("Twin page: 'AERIS Twin', physics-based digital model, not yet validated, controller summary", tw["h1"] == "AERIS Twin" and "physics-based digital model" in tw["note"] and "not yet a validated digital twin" in tw["note"] and "COM-adaptive LQR" in tw["ctl"], tw["h1"])
        h1s = {}
        for v in ["", "#cube", "#twin", "#lab", "#research", "#results", "#validation"]:
            await page.goto(URL + v, wait_until="load"); await page.wait_for_timeout(700)
            h1s[v or "home"] = await page.evaluate("[...document.querySelectorAll('h1')].filter(h => h.offsetParent !== null).length")
        check("Each page shows exactly one visible h1", all(n == 1 for n in h1s.values()), h1s)
        unnamed = await page.evaluate("[...document.querySelectorAll('button, a[href]')].filter(b => b.offsetParent !== null && !(b.textContent.trim() || b.getAttribute('aria-label') || b.getAttribute('title'))).map(b => b.outerHTML.slice(0, 80))")
        check("Visible buttons and links have accessible names", not unnamed, unnamed[:3])
        check("Content pages load without script errors", not page.errors, page.errors[:3])
        await ctx.close()

        # ---------------- mobile ----------------
        ctx, page = await new_page(br, 390, 844, 2)
        overflow = {}
        for h in ["", "#cube", "#research", "#results", "#validation", "#lab/sweep"]:
            await page.goto(URL + h, wait_until="load"); await page.wait_for_timeout(1300)
            overflow[h or "home"] = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            await shot(page, "v3-mobile-" + (h.replace("#", "").replace("/", "-") or "home"))
        check("No horizontal scrolling at 390 px on the new pages and the sweep", all(v <= 0 for v in overflow.values()), overflow)
        await ctx.close()
        await br.close()
    passed = sum(1 for r in results if r[1])
    print(f"\n{passed} / {len(results)} v3 browser checks passed")
    sys.exit(0 if passed == len(results) else 1)

asyncio.run(main())

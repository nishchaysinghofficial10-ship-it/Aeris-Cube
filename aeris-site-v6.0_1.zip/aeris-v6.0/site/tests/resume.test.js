/* Race-safe telemetry resume and catch-up (v6, review finding V52-1 of v5.2).

     node tests/resume.test.js

   The real HardwareTelemetryAdapter.live() against deterministic fixtures: a model of the backend hub (contiguous
   frame indices n, a retained-history buffer that keeps the most recent frames and reports what it evicted, a stream
   id per process), a WebSocket whose events the test fires by hand, and history requests that the test answers when it
   chooses (so frames can arrive during the handshake and during the catch-up). Nothing here touches a network. The
   live suites exercise the same code against a real backend (live_backend.test.js L14 and L15). */
"use strict";
var path = require("path");
global.AERIS_SCHEMA = require(path.join(__dirname, "..", "js", "platform", "schema.js"));
var H = require(path.join(__dirname, "..", "js", "adapters", "hardware-telemetry.js"));

var results = [], queue = [];
function test(n, f) { queue.push({ n: n, f: f }); }
function run() {
  var i = 0;
  (function next() {
    if (i >= queue.length) return report();
    var t = queue[i++], cur = { name: t.n, ok: true, msgs: [] };
    function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
    var p; try { p = t.f(check); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); }
    Promise.resolve(p).then(function () { H.bind(null); results.push(cur); next(); }, function (e) { H.bind(null); cur.ok = false; cur.msgs.push("rejected: " + (e && (e.stack || e.message) || e)); results.push(cur); next(); });
  })();
}
function report() {
  var pass = results.filter(function (r) { return r.ok; }).length;
  results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
  console.log("\n" + pass + " / " + results.length + " telemetry resume tests passed");
  process.exit(pass === results.length ? 0 : 1);
}

/* ---------------- fixtures ---------------- */
/* the backend hub: contiguous indices, retained history (TelemetryHub.frames_after semantics) */
function hub(stream, retained) {
  var h = { stream: stream, n: 0, retained: retained || 2000, frames: [] };
  h.accept = function (k) { var out = []; for (var i = 0; i < k; i++) { h.n++; var f = { n: h.n, seq: h.n, t: h.n / 100 }; h.frames.push(f); out.push(f); if (h.frames.length > h.retained) h.frames.shift(); } return out; };
  h.after = function (after, limit, named) {
    var changed = !!named && named !== h.stream; if (changed) after = 0;
    var out = h.frames.filter(function (f) { return f.n > after; }).slice(0, Math.max(1, limit));
    var oldest = h.frames.length ? h.frames[0].n : h.n + 1;
    return { frames: out, last_n: h.n, missed: h.n > after ? Math.max(0, oldest - after - 1) : 0, stream_id: h.stream, stream_changed: changed };
  };
  h.restart = function (s) { h.stream = s; h.n = 0; h.frames = []; };
  return h;
}
/* the research backend seen by the adapter: answers history requests from the hub, now or when the test says so */
function backend(h) {
  var b = { hub: h, paths: [], held: [], hold: false, fail: 0 };
  b.api = { configured: function () { return true; }, available: function () { return { ok: true }; }, wsUrl: "ws://fixture",
    capabilities: function () { return { reported: true, telemetry: { available: true } }; },
    request: function (method, url) {
      b.paths.push(url);
      if (url.indexOf("/telemetry/status") === 0) return Promise.resolve({ stream_id: b.hub.stream, last_n: b.hub.n, connected: true });
      var q = {}; url.split("?")[1].split("&").forEach(function (kv) { var p = kv.split("="); q[p[0]] = decodeURIComponent(p[1]); });
      if (b.fail > 0) { b.fail--; return Promise.reject({ code: "unavailable", message: "fixture: history request failed" }); }
      var answer = function () { return b.hub.after(+q.after, +q.limit, q.stream); };
      if (!b.hold) return Promise.resolve(answer());
      return new Promise(function (res) { b.held.push({ url: url, release: function (override) { res(override || answer()); } }); });
    } };
  b.releaseAll = function () { var h2 = b.held; b.held = []; h2.forEach(function (x) { x.release(); }); };
  b.history = function () { return b.paths.filter(function (p) { return p.indexOf("/telemetry/frames") === 0; }); };
  return b;
}
function handWS() { var made = []; function WS(url) { this.url = url; made.push(this); } WS.prototype.close = function () { this.closed = true; }; WS.made = made; return WS; }
function send(ws, o) { ws.onmessage({ data: JSON.stringify(o) }); }
function settle(k) { var p = Promise.resolve(); for (var i = 0; i < (k || 4); i++) p = p.then(function () { return new Promise(function (r) { setImmediate(r); }); }); return p; }
function manualWait() { var q = []; var w = function (ms, fn) { q.push(fn); return 0; }; w.q = q; w.next = function () { var fn = q.shift(); if (fn) fn(); return !!fn; }; return w; }
function consumer() {
  var c = { delivered: [], gaps: [], log: [] };
  c.on = function (ev) {
    if (ev.type === "frames") { c.delivered = c.delivered.concat(ev.frames.map(function (f) { return f.n; })); c.log.push("frames:" + ev.frames[0].n + "-" + ev.frames[ev.frames.length - 1].n); }
    else if (ev.type === "gap") { c.gaps.push(ev); c.log.push("gap:" + ev.from + "-" + ev.to); }
    else if (ev.type === "stream") c.log.push("stream:" + ev.stream);
    else if (ev.type === "catchup") c.log.push("catchup:" + ev.state);
  };
  return c;
}
function range(a, b) { var o = []; for (var n = a; n <= b; n++) o.push(n); return o; }
function same(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
function inOrderOnce(list) { for (var i = 1; i < list.length; i++) if (!(list[i] > list[i - 1])) return false; return true; }

/* ================================================================ tests */
test("R1 Same-process reconnect: frames accepted after the last poll and before the new subscription are fetched; live frames that arrive meanwhile wait; each frame once, in order", function (check) {
  var h = hub("K"), b = backend(h), WS = handWS(), c = consumer(), wait = manualWait();
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: wait });
  var a = WS.made[0]; a.onopen(); send(a, { type: "status", status: { stream_id: "K", last_n: 0 } });
  send(a, { type: "frames", stream: "K", frames: h.accept(50), dropped: 0 });
  a.onclose({ code: 1006 });                                         // the socket drops; polling reads the history
  return settle().then(function () {
    check(live.lastN() === 50 && live.mode() === "polling", "polled up to 50: " + live.lastN());
    h.accept(15);                                                     // 51..65: accepted while no socket is subscribed
    b.hold = true;
    wait.next();                                                      // the adapter opens a new socket
    var s = WS.made[1]; s.onopen(); send(s, { type: "status", status: { stream_id: "K", last_n: 65 } });
    check(b.held.length === 1 && /after=50&limit=500&stream=K$/.test(b.held[0].url), "the backlog after the cursor is requested: " + JSON.stringify(b.held.map(function (x) { return x.url; })));
    send(s, { type: "frames", stream: "K", frames: h.accept(5), dropped: 0 });   // 66..70 live, before the history answer
    check(same(c.delivered, range(1, 50)), "live frames wait for the history: " + c.delivered.slice(-3));
    b.releaseAll();
    return settle();
  }).then(function () {
    check(same(c.delivered, range(1, 70)), "1..70 once and in order: " + JSON.stringify(c.delivered.slice(45)));
    // the history page holds everything retained after the cursor (51..70), including frames also held live; each is delivered once
    check(c.gaps.length === 0 && live.stats().recovered === 20 && live.stats().catchups === 1, "nothing lost, 51..70 delivered from the history: " + JSON.stringify(live.stats()));
    live.close();
  });
});

test("R2 Process restart (V52-1): the new stream's first frame, accepted before the socket subscribed and still retained, is recovered once and before frame 2", function (check) {
  var h = hub("old"), b = backend(h), WS = handWS(), c = consumer(), wait = manualWait();
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: wait });
  var a = WS.made[0]; a.onopen(); send(a, { type: "status", status: { stream_id: "old", last_n: 0 } });
  send(a, { type: "frames", stream: "old", frames: h.accept(300), dropped: 0 });
  a.onclose({ code: 1012 });
  return settle().then(function () {
    h.restart("new"); h.accept(1);                                   // the new process accepts frame 1 ...
    b.hold = true;
    wait.next();
    var s = WS.made[1]; s.onopen(); send(s, { type: "status", status: { stream_id: "new", last_n: 1 } });   // ... before this socket subscribed
    var shown = c.delivered.length;
    send(s, { type: "frames", stream: "new", frames: h.accept(1), dropped: 0 });                        // frame 2 live
    check(c.delivered.length === shown, "frame 2 is held until frame 1 has been fetched: " + JSON.stringify(c.delivered.slice(shown)));
    b.releaseAll();
    return settle();
  }).then(function () {
    var after = c.delivered.slice(c.delivered.lastIndexOf(300) + 1);
    check(same(after, [1, 2]), "the new stream from n = 1: " + JSON.stringify(after));
    check(c.log.indexOf("stream:new") >= 0 && c.log.indexOf("stream:new") < c.log.lastIndexOf("frames:1-2"), "stream event first: " + JSON.stringify(c.log.slice(-5)));
    check(c.gaps.length === 0 && live.streamChanges() === 1 && live.lastN() === 2, "no gap, one change: " + JSON.stringify(c.gaps));
    check(b.history().some(function (p) { return /after=0&limit=500&stream=new$/.test(p); }), "the new stream's history was read from its beginning: " + JSON.stringify(b.history()));
    live.close();
  });
});

test("R3 Frames arriving during the handshake and the catch-up are held, then delivered after the history without duplicates", function (check) {
  var h = hub("S"), b = backend(h), WS = handWS(), c = consumer();
  h.accept(100);
  H.bind(b.api);
  b.hold = true;
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait(), stream: "S", after: 40 });
  var s = WS.made[0];
  s.onopen(); send(s, { type: "status", status: { stream_id: "S", last_n: 100 } });
  for (var k = 0; k < 4; k++) send(s, { type: "frames", stream: "S", frames: h.accept(5), dropped: 0 });   // 101..120
  check(c.delivered.length === 0 && live.stats().catchingUp, "nothing delivered before the history answer");
  b.releaseAll();
  return settle().then(function () {
    check(same(c.delivered, range(41, 120)), "41..120 once in order: " + c.delivered.length + " " + c.delivered.slice(0, 3) + "…" + c.delivered.slice(-3));
    check(!live.stats().catchingUp && c.gaps.length === 0, "caught up without gaps");
    live.close();
  });
});

test("R4 Duplicates: overlapping socket batches and a history page that overlaps the buffered frames still deliver each index once", function (check) {
  var h = hub("D"), b = backend(h), WS = handWS(), c = consumer();
  h.accept(60);
  H.bind(b.api); b.hold = true;
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait(), stream: "D", after: 10 });
  var s = WS.made[0]; s.onopen(); send(s, { type: "status", status: { stream_id: "D", last_n: 60 } });
  var batch = h.accept(10);                                          // 61..70
  send(s, { type: "frames", stream: "D", frames: batch, dropped: 0 });
  send(s, { type: "frames", stream: "D", frames: batch, dropped: 0 });               // the same batch again
  b.held[0].release(h.after(10, 500, "D"));                          // history now holds 11..70: overlaps the buffer
  return settle().then(function () {
    send(s, { type: "frames", stream: "D", frames: batch.concat(h.accept(3)), dropped: 0 });  // 61..73 again (overlap) + new
    check(same(c.delivered, range(11, 73)), "11..73 once: " + JSON.stringify(c.delivered.slice(-8)));
    live.close();
  });
});

test("R5 Old-stream responses: a history answer of the stream the client has left is ignored; the new stream is read from its beginning", function (check) {
  var h = hub("A"), b = backend(h), WS = handWS(), c = consumer();
  h.accept(80);
  H.bind(b.api); b.hold = true;
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait(), stream: "A", after: 20 });
  var s = WS.made[0]; s.onopen(); send(s, { type: "status", status: { stream_id: "A", last_n: 80 } });
  var staleAnswer = h.after(20, 500, "A");                           // what the old process would have answered
  check(b.held.length === 1, "catch-up for stream A pending");
  // the backend restarts before that answer arrives; a socket to the new process reports stream B
  h.restart("B"); h.accept(3);
  send(s, { type: "status", status: { stream_id: "B", last_n: 3 } });
  check(live.streamId() === "B" && live.lastN() === 0, "switched to B");
  b.held.shift().release(staleAnswer);                                // the late answer about stream A
  return settle().then(function () {
    check(c.delivered.every(function (n) { return n <= 3; }) && c.delivered.indexOf(21) < 0, "nothing of stream A delivered after the switch: " + JSON.stringify(c.delivered.slice(0, 5)));
    // the new stream: frames 4.. arrive live with a hole 1..3 → fetched
    send(s, { type: "frames", stream: "B", frames: h.accept(2), dropped: 0 });
    b.releaseAll();
    return settle();
  }).then(function () {
    b.releaseAll();
    return settle();
  }).then(function () {
    check(same(c.delivered, range(1, 5)), "stream B 1..5: " + JSON.stringify(c.delivered));
    live.close();
  });
});

test("R6 A backlog longer than one history page is read page by page; live frames follow", function (check) {
  var h = hub("P", 5000), b = backend(h), WS = handWS(), c = consumer();
  h.accept(1300);
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait(), stream: "P", after: 0, pageSize: 500 });
  var s = WS.made[0]; s.onopen(); send(s, { type: "status", status: { stream_id: "P", last_n: 1300 } });
  send(s, { type: "frames", stream: "P", frames: h.accept(4), dropped: 0 });
  return settle(10).then(function () {
    var hist = b.history();
    check(hist.length === 3 && /after=0&/.test(hist[0]) && /after=500&/.test(hist[1]) && /after=1000&/.test(hist[2]), "three pages: " + JSON.stringify(hist));
    check(same(c.delivered, range(1, 1304)), "1..1304 once in order: " + c.delivered.length);
    live.close();
  });
});

test("R7 Buffer overflow: the oldest buffered live frames are dropped and fetched from the retained history; nothing is lost", function (check) {
  var h = hub("O", 5000), b = backend(h), WS = handWS(), c = consumer();
  h.accept(30);
  H.bind(b.api); b.hold = true;
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait(), stream: "O", after: 10, maxBuffer: 10 });
  var s = WS.made[0]; s.onopen(); send(s, { type: "status", status: { stream_id: "O", last_n: 30 } });
  for (var k = 0; k < 6; k++) send(s, { type: "frames", stream: "O", frames: h.accept(5), dropped: 0 });   // 31..60 while waiting
  check(live.stats().overflowed === 20, "20 oldest buffered frames dropped: " + JSON.stringify(live.stats()));
  b.hold = false; b.releaseAll();
  return settle(10).then(function () {
    check(same(c.delivered, range(11, 60)), "11..60 once in order: " + c.delivered.length + " " + JSON.stringify(c.delivered.slice(15, 25)));
    check(c.gaps.length === 0, "no gap: they were still retained");
    live.close();
  });
});

test("R8 History no longer retained: the missing range is reported as an explicit gap (stream, from, to, count); the cursor moves past it; later frames continue", function (check) {
  var h = hub("G", 50), b = backend(h), WS = handWS(), c = consumer();
  h.accept(200);                                                     // only 151..200 retained
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait(), stream: "G", after: 100 });
  var s = WS.made[0]; s.onopen(); send(s, { type: "status", status: { stream_id: "G", last_n: 200 } });
  return settle().then(function () {
    send(s, { type: "frames", stream: "G", frames: h.accept(2), dropped: 0 });
    check(c.gaps.length === 1 && c.gaps[0].from === 101 && c.gaps[0].to === 150 && c.gaps[0].missed === 50 && c.gaps[0].stream === "G", "explicit gap 101–150: " + JSON.stringify(c.gaps));
    check(same(c.delivered, range(151, 202)), "151..202 delivered: " + c.delivered.length);
    check(c.log.indexOf("gap:101-150") < c.log.indexOf("frames:151-200"), "the gap is reported before the frames after it");
    live.close();
  });
});

test("R9 A history that cannot be read (repeated failures) ends in an explicit gap after the bounded attempts; live frames continue", function (check) {
  var h = hub("F"), b = backend(h), WS = handWS(), c = consumer(), rw = manualWait();
  h.accept(20);
  H.bind(b.api); b.fail = 3;
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait(), retryWait: rw, stream: "F", after: 5, historyAttempts: 3 });
  var s = WS.made[0]; s.onopen(); send(s, { type: "status", status: { stream_id: "F", last_n: 20 } });
  send(s, { type: "frames", stream: "F", frames: h.accept(3), dropped: 0 });
  return settle().then(function () { rw.next(); return settle(); }).then(function () { rw.next(); return settle(); }).then(function () {
    check(c.gaps.length === 1 && c.gaps[0].from === 6 && c.gaps[0].to === 20 && /could not be read/.test(c.gaps[0].reason), "gap after 3 attempts: " + JSON.stringify(c.gaps));
    check(same(c.delivered, range(21, 23)), "live frames continue: " + JSON.stringify(c.delivered));
    check(b.history().length === 3, "exactly 3 attempts: " + b.history().length);
    live.close();
  });
});

test("R10 A slow client whose socket queue dropped frames (indices skip) gets them from the history", function (check) {
  var h = hub("Q"), b = backend(h), WS = handWS(), c = consumer();
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait() });
  var s = WS.made[0]; s.onopen(); send(s, { type: "status", status: { stream_id: "Q", last_n: 0 } });
  send(s, { type: "frames", stream: "Q", frames: h.accept(10), dropped: 0 });
  h.accept(25);                                                       // 11..35 dropped for this client by the backend
  send(s, { type: "frames", stream: "Q", frames: h.accept(5), dropped: 25 });
  return settle().then(function () {
    check(same(c.delivered, range(1, 40)), "1..40: " + JSON.stringify(c.delivered.slice(8, 14)));
    check(c.gaps.length === 0 && live.stats().recovered >= 25 && live.stats().catchups === 1, "11..35 came from the history: " + JSON.stringify(live.stats()));
    live.close();
  });
});

test("R11 A new viewer starts at the live edge: no history is fetched for frames it never showed", function (check) {
  var h = hub("E"), b = backend(h), WS = handWS(), c = consumer();
  h.accept(500);
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait() });
  var s = WS.made[0]; s.onopen(); send(s, { type: "status", status: { stream_id: "E", last_n: 500 } });
  send(s, { type: "frames", stream: "E", frames: h.accept(3), dropped: 0 });
  return settle().then(function () {
    check(b.history().length === 0 && same(c.delivered, [501, 502, 503]), "starts at 501 without a history request: " + JSON.stringify(b.history()));
    live.close();
  });
});

test("R12 Polling: a full page is followed at once by the next one; evicted frames are an explicit gap with their range", function (check) {
  var h = hub("L", 600), b = backend(h), c = consumer(), wait = manualWait();
  var NoWS = function () { throw new Error("no WebSocket in this test"); };
  h.accept(700);                                                      // 101..700 retained
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: NoWS, wait: wait, stream: "L", after: 50, pageSize: 500 });
  return settle().then(function () {
    check(c.gaps.length === 1 && c.gaps[0].from === 51 && c.gaps[0].to === 100, "evicted 51–100 reported: " + JSON.stringify(c.gaps));
    check(live.lastN() === 600, "first page 101..600: " + live.lastN());
    wait.next();                                                      // the immediate next page
    return settle();
  }).then(function () {
    check(same(c.delivered, range(101, 700)), "101..700: " + c.delivered.length);
    live.close();
  });
});

test("R13 close() during a catch-up: the pending answer changes nothing and no event follows", function (check) {
  var h = hub("C"), b = backend(h), WS = handWS(), c = consumer();
  h.accept(30);
  H.bind(b.api); b.hold = true;
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait(), stream: "C", after: 5 });
  var s = WS.made[0]; s.onopen(); send(s, { type: "status", status: { stream_id: "C", last_n: 30 } });
  live.close();
  var n = c.log.length;
  b.releaseAll();
  return settle().then(function () {
    check(c.log.length === n && c.delivered.length === 0, "nothing after close: " + JSON.stringify(c.log.slice(n)));
  });
});

test("R14 The reviewer's V52-1 fixture with a history that serves frame 1: delivered [1, 2], one history request for the new stream, no gap", function (check) {
  // websocket_gap_probe.cjs, with /telemetry/frames answering what the new stream retains (the probe's own fixture answers nothing)
  var stream = "old", retained = [], sockets = [], timers = [], events = [];
  H.bind({ configured: function () { return true; }, available: function () { return { ok: true }; }, capabilities: function () { return { reported: true, telemetry: { available: true } }; }, wsUrl: "ws://fixture",
    request: function (m, url) { return Promise.resolve(url.indexOf("/telemetry/frames") === 0 ? { stream_id: stream, last_n: retained.length ? retained[retained.length - 1].n : 1, frames: /stream=new/.test(url) ? retained.filter(function (f) { return f.n > +/after=(\d+)/.exec(url)[1]; }) : [], missed: 0 } : { stream_id: stream, last_n: 1 }); } });
  function Socket(url) { this.url = url; sockets.push(this); } Socket.prototype.close = function () {};
  var client = H.live(function (e) { events.push(e); }, { WebSocket: Socket, stream: "old", after: 1, wait: function (ms, fn) { timers.push(fn); return null; } });
  sockets[0].onopen(); send(sockets[0], { type: "status", status: { stream_id: "old", last_n: 1 } });
  sockets[0].onclose({ code: 1006 });
  return settle().then(function () {
    stream = "new"; retained = [{ n: 1, t: 0.1 }];
    timers.shift()();
    sockets[1].onopen(); send(sockets[1], { type: "status", status: { stream_id: "new", last_n: 1 } });
    retained.push({ n: 2, t: 0.2 }); send(sockets[1], { type: "frames", stream: "new", frames: [{ n: 2, t: 0.2 }], dropped: 0 });
    return settle();
  }).then(function () {
    var delivered = events.filter(function (e) { return e.type === "frames"; }).reduce(function (a, e) { return a.concat(e.frames.map(function (f) { return f.n; })); }, []);
    check(same(delivered, [1, 2]) && client.lastN() === 2, "delivered [1, 2]: " + JSON.stringify(delivered));
    check(events.filter(function (e) { return e.type === "gap"; }).length === 0, "no gap");
    client.close();
  });
});

run();

/* Numerical tests for the AERIS physics core (js/core.js).
   Run with:  node tests/numerics.test.js
   These tests check calculations only. Visual and browser behaviour is checked
   separately (tests/browser_check.py). */
"use strict";
var path = require("path");
var AERIS_TWIN = require(path.join(__dirname, "..", "js", "core.js"));
var REF = require(path.join(__dirname, "python_reference_v1.json"));
var DEG = AERIS_TWIN.DEG, RPM = AERIS_TWIN.RPM;

var results = [], current = null;
function test(name, fn) {
  current = { name: name, ok: true, msgs: [] };
  try { fn(); } catch (e) { current.ok = false; current.msgs.push("threw: " + (e && e.stack || e)); }
  results.push(current);
}
function check(cond, msg) { if (!cond) { current.ok = false; current.msgs.push(msg); } }
function near(a, b, tol, msg) { check(typeof a === "number" && isFinite(a) && Math.abs(a - b) <= tol, (msg || "value") + ": got " + a + ", expected " + b + " ± " + tol); }
function rel(a, b, rtol, msg) { near(a, b, Math.abs(b) * rtol, msg); }
function cfg(o) { var c = AERIS_TWIN.defaultConfig(o.mode || "edge"); Object.keys(o).forEach(function (k) { c[k] = o[k]; }); return c; }
function zeroIni(extra) { var i = { tilt_deg: 0, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }; Object.keys(extra || {}).forEach(function (k) { i[k] = extra[k]; }); return i; }
function last(a) { return a[a.length - 1]; }

/* ------------------------------------------------------------------ 1. regression case */
test("Regression: PID, tilt 0, COM +3 mm, 4 s is reported as Drifting (not Recovered)", function () {
  var r = AERIS_TWIN.simulate(cfg({ controller: { type: "pid" }, initial: zeroIni(), comOffset_m: 0.003, duration_s: 4, torqueScale: 1, estimator: { type: "ideal" } }));
  check(r.ok, "run should be valid");
  check(r.outcome.code === "drifting", "outcome should be drifting, got " + r.outcome.code);
  check(r.metrics.settle_s === null, "settling time must be null (never the final timestamp), got " + r.metrics.settle_s);
  check(r.metrics.settle_s !== r.metrics.recorded_s, "settling time equals the end of the window");
  check(r.metrics.drift && r.metrics.drift.kind === "wheel", "drift should be a wheel-speed drift");
  near(r.metrics.drift.slope_rpm_s, 1013, 15, "wheel slope rpm/s");
  near(r.metrics.drift.projected_s, 4.85, 0.1, "projected time to the wheel-speed limit");
  near(r.metrics.finalLean_deg, 1.35, 0.02, "final-window COM lean (PID holds θ = 0, so e = β)");
  check(/rising steadily/.test(r.outcome.reason), "reason should explain the drift");
  check(r.outcome.label === AERIS_TWIN.OUTCOMES.drifting.label, "label must come from the single outcome table");
});
test("Regression: the same case over 20 s ends Fallen when the wheel saturates", function () {
  var r = AERIS_TWIN.simulate(cfg({ controller: { type: "pid" }, initial: zeroIni(), comOffset_m: 0.003, duration_s: 20 }));
  check(r.outcome.code === "fallen", "expected fallen, got " + r.outcome.code);
  near(r.metrics.fellAt_s, REF.E2_pid.fell, 0.02, "fall time vs independent Python model");
  check(r.metrics.peakOmega_frac > 0.99, "wheel should reach its limit before the fall");
});

/* ------------------------------------------------------------------ 2. settling semantics (synthetic) */
function synth(fn, T, dt, oms) {
  var n = Math.round(T / dt), e = new Float64Array(n + 1), om = new Float64Array(n + 1);
  for (var i = 0; i <= n; i++) { e[i] = fn(i * dt) * DEG; om[i] = (oms ? oms(i * dt) : 0) * RPM; }
  return { e: e, om: [om], sat: new Uint8Array(n + 1), E: 0, nSteps: n };
}
function ctx(T) { return { mode: "edge", wmax: 5000 * RPM, dt: 0.002, fellAt: null, contactAt: null, window_s: T }; }
test("Settling: earliest time after which |e| stays inside ±0.25°", function () {
  var A = AERIS_TWIN.assess(synth(function (t) { return t < 1 ? 2 * (1 - t) + 0.3 : 0.1; }, 4, 0.002), ctx(4));
  near(A.metrics.settle_s, 1.0, 0.003, "settle time");
  check(A.outcome.code === "recovered", "should be recovered");
});
test("Settling: entering the band in the last 0.3 s is NOT settled (hold 0.5 s)", function () {
  var A = AERIS_TWIN.assess(synth(function (t) { return t < 3.7 ? 1 : 0.1; }, 4, 0.002), ctx(4));
  check(A.metrics.settle_s === null, "settle must be null, got " + A.metrics.settle_s);
  check(A.outcome.code === "not_settled", "outcome should be not_settled, got " + A.outcome.code);
});
test("Settling: outside the band at the final sample is never reported as settled", function () {
  var A = AERIS_TWIN.assess(synth(function (t) { return t < 3.998 ? 0.1 : 1; }, 4, 0.002), ctx(4));
  check(A.metrics.settle_s === null, "settle must be null");
});
test("Drift: a steady wheel ramp is Drifting even when the lean is inside the band", function () {
  var A = AERIS_TWIN.assess(synth(function () { return 0.05; }, 6, 0.002, function (t) { return 200 * t; }), ctx(6));
  check(A.outcome.code === "drifting", "expected drifting, got " + A.outcome.code);
  near(A.metrics.drift.projected_s, 6 + (5000 - 1200) / 200, 0.05, "projected saturation");
});
test("Drift: a wheel converging to a constant speed is not drifting", function () {
  var A = AERIS_TWIN.assess(synth(function () { return 0.05; }, 10, 0.002, function (t) { return 800 * (1 - Math.exp(-t / 0.8)); }), ctx(10));
  check(A.outcome.code === "recovered", "expected recovered, got " + A.outcome.code);
  check(/has not returned/.test(A.outcome.notes.join(" ")), "should note the parked wheel momentum");
});

/* ------------------------------------------------------------------ 3. validation */
test("Invalid: a = 0.08 m, m = 0.3 kg, k_J = 0.1, J_w = 0.005 kg·m² is rejected before simulation", function () {
  var p = AERIS_TWIN.clone(AERIS_TWIN.NOMINAL); p.a = 0.08; p.m = 0.3; p.kJ = 0.1; p.Jw = 0.005;
  var v = AERIS_TWIN.validateConfig(cfg({ params: p }));
  check(!v.ok, "validation must fail");
  check(v.errors.some(function (e) { return e.path === "params.Jw"; }), "J_w error expected");
  check(v.errors.some(function (e) { return e.path === "params.kJ" && /negative/.test(e.message); }), "negative-inertia explanation expected");
  check(v.design === null && v.mp === null, "no design or mass properties for an invalid configuration");
  var r = AERIS_TWIN.simulate(cfg({ params: p }));
  check(!r.ok && r.outcome.code === "invalid", "simulate must return the invalid outcome");
  check(!r.samples && !r.metrics, "no samples or metrics may be produced");
});
test("Invalid: non-numeric and missing values are reported, not replaced by defaults", function () {
  var r = AERIS_TWIN.simulate({ mode: "edge", params: { a: "abc" }, duration_s: "x" });
  check(!r.ok, "must be invalid");
  check(r.errors.some(function (e) { return e.path === "params.a"; }), "edge length error");
  check(r.errors.some(function (e) { return e.path === "duration_s"; }), "duration error");
});
test("Invalid: unknown mode, controller, estimator and frame are named in the errors", function () {
  var r = AERIS_TWIN.simulate({ mode: "sideways" }); check(!r.ok && r.errors[0].path === "mode", "mode");
  r = AERIS_TWIN.simulate(cfg({ controller: { type: "mpc" } })); check(!r.ok && /Unknown controller/.test(r.errors[0].message), "controller");
  r = AERIS_TWIN.simulate(cfg({ mode: "corner", estimator: { type: "kf" } })); check(!r.ok && r.errors[0].path === "estimator.type", "corner estimator");
  r = AERIS_TWIN.simulate(cfg({ disturbances: [{ id: "F", type: "force", magnitude_N: 1, point_m: [0.09, 0.09, 0.18], direction: [1, 0, 0], frame: "lab", t_start_s: 0, duration_s: 1 }] }));
  check(!r.ok && r.errors.some(function (e) { return /frame/.test(e.path); }), "frame");
});
test("Warning: centre of mass near the end of the support edge (tipping over the end is not modelled)", function () {
  var p = AERIS_TWIN.clone(AERIS_TWIN.NOMINAL); p.m = 0.3;
  var v = AERIS_TWIN.validateConfig(cfg({ params: p, attachments: [{ id: "m1", label: "Far", mass_kg: 5, pos_m: [0.18, 0.09, 0.09] }] }));
  check(v.ok, "still valid: the COM projects onto the edge");
  check(v.warnings.some(function (w) { return /from one end of the support edge/.test(w.message); }), "end-of-edge warning expected");
});
test("Invalid: attachment outside the cube and initial attitude through the floor", function () {
  var r = AERIS_TWIN.simulate(cfg({ attachments: [{ id: "m1", label: "Out", mass_kg: 0.1, pos_m: [0.3, 0, 0] }] }));
  check(!r.ok && /outside the cube/.test(r.errors[0].message), "outside the cube");
  r = AERIS_TWIN.simulate(cfg({ attachments: [{ id: "m1", label: "Brass", mass_kg: 1, pos_m: [0.09, 0, 0.18] }], initial: zeroIni({ tilt_deg: -30, reference: "balance" }) }));
  check(!r.ok && r.errors[0].path === "initial", "initial floor contact");
});
test("Invalid: control loop too slow for the dynamics", function () {
  var p = AERIS_TWIN.clone(AERIS_TWIN.NOMINAL); p.a = 0.05; p.m = 0.5; p.fs = 50; p.Jw = 1e-5;
  var v = AERIS_TWIN.validateConfig(cfg({ params: p }));
  check(!v.ok && v.errors.some(function (e) { return e.path === "params.fs"; }), "loop-rate error expected: " + JSON.stringify(v.errors));
});
test("Warnings: loads after the run, failure in a wheel edge mode does not use", function () {
  var v = AERIS_TWIN.validateConfig(cfg({ duration_s: 5, events: [{ id: "E", type: "wheel_failure", wheel: "y", t_s: 1 }], disturbances: [{ id: "T", type: "torque", magnitude_Nm: 0.01, direction: [1, 0, 0], frame: "body", t_start_s: 8, duration_s: 1 }] }));
  check(v.ok, "valid with warnings");
  check(v.warnings.some(function (w) { return /has no effect/.test(w.message) && /Y-wheel/.test(w.message); }), "edge mode Y-wheel warning");
  check(v.warnings.some(function (w) { return /after the run ends/.test(w.message); }), "load-after-run warning");
});

/* ------------------------------------------------------------------ 4. mass properties */
function matNear(A, B, tol, msg) { for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) near(A[i][j], B[i][j], tol, msg + "[" + i + "][" + j + "]"); }
test("Mass properties: bare cube matches the nominal design quantities", function () {
  var c = cfg({}), mp = AERIS_TWIN.massProps(AERIS_TWIN.normalizeConfig(c)), d = AERIS_TWIN.derive(AERIS_TWIN.NOMINAL);
  near(mp.M, 1.8, 1e-12, "mass");
  near(mp.rc[0], 0.09, 1e-12, "COM x"); near(mp.rc[1], 0.09, 1e-12, "COM y"); near(mp.rc[2], 0.09, 1e-12, "COM z");
  rel(mp.edge.Th0, d.Th0e, 1e-12, "Θ about the edge"); rel(mp.edge.l, d.le, 1e-12, "l_e");
  rel(mp.corner.l, d.lc, 1e-12, "l_c"); near(mp.edge.beta, 0, 1e-12, "β");
});
test("Mass properties: point masses, COM and parallel-axis terms computed independently", function () {
  var ats = [{ id: "a", label: "A", mass_kg: 0.25, pos_m: [0.18, 0, 0.18] }, { id: "b", label: "B", mass_kg: 0.1, pos_m: [0.02, 0.15, 0.05] }];
  var c = AERIS_TWIN.normalizeConfig(cfg({ attachments: ats })), mp = AERIS_TWIN.massProps(c), a = 0.18, m0 = 1.8, Jc0 = 0.2 * m0 * a * a;
  var M = m0 + 0.35, rc = [0, 1, 2].map(function (i) { return (m0 * a / 2 + 0.25 * ats[0].pos_m[i] + 0.1 * ats[1].pos_m[i]) / M; });
  near(mp.M, M, 1e-12, "total mass");
  [0, 1, 2].forEach(function (i) { near(mp.rc[i], rc[i], 1e-12, "COM " + i); });
  // inertia about the COM from each part's own inertia + its parallel-axis term about the COM
  var ThC = AERIS_TWIN.vec.steiner(m0, AERIS_TWIN.vec.sub3([a / 2, a / 2, a / 2], rc));
  for (var i = 0; i < 3; i++) ThC[i][i] += Jc0;
  ats.forEach(function (at) { var S = AERIS_TWIN.vec.steiner(at.mass_kg, AERIS_TWIN.vec.sub3(at.pos_m, rc)); for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) ThC[i][j] += S[i][j]; });
  matNear(mp.ThC, ThC, 1e-12, "Θ_C");
  // Steiner identity: Θ_O = Θ_C + M(|r_c|² I − r_c r_cᵀ)
  var S2 = AERIS_TWIN.vec.steiner(M, rc), ThO = ThC.map(function (r, i) { return r.map(function (v, j) { return v + S2[i][j]; }); });
  matNear(mp.ThO, ThO, 1e-12, "Θ_O");
  // a single point mass at (a,0,0) adds m a² about y and z, nothing about x
  var mp0 = AERIS_TWIN.massProps(AERIS_TWIN.normalizeConfig(cfg({}))), mp1 = AERIS_TWIN.massProps(AERIS_TWIN.normalizeConfig(cfg({ attachments: [{ id: "p", label: "P", mass_kg: 0.3, pos_m: [a, 0, 0] }] })));
  near(mp1.ThO[0][0] - mp0.ThO[0][0], 0, 1e-15, "ΔΘ_xx"); near(mp1.ThO[1][1] - mp0.ThO[1][1], 0.3 * a * a, 1e-15, "ΔΘ_yy"); near(mp1.ThO[2][2] - mp0.ThO[2][2], 0.3 * a * a, 1e-15, "ΔΘ_zz");
});
test("Mass properties: base COM offset sets β = atan2(δ, l_e) exactly", function () {
  var mp = AERIS_TWIN.massProps(AERIS_TWIN.normalizeConfig(cfg({ comOffset_m: 0.003 })));
  near(mp.edge.beta, Math.atan2(0.003, 0.18 / Math.SQRT2), 1e-12, "β");
  near(mp.edge.l, Math.hypot(0.003, 0.18 / Math.SQRT2), 1e-12, "l");
});

/* ------------------------------------------------------------------ 5. forces and torques */
test("Force torque: τ = r × F about the pivot, body and world frames agree", function () {
  var top = [0.09, 0.18, 0.18], R0 = AERIS_TWIN.edgeR(0);
  var Lw = { type: "force", magnitude_N: 1, point_m: top, direction: [0, -1, 0], frame: "world" };
  var Lb = { type: "force", magnitude_N: 1, point_m: top, direction: AERIS_TWIN.vec.mtv(R0, [0, -1, 0]), frame: "body" };
  var tw = AERIS_TWIN.loadTorqueBody(Lw, R0), tb = AERIS_TWIN.loadTorqueBody(Lb, R0);
  near(tw[0], 0.18 * Math.SQRT2, 1e-12, "τ_x = a√2·F for a horizontal push at the top edge");
  [0, 1, 2].forEach(function (i) { near(tw[i], tb[i], 1e-12, "frame equivalence " + i); });
  // world-frame check: r_world × F_world equals R τ_body
  var rW = AERIS_TWIN.vec.mv(R0, top), tW = AERIS_TWIN.vec.cross(rW, [0, -1, 0]), tWb = AERIS_TWIN.vec.mv(R0, tw);
  [0, 1, 2].forEach(function (i) { near(tW[i], tWb[i], 1e-12, "world torque " + i); });
});
test("Force effect: pushing the top toward −y tilts the cube toward −y (θ increases)", function () {
  var base = cfg({ controller: { type: "none" }, initial: zeroIni(), duration_s: 1 });
  var push = AERIS_TWIN.clone(base); push.disturbances = [{ id: "F1", type: "force", magnitude_N: 1, point_m: [0.09, 0.18, 0.18], direction: [0, -1, 0], frame: "world", t_start_s: 0, duration_s: 0.05 }];
  var r0 = AERIS_TWIN.simulate(base), r1 = AERIS_TWIN.simulate(push);
  check(r0.samples.cols.theta[5] === 0, "no push: the cube stays at θ = 0");
  check(r1.samples.cols.theta[5] > 1 * DEG, "push: θ(0.1 s) should exceed 1°, got " + r1.samples.cols.theta[5] / DEG);
  near(r1.samples.cols.tauF[0], 0.18 * Math.SQRT2, 1e-5, "recorded applied torque");
});
test("Force effect: a force through the pivot or along the support edge does nothing in edge mode", function () {
  var base = cfg({ controller: { type: "lqr" }, initial: zeroIni({ tilt_deg: 1 }), duration_s: 2 });
  var a = AERIS_TWIN.clone(base); a.disturbances = [{ id: "F1", type: "force", magnitude_N: 5, point_m: [0, 0, 0], direction: [0, 1, 1], frame: "body", t_start_s: 0, duration_s: 2 }];
  var b = AERIS_TWIN.clone(base); b.disturbances = [{ id: "F2", type: "force", magnitude_N: 5, point_m: [0.09, 0.18, 0.18], direction: [1, 0, 0], frame: "body", t_start_s: 0, duration_s: 2 }];
  var r0 = AERIS_TWIN.simulate(base), ra = AERIS_TWIN.simulate(a), rb = AERIS_TWIN.simulate(b);
  near(last(ra.samples.cols.theta), last(r0.samples.cols.theta), 1e-12, "through the pivot");
  near(last(rb.samples.cols.theta), last(r0.samples.cols.theta), 1e-12, "along the edge");
});
test("Force effect: a sustained push changes the result and is recorded", function () {
  var base = cfg({ controller: { type: "lqr" }, initial: zeroIni(), duration_s: 6 });
  var p = AERIS_TWIN.clone(base); p.disturbances = [{ id: "F1", type: "force", magnitude_N: 0.3, point_m: [0.09, 0.18, 0.18], direction: [0, 1, 0], frame: "world", t_start_s: 1, duration_s: 2 }];
  var r0 = AERIS_TWIN.simulate(base), r1 = AERIS_TWIN.simulate(p);
  check(r1.metrics.peakLean_deg > r0.metrics.peakLean_deg + 0.1, "peak lean should grow");
  check(r1.metrics.peakOmega_rpm > r0.metrics.peakOmega_rpm + 100, "wheel should absorb the push");
});
test("Corner mode: world-frame horizontal force produces the expected tilt direction", function () {
  var base = cfg({ mode: "corner", controller: { type: "none" }, initial: zeroIni(), duration_s: 1 });
  var p = AERIS_TWIN.clone(base); p.disturbances = [{ id: "F1", type: "force", magnitude_N: 1, point_m: [0.18, 0.18, 0.18], direction: [1, 0, 0], frame: "world", t_start_s: 0, duration_s: 0.05 }];
  var r = AERIS_TWIN.simulate(p), S = r.samples.cols, k = 5, q = [S.q0[k], S.q1[k], S.q2[k], S.q3[k]];
  var top = AERIS_TWIN.vec.mv(AERIS_TWIN.Q3.rot(q), [0.18, 0.18, 0.18]);
  check(top[0] > 1e-4, "the top vertex should move toward world +x, got " + top[0]);
});

/* ------------------------------------------------------------------ 6. nominal regression vs the independent Python model */
test("Controller design matches the Python reference", function () {
  var D = AERIS_TWIN.design(AERIS_TWIN.NOMINAL);
  [0, 1, 2].forEach(function (i) { rel(D.e.K[i], REF.K[i], 1e-6, "K" + i); });
  rel(D.e.pid.Kp, REF.PID[0], 1e-6, "Kp"); rel(D.e.pid.Ki, REF.PID[1], 1e-6, "Ki"); rel(D.e.pid.Kd, REF.PID[2], 1e-6, "Kd");
});
["pid", "lqr", "adp"].forEach(function (c) {
  test("E1 (2° step, 10 s) " + c + ": energy, peak and final wheel speed match Python", function () {
    var r = AERIS_TWIN.simulate(cfg({ controller: { type: c }, initial: zeroIni({ tilt_deg: 2 }), duration_s: 10 })), ref = REF["E1_" + c];
    rel(r.metrics.energy_J, ref.E, 1e-4, "energy"); rel(r.metrics.peakOmega_rpm, ref.wpk_rpm, 1e-4, "peak Ω");
    near(r.metrics.finalOmega_rpm.x, ref.wend_rpm, 0.01, "final Ω"); check(r.outcome.code === "recovered", "recovered");
  });
  test("E3 (0.05 N·m for 1–6 s) " + c + ": energy and wheel speeds match Python", function () {
    var r = AERIS_TWIN.simulate(cfg({ controller: { type: c }, initial: zeroIni(), duration_s: 15, disturbances: [{ id: "L1", type: "torque", magnitude_Nm: 0.05, direction: [1, 0, 0], frame: "body", t_start_s: 1, duration_s: 5 }] })), ref = REF["E3_" + c];
    rel(r.metrics.energy_J, ref.E, 1e-4, "energy"); rel(r.metrics.peakOmega_rpm, ref.wpk_rpm, 1e-4, "peak Ω");
    near(r.metrics.finalOmega_rpm.x, ref.wend_rpm, 0.01, "final Ω");
  });
});
test("E2 (3 mm COM offset, 20 s): LQR parks the wheel, adaptive learns β (exact geometry, ≤ 0.1 % from v1)", function () {
  var l = AERIS_TWIN.simulate(cfg({ controller: { type: "lqr" }, initial: zeroIni(), comOffset_m: 0.003, duration_s: 20 }));
  var a = AERIS_TWIN.simulate(cfg({ controller: { type: "adp" }, initial: zeroIni(), comOffset_m: 0.003, duration_s: 20 }));
  rel(l.metrics.finalOmega_rpm.x, REF.E2_lqr.wend_rpm, 1e-3, "LQR parked wheel speed");
  rel(l.metrics.energy_J, REF.E2_lqr.E, 1e-3, "LQR energy");
  near(last(a.samples.cols.betahat) / DEG, REF.E2_adp.bh_end_deg, 0.002, "adaptive β̂");
  rel(a.metrics.energy_J, REF.E2_adp.E, 1e-3, "adaptive energy");
  check(l.outcome.code === "recovered" && a.outcome.code === "recovered", "both recover");
});
test("Corner: X-wheel failure falls ≈0.79 s after the fault without reconfiguration, holds with it", function () {
  function run(rc) { return AERIS_TWIN.simulate(cfg({ mode: "corner", controller: { type: "lqr", reconfigureOnFailure: rc }, initial: zeroIni({ tilt_deg: 2, azimuth_deg: 0.7 / DEG }), duration_s: 10, events: [{ id: "E1", type: "wheel_failure", wheel: "x", t_s: 0.1 }] })); }
  var no = run(false), yes = run(true);
  check(no.outcome.code === "fallen", "without reconfiguration: fallen"); near(no.metrics.fellAt_s - 0.1, 0.79, 0.05, "time from fault to fall");
  check(yes.outcome.code === "recovered", "with reconfiguration: recovered");
  check(/Yaw is not controlled/.test(yes.outcome.notes.join(" ")), "yaw note after failure");
});

/* ------------------------------------------------------------------ 7. determinism, serialisation, independence */
test("Determinism: identical configuration → identical samples; the seed changes noisy runs", function () {
  var c = cfg({ estimator: { type: "kf" }, initial: zeroIni({ tilt_deg: 1 }), duration_s: 3, seed: 11 });
  var a = AERIS_TWIN.simulate(c), b = AERIS_TWIN.simulate(AERIS_TWIN.clone(c)), d = AERIS_TWIN.simulate(Object.assign(AERIS_TWIN.clone(c), { seed: 12 }));
  check(JSON.stringify(a.samples) === JSON.stringify(b.samples), "same seed must reproduce");
  check(JSON.stringify(a.samples) !== JSON.stringify(d.samples), "different seed must differ");
});
test("Serialisation: config → JSON → config reproduces the run exactly", function () {
  var c = cfg({ controller: { type: "adp" }, comOffset_m: 0.002, attachments: [{ id: "m1", label: "Clip", mass_kg: 0.02, pos_m: [0.1, 0.05, 0.17] }], disturbances: [{ id: "F1", type: "force", magnitude_N: 0.2, point_m: [0.09, 0.18, 0.18], direction: [0, 1, 0], frame: "world", t_start_s: 1, duration_s: 0.5 }], duration_s: 4 });
  var a = AERIS_TWIN.simulate(c), b = AERIS_TWIN.simulate(JSON.parse(JSON.stringify(a.config)));
  check(JSON.stringify(a.samples) === JSON.stringify(b.samples), "samples");
  check(JSON.stringify(a.metrics) === JSON.stringify(b.metrics), "metrics");
});
test("Independence: editing a config after a run does not change that run", function () {
  var c = cfg({ duration_s: 2 }), r = AERIS_TWIN.simulate(c), before = JSON.stringify(r.config);
  c.params.m = 3; c.attachments.push({ id: "x", label: "x", mass_kg: 1, pos_m: [0.1, 0.1, 0.1] });
  check(JSON.stringify(r.config) === before, "stored config must be a snapshot");
});
test("Samples: timestamps start at 0, are increasing and finite", function () {
  var r = AERIS_TWIN.simulate(cfg({ duration_s: 3 })), t = r.samples.cols.t;
  check(t[0] === 0, "first sample at t = 0"); near(last(t), 3, 1e-9, "last sample at the end of the window");
  for (var i = 1; i < t.length; i++) if (!(t[i] > t[i - 1])) { check(false, "non-increasing time at " + i); break; }
  Object.keys(r.samples.cols).forEach(function (k) { check(r.samples.cols[k].length === t.length, "column " + k + " length"); check(r.samples.cols[k].every(isFinite), "column " + k + " finite"); check(!!r.samples.units[k], "unit for " + k); });
});

/* ------------------------------------------------------------------ 8. samples agree with the equations shown in the Maths panel */
test("Maths consistency: recorded command equals −K·x(t) at the same sample (edge, LQR, ideal sensing)", function () {
  var r = AERIS_TWIN.simulate(cfg({ controller: { type: "lqr" }, initial: zeroIni({ tilt_deg: 2 }), comOffset_m: 0.002, duration_s: 3 })), S = r.samples.cols, K = r.design.tilt.K, ref = r.design.betaRef, worst = 0;
  for (var i = 0; i < S.t.length - 1; i++) { var u = -(K[0] * (S.theta[i] + ref) + K[1] * S.thetadot[i] + K[2] * S.omega_x[i]); worst = Math.max(worst, Math.abs(u - S.Tc_x[i])); }
  check(worst < 2e-5, "max |u − Tc| = " + worst);
});
test("Maths consistency: gravity torque column equals M·g·l·sin(e) at every sample", function () {
  var r = AERIS_TWIN.simulate(cfg({ controller: { type: "pid" }, initial: zeroIni({ tilt_deg: 1 }), attachments: [{ id: "m1", label: "Clip", mass_kg: 0.05, pos_m: [0.09, 0.02, 0.18] }], duration_s: 2 })), S = r.samples.cols, d = r.mp, worst = 0;
  var Mgl = d.M * 9.81 * d.edge.l;
  for (var i = 0; i < S.t.length; i++) worst = Math.max(worst, Math.abs(Mgl * Math.sin(S.e[i]) - S.tauG[i]));
  check(worst < 2e-6, "max deviation " + worst);
});
test("Energy column is non-decreasing and ends at the reported energy", function () {
  var r = AERIS_TWIN.simulate(cfg({ mode: "corner", initial: zeroIni({ tilt_deg: 2, azimuth_deg: 30 }), duration_s: 4 })), E = r.samples.cols.E;
  for (var i = 1; i < E.length; i++) if (E[i] < E[i - 1] - 1e-9) { check(false, "energy decreased at row " + i); break; }
  rel(E[E.length - 1], r.metrics.energy_J, 1e-5, "final energy");
});

/* ------------------------------------------------------------------ report */
var pass = results.filter(function (r) { return r.ok; }).length;
results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name); r.msgs.forEach(function (m) { console.log("     " + m); }); });
console.log("\n" + pass + " / " + results.length + " numerical tests passed");
if (typeof process !== "undefined") process.exitCode = pass === results.length ? 0 : 1;

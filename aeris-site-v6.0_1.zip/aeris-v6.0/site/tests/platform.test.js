/* Tests for the platform data layer: design tokens, experiment IDs, schema
   normalisation, the event timeline and backward compatibility with records
   saved by site v2.   Run with:  node tests/platform.test.js */
"use strict";
var path = require("path"), fs = require("fs");
global.window = {};
var J = function (p) { return path.join(__dirname, "..", "js", p); };
var TOK = require(J("platform/tokens.js"));
var IDS = require(J("platform/ids.js")); global.AERIS_IDS = IDS;
var TWIN = require(J("core.js")); global.AERIS_TWIN = TWIN;
var SCHEMA = require(J("platform/schema.js")); global.AERIS_SCHEMA = SCHEMA;
var EVENTS = require(J("platform/events.js")); global.AERIS_EVENTS = EVENTS;
var RUNS = require(J("runs.js"));
var results = [], cur;
function test(n, f) { cur = { name: n, ok: true, msgs: [] }; try { RUNS.useStorage(RUNS.memoryStore(), false); f(); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); } results.push(cur); }
function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
function cfg(mode, o) { var c = TWIN.defaultConfig(mode); Object.keys(o || {}).forEach(function (k) { c[k] = o[k]; }); return c; }
var ini0 = { tilt_deg: 0, rate_dps: 0, azimuth_deg: 0, reference: "geometric" };

/* ------------------------------------------------------------ colour tokens */
test("Colour tokens: CSS custom properties match js/platform/tokens.js", function () {
  var css = fs.readFileSync(path.join(__dirname, "..", "css", "base.css"), "utf8");
  Object.keys(TOK.CSS_VARS).forEach(function (k) {
    var m = new RegExp(k.replace(/[-]/g, "\\-") + ":\\s*(#[0-9a-fA-F]{6})").exec(css);
    check(m && m[1].toLowerCase() === TOK.CSS_VARS[k].toLowerCase(), k + " in base.css is " + (m && m[1]) + ", tokens.js says " + TOK.CSS_VARS[k]);
  });
});
test("Controller colours are neutral: distinct, never the brand lime or a status colour", function () {
  var C = TOK.CONTROLLER_ORDER.map(function (k) { return TOK.controller(k).color.toLowerCase(); });
  check(new Set(C).size === 3, "controllers must have three distinct colours");
  var reserved = [TOK.color.brand].concat(Object.keys(TOK.color.status).map(function (k) { return TOK.color.status[k]; })).map(function (x) { return x.toLowerCase(); });
  C.forEach(function (c) { check(reserved.indexOf(c) < 0, c + " is a reserved brand/status colour"); });
  check(TOK.controller("adp").color !== TOK.color.brand, "Adaptive must not be drawn in the brand lime");
  var m = TOK.CONTROLLER_ORDER.map(function (k) { return TOK.controller(k).marker; });
  check(new Set(m).size === 3, "each controller needs its own marker shape (colour is never the only channel)");
});
test("Controller names are technically accurate (COM-adaptive LQR)", function () {
  check(TOK.controller("adp").name === "COM-adaptive LQR", "adaptive controller name: " + TOK.controller("adp").name);
  check(RUNS.CTRL_NAMES.adp === "COM-adaptive LQR", "run names use the same name");
});
test("Outcome status mapping: green = recovered, amber = warning states, red = failure", function () {
  check(TOK.outcome("recovered").tone === "stable", "recovered → stable");
  check(TOK.outcome("drifting").tone === "warning" && TOK.outcome("not_settled").tone === "warning", "drifting / not settled → warning");
  check(TOK.outcome("fallen").tone === "failure" && TOK.outcome("invalid").tone === "failure", "fallen / invalid → failure");
  ["recovered", "drifting", "not_settled", "fallen", "invalid"].forEach(function (c) { check(!!TOK.outcome(c).icon, c + " has an icon (never colour alone)"); });
});

/* ------------------------------------------------------------ experiment IDs */
test("Experiment IDs: AERIS-EXP-###### format, ranges and legacy ARC ids", function () {
  check(IDS.format(7) === "AERIS-EXP-000007", "format");
  check(IDS.parse("AERIS-EXP-004287") === 4287, "parse");
  check(!IDS.isValid("ARC-EXP-0001") && !IDS.isValid("AERIS-EXP-12"), "invalid ids rejected");
  check(IDS.fromLegacy("ARC-EXP-0003") === "AERIS-EXP-000003", "legacy ARC id maps to the same number");
  check(IDS.kind("AERIS-EXP-000003") === "reference" && IDS.kind("AERIS-EXP-000010") === "example" && IDS.kind("AERIS-EXP-000100") === "local", "kinds");
  check(IDS.forExample("example-regression") === "AERIS-EXP-000010", "fixed example id");
});
test("Experiment IDs: the local counter persists and never reuses an ID in the library", function () {
  var s = RUNS.memoryStore(); IDS.useStore(s);
  var a = IDS.next([]), b = IDS.next([]);
  check(IDS.parse(a) >= 100 && IDS.parse(b) === IDS.parse(a) + 1, "sequential from 000100: " + a + ", " + b);
  var c = IDS.next(["AERIS-EXP-000500"]);
  check(IDS.parse(c) === 501, "skips past ids already in use: " + c);
  IDS.useStore(s); check(IDS.parse(IDS.next([])) === 502, "counter survives (stored in " + IDS.KEY + ")");
});
test("New runs carry an experiment ID; examples use their fixed ID", function () {
  var r = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { duration_s: 2 })));
  check(IDS.isValid(r.experiment_id) && IDS.kind(r.experiment_id) === "local", "user run id: " + r.experiment_id);
  var ex = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { duration_s: 2 })), { id: "example-edge-push", source: "example" });
  check(ex.experiment_id === "AERIS-EXP-000012" && ex.collection === "example", "example id / collection: " + ex.experiment_id + " " + ex.collection);
});

/* ------------------------------------------------------------ schema revision 1.1 */
test("Run records (revision 1.1): origin, validation state, timeline and definitions are present", function () {
  var r = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { duration_s: 3 })));
  check(r.schema === "aeris-run/1" && r.schema_revision === "1.1", "schema " + r.schema + " rev " + r.schema_revision);
  check(r.source === "simulation" && r.origin.kind === "simulation" && r.origin.engine === "aeris-twin-js" && r.origin.adapter === "local-simulator", "origin");
  check(r.validation.status === "nominal" && /nominal/i.test(r.provenance), "validation state recorded as nominal");
  check(r.timeline && Array.isArray(r.timeline.events) && r.timeline.events.length >= 1, "timeline events");
  check(r.definitions.events && r.definitions.events.saturation, "event definitions saved with the run");
  ["rmsLean_deg", "effort_Nms", "speedLimited_s", "omegaMargin_frac"].forEach(function (k) { check(typeof r.metrics[k] === "number" && isFinite(r.metrics[k]), "metric " + k); });
});
test("Backward compatibility: a v2 record (revision 1.0) is upgraded on import, samples untouched", function () {
  var r = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { controller: { type: "pid" }, initial: ini0, comOffset_m: 0.003, duration_s: 4 })));
  var v1 = JSON.parse(JSON.stringify(r));
  ["schema_revision", "experiment_id", "collection", "origin", "validation", "group", "timeline"].forEach(function (k) { delete v1[k]; });
  delete v1.definitions.events; v1.source = "imported";
  var samples = JSON.stringify(v1.samples);
  var p = RUNS.parseImport(JSON.stringify(v1));
  check(p.errors.length === 0 && p.runs.length === 1, "imports: " + p.errors.join(" "));
  var u = p.runs[0];
  check(u.schema_revision === "1.1" && IDS.isValid(u.experiment_id), "upgraded to 1.1 with id " + u.experiment_id);
  check(u.collection === "imported" && u.source === "simulation" && u.origin.kind === "simulation", "legacy source value moved to collection");
  check(u.timeline && u.timeline.rebuilt === true && u.timeline.events.some(function (e) { return e.type === "speed_risk" || e.type === "termination"; }), "timeline rebuilt from recorded samples");
  check(JSON.stringify(u.samples) === samples, "samples unchanged by the upgrade");
});
test("Backward compatibility: runs saved in browser storage by v2 get IDs once and keep them", function () {
  var store = RUNS.memoryStore(); RUNS.useStorage(store, true);
  var r = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { duration_s: 2 })));
  ["schema_revision", "experiment_id", "collection", "origin", "validation", "group", "timeline"].forEach(function (k) { delete r[k]; });
  store.setItem(RUNS.KEYS.run + r.id, JSON.stringify(r));
  store.setItem(RUNS.KEYS.index, JSON.stringify([{ id: r.id, name: r.name, created: r.created, mode: "edge" }]));
  RUNS.useStorage(store, true);
  var first = RUNS.list()[0].experiment_id;
  check(IDS.isValid(first), "migrated id: " + first);
  RUNS.useStorage(store, true);
  check(RUNS.list()[0].experiment_id === first && RUNS.load(r.id).record.experiment_id === first, "id is stable across reloads");
});
test("Import: an experiment-ID clash with a different run gets a new ID and keeps the original", function () {
  var a = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { duration_s: 2 }))); RUNS.save(a);
  var b = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { duration_s: 3 }))); b.experiment_id = a.experiment_id;
  var res = RUNS.importRuns(RUNS.parseImport(JSON.stringify(b)).runs);
  var got = res.added[0];
  check(got && got.experiment_id !== a.experiment_id && got.original_experiment_id === a.experiment_id, "re-issued: " + (got && got.experiment_id));
});
test("Import: malformed timelines and hardware recordings are rejected with explanations", function () {
  var r = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { duration_s: 2 })));
  var bad = JSON.parse(JSON.stringify(r)); bad.timeline = { events: [{ type: "fall" }] };
  check(RUNS.parseImport(JSON.stringify(bad)).errors.some(function (e) { return /timeline/.test(e); }), "timeline error");
  var hw = JSON.parse(JSON.stringify(r)); hw.origin = { kind: "hardware" };
  check(RUNS.parseImport(JSON.stringify(hw)).errors.some(function (e) { return /hardware recording/.test(e); }), "hardware data is not a simulated run");
});
test("CSV export names the experiment, the source and the validation state", function () {
  var r = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { duration_s: 2 })));
  var head = RUNS.toCSV(r).split("\n").slice(0, 6).join("\n");
  check(head.indexOf(r.experiment_id) >= 0 && /source: simulation/.test(head) && /validation: nominal/.test(head), head);
});

/* ------------------------------------------------------------ event timeline */
test("Timeline: the regression case over 20 s shows saturation risk, the speed limit, saturation and the fall in order", function () {
  var r = TWIN.simulate(cfg("edge", { controller: { type: "pid" }, initial: ini0, comOffset_m: 0.003, duration_s: 20 }));
  var types = r.timeline.events.map(function (e) { return e.type; });
  var at = function (ty) { return r.timeline.events.filter(function (e) { return e.type === ty; })[0]; };
  check(at("speed_risk") && at("speed_limit") && at("saturation") && at("fall") && at("termination"), "types: " + types.join(","));
  check(at("speed_risk").t < at("speed_limit").t && at("speed_limit").t <= at("fall").t, "order");
  check(Math.abs(at("fall").t - r.metrics.fellAt_s) < 1e-9, "fall event at the fall time");
  check(r.timeline.events.every(function (e) { return ["info", "stable", "warning", "failure"].indexOf(e.severity) >= 0; }), "severities");
});
test("Timeline: disturbances, wheel failures, reconfiguration and recovery are listed; failed wheels are not called saturated", function () {
  var r = TWIN.simulate(cfg("corner", { duration_s: 10, events: [{ id: "E1", type: "wheel_failure", wheel: "x", t_s: 0.1 }], disturbances: [{ id: "F1", type: "force", magnitude_N: 0.2, point_m: [0.18, 0.18, 0.18], direction: [1, 0, 0], frame: "world", t_start_s: 5, duration_s: 0.5 }] }));
  var E = r.timeline.events;
  check(E.some(function (e) { return e.type === "wheel_failure" && e.wheel === "x" && e.t === 0.1; }), "failure");
  check(E.some(function (e) { return e.type === "controller_mode"; }), "reconfiguration");
  check(E.some(function (e) { return e.type === "disturbance" && e.t === 5 && e.t_end === 5.5; }), "disturbance window");
  check(!E.some(function (e) { return e.type === "saturation" && e.wheel === "x" && e.t >= 0.1; }), "no saturation reported for the failed wheel");
  if (r.outcome.code === "recovered") check(E.some(function (e) { return e.type === "recovered" && Math.abs(e.t - r.metrics.settle_s) < 1e-9; }), "recovery at t_s");
});
test("Timeline: an estimator warning appears for gyro-only integration (drift) and not for ideal sensing", function () {
  var g = TWIN.simulate(cfg("edge", { estimator: { type: "gyro" }, duration_s: 10, initial: { tilt_deg: 1, rate_dps: 0, azimuth_deg: 0, reference: "geometric" } }));
  var i = TWIN.simulate(cfg("edge", { estimator: { type: "ideal" }, duration_s: 10 }));
  check(g.timeline.events.some(function (e) { return e.type === "estimator_warning"; }), "gyro-only should warn");
  check(!i.timeline.events.some(function (e) { return e.type === "estimator_warning"; }), "ideal never warns");
});

var pass = results.filter(function (r) { return r.ok; }).length;
results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
console.log("\n" + pass + " / " + results.length + " platform tests passed");
process.exit(pass === results.length ? 0 : 1);

"""Browser end-to-end checks for v6.0 (Playwright + Chromium; bounded waits on what the page shows).

Run:   python3 tests/browser_v6.py            (starts a static server, and the AERIS backend twice — AERIS_AUTH=local and
                                                AERIS_AUTH=jwt with the development identity fixture — on free local
                                                ports with temporary databases)
       python3 tests/browser_v6.py --shots    (also writes screenshots to tests/screenshots/)

Python for the backend: $AERIS_PYTHON, else backend/.venv/bin/python, else ../.venv/bin/python, else this interpreter.
When the backend cannot start, its checks are reported as NOT RUN (exit code 2); the rest still runs.

What stands in for hardware here, and only here:
  * the SYNTHETIC device: the firmware core compiled to WebAssembly (firmware/wasm), in the page — labelled synthetic;
  * a SCRIPTED serial port standing in for navigator.serial: it is backed by that synthetic device, or it plays an
    ARTIFICIAL test board (silent like a board without AERIS firmware; after the scripted installation it answers
    with the hello the release manifest expects). No physical board is involved;
  * a SCRIPTED flasher served in place of vendor/esptool-js.min.js: it records what the installer would write.
Nothing here measures or balances a physical cube.

Covers: the virtual cube stays the default (hero, navigation, nothing of the Connect stack loaded on the virtual pages);
Build (readiness, BOM with sources, sizing, downloads that exist with their SHA-256 and the reasons for those that do
not, steps with blocked reasons, notes kept per revision, a revision change explained); Connect with the synthetic
device (pairing needs ARM, diagnostics, calibration, configuration, self-test, experiment with ARM, Stop, recording,
exports, gates); Web Serial with the scripted port (the same flow over the serial transport; the installer refuses a
synthetic device); the installer on a blank artificial board (development-key consent, image hashes, scripted writing,
identity afterwards, a tampered image refused before writing); the backend in local mode (pairing through the relay,
calibration from the command log, profiles, configurations, experiment, recording, Simulate My Cube, comparison with
its evidence status, opening the simulation in AERIS Lab); the backend in jwt mode (development token only on this
computer); keyboard use of the device tabs; phone widths (375 and 390 px) without horizontal scrolling.
"""
import asyncio, hashlib, json, os, pathlib, socket, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request
import functools, http.server
from playwright.async_api import async_playwright

SITE = pathlib.Path(__file__).resolve().parent.parent
REPO = SITE.parent
BACKEND = REPO / "backend"
SHOTS = "--shots" in sys.argv
SHOT_DIR = SITE / "tests" / "screenshots"
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
FILE_URL = (SITE / "index.html").as_uri()
results = []
NOT_RUN = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else "  →  " + str(detail)[:900]), flush=True)


def not_run(name, why):
    NOT_RUN.append((name, why))
    print("NOT RUN " + name + "  →  " + why, flush=True)


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def backend_python():
    for c in (os.environ.get("AERIS_PYTHON"), BACKEND / ".venv" / "bin" / "python", REPO.parent / ".venv" / "bin" / "python"):
        if c and pathlib.Path(c).exists():
            return str(c)
    return sys.executable


def wait_http(url, timeout=60):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                return r.status == 200
        except Exception:
            time.sleep(0.2)
    return False


def sha256(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


async def shot(page, name):
    if SHOTS:
        SHOT_DIR.mkdir(parents=True, exist_ok=True)
        await page.screenshot(path=str(SHOT_DIR / f"v6-{name}.png"))


class Static:
    """The site on http://127.0.0.1:PORT (a secure context: Web Serial is offered)."""
    def __init__(self):
        self.port = free_port()
        class Quiet(http.server.SimpleHTTPRequestHandler):
            def log_message(self, *a, **k):
                pass
        h = functools.partial(Quiet, directory=str(SITE))
        self.srv = http.server.ThreadingHTTPServer(("127.0.0.1", self.port), h)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.port}/index.html"

    def close(self):
        self.srv.shutdown()


class Backend:
    def __init__(self, env_extra=None):
        self.port = free_port()
        self.tmp = tempfile.mkdtemp(prefix="aeris-v6-browser-")
        env = dict(os.environ, PYTHONPATH=str(BACKEND))
        for k in [k for k in env if k.startswith("AERIS_")]:
            env.pop(k)
        env.update(env_extra or {})
        self.log = open(os.path.join(self.tmp, "backend.log"), "w")
        self.proc = subprocess.Popen([backend_python(), "-m", "aeris_backend.api.main", "--port", str(self.port), "--db", os.path.join(self.tmp, "aeris.sqlite3"),
                                      "--telemetry-dir", os.path.join(self.tmp, "tel"), "--serve-site", str(SITE), "--workers", "1", "--log-level", "warning"],
                                     cwd=str(BACKEND), env=env, stdout=self.log, stderr=subprocess.STDOUT)
        self.ok = wait_http(f"http://127.0.0.1:{self.port}/api/v1/health")
        self.url = f"http://127.0.0.1:{self.port}/"

    def close(self):
        self.proc.terminate()
        try:
            self.proc.wait(10)
        except subprocess.TimeoutExpired:
            self.proc.kill()
        self.log.close()

    def tail(self):
        try:
            return open(os.path.join(self.tmp, "backend.log")).read()[-1500:]
        except OSError:
            return ""


# ---------------------------------------------------------------------------------------------------------------- doubles
SERIAL_MOCK = r"""(() => {
  /* TEST DOUBLE for navigator.serial (tests/browser_v6.py): a scripted port. mode "synthetic": backed by the AERIS
     synthetic device (WebAssembly) in this page; "blank": an artificial board that says nothing in the AERIS protocol;
     "release": the artificial board after the scripted installation, answering with the release manifest's hello. */
  const TE = new TextEncoder(), TD = new TextDecoder();
  function crc32(b) { let crc = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) { let c = (crc ^ b[i]) & 0xFF; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xEDB88320 : c >>> 1; crc = (crc >>> 8) ^ c; } return (crc ^ 0xFFFFFFFF) >>> 0; }
  function frame(o) { const t = JSON.stringify(o), js = TE.encode(t); return TE.encode(t + "\t" + crc32(js).toString(16).padStart(8, "0") + "\n"); }
  const M = window.__serialMock = { mode: "synthetic", requests: 0, opened: 0, closed: 0, dev: null, port: null, filters: null, releaseHello: null, flash: [] };
  class FakePort {
    constructor() { this.readable = null; this.writable = null; this._ctl = null; this._timer = null; this._buf = ""; }
    getInfo() { return { usbVendorId: 0x303A, usbProductId: 0x1001 }; }
    async open(opts) {
      M.opened++; const self = this; M.port = this;
      this.readable = new ReadableStream({ start(c) { self._ctl = c; }, cancel() { self._ctl = null; } });
      this.writable = new WritableStream({ write(chunk) { self._in(chunk); } });
      if (M.mode === "synthetic") await this._synth();
    }
    async close() { M.closed++; if (this._timer) clearInterval(this._timer); this._timer = null; if (M.dev && M.mode === "synthetic") M.dev.linkDown(0); try { if (this._ctl) this._ctl.close(); } catch (e) {} this._ctl = null; this.readable = null; this.writable = null; }
    _out(b) { if (this._ctl) this._ctl.enqueue(new Uint8Array(b)); }
    async _synth() {
      await AERIS_LAZY.load(["firmware/synthetic/aeris-device.wasm.js"]);
      if (!M.dev) {
        const bin = atob(window.AERIS_SYNTH_WASM_B64), bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        M.dev = await AERIS_SYNTH.create({ wasm: bytes, plant: AERIS_DATA.plants.edge, deviceId: "synthetic-serial-test", onOut: (link, b) => { if (M.port) M.port._out(b); } });
      }
      M.dev.linkUp(0);
      let last = performance.now();
      this._timer = setInterval(() => { const now = performance.now(), dt = Math.min(50, now - last); last = now; M.dev.advance(dt * 1000); }, 10);
    }
    _in(chunk) {
      if (M.mode === "synthetic") { if (M.dev) M.dev.input(0, new Uint8Array(chunk)); return; }
      if (M.mode !== "release") return;
      this._buf += TD.decode(chunk);
      let i;
      while ((i = this._buf.indexOf("\n")) >= 0) {
        const line = this._buf.slice(0, i); this._buf = this._buf.slice(i + 1);
        let m; try { m = JSON.parse(line.slice(0, line.lastIndexOf("\t"))); } catch (e) { continue; }
        if (m.kind === "host_hello") {
          this._out(frame(M.releaseHello));
          this._out(frame({ kind: "state", state: "DISARMED", reason: "boot complete; motors disabled", faults: null, latched: null, config_hash: null, mode: null, actuation_permitted: false, experiment: null, waiting: null, task: null, link_lost: false }));
        }
      }
    }
  }
  Object.defineProperty(navigator, "serial", { configurable: true, value: { requestPort: async (o) => { M.requests++; M.filters = o && o.filters || null; return new FakePort(); }, getPorts: async () => [] } });
})();"""

SCRIPTED_ESPTOOL = r"""/* TEST DOUBLE served in place of vendor/esptool-js.min.js (tests/browser_v6.py): a scripted flasher. It reports a chip
   and a flash size and records what would be written; it writes nothing anywhere. */
var AERIS_ESPTOOL = (function () {
  var M = window.__serialMock;
  function Transport(port) { this.port = port; }
  Transport.prototype.disconnect = function () { return Promise.resolve(); };
  function ESPLoader(o) { this.o = o; this.chip = null; }
  ESPLoader.prototype.main = function () { this.chip = { CHIP_NAME: M.chip || "ESP32-S3" }; M.flash.push({ step: "main" }); return Promise.resolve(this.chip.CHIP_NAME + " (scripted test flasher)"); };
  ESPLoader.prototype.detectFlashSize = function () { M.flash.push({ step: "flash-size" }); return Promise.resolve(M.flashSize || "8MB"); };
  ESPLoader.prototype.writeFlash = function (opt) {
    M.flash.push({ step: "write", parts: opt.fileArray.map(function (f) { return { address: f.address, bytes: f.data.length }; }), flashSize: opt.flashSize, eraseAll: opt.eraseAll });
    opt.fileArray.forEach(function (f, i) { opt.reportProgress(i, f.data.length, f.data.length); });
    M.mode = "release";
    return Promise.resolve();
  };
  ESPLoader.prototype.after = function (m) { M.flash.push({ step: "after", mode: m }); return Promise.resolve(); };
  return { Transport: Transport, ESPLoader: ESPLoader, scripted: true };
})();"""


# ---------------------------------------------------------------------------------------------------------------- helpers
async def new_page(br, w=1440, h=950, init=None, **kw):
    ctx = await br.new_context(viewport={"width": w, "height": h}, reduced_motion="reduce", accept_downloads=True, **kw)
    if init:
        await ctx.add_init_script(init)
    page = await ctx.new_page()
    page.errors = []
    page.requested = []
    page.on("pageerror", lambda e: page.errors.append(str(e)))
    page.on("console", lambda m: page.errors.append("console: " + m.text) if m.type == "error" else None)
    page.on("request", lambda r: page.requested.append(r.url))
    return ctx, page


# the device's estimate has settled near the start position (the device refuses to start above the recipe's tilt_start_deg)
SETTLED = "(() => { const L = ConnectPage._state.live.lean, n = L.length; return n > 10 && L.slice(-10).every(x => isFinite(x) && x < 2.0); })()"


async def idle(page, timeout=120):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if not await page.evaluate("ConnectPage._state.busy"):
            return True
        await page.wait_for_timeout(100)
    return False


async def status(page):
    return await page.evaluate("(() => { const s = document.getElementById('cnStatus'); return {tone: s.className.replace('cn-status', '').trim(), text: s.textContent}; })()")


async def wait_for(page, js, timeout=30):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            if await page.evaluate(js):
                return True
        except Exception:
            pass
        await page.wait_for_timeout(150)
    return False


async def act(page, selector, timeout=120):
    await page.click(selector)
    await page.wait_for_timeout(50)
    return await idle(page, timeout)


async def tab(page, name):
    await page.click(f"#cnTab-{name}")
    await page.wait_for_timeout(120)


async def full_local_flow(page, label, arm, spin, face, hold):
    """pair → diagnostics → calibration → configuration → self-test → recording → experiment with ARM → stop recording.
    arm/spin/face/hold: how this test presses the device's local controls (the synthetic device's hands)."""
    out = {}
    await page.click('[data-act="pair"]')
    await page.wait_for_timeout(1200)
    out["waits_for_arm"] = (await status(page))["text"].startswith("Press ARM") and not await page.evaluate("ConnectPage._state.drv.paired()")
    await arm()
    await idle(page)
    out["paired"] = await page.evaluate("ConnectPage._state.drv.paired()") and (await status(page))["text"] == "Paired."
    await act(page, '[data-act="diag"]')
    out["diag"] = await page.inner_text("#cnPanel")
    await tab(page, "calibrate")
    await act(page, '[data-act="cal-imu"]')
    for f in ("+z", "+x"):
        await face(f)
        await page.select_option("#cnCalFace", f)
        await act(page, '[data-act="cal-axes"]')
    await page.click('[data-act="cal-enc"]')
    await page.wait_for_timeout(1500)
    await spin()
    await idle(page)
    await act(page, '[data-act="cal-compute"]')
    out["cal"] = await page.evaluate("(() => { const c = ConnectPage._state.calibration; return c && {to_body: c.imu.to_body, wheels: c.wheel_directions_confirmed, ref: ConnectPage._state.calRef}; })()")
    await tab(page, "configure")
    out["apply_disabled_before"] = await page.evaluate("document.querySelector('[data-act=\"cfg-apply\"]').disabled")
    await act(page, '[data-act="cfg-build"]')
    await act(page, '[data-act="cfg-apply"]')
    await act(page, '[data-act="selftest"]')
    out["ready"] = await page.evaluate("(ConnectPage._state.drv.state() || {}).state")
    await tab(page, "record")
    await act(page, '[data-act="rec-start"]')
    await tab(page, "experiment")
    await hold()
    out["settled"] = await wait_for(page, SETTLED, 20)
    await page.fill("#cnDur", "3")
    out["req_enabled"] = await wait_for(page, "!document.querySelector('[data-act=\"exp-req\"]').disabled", 10)
    if not out["req_enabled"]:
        out["gates"] = await page.inner_text("#cnPanel")
        out["state_now"] = await page.evaluate("ConnectPage._state.drv.state()")
        return out
    await page.click('[data-act="exp-req"]')
    await page.wait_for_timeout(1500)
    out["running_before_arm"] = await page.evaluate("(ConnectPage._state.drv.state() || {}).state")
    await arm()
    out["balancing"] = await wait_for(page, "(ConnectPage._state.drv.state() || {}).state === 'BALANCING'", 10)
    await idle(page, 60)
    out["exp"] = await page.evaluate("ConnectPage._state.exp && {status: ConnectPage._state.exp.status, result: ConnectPage._state.exp.result}")
    out["exp_status"] = await status(page)
    out["after_state"] = await page.evaluate("(ConnectPage._state.drv.state() || {}).state")
    out["req_disabled_after"] = await page.evaluate("document.querySelector('[data-act=\"exp-req\"]') ? document.querySelector('[data-act=\"exp-req\"]').disabled : null")
    await tab(page, "record")
    await act(page, '[data-act="rec-stop"]')
    out["recording"] = await page.evaluate("(() => { const r = ConnectPage._state.recording; return r && r.document && {frames: r.document.samples.cols.t.length, synthetic: r.document.synthetic, kind: r.document.device.kind, trust: r.document.provenance.trust, config: r.document.provenance.device_link.config_hash}; })()")
    return out


# ---------------------------------------------------------------------------------------------------------------- the checks
async def virtual_first(br):
    ctx, page = await new_page(br)
    await page.goto(FILE_URL, wait_until="load")
    await page.wait_for_timeout(1500)
    cta = await page.evaluate("[...document.querySelectorAll('#view-home .hero-cta a')].map(a => [a.textContent.trim().replace(/\\s+/g, ' '), a.getAttribute('href'), a.classList.contains('btn-solid')])")
    check("Home: the virtual cube is the primary action; Build and Connect are optional secondary actions",
          cta[:3] == [["Try the Virtual Cube →", "#lab", True], ["Build Your Own Cube", "#build", False], ["Connect My Cube", "#connect", False]], cta)
    await page.goto(FILE_URL + "#lab", wait_until="load")
    await page.wait_for_timeout(2500)
    stack = [u for u in page.requested if any(x in u for x in ("aeris-data.js", "aeris-device.wasm", "noble-p256", "esptool", "/js/connect/link.js", "/js/connect/synthetic.js"))]
    check("The virtual cube's pages load nothing of the device stack (data, synthetic device, P-256, flasher)", not stack and await page.evaluate("typeof AERIS_SYNTH === 'undefined' && typeof AERIS_NOBLE === 'undefined'"), stack)
    nav = await page.evaluate("[...document.querySelectorAll('.nav-links a')].map(a => a.textContent.trim())")
    ov = await page.evaluate("[...document.querySelectorAll('.overlay a')].map(a => a.getAttribute('href'))")
    foot = await page.evaluate("[...document.querySelectorAll('footer .foot-links a')].map(a => a.getAttribute('href'))")
    check("Navigation, menu and footer reach Build and Connect", nav[-2:] == ["Build", "Connect"] and "#build" in ov and "#connect" in ov and "#build" in foot and "#connect" in foot, (nav, ov, foot))
    check("Virtual pages without script errors", not page.errors, page.errors[:3])
    await ctx.close()


async def build_page(br):
    kit = json.loads((SITE / "data" / "kits" / "aeris-kit-a1.json").read_text())
    bom = json.loads((SITE / "data" / "bom" / "aeris-kit-a1.bom.json").read_text())
    ctx, page = await new_page(br)
    await page.goto(FILE_URL + "#build", wait_until="load")
    await wait_for(page, "!document.getElementById('bdBody').hidden", 20)
    h1 = await page.evaluate("[...document.querySelectorAll('h1')].filter(h => h.offsetParent).map(h => h.textContent)")
    ladder = await page.evaluate("[...document.querySelectorAll('#bdLadder li')].map(l => l.className + ':' + l.textContent)")
    back = await page.evaluate("[...document.querySelectorAll('.back-virtual')].map(a => [a.getAttribute('href'), a.closest('main').id])")
    check("Build and Connect each offer a route back to the virtual cube", back == [["#lab", "view-build"], ["#lab", "view-connect"]], back)
    check("Build: one h1; the readiness ladder marks the current level (candidate) and says no A1 cube is built",
          h1 == ["Build Your Own Cube"] and len(ladder) == 6 and ladder[1].startswith("now:") and "no a1 cube built yet" in (await page.inner_text("#bdBadges")).lower(), (h1, ladder))
    rows = await page.evaluate("[...document.querySelectorAll('#bdBom tbody tr:not(.bd-det)')].length")
    srcs = await page.evaluate("[...document.querySelectorAll('#bdBom a[href^=\"http\"]')].map(a => [a.target, a.rel])")
    check("Build: every BOM item is listed; published facts link their sources (new tab, noopener)",
          rows == len(bom["items"]) and srcs and all(t == "_blank" and "noopener" in r for t, r in srcs), (rows, len(bom["items"]), srcs[:3]))
    dl = await page.evaluate("[...document.querySelectorAll('#bdDownloads li')].map(li => ({ok: li.classList.contains('ok'), href: (li.querySelector('a') || {}).getAttribute ? li.querySelector('a').getAttribute('href') : null, text: li.innerText, buttons: li.querySelectorAll('a,button').length}))")
    avail = [d for d in kit["downloads"] if d["status"] == "available"]
    hashes_ok = all((SITE / d["path"]).is_file() and sha256(SITE / d["path"]) == d["sha256"] and d["sha256"] in "".join(x["text"] for x in dl) for d in avail)
    unav = [x for x in dl if not x["ok"]]
    check("Build: available downloads exist with their SHA-256; unavailable ones show the reason and no link or button",
          len(dl) == len(kit["downloads"]) and hashes_ok and all(x["href"] for x in dl if x["ok"]) and unav and all(x["buttons"] == 0 and "unavailable" in x["text"].lower() for x in unav), dl)
    blocked = await page.evaluate("[...document.querySelectorAll('.bd-step.blocked')].map(s => ({why: (s.querySelector('.bd-block') || {}).textContent || '', cb: s.querySelector('input[type=checkbox]').disabled}))")
    n_blocked = sum(1 for s in kit["steps"] if s["availability"]["status"] == "blocked")
    check("Build: blocked steps say why and cannot be ticked", len(blocked) == n_blocked and all(b["why"].startswith("Why blocked:") and b["cb"] for b in blocked), blocked[:2])
    sizing = await page.inner_text("#bdSizingNote")
    check("Build: the sizing states the candidate driver's static limit (nominal model, nothing measured)", "static limit" in sizing and "nothing measured" in sizing, sizing[:300])
    # notes: kept per revision in this browser; a revision change explains what it invalidates
    await page.check('input[data-step="plan-readiness"]')
    await page.check('input[data-step="firmware-install"]')
    await page.reload(wait_until="load")
    await wait_for(page, "!document.getElementById('bdBody').hidden", 20)
    kept = await page.evaluate("[...document.querySelectorAll('#bdSteps input:checked')].map(c => c.getAttribute('data-step'))")
    prog = await page.inner_text("#bdProgress")
    check("Build: ticked steps are kept in this browser for this revision (notes, not qualifications)", sorted(kept) == ["firmware-install", "plan-readiness"] and prog.startswith("2 of"), (kept, prog))
    await page.evaluate("localStorage.setItem('aeris.v6.build.aeris-kit-a1', JSON.stringify({revision: 'A0-unknown', done: {'plan-readiness': '2026-01-01T00:00:00Z'}}))")
    await page.reload(wait_until="load")
    await wait_for(page, "!document.getElementById('bdBody').hidden", 20)
    banner = await page.evaluate("(() => { const b = document.getElementById('bdRevBanner'); return {hidden: b.hidden, text: b.innerText}; })()")
    kept = await page.evaluate("[...document.querySelectorAll('#bdSteps input:checked')].length")
    check("Build: notes from an unknown earlier revision do not carry over, and the page says so", not banner["hidden"] and "A0-unknown → A1-candidate" in banner["text"] and "none of them carry over" in banner["text"] and kept == 0, banner)
    await page.click("#bdReset")
    check("Build: 'Clear my notes' clears them", await page.evaluate("document.querySelectorAll('#bdSteps input:checked').length === 0 && document.getElementById('bdRevBanner').hidden"))
    # a step's action leads to the Connect page's step
    await page.click('#step-calibrate-imu .bd-step-f a')
    await page.wait_for_timeout(1500)
    check("Build: a step's action opens the matching Connect step", await page.evaluate("location.hash") == "#connect/calibrate" and "Choose a device first" in (await status(page))["text"], await page.evaluate("location.hash"))
    await page.goto(FILE_URL + "#build-step-bench-can", wait_until="load")
    await page.wait_for_timeout(1500)
    top = await page.evaluate("document.getElementById('step-bench-can').getBoundingClientRect().top")
    check("Build: #build-step-<id> scrolls to that step", 0 <= top < 260, top)
    await shot(page, "build")
    check("Build page without script errors", not page.errors, page.errors[:3])
    await ctx.close()


async def connect_synthetic(br):
    ctx, page = await new_page(br)
    await page.goto(FILE_URL + "#connect", wait_until="load")
    await wait_for(page, "ConnectPage._state.ready", 20)
    h1 = await page.evaluate("[...document.querySelectorAll('h1')].filter(h => h.offsetParent).map(h => h.textContent)")
    env = await page.inner_text("#cnEnv")
    check("Connect: one h1; what is implemented and how it was tested, never with a physical board", h1 == ["Connect My Cube"] and "never with a physical board" in env and "no AERIS reference cube has been built" in env, (h1, env[:200]))
    nb = await page.inner_text("#cnChoose")
    check("Connect without a backend: pairing stays with this browser; Simulate My Cube is said to need a backend", "No backend is configured" in nb, nb[-300:])
    await act(page, '[data-act="syn"]')
    ident = await page.inner_text("#cnIdent")
    strip = await page.evaluate("document.querySelector('#sysbar [data-k=\"source\"]').textContent")
    check("Synthetic device: labelled 'not a cube' on the device and SYNTHETIC in the status strip", "SYNTHETIC DEVICE — NOT A CUBE" in ident.upper() and "SYNTHETIC TELEMETRY" in strip, (ident[:120], strip))
    # keyboard: the device steps are an ARIA tab list
    await page.focus("#cnTab-pair")
    await page.keyboard.press("ArrowRight")
    k1 = await page.evaluate("[document.activeElement.id, document.getElementById('cnTab-diagnostics').getAttribute('aria-selected')]")
    await page.keyboard.press("End")
    k2 = await page.evaluate("document.activeElement.id")
    await page.keyboard.press("Home")
    k3 = await page.evaluate("document.activeElement.id")
    check("Keyboard: arrow keys, Home and End move between the device steps", k1 == ["cnTab-diagnostics", "true"] and k2 == "cnTab-record" and k3 == "cnTab-pair", (k1, k2, k3))
    await page.focus("#cnTab-pair")
    await page.keyboard.press("Enter")
    hands = {"arm": lambda: page.click('.cn-hands [data-act="op-arm"]'), "spin": lambda: page.click('.cn-hands [data-act="op-spin"]'),
             "hold": lambda: page.click('.cn-hands [data-act="op-hold"]')}

    async def face(f):
        await page.select_option("#cnFace", f)
        await page.click('.cn-hands [data-act="op-face"]')
        await page.wait_for_timeout(300)
    out = await full_local_flow(page, "synthetic", hands["arm"], hands["spin"], face, hands["hold"])
    if "exp" not in out:
        check("Synthetic device: the experiment can be requested after the self-test", False, out)
        await ctx.close()
        return
    check("Pairing waits for the press of ARM on the cube, then pairs with this browser", out["waits_for_arm"] and out["paired"], out)
    check("Diagnostics: IMU, drivers (unpowered while DISARMED), loop, estimator and local controls", "LSM6DSOX at 0x6a" in out["diag"] and "unpowered" in out["diag"] and "Local stop: released" in out["diag"], out["diag"][:500])
    check("Calibration from the device's measurements: mounting fitted, three wheel directions confirmed", out["cal"] and out["cal"]["to_body"] == [1, 0, 0, 0, 1, 0, 0, 0, 1] and out["cal"]["wheels"] is True and out["cal"]["ref"]["id"].startswith("LOCAL-CAL-"), out["cal"])
    check("Configuration: Apply is offered only for a prepared configuration; the self-test reaches READY", out["apply_disabled_before"] is True and out["ready"] == "READY", out)
    res = (out.get("exp") or {}).get("result") or {}
    check("Experiment: requesting starts nothing until ARM is pressed; then it balances and stops normally; the result reports the torque-limited control steps per wheel",
          out["req_enabled"] and out["running_before_arm"] == "READY" and out["balancing"] and out["exp"]["status"] == "completed" and res.get("ended") == "duration reached" and out["exp_status"]["tone"] == "ok"
          and res.get("balancing_steps", 0) > 1000 and len(res.get("saturated_steps") or []) == 3
          and ("control steps)" in out["exp_status"]["text"] or "no torque limit reached" in out["exp_status"]["text"]),
          {k: out[k] for k in ("req_enabled", "running_before_arm", "balancing", "exp", "exp_status")})
    check("After an experiment the device is DISARMED and the next one needs a new self-test", out["after_state"] == "DISARMED" and out["req_disabled_after"] is True, (out["after_state"], out["req_disabled_after"]))
    check("The browser recording is SYNTHETIC with the applied configuration's hash", out["recording"] and out["recording"]["synthetic"] is True and out["recording"]["kind"] == "emulator" and out["recording"]["trust"] == "synthetic" and out["recording"]["frames"] > 50 and len(out["recording"]["config"]) == 64, out["recording"])
    async with page.expect_download() as d1:
        await page.click('[data-act="rec-json"]')
    j = json.loads(pathlib.Path(await (await d1.value).path()).read_text())
    async with page.expect_download() as d2:
        await page.click('[data-act="rec-ndjson"]')
    lines = pathlib.Path(await (await d2.value).path()).read_text().splitlines()
    check("Exports keep the provenance: SYNTHETIC in the file name, the document and every hello", (await d1.value).suggested_filename.endswith("-SYNTHETIC.json") and j["synthetic"] is True and json.loads(lines[0])["synthetic"] is True and len(lines) == j["samples"]["cols"]["t"].__len__() + 1,
          ((await d1.value).suggested_filename, j["synthetic"], lines[0][:120]))
    rec = await page.inner_text("#cnPanel")
    check("Without a backend, Simulate My Cube says it needs one (nothing is substituted in the browser)", "Needs a reachable AERIS backend" in rec and await page.evaluate("!document.querySelector('[data-act=\"simulate\"]')"), rec[-300:])
    # Stop: always available, needs no lease; an experiment stopped by it ends early. The self-test needs the cube still:
    # after the first experiment it fell into the fixture, so it is held at the start position first
    await page.click('.cn-hands [data-act="op-hold"]')
    await wait_for(page, SETTLED, 20)
    await tab(page, "configure")
    await act(page, '[data-act="selftest"]')
    await tab(page, "experiment")
    await page.fill("#cnDur", "8")
    if not await wait_for(page, "!document.querySelector('[data-act=\"exp-req\"]').disabled", 15):
        check("Stop (always available, no lease) ends a balancing experiment early", False,
              {"panel": await page.inner_text("#cnPanel"), "state": await page.evaluate("ConnectPage._state.drv.state()"), "selftest": await page.evaluate("ConnectPage._state.selftestCmd")})
        await ctx.close()
        return
    await page.click('[data-act="exp-req"]')
    await page.wait_for_timeout(800)
    await page.click('.cn-hands [data-act="op-arm"]')
    await wait_for(page, "(ConnectPage._state.drv.state() || {}).state === 'BALANCING'", 10)
    await page.wait_for_timeout(800)
    await shot(page, "connect-balancing")
    balancing = await page.evaluate("(ConnectPage._state.drv.state() || {}).state")
    exp_id = await page.evaluate("(Object.values(ConnectPage._state.session.host.pending).filter(p => p.action === 'start_experiment').pop() || {}).id")
    await page.click('.cn-dev-btns [data-act="stop"]')
    ended = await wait_for(page, f"(ConnectPage._state.session.host.pending['{exp_id}'] || {{}}).final === true", 20)
    rec = await page.evaluate(f"ConnectPage._state.session.host.pending['{exp_id}']")
    check("Stop (always available, no lease) ends a balancing experiment early", balancing == "BALANCING" and ended and (rec.get("result") or {}).get("ended") not in (None, "duration reached"), (balancing, rec))
    await idle(page, 30)
    check("Connect (synthetic) without script errors", not page.errors, page.errors[:3])
    await ctx.close()


async def web_serial(br, static):
    manifest = json.loads((SITE / "firmware" / "releases" / "0.1.0" / "manifest.json").read_text())
    exp = manifest["expected_hello"]
    hello = {"kind": "dev_hello", "link": "aeris-device-link/1", "versions": [1], "device_id": "artificial-test-board",
             "fw": {"version": exp["fw.version"], "build": exp["fw.build"], "actuation_build": exp["fw.actuation_build"]},
             "board": {"id": exp["board.id"], "kind": "physical", "synthetic": False, "chip": "ESP32-S3"},
             "caps": {"actions": ["identify", "diagnostics", "self_test", "calibrate_imu", "calibrate_axes", "check_encoders", "apply_config", "start_experiment", "stop", "unpair", "enter_update"],
                      "controllers": ["edge-lqr", "corner-mimo-lqr"], "estimators": ["cf3d"], "imu": "lsm6dsox", "motor": "odrive-cansimple", "config_schema": "aeris-device-config/1", "max_control_hz": 1000},
             "limits": {"hard_max_current_A": 10, "hard_max_torque_Nm": 1, "hard_max_speed_rpm": 8000}, "paired": False}
    init = SERIAL_MOCK + "\nwindow.__serialMock.releaseHello = " + json.dumps(hello) + ";"
    # (a) the scripted port backed by the synthetic device: the same flow over the Web Serial transport
    ctx, page = await new_page(br, init=init)
    await page.goto(static.url + "#connect", wait_until="load")
    await wait_for(page, "ConnectPage._state.ready", 20)
    await act(page, '[data-act="serial"]')
    info = await page.evaluate("({kind: ConnectPage._state.transport && ConnectPage._state.transport.kind, req: __serialMock.requests, filters: __serialMock.filters, tabs: [...document.querySelectorAll('#cnTabs [role=tab]')].map(t => t.textContent)})")
    check("Web Serial: the visitor chooses the port (filtered to Espressif's USB) and the page speaks the device link over it",
          info["kind"] == "web-serial" and info["req"] == 1 and info["filters"] == [{"usbVendorId": 0x303A}] and info["tabs"][0] == "Install", info)
    await tab(page, "install")
    await act(page, '[data-act="inst-load"]')
    await page.check("#cnAllowDev")
    await page.wait_for_timeout(200)
    pre = await page.inner_text("#cnPanel")
    check("Installer: refuses to write to a synthetic device (nothing to install on it)", "this is a synthetic device" in pre and await page.evaluate("document.querySelector('[data-act=\"inst-run\"]').disabled"), pre[-300:])
    await tab(page, "pair")

    async def arm():
        await page.evaluate("__serialMock.dev.armPress()")

    async def spin():
        await page.evaluate("[0, 1, 2].forEach(i => __serialMock.dev.spin(i, 20))")

    async def face(f):
        await page.evaluate(f"__serialMock.dev.face('{f}')")
        await page.wait_for_timeout(300)

    async def hold():
        await page.evaluate("__serialMock.dev.hold()")
    out = await full_local_flow(page, "serial", arm, spin, face, hold)
    if "exp" not in out:
        check("Web Serial: the experiment can be requested after the self-test", False, out)
        await ctx.close()
        return
    check("Web Serial (scripted port, synthetic device): pair with ARM, calibrate, configure, self-test, experiment with ARM, record",
          out["paired"] and out["cal"] and out["cal"]["wheels"] and out["ready"] == "READY" and out["exp"]["status"] == "completed" and out["recording"]["synthetic"] is True,
          {k: out[k] for k in ("paired", "cal", "ready", "exp", "recording")})
    await act(page, '[data-act="disconnect"]')
    check("Disconnecting closes the port", await page.evaluate("__serialMock.closed >= 1 && !ConnectPage._state.drv"))
    check("Web Serial flow without script errors", not page.errors, page.errors[:3])
    await ctx.close()

    # (b) a blank ARTIFICIAL board: the installer with the scripted flasher, then the identity check
    ctx, page = await new_page(br, init=init.replace('mode: "synthetic"', 'mode: "blank"'))
    await page.route("**/vendor/esptool-js.min.js", lambda r: r.fulfill(status=200, content_type="application/javascript", body=SCRIPTED_ESPTOOL))
    await page.goto(static.url + "#connect", wait_until="load")
    await wait_for(page, "ConnectPage._state.ready", 20)
    await act(page, '[data-act="serial"]', 30)
    st = await status(page)
    tabs = await page.evaluate("[...document.querySelectorAll('#cnTabs [role=tab]')].map(t => t.textContent)")
    check("A board that does not answer in the AERIS protocol is offered the installer only", "No AERIS firmware answered" in st["text"] and tabs == ["Install"], (st, tabs))
    await act(page, '[data-act="inst-load"]')
    p1 = await page.inner_text("#cnPanel")
    dis1 = await page.evaluate("document.querySelector('[data-act=\"inst-run\"]').disabled")
    check("Installer: the release is signed with a DEVELOPMENT test key; it needs explicit consent before Install is enabled", "DEVELOPMENT build signed with a test key" in p1 and dis1, p1[:400])
    await page.check("#cnAllowDev")
    await page.wait_for_timeout(200)
    p2 = await page.inner_text("#cnPanel")
    check("Installer: with consent the signature verifies (development key) and Install is enabled", "Signature: development key" in p2 and not await page.evaluate("document.querySelector('[data-act=\"inst-run\"]').disabled"), p2[:400])
    await act(page, '[data-act="inst-run"]', 60)
    log = await page.evaluate("__serialMock.flash")
    writes = [x for x in log if x["step"] == "write"]
    want = [{"address": p["offset"], "bytes": p["bytes"]} for p in manifest["parts"]]
    res = await page.inner_text("#cnPanel")
    check("Installer: every image checked, then written at the manifest's offsets (scripted flasher), keeping the flash settings",
          len(writes) == 1 and writes[0]["parts"] == want and writes[0]["flashSize"] == "keep" and writes[0]["eraseAll"] is False and "Written to ESP32-S3" in res, (log, res[-200:]))
    await act(page, '[data-act="inst-verify"]', 30)
    res = await page.inner_text("#cnPanel")
    ident = await page.inner_text("#cnIdent")
    check("After installing, the board's hello is checked against the manifest (version, build, board, no actuation)",
          ("Installed and verified: firmware 0.1.0 (" + exp["fw.build"] + ")") in res and "DECLARED PHYSICAL — NOT VERIFIED" in ident.upper(), (res[-250:], ident[:200]))
    await shot(page, "connect-installer")
    await ctx.close()

    # (c) a tampered image: refused before anything is written
    ctx, page = await new_page(br, init=init.replace('mode: "synthetic"', 'mode: "blank"'))
    await page.route("**/vendor/esptool-js.min.js", lambda r: r.fulfill(status=200, content_type="application/javascript", body=SCRIPTED_ESPTOOL))
    app = (SITE / "firmware" / "releases" / "0.1.0" / "aeris_fw.bin").read_bytes()
    bad = bytearray(app); bad[1000] ^= 0xFF
    await page.route("**/firmware/releases/0.1.0/aeris_fw.bin", lambda r: r.fulfill(status=200, content_type="application/octet-stream", body=bytes(bad)))
    await page.goto(static.url + "#connect", wait_until="load")
    await wait_for(page, "ConnectPage._state.ready", 20)
    await act(page, '[data-act="serial"]', 30)
    await act(page, '[data-act="inst-load"]')
    await page.check("#cnAllowDev")
    await act(page, '[data-act="inst-run"]', 60)
    res = await page.inner_text("#cnPanel")
    log = await page.evaluate("__serialMock.flash")
    check("Installer: a modified image is refused before anything is written (SHA-256 against the signed manifest)", "does not match the manifest" in res and "nothing was written" in res and not log, (res[-300:], log))
    await ctx.close()


async def backend_local(br):
    be = Backend()
    if not be.ok:
        for n in ("Backend (local): pairing through the backend relay needs ARM", "Backend (local): calibration from the command log, profile revision, configuration, experiment, recording",
                  "Backend (local): Simulate My Cube and the comparison with its evidence status", "Backend (local): the simulation opens in AERIS Lab"):
            not_run(n, "the backend did not start: " + be.tail()[-300:])
        be.close()
        return
    try:
        ctx, page = await new_page(br)
        await page.goto(be.url + "#connect", wait_until="load")
        await wait_for(page, "ConnectPage._state.ready && ConnectPage._state.apiStatus", 20)
        choose = await page.inner_text("#cnChoose")
        await page.check("#cnVia")
        await act(page, '[data-act="syn"]')
        kind = await page.evaluate("ConnectPage._state.drv && ConnectPage._state.drv.kind")
        await page.click('[data-act="pair"]')
        await page.wait_for_timeout(1500)
        waiting = (await status(page))["text"]
        await page.click('.cn-hands [data-act="op-arm"]')
        await idle(page)
        listed = await page.evaluate("fetch('/api/v6/devices').then(r => r.json()).then(j => j.devices.map(d => [d.id, d.synthetic]))")
        check("Backend (local): pairing through the backend relay needs ARM; the device is then listed for this computer's owner",
              "AERIS_AUTH=local" in choose and kind == "backend" and waiting.startswith("Press ARM") and listed == [["synthetic-web-edge", True]], (kind, waiting, listed))
        await page.wait_for_timeout(600)
        await tab(page, "calibrate")
        await act(page, '[data-act="cal-imu"]')
        for f in ("+z", "+y"):
            await page.select_option("#cnFace", f); await page.click('.cn-hands [data-act="op-face"]'); await page.wait_for_timeout(300)
            await page.select_option("#cnCalFace", f)
            await act(page, '[data-act="cal-axes"]')
        await page.click('[data-act="cal-enc"]'); await page.wait_for_timeout(2500); await page.click('.cn-hands [data-act="op-spin"]'); await idle(page)
        await act(page, '[data-act="cal-compute"]')
        cal1 = await page.evaluate("ConnectPage._state.calRef")
        await tab(page, "profile")
        await page.fill("#cnPf-body-mass_kg", "99")
        await act(page, '[data-act="prof-validate"]')
        invalid = (await status(page))["tone"] == "bad" and await page.evaluate("document.getElementById('cnPf-body-mass_kg').getAttribute('aria-invalid') === 'true'")
        await page.fill("#cnPf-body-mass_kg", "1.85")
        await page.select_option("#cnVs-body", "measured")
        await act(page, '[data-act="prof-save"]')
        saved = await page.evaluate("ConnectPage._state.profSaved && [ConnectPage._state.profSaved.id, ConnectPage._state.profSaved.revision]")
        await act(page, '.cn-out [data-act="prof-use"]')
        uses = await page.evaluate("[ConnectPage._state.drv.view.profile_id, ConnectPage._state.drv.view.profile_revision]")
        await tab(page, "calibrate")
        await act(page, '[data-act="cal-compute"]')
        cal2 = await page.evaluate("ConnectPage._state.calRef")
        await tab(page, "configure")
        await act(page, '[data-act="cfg-build"]')
        built = await page.evaluate("ConnectPage._state.config && ConnectPage._state.config.composed")
        await act(page, '[data-act="cfg-apply"]')
        await page.wait_for_timeout(600)
        await act(page, '[data-act="selftest"]')
        await page.wait_for_timeout(600)
        await tab(page, "record")
        await act(page, '[data-act="rec-start"]')
        await tab(page, "experiment")
        await page.click('#cnPanel [data-act="op-hold"]')
        await wait_for(page, SETTLED, 20)
        await page.fill("#cnDur", "4")
        await page.click('[data-act="exp-req"]')
        await page.wait_for_timeout(1500)
        await page.click('.cn-hands [data-act="op-arm"]')
        await idle(page, 90)
        exp = await page.evaluate("ConnectPage._state.exp && {status: ConnectPage._state.exp.status, result: ConnectPage._state.exp.result}")
        await page.wait_for_timeout(800)
        await tab(page, "record")
        await act(page, '[data-act="rec-stop"]')
        stored = await page.evaluate("ConnectPage._state.recording && ConnectPage._state.recording.stored")
        check("Backend (local): calibration from the command log, a validated profile revision used by the device, configuration built by the backend, experiment, recording",
              invalid and cal1 and cal1["id"].startswith("AERIS-CAL-") and saved == ["my-cube", 1] and uses == ["my-cube", 1] and cal2 and cal2["id"] != cal1["id"] and built == "built by the AERIS backend for this device"
              and exp and exp["status"] == "completed" and exp["result"]["ended"] == "duration reached" and stored and stored["synthetic"] is True and stored["id"].startswith("AERIS-HW-"),
              {"invalid": invalid, "cal1": cal1, "saved": saved, "uses": uses, "cal2": cal2, "built": built, "exp": exp, "stored": stored})
        await act(page, '[data-act="simulate"]', 240)
        sim = await page.evaluate("ConnectPage._state.sim && ConnectPage._state.sim.run && {id: ConnectPage._state.sim.run.id, twin: ConnectPage._state.sim.run.twin}")
        await act(page, '[data-act="compare"]')
        cmp = await page.evaluate("ConnectPage._state.cmp && {synthetic: ConnectPage._state.cmp.synthetic, admissible: ConnectPage._state.cmp.evidence.admissible_as_validation_evidence, errors: ConnectPage._state.cmp.result.errors, rule: (ConnectPage._state.cmp.result.alignment || {}).recording_t0_rule, att: (ConnectPage._state.cmp.result.signals || {}).attitude}")
        panel = await page.inner_text("#cnPanel")
        check("Backend (local): Simulate My Cube runs the device's profile revision and calibration; the comparison is computed and NOT admissible as evidence",
              sim and sim["twin"]["profile"]["id"] == "my-cube" and sim["twin"]["calibration"]["id"] == cal2["id"] and cmp and cmp["synthetic"] is True and cmp["admissible"] is False and cmp["errors"] == []
              and "status ok" in (cmp["rule"] or "") and cmp["att"] and cmp["att"]["n"] > 20 and "not admissible" in panel and "SYNTHETIC" in panel.upper(),
              {"sim": sim, "cmp": cmp})
        await shot(page, "connect-compare")
        await page.click('[data-act="sim-open"]')
        opened = await wait_for(page, "location.hash.indexOf('#lab') === 0 && !document.getElementById('view-lab').hidden && document.body.innerText.indexOf('" + (sim or {}).get("id", "none") + "') >= 0", 20)
        check("Backend (local): the simulation opens in AERIS Lab", opened, await page.evaluate("location.hash"))
        check("Backend (local) flow without script errors", not page.errors, page.errors[:3])
        await ctx.close()
    finally:
        be.close()


async def backend_jwt(br):
    sys.path.insert(0, str(BACKEND))
    try:
        from aeris_backend.tools import devauth
    except Exception as e:                                  # pragma: no cover
        not_run("Backend (jwt): sign-in with a development token on this computer only", f"cannot import devauth: {e}")
        return
    d = tempfile.mkdtemp(prefix="aeris-v6-devauth-")
    devauth.init(d)
    env = devauth.env(d)
    port = free_port()
    env["AERIS_PUBLIC_ORIGIN"] = f"http://127.0.0.1:{port}"
    be = Backend.__new__(Backend)
    be.port = port
    be.tmp = tempfile.mkdtemp(prefix="aeris-v6-browser-jwt-")
    e2 = dict(os.environ, PYTHONPATH=str(BACKEND))
    for k in [k for k in e2 if k.startswith("AERIS_")]:
        e2.pop(k)
    e2.update(env)
    be.log = open(os.path.join(be.tmp, "backend.log"), "w")
    be.proc = subprocess.Popen([backend_python(), "-m", "aeris_backend.api.main", "--port", str(port), "--db", os.path.join(be.tmp, "aeris.sqlite3"), "--telemetry-dir", os.path.join(be.tmp, "tel"),
                                "--serve-site", str(SITE), "--workers", "1", "--log-level", "warning"], cwd=str(BACKEND), env=e2, stdout=be.log, stderr=subprocess.STDOUT)
    be.ok = wait_http(f"http://127.0.0.1:{port}/api/v1/health")
    be.url = f"http://127.0.0.1:{port}/"
    if not be.ok:
        not_run("Backend (jwt): sign-in with a development token on this computer only", "the backend did not start: " + be.tail()[-300:])
        be.close()
        return
    try:
        ctx, page = await new_page(br)
        await page.goto(be.url + "#connect", wait_until="load")
        await wait_for(page, "ConnectPage._state.ready && ConnectPage._state.apiStatus", 20)
        before = await page.inner_text("#cnChoose")
        await page.fill("#cnDevTok", "not-a-token")
        await page.click('[data-act="devtok"]')
        refused = await status(page)
        tok = devauth.token(d, "alice")
        await page.fill("#cnDevTok", tok)
        await act(page, '[data-act="devtok"]')
        after = await page.inner_text("#cnChoose")
        try:
            urllib.request.urlopen(be.url + "api/v6/devices", timeout=5)
            unauth = 200
        except urllib.error.HTTPError as e:
            unauth = e.code
        await act(page, '[data-act="signout"]')
        out = await page.inner_text("#cnChoose")
        check("Backend (jwt): a development token is accepted only on this computer; devices need it; signing out forgets it",
              "development token" in before.lower() and refused["tone"] == "bad" and "not a JWT" in refused["text"] and "Using a development token" in after and "Your devices" in after
              and unauth == 401 and "Development token" in out, (before[-300:], refused, after[-300:], unauth))
        check("Backend (jwt) without script errors", not page.errors, page.errors[:3])
        await ctx.close()
    finally:
        be.close()


async def phones(br):
    over, menus, errors = {}, {}, []
    for w, hgt in ((375, 812), (390, 844)):
        ctx, page = await new_page(br, w, hgt, device_scale_factor=2)
        for h in ("#build", "#connect"):
            await page.goto(FILE_URL + h, wait_until="load")
            await page.wait_for_timeout(1500)
            over[f"{w}px {h}"] = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        await act(page, '[data-act="syn"]')
        for t in ("pair", "calibrate", "profile", "configure", "experiment", "record"):
            await tab(page, t)
            over[f"{w}px #connect/{t}"] = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
        if w == 390:
            await shot(page, "connect-phone")
        await page.click("#burger")
        await page.wait_for_timeout(500)
        menus[w] = await page.evaluate("(() => { const a = [...document.querySelectorAll('.overlay a')]; const r = a.map(x => x.getBoundingClientRect()); return {n: a.length, inView: r.filter(b => b.top >= 0 && b.bottom <= innerHeight).length}; })()")
        errors += page.errors
        await ctx.close()
    check("Phone (375 px and 390 px): Build, Connect and every device step without horizontal scrolling; the menu shows all its entries",
          all(v <= 0 for v in over.values()) and all(m["n"] == m["inView"] for m in menus.values()), (over, menus))
    check("Phone layout without script errors", not errors, errors[:3])


async def main():
    static = Static()
    try:
        async with async_playwright() as p:
            br = await p.chromium.launch(args=ARGS)
            for fn in (virtual_first, build_page, connect_synthetic):
                await fn(br)
            await web_serial(br, static)
            await backend_local(br)
            await backend_jwt(br)
            await phones(br)
            await br.close()
    finally:
        static.close()
    passed = sum(1 for r in results if r[1])
    print(f"\n{passed} / {len(results)} v6 browser checks passed" + (f" ({len(NOT_RUN)} not run)" if NOT_RUN else ""))
    sys.exit(0 if passed == len(results) and not NOT_RUN else (2 if NOT_RUN and passed == len(results) else 1))


asyncio.run(main())

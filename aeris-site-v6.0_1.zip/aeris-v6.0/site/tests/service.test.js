/* Tests for the experiment service, the data-source adapters, the job state
   machine and research-sweep definitions.   Run with:  node tests/service.test.js */
"use strict";
var path = require("path");
global.window = { AERIS_CONFIG: { researchApi: { baseUrl: null } } };
var J = function (p) { return require(path.join(__dirname, "..", "js", p)); };
global.AERIS_IDS = J("platform/ids.js");
global.AERIS_TWIN = J("core.js");
global.AERIS_SCHEMA = J("platform/schema.js");
global.AERIS_EVENTS = J("platform/events.js");
global.AERIS_RUNS = J("runs.js");
global.AERIS_JOBS = J("platform/jobs.js");
global.AERIS_SWEEP = J("platform/sweep.js");
global.AERIS_EXAMPLES = J("platform/examples.js");
global.LocalSimulatorAdapter = J("adapters/local-simulator.js");
global.ReplayAdapter = J("adapters/replay.js");
global.ResearchApiAdapter = J("adapters/research-api.js");
global.HardwareTelemetryAdapter = J("adapters/hardware-telemetry.js");
global.MockResearchBackend = J("adapters/mock-research-backend.js");
var SERVICE = J("platform/service.js");
var TWIN = global.AERIS_TWIN, RUNS = global.AERIS_RUNS, JOBS = global.AERIS_JOBS, SWEEP = global.AERIS_SWEEP;

var results = [], queue = [];
function test(n, f) { queue.push({ n: n, f: f }); }
function cfg(mode, o) { var c = TWIN.defaultConfig(mode); Object.keys(o || {}).forEach(function (k) { c[k] = JSON.parse(JSON.stringify(o[k])); }); return c; }
function run() {
  var i = 0;
  (function next() {
    if (i >= queue.length) return report();
    var t = queue[i++], cur = { name: t.n, ok: true, msgs: [] };
    function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
    RUNS.useStorage(RUNS.memoryStore(), false);
    var p; try { p = t.f(check); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); }
    Promise.resolve(p).then(function () { results.push(cur); next(); }, function (e) { cur.ok = false; cur.msgs.push("rejected: " + JSON.stringify(e && e.message || e)); results.push(cur); next(); });
  })();
}
function report() {
  var pass = results.filter(function (r) { return r.ok; }).length;
  results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
  console.log("\n" + pass + " / " + results.length + " service tests passed");
  process.exit(pass === results.length ? 0 : 1);
}

/* ------------------------------------------------------------ modes and adapter selection */
test("Adapter selection: DEMO routes to the browser engine; SIMULATION and HARDWARE are disabled with reasons", function (check) {
  var M = SERVICE.modes(), by = {}; M.forEach(function (m) { by[m.id] = m; });
  check(by.demo.available && by.demo.adapter === "local-simulator", "demo available on the local engine");
  check(!by.simulation.available && /research backend is configured/.test(by.simulation.reason), "simulation disabled until a backend URL is set: " + by.simulation.reason);
  check(!by.hardware.available && /research backend/.test(by.hardware.reason), "hardware disabled (telemetry needs the research backend): " + by.hardware.reason);
  check(SERVICE.setMode("hardware").ok === false && SERVICE.getMode() === "demo", "cannot switch to an unavailable mode");
  check(SERVICE.route("single").name === "local-simulator" && SERVICE.route("replay").name === "replay", "routes");
});
/* v4: CONFIGURED is not REACHABLE (requirement E). v3 made SIMULATION selectable as soon as a URL was set, even with an
   offline backend; now a successful probe (GET /health + GET /capabilities) is required, and only reported capabilities count. */
test("Adapter selection: a configured backend enables SIMULATION only once it is reachable, then routes runs and sweeps to it", function (check) {
  var off = ResearchApiAdapter.create({ baseUrl: "https://aeris.example/api-host", transport: function () { return Promise.reject(new Error("offline")); } });
  SERVICE.register(off);
  check(!SERVICE.modeInfo("simulation").available && /not been confirmed/.test(SERVICE.modeInfo("simulation").reason), "configured but unchecked: not selectable");
  return off.probe().then(function () {
    check(!SERVICE.modeInfo("simulation").available && /not reachable/.test(SERVICE.modeInfo("simulation").reason), "configured but offline: " + SERVICE.modeInfo("simulation").reason);
    check(off.capabilities().reported === false && off.capabilities().sweep === null, "no guessed capabilities");
    var api = ResearchApiAdapter.create({ baseUrl: "mock://b", transport: MockResearchBackend.createTransport(), mock: true });
    SERVICE.register(api);
    return api.probe().then(function () {
      check(SERVICE.modeInfo("simulation").available, "available once reachable");
      check(api.capabilities().reported === true && api.capabilities().sweep.maxRuns === 2000, "reported capabilities used");
      check(SERVICE.setMode("simulation").ok && SERVICE.route("single") === api && SERVICE.route("sweep") === api, "routes to the API adapter");
      SERVICE.setMode("demo");
      SERVICE.register(ResearchApiAdapter.create({ baseUrl: null }));
    });
  });
});

/* ------------------------------------------------------------ local simulator adapter */
test("Local simulator adapter: runSingle returns a revision-1.1 record from the browser engine", function (check) {
  return SERVICE.runSingle(cfg("edge", { duration_s: 2 }), { name: "t" }).then(function (o) {
    check(o.ok && o.record.origin.adapter === "local-simulator" && o.record.origin.mode === "demo", "origin");
    check(o.record.schema_revision === "1.1" && /^AERIS-EXP-\d{6}$/.test(o.record.experiment_id), "record fields");
  });
});
test("Local simulator adapter: an invalid setup resolves as not-ok with the validation errors (no record)", function (check) {
  return SERVICE.runSingle(cfg("edge", { params: Object.assign(TWIN.clone(TWIN.NOMINAL), { a: 0.08, m: 0.3, kJ: 0.1, Jw: 0.005 }) })).then(function (o) {
    check(!o.ok && o.result.outcome.code === "invalid" && !o.record, "invalid");
  });
});
test("Controller set: one setup, three controllers, nothing else changes; the runs share a group", function (check) {
  var base = cfg("edge", { initial: { tilt_deg: 3, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, duration_s: 3, comOffset_m: 0.002 });
  return SERVICE.runControllerSet(base, ["pid", "lqr", "adp"]).then(function (o) {
    check(o.records.length === 3, "three records");
    var cs = o.records.map(function (r) { return r.config.controller.type; });
    check(cs.join() === "pid,lqr,adp", "controllers " + cs);
    var strip = function (r) { var c = TWIN.clone(r.config); c.controller.type = "x"; return JSON.stringify(c); };
    check(strip(o.records[0]) === strip(o.records[1]) && strip(o.records[1]) === strip(o.records[2]), "configurations differ only in the controller");
    check(o.records.every(function (r) { return r.group && r.group.id === o.group.id && r.group.varied === "controller.type"; }), "shared group");
  });
});
test("Reproduce: browser-engine runs re-run identically; runs from other engines are not re-run here", function (check) {
  var rec = RUNS.fromSimulation(TWIN.simulate(cfg("corner", { duration_s: 2 })));
  var r = SERVICE.reproduce(rec);
  check(r.ok && r.identical, "identical re-run");
  rec.origin = { kind: "simulation", engine: "aeris-research-backend" };
  check(!SERVICE.reproduce(rec).ok, "backend run not re-run in the browser");
});
test("Unsupported inputs are listed for the active engine (corner-mode sensor settings)", function (check) {
  var u = SERVICE.unsupportedInputs(cfg("corner", { sensor: { latency_ms: 20 } }));
  check(u.length === 1 && u[0].path === "sensor", JSON.stringify(u));
  check(SERVICE.unsupportedInputs(cfg("edge", {})).length === 0, "none for the default setup");
});

/* ------------------------------------------------------------ jobs */
test("Job states: legal transitions, progress only while running, terminal states are final", function (check) {
  var j = JOBS.create({ kind: "sweep", total: 10 }), seen = [];
  JOBS.subscribe(j, function (x) { seen.push(x.state); });
  var threw = false; try { JOBS.advance(j, 1); } catch (e) { threw = true; } check(threw, "no progress while queued");
  JOBS.move(j, "initializing"); JOBS.move(j, "running"); JOBS.advance(j, 4);
  check(j.progress.done === 4 && Math.abs(j.progress.fraction - 0.4) < 1e-12, "progress 4/10");
  check(/RUNNING · 4 \/ 10 simulations · 40\.0 %/.test(JOBS.describe(j)), JOBS.describe(j));
  JOBS.advance(j, 50); check(j.progress.done === 10, "never beyond the total");
  JOBS.move(j, "analyzing"); JOBS.move(j, "complete");
  threw = false; try { JOBS.move(j, "running"); } catch (e) { threw = true; } check(threw, "complete is terminal");
  threw = false; try { JOBS.move(JOBS.create({}), "complete"); } catch (e) { threw = true; } check(threw, "cannot skip to complete");
  check(seen.join() === "initializing,running,running,running,analyzing,complete", seen.join());
  var c = JOBS.create({}); JOBS.move(c, "cancelled"); check(JOBS.isTerminal(c) && c.finished, "cancel from queued");
});

/* ------------------------------------------------------------ sweeps */
test("Sweep validation: ranges, limits, controllers and helpful messages", function (check) {
  var base = cfg("edge", {});
  var ok = SWEEP.validate({ base: base, mode: "grid", controllers: ["pid", "lqr", "adp"], variables: [{ key: "tilt_deg", min: 0, max: 20, steps: 5 }, { key: "rate_dps", min: -40, max: 40, steps: 5 }], duration_s: 3 });
  check(ok.ok && ok.total === 75 && ok.points === 25, "5×5 grid × 3 controllers = 75 runs");
  var big = SWEEP.validate({ base: base, mode: "grid", variables: [{ key: "tilt_deg", min: 0, max: 20, steps: 20 }, { key: "rate_dps", min: -40, max: 40, steps: 20 }] });
  check(!big.ok && big.errors.some(function (e) { return /more than this engine accepts/.test(e.message); }), "local limit enforced");
  var bad = SWEEP.validate({ base: base, controllers: [], variables: [{ key: "tilt_deg", min: 5, max: 1, steps: 3 }, { key: "nope", min: 0, max: 1 }] });
  var txt = bad.errors.map(function (e) { return e.message; }).join(" | ");
  check(!bad.ok && /at least one controller/.test(txt) && /upper end must be above/.test(txt) && /Unknown variable 'nope'/.test(txt), txt);
  var mc = SWEEP.validate({ base: base, mode: "montecarlo", samples: 20, variables: [{ key: "inertia_scale", min: 0.5, max: 2, dist: "normal", mean: 1, sd: 0 }] });
  check(!mc.ok && mc.errors.some(function (e) { return /positive standard deviation/.test(e.message); }), "normal needs sd > 0");
  var w = SWEEP.validate({ base: base, mode: "random", samples: 5, controllers: ["lqr"], variables: [{ key: "noise_scale", min: 1, max: 3 }] });
  check(w.ok && w.warnings.some(function (x) { return /no effect with ideal sensing/.test(x.message); }), "no-effect variable flagged");
  var inv = SWEEP.validate({ base: cfg("edge", { params: Object.assign(TWIN.clone(TWIN.NOMINAL), { Jw: 0.2 }) }), variables: [{ key: "tilt_deg", min: 0, max: 5, steps: 2 }] });
  check(!inv.ok && inv.errors.some(function (e) { return /^Base setup/.test(e.message); }), "invalid base setup reported");
});
test("Sweep expansion: paired design (every controller sees the same conditions) and seeded sampling", function (check) {
  var def = { base: cfg("edge", {}), mode: "random", samples: 6, seed: 42, controllers: ["pid", "adp"], mass_configs: ["none", "top50"], variables: [{ key: "tilt_deg", min: 0, max: 10 }, { key: "com_y_mm", min: -5, max: 5 }] };
  var a = SWEEP.expand(def), b = SWEEP.expand(def);
  check(a.length === 24, "6 points × 2 masses × 2 controllers");
  check(JSON.stringify(a.map(function (r) { return r.values; })) === JSON.stringify(b.map(function (r) { return r.values; })), "same seed, same points");
  var byPoint = {}; a.forEach(function (r) { var k = r.point + "|" + r.mass_config; (byPoint[k] = byPoint[k] || []).push(r); });
  check(Object.keys(byPoint).every(function (k) { var g = byPoint[k]; return g.length === 2 && JSON.stringify(g[0].values) === JSON.stringify(g[1].values); }), "paired");
  var r0 = a.filter(function (r) { return r.mass_config === "top50"; })[0];
  check(r0.config.attachments.length === 1 && Math.abs(r0.config.attachments[0].pos_m[2] - 0.18) < 1e-12, "mass configuration applied");
  check(Math.abs(r0.config.comShift_m[1] - r0.values.com_y_mm / 1000) < 1e-15, "COM shift applied in metres");
});
test("Local sweep job: real simulations, real progress, analysis computed only from the rows", function (check) {
  var def = { base: cfg("edge", {}), mode: "grid", controllers: ["lqr", "pid"], variables: [{ key: "tilt_deg", min: 0, max: 12, steps: 4 }, { key: "rate_dps", min: -30, max: 30, steps: 3 }], duration_s: 3 };
  var states = [], job = LocalSimulatorAdapter.submitSweep(def, { sync: true });
  check(job.state === "complete", "state " + job.state + " " + (job.error && job.error.message));
  var res = job.result;
  check(res && res.rows.length === 24 && job.progress.done === 24, "24 runs done");
  check(res.provenance.demo === true && res.provenance.mock === false && /browser/.test(res.provenance.note), "provenance says browser demo, not mock");
  var an = res.analysis, lqr = an.controllers.lqr;
  check(lqr.n === 12 && lqr.recovered === res.rows.filter(function (r) { return r.controller === "lqr" && r.outcome === "recovered"; }).length, "counts come from the rows");
  check(an.maps.length === 1 && an.maps[0].title === "Domain of attraction" && an.maps[0].cells.lqr.length === 12, "domain-of-attraction map");
  var direct = TWIN.simulate(res.rows[5] && SWEEP.expand(def)[5].config);
  check(direct.outcome.code === res.rows[5].outcome, "row outcome equals a direct simulation of that point");
  check(an.probability.length === 2 && an.boundaries.tilt_deg.lqr.nRecovered + an.boundaries.tilt_deg.lqr.nNot === lqr.valid, "probabilities and boundaries");
});
test("Local sweep job: cancelling keeps partial results and marks the job CANCELLED", function (check) {
  var def = { base: cfg("edge", {}), mode: "grid", controllers: ["lqr"], variables: [{ key: "tilt_deg", min: 0, max: 10, steps: 30 }], duration_s: 2 };
  var job = LocalSimulatorAdapter.submitSweep(def, { budgetMs: 1 });
  return new Promise(function (res) {
    JOBS.subscribe(job, function (j) { if (j.state === "running" && j.progress.done > 0 && !j._cancel) LocalSimulatorAdapter.cancelJob(j); if (JOBS.isTerminal(j)) res(j); });
  }).then(function (j) {
    check(j.state === "cancelled" && j.result && j.result.partial === true && j.result.rows.length < 30 && j.result.rows.length > 0, "cancelled with " + (j.result && j.result.rows.length) + " rows");
  });
});
test("Wilson interval and histograms behave at the edges", function (check) {
  var w = SWEEP.wilson(0, 10); check(w[0] === 0 && w[1] > 0.2 && w[1] < 0.35, "0/10 → [0, ~0.28]: " + w);
  var w2 = SWEEP.wilson(10, 10); check(w2[1] === 1 && w2[0] > 0.65, "10/10: " + w2);
});

/* ------------------------------------------------------------ research API adapter (mock transport) */
test("Research API adapter: submit → poll → COMPLETE → fetch the run; requests follow the contract", function (check) {
  var tr = MockResearchBackend.createTransport(), api = ResearchApiAdapter.create({ baseUrl: "mock://backend", transport: tr, pollMs: 0, mock: true, wait: function () { return Promise.resolve(); } });
  return api.runSingle(cfg("edge", { duration_s: 2 }), { name: "api test" }).then(function (o) {
    check(o.ok && o.record && o.job.state === "complete", "completed");
    check(o.record.origin.engine === "mock-research-backend" && /MOCK/.test(o.record.provenance), "mock provenance is visible");
    var paths = tr.log.map(function (l) { return l.method + " " + l.url.replace("mock://backend", ""); });
    check(paths[0] === "POST /api/v1/simulations" && paths.some(function (p) { return /^GET \/api\/v1\/jobs\//.test(p); }) && /^GET \/api\/v1\/runs\//.test(paths[paths.length - 1]), paths.join(", "));
    check(tr.log[0].body.config && tr.log[0].body.config.schema === "aeris-config/1", "config sent as aeris-config/1");
  });
});
test("Research API adapter: a rejected configuration becomes an invalid outcome with the server's details", function (check) {
  var api = ResearchApiAdapter.create({ baseUrl: "mock://b", transport: MockResearchBackend.createTransport(), wait: function () { return Promise.resolve(); } });
  return api.runSingle(cfg("edge", { params: Object.assign(TWIN.clone(TWIN.NOMINAL), { Jw: 0.2 }) })).then(function () { check(false, "should reject"); }, function (e) {
    check(e.code === "invalid_config" && e.status === 422 && e.details.length > 0, JSON.stringify(e).slice(0, 200));
  });
});
test("Research API adapter: sweep job mirrors server states and delivers the aeris-sweep/1 result", function (check) {
  var api = ResearchApiAdapter.create({ baseUrl: "mock://b", transport: MockResearchBackend.createTransport(), pollMs: 0, mock: true, wait: function () { return Promise.resolve(); } });
  var job = api.submitSweep({ base: cfg("edge", {}), mode: "grid", controllers: ["lqr"], variables: [{ key: "tilt_deg", min: 0, max: 8, steps: 3 }], duration_s: 2 }), seen = [];
  JOBS.subscribe(job, function (j) { if (seen[seen.length - 1] !== j.state) seen.push(j.state); });
  return new Promise(function (res) { (function wait() { if (job.result || job.state === "failed") res(); else setTimeout(wait, 5); })(); }).then(function () {
    check(job.state === "complete" && job.result && job.result.schema === "aeris-sweep/1" && job.result.provenance.mock === true, "state " + job.state);
    check(seen.join() === "initializing,running,analyzing,complete", "states " + seen.join());
    check(job.progress.done === job.progress.total && job.progress.total === 3, "progress " + job.progress.done + "/" + job.progress.total);
  });
});
test("Research API adapter: network failures and bad job states are reported, never guessed", function (check) {
  var api = ResearchApiAdapter.create({ baseUrl: "mock://b", transport: MockResearchBackend.createTransport({ failAll: true }) });
  var p1 = api.runSingle(cfg("edge", {})).then(function () { check(false, "should fail"); }, function (e) { check(e.code === "network" && e.retryable, "network error: " + e.code); });
  var odd = ResearchApiAdapter.create({ baseUrl: "mock://b", wait: function () { return Promise.resolve(); }, transport: function (u, i) { var body = /simulations$/.test(u) ? { job: { id: "j1", state: "weird" } } : {}; return Promise.resolve({ ok: true, status: 200, text: function () { return Promise.resolve(JSON.stringify(body)); } }); } });
  var p2 = odd.runSingle(cfg("edge", {})).then(function () { check(false, "should fail"); }, function (e) { check(e.code === "bad_response", "unknown state rejected: " + e.code); });
  return Promise.all([p1, p2]);
});

/* ------------------------------------------------------------ hardware and replay adapters */
test("Hardware adapter: without a reachable backend it is unavailable and connect() refuses; frames and recordings are validated", function (check) {
  var H = HardwareTelemetryAdapter;   // v5: implemented (telemetry via the research backend), unavailable here (no backend in this test)
  check(!H.available().ok && H.capabilities().implemented === true && H.capabilities().live === false, "unavailable without a backend: " + H.available().reason);
  var p = H.connect().then(function () { check(false, "must not connect"); }, function (e) { check(e.code === "unavailable", e.code); });
  check(H.parseFrame({ t: 0.1, q: [1, 0, 0, 0], w: [0, 0, 0], wheel_rpm: [0, 0, 0] }).ok, "valid frame");
  check(!H.parseFrame({ t: 0.1, q: [2, 0, 0, 0] }).ok, "non-unit quaternion rejected");
  check(!H.importRecording({ schema: "aeris-hardware-run/1" }).ok, "incomplete recording rejected");
  return p;
});
test("Replay adapter: examples are computed from their fixed setups once and then replayed from storage", function (check) {
  var a = ReplayAdapter.example("example-edge-push"), b = ReplayAdapter.example("example-edge-push");
  check(a.ok && !a.stored === false && b.ok && b.stored === true, "stored after first use");
  check(a.record.experiment_id === "AERIS-EXP-000012" && a.record.collection === "example", a.record.experiment_id);
  check(JSON.stringify(a.record.samples) === JSON.stringify(b.record.samples), "same recording");
});

run();

/* The live suites' child-process helper (tests/lib/procs.js), v6 — review finding V52-3 of v5.2.

     node tests/procs.test.js

   P1–P6 drive the helper with fake child processes and fake timers (deterministic, no process is started or killed);
   P7 uses real child processes (Node scripts started here and stopped by the helper). The reviewer's probe executed
   v5.2's helper against two fake children and saw the old child's 5 s timer send SIGKILL to the replacement; P1 runs
   that sequence against the v6 helper. */
"use strict";
var EventEmitter = require("events"), cp = require("child_process");
var PROCS = require("./lib/procs.js");

var results = [], queue = [];
function test(n, f) { queue.push({ n: n, f: f }); }
function run() {
  var i = 0;
  (function next() {
    if (i >= queue.length) return report();
    var t = queue[i++], cur = { name: t.n, ok: true, msgs: [] };
    function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
    var p; try { p = t.f(check); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); }
    Promise.resolve(p).then(function () { results.push(cur); next(); }, function (e) { cur.ok = false; cur.msgs.push("rejected: " + (e && (e.stack || e.message) || e)); results.push(cur); next(); });
  })();
}
function report() {
  var pass = results.filter(function (r) { return r.ok; }).length;
  results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
  console.log("\n" + pass + " / " + results.length + " process-helper tests passed");
  process.exit(pass === results.length ? 0 : 1);
}

/* a fake child: records signals; behaviour on SIGTERM / SIGKILL chosen by the test */
function fakeChild(name, log, onTerm, onKill) {
  var c = new EventEmitter();
  c.name = name; c.exitCode = null; c.signalCode = null;
  c.kill = function (sig) {
    log.push({ name: name, signal: sig });
    var how = sig === "SIGKILL" ? (onKill || "exit") : (onTerm || "exit");
    if (how === "throw") throw new Error("kill " + sig + " failed for " + name);
    if (how === "error") { c.emit("error", new Error("signal " + sig + " could not be delivered to " + name)); return true; }
    if (how === "exit") { c.signalCode = sig; c.emit("exit", null, sig); }
    return true;                                   // "ignore": a stuck child
  };
  return c;
}
/* fake timers: nothing fires until the test says so; cleared timers never fire */
function fakeTimers() {
  var t = { list: [], cleared: 0 };
  t.setTimeout = function (fn, ms) { var h = { fn: fn, ms: ms, cleared: false, fired: false }; t.list.push(h); return h; };
  t.clearTimeout = function (h) { if (h && !h.cleared) { h.cleared = true; t.cleared++; } };
  t.pending = function () { return t.list.filter(function (h) { return !h.cleared && !h.fired; }); };
  t.fireAll = function () { t.pending().forEach(function (h) { h.fired = true; h.fn(); }); };
  t.fireFirst = function () { var h = t.pending().sort(function (a, b) { return a.ms - b.ms; })[0]; if (h) { h.fired = true; h.fn(); } return !!h; };
  return t;
}
function settle() { return new Promise(function (r) { setImmediate(r); }); }

test("P1 The reviewer's sequence: the old child exits on SIGTERM, a replacement starts, the old timer can never kill it (its timer was cleared)", function (check) {
  var log = [], T = fakeTimers();
  var proc = fakeChild("old backend", log);
  return PROCS.stop(proc, { setTimeout: T.setTimeout, clearTimeout: T.clearTimeout }).then(function (r) {
    check(r.code === null && r.signal === "SIGTERM" && !r.forced && !r.stuck, "stopped by SIGTERM: " + JSON.stringify(r));
    proc = fakeChild("replacement backend", log);                 // the global the v5.2 timer read
    check(T.pending().length === 0, "no timer left after the old child exited: " + T.pending().length);
    T.fireAll();                                                   // whatever is left, fires now
    check(!log.some(function (k) { return k.name === "replacement backend"; }), "the replacement received no signal: " + JSON.stringify(log));
    check(log.length === 1 && log[0].signal === "SIGTERM", "only the old child's SIGTERM: " + JSON.stringify(log));
    check(proc.listenerCount("exit") === 0, "the replacement has no listener of the helper");
  });
});

test("P2 A stuck old child is still force-killed — the SIGKILL goes to that child, never to a replacement", function (check) {
  var log = [], T = fakeTimers();
  var old = fakeChild("stuck old backend", log, "ignore", "exit");
  var stopping = PROCS.stop(old, { setTimeout: T.setTimeout, clearTimeout: T.clearTimeout, graceMs: 5000 });
  var replacement = fakeChild("replacement backend", log);
  check(T.fireFirst(), "a fallback timer exists while the child is stuck");
  return stopping.then(function (r) {
    check(r.forced === true && r.signal === "SIGKILL" && !r.stuck, "forced: " + JSON.stringify(r));
    check(JSON.stringify(log) === JSON.stringify([{ name: "stuck old backend", signal: "SIGTERM" }, { name: "stuck old backend", signal: "SIGKILL" }]), "signals: " + JSON.stringify(log));
    T.fireAll();
    check(!log.some(function (k) { return k.name === "replacement backend"; }) && replacement.listenerCount("exit") === 0, "the replacement is untouched");
    check(old.listenerCount("exit") === 0 && old.listenerCount("error") === 0, "no listener left on the old child");
  });
});

test("P3 Idempotent: stopping the same child twice is one stop (one SIGTERM, the same promise); an exited child resolves at once", function (check) {
  var log = [], T = fakeTimers();
  var c = fakeChild("slow", log, "ignore", "exit");
  var a = PROCS.stop(c, { setTimeout: T.setTimeout, clearTimeout: T.clearTimeout }), b = PROCS.stop(c, { setTimeout: T.setTimeout, clearTimeout: T.clearTimeout });
  check(a === b, "the same promise");
  check(log.length === 1, "one SIGTERM: " + JSON.stringify(log));
  c.signalCode = "SIGTERM"; c.emit("exit", null, "SIGTERM");      // it exits on its own
  return a.then(function (r) {
    check(!r.forced && T.pending().length === 0, "no SIGKILL, no timer left: " + JSON.stringify(r));
    var done = fakeChild("done", log); done.exitCode = 0;
    return PROCS.stop(done, { setTimeout: T.setTimeout, clearTimeout: T.clearTimeout }).then(function (r2) {
      check(r2.already === true && log.filter(function (k) { return k.name === "done"; }).length === 0, "an exited child is not signalled: " + JSON.stringify(r2));
      return PROCS.stop(null).then(function (r3) { check(r3.already === true, "no child: nothing to do"); });
    });
  });
});

test("P4 A child that cannot be signalled (kill throws) does not hang the suite or leak timers/listeners", function (check) {
  var log = [], T = fakeTimers();
  var c = fakeChild("unsignallable", log, "throw", "throw");
  var p = PROCS.stop(c, { setTimeout: T.setTimeout, clearTimeout: T.clearTimeout, graceMs: 100, hardLimitMs: 200 });
  T.fireFirst();                                                   // SIGKILL attempt (throws as well)
  T.fireFirst();                                                   // the hard limit
  return p.then(function (r) {
    check(r.stuck === true && r.errors.length === 2, "reported stuck with both errors: " + JSON.stringify(r));
    check(T.pending().length === 0, "no timer left");
    check(c.listenerCount("exit") === 0 && c.listenerCount("error") === 0, "no listener left");
  });
});

test("P5 A process 'error' during the stop is recorded; listeners are removed after the exit", function (check) {
  var log = [], T = fakeTimers();
  var c = fakeChild("erroring", log, "error", "exit");
  var p = PROCS.stop(c, { setTimeout: T.setTimeout, clearTimeout: T.clearTimeout });
  T.fireFirst();                                                   // the fallback SIGKILL: exits
  return p.then(function (r) {
    check(r.errors.length === 1 && /could not be delivered/.test(r.errors[0]) && r.forced, JSON.stringify(r));
    check(c.listenerCount("exit") === 0 && c.listenerCount("error") === 0 && T.pending().length === 0, "clean");
  });
});

test("P6 Timers are bound to their child: two children stopped one after the other each get their own fallback", function (check) {
  var log = [], T = fakeTimers();
  var a = fakeChild("A", log, "ignore", "exit"), b = fakeChild("B", log, "exit", "exit");
  var pa = PROCS.stop(a, { setTimeout: T.setTimeout, clearTimeout: T.clearTimeout });
  return PROCS.stop(b, { setTimeout: T.setTimeout, clearTimeout: T.clearTimeout }).then(function () {
    T.fireAll();                                                   // only A's timers are still pending
    return pa;
  }).then(function (r) {
    var kills = log.filter(function (k) { return k.signal === "SIGKILL"; });
    check(kills.length === 1 && kills[0].name === "A" && r.forced, "the SIGKILL went to A only: " + JSON.stringify(log));
  });
});

/* real processes */
function spawnNode(code) { return cp.spawn(process.execPath, ["-e", code], { stdio: "ignore" }); }
function alive(c) { return c.exitCode === null && c.signalCode === null; }
test("P7 Real processes: a cooperative child stops on SIGTERM; a child that ignores SIGTERM is SIGKILLed after the grace; a replacement started at once survives the old child's grace period", function (check) {
  var coop = spawnNode("setInterval(function () {}, 1000)");
  var stuck = spawnNode("process.on('SIGTERM', function () {}); setInterval(function () {}, 1000)");
  var replacement = null;
  return new Promise(function (r) { setTimeout(r, 300); }).then(function () {          // the stuck child has installed its handler
    return PROCS.stop(coop, { graceMs: 3000 });
  }).then(function (r) {
    check(r.signal === "SIGTERM" && !r.forced, "cooperative child: SIGTERM " + JSON.stringify(r));
    replacement = spawnNode("setInterval(function () {}, 1000)");                      // started right after the old one exited
    return PROCS.stop(stuck, { graceMs: 400 });
  }).then(function (r) {
    check(r.signal === "SIGKILL" && r.forced === true, "stuck child: SIGKILL after the grace " + JSON.stringify(r));
    return new Promise(function (res) { setTimeout(res, 1200); });                   // longer than every grace above
  }).then(function () {
    check(alive(replacement), "the replacement is still running (exit " + replacement.exitCode + ", signal " + replacement.signalCode + ")");
    return PROCS.stop(replacement, { graceMs: 3000 });
  }).then(function (r) {
    check(r.signal === "SIGTERM" && !alive(replacement), "the replacement stops when asked: " + JSON.stringify(r));
  });
});

run();

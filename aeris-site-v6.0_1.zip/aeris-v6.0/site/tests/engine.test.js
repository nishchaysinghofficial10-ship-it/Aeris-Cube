/* Tests for the AERIS Twin engine features added in aeris-twin 0.3.0:
   bit-exact regression against 0.2.0 at default settings, the edge-mode sensor
   pipeline (noise, bias, quantisation, latency, dropout), wheel health, motor
   torque lag, the 3-D base COM shift, research metrics and input flagging.
   Run with:  node tests/engine.test.js */
"use strict";
var path = require("path"), crypto = require("crypto");
var TWIN = require(path.join(__dirname, "..", "js", "core.js"));
var FIX = require(path.join(__dirname, "fixtures", "twin_v0.2_reference.json"));
var DEG = TWIN.DEG, RPM = TWIN.RPM;
var results = [], cur;
function test(n, f) { cur = { name: n, ok: true, msgs: [] }; try { f(); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); } results.push(cur); }
function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
function cfg(mode, o) { var c = TWIN.defaultConfig(mode); Object.keys(o || {}).forEach(function (k) { c[k] = JSON.parse(JSON.stringify(o[k])); }); return c; }
function sha(x) { return crypto.createHash("sha256").update(JSON.stringify(x)).digest("hex"); }
function peakAbs(a) { var m = 0; a.forEach(function (v) { if (Math.abs(v) > m) m = Math.abs(v); }); return m; }
var ini = function (t) { return { tilt_deg: t, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }; };

test("Regression: default settings reproduce aeris-twin 0.2.0 bit-for-bit (13 edge and corner cases)", function () {
  FIX.cases.forEach(function (c, i) {
    var r = TWIN.simulate(cfg(c.mode, c.config));
    check(r.ok && r.outcome.code === c.outcome, "case " + i + " outcome " + r.outcome.code + " vs " + c.outcome);
    check(sha(r.samples.cols) === c.sha256, "case " + i + " samples differ from the 0.2.0 reference");
    Object.keys(c.metrics).forEach(function (k) { check(JSON.stringify(r.metrics[k]) === JSON.stringify(c.metrics[k]), "case " + i + " metric " + k); });
  });
});
test("Sensor model: each setting changes a Kalman-filter run; the same seed repeats exactly", function () {
  var base = { controller: { type: "lqr" }, estimator: { type: "kf" }, initial: ini(2), duration_s: 5, seed: 3 };
  var ref = TWIN.simulate(cfg("edge", base));
  [["gyro_noise_dps", 0.8], ["gyro_bias_dps", 2], ["gyro_bias_walk_dps", 0.05], ["accel_noise_mps2", 0.3], ["gyro_quant_dps", 0.1], ["accel_quant_deg", 0.2], ["latency_ms", 20], ["dropout", 0.3]].forEach(function (kv) {
    var o = JSON.parse(JSON.stringify(base)); o.sensor = {}; o.sensor[kv[0]] = kv[1];
    var a = TWIN.simulate(cfg("edge", o)), b = TWIN.simulate(cfg("edge", o));
    check(a.ok && sha(a.samples.cols) !== sha(ref.samples.cols), kv[0] + " should change the run");
    check(sha(a.samples.cols) === sha(b.samples.cols), kv[0] + " must be deterministic for a fixed seed");
  });
});
test("Sensor model: latency degrades the loop (larger error at 60 ms than at 0 ms)", function () {
  var o = { controller: { type: "lqr" }, estimator: { type: "cf" }, initial: ini(3), duration_s: 6 };
  var a = TWIN.simulate(cfg("edge", o)), o2 = JSON.parse(JSON.stringify(o)); o2.sensor = { latency_ms: 60 };
  var b = TWIN.simulate(cfg("edge", o2));
  check(b.metrics.rmsLean_deg > a.metrics.rmsLean_deg, "RMS lean " + a.metrics.rmsLean_deg + " → " + b.metrics.rmsLean_deg);
});
test("Sensor settings with ideal sensing or in corner mode are flagged as having no effect (never silently ignored)", function () {
  var e = TWIN.validateConfig(cfg("edge", { sensor: { latency_ms: 10 } }));
  check(e.ok && e.warnings.some(function (w) { return w.path === "sensor" && /no effect/.test(w.message); }), "ideal estimator warning");
  var c = TWIN.validateConfig(cfg("corner", { sensor: { gyro_noise_dps: 1 } }));
  check(c.ok && c.warnings.some(function (w) { return w.path === "sensor" && /ideal state feedback/.test(w.message); }), "corner warning");
  var r = TWIN.validateConfig(cfg("edge", { estimator: { type: "kf" }, sensor: { rate_hz: 1000 } }));
  check(r.warnings.some(function (w) { return w.path === "sensor.rate_hz"; }), "IMU rate different from the loop rate is flagged");
});
test("Wheel health: a 50 % wheel never delivers more than half the nominal torque", function () {
  var o = { controller: { type: "lqr" }, initial: ini(6), duration_s: 3, actuator: { wheel_health: { x: 0.5 } } };
  var r = TWIN.simulate(cfg("edge", o)), d = TWIN.derive(TWIN.NOMINAL);
  check(peakAbs(r.samples.cols.T_x) <= 0.5 * d.taumax * (1 + 1e-5), "peak torque " + peakAbs(r.samples.cols.T_x) + " vs " + 0.5 * d.taumax + " (samples are stored to 6 significant digits)");
  var full = TWIN.simulate(cfg("edge", { controller: { type: "lqr" }, initial: ini(6), duration_s: 3 }));
  check(peakAbs(full.samples.cols.T_x) > 0.5 * d.taumax, "the healthy wheel saturates higher");
  var w = TWIN.validateConfig(cfg("edge", { actuator: { wheel_health: { y: 0.3 } } }));
  check(w.warnings.some(function (x) { return /wheel X/.test(x.message); }), "unused wheel health flagged in edge mode");
});
test("Motor lag: the applied torque follows the command as a first-order lag", function () {
  // v5: 125 Hz instead of 200 Hz — 200 Hz does not divide the 500 Hz loop rate (v4 recorded it at 166.7 Hz under a 200 Hz
  // label, defect D, now rejected). The assertions only use the first sample and whole-run hashes.
  var o = { controller: { type: "lqr" }, initial: ini(2), duration_s: 2, record_hz: 125, actuator: { motor_lag_ms: 30 } };
  var r = TWIN.simulate(cfg("edge", o)), S = r.samples.cols;
  /* discrete first-order lag: over the first step the motor delivers (1 − e^(−Δt/τ)) of the deliverable command */
  var d = TWIN.derive(TWIN.NOMINAL);
  function firstStep(lagMs) {
    var q = JSON.parse(JSON.stringify(o)); q.actuator = { motor_lag_ms: lagMs }; var X = TWIN.simulate(cfg("edge", q)).samples.cols;
    var T0 = Math.sign(X.Tc_x[0]) * Math.min(Math.abs(X.Tc_x[0]), d.taumax), f = 1 - Math.exp(-(1 / d.fs) / (lagMs / 1000));
    return { got: X.T_x[0], want: f * T0 };
  }
  [30, 60].forEach(function (L) { var x = firstStep(L); check(Math.abs(x.got - x.want) <= 1e-5 * Math.abs(x.want), L + " ms: first-step torque " + x.got + " vs " + x.want); });
  check(Math.abs(firstStep(60).got) < Math.abs(firstStep(30).got), "a longer lag delivers less torque in the first step");
  var lagless = TWIN.simulate(cfg("edge", { controller: { type: "lqr" }, initial: ini(2), duration_s: 2, record_hz: 125 }));
  check(sha(lagless.samples.cols) !== sha(S), "lag changes the run");
  check(r.ok && r.outcome.code !== "invalid", "30 ms lag is a valid run");
});
test("3-D COM shift: a shift along n̂ equals the scalar edge COM offset; x shifts move the COM along the edge only", function () {
  var d = 0.004, n = TWIN.N_EDGE;
  var a = TWIN.validateConfig(cfg("edge", { comOffset_m: d })).mp, b = TWIN.validateConfig(cfg("edge", { comShift_m: [0, n[1] * d, n[2] * d] })).mp;
  check(Math.abs(a.edge.beta - b.edge.beta) < 1e-12 && Math.abs(a.edge.l - b.edge.l) < 1e-12, "β and l agree");
  var x = TWIN.validateConfig(cfg("edge", { comShift_m: [0.01, 0, 0] })).mp, z = TWIN.validateConfig(cfg("edge", {})).mp;
  check(Math.abs(x.edge.beta - z.edge.beta) < 1e-12 && Math.abs(x.edge.xc - z.edge.xc - 0.01) < 1e-12, "x shift only moves the COM along the edge");
  var big = TWIN.validateConfig(cfg("edge", { comShift_m: [0, 0.2, 0] }));
  check(!big.ok && big.errors.some(function (e) { return e.path === "comShift_m.1"; }), "out-of-range shift rejected");
});
test("Controller structure: full MIMO LQR is rejected with an explanation (not silently replaced)", function () {
  var v = TWIN.validateConfig(cfg("corner", { controller: { type: "lqr", structure: "mimo-lqr" } }));
  check(!v.ok && v.errors.some(function (e) { return e.path === "controller.structure" && /not implemented in the browser engine/.test(e.message); }), "mimo rejected");
});
test("Research metrics: RMS error, control effort, saturation times and margins are consistent", function () {
  var r = TWIN.simulate(cfg("edge", { controller: { type: "lqr" }, initial: ini(3), duration_s: 6 })), m = r.metrics;
  check(m.rmsLean_deg > 0 && m.rmsLean_deg <= m.peakLean_deg, "0 < RMS ≤ peak");
  check(m.effort_Nms > 0, "effort positive");
  check(Math.abs(m.leanMargin_deg - (TWIN.ASSESS.fallEdgeDeg - m.peakLean_deg)) < 1e-12, "lean margin = fall threshold − peak lean");
  check(Math.abs(m.omegaMargin_frac - (1 - m.peakOmega_frac)) < 1e-12, "wheel-speed margin");
  var f = TWIN.simulate(cfg("edge", { controller: { type: "pid" }, initial: ini(0), comOffset_m: 0.003, duration_s: 20 })).metrics;
  check(f.leanMargin_deg === null && f.speedLimited_s > 0 && f.torqueLimited_s > 0, "fallen run: no margin, speed- and torque-limited time recorded");
});

var pass = results.filter(function (r) { return r.ok; }).length;
results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
console.log("\n" + pass + " / " + results.length + " engine tests passed");
process.exit(pass === results.length ? 0 : 1);

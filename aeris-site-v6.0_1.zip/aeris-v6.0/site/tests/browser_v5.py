"""Browser end-to-end checks for v5 (Playwright + Chromium), with REDUCED MOTION (no autoplay) throughout and
bounded waits on the actual completion conditions (never a fixed pause before reading a result).

Run:   python3 tests/browser_v5.py            (starts the research backend, the SYNTHETIC telemetry emulator and a
                                               static server itself, on free local ports, with a temporary database)
       python3 tests/browser_v5.py --shots    (also writes screenshots to tests/screenshots/)

Python for the backend: $AERIS_PYTHON, else backend/.venv/bin/python, else ../.venv/bin/python, else this
interpreter. If the backend cannot be started the backend-dependent checks are reported as NOT RUN (exit code 2).

Covers:
  DEMO (no backend configured): the replay-race fix (a pending setup preview never overwrites a replay; 3-D view,
      telemetry, timeline and record agree), revision-1.2 features refused in DEMO, HARDWARE refused with its reason.
  SIMULATION: configure → validate → run (explicit quaternion initial state, nonlinear controller, MEKF, free
      heading) → inspect and replay → compare → the replay-race check again with a stored backend run → export →
      reload → reproduce.
  Sweep: progress → cancel → partial rows → analyse stored rows → dataset created → finalised → exported with an
      integrity check.
  Telemetry (HARDWARE mode): live frames from the synthetic emulator, SYNTHETIC labels everywhere (banner, 3-D view,
      status strip, recordings, replay, comparison, dataset), stream quality, file replay, 390 px layout.
  Backend stopped: NOT REACHABLE, SIMULATION/HARDWARE disabled with reasons, DEMO still runs.
"""
import asyncio, json, os, sys, pathlib, subprocess, tempfile, time, socket, urllib.request
from playwright.async_api import async_playwright

SITE = pathlib.Path(__file__).resolve().parent.parent
BACKEND = SITE.parent / "backend"
SHOTS = "--shots" in sys.argv
SHOT_DIR = SITE / "tests" / "screenshots"
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else "  →  " + str(detail)[:700]), flush=True)


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def backend_python():
    for c in (os.environ.get("AERIS_PYTHON"), BACKEND / ".venv" / "bin" / "python", SITE.parent.parent / ".venv" / "bin" / "python"):
        if c and pathlib.Path(c).exists():
            return str(c)
    return sys.executable


def wait_http(url, timeout=40):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                return r.status == 200
        except Exception:
            time.sleep(0.25)
    return False


async def shot(page, name):
    if SHOTS:
        SHOT_DIR.mkdir(parents=True, exist_ok=True)
        await page.screenshot(path=str(SHOT_DIR / (name + ".png")))


async def wait_for(page, js, timeout=30000, step=100):
    """Bounded wait for a condition in the page; False if it is not reached in time (the check then fails)."""
    t = 0
    while t < timeout:
        try:
            if await page.evaluate(js):
                return True
        except Exception:
            pass
        await page.wait_for_timeout(step); t += step
    return False


# One sample shown everywhere: the 3-D view, the telemetry panel (its time cell), the timeline, the plots (built for
# this run, cursor at this sample) and the selected record; no setup preview label; nothing playing (reduced motion).
AGREE = """(() => { const s = AERIS_DEBUG.snapshot(), v = s.viewer || {}, pc = s.plotCursor || {};
  const teleOk = s.teleT != null && Math.abs(parseFloat(s.teleT) - s.t) < 6e-4, tlOk = s.tlT != null && Math.abs(parseFloat(s.tlT) - s.t) < 1e-6;
  return { runId: s.runId, idx: s.idx, t: s.t, viewMode: s.viewMode, playing: s.playing, viewerRun: v.runId, viewerIdx: v.idx, viewerT: v.t,
           tlRun: s.tlRun, tlT: s.tlT, teleT: s.teleT, plotsRun: s.plotsRun, plotRun: pc.run, plotIdx: pc.idx, tag: s.tag, pending: s.previewPending,
           ok: s.viewMode === 'replay' && v.runId === s.runId && v.idx === s.idx && s.tlRun === s.runId && tlOk && teleOk
               && s.plotsRun === s.runId && pc.run === s.runId && pc.idx === s.idx && !/setup preview/i.test(s.tag) && !s.playing }; })()"""


async def demo_checks(br, origin):
    ctx = await br.new_context(viewport={"width": 1440, "height": 900}, reduced_motion="reduce")
    await ctx.add_init_script("window.AERIS_CONFIG = {researchApi: {baseUrl: null}};")
    page = await ctx.new_page()
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append("PAGEERROR " + str(e)))
    await page.goto(origin + "/index.html#lab", wait_until="load")
    await wait_for(page, "!!(window.Workspace && window.AERIS_DEBUG)", 20000)

    # ---- the replay race (review finding E): edit the setup (schedules a preview), then open a replay 0–150 ms later
    bad = []
    for delay in (0, 30, 60, 90, 150):
        await page.evaluate("Workspace.openConfig((()=>{const c=AERIS_TWIN.defaultConfig('edge'); c.duration_s=2; c.initial.tilt_deg=3; return c})())")
        await wait_for(page, "!!document.querySelector('[data-path=\"initial.tilt_deg\"]')", 5000)
        await page.fill('[data-path="initial.tilt_deg"]', str(2 + delay / 100))          # schedules the debounced preview
        if delay:
            await page.wait_for_timeout(delay)                                            # the race window under test, not a result wait
        await page.evaluate("Workspace.openExample('example-edge-push'); window.__openedAt = performance.now();")
        ok = await wait_for(page, "AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === 'example-edge-push' && AERIS_DEBUG.snapshot().viewMode === 'replay'", 10000)
        first = await page.evaluate(AGREE)
        # a stale preview would fire one debounce period (90 ms) after the edit: read the state again once that
        # moment has certainly passed (bounded wait on the clock condition, then on no pending preview)
        await wait_for(page, "performance.now() - window.__openedAt > 300 && !AERIS_DEBUG.snapshot().previewPending", 5000, 20)
        later = await page.evaluate(AGREE)
        if not (ok and first["ok"] and later["ok"] and later["runId"] == first["runId"]):
            bad.append({"delay_ms": delay, "first": first, "later": later})
    check("DEMO replay race (E): a setup edit 0–150 ms before opening a replay never overwrites it; view, telemetry, timeline, plots and record agree; no autoplay", not bad, bad[:2])
    await page.evaluate("AERIS_DEBUG.seekTime(0.8)")
    ok = await wait_for(page, "Math.abs(AERIS_DEBUG.snapshot().t - 0.8) < 0.02")
    s = await page.evaluate(AGREE)
    check("DEMO replay: seeking keeps the 3-D view, telemetry, timeline and plots on the same sample", ok and s["ok"] and s["viewerIdx"] == s["idx"] and s["tlT"] is not None and abs(float(s["tlT"]) - s["t"]) < 1e-6, s)
    await shot(page, "v5-01-demo-replay")

    # ---- revision 1.2 features are refused in DEMO (the browser engine cannot execute them), never simplified
    await page.evaluate("""Workspace.openConfig((()=>{const c=AERIS_TWIN.defaultConfig('corner'); c.initial={tilt_deg:null, rate_dps:null, azimuth_deg:null, reference:null,
        attitude_q:[0.880990552979211,0.3399789848371774,-0.3290195188065467,-0.004011442979123468], body_rate_dps:[3,-2,1]}; c.duration_s=2; return c})())""")
    await wait_for(page, "/research backend|DEMO/.test((document.getElementById('valBox')||{}).innerText || '')", 5000)
    before = await page.evaluate("({run: AERIS_DEBUG.W.run ? AERIS_DEBUG.W.run.id : null, saved: AERIS_RUNS.list().length})")
    await page.click("#btnRun", force=True)
    await wait_for(page, "!!AERIS_DEBUG.W.attempt || (AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id !== %s)" % json.dumps(before["run"]), 8000)
    st = await page.evaluate("({run: AERIS_DEBUG.W.run ? AERIS_DEBUG.W.run.id : null, saved: AERIS_RUNS.list().length, attempt: AERIS_DEBUG.W.attempt && AERIS_DEBUG.W.attempt.outcome && AERIS_DEBUG.W.attempt.outcome.code, val: document.getElementById('valBox').innerText})")
    # the invalid attempt clears the replay (browser_check.py) and creates no recording
    check("DEMO refuses the explicit quaternion initial state with a reason naming the research backend; nothing runs",
          st["run"] in (None, before["run"]) and st["saved"] == before["saved"] and st["attempt"] == "invalid" and "initial attitude quaternion" in st["val"] and "research backend" in st["val"].lower(), st)

    # ---- HARDWARE without a backend
    await page.click('.wm-b[data-mode="hardware"]', force=True)
    m = await page.evaluate("[AERIS_SERVICE.getMode(), document.getElementById('wmOff').textContent]")
    check("DEMO page without a backend: HARDWARE refused with its reason (telemetry needs the research backend)", m[0] == "demo" and "Telemetry reaches this site through the AERIS research backend" in m[1], m)
    await page.click("#wk-tel")
    ok = await wait_for(page, "typeof AERIS_TELEMETRY_UI !== 'undefined' && /unavailable/i.test(document.getElementById('tmBanner').innerText)", 10000)
    t = await page.evaluate("[document.getElementById('tmBanner').innerText, document.getElementById('tmConnect').disabled]")
    check("Telemetry tab without a backend says it is unavailable and why; Connect is disabled", ok and t[1] and "No research backend is configured" in t[0], t)
    check("DEMO pages without a backend: no script errors", not errors, errors[:4])
    await ctx.close()


async def simulation_and_telemetry(br, origin, base, be, emu_port):
    cfg = json.dumps({"researchApi": {"baseUrl": base, "wsUrl": base.replace("http", "ws"), "pollMs": 300, "probeMs": 60000, "mock": False}})
    ctx = await br.new_context(viewport={"width": 1440, "height": 900}, reduced_motion="reduce", accept_downloads=True)
    await ctx.add_init_script("window.AERIS_CONFIG = " + cfg + ";")
    page = await ctx.new_page()
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append("PAGEERROR " + str(e)))
    await page.goto(origin + "/index.html#lab", wait_until="load")
    ok = await wait_for(page, "AERIS_SERVICE.modeInfo('simulation').available", 20000)
    check("SIMULATION becomes selectable only after the backend answered its probe", ok)
    await page.click('.wm-b[data-mode="simulation"]')
    await wait_for(page, "AERIS_SERVICE.getMode() === 'simulation'", 5000)

    # ---------------- configure → validate → run (advanced) ----------------
    setup = """(()=>{const c=AERIS_TWIN.defaultConfig('corner'); c.controller.type='nlpd'; c.estimator={type:'mekf', stale_after_s:0.03};
        c.initial={tilt_deg:null, rate_dps:null, azimuth_deg:null, reference:null, attitude_q:[0.880990552979211,0.3399789848371774,-0.3290195188065467,-0.004011442979123468], body_rate_dps:[3,-2,1]};
        c.reference={attitude:'balance', heading:'free', yaw_deg:0}; c.duration_s=3; c.seed=5; return c})()"""
    await page.evaluate("Workspace.openConfig(" + setup + ", {})")
    ok = await wait_for(page, "!!document.querySelector('input[name=\"initForm\"][value=\"explicit\"]:checked') && !!document.getElementById('f_initial_attitude_q_0')", 8000)
    form = await page.evaluate("({q0: document.getElementById('f_initial_attitude_q_0').value, heading: (document.getElementById('f_reference_heading')||{}).value, ctl: document.getElementById('f_controller_type').value})")
    check("Setup form shows the explicit quaternion editor, the objective (free heading) and the research controller", ok and form["q0"].startswith("0.88099") and form["heading"] == "free" and form["ctl"] == "nlpd", form)
    ok = await wait_for(page, "!/error/i.test((document.getElementById('valBox')||{}).className) && /Ready|valid|backend/i.test((document.getElementById('valBox')||{}).innerText)", 10000)
    vb = await page.evaluate("document.getElementById('valBox').innerText")
    check("The setup validates for the research backend (no errors shown)", ok and "error" not in vb.lower().split("warning")[0][:40], vb[:300])
    await page.click("#btnRun")
    ok = await wait_for(page, "AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.origin && AERIS_DEBUG.W.run.origin.engine === 'aeris-research-backend' && !AERIS_DEBUG.W.busy", 60000)
    rec = await page.evaluate("(()=>{const r=AERIS_DEBUG.W.run; return r ? {id:r.id, xid:r.experiment_id, ini:r.executed.initial_state, ref:r.executed.reference, mv:r.reproduction && r.reproduction.metrics_version, playing: AERIS_DEBUG.W.playing} : null})()")
    res = (await page.evaluate("document.getElementById('rp-res').innerText")) if ok else ""
    check("Backend run: explicit initial state and requested vs equilibrium reference recorded; metric version 2; no autoplay",
          ok and rec and rec["mv"] == "2" and rec["ini"] and rec["ini"].get("attitude_from") == "explicit attitude quaternion" and rec["ini"].get("body_rate_dps") == [3, -2, 1]
          and rec["ref"] and rec["ref"].get("requested", {}).get("heading") == "free" and "controller_target" in rec["ref"] and rec["playing"] is False, rec)
    low = res.lower()
    check("Results panel shows metric definitions v2, the control objective, the initial state and the estimate age",
          "version 2" in low and "control objective" in low and "initial state" in low and "estimate age" in low, res[:900])
    await shot(page, "v5-02-simulation-run")

    # ---------------- inspect / replay ----------------
    await page.evaluate("AERIS_DEBUG.seekTime(1.2)")
    ok = await wait_for(page, "Math.abs(AERIS_DEBUG.snapshot().t - 1.2) < 0.03")
    s = await page.evaluate(AGREE)
    check("Replay of the backend run: seeking keeps the 3-D view, telemetry, timeline, plots and record on one sample", ok and s["ok"], s)

    # ---------------- compare (a second backend run of the same setup with LQR) ----------------
    first_id = rec["id"] if rec else None
    await page.evaluate("Workspace.openConfig((()=>{const c=" + setup + "; c.controller.type='lqr'; return c})(), {run: true})")
    ok = await wait_for(page, "AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id !== %s && AERIS_DEBUG.W.run.origin.engine === 'aeris-research-backend' && !AERIS_DEBUG.W.busy" % json.dumps(first_id), 60000)
    second_id = await page.evaluate("AERIS_DEBUG.W.run.id")
    await page.click("#lt-rec")
    await wait_for(page, "!!document.querySelector('[data-cmp=%s]') && !!document.querySelector('[data-cmp=%s]')" % (json.dumps(first_id), json.dumps(second_id)), 8000)
    for rid in (first_id, second_id):
        if not await page.evaluate("document.querySelector('[data-cmp=%s]').checked" % json.dumps(rid)):
            await page.click("[data-cmp=%s] + span" % json.dumps(rid))
    await page.click("#rt-cmp")
    ok = await wait_for(page, "AERIS_DEBUG.W.compare.length >= 2 && /LQR/.test(document.getElementById('rp-cmp').innerText)", 8000)
    cmp_txt = await page.evaluate("document.getElementById('rp-cmp').innerText")
    check("Compare: both backend runs listed with their differing controller", ok and ("nonlinear" in cmp_txt.lower() or "nlpd" in cmp_txt.lower()), cmp_txt[:400])
    await shot(page, "v5-03-compare")
    rs = await page.evaluate("(()=>{const t=document.getElementById('cmpResearch'); return t ? {text: t.innerText, warn: !!document.getElementById('cmpMv')} : null})()")
    check("Compare: research metrics of both backend runs with their definition version (2) and units (IAE °·s, ISE °²·s); no version warning",
          rs and rs["text"].count("version 2") >= 2 and "IAE [°·s]" in rs["text"] and "ISE [°²·s]" in rs["text"] and not rs["warn"], rs)
    # a v4 backend record (research metrics version 1) next to a v5 run: versions named as not comparable, v1 ISE withheld
    fxr = json.loads((SITE / "tests" / "fixtures" / "backend_records.json").read_text(encoding="utf-8"))["records"]
    old = next(r for _, r in sorted(fxr.items()) if r.get("research") and (r["research"].get("attitude_error") or {}).get("ise") is not None)
    await page.evaluate("t => AERIS_DEBUG.doImport(t)", json.dumps(old))
    await page.evaluate("Workspace.openRun(AERIS_RUNS.load(%s).record, {})" % json.dumps(first_id))     # re-renders the recordings list
    ok = await wait_for(page, "AERIS_RUNS.load(%s).ok && !!document.querySelector('[data-cmp=%s]')" % (json.dumps(old["id"]), json.dumps(old["id"])), 8000)
    await page.click("#lt-rec")
    if await page.evaluate("document.querySelector('[data-cmp=%s]').checked" % json.dumps(second_id)):
        await page.click("[data-cmp=%s] + span" % json.dumps(second_id))
    if not await page.evaluate("document.querySelector('[data-cmp=%s]').checked" % json.dumps(old["id"])):
        await page.click("[data-cmp=%s] + span" % json.dumps(old["id"]))
    await page.click("#rt-cmp")
    ok = ok and await wait_for(page, "!!document.getElementById('cmpMv') && AERIS_DEBUG.W.compare.indexOf(%s) >= 0" % json.dumps(old["id"]), 8000)
    mixed = await page.evaluate("(()=>{const t=document.getElementById('cmpResearch'); const w=document.getElementById('cmpMv'); return {text: t ? t.innerText : '', warn: w ? w.innerText : ''}})()")
    check("Compare with a v4 backend record: metric versions 1 and 2 named as not comparable; the version-1 ISE is withheld, never shown as °²·s",
          ok and "not comparable" in mixed["warn"] and "version 1" in mixed["text"] and "version 2" in mixed["text"] and "withheld" in mixed["text"], mixed)
    if SHOTS and ok:
        await page.evaluate("document.getElementById('cmpResearch').scrollIntoView({block: 'center'})")
        await shot(page, "v5-03b-compare-metric-versions")

    # ---------------- the replay race (E) in SIMULATION: a setup edit 0–150 ms before opening a stored backend run
    # from the recordings list (the real button and handler), reduced motion, autoplay off
    bad = []
    for delay in (0, 30, 60, 90, 150):
        await page.evaluate("Workspace.openConfig((()=>{const c=AERIS_TWIN.defaultConfig('edge'); c.duration_s=2; c.initial.tilt_deg=3; return c})(), {})")
        await wait_for(page, "!!document.querySelector('[data-path=\"initial.tilt_deg\"]')", 5000)
        await page.fill('[data-path="initial.tilt_deg"]', str(2 + delay / 100))          # schedules the debounced preview
        if delay:
            await page.wait_for_timeout(delay)                                            # the race window under test, not a result wait
        opened = await page.evaluate("(()=>{const b=document.querySelector('.rec-open[data-id=%s]'); if(!b) return false; b.click(); window.__openedAt=performance.now(); return true})()" % json.dumps(first_id))
        ok = opened and await wait_for(page, "AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === %s && AERIS_DEBUG.snapshot().viewMode === 'replay'" % json.dumps(first_id), 10000)
        first = await page.evaluate(AGREE)
        await wait_for(page, "performance.now() - window.__openedAt > 300 && !AERIS_DEBUG.snapshot().previewPending", 5000, 20)
        later = await page.evaluate(AGREE)
        xid = (rec or {}).get("xid") or first_id
        if not (ok and first["ok"] and later["ok"] and later["runId"] == first_id and xid and xid in (later["tag"] or "")):
            bad.append({"delay_ms": delay, "opened": opened, "first": first, "later": later})
    check("SIMULATION replay race (E): a setup edit 0–150 ms before opening a stored backend run never overwrites it; view, telemetry, timeline, plots and record agree; no autoplay", not bad, bad[:2])

    # ---------------- save / export / reload / reproduce ----------------
    await page.evaluate("Workspace.openRun(AERIS_RUNS.load(%s).record, {})" % json.dumps(first_id))
    await wait_for(page, "AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === %s" % json.dumps(first_id), 8000)
    await page.click("#rt-res")
    await wait_for(page, "!!document.querySelector('#rp-res .acts2 [data-a=\"json\"]')", 5000)
    await page.click('#rp-res .acts2 [data-a="json"]')
    ok = await wait_for(page, "!!AERIS_DEBUG.lastExportText()", 5000)
    exp = json.loads(await page.evaluate("AERIS_DEBUG.lastExportText()")) if ok else {}
    await page.keyboard.press("Escape")
    check("Export JSON of the backend run carries its id, executed method, reference and metric version", exp.get("id") == first_id and exp.get("executed", {}).get("controller", {}).get("type") == "nlpd" and exp.get("reproduction", {}).get("metrics_version") == "2", {k: exp.get(k) for k in ("id", "experiment_id")})
    before = await page.evaluate("JSON.stringify(AERIS_RUNS.load(%s).record)" % json.dumps(first_id))
    await page.reload(wait_until="load")
    ok = await wait_for(page, "!!(window.AERIS_DEBUG && AERIS_RUNS.load(%s).ok && AERIS_SERVICE.modeInfo('simulation').available)" % json.dumps(first_id), 20000)
    after = await page.evaluate("JSON.stringify(AERIS_RUNS.load(%s).record)" % json.dumps(first_id))
    check("After a reload the saved backend run is unchanged", ok and before == after)
    await page.evaluate("Workspace.openRun(AERIS_RUNS.load(%s).record, {})" % json.dumps(first_id))
    await wait_for(page, "AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.id === %s && !!document.querySelector('#rp-res [data-a=\"repro\"]')" % json.dumps(first_id), 8000)
    await page.click('.wm-b[data-mode="simulation"]')
    await page.click('#rp-res [data-a="repro"]')
    ok = await wait_for(page, "/reproduced every saved sample exactly|differ|could not|not/.test((document.getElementById('reproOut')||{}).innerText || '') && !/Asking/.test(document.getElementById('reproOut').innerText)", 60000)
    ro = await page.evaluate("document.getElementById('reproOut').innerText")
    check("Reproduce on the backend after the reload: every saved sample reproduced exactly", ok and "reproduced every saved sample exactly" in ro, ro)

    # ---------------- sweep → progress → cancel → partial → analyse → dataset → finalise → export ----------------
    # the sweep's base setup is the Single-experiment draft: use a legacy-initial edge setup (a tilt/rate grid cannot
    # vary the legacy tilt of an explicit-quaternion setup; the sweep validation refuses that combination)
    await page.evaluate("Workspace.openConfig(AERIS_TWIN.defaultConfig('edge'), {})")
    await page.click("#wk-sweep")
    await wait_for(page, "typeof AERIS_SWEEP_UI !== 'undefined' && !!document.querySelector('[data-preset=\"doa\"]')", 15000)
    await page.click('[data-preset="doa"]')
    ok = await wait_for(page, "/147 runs/.test((document.getElementById('swVal')||{}).innerText || '') && !document.getElementById('swRun').disabled", 15000)
    if not ok:
        check("Sweep definition validates on the backend", False, await page.evaluate("(document.getElementById('swVal')||{}).innerText"))
    await page.click("#swRun")
    ok = await wait_for(page, "AERIS_SWEEP_UI._state.job && AERIS_SWEEP_UI._state.job.state === 'running' && AERIS_SWEEP_UI._state.job.progress.done >= 6", 90000)
    prog = await page.evaluate("(()=>{const j=AERIS_SWEEP_UI._state.job; return {done:j.progress.done, total:j.progress.total, text: document.getElementById('swJob').innerText}})()")
    check("Sweep progress is shown while it runs on the backend", ok and 0 < prog["done"] < prog["total"] and str(prog["done"]) in prog["text"], prog)
    await page.click("#swCancel")
    ok = await wait_for(page, "AERIS_SWEEP_UI._state.job && AERIS_SWEEP_UI._state.job.state === 'cancelled' && !!AERIS_SWEEP_UI._state.result", 60000)
    part = await page.evaluate("(()=>{const r=AERIS_SWEEP_UI._state.result; return r ? {id:r.id, partial:r.partial, n:r.rows.length, total:r.total} : null})()")
    out = await page.evaluate("document.getElementById('swOut').innerText")
    check("Cancelled sweep: the finished rows are retrieved and labelled PARTIAL", ok and part and part["partial"] and part["n"] >= 6 and "PARTIAL sweep" in out, part)
    await wait_for(page, "!!document.querySelector('[data-sw=\"beAnalyze\"]')", 5000)
    await page.click('[data-sw="beAnalyze"]')
    ok = await wait_for(page, "/Analysed \\d+ stored rows/.test((document.getElementById('swBeOut')||{}).innerText || '')", 30000)
    note = await page.evaluate("(AERIS_SWEEP_UI._state.result.analysis_note || '') + ' | ' + document.getElementById('swOut').innerText.slice(0, 50)")
    check("'Analyse stored rows' asks the backend for the analysis of the partial rows", ok and "stored rows" in note, note[:200])
    await page.click('[data-sw="beDataset"]')
    ok = await wait_for(page, "/AERIS-DS-\\d+/.test((document.getElementById('swBeOut')||{}).innerText || '')", 15000)
    await page.click('[data-sw="beFinalize"]')
    ok2 = await wait_for(page, "/FINAL/.test((document.getElementById('swBeOut')||{}).innerText || '')", 15000)
    await page.click('[data-sw="beExport"]')
    ok3 = await wait_for(page, "!!AERIS_SWEEP_UI._state.lastBundle", 15000)
    bundle = await page.evaluate("AERIS_SWEEP_UI._state.lastBundle && {schema: AERIS_SWEEP_UI._state.lastBundle.schema, status: AERIS_SWEEP_UI._state.lastBundle.dataset.status, integrity: AERIS_SWEEP_UI._state.lastBundle.integrity, rows: AERIS_SWEEP_UI._state.lastBundle.members.sweeps[0].rows.length, partial: AERIS_SWEEP_UI._state.lastBundle.members.sweeps[0].partial}")
    await page.keyboard.press("Escape")
    check("Dataset from the cancelled sweep: created, finalised (immutable) and exported with an intact integrity check",
          ok and ok2 and ok3 and bundle and bundle["schema"] == "aeris-dataset-bundle/1" and bundle["status"] == "final" and bundle["integrity"]["members_hash_ok"] and bundle["integrity"]["member_content_ok"] and bundle["partial"] and bundle["rows"] == part["n"], bundle)
    await shot(page, "v5-04-sweep-dataset")

    # ---------------- telemetry (HARDWARE mode) ----------------
    ok = await wait_for(page, "AERIS_SERVICE.modeInfo('hardware').available", 10000)
    await page.click('.wm-b[data-mode="hardware"]')
    ok = ok and await wait_for(page, "AERIS_SERVICE.getMode() === 'hardware' && AERIS_DEBUG.snapshot().kind === 'telemetry' && typeof AERIS_TELEMETRY_UI !== 'undefined' && !document.getElementById('tmConnect').disabled", 15000)
    b0 = await page.evaluate("document.getElementById('tmBanner').innerText")
    check("HARDWARE mode opens the Telemetry tab; before a source connects it says so (no connection claimed)", ok and "NO TELEMETRY SOURCE" in b0.upper(), b0)   # innerText follows CSS upper case
    await page.fill("#tmPort", str(emu_port))
    await page.click("#tmConnect")
    ok = await wait_for(page, "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return s.connected && s.kind === 'synthetic' && s.viewer && s.viewer.n > 20 && s.transport === 'websocket'; })()", 20000)
    snap1 = await page.evaluate("AERIS_TELEMETRY_UI.snapshot()")
    await wait_for(page, "AERIS_TELEMETRY_UI.snapshot().viewer.n > %d" % ((snap1.get("viewer") or {}).get("n") or 0), 5000)
    snap2 = await page.evaluate("AERIS_TELEMETRY_UI.snapshot()")
    ui = await page.evaluate("({banner: document.getElementById('tmBanner').innerText, tag: document.getElementById('tmTag').innerText, strip: Object.fromEntries(AERIS_STATUS.snapshot().map(x => [x.key, x.value]))})")
    check("Live synthetic telemetry over the WebSocket: the 3-D view follows new frames", ok and snap2["viewer"]["n"] > snap1["viewer"]["n"], [snap1, snap2])
    check("The emulator is labelled SYNTHETIC in the banner, on the 3-D view and in the status strip — never HARDWARE",
          "SYNTHETIC EMULATOR" in ui["banner"].upper() and "NOT THE PHYSICAL CUBE" in ui["banner"].upper() and "SYNTHETIC" in ui["tag"].upper() and ui["strip"]["source"] == "SYNTHETIC TELEMETRY", ui)
    q = await page.evaluate("Object.fromEntries([...document.querySelectorAll('#tmQuality td[data-q]')].map(td => [td.dataset.q, td.textContent]))")
    check("Stream quality shows accepted frames, duplicates, gaps and the live transport", int(q.get("Frames accepted", "0")) > 20 and "Duplicates dropped" in q and "Gaps · frames missing" in q and "WebSocket live" in q.get("This page", ""), q)
    await shot(page, "v5-05-telemetry-live")
    await page.fill("#tmRecName", "browser v5 recording")
    await page.click("#tmRecStart")
    await wait_for(page, "AERIS_TELEMETRY_UI.snapshot().recording", 5000)
    n0 = (await page.evaluate("AERIS_TELEMETRY_UI.snapshot()"))["latest"]["n"]
    await wait_for(page, "AERIS_TELEMETRY_UI.snapshot().latest.n > %d" % (n0 + 80), 15000)
    await page.click("#tmRecStop")
    ok = await wait_for(page, "/Stored as AERIS-HW-\\d+/.test(document.getElementById('tmRecState').innerText)", 15000)
    rs = await page.evaluate("document.getElementById('tmRecState').innerText")
    rid = rs.split("Stored as ")[1].split()[0] if ok else None
    await wait_for(page, "!!document.querySelector('tr[data-rec=%s]')" % json.dumps(rid), 10000)
    row = await page.evaluate("(document.querySelector('tr[data-rec=%s]') || {}).innerText || ''" % json.dumps(rid))
    check("Recording stored on the backend and listed as SYNTHETIC (emulator)", ok and "SYNTHETIC" in rs.upper() and "SYNTHETIC" in row.upper() and "emulator" in row, [rs, row])
    await page.click("[data-replay=%s]" % json.dumps(rid))
    ok = await wait_for(page, "/^REPLAY/.test(document.getElementById('tmBannerT').textContent) && /SYNTHETIC/.test(document.getElementById('tmBannerT').textContent)", 15000)
    rb = await page.evaluate("[document.getElementById('tmBannerT').textContent, Object.fromEntries(AERIS_STATUS.snapshot().map(x => [x.key, x.value])).source]")
    check("Replaying the stored recording keeps the SYNTHETIC label (REPLAY · SYNTHETIC …)", ok and rb[1] == "SYNTHETIC TELEMETRY", rb)
    await page.click("[data-cmp=%s]" % json.dumps(rid))
    await wait_for(page, "!!document.getElementById('tmCmpRun')", 10000)
    await page.select_option("#tmCmpRun", first_id)
    await page.click("#tmCmpGo")
    ok = await wait_for(page, "/Not validation evidence|Admissible/.test((document.getElementById('tmCmpOut')||{}).innerText || '')", 20000)
    co = await page.evaluate("document.getElementById('tmCmpOut').innerText")
    check("Comparison of the synthetic recording with a simulated run: computed, but NOT validation evidence (reason: SYNTHETIC)", ok and "Not validation evidence" in co and "SYNTHETIC" in co and "never promotes" in co, co[:500])
    await page.click("[data-ds=%s]" % json.dumps(rid))
    ok = await wait_for(page, "/Dataset AERIS-DS-/i.test((document.getElementById('tmCmp')||{}).innerText || '')", 10000)
    dso = await page.evaluate("document.getElementById('tmCmp').innerText")
    check("A dataset of the recording is marked synthetic-telemetry and says it contains SYNTHETIC data", ok and "synthetic-telemetry" in dso and "SYNTHETIC" in dso, dso[:300])
    await page.click('input[name="tmKind"][value="file"]')
    await wait_for(page, "!!document.querySelector('#tmFile option[value=\"session.ndjson\"]')", 10000)
    await page.fill("#tmSpeed", "0")
    await page.click("#tmConnect")
    ok = await wait_for(page, "/^REPLAY/.test(document.getElementById('tmBannerT').textContent) && /file session\\.ndjson/.test(document.getElementById('tmSrc').innerText)", 15000)
    check("File replay from the telemetry directory goes through the same path and stays SYNTHETIC", ok, await page.evaluate("[document.getElementById('tmBannerT').textContent, document.getElementById('tmSrc').innerText]"))
    await page.click("#tmDisconnect")
    await shot(page, "v5-06-telemetry-records")
    await page.set_viewport_size({"width": 390, "height": 844})
    await wait_for(page, "document.documentElement.clientWidth <= 390", 3000)
    ov = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    await shot(page, "v5-07-telemetry-390")
    check("No horizontal scrolling on the Telemetry tab at 390 px", ov <= 1, ov)
    await page.set_viewport_size({"width": 1440, "height": 900})

    # ---------------- backend stopped ----------------
    be.terminate(); be.wait(timeout=20)
    await page.click("#wk-single")
    await page.click('#wsModes [data-probe]')
    ok = await wait_for(page, "/not reachable/.test((document.getElementById('wmBackend')||{}).textContent)", 20000)
    dis = await page.evaluate("['simulation','hardware'].map(m => document.querySelector('.wm-b[data-mode=\"' + m + '\"]').getAttribute('aria-disabled'))")
    check("Backend stopped: NOT REACHABLE, SIMULATION and HARDWARE disabled with reasons", ok and dis == ["true", "true"], dis)
    await page.click('.wm-b[data-mode="demo"]')
    await page.evaluate("Workspace.openConfig((()=>{const c=AERIS_TWIN.defaultConfig('edge'); c.duration_s=2; return c})(), {run:true})")
    ok = await wait_for(page, "AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.origin.engine === 'aeris-twin-js' && !AERIS_DEBUG.W.busy", 20000)
    check("DEMO keeps working after the backend is gone", ok)
    rest = [e for e in errors if "Failed to load resource" not in e and "ERR_CONNECTION_REFUSED" not in e and "WebSocket connection" not in e]
    check("No script errors during the SIMULATION/telemetry session", not rest, rest[:5])
    await ctx.close()


async def main():
    bport, sport, eport = free_port(), free_port(), free_port()
    base, origin = f"http://127.0.0.1:{bport}", f"http://127.0.0.1:{sport}"
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="aeris-e2e5-"))
    (tmp / "telemetry").mkdir()
    py = backend_python()
    subprocess.run([py, "-m", "aeris_backend.telemetry.emulator", "--write", str(tmp / "telemetry" / "session.ndjson"), "--frames", "300", "--rate", "50"],
                   cwd=str(BACKEND), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    be = subprocess.Popen([py, "-m", "aeris_backend.api.main", "--port", str(bport), "--db", str(tmp / "e2e.sqlite3"), "--workers", "2", "--cors", origin,
                           "--telemetry-dir", str(tmp / "telemetry"), "--log-level", "warning"], cwd=str(BACKEND), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    emu = subprocess.Popen([py, "-m", "aeris_backend.telemetry.emulator", "--port", str(eport), "--faults", "drop=0.02,duplicate=0.02,reorder=0.01"],
                           cwd=str(BACKEND), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    web = subprocess.Popen([sys.executable, "-m", "http.server", str(sport), "--bind", "127.0.0.1", "--directory", str(SITE)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    code = 0
    try:
        wait_http(origin + "/index.html")
        async with async_playwright() as p:
            br = await p.chromium.launch(args=ARGS)
            await demo_checks(br, origin)
            if not wait_http(base + "/api/v1/health"):
                err = be.stderr.read().decode()[-600:] if be.poll() is not None else "no answer"
                print("NOT RUN: the research backend could not be started with " + py + ": " + err)
                code = 2
            else:
                await simulation_and_telemetry(br, origin, base, be, eport)
            await br.close()
    finally:
        for proc in (be, emu, web):
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=10)
                except Exception:
                    proc.kill()
    n = sum(1 for r in results if r[1])
    print(f"\n{n} / {len(results)} v5 browser checks passed" + (" (backend checks NOT RUN)" if code == 2 else ""))
    return code if code else (0 if n == len(results) else 1)


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))

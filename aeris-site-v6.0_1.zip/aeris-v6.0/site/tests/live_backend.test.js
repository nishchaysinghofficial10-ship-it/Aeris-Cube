/* Live integration test: the site's real ResearchApiAdapter and experiment service against the RUNNING
   Python research backend (uvicorn, real HTTP and WebSocket, temporary SQLite database).

     node tests/live_backend.test.js            (starts and stops the backend itself)

   Python: $AERIS_PYTHON, else backend/.venv/bin/python, else ../.venv/bin/python, else python3.
   If the backend cannot be started, every test is reported as NOT RUN (exit code 2), never as passed.

   Covers: probe and capabilities, a legacy run (checked against the browser engine), an advanced
   controller/estimator run, persisted retrieval, save/export/import without metadata changes,
   reproduction, a controller set, a complete sweep with its saved per-row configurations, cancellation
   during and before execution with partial results, the authoritative backend validation, hardware
   status, the telemetry path with the standalone SYNTHETIC emulator (v5), the telemetry stream across a real backend
   process restart (v5.1), and DEMO mode continuing to work after the backend goes away. */
"use strict";
var path = require("path"), fs = require("fs"), os = require("os"), vm = require("vm"), cp = require("child_process");
global.window = { AERIS_CONFIG: { researchApi: { baseUrl: null } } };
var J = function (p) { return require(path.join(__dirname, "..", "js", p)); };
global.AERIS_IDS = J("platform/ids.js");
global.AERIS_TWIN = J("core.js");
global.AERIS_SCHEMA = J("platform/schema.js");
global.AERIS_EVENTS = J("platform/events.js");
global.AERIS_CFG = J("platform/config.js");
global.AERIS_RUNS = J("runs.js");
global.AERIS_JOBS = J("platform/jobs.js");
global.AERIS_SWEEP = J("platform/sweep.js");
global.AERIS_EXAMPLES = J("platform/examples.js");
global.LocalSimulatorAdapter = J("adapters/local-simulator.js");
global.ReplayAdapter = J("adapters/replay.js");
global.ResearchApiAdapter = J("adapters/research-api.js");
// AERIS_TELEMETRY_ADAPTER_UNDER_TEST: run these tests against another copy of the adapter (e.g. the unmodified v5.2 file,
// to show what a test detects); the summary names it
global.HardwareTelemetryAdapter = process.env.AERIS_TELEMETRY_ADAPTER_UNDER_TEST ? require(path.resolve(process.env.AERIS_TELEMETRY_ADAPTER_UNDER_TEST)) : J("adapters/hardware-telemetry.js");
var SERVICE = J("platform/service.js");
var PROCS = require("./lib/procs.js");
var TWIN = global.AERIS_TWIN, RUNS = global.AERIS_RUNS, JOBS = global.AERIS_JOBS, CFG = global.AERIS_CFG;

var ROOT = path.join(__dirname, "..", ".."), BACKEND = path.join(ROOT, "backend");
var PORT = 18000 + Math.floor(Math.random() * 2000), BASE = "http://127.0.0.1:" + PORT;
var DB = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "aeris-live-")), "live.sqlite3");
var proc = null, api = null, logTail = [];
function pythonPath() {
  var c = [process.env.AERIS_PYTHON, path.join(BACKEND, ".venv", "bin", "python"), path.join(ROOT, "..", ".venv", "bin", "python"), "python3"].filter(Boolean);
  for (var i = 0; i < c.length; i++) { if (c[i] === "python3" || fs.existsSync(c[i])) return c[i]; }
  return "python3";
}
function startBackend() {
  var py = pythonPath();
  proc = cp.spawn(py, ["-m", "aeris_backend.api.main", "--port", String(PORT), "--db", DB, "--workers", "2", "--max-jobs", "2", "--log-level", "warning"], { cwd: BACKEND, env: Object.assign({}, process.env, { PYTHONUNBUFFERED: "1" }) });
  proc.stdout.on("data", function (d) { logTail.push(String(d)); if (logTail.length > 50) logTail.shift(); });
  proc.stderr.on("data", function (d) { logTail.push(String(d)); if (logTail.length > 50) logTail.shift(); });
  var t0 = Date.now();
  return new Promise(function (res, rej) {
    (function poll() {
      fetch(BASE + "/api/v1/health").then(function (r) { return r.json(); }).then(function (h) { if (h.status === "ok") res({ python: py, health: h }); else throw new Error("unhealthy"); })
        .catch(function () { if (exited()) return rej(new Error("backend exited (" + (proc.exitCode !== null ? proc.exitCode : proc.signalCode) + "): " + logTail.join("").slice(-800))); if (Date.now() - t0 > 40000) return rej(new Error("backend did not start within 40 s")); setTimeout(poll, 250); });
    })();
  });
}
function exited() { return PROCS.exited(proc); }
/* v6 (review finding V52-3): the child being stopped is captured when the stop begins; its fallback timer is cleared when it
   exits and can never reach a replacement backend; repeated stops are idempotent (tests/lib/procs.js) */
function stopBackend() { return PROCS.stop(proc); }

var results = [], queue = [], started = null;
// AERIS_LIVE_ONLY=L1,L14,L15 runs a selection (diagnosis only: a selection is reported as such and is never the suite result)
var ONLY = (process.env.AERIS_LIVE_ONLY || "").split(",").map(function (x) { return x.trim(); }).filter(Boolean);
function test(n, f) { if (ONLY.length && ONLY.indexOf(n.split(" ")[0]) < 0) return; queue.push({ n: n, f: f }); }
function cfg(mode, o) { var c = TWIN.defaultConfig(mode); Object.keys(o || {}).forEach(function (k) { c[k] = JSON.parse(JSON.stringify(o[k])); }); return c; }
function same(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
function until(job, pred, ms) { var t0 = Date.now(); return new Promise(function (res, rej) { (function w() { if (pred(job)) return res(job); if (Date.now() - t0 > (ms || 120000)) return rej(new Error("timeout; job " + job.state + " " + JSON.stringify(job.progress))); setTimeout(w, 20); })(); }); }
var shared = {};
function run() {
  var i = 0;
  (function next() {
    if (i >= queue.length) return stopBackend().then(report);
    var t = queue[i++], cur = { name: t.n, ok: true, msgs: [], ms: 0 }, t0 = Date.now();
    function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
    var p; try { p = t.f(check); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); }
    var guard, limit = new Promise(function (_, rej) { guard = setTimeout(function () { rej(new Error("test timed out after 240 s")); }, 240000); });
    function done() { clearTimeout(guard); cur.ms = Date.now() - t0; results.push(cur); console.log((cur.ok ? "  ok  " : "  FAIL ") + t.n + " (" + (cur.ms / 1000).toFixed(1) + " s)"); next(); }
    Promise.race([Promise.resolve(p), limit]).then(done, function (e) { cur.ok = false; cur.msgs.push("rejected: " + (e && (e.stack || e.message) || JSON.stringify(e))); done(); });
  })();
}
function report() {
  var pass = results.filter(function (r) { return r.ok; }).length;
  results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + " (" + (r.ms / 1000).toFixed(1) + " s)" + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
  console.log("\nbackend: " + (started ? started.python + " · " + started.health.backend + " " + started.health.version + " · " + BASE : "not started") + " · job updates received over: " + (shared.transport || "—"));
  if (process.env.AERIS_TELEMETRY_ADAPTER_UNDER_TEST) console.log("telemetry adapter under test: " + path.resolve(process.env.AERIS_TELEMETRY_ADAPTER_UNDER_TEST) + " (not the adapter of this package)");
  if (ONLY.length) console.log("SELECTION ONLY (AERIS_LIVE_ONLY=" + ONLY.join(",") + "): a diagnosis, not the live suite result");
  console.log(pass + " / " + results.length + " live backend tests passed");
  process.exit(pass === results.length ? 0 : 1);
}

/* ------------------------------------------------------------------------------------------ */
test("L1 Probe: health and REPORTED capabilities make SIMULATION selectable; nothing is guessed before", function (check) {
  api = ResearchApiAdapter.create({ baseUrl: BASE, wsUrl: BASE.replace(/^http/, "ws"), pollMs: 150, timeoutMs: 30000 });
  SERVICE.register(api);
  check(!SERVICE.modeInfo("simulation").available, "not selectable before the probe");
  return SERVICE.probe().then(function (st) {
    check(st.reachable === true && st.capabilitiesReported === true && st.health.backend === "aeris-research-backend", "reachable: " + JSON.stringify(st).slice(0, 200));
    var c = api.capabilities();
    check(c.engine === "aeris-research-backend" && c.structures.indexOf("mimo-lqr") >= 0 && c.estimators.corner.indexOf("mekf") >= 0 && c.sweep.controllers.indexOf("nlpd") >= 0, "capabilities as reported");
    check(SERVICE.setMode("simulation").ok && SERVICE.route("single") === api, "SIMULATION mode routes to the research backend");
  });
});
test("L2 Legacy single run on the backend: validated record, backend provenance, parity with the browser engine", function (check) {
  var c = cfg("edge", { initial: { tilt_deg: 4, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, duration_s: 3 });
  check(SERVICE.validateConfig(c).ok, "valid for the backend");
  return SERVICE.runSingle(c, { name: "live L2" }).then(function (o) {
    check(o.ok && o.record, "run ok: " + JSON.stringify(o.result && o.result.outcome));
    var r = o.record; shared.legacy = r;
    check(r.origin.engine === "aeris-research-backend" && r.origin.adapter === "research-api" && /^AERIS-EXP-1\d{5}$/.test(r.experiment_id), "origin and id " + r.experiment_id);
    check(r.validation.status === "nominal" && /nominal/i.test(r.provenance), "nominal parameters stated");
    check(o.job.state === "complete" && (o.job.transport === "websocket" || o.job.transport === "polling"), "job followed over " + o.job.transport);
    shared.transport = o.job.transport;
    var b = TWIN.simulate(c), maxd = 0;
    check(b.outcome.code === r.outcome.code, "same outcome as the browser engine: " + b.outcome.code + " / " + r.outcome.code);
    ["theta", "omega_x", "T_x"].forEach(function (k) { var x = r.samples.cols[k], y = b.samples.cols[k]; for (var i = 0; i < Math.min(x.length, y.length); i++) maxd = Math.max(maxd, Math.abs(x[i] - y[i]) / Math.max(1, Math.abs(y[i]))); });
    check(maxd <= 1e-6, "recorded samples agree with the browser engine within 1e-6 (relative, floor 1): " + maxd);
  });
});
test("L3 Advanced run: nonlinear controller + quaternion MEKF + research recovery criteria + impulse", function (check) {
  var c = cfg("corner", { initial: { tilt_deg: 2, rate_dps: 5, azimuth_deg: 30, reference: "geometric" }, duration_s: 4, seed: 11 });
  c.controller.type = "nlpd"; c.estimator = { type: "mekf" };
  c.recovery = { attitude_error_deg: 1, rate_dps: 3, hold_s: 0.5, max_time_s: null, yaw_objective: "free" };
  c.disturbances = [{ id: "I1", type: "impulse", frame: "body", direction: [1, 0, 0], magnitude_Nms: 0.01, t_s: 1.5 }];
  var v = SERVICE.validateConfig(c);
  check(v.ok, "valid against the reported capabilities: " + JSON.stringify(v.errors));
  return SERVICE.runSingle(c, { name: "live L3" }).then(function (o) {
    check(o.ok, "run ok: " + JSON.stringify(o.result && o.result.outcome));
    var r = o.record; shared.advanced = r;
    check(r.executed.controller.type === "nlpd" && r.executed.controller.structure === "nonlinear-full-tensor" && r.executed.controller.gains && r.executed.controller.gains.kp_tilt_per_s2 > 0, "executed controller persisted with its gains");
    check(r.executed.estimator.type === "mekf" && r.executed.estimator.truth_access === false, "estimator: MEKF, no truth access");
    check(same(r.config.recovery, c.recovery) && r.research.recovery.criteria.hold_s === 0.5, "criteria saved with the experiment");
    check(r.research.estimator && typeof r.research.estimator.attitude_rmse_deg === "number", "estimator error measured against the true state");
    check(r.timeline.events.some(function (e) { return e.type === "impulse"; }) && r.executed.impulses_applied.length === 1, "impulse applied and logged");
  });
});
test("L4 Persisted retrieval, browser save/load and export/import keep the backend metadata unchanged", function (check) {
  var r = shared.advanced, meta = function (x) { return JSON.stringify([x.derived, x.design, x.research, x.executed, x.termination, x.reproduction, x.origin, x.experiment_id]); };
  return api.getRun(r.id).then(function (again) {
    check(meta(again) === meta(r), "GET /runs/{id} returns the stored record");
    RUNS.useStorage(RUNS.memoryStore(), false);
    check(RUNS.save(r).ok, "saved");
    var l = RUNS.load(r.id); check(l.ok && meta(l.record) === meta(r), "load keeps metadata");
    var imp = RUNS.parseImport(RUNS.exportJSON([r]));
    check(!imp.errors.length && imp.runs.length === 1 && meta(imp.runs[0]) === meta(r), "export → import keeps metadata: " + imp.errors.join(" "));
  });
});
test("L5 Reproduction on the backend: identical re-run, no browser substitute", function (check) {
  return SERVICE.reproduceAsync(shared.advanced).then(function (o) {
    check(o.ok && o.identical === true && o.engine === "aeris-research-backend", "identical: " + JSON.stringify({ ok: o.ok, identical: o.identical, max: o.maxAbsDiff, msg: o.message }));
    check(o.report && o.report.of_run === shared.advanced.id && o.report.of_experiment === shared.advanced.experiment_id && o.report.max_abs_diff === 0 && o.report.same_config_hash === true, "report names the original run: " + JSON.stringify(o.report));
  });
});
test("L6 Controller set on the backend: LQR, coupled MIMO LQR and the nonlinear controller on one setup", function (check) {
  var c = cfg("corner", { initial: { tilt_deg: 2, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, duration_s: 3 });
  return SERVICE.runControllerSet(c, ["lqr", "lqr-mimo", "nlpd"], { name: "live L6" }).then(function (o) {
    check(o.records.length === 3, "three records: " + o.outcomes.map(function (x) { return x.ok; }));
    var st = o.records.map(function (r) { return r.executed.controller.type + "/" + r.executed.controller.structure; });
    check(same(st, ["lqr/decoupled", "lqr/mimo-lqr", "nlpd/nonlinear-full-tensor"]), "executed methods " + st.join(", "));
    check(o.records[1].design.mimo && o.records[1].design.mimo.controllable_rank === 8 && o.records[1].design.mimo.state_dim === 9, "MIMO design saved (rank 8 of 9)");
    check(o.records.every(function (r) { return r.group && r.group.id === o.group.id; }), "shared group");
  });
});
test("L7 Sweep on the backend: paired seeds, analysis with paired comparison, per-row configuration retrievable", function (check) {
  var def = { revision: "1.1", seed_strategy: "paired", name: "live L7", base: cfg("edge", {}), mode: "grid", controllers: ["lqr", "nlpd"], variables: [{ key: "tilt_deg", min: 1, max: 9, steps: 3 }, { key: "rate_dps", min: -30, max: 30, steps: 2 }], duration_s: 3 };
  var v = SERVICE.validateSweep(def);
  check(v.ok && v.total === 12, "valid, 12 runs: " + JSON.stringify(v.errors));
  var job = SERVICE.submitSweep(def);
  return until(job, function (j) { return j.result || j.state === "failed"; }).then(function () {
    var sw = job.result;
    check(job.state === "complete" && sw && sw.rows.length === 12 && !sw.partial, "complete with 12 rows (" + job.state + ")");
    check(/^AERIS-SWP-1\d{5}$/.test(sw.id) && sw.engine.engine === "aeris-research-backend", "backend sweep id " + sw.id);
    check(sw.analysis && sw.analysis.paired && sw.analysis.paired.length === 1 && sw.analysis.paired[0].pairs === 6, "paired comparison over 6 pairs");
    check(sw.analysis.controllers.lqr.research_rate !== undefined, "research-criteria recovery rate reported");
    var row = sw.rows[3];
    return api.getSweepRow(sw.id, row.index).then(function (full) {
      check(full.config && full.config.controller.type === (row.controller === "lqr" ? "lqr" : "nlpd") && Math.abs(full.config.initial.tilt_deg - row.values.tilt_deg) < 1e-12 && full.config_hash === row.config_hash, "saved configuration of row " + row.index);
    });
  });
});
test("L8 Cancel DURING execution: partial results kept, labelled PARTIAL, terminal state final", function (check) {
  var def = { revision: "1.1", name: "live L8", base: cfg("corner", {}), mode: "grid", controllers: ["lqr", "pid"], variables: [{ key: "tilt_deg", min: 0, max: 10, steps: 20 }, { key: "rate_dps", min: -40, max: 40, steps: 10 }], duration_s: 4 };
  var job = SERVICE.submitSweep(def), cancelled = false, states = [];
  JOBS.subscribe(job, function (j) { if (states[states.length - 1] !== j.state) states.push(j.state); if (j.state === "running" && j.progress.done >= 6 && !cancelled) { cancelled = true; SERVICE.cancel(j); } });
  return until(job, function (j) { return (j.result || j.state === "failed") && JOBS.isTerminal(j); }, 180000).then(function () {
    var sw = job.result;
    check(job.state === "cancelled" && states.indexOf("running") >= 0 && states.indexOf("complete") < 0, "cancelled while running: " + states.join(" → "));
    check(sw && sw.partial === true && sw.rows.length >= 6 && sw.rows.length < 400, "partial rows kept: " + (sw && sw.rows.length));
    var idx = {}; (sw ? sw.rows : []).forEach(function (r) { idx[r.index] = 1; });
    check(sw && Object.keys(idx).length === sw.rows.length, "no duplicated rows");
    check(sw && sw.analysis && sw.analysis.controllers.lqr && sw.analysis.partial === true && !sw.analysis_note && /^PARTIAL/.test(sw.analysis.notes[0]), "the backend's analysis of the finished runs, labelled PARTIAL");
    check(sw && sw.analysis.controllers.lqr.n + sw.analysis.controllers.pid.n === sw.rows.length, "analysis counts exactly the saved rows");
    return api.request("GET", "/jobs/" + job.server_id).then(function (j) { check(j.state === "cancelled" && j.progress.done === sw.rows.length, "server agrees: " + j.state + " " + j.progress.done + " rows " + sw.rows.length); });
  });
});
test("L9 Cancel BEFORE execution: a job queued behind two running jobs is cancelled without running anything", function (check) {
  var big = function (n) { return { revision: "1.1", name: "live L9 " + n, base: cfg("edge", {}), mode: "grid", controllers: ["lqr"], variables: [{ key: "tilt_deg", min: 0, max: 10, steps: 60 }], duration_s: 15 }; };
  var term = function (j) { return JOBS.isTerminal(j); };
  var a = SERVICE.submitSweep(big("A")), b = SERVICE.submitSweep(big("B")), c = null;
  return until(a, function (j) { return j.state === "running"; }).then(function () { return until(b, function (j) { return j.state === "running"; }); }).then(function () {
    c = SERVICE.submitSweep(big("C"));
    return until(c, function (j) { return !!j.server_id; });
  }).then(function () { return api.request("GET", "/jobs/" + c.server_id); }).then(function (sj) {
    check(sj.state === "queued", "third job queued behind the two running ones (max_jobs 2): " + sj.state);
    return SERVICE.cancel(c);
  }).then(function () { return until(c, term, 60000); }).then(function () {
    check(c.state === "cancelled" && !c.result, "cancelled, no result to show: " + c.state);
    return api.request("GET", "/jobs/" + c.server_id);
  }).then(function (sj) {
    check(sj.state === "cancelled" && sj.progress.done === 0 && /before it started/.test(sj.message), "server: cancelled before it started, 0 runs: " + JSON.stringify([sj.progress, sj.message]));
    return api.getSweep(sj.result_ref.id);
  }).then(function (sw) {
    check(sw.status === "cancelled" && sw.rows.length === 0, "the sweep record is kept for provenance, with no rows: " + sw.status + " " + sw.rows.length);
    return Promise.all([SERVICE.cancel(a), SERVICE.cancel(b)]);
  }).then(function () {
    var settled = function (j) { return term(j) && (j.progress.done === 0 || !!j.result); };   // a result is fetched only when runs finished
    return Promise.all([until(a, settled, 60000), until(b, settled, 60000)]);
  }).then(function () {
    [a, b].forEach(function (j, i) { check(j.state === "cancelled" && (j.progress.done === 0 ? !j.result : j.result.partial === true && j.result.rows.length === j.progress.done), "running job " + "AB"[i] + " cancelled (" + j.progress.done + " runs kept)"); });
  });
});
test("L10 Authoritative backend validation: what the backend refuses is refused, with its reasons", function (check) {
  var c = cfg("corner", { duration_s: 2 }); c.solver = { method: "rk4", integration_hz: 750 };   // not a multiple of the 500 Hz loop
  return SERVICE.validateRemote(c).then(function (v) {
    check(v && v.ok === false && v.errors.some(function (e) { return e.path === "solver.integration_hz"; }), "remote validation: " + JSON.stringify(v && v.errors));
    return SERVICE.runSingle(c, { name: "live L10" });
  }).then(function (o) {
    check(!o.ok && !o.record && o.result.outcome.code === "invalid", "submission refused, no record");
  });
});
test("L11 Hardware: the backend reports no connection; frames are validated strictly", function (check) {
  return api.hardwareStatus().then(function (h) {
    check(h && h.connected === false, "not connected: " + JSON.stringify(h));
    return api.request("POST", "/hardware/frames/validate", { frame: { t: "0.1", q: [1, 0, 0, 0] } });
  }).then(function (r) { check(r && r.ok === false && r.errors.some(function (e) { return /^t:/.test(e); }), "string time rejected: " + JSON.stringify(r)); });
});
/* v5: the telemetry path with the real adapter, the real backend and the standalone emulator (a separate process on
   this computer). Everything here is SYNTHETIC and must stay labelled so. */
function startEmulator(port) {
  var py = pythonPath(), out = "";
  var em = cp.spawn(py, ["-m", "aeris_backend.telemetry.emulator", "--port", String(port), "--rate", "100", "--seed", "3", "--faults", "drop=0.02,duplicate=0.02"], { cwd: BACKEND });
  em.stdout.on("data", function (d) { out += d; }); em.stderr.on("data", function (d) { out += d; });
  var t0 = Date.now();
  return new Promise(function (res, rej) { (function w() { if (/telemetry emulator on/.test(out)) return res(em); if (em.exitCode !== null || Date.now() - t0 > 30000) return rej(new Error("emulator did not start: " + out.slice(-400))); setTimeout(w, 50); })(); });
}
test("L13 Telemetry: emulator → backend → live WebSocket in order → synthetic recording → export → replay; HARDWARE never claims the cube", function (check) {
  var H = HardwareTelemetryAdapter, EPORT = 20000 + Math.floor(Math.random() * 2000), em = null, stream = null, got = [], kinds = [], rid = null;
  H.bind(api);
  check(H.available().ok, "HARDWARE mode available with the reachable backend: " + H.available().reason);
  function waitFor(pred, ms) { var t0 = Date.now(); return new Promise(function (res, rej) { (function w() { Promise.resolve(pred()).then(function (v) { if (v) return res(v); if (Date.now() - t0 > (ms || 30000)) return rej(new Error("condition not reached")); setTimeout(w, 100); }, rej); })(); }); }
  return startEmulator(EPORT).then(function (e) {
    em = e;
    return H.connect({ source: "tcp", host: "127.0.0.1", port: EPORT });
  }).then(function (st) {
    check(st.source && st.source.kind === "tcp", "connect accepted: " + JSON.stringify(st.source));
    stream = H.live(function (ev) { if (ev.type === "frames") got = got.concat(ev.frames); else if (ev.type === "transport") kinds.push(ev.kind); }, {});
    return waitFor(function () { return got.length >= 50; });
  }).then(function () {
    var ns = got.map(function (f) { return f.n; });
    check(ns.every(function (n, i) { return i === 0 || n > ns[i - 1]; }), "frames in order, no duplicates");
    check(kinds[0] === "websocket", "live over the WebSocket: " + JSON.stringify(kinds));
    check(got.every(function (f) { return H.parseFrame(f).ok; }), "every delivered frame passes the browser's own strict check");
    return H.status();
  }).then(function (st) {
    check(st.provenance.synthetic === true && st.provenance.source_kind === "emulator" && st.live === false && st.provenance.declared_physical === false, "synthetic, not live hardware: " + JSON.stringify(st.provenance));
    check(H.provenanceLabel(st.provenance).cls === "synthetic", "labelled synthetic");
    check(st.counters.duplicates > 0 || st.counters.gaps > 0, "injected faults are counted: " + JSON.stringify(st.counters));
    SERVICE.setMode("hardware");
    check(SERVICE.getMode() === "hardware", "HARDWARE mode selectable");
    return api.capabilities().hardware.live === false ? H.startRecording("live L13") : Promise.reject(new Error("capabilities claim live hardware"));
  }).then(function () { return new Promise(function (r) { setTimeout(r, 1200); }); }).then(function () { return H.stopRecording(); }).then(function (r) {
    rid = r.id;
    check(r.synthetic === true && r.provenance.source_kind === "emulator" && /SYNTHETIC/.test(r.provenance.label) && r.quality.n > 50, "stored synthetic recording: " + JSON.stringify(r).slice(0, 300));
    return fetch(H.exportUrl(rid, "ndjson")).then(function (x) { return x.text(); });
  }).then(function (txt) {
    var hello = JSON.parse(txt.split("\n")[0]);
    check(hello.type === "hello" && hello.synthetic === true && hello.device.kind === "emulator", "the export keeps the synthetic hello");
    return H.connect({ source: "recording", recording_id: rid, speed: 0 });
  }).then(function () { return waitFor(function () { return H.status().then(function (s) { return s.source && s.source.state === "finished" ? s : null; }); }); }).then(function (s) {
    check(s.provenance.replay === true && s.provenance.synthetic === true && /^REPLAY/.test(H.provenanceLabel(s.provenance).text), "replay labelled synthetic: " + JSON.stringify(s.provenance));
    return H.disconnect();
  }).then(function () {
    if (stream) stream.close(); if (em) em.kill("SIGTERM"); SERVICE.setMode("simulation"); H.bind(null);
  }, function (e) { if (stream) stream.close(); if (em) em.kill("SIGTERM"); H.bind(null); throw e; });
});
/* v5.1 (review finding F2): the backend PROCESS is stopped and started again on the same port and database while the
   adapters stay loaded, like a browser tab that stays open. Frame indices restart with the new process; the stream id
   tells the adapter. Two consumers run at once: one on the WebSocket, one forced to poll. SYNTHETIC sources only. */
test("L14 Telemetry across a REAL backend restart: WebSocket and polling consumers show the new process's frames promptly; a reconnect without restart keeps one cursor; a short low-rate replay arrives", function (check) {
  var H = HardwareTelemetryAdapter, EPORT = 22000 + Math.floor(Math.random() * 2000), em = null, sockets = [], ws = null, poll = null, lowRate = null, before = null, t0 = 0;
  H.bind(api);
  function waitFor(pred, ms) { var t = Date.now(); return new Promise(function (res) { (function w() { var v = pred(); if (v) return res(v); if (Date.now() - t > (ms || 30000)) return res(null); setTimeout(w, 50); })(); }); }
  function consumer(opts) {
    var c = { frames: [], events: [] };
    c.live = H.live(function (ev) {
      if (ev.type === "frames") ev.frames.forEach(function (f) { c.frames.push({ n: f.n, at: Date.now() }); });
      else if (ev.type !== "status" && ev.type !== "error") c.events.push({ type: ev.type, kind: ev.kind || null, stream: ev.stream || null, at: Date.now() });
    }, opts);
    c.since = function (t) { return c.frames.filter(function (f) { return f.at >= t; }); };
    return c;
  }
  function trackedWS(url) { var s = new WebSocket(url); sockets.push(s); return s; }
  function inOrder(list) { return list.every(function (f, i) { return i === 0 || f.n > list[i - 1].n; }); }
  function cleanup() { if (ws) ws.live.close(); if (poll) poll.live.close(); if (em) em.kill("SIGTERM"); H.bind(null); }
  return startEmulator(EPORT).then(function (e) {
    em = e;
    return H.connect({ source: "tcp", host: "127.0.0.1", port: EPORT });
  }).then(function () {
    ws = consumer({ WebSocket: trackedWS });
    poll = consumer({ WebSocket: function () { throw new Error("WebSocket disabled: this consumer polls"); }, pollMs: 100 });
    return waitFor(function () { return ws.live.lastN() >= 150 && poll.live.lastN() >= 150 && ws.live.mode() === "websocket"; });
  }).then(function (ok) {
    check(ok, "both consumers live before the restart: " + ws.live.lastN() + " / " + poll.live.lastN() + " (" + ws.live.mode() + ")");
    // (1) a reconnect WITHOUT a restart: the socket drops, the stream goes on — one cursor, no reset, nothing twice
    var sid = ws.live.streamId(), n0 = ws.live.lastN();
    sockets[sockets.length - 1].close();
    return waitFor(function () { return sockets.length >= 2 && ws.live.mode() === "websocket" && ws.live.lastN() > n0 + 100; }).then(function (ok2) {
      check(ok2, "live again over a new socket: " + ws.live.mode() + ", " + sockets.length + " sockets, n " + ws.live.lastN());
      check(inOrder(ws.frames) && ws.live.streamId() === sid && ws.live.streamChanges() === 0, "same stream, each frame once in order: " + ws.live.streamId() + " changes " + ws.live.streamChanges());
    });
  }).then(function () {
    // a short LOW-RATE synthetic recording (12 samples at 5 Hz, no seq column) to replay after the restart
    var n = 12, t = [], q0 = [], q1 = [], z = [];
    for (var k = 0; k < n; k++) { t.push(0.2 * k); q0.push(Math.cos(0.005 * k)); q1.push(Math.sin(0.005 * k)); z.push(0); }
    return api.request("POST", "/hardware/recordings", { schema: "aeris-hardware-run/1", synthetic: true, device: { id: "live-L14-low-rate-fixture", firmware: "none" },
      recording: { started: new Date().toISOString(), notes: "L14: short low-rate SYNTHETIC fixture (5 Hz), not a measurement" }, mode: "corner",
      samples: { rate_hz: 5, cols: { t: t, q0: q0, q1: q1, q2: z, q3: z.slice() }, units: { t: "s", q0: "1", q1: "1", q2: "1", q3: "1" } } });
  }).then(function (r) {
    lowRate = r;
    check(r && r.synthetic === true && r.quality.n === 12, "low-rate synthetic recording stored: " + JSON.stringify(r && r.quality));
    before = { stream: ws.live.streamId(), ws: ws.live.lastN(), poll: poll.live.lastN() };
    check(before.ws > 12 && before.poll > 12, "the old cursors are far above what the new process will send: " + JSON.stringify(before));
    // (2) the backend process stops and a new one starts on the same port and database
    return stopBackend().then(function () { return startBackend(); });
  }).then(function () {
    t0 = Date.now();
    return H.connect({ source: "recording", recording_id: lowRate.id, speed: 1 });
  }).then(function () {
    return waitFor(function () { return ws.since(t0).length >= 12 && poll.since(t0).length >= 12; }, 15000);
  }).then(function () {
    [["websocket consumer", ws], ["polling consumer", poll]].forEach(function (x) {
      var c = x[1], got = c.since(t0), first = got[0], ev = c.events.filter(function (e) { return e.type === "stream"; }).pop();
      check(got.length >= 12 && first && first.n === 1, x[0] + ": the new process's frames from n = 1: " + JSON.stringify(got.slice(0, 3)) + " … " + got.length);
      check(first && first.at - t0 < 4000, x[0] + ": first new frame " + (first ? first.at - t0 : "never") + " ms after the replay was connected (low-rate source, 5 Hz)");
      check(c.live.streamChanges() === 1 && c.live.streamId() !== before.stream && ev && ev.stream === c.live.streamId(), x[0] + ": one stream change reported: " + JSON.stringify(ev));
      check(inOrder(got), x[0] + ": in order, nothing twice");
    });
    // (3) the live emulator on the new backend: frames continue at once for both consumers
    var t1 = Date.now();
    return H.connect({ source: "tcp", host: "127.0.0.1", port: EPORT }).then(function () {
      return waitFor(function () { return ws.since(t1).length >= 20 && poll.since(t1).length >= 20; }, 5000);
    }).then(function (ok) {
      check(ok, "live frames after the restart: websocket " + ws.since(t1).length + ", polling " + poll.since(t1).length);
      check(ws.since(t1)[0] && ws.since(t1)[0].n === 13 && poll.since(t1)[0] && poll.since(t1)[0].n === 13, "the new stream continues after the replay (n 13 …)");
      return H.status();
    }).then(function (st) {
      check(st.stream_id === ws.live.streamId() && st.stream_id === poll.live.streamId(), "consumers follow the backend's stream: " + st.stream_id);
      check(st.provenance.synthetic === true && st.provenance.declared_physical === false, "still labelled synthetic");
      return H.disconnect();
    });
  }).then(cleanup, function (e) { cleanup(); throw e; });
});
test("L15 Reconnect race, made deterministic (review finding V52-1): frames the NEW backend process accepted before this client's socket subscribed are fetched from its history — from n = 1, once, in order", function (check) {
  // A consumer's reconnect is held (its poll/reopen scheduler is a gate the test opens) until the restarted backend has
  // ACCEPTED frames 1..k of a replay with no subscriber of this client; only then may the adapter open its socket. The
  // socket's first status then says last_n = k: those frames are not on the socket and must come from the history.
  // v5.2's adapter adopted the new stream and showed frames from k + 1 (reviewer: 11 of 12 from n = 2, L14 on macOS).
  var H = HardwareTelemetryAdapter, gate = [], c = { frames: [], events: [] }, rec = null, before = null, t0 = 0;
  H.bind(api);
  function waitFor(pred, ms) { var t = Date.now(); return new Promise(function (res) { (function w() { Promise.resolve(pred()).then(function (v) { if (v) return res(v); if (Date.now() - t > (ms || 30000)) return res(null); setTimeout(w, 50); }, function () { if (Date.now() - t > (ms || 30000)) return res(null); setTimeout(w, 50); }); })(); }); }
  var held = function (ms, fn) { gate.push(fn); return 0; };
  function cleanup() { if (c.live) c.live.close(); H.bind(null); }
  var n = 12, t = [], q0 = [], q1 = [], z = [];
  for (var k = 0; k < n; k++) { t.push(0.2 * k); q0.push(Math.cos(0.004 * k)); q1.push(Math.sin(0.004 * k)); z.push(0); }
  return api.request("POST", "/hardware/recordings", { schema: "aeris-hardware-run/1", synthetic: true, device: { id: "live-L15-fixture", firmware: "none" },
    recording: { started: new Date().toISOString(), notes: "L15: SYNTHETIC 5 Hz fixture, not a measurement" }, mode: "corner",
    samples: { rate_hz: 5, cols: { t: t, q0: q0, q1: q1, q2: z, q3: z.slice() }, units: { t: "s", q0: "1", q1: "1", q2: "1", q3: "1" } } }).then(function (r) {
    rec = r;
    c.live = H.live(function (ev) {
      if (ev.type === "frames") ev.frames.forEach(function (f) { c.frames.push({ n: f.n, stream: c.live ? c.live.streamId() : null }); });
      else if (ev.type !== "status" && ev.type !== "error") c.events.push(ev);
    }, { wait: held });
    return waitFor(function () { return c.live.mode() === "websocket" && c.live.streamId(); }, 10000);
  }).then(function (ok) {
    check(ok, "consumer live over a WebSocket before the restart: " + c.live.mode());
    before = c.live.streamId();
    return stopBackend().then(function () { return startBackend(); });
  }).then(function () {
    t0 = Date.now();
    return H.connect({ source: "recording", recording_id: rec.id, speed: 1 });
  }).then(function () {
    // the new process accepts frames with no subscriber of this consumer (its reconnect is still held)
    return waitFor(function () { return H.status().then(function (s) { return s.last_n >= 3 ? s : null; }); }, 15000);
  }).then(function (st) {
    check(st && st.last_n >= 3, "the new process accepted frames before the consumer reconnected: last_n " + (st && st.last_n));
    check(c.frames.filter(function (f) { return f.stream !== before; }).length === 0, "nothing of the new stream reached the consumer yet");
    var pending = gate.splice(0); pending.forEach(function (fn) { fn(); });   // the consumer may reconnect now
    return waitFor(function () { return c.frames.filter(function (f) { return f.stream && f.stream !== before; }).length >= 10; }, 20000);
  }).then(function () {
    var got = c.frames.filter(function (f) { return f.stream && f.stream !== before; }).map(function (f) { return f.n; });
    var gaps = c.events.filter(function (e) { return e.type === "gap"; }), cu = c.events.filter(function (e) { return e.type === "catchup"; });
    check(got[0] === 1, "the new stream from n = 1: " + JSON.stringify(got.slice(0, 5)) + " … " + got.length);
    check(got.every(function (x, i) { return x === i + 1; }), "each frame once, in order, without a hole: " + JSON.stringify(got));
    check(gaps.length === 0, "no frame lost: " + JSON.stringify(gaps));
    check(cu.length >= 1 && cu[0].state === "started", "the frames before the subscription came from the history (catch-up): " + JSON.stringify(cu.slice(0, 2)));
    check(c.live.streamChanges() === 1, "one stream change: " + c.live.streamChanges());
    return H.disconnect();
  }).then(cleanup, function (e) { cleanup(); throw e; });
});
test("L12 DEMO keeps working when the backend goes away; backend runs are then not re-run in the browser", function (check) {
  return stopBackend().then(function () { return SERVICE.probe(); }).then(function (st) {
    check(st.reachable === false && !SERVICE.modeInfo("simulation").available && /not reachable/.test(SERVICE.modeInfo("simulation").reason), "SIMULATION unavailable: " + SERVICE.modeInfo("simulation").reason);
    check(SERVICE.setMode("demo").ok, "DEMO selectable");
    return SERVICE.runSingle(cfg("edge", { duration_s: 2 }), { name: "offline demo" });
  }).then(function (o) {
    check(o.ok && o.record.origin.engine === "aeris-twin-js", "DEMO run on the browser engine");
    return SERVICE.reproduceAsync(shared.legacy);
  }).then(function (o) { check(!o.ok && /research backend/.test(o.message), "backend run not re-run locally: " + o.message); });
});

startBackend().then(function (s) { started = s; run(); }, function (e) {
  console.log("NOT RUN: the research backend could not be started (" + e.message + ").");
  queue.forEach(function (t) { console.log("NOT RUN " + t.n); });
  console.log("\n0 / " + queue.length + " live backend tests run (" + queue.length + " not run)");
  stopBackend().then(function () { process.exit(2); });
});

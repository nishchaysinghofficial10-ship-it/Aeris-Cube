"""Browser end-to-end checks for v5.1 (Playwright + Chromium, reduced motion, bounded waits on the displayed state).

Run:   python3 tests/browser_v51.py            (starts the research backend, the SYNTHETIC telemetry emulator, an
                                                ARTIFICIAL declared-physical test fixture and a static server itself,
                                                on free local ports, with a temporary database)
       python3 tests/browser_v51.py --shots    (also writes screenshots to tests/screenshots/)

Python for the backend: $AERIS_PYTHON, else backend/.venv/bin/python, else ../.venv/bin/python, else this
interpreter. If the backend cannot be started every check is reported as NOT RUN (exit code 2).

Covers (review of v5, findings F2 and F1):
  F2  Two tabs stay open on the Telemetry tab — A on the WebSocket, B with WebSocket switched off (it polls). A
      reconnect WITHOUT a restart (A's live socket closes; B's tab is hidden and shown again) continues the same
      stream. Then the backend PROCESS is stopped and started again on the same port and database (A's site also
      probes the backend while it is down, so A's tab shows "Telemetry unavailable" and must recover by itself):
      both tabs must drop the old frame, show the new process's state, show a short low-rate replay (12 frames at
      5 Hz) as it arrives — values, readout and 3-D view agreeing — and continue with live frames; A returns to the
      WebSocket.
  F1  In the Telemetry tab: a recording from the declared-physical fixture is listed as declared (not verified); a
      recording that switches from that fixture to the emulator while recording is SYNTHETIC in the list, in its
      NDJSON export (every hello) and in its replay (the banner never says physical); a recording captured from a
      replay of the declared-physical recording is listed as a copy.

Everything "physical" here is an ARTIFICIAL TEST FIXTURE (a line server in this script); nothing comes from hardware.
"""
import asyncio, json, os, sys, pathlib, subprocess, tempfile, time, socket, threading, urllib.request
from playwright.async_api import async_playwright

SITE = pathlib.Path(__file__).resolve().parent.parent
BACKEND = SITE.parent / "backend"
SHOTS = "--shots" in sys.argv
SHOT_DIR = SITE / "tests" / "screenshots"
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
results = []
CONVENTIONS = {"quaternion": "w,x,y,z; body to world; Hamilton product", "body_axes": "x, y, z along the cube edges from the pivot corner",
               "world_axes": "z up", "time": "seconds since the session start (monotonic)"}
PHYS_HELLO = {"type": "hello", "protocol": "aeris-telemetry-ndjson/1", "device": {"id": "test-fixture-physical-declaration", "kind": "physical", "firmware": "test-only"},
              "synthetic": False, "mode": "corner", "conventions": CONVENTIONS, "nominal_rate_hz": 100}
# A: every WebSocket the page opens is remembered, so the test can close the live socket (transport reconnect)
TRACK_WS = """(() => { const W = window.WebSocket; window.__aerisSockets = [];
  function T(u, p) { const s = p === undefined ? new W(u) : new W(u, p); window.__aerisSockets.push(s); return s; }
  T.prototype = W.prototype; T.CONNECTING = 0; T.OPEN = 1; T.CLOSING = 2; T.CLOSED = 3; window.WebSocket = T; })();"""
NO_WS = "window.WebSocket = undefined;"          # B: a browser without WebSocket: the telemetry stream polls
SNAP = "AERIS_TELEMETRY_UI.snapshot()"
PLANNED = 12                                      # checks of a complete run (reported as not run when the backend cannot start)
VIEW = """(() => ({ snap: AERIS_TELEMETRY_UI.snapshot(), read: document.getElementById('tmRead').innerText, readout: document.getElementById('tmT').textContent,
  banner: document.getElementById('tmBannerT').textContent, kind: document.getElementById('tmBanner').getAttribute('data-kind'),
  stream: (document.querySelector('#tmQuality td[data-q="Backend stream"]') || {}).textContent || null,
  page: (document.querySelector('#tmQuality td[data-q="This page"]') || {}).textContent || null }))()"""


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else "  →  " + str(detail)[:900]), flush=True)


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def backend_python():
    for c in (os.environ.get("AERIS_PYTHON"), BACKEND / ".venv" / "bin" / "python", SITE.parent.parent / ".venv" / "bin" / "python"):
        if c and pathlib.Path(c).exists():
            return str(c)
    return sys.executable


def wait_http(url, timeout=40):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                return r.status == 200
        except Exception:
            time.sleep(0.2)
    return False


async def shot(page, name):
    if SHOTS:
        SHOT_DIR.mkdir(parents=True, exist_ok=True)
        await page.screenshot(path=str(SHOT_DIR / (name + ".png")))


async def wait_for(page, js, timeout=30000, step=100):
    """Bounded wait for a condition in the page; False if it is not reached in time (the check then fails)."""
    t = 0
    while t < timeout:
        try:
            if await page.evaluate(js):
                return True
        except Exception:
            pass
        await page.wait_for_timeout(step); t += step
    return False


async def ms_until(page, js, t0, timeout=15000):
    """Wall-clock milliseconds from t0 until the condition holds in the page (None if it never does)."""
    while (time.time() - t0) * 1000 < timeout:
        try:
            if await page.evaluate(js):
                return round((time.time() - t0) * 1000)
        except Exception:
            pass
        await page.wait_for_timeout(25)
    return None


def fixture_server():
    """ARTIFICIAL declared-physical source for the provenance checks: each connection gets the physical hello, then
    frames at about 100 Hz until it is closed. It is a test fixture, not a device."""
    srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); srv.bind(("127.0.0.1", 0)); srv.listen(4)
    stop = threading.Event()

    def serve(conn):
        with conn:
            try:
                conn.sendall((json.dumps(PHYS_HELLO) + "\n").encode())
                k = 0
                while not stop.is_set():
                    conn.sendall((json.dumps({"type": "frame", "seq": k, "t": round(0.01 * k, 6), "q": [1, 0, 0, 0], "w": [0, 0, 0]}) + "\n").encode())
                    k += 1
                    time.sleep(0.01)
            except OSError:
                return

    def run():
        srv.settimeout(0.2)
        while not stop.is_set():
            try:
                c, _ = srv.accept()
            except OSError:
                continue
            threading.Thread(target=serve, args=(c,), daemon=True).start()
        srv.close()
    threading.Thread(target=run, daemon=True).start()
    return srv.getsockname()[1], stop.set


def start_backend(st):
    return subprocess.Popen([st["py"], "-m", "aeris_backend.api.main", "--port", str(st["bport"]), "--db", st["db"], "--workers", "1", "--cors", st["origin"],
                             "--telemetry-dir", st["teldir"], "--log-level", "warning"], cwd=str(BACKEND), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)


async def open_tab(br, st, init):
    cfg = json.dumps({"researchApi": {"baseUrl": st["base"], "wsUrl": st["base"].replace("http", "ws"), "pollMs": 300, "probeMs": 60000, "mock": False}})
    ctx = await br.new_context(viewport={"width": 1440, "height": 900}, reduced_motion="reduce")
    await ctx.add_init_script(init)
    await ctx.add_init_script("window.AERIS_CONFIG = " + cfg + ";")
    page = await ctx.new_page()
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append("PAGEERROR " + str(e)))
    await page.goto(st["origin"] + "/index.html#lab", wait_until="load")
    ok = await wait_for(page, "AERIS_SERVICE.modeInfo('hardware').available", 20000)
    await page.click('.wm-b[data-mode="hardware"]')
    ok = ok and await wait_for(page, "AERIS_SERVICE.getMode() === 'hardware' && AERIS_DEBUG.snapshot().kind === 'telemetry' && typeof AERIS_TELEMETRY_UI !== 'undefined' && !document.getElementById('tmConnect').disabled", 15000)
    return ctx, page, errors, ok


async def connect_tcp(page, port):
    await page.click('input[name="tmKind"][value="tcp"]')
    await wait_for(page, "!!document.getElementById('tmPort')", 5000)
    await page.fill("#tmPort", str(port))
    await page.click("#tmConnect")


# ================================================================ F2: a backend restart with two tabs open
async def restart_checks(br, st):
    ctxA, A, errA, okA = await open_tab(br, st, TRACK_WS)
    ctxB, B, errB, okB = await open_tab(br, st, NO_WS)
    check("Two tabs open the Telemetry tab of one backend (A: WebSocket; B: WebSocket switched off, so it polls)", okA and okB and await B.evaluate("typeof WebSocket === 'undefined'"))
    await connect_tcp(A, st["eport"])
    live = "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return s.connected && s.kind === 'synthetic' && s.latest && s.viewer && s.viewer.n === s.latest.n && s.latest.n > 50 && s.transport === '%s'; })()"
    okA, okB = await wait_for(A, live % "websocket", 20000), await wait_for(B, live % "polling", 20000)
    vA, vB = await A.evaluate(VIEW), await B.evaluate(VIEW)
    stream1 = vA["snap"]["stream"]
    check("Both tabs show the live SYNTHETIC emulator stream of the same backend stream: A over the WebSocket, B by polling",
          okA and okB and stream1 and vB["snap"]["stream"] == stream1 and "SYNTHETIC" in vA["banner"].upper() and "SYNTHETIC" in vB["banner"].upper(), [vA, vB])
    await shot(A, "v51-01-two-tabs-live")

    # ---- a reconnect WITHOUT a restart: the same stream continues, nothing is reset
    nA = vA["snap"]["latest"]["n"]
    closed = await A.evaluate("window.__aerisSockets.filter(s => /telemetry\\/live/.test(s.url) && s.readyState === 1).map(s => (s.close(), s.url)).length")
    okA = await wait_for(A, "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return window.__aerisSockets.filter(x => /telemetry\\/live/.test(x.url)).length >= 2 && s.transport === 'websocket' && s.latest && s.latest.n > %d; })()" % (nA + 100), 20000)
    await B.click("#wk-single")
    hid = await wait_for(B, "document.getElementById('wsTel').hidden", 5000)
    nB = (await B.evaluate(SNAP))["latest"]["n"]
    await B.click("#wk-tel")
    okB = await wait_for(B, "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return !document.getElementById('wsTel').hidden && s.transport === 'polling' && s.latest && s.latest.n > %d; })()" % (nB + 50), 20000)
    vA2, vB2 = await A.evaluate(VIEW), await B.evaluate(VIEW)
    check("Reconnect without a restart (A: its live socket closes and reopens; B: the tab is hidden and shown again): same stream, no reset, frames continue",
          closed == 1 and hid and okA and okB and vA2["snap"]["stream"] == stream1 == vB2["snap"]["stream"] and vA2["snap"]["streamChanges"] == 0 and vB2["snap"]["streamChanges"] == 0
          and "restarted" not in (vA2["stream"] or "") and "restarted" not in (vB2["stream"] or ""), [closed, hid, vA2, vB2])

    # ---- the backend process is stopped and started again (same port, same database); both tabs stay open.
    # Tab A's site also probes the backend while it is down (as its periodic one-minute probe may do): its Telemetry
    # tab then says "Telemetry unavailable" and must come back by itself (it re-probes every 3 s while open). Tab B
    # is not probed: it notices the restart through the stream alone.
    st["be"].terminate(); st["be"].wait(timeout=30)
    await A.evaluate("AERIS_SERVICE.probe()")
    down = await wait_for(A, "!AERIS_SERVICE.modeInfo('hardware').available && /Telemetry unavailable/i.test(document.getElementById('tmBannerT').textContent)", 15000)
    st["be"] = start_backend(st)
    healthy = wait_http(st["base"] + "/api/v1/health")
    t_up = time.time()
    reset = ("(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return s.streamChanges === 1 && !!s.stream && s.stream !== %s && s.latest === null && s.viewer === null"
             " && /No frames yet/.test(document.getElementById('tmRead').innerText) && document.getElementById('tmT').textContent === ''"
             " && /^No telemetry source$/i.test(document.getElementById('tmBannerT').textContent)"
             " && /restarted 1× while this page was open/.test((document.querySelector('#tmQuality td[data-q=\"Backend stream\"]') || {}).textContent || ''); })()") % json.dumps(stream1)
    msA_back = await ms_until(A, reset, t_up, 25000)
    okA, okB = msA_back is not None, await wait_for(B, reset, 25000)
    rA, rB = await A.evaluate(VIEW), await B.evaluate(VIEW)
    check("Backend restarted with both tabs open: each tab adopts the new stream, drops the old frame (values, readout, 3-D view) and shows the new process's state (no source) — it does not keep showing the old frame",
          healthy and okA and okB and rA["snap"]["stream"] == rB["snap"]["stream"], [healthy, rA, rB])
    check("A tab whose site probed the backend while it was down said 'Telemetry unavailable' and came back by itself within a few seconds of the restart (re-probe every 3 s; no reload, no click)",
          down and msA_back is not None and msA_back < 10000, {"unavailable_seen": down, "back_after_ms": msA_back})
    st.setdefault("timings", {})["unavailable_tab_back_after_ms"] = msA_back
    await shot(A, "v51-02-after-restart")

    # ---- a short LOW-RATE replay on the new process: 12 frames at 5 Hz (n = 1 … 12, far below the old cursors)
    await A.click('input[name="tmKind"][value="file"]')
    await wait_for(A, "!!document.querySelector('#tmFile option[value=\"session-low.ndjson\"]')", 10000)
    await A.select_option("#tmFile", "session-low.ndjson")
    await A.fill("#tmSpeed", "1")
    t0 = time.time()
    await A.click("#tmConnect")
    first = "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return !!(s.latest && s.latest.n >= 1 && s.viewer && s.viewer.n === s.latest.n); })()"
    msA, msB = await asyncio.gather(ms_until(A, first, t0), ms_until(B, first, t0))
    last = "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return !!(s.latest && s.latest.n === 12 && s.viewer && s.viewer.n === 12 && /seq 11/.test(document.getElementById('tmT').textContent)); })()"
    okA, okB = await wait_for(A, last, 10000, 50), await wait_for(B, last, 10000, 50)
    lA, lB = await A.evaluate(VIEW), await B.evaluate(VIEW)

    def shows_last(v):
        s = v["snap"]
        return (s["latest"] and s["latest"]["n"] == 12 and s["latest"]["seq"] == 11 and abs(s["latest"]["t"] - 2.2) < 1e-9 and s["viewer"]["n"] == 12
                and v["readout"] == "t = 2.200 s · seq 11" and "n 12 · seq 11" in v["read"] and s["streamChanges"] == 1 and "REPLAY" in v["banner"].upper() and "SYNTHETIC" in v["banner"].upper())
    check("A short low-rate replay (12 frames at 5 Hz) after the restart reaches both tabs as it arrives: first frame promptly (< 3 s); the last frame's values, readout and 3-D view agree (t = 2.200 s, seq 11, n 12)",
          msA is not None and msB is not None and msA < 3000 and msB < 3000 and okA and okB and shows_last(lA) and shows_last(lB), {"first_frame_ms": [msA, msB], "A": lA, "B": lB})
    st.setdefault("timings", {})["replay_first_frame_ms"] = {"websocket_tab": msA, "polling_tab": msB}

    # ---- live frames on the new process; A returns to the WebSocket
    await connect_tcp(A, st["eport"])
    cont = "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return s.connected && s.kind === 'synthetic' && s.latest && s.latest.n > 80 && s.viewer.n === s.latest.n && s.streamChanges === 1; })()"
    okA, okB = await wait_for(A, cont, 15000), await wait_for(B, cont, 15000)
    backWs = await wait_for(A, "AERIS_TELEMETRY_UI.snapshot().transport === 'websocket'", 30000)
    cA, cB = await A.evaluate(VIEW), await B.evaluate(VIEW)
    check("Live frames continue in both tabs after the restart (the new stream's n continues after the replay); A is back on the WebSocket, B keeps polling",
          okA and okB and backWs and "WebSocket live" in (cA["page"] or "") and "polling" in (cB["page"] or ""), [cA, cB])
    await connect_tcp(A, st["eport"])
    st["pages"] = (ctxA, A, errA, ctxB, B, errB)


# ================================================================ F1: provenance as the Telemetry tab shows it
async def store(page, name, record_until_js, timeout=20000):
    await page.fill("#tmRecName", name)
    await page.click("#tmRecStart")
    await wait_for(page, "AERIS_TELEMETRY_UI.snapshot().recording", 8000)
    await wait_for(page, record_until_js, timeout)
    await page.click("#tmRecStop")
    ok = await wait_for(page, "/Stored as AERIS-HW-\\d+/.test(document.getElementById('tmRecState').innerText)", 15000)
    text = await page.evaluate("document.getElementById('tmRecState').innerText")
    rid = text.split("Stored as ")[1].split()[0] if ok else None
    row = ""
    if rid:
        await wait_for(page, "!!document.querySelector('tr[data-rec=%s]')" % json.dumps(rid), 10000)
        row = await page.evaluate("(document.querySelector('tr[data-rec=%s]') || {}).innerText || ''" % json.dumps(rid))
    return rid, text, row


async def provenance_checks(st):
    ctxA, A, errA, ctxB, B, errB = st["pages"]
    await ctxB.close()
    fport = st["fport"]
    # (1) the declared-physical fixture alone: the original is listed as declared, never verified
    await connect_tcp(A, fport)
    ok = await wait_for(A, "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return s.kind === 'declared' && s.connected && s.latest && s.latest.n > 0; })()", 15000)
    ban = await A.evaluate("document.getElementById('tmBannerT').textContent")
    n0 = (await A.evaluate(SNAP))["latest"]["n"]
    rid_p, text_p, row_p = await store(A, "declared-physical fixture (ARTIFICIAL)", "AERIS_TELEMETRY_UI.snapshot().latest.n > %d" % (n0 + 200))
    check("A recording of the declared-physical fixture alone: banner 'Declared physical … not verified'; stored and listed as declared (not verified), not synthetic, not a copy",
          ok and "Declared physical device" in ban and "not verified" in ban and rid_p and "SYNTHETIC" not in text_p.upper() and "declared physical (not verified)" in row_p and "copy" not in row_p and "SYNTHETIC" not in row_p.upper(),
          [ban, text_p, row_p])

    # (2) the source changes from the fixture to the emulator WHILE recording: SYNTHETIC everywhere downstream
    await connect_tcp(A, fport)
    await wait_for(A, "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return s.kind === 'declared' && s.connected; })()", 15000)
    await A.fill("#tmRecName", "mixed: fixture then emulator")
    await A.click("#tmRecStart")
    await wait_for(A, "AERIS_TELEMETRY_UI.snapshot().recording", 8000)
    n1 = (await A.evaluate(SNAP))["latest"]["n"]
    await wait_for(A, "AERIS_TELEMETRY_UI.snapshot().latest.n > %d" % (n1 + 60), 10000)
    await connect_tcp(A, st["eport"])
    await wait_for(A, "(() => { const s = AERIS_TELEMETRY_UI.snapshot(); return s.kind === 'synthetic' && s.connected; })()", 15000)
    n2 = (await A.evaluate(SNAP))["latest"]["n"]
    await wait_for(A, "AERIS_TELEMETRY_UI.snapshot().latest.n > %d" % (n2 + 60), 10000)
    await A.click("#tmRecStop")
    ok = await wait_for(A, "/Stored as AERIS-HW-\\d+/.test(document.getElementById('tmRecState').innerText)", 15000)
    text_m = await A.evaluate("document.getElementById('tmRecState').innerText")
    rid_m = text_m.split("Stored as ")[1].split()[0] if ok else None
    await wait_for(A, "!!document.querySelector('tr[data-rec=%s]')" % json.dumps(rid_m), 10000)
    row_m = await A.evaluate("(document.querySelector('tr[data-rec=%s]') || {}).innerText || ''" % json.dumps(rid_m))
    exp = await A.evaluate("fetch(HardwareTelemetryAdapter.exportUrl(%s, 'ndjson')).then(r => r.text()).then(t => t.trim().split('\\n').map(l => JSON.parse(l)).filter(m => m.type === 'hello').map(h => ({kind: h.device.kind, synthetic: h.synthetic, trust: h.lineage && h.lineage.trust})))" % json.dumps(rid_m))
    check("Fixture → emulator while recording: stored SYNTHETIC, listed SYNTHETIC, and every hello of its NDJSON export is synthetic (segments kept)",
          rid_m and "SYNTHETIC" in text_m.upper() and "SYNTHETIC" in row_m.upper() and len(exp) == 2 and all(h["synthetic"] is True and h["trust"] == "synthetic" for h in exp)
          and [h["kind"] for h in exp] == ["file-replay", "emulator"], [text_m, row_m, exp])
    # its replay: the banner is SYNTHETIC for the whole replay, never 'Declared physical'
    await A.click("[data-replay=%s]" % json.dumps(rid_m))
    seen, t0 = set(), time.time()
    while time.time() - t0 < 20:
        b = await A.evaluate("[document.getElementById('tmBannerT').textContent, (AERIS_TELEMETRY_UI.snapshot().connected)]")
        seen.add(b[0])
        if any(x.startswith("REPLAY") for x in seen) and (await A.evaluate("/replay finished/.test(document.getElementById('tmSrc').innerText)")):
            break
        await A.wait_for_timeout(50)
    replay_banners = sorted(x for x in seen if x.startswith("REPLAY"))
    check("Replaying the mixed recording: every banner shown during the replay is REPLAY · SYNTHETIC …; none says 'Declared physical'",
          replay_banners and all("SYNTHETIC" in x.upper() for x in replay_banners) and not any("Declared physical" in x for x in seen), sorted(seen))

    # (3) a copy: the declared-physical recording replayed and recorded again is listed as a copy.
    # v5.2: no race with the end of the replay. v5.1 replayed the ~2 s recording at 1x (the row's Replay button) and
    # recorded until "replay finished"; when the page learned of the replay late, the recording held one frame and was
    # refused (seen once, in the first full run of v5.2). Now the same replay of the stored recording is started from the
    # connect form at 0.1x, so it lasts at least 20 s — longer than every bounded wait before the recording starts
    # (10 s + 8 s) — and the recording is stopped after six replayed frames, while the replay is still running.
    await A.click('input[name="tmKind"][value="recording"]')
    await wait_for(A, "!!document.getElementById('tmRec') && [...document.getElementById('tmRec').options].some(o => o.value === %s)" % json.dumps(rid_p), 10000)
    await A.select_option("#tmRec", rid_p)
    await A.fill("#tmSpeed", "0.1")
    await A.click("#tmConnect")
    ok = await wait_for(A, "/^REPLAY/.test(document.getElementById('tmBannerT').textContent) && AERIS_TELEMETRY_UI.snapshot().kind === 'declared' && !document.getElementById('tmRecStart').disabled", 10000)
    await A.fill("#tmRecName", "copy of the declared-physical recording")
    await A.click("#tmRecStart")
    started = await wait_for(A, "AERIS_TELEMETRY_UI.snapshot().recording", 8000)
    n_start = ((await A.evaluate(SNAP)).get("latest") or {}).get("n", 0)
    framed = await wait_for(A, "AERIS_TELEMETRY_UI.snapshot().latest.n >= %d" % (n_start + 6), 15000)
    running = await A.evaluate("!/replay finished/.test(document.getElementById('tmSrc').innerText)")
    await A.click("#tmRecStop")
    stored = await wait_for(A, "/Stored as AERIS-HW-\\d+/.test(document.getElementById('tmRecState').innerText)", 15000)
    text_c = await A.evaluate("document.getElementById('tmRecState').innerText")
    rid_c = text_c.split("Stored as ")[1].split()[0] if stored else None
    row_c = ""
    if rid_c:
        await wait_for(A, "!!document.querySelector('tr[data-rec=%s]')" % json.dumps(rid_c), 10000)
        row_c = await A.evaluate("(document.querySelector('tr[data-rec=%s]') || {}).innerText || ''" % json.dumps(rid_c))
    await A.click("#tmDisconnect")
    check("Recording a replay of the declared-physical recording: listed as a copy captured from a replay (not an original measurement)",
          ok and started and framed and running and rid_c and "SYNTHETIC" not in text_c.upper() and "copy captured from a replay" in row_c,
          [text_c, row_c, {"banner": ok, "recording_started": started, "frames_seen": framed, "replay_still_running_at_stop": running}])
    await shot(A, "v51-03-provenance-list")
    rest = [e for e in errA + errB if "Failed to load resource" not in e and "ERR_CONNECTION_REFUSED" not in e and "WebSocket connection" not in e]
    check("No script errors in either tab (connection errors while the backend was down are expected and excluded)", not rest, rest[:5])
    await ctxA.close()


async def main():
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="aeris-e2e51-"))
    (tmp / "telemetry").mkdir()
    st = {"py": backend_python(), "bport": free_port(), "sport": free_port(), "eport": free_port(), "db": str(tmp / "e2e.sqlite3"), "teldir": str(tmp / "telemetry")}
    st["base"], st["origin"] = f"http://127.0.0.1:{st['bport']}", f"http://127.0.0.1:{st['sport']}"
    subprocess.run([st["py"], "-m", "aeris_backend.telemetry.emulator", "--write", str(tmp / "telemetry" / "session-low.ndjson"), "--frames", "12", "--rate", "5"],
                   cwd=str(BACKEND), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    st["be"] = start_backend(st)
    emu = subprocess.Popen([st["py"], "-m", "aeris_backend.telemetry.emulator", "--port", str(st["eport"])], cwd=str(BACKEND), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    web = subprocess.Popen([sys.executable, "-m", "http.server", str(st["sport"]), "--bind", "127.0.0.1", "--directory", str(SITE)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    st["fport"], stop_fixture = fixture_server()
    code = 0
    try:
        wait_http(st["origin"] + "/index.html")
        if not wait_http(st["base"] + "/api/v1/health"):
            err = st["be"].stderr.read().decode()[-600:] if st["be"].poll() is not None else "no answer"
            print("NOT RUN: the research backend could not be started with " + st["py"] + ": " + err)
            code = 2
        else:
            async with async_playwright() as p:
                br = await p.chromium.launch(args=ARGS)
                await restart_checks(br, st)
                await provenance_checks(st)
                await br.close()
    finally:
        stop_fixture()
        for proc in (st["be"], emu, web):
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=10)
                except Exception:
                    proc.kill()
    if st.get("timings"):
        print("timings: " + json.dumps(st["timings"]))
    n = sum(1 for r in results if r[1])
    if code == 2:
        print(f"\n0 / {PLANNED} v5.1 browser checks run ({PLANNED} not run)")
        return 2
    print(f"\n{n} / {len(results)} v5.1 browser checks passed")
    return 0 if n == len(results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))

/* v5 frontend tests: configuration revision 1.2 (explicit initial state, reference block, estimate age limit),
   DEMO refusals, the recording-rate rule in the browser engine and in old records, metric versions and
   reanalysis, the sweep success criterion, and the cancellable debounce behind the replay-race fix (E).
   Run with:  node tests/v5.test.js

   Backend records used here are REAL research-backend output: tests/fixtures/backend_records.json (written by
   the v4 backend, kept as compatibility fixtures) and tests/fixtures/backend_records_v5.json (written by the v5
   backend, backend/tools/make_frontend_fixtures.py). */
"use strict";
var path = require("path"), fs = require("fs");
global.window = { AERIS_CONFIG: { researchApi: { baseUrl: null } } };
var J = function (p) { return require(path.join(__dirname, "..", "js", p)); };
global.AERIS_IDS = J("platform/ids.js");
global.AERIS_TWIN = J("core.js");
global.AERIS_SCHEMA = J("platform/schema.js");
global.AERIS_EVENTS = J("platform/events.js");
global.AERIS_CFG = J("platform/config.js");
global.AERIS_RUNS = J("runs.js");
global.AERIS_JOBS = J("platform/jobs.js");
global.AERIS_SWEEP = J("platform/sweep.js");
global.AERIS_EXAMPLES = J("platform/examples.js");
global.LocalSimulatorAdapter = J("adapters/local-simulator.js");
global.ReplayAdapter = J("adapters/replay.js");
global.ResearchApiAdapter = J("adapters/research-api.js");
global.HardwareTelemetryAdapter = J("adapters/hardware-telemetry.js");
var SERVICE = J("platform/service.js");
var TWIN = global.AERIS_TWIN, RUNS = global.AERIS_RUNS, SWEEP = global.AERIS_SWEEP, CFG = global.AERIS_CFG, JOBS = global.AERIS_JOBS;
var FX4 = JSON.parse(fs.readFileSync(path.join(__dirname, "fixtures", "backend_records.json"), "utf8")).records;
var FX5 = JSON.parse(fs.readFileSync(path.join(__dirname, "fixtures", "backend_records_v5.json"), "utf8")).records;
function clone(o) { return JSON.parse(JSON.stringify(o)); }
function cfg(mode, o) { var c = TWIN.defaultConfig(mode); Object.keys(o || {}).forEach(function (k) { c[k] = clone(o[k]); }); return c; }
function same(a, b) { return JSON.stringify(a) === JSON.stringify(b); }

var results = [], queue = [];
function test(n, f) { queue.push({ n: n, f: f }); }
function run() {
  var i = 0;
  (function next() {
    if (i >= queue.length) return report();
    var t = queue[i++], cur = { name: t.n, ok: true, msgs: [] };
    function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
    RUNS.useStorage(RUNS.memoryStore(), false);
    var p; try { p = t.f(check); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); }
    Promise.resolve(p).then(function () { results.push(cur); next(); }, function (e) { cur.ok = false; cur.msgs.push("rejected: " + JSON.stringify(e && (e.stack || e.message) || e)); results.push(cur); next(); });
  })();
}
function report() {
  var pass = results.filter(function (r) { return r.ok; }).length;
  results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
  console.log("\n" + pass + " / " + results.length + " v5 frontend tests passed");
  process.exit(pass === results.length ? 0 : 1);
}
var CAPS = { kind: "simulation", engine: "aeris-research-backend", engine_version: "aeris-research-engine 1.1.0", reported: true, controllers: ["pid", "lqr", "adp", "nlpd", "none"], structures: ["decoupled", "mimo-lqr"],
  estimators: { edge: ["ideal", "cf", "kf", "accel", "gyro", "cf3d", "mekf"], corner: ["ideal", "cf3d", "mekf"] }, plant: { maxAttachments: 32 }, rates: { maxIntegration_hz: 20000, record_hz: [1, 1000] },
  limits: { maxDuration_s: 600, minDuration_s: 0.5 }, config: { schema: "aeris-config/1", revision: "1.2", revisions: ["1.0", "1.1", "1.2"] },
  sweep: { controllers: ["pid", "lqr", "adp", "nlpd", "lqr-mimo", "none"], seed_strategies: { paired: "", legacy: "", fixed: "", independent: "" }, revision: "1.2", criteria: ["legacy", "research", "research_sustained"] } };
// what an AERIS v4 backend reported (backend 1.0.0: configuration revisions 1.0 and 1.1, no declared sweep criteria)
var CAPS_V4 = Object.assign({}, CAPS, { engine_version: "aeris-research-engine 1.0.0", config: { schema: "aeris-config/1", revisions: ["1.0", "1.1"] },
  sweep: { controllers: CAPS.sweep.controllers, seed_strategies: CAPS.sweep.seed_strategies } });
var Q0 = [0.880990552979211, 0.3399789848371774, -0.3290195188065467, -0.004011442979123468];
function explicitCorner(extra) { return cfg("corner", Object.assign({ initial: { tilt_deg: null, rate_dps: null, azimuth_deg: null, reference: null, attitude_q: Q0.slice(), body_rate_dps: [3, -2, 1] }, reference: { attitude: "balance", heading: "free", yaw_deg: 0 }, estimator: { type: "mekf", stale_after_s: 0.03 } }, extra || {})); }

/* ================================================================ revision 1.2 configuration */
test("R1 Revision 1.2 fields survive normalisation, export/import and repeated normalisation; legacy inputs become null", function (check) {
  var n1 = CFG.normalize(explicitCorner()), n2 = CFG.normalize(clone(n1));
  check(same(n1, n2), "idempotent");
  check(same(n1.initial.attitude_q, Q0) && same(n1.initial.body_rate_dps, [3, -2, 1]), "explicit state kept: " + JSON.stringify(n1.initial));
  check(n1.initial.tilt_deg === null && n1.initial.azimuth_deg === null && n1.initial.reference === null && n1.initial.rate_dps === null, "legacy tilt/rate are null");
  check(same(n1.reference, { attitude: "balance", heading: "free", yaw_deg: 0 }) && n1.estimator.stale_after_s === 0.03, "reference block and age limit kept");
  check(n1.config_revision === "1.2", "marked revision 1.2: " + n1.config_revision);
  var ext = CFG.extensions(n1);
  ["initial.attitude_q", "initial.body_rate_dps", "reference", "estimator.stale_after_s"].forEach(function (p) { check(ext.indexOf(p) >= 0, p + " counted as a research feature: " + ext); });
  var back = RUNS.parseImport(RUNS.exportConfig(n1));
  check(!back.errors.length && same(CFG.normalize(back.configs[0]), n1), "export → import round trip: " + JSON.stringify(back.errors));
  var plain = CFG.normalize(cfg("corner", {}));
  check(plain.config_revision === undefined && !CFG.inUse("reference", { attitude: "balance", heading: "hold", yaw_deg: 0 }), "defaults do not count as a research feature");
});
test("R2 DEMO refuses every revision-1.2 feature with a capability error; SIMULATION accepts them", function (check) {
  var d = SERVICE.validateConfig(explicitCorner(), "demo");
  var paths = d.errors.filter(function (e) { return e.kind === "capability"; }).map(function (e) { return e.path; });
  ["initial.attitude_q", "initial.body_rate_dps", "reference", "estimator.stale_after_s"].forEach(function (p) { check(paths.indexOf(p) >= 0, "refused in DEMO: " + p + " (" + paths + ")"); });
  check(!d.errors.some(function (e) { return /Initial tilt must be a finite number/.test(e.message); }), "no misleading legacy tilt error when the explicit state replaces it");
  var b = CFG.validateFor(explicitCorner({ estimator: { type: "mekf", stale_after_s: 0.03 } }), "backend", CAPS);
  check(b.ok, "SIMULATION accepts: " + JSON.stringify(b.errors));
  return LocalSimulatorAdapter.runSingle(explicitCorner(), {}).then(function (o) { check(!o.ok && /only the research backend runs/.test(o.result.outcome.reason), "the browser engine does not run it: " + (o.result && o.result.outcome.reason)); });
});
test("R3 Early feedback mirrors the backend rules: unit quaternion, edge hinge axis, conflicts, unsupported objectives", function (check) {
  function errs(c) { return CFG.validateFor(c, "backend", CAPS).errors.map(function (e) { return e.path + ": " + e.message; }).join(" | "); }
  check(/unit quaternion/.test(errs(explicitCorner({ initial: { attitude_q: [1, 0.1, 0, 0], body_rate_dps: [0, 0, 0], tilt_deg: null, rate_dps: null, azimuth_deg: null, reference: null } }))), "non-unit q refused");
  var h = Math.PI / 8 + 0.01, off = TWIN.Q3.mul([Math.cos(h), Math.sin(h), 0, 0], TWIN.Q3.axis([0, 1, 0], 0.02));
  check(/support edge/.test(errs(cfg("edge", { initial: { attitude_q: off, tilt_deg: null, azimuth_deg: null, reference: null, rate_dps: 0 } }))), "edge: off-axis q refused");
  check(/\[ω_x, 0, 0\]/.test(errs(cfg("edge", { initial: { body_rate_dps: [1, 1, 0], rate_dps: null, tilt_deg: 2, azimuth_deg: 0, reference: "geometric" } }))), "edge: off-axis rate refused");
  check(/must be null/.test(errs(cfg("corner", { initial: { attitude_q: Q0.slice(), tilt_deg: 2, rate_dps: 0, azimuth_deg: 0, reference: "geometric" } }))) === false, "normalisation nulls the legacy inputs of an explicit setup (no conflict reported after normalising)");
  var mimo = explicitCorner({ controller: { type: "lqr", structure: "mimo-lqr", knowsAttachments: false, reconfigureOnFailure: true } });
  check(/full attitude including the heading/.test(errs(mimo)), "free heading + MIMO LQR refused");
  check(/Yaw commands need/.test(errs(explicitCorner({ commands: [{ id: "C1", type: "yaw_step", t_s: 1, angle_deg: 30 }] }))), "free heading + yaw commands refused");
  check(/heading/.test(errs(cfg("edge", { reference: { heading: "free" } }))), "edge heading refused");
  check(/one of balance/.test(errs(cfg("corner", { reference: { attitude: "tilted" } }))), "non-balance attitude target refused");
});
test("R4 The setup preview uses the explicit state; the explicit editor starts from the legacy inputs' attitude", function (check) {
  var c = cfg("corner", { initial: { tilt_deg: 4, rate_dps: 6, azimuth_deg: 30, reference: "balance" } }), mp = TWIN.massProps(c), st = TWIN.initialState(c, mp);
  var ex = CFG.explicitFromLegacy(c, mp);
  check(ex.attitude_q.every(function (x, i) { return Math.abs(x - st.q[i]) < 1e-12; }) && ex.body_rate_dps.every(function (x, i) { return Math.abs(x - st.w[i] / TWIN.DEG) < 1e-9; }), "corner: q and ω equal the legacy initial state");
  var pose = CFG.initialPose(CFG.normalize(Object.assign(clone(c), { initial: { attitude_q: ex.attitude_q, body_rate_dps: ex.body_rate_dps } })), mp);
  var R = TWIN.Q3.rot(st.q);
  check(pose.explicit && pose.R.every(function (row, i) { return row.every(function (x, j) { return Math.abs(x - R[i][j]) < 1e-12; }); }), "preview rotation equals the legacy attitude");
  var e = cfg("edge", { initial: { tilt_deg: 3, rate_dps: 7, reference: "geometric" } }), mpe = TWIN.massProps(e), exe = CFG.explicitFromLegacy(e, mpe);
  check(Math.abs(CFG.edgeThetaOfQ(exe.attitude_q).theta - 3 * TWIN.DEG) < 1e-12 && Math.abs(exe.body_rate_dps[0] - 7) < 1e-12 && exe.body_rate_dps[1] === 0, "edge: θ and rate kept");
});
test("R5 Real v5 backend records (explicit state, free heading, estimator timing, lineage) validate and keep their fields", function (check) {
  Object.keys(FX5).forEach(function (k) {
    var rec = clone(FX5[k]), v = RUNS.validateRecord(rec);
    check(v.ok, k + ": " + v.errors.join(" "));
    check(rec.schema_revision === "1.3" && RUNS.isBackendRecord(rec), k + ": revision 1.3 backend record");
    var done = RUNS.completeRecord(rec, v);
    check(done.schema_revision === "1.3" && same(done.config, FX5[k].config) && same(done.executed, FX5[k].executed), k + ": nothing rewritten");
    check(RUNS.metricsVersion(done) === "2" && done.samples.schedule && done.samples.schedule.matches_request, k + ": metric version 2, recording schedule saved");
  });
  var f = FX5.v5_corner_explicit_free;
  check(f.executed.reference.requested.heading === "free" && /any heading/.test(f.research.recovery.target), "free heading recorded with the target");
  check(f.research.estimator.age_mean_s > 0 && f.samples.cols.est_age && f.samples.cols.est_valid, "estimator timing recorded");
  check(FX5.v5_reanalysis.lineage.relation === "reanalysis", "lineage kept");
  var csv = RUNS.toCSV(RUNS.completeRecord(clone(FX5.v5_reanalysis), RUNS.validateRecord(clone(FX5.v5_reanalysis))));
  check(/research metrics version: 2/.test(csv) && /lineage: reanalysis of AERIS-EXP-900003/.test(csv), "CSV header names metric version and lineage");
});

/* ================================================================ recording schedule (Fix D) */
test("D1 The browser engine refuses rates that do not divide the loop rate and labels the realized rate", function (check) {
  var v = TWIN.validateConfig(cfg("edge", { record_hz: 60 }));
  check(!v.ok && v.errors.some(function (e) { return e.path === "record_hz" && /62\.5 Hz/.test(e.message) && /55\.5556 Hz/.test(e.message); }), "60 Hz at 500 Hz refused with the nearest valid rates");
  [10, 25, 50, 62.5, 100, 125].forEach(function (hz) {
    var r = TWIN.simulate(cfg("edge", { record_hz: hz, duration_s: 1 }));
    var dt = r.samples.cols.t[1] - r.samples.cols.t[0];
    check(r.ok && r.samples.rate_hz === hz && Math.abs(1 / dt - hz) < 1e-6 * hz && r.samples.schedule.realized_hz === hz && r.samples.schedule.matches_request, hz + " Hz recorded and labelled exactly");
  });
  check(!CFG.validateFor(cfg("edge", { record_hz: 60 }), "backend", CAPS).ok, "SIMULATION refuses 60 Hz at 500 Hz integration");
  check(CFG.validateFor(cfg("edge", { record_hz: 250, solver: { method: "rk4", integration_hz: 1000 } }), "backend", CAPS).ok, "SIMULATION: 250 Hz divides a 1000 Hz integration rate");
});
test("D2 Old records with the v4 recording defect are detected and reported, never relabelled", function (check) {
  var r = RUNS.fromSimulation(TWIN.simulate(cfg("edge", { record_hz: 50, duration_s: 1 })));
  // what AERIS v4 wrote for record_hz 60 at fs 500: every 8 steps (0.016 s), labelled 60 Hz
  var t = [], n = 63; for (var i = 0; i <= n; i++) t.push(+(Math.min(i * 0.016, 1)).toPrecision(6));
  var v4 = clone(r); v4.config.record_hz = 60; v4.samples.rate_hz = 60; delete v4.samples.schedule;
  Object.keys(v4.samples.cols).forEach(function (k) { v4.samples.cols[k] = t.map(function (_, j) { return k === "t" ? t[j] : (r.samples.cols[k][Math.min(j, r.samples.cols[k].length - 1)]); }); });
  var info = RUNS.recordingInfo(v4);
  check(info.mismatch && Math.abs(info.realized - 62.5) < 1e-6 && /labelled 60 Hz/.test(info.note), "mismatch detected: " + JSON.stringify(info));
  var csv = RUNS.toCSV(v4);
  check(/recorded at 62\.5 Hz \(the record's label says 60 Hz/.test(csv), "CSV states the realized rate: " + csv.split("\n")[6]);
  check(v4.samples.rate_hz === 60, "the record itself is unchanged");
  check(!RUNS.recordingInfo(r).mismatch, "a v5 record has no mismatch");
});

/* ================================================================ metric versions and reanalysis (Fix A) */
test("M1 Records keep their metric version: v4 backend records are version 1, v5 records version 2", function (check) {
  Object.keys(FX4).forEach(function (k) { check(RUNS.metricsVersion(FX4[k]) === "1", k + ": v4 record is metric version 1"); });
  check(FX4.edge_lqr.research.attitude_error.ise === FX4.edge_lqr.research.attitude_error.ise, "old values are shown as saved");
  Object.keys(FX5).forEach(function (k) { check(RUNS.metricsVersion(FX5[k]) === "2" && FX5[k].research.units["attitude_error.ise"] === "deg²·s", k + ": version 2 with units"); });
  var a = FX5.v5_corner_offset.research.attitude_error;
  check(Math.abs(a.rms - Math.sqrt(a.ise / a.duration_s)) < 1e-9 * Math.max(1, a.rms), "RMS = sqrt(ISE / T) in the v5 record");
});
test("M2 Reanalysis asks the backend for a new record with lineage; the old record is untouched", function (check) {
  var old = clone(FX4.corner_mimo), calls = [], jobPolls = 0, newRec = clone(FX5.v5_reanalysis);
  newRec.origin.adapter = "research-api";
  function reply(status, obj) { var t = JSON.stringify(obj); return Promise.resolve({ ok: status < 400, status: status, text: function () { return Promise.resolve(t); } }); }
  function tr(url, init) {
    var p = url.replace(/^.*\/api\/v1/, "");
    calls.push(init.method + " " + p);
    if (p === "/health") return reply(200, { status: "ok" });
    if (p === "/capabilities") return reply(200, CAPS);
    if (init.method === "POST" && p === "/runs/" + old.id + "/reanalyze") return reply(202, { job: { id: "job-r", kind: "single", state: "queued", seq: 1, progress: { done: 0, total: 1, failed: 0, fraction: 0 }, result_ref: null } });
    if (p === "/jobs/job-r") { jobPolls += 1; return reply(200, { id: "job-r", kind: "single", state: jobPolls > 1 ? "complete" : "running", seq: 1 + jobPolls, progress: { done: jobPolls > 1 ? 1 : 0, total: 1, failed: 0, fraction: jobPolls > 1 ? 1 : 0 }, result_ref: jobPolls > 1 ? { kind: "run", id: newRec.id } : null }); }
    if (p === "/runs/" + newRec.id) return reply(200, newRec);
    return reply(404, { error: { code: "not_found", message: "unknown " + p } });
  }
  var api = ResearchApiAdapter.create({ baseUrl: "http://test-backend", transport: tr, pollMs: 0, wait: function () { return new Promise(function (r) { setTimeout(r, 0); }); } });
  var before = JSON.stringify(old);
  return api.probe().then(function () { return api.reanalyze(old); }).then(function (o) {
    check(o.ok && o.record.lineage.relation === "reanalysis" && o.record.id !== old.id, "new record with lineage: " + JSON.stringify(o).slice(0, 200));
    check(calls.indexOf("POST /runs/" + old.id + "/reanalyze") >= 0, "POST /runs/{id}/reanalyze: " + calls.join(", "));
    check(JSON.stringify(old) === before, "the old record is unchanged");
  });
});

/* ================================================================ sweeps: declared success criterion */
test("S1 The sweep criterion is kept, refused in DEMO when it is not the legacy rule, and accepted for the backend", function (check) {
  var d = { revision: "1.2", criterion: "research_sustained", base: cfg("corner", {}), mode: "grid", controllers: ["lqr"], variables: [{ key: "tilt_deg", min: 1, max: 3, steps: 2 }], duration_s: 2 };
  check(SWEEP.normalize(d).criterion === "research_sustained", "normalisation keeps the criterion");
  var b = SWEEP.validate(d, { engine: "browser" });
  check(!b.ok && b.errors.some(function (e) { return e.path === "criterion" && e.kind === "capability"; }), "DEMO refuses a research criterion");
  var r = SWEEP.validate(d, { engine: "backend", caps: CAPS, limits: { maxRuns: 1000, maxDuration_s: 600 } });
  check(r.ok, "backend accepts: " + JSON.stringify(r.errors));
  check(!SWEEP.validate(Object.assign(clone(d), { criterion: "bogus" }), { engine: "backend", caps: CAPS, limits: { maxRuns: 1000, maxDuration_s: 600 } }).ok, "unknown criterion refused");
  var bad = SWEEP.validate({ revision: "1.2", base: explicitCorner(), mode: "grid", controllers: ["lqr"], variables: [{ key: "tilt_deg", min: 1, max: 3, steps: 2 }], duration_s: 2 }, { engine: "backend", caps: CAPS, limits: { maxRuns: 1000, maxDuration_s: 600 } });
  check(!bad.ok && /attitude quaternion/.test(bad.errors.map(function (e) { return e.message; }).join(" ")), "varying the legacy tilt of an explicit-attitude base is refused");
});

test("C1 Revision-1.2 features and a declared sweep criterion are refused, feature by feature, for a backend that does not report them (v4)", function (check) {
  var v4 = CFG.validateFor(explicitCorner(), "backend", CAPS_V4);
  var paths = v4.errors.filter(function (e) { return e.kind === "capability"; }).map(function (e) { return e.path; });
  ["initial.attitude_q", "initial.body_rate_dps", "reference", "estimator.stale_after_s"].forEach(function (p) { check(paths.indexOf(p) >= 0, "refused for the v4 backend: " + p + " (" + paths + ")"); });
  check(v4.errors.some(function (e) { return /revisions 1\.0, 1\.1 only/.test(e.message); }), "the message names what the backend reports: " + JSON.stringify(v4.errors.map(function (e) { return e.message; })));
  check(CFG.validateFor(cfg("corner", {}), "backend", CAPS_V4).ok, "a revision-1.0 setup still goes to the v4 backend");
  check(CFG.validateFor(explicitCorner(), "backend", CAPS).ok, "the v5 backend (reports revision 1.2) accepts it");
  var d = { revision: "1.2", criterion: "research", base: cfg("corner", {}), mode: "grid", controllers: ["lqr"], variables: [{ key: "tilt_deg", min: 1, max: 3, steps: 2 }], duration_s: 2 };
  var sv4 = SWEEP.validate(d, { engine: "backend", caps: CAPS_V4, limits: { maxRuns: 1000, maxDuration_s: 600 } });
  check(!sv4.ok && sv4.errors.some(function (e) { return e.path === "criterion" && e.kind === "capability"; }), "a research criterion is refused for the v4 backend: " + JSON.stringify(sv4.errors));
  check(SWEEP.validate(Object.assign(clone(d), { criterion: "legacy" }), { engine: "backend", caps: CAPS_V4, limits: { maxRuns: 1000, maxDuration_s: 600 } }).ok, "the legacy criterion is fine for the v4 backend");
});

/* ================================================================ E: the cancellable debounce behind the replay-race fix */
test("E1 A cancelled debounced call never runs; pending() reports scheduled work", function (check) {
  global.AERIS_TOKENS = J("platform/tokens.js");
  var src = fs.readFileSync(path.join(__dirname, "..", "js", "ws-util.js"), "utf8");
  var sandbox = { window: {}, document: { documentElement: { classList: { add: function () {} } } }, setTimeout: setTimeout, clearTimeout: clearTimeout, console: console };
  var vm = require("vm"); vm.createContext(sandbox);
  vm.runInContext(src, sandbox);
  var U = sandbox.U;     // ws-util.js defines the global U
  check(!!U, "ws-util exports debounce");
  var ran = [], d = U.debounce(function (x) { ran.push(x); }, 20);
  d(1); check(d.pending(), "pending after scheduling");
  d.cancel(); check(!d.pending(), "not pending after cancel");
  d(2); d(3);
  return new Promise(function (res) { setTimeout(res, 60); }).then(function () {
    check(same(ran, [3]), "only the last call after the cancel ran: " + JSON.stringify(ran));
    var ws = fs.readFileSync(path.join(__dirname, "..", "js", "workspace.js"), "utf8");
    check(/previewTimer = U\.debounce\(function \(gen\) \{ if \(gen === W\.viewGen && W\.viewMode === "setup"\) previewSetup\(\); \}/.test(ws), "the preview callback checks generation and mode");
    check(/W\.viewGen\+\+; previewTimer\.cancel\(\);/.test(ws), "every view-mode change cancels pending previews");
    check(/if \(!W\.viewer \|\| W\.viewMode !== "setup"\) return;/.test(ws), "previewSetup itself refuses to draw outside setup mode");
  });
});

/* ================================================================ telemetry (docs/TELEMETRY.md) */
function fakeApi(opts) {
  opts = opts || {};
  var calls = [], api = ResearchApiAdapter.create({ baseUrl: "http://127.0.0.1:1", wsUrl: opts.ws === false ? null : "ws://127.0.0.1:1", transport: function (u, init) {
    calls.push([init.method, u.replace("http://127.0.0.1:1/api/v1", "")]);
    var path = u.replace("http://127.0.0.1:1/api/v1", ""), body = opts.routes && opts.routes(path, init) || {};
    return Promise.resolve({ ok: true, status: 200, text: function () { return Promise.resolve(JSON.stringify(body)); } });
  } });
  api.reachable = true; api._caps = Object.assign({}, CAPS, { telemetry: opts.telemetry === undefined ? { available: true, protocol: "aeris-telemetry-ndjson/1", transports: ["tcp", "file", "recording"], read_only: true } : opts.telemetry });
  api.calls = calls;
  return api;
}
function fakeWS(script) {
  var made = [];
  function WS(url) { this.url = url; made.push(this); var self = this; setTimeout(function () { script(self, made.length); }, 1); }
  WS.prototype.close = function () { this.closed = true; };
  WS.made = made;
  return WS;
}
test("T1 HARDWARE mode needs a reachable backend that reports telemetry; the reason is shown otherwise", function (check) {
  var H = HardwareTelemetryAdapter;
  H.bind(null);
  check(!H.available().ok && /No research backend is configured/.test(H.available().reason), H.available().reason);
  var p = H.connect().then(function () { check(false, "must not connect without a backend"); }, function (e) { check(e.code === "unavailable", e.code); });
  var off = fakeApi({ telemetry: { available: false } }); H.bind(off);
  check(!H.available().ok && /switched off/.test(H.available().reason), H.available().reason);
  var old = fakeApi({ telemetry: null }); delete old._caps.telemetry; H.bind(old);
  check(!H.available().ok && /did not report a telemetry path/.test(H.available().reason), H.available().reason);
  var down = fakeApi(); down.reachable = false; down.probeError = { message: "connection refused" }; H.bind(down);
  check(!H.available().ok && /not reachable/.test(H.available().reason), H.available().reason);
  var ok = fakeApi(); H.bind(ok);
  check(H.available().ok && H.capabilities().readOnly === true && H.capabilities().implemented === true, JSON.stringify(H.capabilities()));
  H.bind(null);
  return p;
});
test("T2 The live stream delivers frames once and in order across a WebSocket drop and the polling fallback", function (check) {
  var H = HardwareTelemetryAdapter, polled = 0;
  var api = fakeApi({ routes: function (path) {
    if (/^\/telemetry\/frames\?after=(\d+)/.test(path)) { polled++; var after = +/after=(\d+)/.exec(path)[1]; return { frames: [4, 5, 6].filter(function (n) { return n > after; }).map(function (n) { return { n: n, seq: n, t: n / 100 }; }), last_n: 6, missed: 0 }; }
    if (path === "/telemetry/status") return { connected: true, provenance: { synthetic: true, source_kind: "emulator", label: "SYNTHETIC EMULATOR — not the physical cube" } };
    return {};
  } });
  H.bind(api);
  var WS = fakeWS(function (ws, k) {
    if (k === 1) {    // first socket: opens, sends frames 1–3 (then 2 again), then closes
      ws.onopen(); ws.onmessage({ data: JSON.stringify({ type: "status", status: { connected: true } }) });
      ws.onmessage({ data: JSON.stringify({ type: "frames", frames: [{ n: 1 }, { n: 2 }, { n: 3 }], dropped: 0 }) });
      ws.onmessage({ data: JSON.stringify({ type: "frames", frames: [{ n: 2 }, { n: 3 }], dropped: 0 }) });
      ws.onclose({ code: 1006 });
    } else { ws.onclose({ code: 1006 }); }   // later sockets fail to open
  });
  var got = [], kinds = [], statuses = 0;
  var timers = [];
  var st = H.live(function (ev) { if (ev.type === "frames") got = got.concat(ev.frames.map(function (f) { return f.n; })); else if (ev.type === "transport") kinds.push(ev.kind); else if (ev.type === "status") statuses++; },
    { WebSocket: WS, pollMs: 5, wait: function (ms, fn) { var t = setTimeout(fn, ms); timers.push(t); return t; } });
  return new Promise(function (res) { setTimeout(res, 250); }).then(function () {
    st.close();
    check(same(got, [1, 2, 3, 4, 5, 6]), "each frame once, in order: " + JSON.stringify(got));
    check(kinds[0] === "websocket" && kinds.indexOf("polling") > 0, "transport reported: " + JSON.stringify(kinds));
    check(polled > 0 && statuses > 0, "polled " + polled + ", statuses " + statuses);
    check(WS.made.length >= 2 && WS.made.length <= 5, "a bounded number of WebSocket attempts: " + WS.made.length);
    check(api.calls.every(function (c) { return c[0] === "GET"; }), "the live view only reads: " + JSON.stringify(api.calls.slice(0, 3)));
    H.bind(null);
  });
});
test("T3 A full live-client list (4429) falls back to polling at once and says why", function (check) {
  var H = HardwareTelemetryAdapter;
  var api = fakeApi({ routes: function (path) { return /frames/.test(path) ? { frames: [{ n: 9 }], last_n: 9, missed: 3 } : { connected: false }; } });
  H.bind(api);
  var WS = fakeWS(function (ws) { ws.onclose({ code: 4429 }); });
  var reasons = [], gaps = 0;
  var st = H.live(function (ev) { if (ev.type === "transport") reasons.push(ev.reason); if (ev.type === "gap") gaps += ev.missed; }, { WebSocket: WS, pollMs: 5 });
  return new Promise(function (res) { setTimeout(res, 80); }).then(function () {
    st.close();
    check(WS.made.length === 1, "no WebSocket retries after 4429: " + WS.made.length);
    check(reasons.some(function (r) { return /limit/.test(r || ""); }), JSON.stringify(reasons));
    check(gaps >= 3, "frames missed while polling are reported: " + gaps);
    H.bind(null);
  });
});
test("T4 Provenance labels: synthetic is never shown as the cube; a declared device is 'not verified'", function (check) {
  var L = HardwareTelemetryAdapter.provenanceLabel;
  var syn = L({ source_kind: "emulator", synthetic: true, label: "SYNTHETIC EMULATOR — not the physical cube" });
  check(syn.cls === "synthetic" && /SYNTHETIC/.test(syn.text) && /not the physical cube/.test(syn.text), JSON.stringify(syn));
  var rep = L({ source_kind: "emulator", synthetic: true, replay: true, label: "SYNTHETIC EMULATOR — not the physical cube" });
  check(/^REPLAY/.test(rep.text) && rep.cls === "synthetic", rep.text);
  var dev = L({ source_kind: "physical", synthetic: false, declared_physical: true, device_id: "cube-1" });
  check(dev.cls === "declared" && /not verified/.test(dev.text), dev.text);
  check(L(null).cls === "none" && L({}).text === "No telemetry source", "no source");
  var ST = require(path.join(__dirname, "..", "js", "ui", "status.js"));
  var m = ST.model("lab", { source: "telemetry-synthetic" }, "hardware");
  check(m[1].value === "SYNTHETIC TELEMETRY" && m[1].value !== "HARDWARE", JSON.stringify(m[1]));
  var m2 = ST.model("lab", { source: "telemetry-declared" }, "hardware");
  check(/DECLARED/.test(m2[1].value), m2[1].value);
});
test("T5 The telemetry panel and the bridge text never call the emulator the cube (source check)", function (check) {
  var ui = fs.readFileSync(path.join(__dirname, "..", "js", "ui", "telemetry-ui.js"), "utf8");
  check(/SYNTHETIC telemetry · not the cube/.test(ui), "the 3-D view label names synthetic telemetry");
  check(!/send\(|\.send\b/.test(ui), "the panel has no code path that sends to a device");
  var ad = fs.readFileSync(path.join(__dirname, "..", "js", "adapters", "hardware-telemetry.js"), "utf8");
  check(!/ws\.send|\.send\(/.test(ad), "the adapter never sends on the live socket");
});

run();

/* v5.1 frontend tests: the live telemetry stream across research-backend restarts (review finding F2; stream
   identity, docs/TELEMETRY.md §7) and how the Telemetry tab words the origin of stored recordings (finding F1).
   Run with:  node tests/v51.test.js

   The transports here are hand-driven fixtures (a WebSocket whose events the test fires, a request function that
   answers like a backend): no backend process is involved. The same adapter is exercised against real backend
   processes by live_backend.test.js (L14) and in Chromium by browser_v51.py. */
"use strict";
var path = require("path"), fs = require("fs");
global.window = { AERIS_CONFIG: { researchApi: { baseUrl: null } } };
var J = function (p) { return require(path.join(__dirname, "..", "js", p)); };
global.AERIS_IDS = J("platform/ids.js");
global.AERIS_TWIN = J("core.js");
global.AERIS_SCHEMA = J("platform/schema.js");
global.AERIS_EVENTS = J("platform/events.js");
global.AERIS_CFG = J("platform/config.js");
global.AERIS_RUNS = J("runs.js");
global.AERIS_JOBS = J("platform/jobs.js");
global.ResearchApiAdapter = J("adapters/research-api.js");
var H = J("adapters/hardware-telemetry.js");
function same(a, b) { return JSON.stringify(a) === JSON.stringify(b); }

var results = [], queue = [];
function test(n, f) { queue.push({ n: n, f: f }); }
function run() {
  var i = 0;
  (function next() {
    if (i >= queue.length) return report();
    var t = queue[i++], cur = { name: t.n, ok: true, msgs: [] };
    function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
    var p; try { p = t.f(check); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + (e && e.stack || e)); }
    Promise.resolve(p).then(function () { H.bind(null); results.push(cur); next(); }, function (e) { H.bind(null); cur.ok = false; cur.msgs.push("rejected: " + (e && (e.stack || e.message) || e)); results.push(cur); next(); });
  })();
}
function report() {
  var pass = results.filter(function (r) { return r.ok; }).length;
  results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.ok ? "" : "\n     " + r.msgs.join("\n     "))); });
  console.log("\n" + pass + " / " + results.length + " v5.1 frontend tests passed");
  process.exit(pass === results.length ? 0 : 1);
}

/* ---------------- fixtures ---------------- */
var CAPS = { kind: "simulation", engine: "aeris-research-backend", engine_version: "aeris-research-engine 1.1.1", reported: true, controllers: ["pid", "lqr"],
  telemetry: { available: true, protocol: "aeris-telemetry-ndjson/1", transports: ["tcp", "file", "recording"], read_only: true } };
/* a research backend whose answers the test sets: backend.frames(path) and backend.status() */
function fakeBackend() {
  var b = { paths: [], frames: function () { return { frames: [], last_n: 0, missed: 0 }; }, status: function () { return { connected: true }; } };
  b.api = ResearchApiAdapter.create({ baseUrl: "http://127.0.0.1:1", wsUrl: "ws://127.0.0.1:1", transport: function (u, init) {
    var p = u.replace("http://127.0.0.1:1/api/v1", ""); b.paths.push(p);
    var body = /^\/telemetry\/frames/.test(p) ? b.frames(p) : p === "/telemetry/status" ? b.status() : {};
    return Promise.resolve({ ok: true, status: 200, text: function () { return Promise.resolve(JSON.stringify(body)); } });
  } });
  b.api.reachable = true; b.api._caps = CAPS;
  return b;
}
/* a WebSocket whose events the test fires by hand */
function handWS() {
  var made = [];
  function WS(url) { this.url = url; made.push(this); }
  WS.prototype.close = function () { this.closed = true; };
  WS.made = made;
  return WS;
}
function send(ws, o) { ws.onmessage({ data: JSON.stringify(o) }); }
function settle() { return new Promise(function (r) { setImmediate(r); }).then(function () { return new Promise(function (r) { setImmediate(r); }); }); }
function frames(a, b) { var o = []; for (var n = a; n <= b; n++) o.push({ n: n, seq: n, t: n / 100 }); return o; }
/* a consumer that remembers what the live stream told it, in order */
function consumer() {
  var c = { log: [], delivered: [] };
  c.on = function (ev) {
    c.log.push(ev.type === "frames" ? "frames:" + ev.frames.map(function (f) { return f.n; }).join(",") : ev.type === "stream" ? "stream:" + ev.stream : ev.type === "transport" ? "transport:" + ev.kind : ev.type);
    if (ev.type === "frames") c.delivered = c.delivered.concat(ev.frames.map(function (f) { return f.n; }));
    if (ev.type === "stream") c.stream = ev;
  };
  return c;
}
function manualWait() { var q = []; var w = function (ms, fn) { q.push(fn); return 0; }; w.q = q; w.next = function () { var fn = q.shift(); if (fn) fn(); return !!fn; }; return w; }

/* ================================================================ stream identity (F2) */
test("W1 A backend restart (new stream id) starts the cursor again: 'stream' first, then the new process's frames; late messages of the old stream are ignored", function (check) {
  var b = fakeBackend(), WS = handWS(), c = consumer(), wait = manualWait();
  b.frames = function () { return { frames: [], last_n: 2, missed: 0, stream_id: "S2" }; };
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: wait });
  var a = WS.made[0];
  a.onopen(); send(a, { type: "status", status: { stream_id: "S1", last_n: 0 } });
  send(a, { type: "frames", stream: "S1", frames: frames(1, 1000), dropped: 0 });
  check(live.streamId() === "S1" && live.lastN() === 1000 && live.streamChanges() === 0, "the first stream is adopted silently: " + live.streamId() + " " + live.lastN());
  a.onclose({ code: 1012 });                                     // the backend process stops ...
  return settle().then(function () {
    check(b.paths.some(function (p) { return /after=1000&limit=500&stream=S1$/.test(p); }), "the poll names its stream: " + JSON.stringify(b.paths));
    check(live.streamId() === "S2" && live.streamChanges() === 1 && c.stream && c.stream.previous === "S1", "the poll answer of the new process switched the stream: " + JSON.stringify(c.stream));
    wait.next();                                                 // ... the adapter opens a new socket to the new process
    var s = WS.made[1];
    s.onopen(); send(s, { type: "status", status: { stream_id: "S2", last_n: 2 } });
    send(s, { type: "frames", stream: "S2", frames: frames(1, 2), dropped: 0 });
    send(s, { type: "frames", stream: "S1", frames: frames(1001, 1001), dropped: 0 });        // a late batch of the old stream
    send(s, { type: "status", status: { stream_id: "S1", last_n: 1001 } });                   // and a late status of it
    var iStream = c.log.indexOf("stream:S2"), iNew = c.log.indexOf("frames:1,2");
    check(iStream >= 0 && iNew > iStream, "reset before the new frames: " + JSON.stringify(c.log));
    check(same(c.delivered.slice(-2), [1, 2]) && c.delivered.indexOf(1001) < 0, "new frames delivered, old ones ignored: " + JSON.stringify(c.delivered.slice(-4)));
    check(live.streamId() === "S2" && live.lastN() === 2 && live.streamChanges() === 1, "one change, cursor of the new stream: " + live.lastN());
    live.close();
  });
});

test("W2 Forced polling across a restart: the answer of the new process starts at its beginning; a stale answer of the old one changes nothing", function (check) {
  var b = fakeBackend(), c = consumer(), wait = manualWait();
  var NoWS = function () { throw new Error("WebSocket disabled for this test"); };
  b.frames = function (p) { var after = +/after=(\d+)/.exec(p)[1]; return { frames: frames(1, 480).filter(function (f) { return f.n > after; }), last_n: 480, missed: 0, stream_id: "P1", stream_changed: false }; };
  b.status = function () { return { stream_id: "P1", last_n: 480, connected: true }; };
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: NoWS, wait: wait });
  return settle().then(function () {
    check(live.mode() === "polling" && live.streamId() === "P1" && live.lastN() === 480, "polling stream P1 at 480: " + live.mode() + " " + live.lastN());
    // restart: the new process answers the old cursor from its beginning
    b.frames = function (p) { var named = /stream=([^&]+)/.exec(p), after = +/after=(\d+)/.exec(p)[1], changed = !!named && named[1] !== "P2";
      return { frames: frames(1, 3).filter(function (f) { return f.n > (changed ? 0 : after); }), last_n: 3, missed: 0, stream_id: "P2", stream_changed: changed }; };
    b.status = function () { return { stream_id: "P2", last_n: 3, connected: true }; };
    wait.next();
    return settle();
  }).then(function () {
    check(/after=480&limit=500&stream=P1$/.test(b.paths.filter(function (p) { return /frames/.test(p); }).pop()), "asked with the old cursor and stream");
    check(same(c.delivered.slice(-3), [1, 2, 3]) && c.log.indexOf("stream:P2") >= 0 && c.log.indexOf("stream:P2") < c.log.indexOf("frames:1,2,3"), JSON.stringify(c.log.slice(-4)));
    // a stale answer of the old process (e.g. a slow request) arrives: ignored
    b.frames = function () { return { frames: frames(481, 482), last_n: 482, missed: 0, stream_id: "P1", stream_changed: false }; };
    b.status = function () { return { stream_id: "P1", last_n: 482, connected: true }; };
    var statusesBefore = c.log.filter(function (x) { return x === "status"; }).length;
    wait.next();
    return settle().then(function () {
      check(c.delivered.indexOf(481) < 0 && live.streamId() === "P2" && live.lastN() === 3, "stale answer ignored: " + live.streamId() + " " + live.lastN());
      check(c.log.filter(function (x) { return x === "status"; }).length === statusesBefore, "a stale status is not passed on");
      // the new stream continues normally
      b.frames = function (p) { var after = +/after=(\d+)/.exec(p)[1]; return { frames: frames(1, 5).filter(function (f) { return f.n > after; }), last_n: 5, missed: 0, stream_id: "P2", stream_changed: false }; };
      b.status = function () { return { stream_id: "P2", last_n: 5, connected: true }; };
      wait.next();
      return settle();
    });
  }).then(function () {
    check(/after=3&limit=500&stream=P2$/.test(b.paths.filter(function (p) { return /frames/.test(p); }).pop()), "continues with the new cursor and stream");
    check(same(c.delivered.slice(-5), [1, 2, 3, 4, 5]) && live.streamChanges() === 1, JSON.stringify(c.delivered.slice(-6)));
    live.close();
  });
});

test("W3 A reconnect WITHOUT a restart keeps one cursor: each frame once and in order across WebSocket → polling → WebSocket", function (check) {
  var b = fakeBackend(), WS = handWS(), c = consumer(), wait = manualWait();
  b.frames = function (p) { var after = +/after=(\d+)/.exec(p)[1]; return { frames: frames(1, 7).filter(function (f) { return f.n > after; }), last_n: 7, missed: 0, stream_id: "K" }; };
  b.status = function () { return { stream_id: "K", last_n: 7 }; };
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: wait });
  var a = WS.made[0];
  a.onopen(); send(a, { type: "status", status: { stream_id: "K", last_n: 0 } });
  send(a, { type: "frames", stream: "K", frames: frames(1, 4), dropped: 0 });
  send(a, { type: "frames", stream: "K", frames: frames(3, 5), dropped: 0 });          // overlap: 3 and 4 again
  a.onclose({ code: 1006 });
  return settle().then(function () {
    wait.next();
    var s = WS.made[1];
    s.onopen(); send(s, { type: "status", status: { stream_id: "K", last_n: 7 } });
    send(s, { type: "frames", stream: "K", frames: frames(6, 9), dropped: 0 });
    check(same(c.delivered, [1, 2, 3, 4, 5, 6, 7, 8, 9]), "each once, in order: " + JSON.stringify(c.delivered));
    check(live.streamChanges() === 0 && c.log.every(function (x) { return !/^stream:/.test(x); }), "no reset without a restart: " + JSON.stringify(c.log));
    live.close();
  });
});

test("W4 A v5 backend sends no stream id: a counter below the cursor (poll answer, first status of a socket) restarts; nothing else does", function (check) {
  var b = fakeBackend(), WS = handWS(), c = consumer(), wait = manualWait();
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: wait });
  var a = WS.made[0];
  a.onopen(); send(a, { type: "status", status: { last_n: 0 } });
  send(a, { type: "frames", frames: frames(1, 300), dropped: 0 });
  send(a, { type: "status", status: { last_n: 250 } });                  // an older status later on the same socket: never a restart
  check(live.lastN() === 300 && live.streamChanges() === 0, "no reset from a mid-socket status: " + live.streamChanges());
  check(live.observe(undefined) === "ok" && live.streamChanges() === 0, "a status fetched elsewhere never triggers the counter rule");
  a.onclose({ code: 1012 });
  b.frames = function (p) { var after = +/after=(\d+)/.exec(p)[1]; return { frames: frames(1, 4).filter(function (f) { return f.n > after; }), last_n: 4, missed: 0 }; };
  return settle().then(function () {
    check(live.streamChanges() === 1 && live.lastN() === 0 && c.stream && c.stream.stream === null, "the poll answer's counter (4 < 300) restarted the stream: " + live.lastN());
    // the next socket's first status: same process now, no second restart; its frames arrive
    wait.next();
    var s = WS.made[1];
    s.onopen(); send(s, { type: "status", status: { last_n: 4 } });
    send(s, { type: "frames", frames: frames(1, 6), dropped: 0 });
    check(same(c.delivered.slice(-6), [1, 2, 3, 4, 5, 6]) && live.streamChanges() === 1, JSON.stringify(c.delivered.slice(-7)));
    // a restart seen first by a new socket: its first status is below the cursor
    s.onclose({ code: 1012 });
    return settle();
  }).then(function () {
    b.frames = function () { return { frames: [], last_n: 6, missed: 0 }; };                 // (the poll still sees the old process)
    wait.next();
    return settle().then(function () {
      wait.next();
      var t = WS.made[WS.made.length - 1];
      t.onopen(); send(t, { type: "status", status: { last_n: 1 } });
      send(t, { type: "frames", frames: frames(1, 2), dropped: 0 });
      check(live.streamChanges() === 2 && same(c.delivered.slice(-2), [1, 2]), "the first status of a socket below the cursor restarted: " + JSON.stringify(c.log.slice(-5)));
      live.close();
    });
  });
});

test("W5 A panel shown again (opts.stream/opts.after) continues its stream, or learns at once that the backend restarted", function (check) {
  var b = fakeBackend(), WS = handWS(), c1 = consumer(), c2 = consumer();
  H.bind(b.api);
  var l1 = H.live(c1.on, { WebSocket: WS, wait: manualWait(), stream: "V", after: 40 });
  var a = WS.made[0];
  a.onopen(); send(a, { type: "status", status: { stream_id: "V", last_n: 45 } });
  send(a, { type: "frames", stream: "V", frames: frames(38, 45), dropped: 0 });
  check(same(c1.delivered, [41, 42, 43, 44, 45]) && l1.streamChanges() === 0, "same stream: continues after 40: " + JSON.stringify(c1.delivered));
  l1.close();
  var l2 = H.live(c2.on, { WebSocket: WS, wait: manualWait(), stream: "V", after: 45 });
  var s = WS.made[1];
  s.onopen(); send(s, { type: "status", status: { stream_id: "W", last_n: 2 } });
  send(s, { type: "frames", stream: "W", frames: frames(1, 2), dropped: 0 });
  check(l2.streamChanges() === 1 && c2.stream && c2.stream.previous === "V" && same(c2.delivered, [1, 2]), "changed stream reported and delivered: " + JSON.stringify(c2.log));
  l2.close();
  // backward compatible: a stream event only exists since v5.1; live() without options behaves as in v5
  var l3 = H.live(consumer().on, { WebSocket: WS, wait: manualWait() });
  check(l3.streamId() === null && l3.lastN() === 0, "no options: nothing assumed");
  l3.close();
});

test("W6 observe(): a status the page fetched itself adopts a new stream (reset first) or is reported stale", function (check) {
  var b = fakeBackend(), WS = handWS(), c = consumer();
  H.bind(b.api);
  var live = H.live(c.on, { WebSocket: WS, wait: manualWait() });
  var a = WS.made[0];
  a.onopen(); send(a, { type: "status", status: { stream_id: "O1", last_n: 0 } });
  send(a, { type: "frames", stream: "O1", frames: frames(1, 9), dropped: 0 });
  check(live.observe("O1") === "ok" && live.streamChanges() === 0, "the current stream is ok");
  check(live.observe("O2") === "ok" && live.streamChanges() === 1 && c.log[c.log.length - 1] === "stream:O2" && live.lastN() === 0, "a new stream: reset reported: " + JSON.stringify(c.log.slice(-2)));
  check(live.observe("O1") === "stale", "the stream left is stale");
  live.close();
  check(live.observe("O3") === "stale", "a closed stream accepts nothing");
});

test("W7 A socket that only reports an error (Node's WebSocket) or never settles falls back to polling; the stream never hangs", function (check) {
  var b = fakeBackend(), c = consumer(), made = [];
  b.frames = function () { return { frames: frames(1, 2), last_n: 2, missed: 0, stream_id: "E" }; };
  H.bind(b.api);
  function ErrOnly(url) { var self = this; made.push(this); setTimeout(function () { self.onerror && self.onerror({}); }, 1); }
  ErrOnly.prototype.close = function () {};
  var w = manualWait();
  var l1 = H.live(c.on, { WebSocket: ErrOnly, wait: w });
  return new Promise(function (r) { setTimeout(r, 20); }).then(function () {
    check(l1.mode() === "polling" && same(c.delivered, [1, 2]), "error without close → polling: " + l1.mode() + " " + JSON.stringify(c.delivered));
    l1.close();
    var c2 = consumer(), hung = [];
    function Never(url) { hung.push(this); }
    Never.prototype.close = function () { this.closedByGuard = true; };
    var l2 = H.live(c2.on, { WebSocket: Never, wait: manualWait(), wsOpenTimeoutMs: 30 });
    return new Promise(function (r) { setTimeout(r, 80); }).then(function () {
      check(hung[0].closedByGuard === true && l2.mode() === "polling" && same(c2.delivered, [1, 2]), "an attempt that never settles is given up: " + l2.mode());
      check(c2.log.indexOf("transport:polling") >= 0, JSON.stringify(c2.log));
      l2.close();
    });
  });
});

test("W8 The Telemetry tab resets its display on a stream change and checks statuses it fetched itself (source check; behaviour: browser_v51.py)", function (check) {
  var ui = fs.readFileSync(path.join(__dirname, "..", "js", "ui", "telemetry-ui.js"), "utf8");
  check(/ev\.type === "stream"\) resetForStream\(ev\)/.test(ui), "the live stream's 'stream' event is handled");
  var body = (/function resetForStream\(ev\) \{([\s\S]*?)\n  \}/.exec(ui) || [])[1] || "";
  ["S.latest = null", "S.lastT = null", "S.ang = [0, 0, 0]", "S.dropped = 0", "S.missed = 0", "S.status = null", "renderRead(null)"].forEach(function (k) { check(body.indexOf(k) >= 0, "resetForStream: " + k); });
  check(/S\.stream\.observe\(st\.stream_id\) === "stale"\) return;/.test(ui), "a stale status fetched by the page is ignored");
  check(/stream: S\.streamId, after:/.test(ui), "a panel shown again passes its stream and cursor to live()");
  check(!/\.send\(/.test(ui), "still read-only: nothing is sent");
});

/* ================================================================ origin of stored recordings (F1) */
test("P1 Stored recordings: unknown origin and replay copies are named; a synthetic recording keeps the SYNTHETIC chip (source check)", function (check) {
  var ui = fs.readFileSync(path.join(__dirname, "..", "js", "ui", "telemetry-ui.js"), "utf8");
  var body = (/function originText\(r\) \{([\s\S]*?)\n  \}/.exec(ui) || [])[1] || "";
  check(/r\.trust === "unknown"\) return "origin not declared/.test(body), "unknown trust is never shown as physical");
  check(/copy captured from a replay/.test(body), "a declared-physical copy says it is a copy");
  check(/r\.synthetic \? synthChip\(\)/.test(ui), "synthetic rows keep the chip");
  var L = H.provenanceLabel;
  var rep = L({ source_kind: "file-replay", synthetic: true, replay: true, label: "SYNTHETIC REPLAY — not the physical cube" });
  check(rep.cls === "synthetic" && /SYNTHETIC REPLAY/.test(rep.text), "the synthetic replay identity is labelled synthetic: " + rep.text);
});

run();

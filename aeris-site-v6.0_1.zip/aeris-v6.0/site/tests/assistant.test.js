/* Tests for the local assistant (js/assistant.js): answers use only run data,
   never produce NaN/undefined, and numbers from an external service are checked.
   Run with:  node tests/assistant.test.js */
"use strict";
var path = require("path");
global.window = {};
var AERIS_TWIN = require(path.join(__dirname, "..", "js", "core.js")); global.AERIS_TWIN = AERIS_TWIN;
var RUNS = require(path.join(__dirname, "..", "js", "runs.js"));
var AS = require(path.join(__dirname, "..", "js", "assistant.js"));
RUNS.useStorage(RUNS.memoryStore(), false);
var results = [], cur;
function test(n, f) { cur = { name: n, ok: true, msgs: [] }; try { f(); } catch (e) { cur.ok = false; cur.msgs.push("threw: " + e.stack); } results.push(cur); }
function check(c, m) { if (!c) { cur.ok = false; cur.msgs.push(m); } }
function cfg(mode, o) { var c = AERIS_TWIN.defaultConfig(mode); Object.keys(o).forEach(function (k) { c[k] = o[k]; }); return c; }
function rec(c) { return RUNS.fromSimulation(AERIS_TWIN.simulate(c)); }
function clean(html) { return !/NaN|undefined|Infinity/.test(html); }
var ini0 = { tilt_deg: 0, rate_dps: 0, azimuth_deg: 0, reference: "geometric" };
var REG = rec(cfg("edge", { controller: { type: "pid" }, initial: ini0, comOffset_m: 0.003, duration_s: 4 }));
var FALL = rec(cfg("edge", { controller: { type: "pid" }, initial: ini0, comOffset_m: 0.003, duration_s: 20 }));
var MASS = rec(cfg("edge", { controller: { type: "lqr", knowsAttachments: true }, attachments: [{ id: "m1", label: "Clip", mass_kg: 0.06, pos_m: [0.09, 0.03, 0.18] }], initial: { tilt_deg: 1, rate_dps: 0, azimuth_deg: 0, reference: "balance" }, duration_s: 4 }));
var CORNER = rec(cfg("corner", { initial: { tilt_deg: 2, rate_dps: 0, azimuth_deg: 40, reference: "geometric" }, duration_s: 4, events: [{ id: "E1", type: "wheel_failure", wheel: "x", t_s: 0.1 }], disturbances: [{ id: "F1", type: "force", magnitude_N: 0.2, point_m: [0.18, 0.18, 0.18], direction: [1, 0, 0], frame: "world", t_start_s: 1, duration_s: 0.5 }] }));

test("Saturation answer quotes the run's own drift slope and lists the data used", function () {
  var a = AS.local("whySaturate", "", REG, 100, {});
  check(a.html.indexOf(Math.round(REG.metrics.drift.slope_rpm_s) + " rpm/s") >= 0, "slope missing");
  check(/Data used/.test(a.html) && clean(a.html), "data-used list / clean");
});
test("'Why did this run fall?' is honest when the run did not fall", function () {
  var a = AS.local("whyFall", "", REG, 0, {});
  check(/did not fall/.test(a.html) && /Drifting/.test(a.html), a.html.slice(0, 120));
});
test("'Why did this run fall?' names the fall time and the saturated wheel", function () {
  var a = AS.local("whyFall", "", FALL, 0, {});
  check(a.html.indexOf(FALL.metrics.fellAt_s.toFixed(2)) >= 0 && /speed limit/.test(a.html) && clean(a.html), a.html.slice(0, 200));
});
test("Centre-of-mass answer uses the saved mass properties", function () {
  var a = AS.local("comShift", "", MASS, 0, {});
  check(a.html.indexOf(MASS.derived.M.toFixed(3)) >= 0 && /Clip/.test(a.html) && clean(a.html), a.html.slice(0, 200));
});
test("Every equation explanation is clean in edge and corner mode", function () {
  Object.keys(AS.EQUATIONS).forEach(function (k) {
    [REG, CORNER].forEach(function (r) { var a = AS.local("explainEquation", "", r, Math.floor(r.samples.cols.t.length / 2), { equation: k }); check(clean(a.html) && a.html.length > 80, k + " " + r.config.mode); });
  });
});
test("Run comparison needs two runs and lists the differing conditions", function () {
  check(/Select two runs/.test(AS.local("diffRuns", "", REG, 0, { compare: [REG] }).html), "one run");
  var a = AS.local("diffRuns", "", REG, 0, { compare: [REG, MASS] });
  check(/Controller/.test(a.html) && /cannot be pinned on any single one/.test(a.html) && /not which controller is better/.test(a.html), a.html.slice(0, 200));
});
test("Free text is routed to a fixed question or answered with the list of supported questions", function () {
  check(AS.classify("why did it fall over?") === "whyFall" && AS.classify("wheel saturation") === "whySaturate", "classify");
  var a = AS.local(AS.classify("what is the weather"), "what is the weather", REG, 0, {});
  check(/No AI service is connected/.test(a.html), "fallback text");
});
test("Numbers from an external service that are not in the run data are flagged", function () {
  var ctx = AS.buildContext(REG, 100, []);
  var out = AS.flagUnverified("The wheel ended at 4135 rpm, not 9876.5 rpm.", ctx);
  check(out.indexOf('<mark class="unverified" title="Not found in this run\'s data">9876.5</mark>') >= 0, out);
  check(out.indexOf("4135</mark>") < 0, "4135 must not be flagged: " + out);
});
test("With no endpoint configured the answer is local and makes no network call", function (done) {
  check(!AS.connected, "should not be connected");
  var called = false; global.fetch = function () { called = true; return Promise.reject(new Error("no")); };
  AS.answer("Why did the reaction wheel saturate?", REG, 10, {}).then(function (a) { check(a.source === "local" && !called, "source " + a.source); });
});

setTimeout(function () {
  var pass = results.filter(function (r) { return r.ok; }).length;
  results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name); r.msgs.forEach(function (m) { console.log("     " + m); }); });
  console.log("\n" + pass + " / " + results.length + " assistant tests passed");
  process.exitCode = pass === results.length ? 0 : 1;
}, 50);

/* Tests for saved runs, persistence, import/export and CSV (js/runs.js).
   Run with:  node tests/runs.test.js   (uses an in-memory store in place of localStorage) */
"use strict";
var path = require("path");
var AERIS_TWIN = require(path.join(__dirname, "..", "js", "core.js"));
global.AERIS_TWIN = AERIS_TWIN;
var RUNS = require(path.join(__dirname, "..", "js", "runs.js"));
var results = [], current = null;
function test(name, fn) { current = { name: name, ok: true, msgs: [] }; try { RUNS.useStorage(RUNS.memoryStore(), false); fn(); } catch (e) { current.ok = false; current.msgs.push("threw: " + (e && e.stack || e)); } results.push(current); }
function check(c, m) { if (!c) { current.ok = false; current.msgs.push(m); } }
function cfg(o) { var c = AERIS_TWIN.defaultConfig(o.mode || "edge"); Object.keys(o).forEach(function (k) { c[k] = o[k]; }); return c; }
function mkRun(o) { return RUNS.fromSimulation(AERIS_TWIN.simulate(cfg(o || {}))); }
function J(x) { return JSON.stringify(x); }

test("A simulation becomes a self-contained, valid record", function () {
  var r = mkRun({ controller: { type: "pid" }, comOffset_m: 0.003, initial: { tilt_deg: 0, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, duration_s: 4 });
  var v = RUNS.validateRecord(r);
  check(v.ok, "valid: " + v.errors.join(" | "));
  ["config", "derived", "design", "samples", "metrics", "definitions", "outcome", "software", "created", "id", "provenance"].forEach(function (k) { check(r[k] != null, "record has " + k); });
  check(r.config.params.fs === 500 && r.config.seed === 7 && r.samples.rate_hz === 50, "time step, seed and rates are stored");
  check(r.outcome.code === "drifting", "regression outcome carried into the record");
  check(/nominal/.test(r.provenance), "provenance says nominal simulation");
  check(r.derived.parts.length === 1 && Math.abs(r.derived.M - 1.8) < 1e-12, "mass properties summary");
});
test("Persistence: save → list → load returns the identical record", function () {
  var r = mkRun({ duration_s: 3 }), s = RUNS.save(r);
  check(s.ok, "saved");
  check(RUNS.list().length === 1 && RUNS.list()[0].id === r.id, "listed");
  var l = RUNS.load(r.id);
  check(l.ok && J(l.record) === J(r), "loaded record identical");
});
test("Persistence: a reload (new module state, same storage) still finds the runs", function () {
  var mem = RUNS.memoryStore(); RUNS.useStorage(mem, true);
  var r = mkRun({ duration_s: 2 }); RUNS.save(r);
  delete require.cache[require.resolve(path.join(__dirname, "..", "js", "runs.js"))];
  var RUNS2 = require(path.join(__dirname, "..", "js", "runs.js")); RUNS2.useStorage(mem, true);
  check(RUNS2.list().length === 1 && RUNS2.load(r.id).ok, "run survives a module reload");
});
test("Old runs are independent of later runs and of the setup", function () {
  var a = mkRun({ duration_s: 2 }), c = cfg({ duration_s: 2, attachments: [{ id: "m1", label: "Brass", mass_kg: 0.05, pos_m: [0.09, 0.18, 0.18] }] });
  RUNS.save(a); var aText = J(RUNS.load(a.id).record);
  var b = RUNS.fromSimulation(AERIS_TWIN.simulate(c)); RUNS.save(b);
  c.params.m = 5; c.attachments[0].mass_kg = 2;           // edit the 'setup' after running
  var a2 = RUNS.load(a.id).record, b2 = RUNS.load(b.id).record;
  check(J(a2) === aText, "run A unchanged after saving run B");
  check(Math.abs(b2.derived.M - 1.85) < 1e-12 && b2.config.params.m === 1.8, "run B keeps its own snapshot (M = 1.85 kg)");
});
test("JSON export → import round trip (single run and bundle)", function () {
  var a = mkRun({ duration_s: 2 }), b = mkRun({ mode: "corner", duration_s: 2 });
  var one = RUNS.parseImport(RUNS.exportJSON(a));
  check(one.errors.length === 0 && one.runs.length === 1, "single import: " + one.errors.join(" | "));
  check(J(one.runs[0].samples) === J(a.samples) && J(one.runs[0].config) === J(a.config) && J(one.runs[0].metrics) === J(a.metrics), "single run identical");
  var both = RUNS.parseImport(RUNS.exportJSON([a, b]));
  check(both.errors.length === 0 && both.runs.length === 2, "bundle import");
  check(both.runs[1].config.mode === "corner", "corner run preserved");
});
test("Import: helpful errors for broken files", function () {
  var a = mkRun({ duration_s: 2 });
  function errs(obj) { return RUNS.parseImport(typeof obj === "string" ? obj : J(obj)).errors.join(" | "); }
  check(/not valid JSON/.test(errs("{ nope")), "invalid JSON");
  check(/Unsupported record schema/.test(errs({ schema: "something/9" })), "schema");
  var m = JSON.parse(J(a)); delete m.samples.cols.omega_x; check(/Missing sample column 'omega_x'/.test(errs(m)), "missing column");
  m = JSON.parse(J(a)); m.samples.cols.theta[3] = null; check(/row 3 is not a finite number/.test(errs(m)), "non-finite value");
  m = JSON.parse(J(a)); m.samples.cols.t[5] = m.samples.cols.t[4]; check(/must increase/.test(errs(m)), "time order");
  m = JSON.parse(J(a)); m.config.params.Jw = 0.05; check(/config\.params\.Jw/.test(errs(m)), "invalid physics in config");
  m = JSON.parse(J(a)); m.samples.cols.e.pop(); check(/has \d+ rows; column 't' has/.test(errs(m)), "ragged columns");
  check(/empty/.test(errs("  ")), "empty file");
});
test("Import: incomplete derived data is rebuilt from the saved setup; broken metrics are rejected", function () {
  var a = mkRun({ duration_s: 2, attachments: [{ id: "m1", label: "Clip", mass_kg: 0.04, pos_m: [0.09, 0.05, 0.18] }] });
  var m = JSON.parse(J(a)); m.derived = { M: 1 }; delete m.design.plant; m.definitions = {};
  var out = RUNS.parseImport(J(m));
  check(out.errors.length === 0 && out.runs.length === 1, "import ok: " + out.errors.join(" | "));
  var r = out.runs[0];
  check(Math.abs(r.derived.M - 1.84) < 1e-12 && r.derived.motor && r.design.plant && r.definitions.assessment.settleTolDeg === AERIS_TWIN.ASSESS.settleTolDeg, "rebuilt from config");
  var b = JSON.parse(J(a)); delete b.metrics.peakOmega_rpm; b.metrics.settle_s = "soon";
  var e = RUNS.parseImport(J(b)).errors.join(" | ");
  check(/peakOmega_rpm/.test(e) && /settle_s/.test(e), e);
});
test("Import: a configuration file loads as a setup, not a run", function () {
  var c = cfg({ controller: { type: "adp" }, duration_s: 6 });
  var out = RUNS.parseImport(RUNS.exportConfig(c));
  check(out.errors.length === 0 && out.configs.length === 1 && out.runs.length === 0, "config imported");
  check(out.configs[0].controller.type === "adp" && out.configs[0].duration_s === 6, "values kept");
});
test("Import: duplicates are skipped, changed copies get a new id", function () {
  var a = mkRun({ duration_s: 2 }); RUNS.save(a);
  var r1 = RUNS.importRuns(RUNS.parseImport(RUNS.exportJSON(a)).runs);
  check(r1.skipped.length === 1 && r1.added.length === 0, "identical copy skipped");
  var m = JSON.parse(J(a)); m.samples.cols.theta[1] = 0.0123;
  var r2 = RUNS.importRuns(RUNS.parseImport(J(m)).runs);
  check(r2.added.length === 1 && r2.added[0].id !== a.id && /imported/.test(r2.added[0].name), "changed copy gets a new id");
  check(RUNS.list().length === 2, "two recordings stored");
});
test("CSV export: metadata header, units in column names, one row per sample", function () {
  var a = mkRun({ duration_s: 2 }), csv = RUNS.toCSV(a).trim().split("\n");
  var header = csv.filter(function (l) { return l.charAt(0) === "#"; }), body = csv.filter(function (l) { return l.charAt(0) !== "#"; });
  check(/nominal/.test(header.join(" ")), "provenance in header");
  check(body[0].indexOf("t [s]") === 0 && /omega_x \[rad\/s\]/.test(body[0]), "unit-labelled columns");
  check(body.length - 1 === a.samples.cols.t.length, "row count");
  check(body[1].split(",").length === Object.keys(a.samples.cols).length, "column count");
});
test("Clear all removes every saved run", function () {
  RUNS.save(mkRun({ duration_s: 1.5 })); RUNS.save(mkRun({ duration_s: 1.5 }));
  check(RUNS.list().length === 2, "two saved");
  RUNS.clearAll();
  check(RUNS.list().length === 0, "none left");
});
test("Storage full: save reports a clear error and does not leave a half-written run", function () {
  var mem = RUNS.memoryStore(), real = mem.setItem;
  mem.setItem = function (k, v) { if (String(v).length > 5000) { var e = new Error("full"); e.name = "QuotaExceededError"; throw e; } real.call(mem, k, v); };
  RUNS.useStorage(mem, true);
  var s = RUNS.save(mkRun({ duration_s: 2 }));
  check(!s.ok && s.quota && /storage is full/.test(s.error), "quota error message");
  check(RUNS.list().length === 0, "nothing listed");
});
test("Reproducibility: re-running a saved configuration gives identical samples", function () {
  var a = mkRun({ controller: { type: "adp" }, estimator: { type: "kf" }, duration_s: 3, seed: 3 });
  var rp = RUNS.reproduce(JSON.parse(J(a)));
  check(rp.ok && rp.identical && rp.maxRelDiff === 0, "identical: " + J(rp));
});
test("Invalid configurations never become recordings", function () {
  var p = AERIS_TWIN.clone(AERIS_TWIN.NOMINAL); p.a = 0.08; p.m = 0.3; p.kJ = 0.1; p.Jw = 0.005;
  var rec = RUNS.fromSimulation(AERIS_TWIN.simulate(cfg({ params: p })));
  check(rec.samples === null && rec.outcome.code === "invalid", "no samples");
  check(!RUNS.validateRecord(rec).ok, "an invalid record does not validate for import");
});

var pass = results.filter(function (r) { return r.ok; }).length;
results.forEach(function (r) { console.log((r.ok ? "PASS " : "FAIL ") + r.name); r.msgs.forEach(function (m) { console.log("     " + m); }); });
console.log("\n" + pass + " / " + results.length + " run-record tests passed");
process.exitCode = pass === results.length ? 0 : 1;

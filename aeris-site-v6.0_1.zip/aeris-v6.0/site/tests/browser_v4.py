"""Browser end-to-end checks for v4: the real site (served over HTTP) in SIMULATION mode against the
RUNNING Python research backend, then DEMO mode after the backend is stopped.

Run:   python3 tests/browser_v4.py            (starts the backend and a static server itself)
       python3 tests/browser_v4.py --shots    (also writes screenshots to tests/screenshots/)

Python for the backend: $AERIS_PYTHON, else backend/.venv/bin/python, else ../.venv/bin/python, else this
interpreter. If the backend cannot be started every check is reported as NOT RUN (exit code 2).

Covers: connection state (configured vs reachable, Check backend), SIMULATION mode, research options in
the setup form, a backend run with a nonlinear controller and MEKF, the replay (seek, play, telemetry,
Maths panel naming the executed method), saving and reloading, reproduction on the backend, a sweep
with paired seeds and research criteria, cancelling a sweep (PARTIAL), and DEMO mode afterwards.
"""
import asyncio, json, os, sys, pathlib, subprocess, tempfile, time, socket, urllib.request
from playwright.async_api import async_playwright

SITE = pathlib.Path(__file__).resolve().parent.parent
BACKEND = SITE.parent / "backend"
SHOTS = "--shots" in sys.argv
SHOT_DIR = SITE / "tests" / "screenshots"
ARGS = ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"]
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else "  →  " + str(detail)[:500]), flush=True)


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def backend_python():
    for c in (os.environ.get("AERIS_PYTHON"), BACKEND / ".venv" / "bin" / "python", SITE.parent.parent / ".venv" / "bin" / "python"):
        if c and pathlib.Path(c).exists():
            return str(c)
    return sys.executable


def wait_http(url, timeout=40):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                return r.status == 200
        except Exception:
            time.sleep(0.25)
    return False


async def shot(page, name):
    if SHOTS:
        SHOT_DIR.mkdir(parents=True, exist_ok=True)
        await page.screenshot(path=str(SHOT_DIR / (name + ".png")))


async def wait_for(page, js, timeout=30000, step=200):
    t = 0
    while t < timeout:
        if await page.evaluate(js):
            return True
        await page.wait_for_timeout(step); t += step
    return False


async def main():
    bport, sport = free_port(), free_port()
    base, origin = f"http://127.0.0.1:{bport}", f"http://127.0.0.1:{sport}"
    db = pathlib.Path(tempfile.mkdtemp(prefix="aeris-e2e-")) / "e2e.sqlite3"
    py = backend_python()
    be = subprocess.Popen([py, "-m", "aeris_backend.api.main", "--port", str(bport), "--db", str(db), "--workers", "2", "--cors", origin, "--log-level", "warning"],
                          cwd=str(BACKEND), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    web = subprocess.Popen([sys.executable, "-m", "http.server", str(sport), "--bind", "127.0.0.1", "--directory", str(SITE)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        if not wait_http(base + "/api/v1/health"):
            err = be.stderr.read().decode()[-600:] if be.poll() is not None else "no answer"
            print("NOT RUN: the research backend could not be started with " + py + ": " + err)
            print("\n0 / 0 v4 browser checks run (not run)")
            return 2
        wait_http(origin + "/index.html")
        cfg = json.dumps({"researchApi": {"baseUrl": base, "wsUrl": base.replace("http", "ws"), "pollMs": 300, "probeMs": 60000, "mock": False}})
        async with async_playwright() as p:
            br = await p.chromium.launch(args=ARGS)
            ctx = await br.new_context(viewport={"width": 1440, "height": 900})
            await ctx.add_init_script("window.AERIS_CONFIG = " + cfg + ";")
            page = await ctx.new_page()
            errors = []
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
            page.on("pageerror", lambda e: errors.append("PAGEERROR " + str(e)))
            await page.goto(origin + "/index.html#lab", wait_until="load")
            await page.wait_for_timeout(1500)

            # ---------------- connection state ----------------
            ok = await wait_for(page, "(document.getElementById('wmBackend')||{}).textContent && /reachable/.test(document.getElementById('wmBackend').textContent) && !/not reachable/.test(document.getElementById('wmBackend').textContent)", 15000)
            line = await page.evaluate("(document.getElementById('wmBackend')||{}).textContent")
            check("Backend line: configured URL and REACHABLE after the probe", ok and base in line, line)
            sim_enabled = await page.evaluate("document.querySelector('.wm-b[data-mode=\"simulation\"]').getAttribute('aria-disabled') !== 'true'")
            check("SIMULATION button enabled only after the backend answered", sim_enabled)
            await page.click('.wm-b[data-mode="simulation"]'); await page.wait_for_timeout(400)
            st = await page.evaluate("Object.fromEntries(AERIS_STATUS.snapshot().map(x => [x.key, x.value]))")
            # v5: the engine version shown is the one the running backend REPORTED (1.1.0 in v5), not a constant in the test
            ev = await page.evaluate("(/(\\d+\\.\\d+\\.\\d+)/.exec(AERIS_SERVICE.capabilities().engine_version) || [])[1]")
            check("Status strip: SIMULATION · research engine (reported version) · NOMINAL", ev and st.get("system") == "SIMULATION" and ("Research engine " + ev) in st.get("model", "") and "NOMINAL" in st.get("model", "").upper(), (ev, st))
            ov = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            check("No horizontal overflow with the backend status line shown", ov <= 1, ov)
            await shot(page, "v4-01-simulation-mode")

            # ---------------- research setup and a backend run ----------------
            setup = "(()=>{const c=AERIS_TWIN.defaultConfig('corner'); c.controller.type='nlpd'; c.estimator={type:'mekf'}; c.initial.tilt_deg=2; c.initial.rate_dps=5; c.duration_s=4; c.seed=21; c.recovery={attitude_error_deg:1,rate_dps:3,hold_s:0.5,max_time_s:null,yaw_objective:'free'}; return c})()"
            await page.evaluate("Workspace.openConfig(" + setup + ", {})"); await page.wait_for_timeout(500)
            form = await page.evaluate("({ctl: document.getElementById('f_controller_type').value, opts: [...document.getElementById('f_controller_type').options].map(o=>o.value), est: (document.getElementById('f_estimator_type')||{}).value, research: !!document.getElementById('grpResearch'), hold: (document.getElementById('f_recovery_hold_s')||{}).value, val: document.getElementById('valBox').innerText})")
            check("Setup form offers the research controller and estimator and keeps the recovery criteria", form["ctl"] == "nlpd" and "nlpd" in form["opts"] and form["est"] == "mekf" and form["research"] and form["hold"] == "0.5", form)
            await page.click("#btnRun")
            ok = await wait_for(page, "AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.origin && AERIS_DEBUG.W.run.origin.engine === 'aeris-research-backend'", 40000)
            rec = await page.evaluate("(()=>{const r=AERIS_DEBUG.W.run; return r ? {id:r.id, xid:r.experiment_id, ctl:r.executed.controller.type, st:r.executed.controller.structure, est:r.executed.estimator.type, rc:r.research.recovery.criteria, src:r.source} : null})()")
            check("Backend run opened: AERIS-EXP-1xxxxx, nonlinear controller + MEKF executed, criteria saved", ok and rec and rec["xid"].startswith("AERIS-EXP-1") and rec["ctl"] == "nlpd" and rec["st"] == "nonlinear-full-tensor" and rec["est"] == "mekf" and rec["rc"]["hold_s"] == 0.5, rec)
            res = await page.evaluate("document.getElementById('rp-res').innerText")
            rl = res.lower()
            check("Results panel: research metrics, research recovery and executed method shown", "research metrics" in rl and ("research recovery at t" in rl or "research recovery criteria not met" in rl) and "nonlinear model-compensated quaternion pd" in rl, res[-900:])
            tag = await page.evaluate("document.getElementById('vwTag').innerText")
            check("3-D view labels the run (SIMULATION, backend experiment id)", rec and rec["xid"] in tag, tag)
            await shot(page, "v4-02-backend-run")

            # ---------------- replay ----------------
            await page.evaluate("AERIS_DEBUG.seekTime(1.0)"); await page.wait_for_timeout(300)
            s1 = await page.evaluate("AERIS_DEBUG.snapshot()")
            check("Replay: seeking to t = 1 s moves the view and telemetry", s1["idx"] > 0 and abs(s1["t"] - 1.0) < 0.06 and s1["teleT"], {k: s1.get(k) for k in ("idx", "t", "teleT")})
            await page.click("#pbPlay")
            await wait_for(page, "AERIS_DEBUG.snapshot().t > %r" % s1["t"], 15000)       # bounded wait on the condition, not a fixed pause
            s2 = await page.evaluate("AERIS_DEBUG.snapshot()"); await page.click("#pbPlay")
            check("Replay: playback advances the time", s2["t"] > s1["t"], [s1["t"], s2["t"]])
            await page.click("#rt-math"); await page.wait_for_timeout(700)
            mx = await page.evaluate("({txt: document.getElementById('rp-math').innerText, err: document.querySelectorAll('#rp-math .tex-err').length})")
            check("Maths panel: computed by the research backend, names the nonlinear PD, all equations render", "Computed by the research backend" in mx["txt"] and "nonlinear model-compensated PD" in mx["txt"] and mx["err"] == 0, {"err": mx["err"], "txt": mx["txt"][:300]})
            await shot(page, "v4-03-maths-panel")

            # ---------------- saved, reloaded ----------------
            before = await page.evaluate("(()=>{const r=AERIS_DEBUG.W.run; return JSON.stringify([r.derived, r.design, r.research, r.executed, r.reproduction])})()")
            await page.reload(wait_until="load"); await page.wait_for_timeout(1500)
            after = await page.evaluate("(()=>{const l=AERIS_RUNS.load(%s); return l.ok ? JSON.stringify([l.record.derived, l.record.design, l.record.research, l.record.executed, l.record.reproduction]) : 'missing: ' + l.error})()" % json.dumps(rec["id"]))
            check("Saved in the browser; after a reload the backend metadata is unchanged", before == after, after[:200])
            await wait_for(page, "AERIS_SERVICE.modeInfo('simulation').available", 15000)
            await page.evaluate("AERIS_SERVICE.setMode('simulation')")
            await page.evaluate("Workspace.openRun(AERIS_RUNS.load(%s).record, {})" % json.dumps(rec["id"])); await page.wait_for_timeout(600)

            # ---------------- reproduction on the backend ----------------
            await page.click("#rt-res"); await page.wait_for_timeout(200)
            await page.click('#rp-res [data-a="repro"]')
            ok = await wait_for(page, "/reproduced every saved sample exactly|differ|could not/.test(document.getElementById('reproOut').innerText)", 40000)
            ro = await page.evaluate("document.getElementById('reproOut').innerText")
            check("Reproduce: the research backend re-runs the saved setup and reproduces every sample exactly", ok and "reproduced every saved sample exactly" in ro, ro)

            # ---------------- sweep on the backend ----------------
            await page.click("#wk-sweep"); await page.wait_for_timeout(1500)
            ctls = await page.evaluate("[...document.querySelectorAll('[data-ctl]')].map(b => b.getAttribute('data-ctl'))")
            check("Sweep controllers come from the backend's capabilities (incl. nlpd and lqr-mimo)", "nlpd" in ctls and "lqr-mimo" in ctls, ctls)
            await page.click('[data-preset="doa"]'); await page.wait_for_timeout(300)
            await page.select_option("#swSeedStr", "paired"); await page.wait_for_timeout(300)
            val = await page.evaluate("document.getElementById('swVal').innerText")
            check("Sweep validated against the backend (147 runs, backend engine and limits)", "147 runs" in val and "research backend" in val.lower(), val)
            await page.click("#swRun")
            ok = await wait_for(page, "!!(AERIS_SWEEP_UI._state.result && AERIS_SWEEP_UI._state.result.rows && AERIS_SWEEP_UI._state.job && AERIS_SWEEP_UI._state.job.state === 'complete')", 120000)
            sw = await page.evaluate("(()=>{const r=AERIS_SWEEP_UI._state.result; return r ? {id:r.id, n:r.rows.length, engine:r.engine && r.engine.engine, paired:!!(r.analysis && r.analysis.paired && r.analysis.paired.length), ss: r.definition.seed_strategy} : null})()")
            out = await page.evaluate("document.getElementById('swOut').innerText")
            check("Sweep ran on the backend: 147 rows, backend sweep id, paired seeds", ok and sw and sw["n"] == 147 and sw["id"].startswith("AERIS-SWP-1") and sw["engine"] == "aeris-research-backend" and sw["ss"] == "paired" and sw["paired"], sw)
            low = out.lower()   # innerText follows CSS text-transform (table heads are upper case)
            check("Sweep results show research criteria, the paired comparison and say what they are", "research criteria met" in low and "paired comparison" in low and "mcnemar" in low and "research backend" in low and "not hardware reliability" in low, out[:600])
            ov = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            check("No horizontal overflow on the sweep results", ov <= 1, ov)
            strip = await page.evaluate("""(()=>{const b=document.getElementById('sysbar'), br=b.getBoundingClientRect();
                const vs=[...b.querySelectorAll('.sb-i')].filter(e=>getComputedStyle(e).display!=='none'), last=vs[vs.length-1];
                const lr=last.querySelector('.sb-v').getBoundingClientRect();
                return {fits: lr.right <= br.right + 0.5, last: last.dataset.k, titled: vs.every(e=>e.title.indexOf(': ')>0), text: b.textContent}})()""")
            check("Status strip with long SIMULATION values: the validation label stays fully visible; full values in the item titles",
                  strip["fits"] and strip["last"] == "validation" and strip["titled"] and "SIM ↔ HW PENDING" in strip["text"], strip)
            await shot(page, "v4-04-backend-sweep")
            row_open = await page.evaluate("(async()=>{const api=AERIS_SERVICE.adapter('research-api'); const r=AERIS_SWEEP_UI._state.result.rows[10]; const full=await api.getSweepRow(AERIS_SWEEP_UI._state.result.id, r.index); return full.config_hash===r.config_hash && full.config.initial.tilt_deg===r.values.tilt_deg})()")
            check("A sweep row's exact saved configuration is retrievable from the backend", row_open)

            # ---------------- cancel a running sweep ----------------
            await page.evaluate("(()=>{const S=AERIS_SWEEP_UI._state; S.def.samples=3000; S.def.mode='random'; S.def.duration_s=6;})()")
            await page.click('input[name="swMode"][value="random"]'); await page.wait_for_timeout(300)
            await page.fill("#swN", "3000"); await page.wait_for_timeout(400)
            await page.click("#swRun")
            await wait_for(page, "AERIS_SWEEP_UI._state.job && AERIS_SWEEP_UI._state.job.state === 'running' && AERIS_SWEEP_UI._state.job.progress.done >= 10", 60000)
            await page.click("#swCancel")
            ok = await wait_for(page, "AERIS_SWEEP_UI._state.job && AERIS_SWEEP_UI._state.job.state === 'cancelled' && !!AERIS_SWEEP_UI._state.result", 60000)
            part = await page.evaluate("(()=>{const r=AERIS_SWEEP_UI._state.result; return r ? {partial:r.partial, n:r.rows.length} : null})()")
            out2 = await page.evaluate("document.getElementById('swOut').innerText")
            check("Cancelling a running backend sweep keeps the finished runs, labelled PARTIAL", ok and part and part["partial"] and 10 <= part["n"] < 9000 and "PARTIAL sweep" in out2, [part, out2[:300]])
            await shot(page, "v4-05-cancelled-sweep")

            # ---------------- backend gone: DEMO still works ----------------
            be.terminate(); be.wait(timeout=20)
            await page.click("#wk-single"); await page.wait_for_timeout(400)
            await page.click('#wsModes [data-probe]')
            ok = await wait_for(page, "/not reachable/.test((document.getElementById('wmBackend')||{}).textContent)", 20000)
            dis = await page.evaluate("document.querySelector('.wm-b[data-mode=\"simulation\"]').getAttribute('aria-disabled')")
            check("Backend stopped: Check backend reports NOT REACHABLE and SIMULATION is disabled", ok and dis == "true", dis)
            await page.click('.wm-b[data-mode="demo"]'); await page.wait_for_timeout(300)
            await page.evaluate("Workspace.openConfig((()=>{const c=AERIS_TWIN.defaultConfig('edge'); c.duration_s=3; return c})(), {run:true})")
            ok = await wait_for(page, "AERIS_DEBUG.W.run && AERIS_DEBUG.W.run.origin.engine === 'aeris-twin-js'", 20000)
            check("DEMO mode runs on the browser engine without the backend", ok)
            check("No script errors during the session", not [e for e in errors if "Failed to load resource" not in e and "ERR_CONNECTION_REFUSED" not in e], errors[:5])
            await br.close()
    finally:
        for proc in (be, web):
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=10)
                except Exception:
                    proc.kill()
    n = sum(1 for r in results if r[1])
    print(f"\n{n} / {len(results)} v4 browser checks passed")
    return 0 if n == len(results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))

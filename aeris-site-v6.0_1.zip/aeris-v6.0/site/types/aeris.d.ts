/* AERIS · type declarations for the platform's data and module interfaces.
   The site runs as plain JavaScript (no build step); these declarations document
   the shapes for editors, for a future TypeScript migration and for the Python
   backend team. The JSON Schemas in /schemas are the normative definition of the
   file formats; keep the two in step (tests/schema.test.js checks the schemas). */

export type Mode = "edge" | "corner";
export type SystemMode = "demo" | "simulation" | "hardware";
export type ControllerType = "pid" | "lqr" | "adp" | "nlpd" | "none";   // adp = COM-adaptive LQR; nlpd = nonlinear quaternion PD (research backend)
export type EstimatorType = "ideal" | "cf" | "kf" | "accel" | "gyro" | "cf3d" | "mekf";   // cf3d, mekf: research backend
export type OutcomeCode = "recovered" | "not_settled" | "drifting" | "fallen" | "invalid";
export type ValidationStatus = "nominal" | "measured" | "validated";
export type SourceKind = "simulation" | "hardware";
export type DisplaySource = SourceKind | "replay";
export type ExperimentId = `AERIS-EXP-${string}`;   // six digits
export type SweepId = `AERIS-SWP-${string}`;
type Vec3 = [number, number, number];

export interface Params { a: number; m: number; kJ: number; Jw: number; g: number; KV: number; R: number; Vs: number; Imax: number; wmaxRpm: number; cv: number; cc: number; fs: number; rImu: number; }
export interface SensorSettings { gyro_noise_dps: number; gyro_bias_dps: number; gyro_bias_walk_dps: number; accel_noise_mps2: number; gyro_quant_dps: number; accel_quant_deg: number; latency_ms: number; dropout: number; rate_hz: number | null; }
export interface ActuatorSettings { motor_lag_ms: number; wheel_health: { x: number; y: number; z: number }; electrical_limit?: "command" | "continuous"; }
type Mat3 = [Vec3, Vec3, Vec3];
/* revision 1.1 disturbances and events (research backend; docs/SCHEMA_EXTENSIONS.md) */
export interface ImpulseLoad { id: string; type: "impulse"; magnitude_Nms: number; direction: Vec3; frame: "world" | "body"; t_s: number; }
export interface ForceImpulseLoad { id: string; type: "force_impulse"; impulse_Ns: number; point_m: Vec3; direction: Vec3; frame: "world" | "body"; t_s: number; }
export interface BiasLoad { id: string; type: "bias"; magnitude_Nm: number; direction: Vec3; frame: "world" | "body"; t_start_s: number; duration_s: number | null; }
export interface WheelEvent { id: string; type: "wheel_failure" | "wheel_degradation" | "wheel_torque_limit" | "wheel_speed_limit"; wheel: string; t_s: number; duration_s?: number | null; health?: number; limit_Nm?: number; limit_rpm?: number; }
export interface WheelSpec { id: string; axis: Vec3; Jw: number; KV: number; R: number; Vs: number; Imax: number; wmaxRpm: number; cv: number; cc: number; health: number; }
export interface RecoveryCriteria { attitude_error_deg: number; rate_dps: number; hold_s: number; max_time_s: number | null; yaw_objective: "hold" | "free"; }
export interface TerminationRules { stop_on_recovery: boolean; post_fall_s: number; check_lift_off: boolean; overspeed_rpm: number | null; max_quaternion_drift: number; }
export interface ForceLoad { id: string; type: "force"; magnitude_N: number; point_m: Vec3; direction: Vec3; frame: "world" | "body"; t_start_s: number; duration_s: number; }
export interface TorqueLoad { id: string; type: "torque"; magnitude_Nm: number; direction: Vec3; frame: "world" | "body"; t_start_s: number; duration_s: number; }

/** aeris-config/1 (revision 1.0 fields; revision 1.1 adds the optional research blocks, all preserved by AERIS_CFG.normalize) */
export interface ExperimentConfig {
  schema: "aeris-config/1"; config_revision?: "1.0" | "1.1"; mode: Mode; params: Params;
  comOffset_m: number; comShift_m: Vec3;
  attachments: { id: string; label: string; mass_kg: number; pos_m: Vec3 }[];
  controller: { type: ControllerType; knowsAttachments: boolean; reconfigureOnFailure: boolean; structure: "decoupled" | "mimo-lqr";
    pid?: { integrator_pole: number; yaw_integrator_pole: number; anti_windup: "clamp" | "conditional" }; lqr?: Record<string, number>; adaptive?: { gamma: number; clamp_deg: number };
    nonlinear?: { omega_n: number; zeta: number; yaw_omega_n: number; yaw_zeta: number; momentum_omega: number; max_ref_tilt_deg: number; compensate_gravity: boolean; compensate_gyroscopic: boolean; compensate_friction: boolean };
    allocation?: { method: "clip" | "bounded-ls" } };
  estimator: { type: EstimatorType; Rkf_deg?: number; mekf?: Record<string, number | boolean | null>; cf3d?: Record<string, number | boolean> };
  seed: number; sensor: SensorSettings & { imu_position_m?: Vec3 | null; accel_dynamic?: boolean; accel_bias_mps2?: Vec3 }; actuator: ActuatorSettings;
  initial: { tilt_deg: number; rate_dps: number; azimuth_deg: number; reference: "geometric" | "balance"; wheel_speeds_rpm?: number[] };
  disturbances: (ForceLoad | TorqueLoad | ImpulseLoad | ForceImpulseLoad | BiasLoad)[];
  events: WheelEvent[];
  commands: { id: string; type: "yaw_step"; t_s: number; angle_deg: number }[];
  uncertainty: { inertiaScale: number; inertia_perturbation_kgm2?: Mat3 }; torqueScale: number; duration_s: number; record_hz: number;
  solver?: { method: "rk4"; integration_hz: number | null };
  plant?: { base_inertia_kgm2: Mat3 | null; base_com_m: Vec3 | null; components: { id: string; label?: string; mass_kg: number; com_m: Vec3; inertia_kgm2?: Mat3 | null }[] };
  wheels?: WheelSpec[] | null; recovery?: RecoveryCriteria; termination?: TerminationRules;
}

export interface TimelineEvent { t: number; t_end?: number; type: string; severity: "info" | "stable" | "warning" | "failure"; source: "input" | "detected"; wheel?: string | null; ref?: string; label: string; detail?: string; }
export interface Timeline { rules: object; resolution_s: number | null; events: TimelineEvent[]; rebuilt?: boolean; }

/** aeris-run/1, revision 1.1 (browser) / 1.2 (research backend) */
export interface RunRecord {
  schema: "aeris-run/1"; schema_revision: "1.0" | "1.1" | "1.2";
  id: string; experiment_id: ExperimentId; original_experiment_id?: ExperimentId;
  name: string; created: string; note?: string;
  source: SourceKind; collection: "user" | "example" | "imported" | "reference";
  origin: { kind: SourceKind; engine: string; engine_version: string | null; adapter: string; mode: SystemMode };
  validation: { status: ValidationStatus; parameter_set: string; note?: string };
  group: { id: string; kind: "controller-set"; controllers: ControllerType[]; varied: string; label?: string } | null;
  config: ExperimentConfig; software: { site: string; model: string; solver: string };
  derived: object | null; design: object | null;
  samples: { rate_hz: number; fs: number; convention: string; cols: Record<string, number[]>; units: Record<string, string> };
  metrics: Record<string, unknown>; definitions: { metrics: Record<string, string>; assessment: Record<string, number>; events?: Record<string, string> };
  outcome: { code: OutcomeCode; label: string; reason: string; notes?: string[] };
  events: object; timeline: Timeline | null; warnings: { path: string; message: string }[]; provenance: string;
  /* revision 1.2 (research backend): kept exactly as the backend wrote them; the browser never rebuilds them */
  research?: { recovery: { criteria: RecoveryCriteria; objective: string; objective_effective: string; objective_note: string | null; recovered: boolean; t_s: number | null } & Record<string, unknown> } & Record<string, unknown>;
  termination?: { reason: "duration" | "recovery" | "loss_of_support" | "fall" | "invalid_state" | "numerical_failure" | "safety_limit" | "cancelled" | "invalid_config"; t: number | null; detail: string };
  executed?: { controller: { type: ControllerType; structure: "decoupled" | "mimo-lqr" | "nonlinear-full-tensor" | "none"; law: string; name: string; gains?: Record<string, number | null> } & Record<string, unknown>;
    estimator: { type: EstimatorType; name: string; truth_access: boolean }; allocation: object; rates: { integration_hz: number; control_hz: number; sensor_hz: number; record_hz: number }; solver: object; schedule: object; impulses_applied: object[] };
  reproduction?: { config_hash: string; seed: number; seed_strategy: object; software: Record<string, string>; parameter_set: { id: string; status: string; applied?: string[]; missing?: string[]; replaced?: object[] }; solver: object; rates: object; determinism: string;
    reproduces?: { of_run: string; of_experiment: string | null; identical: boolean; same_outcome: boolean; max_abs_diff: number; rows: [number, number]; same_config_hash: boolean; same_software: boolean } };
}

/** aeris-job/1 */
export type JobState = "queued" | "initializing" | "running" | "analyzing" | "complete" | "failed" | "cancelled";
export interface Job {
  schema: "aeris-job/1"; id: string; kind: "single" | "sweep" | "controller-set"; state: JobState;
  created: string; updated: string; started: string | null; finished: string | null;
  progress: { done: number; total: number; failed: number; fraction: number };
  adapter: string | null; mode: SystemMode | null; demo: boolean; mock: boolean; message: string;
  error: { code: string; message: string; details?: unknown[]; retryable?: boolean } | null;
  result_ref?: { kind: "run" | "sweep" | "dataset"; id: string } | null;
}

/** aeris-sweep/1 */
export type SweepVariableKey = "com_x_mm" | "com_y_mm" | "com_z_mm" | "tilt_deg" | "rate_dps" | "torque_pct" | "rpm_limit" | "disturbance_N" | "noise_scale" | "inertia_scale";
export type SweepController = "pid" | "lqr" | "adp" | "nlpd" | "lqr-mimo" | "none";   // nlpd, lqr-mimo, none: research backend
export interface SweepDefinition {
  schema: "aeris-sweep/1"; revision?: "1.0" | "1.1"; id: SweepId | null; name: string; created: string | null;
  base: ExperimentConfig; mode: "grid" | "random" | "montecarlo"; seed: number; samples: number;
  controllers: SweepController[]; mass_configs: ("base" | "none" | "top50" | "face100" | "asym2x60")[];
  variables: { key: SweepVariableKey | null; path?: string; label?: string; unit?: string; min: number; max: number; steps?: number; dist?: "uniform" | "normal" | "bounded-normal" | "categorical"; mean?: number | null; sd?: number | null; values?: number[]; probabilities?: number[] }[];
  disturbance: object | null; duration_s: number; record_hz: number;
  seed_strategy?: "paired" | "legacy" | "fixed" | "independent"; estimators?: EstimatorType[] | null; store_runs?: boolean; limits?: object; parameter_set?: string;
}
export interface SweepRow { index: number; point: number; controller: SweepController; mass_config: string; estimator?: EstimatorType | null; values: Record<string, number>; seed: number; config_hash?: string; status?: "ok" | "invalid" | "failed"; outcome: OutcomeCode; saturated: boolean; metrics: Record<string, number | null> | null; research?: object | null; termination?: object | null; reason: string | null; run_id?: string | null; clipped?: { key: string; drawn: number }[]; }
export interface SweepResult { schema: "aeris-sweep/1"; id: SweepId; name: string; created: string; definition: SweepDefinition; engine: object; provenance: { source: "simulation"; demo: boolean; mock: boolean; note: string; validation?: object }; rows: SweepRow[]; partial: boolean; analysis: object | null; job: Job | null; }

/** aeris-dataset/1 */
export interface Dataset { schema: "aeris-dataset/1"; id: string; title: string; created: string; status: "exploratory" | "final"; mock: boolean; provenance: { source: "simulation" | "hardware" | "mixed"; engine: object | null; validation: object; demo: boolean; mock: boolean; note: string }; members: { kind: "run" | "sweep" | "hardware-run"; id: string; schema?: string; runs?: number; partial?: boolean }[]; runs?: RunRecord[]; sweeps?: SweepResult[]; }

/** aeris-hardware-run/1 — real recordings only */
export interface HardwareRun { schema: "aeris-hardware-run/1"; device: { id: string; firmware?: string; imu?: string; wheels?: string }; recording: { started: string; operator?: string; notes?: string }; mode: "edge" | "corner" | "free"; experiment_id?: ExperimentId; parameters?: { parameter_set: string }; samples: { rate_hz?: number; cols: Record<string, number[]>; units: Record<string, string> }; }

/** Data-source adapter (js/adapters/*.js) */
export interface Adapter {
  name: string; kind: string; label: string; mock?: boolean;
  available(): { ok: boolean; reason: string | null };
  capabilities(): object;
  runSingle?(cfg: ExperimentConfig, meta?: object): Promise<{ ok: true; record: RunRecord } | { ok: false; result: { outcome: RunRecord["outcome"]; errors: { path: string; message: string }[] } }>;
  submitSweep?(def: SweepDefinition, opts?: { mode?: SystemMode; sync?: boolean }): Job;
  cancelJob?(job: Job): Promise<Job>;
}
/** ResearchApiAdapter (js/adapters/research-api.js): configured ≠ reachable; only reported capabilities are used */
export interface ResearchApiAdapter extends Adapter {
  configured(): boolean;
  status(): { configured: boolean; reachable: boolean | null; lastProbe: string | null; error: { code: string; message: string } | null; health: object | null; capabilitiesReported: boolean };
  probe(): Promise<ReturnType<ResearchApiAdapter["status"]>>;
  validate(cfg: ExperimentConfig): Promise<{ ok: boolean; errors: object[]; warnings: object[]; config: ExperimentConfig; config_hash: string | null }>;
  reproduce(rec: RunRecord): Promise<{ ok: boolean; identical: boolean; sameOutcome?: boolean; maxAbsDiff?: number; record?: RunRecord; report?: object; engine?: string; message?: string }>;
  getRun(id: string): Promise<RunRecord>; getSweep(id: string): Promise<SweepResult>; getSweepRow(id: string, index: number): Promise<SweepRow & { config: ExperimentConfig }>;
}

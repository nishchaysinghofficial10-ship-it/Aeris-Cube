# AERIS · research-platform frontend (v6.0)

**AERIS**: Autonomous Experimental Reaction-wheel Inertial Stabilization. A static website with no server code: the physical cube (AERIS Cube), its physics-based digital model (AERIS Twin) and the research environment (AERIS Lab). Everything it needs, including three.js, KaTeX and the fonts, is in this folder, so it also works offline (DEMO mode, browser engine). The optional Python research backend (`../backend/`) adds SIMULATION mode and the read-only telemetry path behind HARDWARE mode. v6.0 adds two optional journeys, Build Your Own Cube and Connect My Cube; the virtual cube stays the default and needs neither.

## Open it

- **Quickest:** double-click `index.html` (Chrome, Edge, Firefox, Safari).
- **Local server** (keeps saved runs more reliably):
  ```
  python3 -m http.server 8000
  ```
  then open <http://localhost:8000>.
- **Hosting:** upload the folder to any static host.

## Pages

| Address | What it shows |
|---|---|
| `#top` (home) | Story (RWIP → AERIS Cube → AERIS Twin → AERIS Lab), example replay, standing experiments, evolution |
| `#cube` | AERIS Cube: subsystems, parameters with NOMINAL / MEASURED / VALIDATED status, hardware evidence |
| `#twin`, `#twin-…` | AERIS Twin: derivations, worked calculations, reference experiments AERIS-EXP-000001…7 |
| `#lab`, `#lab/replay`, `#lab/create`, `#lab/sweep`, `#lab/telemetry` | AERIS Lab: single experiments, controller sets, research sweeps, replay, compare; the Telemetry tab (live read-only telemetry through the backend, recordings, replay) |
| `#research` | Research question, hypotheses, variables, controllers, methodology, metrics, limitations, future work, evolution |
| `#results` | Findings (none until the final dataset exists), exploratory sweeps in this browser, earlier benchmark with provenance |
| `#validation` | SIM ↔ hardware: status, method, comparison tool for real recordings, recording format |
| `#build`, `#build-step-<id>` | Build Your Own Cube (v6.0, optional): kit revisions and readiness, the bill of materials with sources and check dates, downloads that exist (with SHA-256) and missing ones with the reason, sizing, guided steps, progress notes kept in this browser (never a qualification) |
| `#connect`, `#connect/<step>` | Connect My Cube (v6.0, optional): the synthetic device in the page, Web Serial, firmware installation, pairing, diagnostics, calibration, profile, configuration, experiment, record and compare; a device of your account on an AERIS backend (`docs/CONNECT.md`) |

Old links still work: `#use…` → `#lab…`, `#lab-…` → `#twin-…`, `#hardware` → `#cube`.

## Adding real evidence

Edit **`js/site-content.js`**. Nothing in it is invented; anything left empty shows as a clearly marked placeholder. See `docs/RESEARCH_PLATFORM.md` §10.

## Connecting the research backend

**Same origin (simplest):** from the repository root run `scripts/start.sh` (add `--emulator` for the synthetic
telemetry emulator) and open <http://127.0.0.1:8750/#lab>. The backend serves this folder itself
(`--serve-site site`) and injects the matching `researchApi` configuration, so nothing has to be edited.
`scripts/stop.sh` shuts it down.

**Separate static server:**

1. Start the backend (`../backend/README.md`): `python -m aeris_backend.api.main --port 8750 --cors http://localhost:8000`.
   For synthetic telemetry also start the standalone emulator, `python -m aeris_backend.telemetry.emulator`
   (127.0.0.1:47100), and press **Connect** in the Telemetry tab.
2. Serve this folder (`python3 -m http.server 8000`) and set in `js/site-content.js`:
   `researchApi: { baseUrl: "http://127.0.0.1:8750", wsUrl: "ws://127.0.0.1:8750", pollMs: 1000, probeMs: 60000, mock: false }`.
3. Open `#lab`. The backend line shows whether the backend is reachable (it is probed at load, every `probeMs` and on **Check backend**); SIMULATION becomes selectable only after the backend has answered its health and capability checks, and uses only the capabilities it reported. DEMO mode keeps running in the browser at all times.

**HARDWARE mode / Telemetry tab.** Selectable when a reachable backend reports its telemetry path. The tab connects
the backend to a telemetry source (the standalone synthetic emulator, a file replay or, later, a device adapter),
shows the live stream with its validation counters (rejected, duplicate, out-of-order, gaps, stale), records it
and replays recordings. Emulator data are labelled **SYNTHETIC EMULATOR — not the physical cube** everywhere
(status strip `SYNTHETIC TELEMETRY`); nothing here sends commands to a device. Protocol and limits:
`docs/TELEMETRY.md`; what a physical device still needs: `docs/HARDWARE_HANDOFF.md`.

Never put credentials in these files. The device API (`/api/v6`) authenticates with the backend's configured identity provider in jwt mode; a host page supplies access tokens through `window.AERIS_AUTH_PROVIDER` (`docs/CONNECT.md` § Security). Contract and behaviour: `docs/BACKEND_INTEGRATION.md`.

## Files and formats

JSON Schemas for every format are in `schemas/` (generated by `build/build_schemas.js` in the source package): `aeris-config/1` (rev 1.0 / 1.1 / 1.2), `aeris-run/1` (rev 1.1 browser, 1.2 v4 research backend, 1.3 v5 research backend), `aeris-runs-bundle/1`, `aeris-sweep/1` (rev 1.0 / 1.1 / 1.2), `aeris-dataset/1`, `aeris-hardware-run/1`, `aeris-job/1`, `aeris-telemetry-frame/1`, `aeris-parameter-set/1`, `aeris-validation-protocol/1`. Revisions only add fields (`docs/SCHEMA_EXTENSIONS.md`; v4 → v5 in `docs/MIGRATION_V5.md`). The live telemetry contract is `aeris-telemetry-ndjson/1` (`docs/TELEMETRY.md`). v6.0 device documents (`aeris-device-profile/1`, `aeris-experiment-recipe/1`, `aeris-calibration/1`, `aeris-device-config/1`, `aeris-kit/1`, `aeris-bom/1`, `aeris-firmware-manifest/1`) are described in `docs/DEVICES.md`; their reference copies are in `data/`, the firmware in `firmware/`. Runs are saved in the browser's local storage; export JSON or CSV to keep them. A host page can set `window.AERIS_ENV = { downloads: false }` (copy only) or `window.AERIS_ENV.save = (name, text) => Promise` to route downloads.

## Tests

```
node tests/numerics.test.js     # physics, outcome rules, validation, mass properties, Python reference
node tests/runs.test.js         # run records, persistence, import/export, CSV
node tests/assistant.test.js    # local explanations use only run data
node tests/platform.test.js     # tokens, experiment IDs, schema normalisation, timelines, v2 compatibility
node tests/engine.test.js       # AERIS Twin 0.3.0: defaults identical to 0.2.0, sensor and actuator models
node tests/service.test.js      # service routing, adapters, job states, mock research API, sweeps
node tests/ui.test.js           # badges, status strip, controller descriptions, computed labels, plots, validation maths
node tests/schema.test.js       # generated records conform to the JSON Schemas
node tests/v4.test.js           # v4 integration: validation layers, preserved fields, backend records, cancellation, connection, recovery, hardware data
node tests/v5.test.js           # v5: metric versions, recording rule, experiment contract, preview/assistant races, telemetry adapter
node tests/live_backend.test.js # the real adapters against a running backend and the standalone emulator (starts ../backend with uvicorn)
python3 tests/browser_check.py  # v2 behaviour in a real browser (Playwright + Chromium), bounded waits
python3 tests/browser_v3.py     # v3 platform features in a real browser
python3 tests/browser_v4.py     # SIMULATION mode in a real browser against the running backend, then DEMO without it
python3 tests/browser_v5.py     # v5 in a real browser: replay race, contract editors, backend runs, reproduce after reload, sweep cancel + dataset, Telemetry tab (synthetic emulator), reduced motion
node tests/v51.test.js          # v5.1: telemetry stream identity across backend restarts (adapter), origin wording of stored recordings
python3 tests/browser_v51.py    # v5.1 in a real browser: two tabs across a real backend restart (WebSocket and polling), provenance in the Telemetry tab
python3 tests/browser_v52.py    # v5.2: sweep cancellation in every job state (before start, running, last run, analysing, after completion, next sweep), full speed and CPU-throttled
node tests/resume.test.js       # v6.0 (V52-1): race-safe telemetry resume — catch-up from history, each frame once and in order, explicit gaps
node tests/procs.test.js        # v6.0 (V52-3): the test suites' process helper — a stop timer never kills a replacement
node tests/connect.test.js      # v6.0: device link host, negotiation, calibration parity with the backend, installer (scripted flasher), sessions, recorder, build progress
python3 tests/browser_v6.py     # v6.0 in a real browser: virtual first, Build, Connect with the synthetic device, a scripted Web Serial port and flasher, a local and a jwt backend, phone layout
```

`live_backend.test.js`, `browser_v4.py`, `browser_v5.py`, `browser_v51.py` and `browser_v6.py` start the backend themselves; set
`AERIS_PYTHON` to the backend's Python (e.g. `../backend/.venv/bin/python`). `python3 ../scripts/run_tests.py` runs
every suite and writes logs with exact counts and a verdict (`--only` for a selection; interpreters given with
`--backend-python` / `--browser-python` are resolved from the directory you start in and never replaced).

## Folder layout

```
index.html              all views (built from build/templates in the source package)
css/                    base (tokens), twin, workspace, platform (status strip, badges, timeline, sweep, pages)
js/site-content.js      editable project content and backend configuration
js/core.js              AERIS Twin engine: physics, validation, design, simulation, assessment, event timeline
js/runs.js              run records, browser library, import/export, CSV
js/platform/            tokens, ids, schema, events, controllers, compare, jobs, sweep, examples, validation, service
js/adapters/            local-simulator, replay, research-api, mock-research-backend, hardware-telemetry (read-only telemetry client)
js/connect/             v6.0 Build and Connect (loaded only when opened): build-ui, connect-ui, link (device link host), serial (Web Serial),
                        session, synthetic (the WebAssembly device), calib, recorder, installer, devapi, auth, store, lazy
js/ui/                  badges, status, timeline, run-plots, mass-panel, setup-panels, pages; sweep-ui and telemetry-ui (loaded on demand)
js/workspace.js         AERIS Lab workspace;  js/ws-maths.js maths panel;  js/assistant.js local explanations
js/viewer3d.js          3-D cube (three.js) with a 2-D fallback
js/twin-page.js, js/home.js, js/app.js, js/charts.js, js/ws-util.js
docs/                   PHYSICS, CONTROLLERS, ESTIMATION, SCHEMA_EXTENSIONS, BACKEND_INTEGRATION, RESEARCH_PLATFORM, HARDWARE_NEXT_STEPS, ROADMAP;
                        v5: EXPERIMENT_CONTRACT, METRICS, ESTIMATION_TIMING, RECORDING, JOBS_AND_RECOVERY, DATABASE, PARAMETERS,
                        REPRODUCIBILITY, TELEMETRY, HARDWARE_HANDOFF, ENGINE_AUDIT, MIGRATION_V5; MIGRATION_V5_1, MIGRATION_V5_2;
                        v6.0: CONNECT, DEVICES, DEVICE_LINK, FIRMWARE_INSTALL, MIGRATION_V6
schemas/                JSON Schemas
data/                   v6.0: kits, BOM, reference profile, recipes, approved reference configurations; aeris-data.js (the same for file:// pages)
firmware/               v6.0: releases/0.1.0 (the signed release image and manifest), trust.json, synthetic/ (the WebAssembly synthetic device)
vendor/, fonts/, assets/  three.js r128, KaTeX 0.16.11, v6.0: esptool-js 0.7.0 and @noble P-256/SHA-256 (vendor/VENDORED.md); fonts (OFL), AI-generated visuals
tests/                  see above
```

## About the numbers

- **Nominal parameters.** Every simulated result, in the browser and on the research backend, uses nominal design parameters. Neither engine has been validated against the physical cube (hardware dataset pending).
- **Synthetic telemetry and devices.** The telemetry path and the device stack have only carried data from synthetic sources (the emulator, the synthetic device in the page or as a process, recorded files); they have never been connected to a physical cube or board. Synthetic data are labelled synthetic everywhere and can never promote a model to validated.
- **Generated visuals.** The render, assembly video and reference sheet are AI-generated and labelled so.
- **Earlier benchmark.** Kept on the Results page labelled UNVERIFIED HISTORICAL: earlier project simulation runs, traces pending import, not produced or re-checked by this site.

What changed since v5: `../CHANGELOG.md` and the current report `../SOFTWARE_COMPLETION_REPORT.md` (v6.0); v4 (and v3): `CHANGES.md`.

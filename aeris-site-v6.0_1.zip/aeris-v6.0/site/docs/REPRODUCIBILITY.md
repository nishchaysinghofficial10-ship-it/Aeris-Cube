# Reproducibility: seeds, tolerances, reproduction and reanalysis

Code: `backend/aeris_backend/rng.py` (`derive_seed`), `experiments/sweeps.py` (`SEED_STRATEGIES`, `seed_for`),
`experiments/reproduce.py` (`reproduction_config`, `compare_reproduction`, `TOL_REL`, `ENGINE_CHANGES`).
Tests: `backend/tests/test_sweeps.py`, `test_engine_audit.py`, `test_service.py`, `test_persistence.py`,
`test_parity.py`; campaign check `studies/verify_campaign.py`.

## 1. Seeds

Every stochastic element (sensor noise, dropouts, random walks, Monte Carlo samples) draws from seeded generators;
there is no hidden global randomness. A single run uses `config.seed`. Sweeps derive seeds with FNV-1a over the
text form of (sweep seed, index, stream name) — independent of controller, worker process and execution order:

| `seed_strategy` | Seed of a run |
|---|---|
| `paired` (default) | `derive_seed(sweep seed, point index, "noise")`: every controller, mass configuration and estimator at a point sees the same noise, so comparisons are paired (McNemar) |
| `legacy` | the browser's rule: Monte Carlo points get seed + point index, other modes the base seed |
| `fixed` | the base configuration's seed for every run |
| `independent` | `derive_seed(sweep seed, run index, "noise")` (unpaired) |

Monte Carlo sample values come from the sweep seed; normal variables are not clipped — samples outside the stated
range become INVALID rows (kept and counted), and `bounded-normal` is the exact truncated normal.

## 2. What is guaranteed, and the tolerances

| Situation | Guarantee | Evidence |
|---|---|---|
| same machine, same software versions | **bit-identical**: samples, metrics, outcome, row values | `test_service.py::test_reproduction_is_identical`, `test_engine_audit.py` (1 vs 3 worker processes and a crash-and-resume give identical rows and analysis), `studies/verify_campaign.py` (32/32 rows identical) |
| another platform, Python/NumPy build or CPU | numeric values may differ in the last digits: **relative 2e-5 per sample value** (`TOL_REL`; records keep 6 significant digits) and the same outcome, the same rows, columns, units and sample rate; for metrics compared by `verify_campaign.py`, relative 2e-5 (1e-9 absolute) | the independent v5 review on macOS arm64 (Python 3.12): largest sample difference 2.053914e-15 against the Linux-generated fixture, same outcome, 31 rows, 39 columns within tolerance; 32 sampled campaign rows within tolerance with unchanged outcomes (supplied evidence, `evidence/v5-independent-review/`). Our own runs: Linux x86-64 only |
| near a boundary (a run that barely recovers or falls) | a tiny numerical difference can flip the outcome; such a flip is reported as a boundary case (`outcome_changed`), never hidden or "rounded away" | — |
| another engine version | differences are expected where the engine changed; `ENGINE_CHANGES` names the affected configurations (1.1.0: cf3d/MEKF runs — prediction to the control time, MEKF reset Jacobian, compensated alignment — and the recorded `est_*` columns of estimator runs) | reproduction verdicts list the expected reasons |

Bitwise equality across platforms is **not** promised.

**How the tests apply this (v5.1, review finding F4 of v5).** `backend/tests/test_reproduction.py` checks a rerun
made in the same environment for bit-identity (samples, outcome, metrics — also after the JSON round trip a stored
record goes through) and checks the stored v4 fixtures, which were generated on another machine, with the
cross-environment rule above (the tolerance is asserted to be the documented 2e-5, so widening it is a visible,
documented decision). Negative controls in the same file show that a relative 1e-3 change of one sample, a change of
1.5 × the tolerance, an outcome change, a missing column, a changed unit and one row fewer all fail, while the
Mac-sized 2.05e-15 difference passes the cross-environment rule and fails the same-environment rule. v5 demanded
bit-identity from the fixtures on every platform and failed on macOS although the application's verdict was
correct.

## 3. Reproduction

`POST /runs/{id}/reproduce` simulates a stored run's saved configuration again as a **new** record; its
`reproduction.reproduces` block compares the two:

* `identical` — same number of rows, every shared sample column bit-identical, same outcome;
* `within_tolerance` — every shared numeric sample within `TOL_REL·max(1, |x|)`, same outcome;
* `different` — otherwise; `explanations` names the reasons that explain it (engine version with the affected
  configurations, metric version, changed configuration), and the block lists the engine and metric versions, the
  first column over tolerance and columns present in only one of the two records.

Configuration changes a reproduction needs are explicit (`config_changes`): a v4 record whose recording rate did
not divide the integration rate is reproduced at the rate v4 actually executed ([RECORDING.md](RECORDING.md)).
The browser shows the verdict ("reproduced every saved sample exactly", or how much and why it differs). Browser
engine records are re-run in the browser; backend records only on the backend (never substituted).

## 4. Reanalysis

A record with an older metric version is not recomputed from its samples (they hold the recording rate only):
`POST /runs/{id}/reanalyze` reproduces it with lineage `relation: reanalysis` and the new metric version
([METRICS.md §4](METRICS.md)). The original record is never changed.

## 5. Parity with the browser engine

For the configurations both engines support, the research backend reproduces the browser engine (`site/js/core.js`)
within the tolerances in `backend/tests/test_parity.py` (deterministic cases sample-for-sample; noisy cases within
stated statistical tolerances). v5 did not change the browser engine's physics; its recording rule now refuses
non-divisor rates like the backend.

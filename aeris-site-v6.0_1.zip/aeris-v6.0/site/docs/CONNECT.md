# Connect My Cube — devices, ownership and the device API (v6.0)

**Optional.** The virtual cube in AERIS Lab stays the default: it runs in the page, from `file://` too, with no
backend, no account and no hardware. Connect My Cube (`#connect`) adds a device workflow: install firmware, pair,
diagnose, calibrate, apply an approved configuration, self-test, run a bounded experiment, record, simulate the same
cube and compare. The connect code loads only when the page is opened (`js/connect/lazy.js`).

**What is real today.** Everything below is implemented and software-tested with **synthetic** devices (the firmware
core driving models of the IMU, the wheel drivers and the engine's plant — in the page as WebAssembly, or as a native
process) and with labelled test doubles (a scripted Web Serial port and flasher). **No physical cube has been
connected, measured or balanced.** A board's `physical` is what its firmware declares; the attitude shown is the
device's estimate; a simulation is a prediction; a comparison with a synthetic recording is never evidence.

| Capability | Status |
|---|---|
| Synthetic device in the page (WebAssembly), the whole journey without a backend | implemented, software-tested (`browser_v6.py`) |
| Web Serial: port selection, firmware install, pairing, commands | implemented; tested with a scripted port and flasher (labelled test doubles); never with a board |
| Backend devices: companion, browser relay, gateway, owners, leases, commands, calibration, configuration, recording, twin, comparison | implemented, software-tested with the native synthetic device (`test_devices_e2e.py`) |
| Physical board, IMU, drivers, motors | **requires hardware** — see [`hardware/COMMISSIONING.md`](../../hardware/COMMISSIONING.md) |

Protocol details: [DEVICE_LINK.md](DEVICE_LINK.md). Documents and the REST reference: [DEVICES.md](DEVICES.md).
Firmware installation: [FIRMWARE_INSTALL.md](FIRMWARE_INSTALL.md). Telemetry and recordings:
[TELEMETRY.md](TELEMETRY.md), [RECORDING.md](RECORDING.md).

## 1. Routes to a device

```
 page ── Web Serial ──────────────────────────────► device (usb)        the page is the link host ("local")
 page ── Web Serial ── page ══ wss /api/v6/relay ═► backend             route browser-relay: the backend is the host
 companion ── serial ═════════ wss /api/v6/relay ═► backend             route companion
 device (net) ═════════════════ wss /api/v6/device-link ═► backend      route gateway: the device connects out, over TLS
```

* **Local** (no backend needed): the page speaks `aeris-device-link/1` itself — to the WebAssembly synthetic device or
  to a board on a Web Serial port (Chromium-based browsers over HTTPS or `localhost`). Pairing is with this browser;
  calibrations are kept in this browser; the configuration is the site's reference configuration (built by the backend
  from the reference profile, `site/data/configs/`) combined in the page with the calibration's mounting and gyroscope
  bias. Recordings are made in the page (`js/connect/recorder.js`) and can be exported or stored on a backend.
* **Backend**: the backend is the link host for a device of your account: through the companion
  (`python -m aeris_backend.companion`) or this page relaying its port (USB-side routes: the device's session
  supervises), or through the device's own outbound WebSocket (gateway: it observes while a USB session exists).
  Commands, leases, the command log, calibrations, configurations, telemetry and recordings live in the backend's
  database, scoped to the owner.

A device that a USB-side route and the gateway reach at the same time is driven through the USB side; the backend
takes the telemetry from the preferred route and continues it, without losing frames, when that route closes or
reconnects (DEVICE_LINK.md §7).

## 2. The journey on the page

Choose a device: **the synthetic device** (in this page; labelled SYNTHETIC everywhere, with on-screen "hands":
press ARM, hold ARM 2 s, emergency stop, rest on a face, hold at the start position, turn the wheels by hand, push), **a
USB port** (Web Serial; a port without answering AERIS firmware offers only Install) or **a device of your account**
on an AERIS backend (when the backend's device API is enabled and you are signed in).

| Step | What happens | Gate |
|---|---|---|
| Install | signed firmware image → board over Web Serial ([FIRMWARE_INSTALL.md](FIRMWARE_INSTALL.md)) | Web Serial only; a device already running AERIS firmware must be in BOOT, DISARMED, FAULT or UPDATE (drivers unpowered) and accept `enter_update`; images that can drive motors are never installed |
| Pair | local proof: the device signs after a press of ARM on the cube | USB link, DISARMED |
| Diagnostics | identify (LED), diagnostics (IMU, drivers, loop timing, estimator, links, local inputs) | nothing moves |
| Calibrate | gyroscope bias (still), two or more faces (gravity directions → IMU mounting), wheel directions (turned by hand) | the device measures; the backend or the page computes (§ Calibration) |
| Profile | view, validate, save a revision of your own profile, use it for this device (backend) | revisions are immutable; using another revision invalidates the current calibration for configuration (measurements are kept for recomputation) |
| Configure | approved configuration (backend-designed gains) → `apply_config` bound by its SHA-256; self-test → READY | fits the device's capabilities; a declared-physical device needs its own calibration |
| Experiment | `start_experiment` waits for ARM on the cube; live attitude estimate, tilt against the start limit, stop always available | actuation build, configuration applied, READY; prerequisites of the recipe |
| Record & compare | record telemetry; export JSON / NDJSON; store on the backend; Simulate My Cube; compare | simulation and comparison need the backend |

Every page of the journey links back to the virtual cube. The Build page's step links open the matching step here.

## 3. Owners, devices and pairing

A **device** is registered to one owner by a pairing proof (DEVICE_LINK.md §4): `POST /api/v6/pairing/start` →
`pair_begin` over USB → ARM press on the cube → `pair_proof` → `POST /api/v6/pairing/complete`, or `{"op":"pair"}`
on a relay (the backend sends `pair_begin` itself). The registration stores the device's public key, board, firmware,
the `synthetic` flag the device declared and a profile revision (the reference profile at first). Another owner's
device answers **404**, exactly like a device that does not exist. `POST /api/v6/devices/{id}/revoke` forgets the
credential and closes its connections.

## 4. Leases and commands

The backend sends only the remote actions (`identify, diagnostics, self_test, calibrate_imu, calibrate_axes,
check_encoders, apply_config, start_experiment, stop, clear_faults, set_telemetry, reboot`); `set_network, unpair,
enter_update, commission, motor_test` are USB-local (the page over Web Serial). Every remote action except
`diagnostics` and `stop` needs the **control lease** (`POST …/lease {"holder": <client session id>}`, 30 s, renewed by
the same holder; `"takeover": true` moves it and raises its epoch, so the old holder's commands are refused by the
device as stale). A command is sent once; its status history (`queued → sent → accepted|rejected → executing →
completed|failed|expired`) is stored with the device's reasons and results. Nothing is resent automatically; after a
backend restart, commands without a final status are marked `expired`.

Before `start_experiment` the backend also requires: the device reports the configuration as applied; the recipe's
prerequisites (the corner recipe needs a completed edge trial — duration reached — of the same device and profile
revision; waived for a device that declares itself synthetic); and, for a device that does not declare itself
synthetic, a calibration with three confirmed wheel directions. The device then applies its own gates (actuation
build, self-test, the local ARM press, start tilt, faults, driver freshness).

## Calibration

The device **measures**; it never decides that a calibration is good enough. The backend
(`backend/aeris_backend/devices/calibration.py`) and the page (`site/js/connect/calib.js`, the same algorithm; a shared
fixture keeps them in agreement) turn device results into an immutable `aeris-calibration/1` document, or refuse with
the reason.

| Measurement | Device command | What is derived | Refused when |
|---|---|---|---|
| Gyroscope bias | `calibrate_imu` (cube completely still) | the bias in the sensor frame (mean of the raw readings), its spread, the accelerometer norm, samples, temperature | the device reported motion, the gyroscope spread exceeds 0.02 rad/s or the accelerometer spread 0.15 m/s², a bias component above 0.2 rad/s |
| IMU mounting (`to_body`) | `calibrate_axes` with the cube resting on named faces (`+x … -z` up), at least two different axes | the best of the 24 axis-aligned rotations mapping each measured gravity direction onto its named body axis, with the residuals | one axis only (the rotation about it is undetermined), implausible gravity magnitude (outside g ± 0.8 m/s²), motion, a best fit worse than 10° |
| Wheel directions | `check_encoders` while each wheel is turned **by hand** in its marked positive direction | per wheel: confirmed, wrong sign (the profile's `driver.sign` must be corrected in a new revision) or not checked (less than a quarter turn, or both directions) | a node that does not match the profile, a result without three wheels |

Inputs are either the ids of completed commands from the backend's command log (evidence origin
`backend-command-log`, with each result's SHA-256) or results relayed by the owner's client from a Web Serial session
the backend did not observe (origin `client-reported`). A calibration is bound to the device and to one **profile
revision**: a configuration refuses a calibration made for another revision. When the measured mounting differs from
the profile's declared `imu.to_body`, configurations use the measured one and the calibration says so.
`wheel_directions_confirmed` is true only when all three wheels were confirmed.

A calibration does **not** establish the mass model, the inertia, the motor constants, the limits or the gains, and it
does not qualify anything: it records sensor orientation, gyroscope bias and wheel directions measured on one device.

## 5. Approved configurations

`POST /api/v6/devices/{id}/configs {"recipe": …, "calibration": …}` builds an `aeris-device-config/1` from the
device's profile revision, the recipe and the calibration (`devices/configgen.py`): the LQR gains are designed by the
backend on the profile's model (the same model Simulate My Cube runs); the limits come from the profile and the
recipe; the calibration's measured mounting and gyroscope bias are applied. The canonical text and its SHA-256 are
stored; the device verifies the hash of the bytes it receives and validates every field again (DEVICE_LINK.md §8).
A configuration is regenerated, never edited: a changed profile, recipe or calibration gives a new hash. It is refused
for a device whose capabilities do not fit (409 `incompatible`, with the reasons), for a calibration of another device
or profile revision, and — for a device that does not declare itself synthetic — without a calibration. The device
keeps the applied configuration in RAM only: after a reboot or a firmware update it must be applied again.

## 6. Telemetry, recordings, Simulate My Cube and comparison

* **Telemetry.** Each device has its own telemetry hub on the backend (`GET /api/v6/devices/{id}/frames`, the live
  socket `/api/v6/devices/{id}/live`), with the provenance rules of [TELEMETRY.md](TELEMETRY.md): a device that
  declares itself synthetic gives synthetic frames, labelled as such. The device's stream continues across route
  changes and reconnections with the device's own backfill; frames the device no longer held are recorded as gaps.
* **Recordings.** `POST …/recordings/start` and `…/recordings/stop` store an `aeris-hardware-run/1` recording
  (`AERIS-HW-…`) owned by the device's owner, with `device_link` (device id, configuration hash, boot id, route). It
  appears in `/api/v1/hardware/recordings` for its owner and exports to JSON and NDJSON like every recording. A page
  recording (local route) carries the same provenance and can be stored with "Store on the backend".
* **Simulate My Cube.** `POST /api/v6/twin/simulate {"device_id" | "profile", "recipe", "calibration"?, "seed"?}` runs
  the research engine on the engine configuration of the same profile revision, recipe and calibration (`twin` is
  stored with the run). The answer is a v1 job and the run's `parameter_set` identity; the run opens in AERIS Lab. It is
  a simulation of the profile's **model** (nominal and declared values unless the profile says measured), not a
  measurement; its label follows the parameter-set coverage rule (DEVICES.md §6): MEASURED only when every model input is
  covered by groups the profile declares measured, otherwise NOMINAL with the covered inputs listed.
* **Comparison.** `POST /api/v6/twin/compare {"run_id", "recording_id", "protocol_id"?, "max_lag_s"?}` compares a
  device recording with a twin run. The recording's clock is moved to the start of its balancing run (its first frame
  with status `ok`; the rule is stated in the result) so that it lines up with the simulation's t = 0; a lag search
  refines the offset. The result states `admissible_as_validation_evidence` with its reasons: a synthetic or
  unknown-origin recording, or no predeclared validation protocol, makes it inadmissible. **Connection, pairing,
  flashing and close numerical agreement never mark a model VALIDATED**; a person reviews admissible evidence.

## Security

* **Authentication modes** (`backend/aeris_backend/devices/auth.py`, `AERIS_AUTH`):
  * `local` (default): one owner, `local`, for a backend on this computer. Refused — the device API is then disabled,
    not opened — when the backend is bound to a non-loopback address or a non-loopback `AERIS_PUBLIC_ORIGIN` is set.
  * `jwt`: every `/api/v1` and `/api/v6` request except `/api/v1/health`, `/api/v1/capabilities` and `/api/v6/status`
    carries `Authorization: Bearer <access token>` from the configured identity provider, verified with PyJWT against
    the issuer's JWKS (`AERIS_JWT_JWKS_URL`, https, or `AERIS_JWT_JWKS_FILE`): exact `iss` (`AERIS_JWT_ISSUER`) and
    `aud` (`AERIS_JWT_AUDIENCE`), required `exp`, `iat`, `sub`, asymmetric algorithms only (`AERIS_JWT_ALGORITHMS`,
    default `RS256,ES256`; `none` and HS* refused). The owner is `<iss>|<sub>`. `AERIS_PUBLIC_ORIGIN` must be
    `https://` (http only for loopback). An incomplete or unsafe configuration fails closed (503 with the reason in
    `/api/v6/status`).
  * The **development fixture** (`python -m aeris_backend.tools.devauth init | token --sub alice | env`) creates a
    local ES256 issuer key and JWKS under `data/dev-auth` (git-ignored) for exercising jwt mode on this computer. Its
    issuer `aeris-dev-issuer` is refused whenever the public origin is not a loopback origin, so it can never secure a
    public deployment. The page accepts a development token only on a loopback origin.
* **Browser WebSockets** cannot send an Authorization header: they present a single-use **ticket** (`POST
  /api/v6/tickets {"purpose": "live" | "relay" | "v1-live"}`, 192-bit random, 30 s, bound to the owner and the
  purpose). Programs (the companion) may send the header instead. Browser origins are checked (jwt mode: the public
  origin and the configured CORS origins).
* **Devices** authenticate on the gateway with the key registered at pairing (challenge-response, 10 s); a socket with
  an `Origin` header is refused (a page cannot pose as a device). Pairing needs the USB link and a local press.
* **Commands**: owner isolation (404 for others), the control lease and its epoch, USB-local-only actions, per-session
  sequence numbers, ttl from receipt, duplicate ids never re-executed (DEVICE_LINK.md §5).
* **No unrestricted unattended Internet motor control**: release firmware never drives motors; an experiment starts
  only after a press of ARM on the cube; its duration is bounded by the approved configuration; the supervisor link's
  loss ends it with a normal stop; `stop` is always accepted from any session without a lease. There is no public
  one-click bypass of the hardware qualification: actuation exists only in experimental builds made from source.
* **Limits**: at most 32 unauthenticated gateway connections, 8 live views per device, binary WebSocket messages up to
  64 KiB, 10 000 open tickets.
* **No secrets in the repository**: no identity-provider keys, no production signing key (the firmware trust list's
  production entry is empty), no Wi-Fi credentials. The development fixtures generate their keys locally; the test
  signing key of the development firmware builds was kept outside the repository.
* Libraries: `cryptography` (ECDSA P-256 verification), PyJWT; in the page the vendored `@noble` P-256/SHA-256 and
  esptool-js. No custom cryptography.

## 7. Local launch

```bash
scripts/install.sh                      # backend/.venv with the pinned dependencies
scripts/start.sh                        # backend + site on http://127.0.0.1:8750/ (AERIS_AUTH=local, one owner)
# or: cd backend && .venv/bin/python -m aeris_backend.api.main --serve-site ../site     (default port 8750)
```

Open `http://127.0.0.1:8750/#connect`. The synthetic device needs nothing else. A board on USB: use Install / Pair on
the page (Web Serial), or the companion:

```bash
# the companion's dependencies (pyserial, websockets) are in backend/requirements-lock.txt: scripts/install.sh installs them
backend/.venv/bin/python -m aeris_backend.companion --backend http://127.0.0.1:8750 --serial /dev/ttyACM0 --pair --name "My cube"
# the native synthetic device instead of a board:
make -C firmware build/host/aeris-hostsim
firmware/build/host/aeris-hostsim --plant firmware/tests/fixtures/plant_edge.json --usb-tcp 47201 --net-tcp 47202 --ctl-tcp 47203
backend/.venv/bin/python -m aeris_backend.companion --backend http://127.0.0.1:8750 --tcp 127.0.0.1:47201 --pair
```

The companion prints the backend's control messages as JSON lines and, with `--pair`, asks you to press ARM on the
cube (for the native synthetic device: send `arm-press` to its control port). jwt mode on this computer:
`python -m aeris_backend.tools.devauth init`, then start the backend with the environment printed by
`python -m aeris_backend.tools.devauth env`, and give the companion `--token-file` (or `AERIS_TOKEN`).

## 8. Public deployment (configuration; none was performed)

No public deployment, account or identity provider was created for v6.0. A deployment needs:

1. a TLS-terminating reverse proxy serving the site and the backend on one `https://` origin (WebSockets passed
   through: `/api/v6/device-link`, `/api/v6/relay`, `/api/v6/devices/*/live`, `/api/v1/telemetry/live`,
   `/api/v1/live/*`);
2. the backend bound to loopback behind it, `AERIS_AUTH=jwt`, `AERIS_PUBLIC_ORIGIN=https://…`, `AERIS_JWT_ISSUER`,
   `AERIS_JWT_AUDIENCE`, `AERIS_JWT_JWKS_URL` of a real OAuth 2.0 / OpenID Connect provider (never the development
   fixture), `AERIS_CORS_ORIGINS` limited to that origin;
3. the page's sign-in through the provider (`window.AERIS_AUTH_PROVIDER` supplies access tokens to `js/connect/auth.js`);
4. a gateway URL (`wss://…/api/v6/device-link`) given to each board over USB with `set_network`; boards verify the
   server against the ESP-IDF CA bundle, so the certificate must come from a public CA;
5. a production firmware signing key held outside the repository and its public key added to the trust list's
   production entries (FIRMWARE_INSTALL.md), and the production security items in
   [`hardware/COMMISSIONING.md`](../../hardware/COMMISSIONING.md).

`/api/v6/status` reports the authentication summary (mode, enabled, problem, public origin, issuer, audience, whether
the development fixture is in use) without any secret.

## 9. Tests

`backend/tests/test_devices_unit.py` (calibration, authentication configuration, link host, negotiation, comparison
alignment), `test_devices_api.py` (pairing proofs, profiles, leases, command gates, calibrations, configurations,
prerequisites, restart expiry, two owners in jwt mode, WebSocket tickets, backup/restore of the device tables),
`test_devices_telemetry.py` (telemetry continuity across routes), `test_devices_e2e.py` (the native synthetic device end
to end, two owners with two concurrent devices, the companion on a real pseudo-terminal opened by pyserial, the
companion and the gateway over TLS on loopback with a test CA — a client without that CA is refused), `site/tests/connect.test.js` (link host, negotiation, calibration
parity, installer, sessions, recorder, build progress), `site/tests/browser_v6.py` (the pages in Chromium: virtual
first, Build, Connect with the synthetic device, a scripted Web Serial port and flasher, a local and a jwt backend).
`firmware/tests/` (the core's host tests, `make -C firmware test`; the ESP32-S3 test image in QEMU) and the drift
suite (`scripts/check_drift.py`) run as `firmware:host`, `firmware:qemu` and `drift` in `scripts/run_tests.py`. The
release validator (`scripts/validate_release.py`) repeats the device journey with the native synthetic device built
from the extracted package against that package's freshly installed backend.

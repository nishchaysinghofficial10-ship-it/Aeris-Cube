# Research metrics — definitions version 2

Code: `backend/aeris_backend/metrics/research.py` (`METRICS_VERSION = "2"`), browser display
`site/js/runs.js` (`metricsVersion`) and `site/js/workspace.js` (results panel). Tests:
`backend/tests/test_metrics.py`, `test_control_metrics.py::test_research_metrics_units_and_definitions`,
`site/tests/v5.test.js` M1–M2. Review evidence: [evidence/README.md](../../evidence/README.md) (finding A).

The research metrics of a backend run are computed from the per-integration-step arrays of the run — never from
the recorded plot samples — and every value is stored with its unit and its definition
(`definitions.research` in the record).

## 1. Time grid and integration rule

A signal x is known at the integration instants `t_k = k·Δt`, `k = 0 … n`, where n is the number of integration
steps actually executed (an early termination shortens n). Time integrals use the trapezoidal rule over the n
intervals:

```
∫x dt ≈ Δt·(x₀/2 + x₁ + … + x_{n−1} + x_n/2)          T = n·Δt
RMS = sqrt(∫x² dt / T)     IAE = ∫|x| dt     ISE = ∫x² dt
```

so a constant x gives RMS = |x|, IAE = |x|·T and ISE = x²·T exactly. With n = 0 the integrals are 0 and
RMS = |x₀|. Quantities that are constant over each integration step (requested and applied torque, saturation
flags, the authority residual) are integrated exactly with one weight per step (k = 0 … n−1). Estimator errors
are evaluated at the start of every step — the estimate the controller used for that step — and time-weighted.

## 2. What is reported (`research`)

| Key | Content | Unit |
|---|---|---|
| `attitude_error` | rms, iae, ise, peak, final, duration_s of the attitude error from the plant's balance attitude (edge: tilt error; corner: geodesic quaternion error, or the tilt part when the heading is free) | °, °·s, °²·s, s |
| `lean` | COM lean from the vertical (the browser's legacy quantity) | ° |
| `body_rate` | rms, peak | °/s |
| `wheel_speed` | peak per wheel, fraction of the speed limit | rpm, – |
| `torque` | peak requested and applied per wheel | N·m |
| `authority` | residual (requested − applied body torque) rms, peak; time with a deficit | N·m, s |
| `effort_Nms`, `energy_model_J` | ∫Σ|T| dt; electrical energy of the motor model | N·m·s, J |
| `saturation_s`, `speed_limited_s` | time torque-limited, time speed-limited | s |
| `estimator` | attitude RMSE, **tilt RMSE** (gravity-observable part), final errors, gyro-bias error, estimate age statistics (mean, max, time stale, time before the first sample) | °, °/s, s |
| `recovery` | research recovery against the stated target ([EXPERIMENT_CONTRACT.md §3](EXPERIMENT_CONTRACT.md)) | – |
| `event_counts`, `termination`, `resolution_s`, `units` | counts of timeline events; why the run ended; the step; the unit table | – |

## 3. Version 1 (v4 records) and why it changed

Records written by the v4 backend have no `metrics_version` field and are **version 1**. Version 1 had two defects
(reproduced on v4 with the review's own probe: a constant 1° for 1 s gave IAE 1.1 °·s and ISE 0.0192 °²·s):

1. ISE of angles was converted from rad²·s by dividing once by the rad→deg factor instead of squaring it — the
   values were in rad²·s but labelled °²·s;
2. the time integrals gave full weight to both end samples: n + 1 weights for n intervals (IAE and ISE too large
   by one step's contribution; RMS mixed conventions).

## 4. Old records are never relabelled

A stored record is immutable. Version-1 values stay as they were saved, labelled "version 1 (pre-v5)" in the
results panel with an explanation, and are never shown as corrected. Recomputing them needs the per-step arrays,
which the record does not contain (its samples hold the recording rate only). **Reanalysis** therefore simulates
the saved configuration again as a NEW record with lineage (`POST /runs/{id}/reanalyze`; "Reanalyse with metric
version 2" in the results panel):

```json
"lineage": {"relation": "reanalysis", "derived_from": "<run id>", "metrics_version_before": "1",
            "metrics_version_after": "2", "why_rerun": "…"}
```

The new record reproduces the old one's samples (the engine is otherwise unchanged for such configurations; see
[REPRODUCIBILITY.md](REPRODUCIBILITY.md)); its research metrics are version 2. Comparisons between records with
different metric versions say so and withhold the version-1 ISE instead of showing it next to version 2: the
backend's `POST /compare` (`experiments/compare.py`: per-run `metrics_version`, `research_note`; field names carry
the units, e.g. `attitude_iae_deg_s`, `attitude_ise_deg2_s`) and the Lab's compare panel ("Research metrics"
table with the definition version per run). Tests: `backend/tests/test_reproduction.py`, `site/tests/browser_v5.py`.

## 5. Sweep rows

Sweep rows carry `research.metrics_version` and the research values of each run (`attitude_rms_deg`,
`attitude_iae_deg_s`, `attitude_ise_deg2_s`, `attitude_final_deg`, recovery fields, estimator errors). The
analysis of a sweep uses its declared criterion ([EXPERIMENT_CONTRACT.md §3](EXPERIMENT_CONTRACT.md)).

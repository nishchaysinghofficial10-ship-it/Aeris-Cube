# Jobs, live updates, cancellation and restart recovery

Code: `backend/aeris_backend/jobs/manager.py`, `storage/sqlite.py`, `api/app.py`; browser
`site/js/adapters/research-api.js`, `site/js/platform/jobs.js`. Tests: `backend/tests/test_recovery.py` (29,
deterministic fault injection at every persistence boundary, bounded live-update queues), `test_process_restart.py` (real process exit and
SIGKILL, then a new server; workers of a killed server exit), `test_service.py`, `test_engine_audit.py` (serial/parallel/restart row identity),
`site/tests/service.test.js`, `live_backend.test.js` L8–L9, `browser_v5.py`. Review evidence: finding B.

## 1. States

```
QUEUED → INITIALIZING → RUNNING (done / total) → ANALYZING → COMPLETE        any non-terminal → FAILED | CANCELLED
```

* `progress.done` only increases and counts finished simulations; `progress.total` is fixed once RUNNING.
* Terminal states never change (the repository refuses the write).
* CANCELLED keeps finished runs: `result_ref` names the (partial) sweep, or the run of a single job.
* Every update increments `job.seq`.

## 2. Persistence boundaries (atomicity)

* **Single run**: the identifiers (experiment id, run id) are stored with the → RUNNING transition; the run
  record, `progress.done = 1`, `result_ref` and → ANALYZING are **one transaction**
  (`Repository.save_single_result`); → COMPLETE follows. A job never has two runs (unique index, schema 2).
* **Sweep**: each row and its run record (`store_runs`) are one transaction; rows are keyed by their index, so a
  row is never stored twice; run ids of sweep rows are derived from (sweep id, row index); → ANALYZING only after
  every row is stored; the analysis is a deterministic function of the rows.

## 3. Restart recovery (at start-up, before dispatching)

| Job found | `resume` (default) | `fail` |
|---|---|---|
| single, run saved | finish it (→ COMPLETE, or CANCELLED if cancellation had been requested); nothing recomputed | same |
| single, ANALYZING, no run | impossible under §2: FAILED `inconsistent_state`, visibly, once | same |
| single, no run | recomputed with the stored identifiers | FAILED `interrupted` |
| sweep, ANALYZING | all rows stored: analysis computed again | same |
| sweep, earlier state | continues, skipping stored rows | FAILED `interrupted`; sweep marked interrupted and partial (analysis on request) |
| cancellation requested | CANCELLED, finished work kept | same |

Every dispatch is counted (`jobs.attempts`, persisted); a job dispatched more than `AERIS_MAX_JOB_ATTEMPTS`
times (default 3; e.g. one that crashes the process at every restart) is FAILED `retry_limit`. Errors are never
swallowed: an exception in a handler becomes a FAILED job with its code and message; if even that cannot be
written the job is quarantined for this process (never re-dispatched) and reported by `/health` (status
`degraded`). A handler that returns without reaching a terminal state is FAILED `not_finalized`. A broken worker
pool fails the job with `worker_crashed` (stored rows are kept).

v4 (the review's probe): a single job persisted at ANALYZING hit `TransitionError analyzing → running`, the error
was swallowed and the job was re-dispatched every second forever. v5: FAILED `inconsistent_state` once.

**Single-process rule**: the backend holds an exclusive advisory lock on `<db>.lock` while the database is open
(released by the operating system if the process dies), so two backend processes never dispatch the same jobs; a
second server on the same database is refused.

**Clean shutdown** (SIGTERM, `scripts/stop.sh`): the telemetry source is disconnected, the dispatcher and running
job tasks are cancelled, the worker pool is shut down, the database is closed and the lock released. Unfinished
jobs stay non-terminal in the database and are recovered at the next start as in the table.

**Crash of the backend process** (killed, `os._exit`): each worker process watches its parent and exits within
about half a second once the backend process is gone, so no orphaned workers keep memory or keep computing work
that nobody collects; the next start creates new workers and recovers the jobs from the database. Found while
running the SIGKILL tests: the pool had no such watch (as in v4), and the workers and the multiprocessing helper
process kept running. Test: `test_process_restart.py::test_worker_processes_exit_when_the_backend_process_is_killed`
(Linux `/proc`; with the watch removed it fails with three processes still running after 15 s). POSIX only: on
Windows a worker cannot see its parent's death this way. v5.1 adds
`test_worker_processes_exit_when_the_backend_process_is_killed_portable_ps`, which finds the workers with POSIX `ps`
(the backend's descendants, recorded before the kill) and therefore also runs on macOS; on macOS the `/proc` test is
reported as skipped, which is not a pass. Negative control for both:
`evidence/v5.1-verification/orphan_workers_negative_control.py` (executed on Linux only; not executed on macOS
by us).

**Fault injection** (tests only): `fault_hook(point, job_id, info)` at every persistence boundary; with
`AERIS_ALLOW_FAULT_INJECTION=1`, `AERIS_FAULT_INJECT="point[@n][,point…]:exit|raise"` makes the process exit
(`os._exit(86)`, like a crash) or raise at the n-th occurrence of that point.

## 4. Cancellation

Cooperative: each running job owns a slot in a shared byte array; workers check it every 1024 integration steps and
stop with termination reason `cancelled` (such a run is not counted as finished). Queued work is dropped
immediately; in-flight sweep rows that finish are stored, then the job ends CANCELLED with a partial analysis. A
cancel request that arrives after the result was saved leaves the saved run in place. The browser retries a failed
cancel request and shows the cancelled job's partial rows labelled **PARTIAL**.

**Browser sweeps (DEMO, `LocalSimulatorAdapter`; v5.2, review finding G4 of v5.1).** A request takes effect while the
job is QUEUED, INITIALIZING or RUNNING (`capabilities().cancel.states`): before execution the job ends CANCELLED with
no run computed; during execution it ends CANCELLED with exactly the runs finished so far (PARTIAL). Once every run has
finished the browser engine does not interrupt its analysis (one short synchronous computation): the Cancel button is
hidden while the job is ANALYZING, and a request that arrives after the last run is reported in the job message
while the complete result is kept — never labelled PARTIAL. The button is reset for the next sweep. Tests:
`site/tests/browser_v52.py` (each state separately, at full speed and with the CPU throttled 4×, three attempts each,
no retries; the kept rows are compared with an independent recomputation) and `site/tests/browser_v3.py`.

## 5. Live updates, ordering and fallbacks

* `WS /live/{job_id}`: the current job first, then updates. Every message carries the job's `seq`; the browser
  drops stale and duplicate updates (`seq ≤` the last seen) and never moves a terminal job. Without a message for
  15 s the server re-sends the current job (heartbeat).
* **Bounded resources**: each WebSocket subscriber has a bounded queue (`AERIS_SUBSCRIBER_QUEUE`, 256); a subscriber
  that falls behind loses intermediate updates — the newest state always replaces the oldest queued message, since
  job updates carry the full state. Telemetry has its own limits ([TELEMETRY.md §3](TELEMETRY.md)). Workload
  limits (`BACKEND_LIMITS`, reported by `/capabilities`) are enforced by validation before a job is queued.
* **Reconnect and polling**: when the WebSocket fails or drops, the browser polls `GET /jobs/{id}` and retries the
  socket; results are always fetched and validated before they are shown.
* **Unreachable backend**: a configured backend is not "reachable" until `/health` and `/capabilities` answered;
  SIMULATION and HARDWARE are disabled with the reason while it is not; "Check backend" re-probes. DEMO keeps
  working without a backend. No status label claims a connection or a finished job without the server's answer.

## 6. Error envelopes

Every error is `{"error": {"code", "message", "details": [{"path", "message", "kind"}], "retryable"}}` with the
HTTP status: 404 `not_found`, 409 state conflicts (`not_finished`, `already_final`, `recording_state`,
`telemetry_off`), 422 `invalid_config` / `invalid_sweep` / `invalid_request` / `invalid_parameter_set` /
`invalid_recording` / `invalid_source` with field paths, 429/503 retryable, 500 `internal`.

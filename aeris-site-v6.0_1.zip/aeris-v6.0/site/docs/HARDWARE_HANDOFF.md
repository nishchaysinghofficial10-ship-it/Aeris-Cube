# Hardware handoff — what you must supply to connect the physical AERIS cube

> **v6.0.** AERIS now has its own firmware (`firmware/`, `aeris-fw 0.1.0`), which speaks the telemetry contract
> directly on its device link and adds bounded, locally enabled commands through `/api/v6`
> ([CONNECT.md](CONNECT.md), [DEVICE_LINK.md](DEVICE_LINK.md)). For the AERIS reference cube the hardware work is in
> [`hardware/COMMISSIONING.md`](../../hardware/COMMISSIONING.md) and [`hardware/INTEGRATION.md`](../../hardware/INTEGRATION.md).
> This document remains the route for **another** device: one that speaks the contract (A), has its own JSON lines
> (B) or binary packets (C), connected read-only through the v1 telemetry path.

The software side of the telemetry path is complete and tested with **synthetic** data only
([TELEMETRY.md](TELEMETRY.md)). Nothing in this repository has been measured on, or connected to, the physical
cube. This document lists exactly what the hardware stage has to provide, in order, and how each item enters
the software. Until these items exist, every run stays NOMINAL and every telemetry recording in the database is
SYNTHETIC.

The integration is **read-only**: the software listens to the cube and records. Motor commands, arming, limits,
watchdogs, emergency stop and every other safety function belong to the firmware and are out of scope here.

## 1. Protocol mapping (how the cube's telemetry reaches the contract)

Choose one:

* **A. The firmware speaks `aeris-telemetry-ndjson/1`** (one JSON object per line over a TCP socket, a hello
  first; [TELEMETRY.md §2](TELEMETRY.md)). Then nothing needs mapping: connect with
  `POST /telemetry/connect {"source": "tcp", "host": "127.0.0.1", "port": …}` (or from the Lab's Telemetry tab).
  A serial/USB/BLE link needs a small bridge process that forwards lines to a local TCP port (not included).
* **B. The firmware has its own JSON lines.** Fill in a mapping for `MappedJsonAdapter`
  (`backend/aeris_backend/telemetry/device.py`, `MAPPING_TEMPLATE`), put it in a JSON file `{"cube": mapping}`
  and start the backend with `AERIS_TELEMETRY_ADAPTERS=that-file.json` (every mapping is checked at start-up);
  then connect with `{"source": "tcp", "host": …, "port": …, "adapter": "cube"}`. Supply, for your firmware
  version:
  1. field names for time, sequence number, quaternion (and its component order `wxyz` or `xyzw`), tilt (edge),
     body rate, IMU gyro and accelerometer, wheel speeds, commanded and measured torques, status;
  2. the unit of every field and its scale to SI (e.g. deg/s → rad/s, mN·m → N·m, g → m/s²);
  3. the status codes and their meaning (`ok`, `idle`, `calibrating`, `fault`, `estop`);
  4. how a session starts and ends (the adapter supplies the hello; `bye`/status lines if you have them).
* **C. Binary packets.** Write a `DeviceAdapter` subclass whose `decode()` turns one packet into contract
  messages. Keep it free of any write/command method.

## 2. Firmware version and identity

The exact firmware version string and a device id (serial or name) for the hello. Every recording stores them;
a comparison names them. The mapping (1B) is written *for* one firmware version: record it in the mapping's
`device.firmware`.

## 3. Frames and axes

State, with a drawing or photo reference:

* the **body axes** of the IMU and of the firmware's attitude estimate relative to the cube (the contract's body
  axes run along the cube edges from the pivot corner, [PHYSICS.md](PHYSICS.md)); give the rotation `C` with
  contract vector = C · device vector — it must be a proper rotation (determinant +1; a mirrored axis set is an
  error to fix, not to map);
* the **world frame** of the firmware's quaternion (z up, or NED z down → `world: diag(1, −1, −1)`);
* the quaternion convention (scalar first or last; Hamilton or JPL product — the adapter implements Hamilton;
  a JPL firmware needs the conjugate);
* the wheel order and positive spin direction of each wheel (`wheels.*.index` and `sign`), and which motor
  torque sign accelerates each wheel positively (the contract: torque on the wheel, reaction on the body is
  opposite; [PHYSICS.md](PHYSICS.md)).

A quick check: with the cube resting on its pivot corner at the balance attitude, the accelerometer must read
about +9.81 m/s² along the body diagonal and the telemetry `q` must match `QEQ` of the model; tilting towards
+x must increase the reported lean in that direction.

## 4. Timing

* the time stamp source and unit (e.g. a 32-bit µs counter; give its wrap modulus), and whether it is the IMU
  sample time or the transmission time;
* the nominal frame rate and the jitter you expect;
* the IMU sample rate, the control loop rate and the measured IMU-to-estimate latency;
* whether sequence numbers restart at boot (the recorder then re-bases the time line and marks
  `time_base_reset`).

Timing parameters also belong in the parameter set (§5): `params.fs`, `sensor.rate_hz`, `sensor.latency_ms`,
`actuator.motor_lag_ms`.

## 5. Measured parameters

Create a parameter set (`POST /parameter-sets`, [PARAMETERS.md](PARAMETERS.md)); every value needs its unit, the
measurement method, the date and an evidence reference (lab notebook page, file, photo id), and optionally an
uncertainty. The supported paths cover:

| Group | Paths |
|---|---|
| mass and geometry | `params.m`, `params.a`, `plant.base_com_m`, `plant.base_inertia_kgm2` (full tensor, symmetric positive definite, triangle inequality), `plant.components.<id>.*`, `attachments.<id>.*`, `comOffset_m`, `comShift_m` |
| wheels and motors | `wheels.<id>.Jw`, `.axis`, `.KV`, `.R`, `.Vs`, `.Imax`, `.wmaxRpm`, `.cv`, `.cc` (or the shared `params.*`) |
| sensing | `sensor.imu_position_m` / `params.rImu`, `sensor.gyro_noise_dps`, `gyro_bias_dps`, `gyro_bias_walk_dps`, `accel_noise_mps2`, quantisation, `dropout` |
| timing | `params.fs`, `sensor.rate_hz`, `sensor.latency_ms`, `actuator.motor_lag_ms` |

A run is labelled MEASURED only when **every** input it uses comes from the set unchanged; a partial set, or a
sweep that varies a measured input, leaves the run NOMINAL with the nominal and overridden inputs listed. Sets
are immutable; a correction is a new set with `supersedes`.

## 6. Real recordings

For each scripted experiment (the same setup that will be simulated):

1. register a **validation protocol** first (`POST /validation/protocols`: metric → threshold, e.g.
   `attitude.rmse`); thresholds registered after the data is ingested make a comparison inadmissible;
2. record from the live stream (Telemetry tab → Start/Stop recording) or upload a file
   (`POST /hardware/recordings`, `aeris-hardware-run/1`, `synthetic: false`, `device.kind` physical); an upload may
   use any unit the importer accepts — its NDJSON export converts them to the stream's units (v5.2) — and a
   `status` column needs `provenance.status_codes` (status name → code) to be streamed;
3. include an **independent attitude reference** (motion capture or similar: `qref0–3` / `theta_ref`) if the
   estimator is to be evaluated — without it, estimator error cannot be computed and the comparison says so;
4. run the same setup in SIMULATION mode with the measured parameter set;
5. compare (`POST /hardware/compare` with the protocol id). The result is evidence with ids and hashes; the
   software never marks a model VALIDATED — a person reviews admissible evidence and records the decision.

## 7. What the software already guarantees (so you can rely on it)

* A synthetic, test or replayed source is never shown or counted as the physical cube; synthetic data can never
  be validation evidence ([TELEMETRY.md §6](TELEMETRY.md)).
* Frames are validated strictly; units are checked, never converted; duplicates, gaps, reordering, staleness and
  reconnects are counted and recorded with each recording.
* Nothing is sent to the device.

## 8. Not done (hardware stage)

Firmware; the physical link and any serial/BLE-to-TCP bridge; a mapping for the real firmware; measured
parameters; real recordings; an independent attitude reference; validation protocols with agreed thresholds;
the review that could ever change a model's status. None of these can be produced by software alone.

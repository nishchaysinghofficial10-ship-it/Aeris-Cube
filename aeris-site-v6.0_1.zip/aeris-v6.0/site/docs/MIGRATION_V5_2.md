# Migrating from v5.1 to v5.2

v5.2 corrects the four findings of the independent review of v5.1 (G1–G4). The engine (`aeris-research-engine
1.1.0`), the numerical behaviour, stored records and their schemas, the database schema, the frozen frontend design
and the `LocalSimulatorAdapter` contract are unchanged; the backend is 1.1.2. Nothing stored is rewritten. Changes
that clients can see are listed here with what to do about them.

## G1 — NDJSON export in the stream's wire units (behaviour change; the old behaviour was wrong)

`GET /api/v1/hardware/recordings/{id}/export?format=ndjson` and the replay of a stored recording
(`POST /api/v1/telemetry/connect {"source": "recording", …}`) now convert every signal to the unit that
`aeris-telemetry-ndjson/1` fixes, with the importer's own factors (`hardware/ingest.py`): time → s, angles → rad,
body and gyro rates → rad/s, wheel speed → **rpm** (also from `omega_x…` stored in rad/s, which v5.1 left out),
torques → N·m, acceleration → m/s². A column already in the wire unit (or an alias with the same factor, e.g. `N*m`,
`m/s^2`, `-`) is copied exactly. Every exported hello's lineage records the conversions (`lineage.export.converted`,
e.g. `{"t": "ms → s", "theta": "deg → rad"}`).

What the stream cannot carry without inventing or relabelling data is refused with **HTTP 422,
`error.code = "export_not_possible"`**, the column and the reason (v5.1: HTTP 500, a silent omission or a relabelled
value):

| Input | v5.1 | v5.2 |
|---|---|---|
| an incomplete vector (`w_x`, `w_y` without `w_z`; three-of-four quaternion components) | HTTP 500 or silently dropped | 422; `omit_unmapped=true` leaves it out |
| columns without a stream field (`thetadot`, `qhat0…`, `sat`, `omega_4`, unknown signals) | silently dropped | 422; `omit_unmapped=true` leaves them out |
| a `status` column without declared codes (`provenance.status_codes`; the AERIS recorder writes it) | read with the recorder's table | 422; `omit_unmapped=true` leaves it out |
| a status code outside the declaration | streamed as `"ok"` | 422; `omit_unmapped=true` leaves status out |
| two wheel-speed column sets, `t` < 0, negative `seq`, an edge recording without `theta`, segments that do not cover the rows | exported anyway (one wheel set silently dropped; the replay then rejected the invalid frames) | 422 (cannot be omitted) |
| no `seq` column | the row index (silently) | the row index, stated in `lineage.export.seq` |

`omit_unmapped=true` (query parameter; `"omit_unmapped": true` in a `connect` body) records what was left out in every
hello (`lineage.export.omitted`). The JSON export is unchanged: it returns the stored document byte for byte, in its
own units. Before any NDJSON text is returned it is replayed through a scratch hub exactly as a file replay would
read it; an export that the hub would not accept line for line is a 422, never a file.

**Faulty copies made with v5 or v5.1 cannot be repaired — regenerate them.** An NDJSON file exported by v5/v5.1
from a recording stored in other units (ms, deg, °, deg/s, °/s, `omega_*`, `wheel_rpm_*` in rad/s, mN·m, g) holds
the raw numbers under wire-unit meaning, and a recording made by replaying such a file stores them under s / rad /
rad/s / rpm labels. Their original units are not recorded in them, so v5.2 does not guess or convert them. The
stored originals are correct and unchanged: export the ORIGINAL again with v5.2 and, if a copy is needed, record that
replay. To find what is affected in a database (read-only, changes nothing):

```bash
backend/.venv/bin/python -m aeris_backend.tools.dbtool export-audit --db data/aeris.sqlite3
```

It lists the originals whose v5/v5.1 export was wrong and the stored copies recorded from such an export (copies
whose lineage was written by a v5/v5.1 export, or v5 replays of the stored recording). Native recorder outputs were
always in wire units and are unaffected.

## G2 — bounded, flat lineage (additive; the nested form is no longer written)

v5.1 nested every previous lineage object (with its own nested `ancestors`) into the next export, so repeated
export → replay → re-record broke the protocol's 8 KiB lineage limit (the 5th generation of a two-segment recording;
the hub refused the hello). A v5.2 lineage adds:

| Field | Meaning |
|---|---|
| `generation` | export steps since the original recording (1 for an export of an original) |
| `ancestry` | compact references to earlier exports — `derived_from`, `generation`, `trust`, `original_synthetic`, `original_device` {id, kind, firmware} — flat, deduplicated, newest first; at most 12: the parents and the 4 oldest (original sources) are kept, middle generations are dropped first |
| `ancestry_omitted` | how many references are not listed (explicit truncation) |
| `ancestry_trust` | the least trustworthy status of EVERY ancestor, listed or not |
| `ancestry_note` | only if a v5.1 lineage was too large to read completely (its unread part then counts as unknown) |
| `export` | the export's unit conversions, sequence source and omissions (G1) |

`trust` and `original_synthetic` keep their v5.1 meaning; `ancestors` is no longer written. Long identifiers copied
into the lineage are cut at 160 characters with a visible `…[N more characters]` marker, and every exported lineage
stays within 6144 bytes (protocol limit 8192); if it could not, the export is refused (422), never cut silently.
Conservative status is computed from everything stated — own trust, `ancestry_trust`, every listed reference and,
for v5.1 documents, every nested `ancestors` entry — and can only lower trust: a synthetic ancestor anywhere keeps
the data synthetic; an unknown one makes it unknown. A v5.1 reader still classifies v5.2 exports correctly (their
`trust` already is the conservative result). Stored v5/v5.1 documents are read as they are and never rewritten; their
nested lineage is flattened in the next export.

## G3 — test runner: skipped test cases are never a pass (exit codes and summary fields)

`scripts/run_tests.py` now accounts for test CASES. New suite statuses: `passed with exclusions` and `incomplete`.
New summary fields: `all_applicable_passed`, `all_tests_executed`, `suites_ran`, `executed`, `skipped_tests`
(every skipped case with its reason), `platform_exclusions`, `failed_tests`, `platform_exclusion_policy`,
`exit_codes`. Changed meanings: `complete` now means every test case of every selected suite was executed (v5.1:
every selected suite ran — now `suites_ran`), and `full_validation` is false whenever anything was skipped,
excluded, not run or not selected.

| Exit code | Verdict | Meaning |
|---|---|---|
| 0 | `PASSED — all N suites ran and passed; every test case executed (full validation)` / `PASSED — selected suites only …` | everything in scope executed and passed |
| 1 | `FAILED — …` | a failure, timeout or missing counts |
| 2 | `INCOMPLETE — …` | a suite not run or skipped, or test cases skipped / not run outside the policy (named in the verdict) |
| 3 | `PASSED WITH DECLARED PLATFORM EXCLUSIONS — …` | nothing failed; the only cases not executed are named by `scripts/platform_exclusions.json` for this platform (listed in the verdict). Not a full validation |
| 64 | usage error | |

The policy has one entry: the `/proc` orphan-worker check is excluded on macOS (`darwin`) only while its portable
`ps` counterpart passes in the same run. A macOS run is therefore exit code 3 with that test named — never 0, never
counted as passed. Linux excludes nothing. The CI jobs (Linux) still require exit code 0. `--timeout` (seconds per
suite) and `--exclusions FILE` (another policy file, recorded with its SHA-256) are new options.

## G4 — browser sweep cancellation (DEMO / browser engine)

* The browser engine does not interrupt its analysis once every run has finished: the Cancel button is hidden while
  a browser sweep is ANALYZING (`LocalSimulatorAdapter.capabilities().cancel.states` = queued, initializing,
  running; the optional `cancellable(job)` says the same; `AERIS_SERVICE.cancellable(job)` asks the job's adapter).
  A request that arrives after the last run is reported in the job message and the complete result is kept. v5.1
  showed the button, labelled it "Cancelling…" and silently completed. Research-backend jobs are unchanged (their
  analysis can be cancelled, docs/BACKEND_INTEGRATION.md §6).
* A cancel request processed in the same update as the last finished run no longer labels the complete set PARTIAL
  (v5.1: "Cancelled after 390 of 390 runs; partial results kept").
* After a cancelled sweep the Cancel button is reset; v5.1 left it disabled as "Cancelling…", so the next sweep in the
  same page could not be cancelled.

Cancellation before execution and during execution is unchanged.

## Compatibility checklist

* API: additive (`omit_unmapped`; the `export_not_possible` error). NDJSON frames of recordings stored in non-wire
  units now carry correct values (different numbers from v5.1, which were wrong).
* Protocol and schemas: unchanged (`lineage` was already an open object; its new keys are additive).
* Stored data: never rewritten; v5/v5.1 lineage is read as it is.
* Runner consumers: read `exit_code` and `full_validation`; treat exit code 3 as "not a full validation".

# Migrating from v5 to v5.1: telemetry provenance, stream identity, test runner, test expectations

v5.1 is a focused completion pass on the independent review of v5 (findings F1–F5). It changes no numerical
behaviour: the engine stays **aeris-research-engine 1.1.0**, the simulation records, sweeps, metrics, parameter sets
and the database schema are unchanged, and `LocalSimulatorAdapter` and the frozen frontend design are untouched.
Nothing stored by v5 is rewritten. Every contract change below is **additive** (new optional fields, an optional
query parameter, new enum values that v5 already wrote). See [TELEMETRY.md](TELEMETRY.md) §6 and §11 for the rules.

## 1. Versions

| Item | v5 | v5.1 | Reading older versions |
|---|---|---|---|
| backend / engine | 1.1.0 / aeris-research-engine 1.1.0 | **1.1.1** / aeris-research-engine 1.1.0 (unchanged) | — |
| `aeris-run/1`, `aeris-config/1`, `aeris-sweep/1`, metrics, database | revision 1.3 / 1.2 / 1.2 / version 2 / schema 2 | unchanged | — |
| `aeris-telemetry-ndjson/1` | hello without lineage | optional `hello.lineage` (written by the backend's exports) | sources without it are unaffected |
| `aeris-hardware-run/1` (recordings) | provenance: hellos, transport, quality | + `segments`, `lineage`, `trust`, `trust_reasons`, `mixed_sources`, `derived`, `derived_from`, `recording_closed`, `stream_id` | v5 documents are classified when read (§2); never rewritten |
| `aeris-dataset/1` | `provenance.source` simulation / hardware / mixed (the backend also wrote `synthetic-telemetry`, which the published schema did not list) | the schema lists `synthetic-telemetry`; + `contains_unknown_origin`, `unknown_origin_members`, `derived_members`, member `trust` and `derived` | — |
| browser client header | `X-AERIS-Client: aeris-web/5.0` | `aeris-web/5.1` | informational |

## 2. Telemetry provenance (F1)

* A recording keeps its **source segments** (`provenance.segments`): which hello declared what for which rows. A
  hello with another **mode** closes the running recording (`recording_closed`).
* Trust classes `synthetic` / `declared-physical` / `unknown` (`telemetry/lineage.py`). One synthetic, test or
  undeclared segment or ancestor lowers the whole recording and everything derived from it.
* **NDJSON exports** write one hello per segment. A recording that is synthetic or unknown is exported so that
  every segment replays as synthetic: a segment that was not already synthetic gets the **synthetic replay
  identity** `device.kind: "file-replay"`, `device.id: "replay:<original id>"`, `synthetic: true`. Every exported
  hello carries `lineage`. Consumers that compare device ids of exports must expect the `replay:` prefix.
* A recording **captured from a replay** is `derived` (a copy): never admissible as evidence, even when declared
  physical. Compare the original recording.
* **Old v5 records** are classified by these rules when listed, read, exported, compared or put in a dataset;
  stored documents and database rows are not modified (tested byte-for-byte). A v5 recording that the v5 defect
  produced (a mixed export replayed and recorded: physical hello, captured from a file) is `derived`, so never
  evidence; its synthetic origin cannot be recovered because the v5 export did not carry it. If you kept such
  recordings, export the ORIGINAL mixed recording again with v5.1; the old copies stay as stored and are never evidence.
* `GET /hardware/recordings` rows have `trust` and `derived` (computed from the document for rows stored before
  v5.1); the Telemetry tab names unknown origins and copies.
* Uploads without a `seq` column can now be exported to NDJSON and replayed (the row index stands in; v5 answered
  HTTP 500 — found while testing F2).

## 3. Telemetry stream identity (F2)

* Every backend process has a `stream_id`; it is in `/telemetry/status` (with `stream_started` and `segment`),
  every `/telemetry/frames` answer (`stream_id`, `stream_changed`) and every live batch (`"stream"`). Frames carry
  their `segment`.
* `GET /telemetry/frames` accepts `stream=<id>` (letters, digits and `._:-`, at most 64 characters); a cursor of
  another stream is answered from this stream's beginning. Without `stream` the answer is the v5 answer.
* The browser adapter keeps its cursor per stream, emits a `stream` event on a change, ignores stale streams,
  falls back to counter regression for v5 backends, and never stalls on a WebSocket that fails without `close`
  (Node) or never opens. The Telemetry tab resets its frame state on a stream change and re-probes an unreachable
  backend every 3 s while open.
* Mixed versions: [TELEMETRY.md](TELEMETRY.md) §11 "Backward compatibility". In short: a v5.1 page works with a v5
  backend except after a restart in which the new process has already counted past the page's cursor; a cached
  v5 page against a v5.1 backend behaves as v5 (reload it).

## 4. Test runner and CI (F3)

`scripts/run_tests.py`:
* Interpreters (`--backend-python`/`$AERIS_PYTHON`, `--browser-python`/`$PLAYWRIGHT_PYTHON`, new `--node`) are
  resolved once, from the directory the runner was started in; paths become absolute without resolving symlinks
  (a venv's python is a link to its base interpreter), bare names are looked up on PATH. An explicit interpreter is
  never replaced by another one; a missing, non-executable or Playwright-less one means **not run** with the reason.
* Process launch failures are caught and reported as **not run** (v5 raised `FileNotFoundError` and wrote no summary).
* Statuses `passed`, `failed`, `not run`, `skipped`; `--only` selects suites (others are listed as not selected);
  `summary.json` has `verdict`, `complete`, `all_passed`, `full_validation`, `interpreters`, `selected`,
  `not_selected`; `SUMMARY.md` starts with the verdict. **Exit codes changed:** 0 only when every selected suite ran
  and passed, 1 when a suite failed, **2 when a selected suite was not run or skipped** (v5 exited 0 when you
  skipped suites), 64 for an unknown suite name (v5 ignored unknown names).
* Migration for scripts: replace `--skip backend,js,live` (now an INCOMPLETE run, exit 2) by `--only browser` when
  a partial run is intended. The CI workflow does this and passes absolute interpreter paths under
  `$GITHUB_WORKSPACE`.
* `scripts/ci_local.py` executes the workflow's `run:` steps locally from clean clones. It is **not** a CI service run.

## 5. Test expectations changed on purpose

No assertion was removed to obtain a pass; where a test changed, it is stricter or the platform rule was made
explicit, with negative controls.

| Test | v5 expectation | v5.1 expectation | Why |
|---|---|---|---|
| `backend/tests/test_reproduction.py` | the five v4 fixtures without a 3-D estimator reproduce **bit-identically on every platform** | (a) a rerun in the same environment is bit-identical (samples, outcome, metrics, also through JSON); (b) the v4 fixtures, generated on another machine, meet the predeclared cross-environment rule: relative 2e-5 per sample (`TOL_REL`, unchanged), same outcome, rows, rate, columns and units, verdict `identical` or `within_tolerance`; (c) negative controls: relative 1e-3, 1.5 × tolerance, outcome change, missing column, changed unit, one row fewer fail; the review's 2.05e-15 passes (b) and fails (a) | review F4: on macOS arm64 the fixtures differ by ≤ 2.05e-15 (same outcome); last digits also differ between x86-64 CPUs (vectorised maths and BLAS kernels are chosen per CPU). Fixtures not regenerated, tolerance not widened |
| `site/tests/browser_v3.py` COM shift | fill 4 mm, wait a fixed 500 ms, label contains "4.00 mm" and SOME arrow exists | bounded wait until input, draft, validated draft, label `\|Δr\| 4.00 mm` and the view's COM vector (0, 4, 0) mm agree; then 5 mm; replay → setup (the run's COM, then the draft's again); back to 0 mm | review F5: the debounced update can take longer than 500 ms under load, and the old check could pass on the previous value's arrow (shown under CPU throttling) |
| `backend/tests/test_process_restart.py` | orphan check via `/proc` (Linux only; skipped on macOS) | unchanged, plus a portable POSIX `ps` version that also runs on macOS | the Mac review could not run the `/proc` check; a skip is not a pass |
| `site/tests/live_backend.test.js` | L1–L13 | + L14: a real backend process restarted with the adapters loaded (WebSocket and polling consumers, a reconnect without restart, a low-rate replay) | F2 |
| new suites | — | `backend/tests/test_provenance.py`, `test_stream_identity.py`, `test_run_tests.py`; `site/tests/v51.test.js`; `site/tests/browser_v51.py`; a schema test for recorder output and datasets | F1–F3 and the dataset schema drift |

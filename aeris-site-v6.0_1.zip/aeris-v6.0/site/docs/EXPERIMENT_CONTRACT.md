# Experiment contract — configuration revision 1.2

Revision 1.2 of `aeris-config/1` completes the general initial state and the explicit objective needed for 3-D
research. Revisions 1.0 (the browser engine's fields) and 1.1 (research blocks) are still read unchanged; a
configuration that does not use the 1.2 fields means exactly what it meant before. The research backend executes
1.2; the browser engine (DEMO) refuses every 1.2 feature with a capability error naming the field — nothing is
simplified, projected or dropped silently.

Code: `backend/aeris_backend/config/normalize.py` (`_reference`, `reference_defaults`), `config/validate.py`
(`_initial_checks`, `_reference_checks`), `simulation/setup.py` (`initial_state`, `RunContext`),
`simulation/__init__.py` (`executed.initial_state`, `executed.reference`, recovery target), browser mirror
`site/js/platform/config.js` (`explicitState`, `initialPose`, `explicitFromLegacy`); schema
`site/schemas/aeris-config-1.schema.json`; tests `backend/tests/test_experiment_contract.py`,
`site/tests/v5.test.js` R1–R5.

## 1. Initial state

| Field | Unit / frame | Rule |
|---|---|---|
| `initial.attitude_q` | `[w, x, y, z]`, scalar first, Hamilton product, rotates **body → world**; world z up; body axes along the cube edges from the pivot corner | unit within ±1e-6 (renormalised and stored normalised, with a warning if not exactly 1); otherwise an error on `initial.attitude_q` |
| `initial.body_rate_dps` | °/s, **body axes** | each component −200…200 °/s |
| `initial.wheel_speeds_rpm` | rpm, relative to the body, one per wheel | as before |

**Precedence and conflicts.** An explicit attitude replaces the legacy `tilt_deg`, `azimuth_deg` and `reference`:
those must be `null` or absent, otherwise the request is refused (they would describe a different attitude).
An explicit body-rate vector replaces the legacy `rate_dps` (which must then be null or absent); with an explicit
attitude in corner mode, a non-zero legacy `rate_dps` is refused because it has no axis. Without the explicit
fields the legacy inputs keep their meaning exactly.

**Support model.** Edge mode rotates only about the support edge (body x): the attitude must be a rotation about
x from the edge reference, `q = [cos(φ/2), sin(φ/2), 0, 0]` with `φ = 45° + θ`, and the body rate must be
`[ω_x, 0, 0]`; anything else is refused with the angle by which it leaves that axis.

Each run records `executed.initial_state`: where the attitude and rate came from (`explicit attitude quaternion`
or the legacy inputs), the quaternion actually used, the body rate, the resulting lean from the balance attitude,
the wheel speeds and the frame conventions.

## 2. Reference and objective (corner mode)

```json
"reference": {"attitude": "balance", "heading": "hold" | "free", "yaw_deg": 0}
```

* `attitude: "balance"` is the only attitude a fixed pivot can hold with bounded wheel speeds (the centre of mass
  above the pivot). **Any other attitude target is refused** — the engine does not add a free-flight or contact
  solver to pretend otherwise, and never projects a request onto a different target.
* `heading: "hold"` — hold the initial heading plus `yaw_deg` and follow the scheduled `commands` (`yaw_step`).
* `heading: "free"` — no heading objective: the yaw rate is damped but no heading is regulated.

Supported combinations (refused otherwise, with the field and the reason):

| Controller | `heading: hold` | `heading: free` |
|---|---|---|
| PID, LQR (decoupled), COM-adaptive LQR | ✓ | ✓ (yaw rate damped only) |
| coupled MIMO LQR (`structure: mimo-lqr`) | ✓ | ✗ — it regulates the full attitude including the heading |
| nonlinear PD | ✓ | ✓ (heading gain 0) |
| `none` | accepted with a warning: no torque, the reference is not tracked | ✓ |

With `heading: free`: `commands` are refused (no heading to command), a non-zero `yaw_deg` is refused, and
recovery criteria that require the heading (`recovery.yaw_objective: hold`) are refused.

**Requested vs achievable.** Every run records `executed.reference`:

* `requested` — the objective as configured;
* `controller_target` — the balance axis of the controller's own model (body frame);
* `plant_equilibrium` — the true balance axis of the simulated plant (the COM direction, including attachments,
  shifts and components);
* `target_offset_deg` — the angle between the two: non-zero when the controller's model does not know the build
  (controllers with integral or adaptive action can remove it). The research recovery criteria are always
  evaluated against the **plant's** equilibrium, so an unreachable model target can never be reported as tracked.

## 3. Recovery statement

`research.recovery` states its target (e.g. "balance attitude (COM above the pivot) at the commanded heading: the
initial heading + 10°"), the thresholds (`attitude_error_deg`, `rate_dps`), `hold_s`, the deadline `max_time_s`,
the yaw objective requested and effective, and any explicit objective change after a fault (e.g. a wheel failure
that gives up yaw control: `objective_effective: free`, with the time and reason in `objective_note` and a
`yaw_objective` timeline event). It separates:

| Field | Meaning |
|---|---|
| `first_recovery_s` (`t_s`) | first time the criteria had held for `hold_s` |
| `sustained`, `sustained_from_s` | the criteria still hold at the end of the window, from that time on |
| `exits_after_recovery`, `last_exit_s` | later exits from the criteria after the first recovery |
| `fell_after_recovery` | a fall after a recovery |

Sweeps declare which success criterion their analysis uses (`criterion`: `legacy`, `research` or
`research_sustained`, sweep revision 1.2) and report first recovery, sustained recovery, later exits and falls after
recovery separately.

## 4. Carried through

* **Schemas**: `aeris-config/1` (1.2 fields), `aeris-run/1` revision 1.3 (`executed.initial_state`,
  `executed.reference`, estimator timing), `aeris-sweep/1` revision 1.2 (`criterion`, path variables).
* **Validation**: backend (authoritative, field-specific errors) and the browser mirror for early feedback.
* **Capabilities**: `/capabilities` reports the revisions and the supported objectives.
* **Frontend**: the Lab's "Initial condition" group switches between "Tilt and rate" and "Quaternion + body rate"
  (with a Normalise button and the conversion from the legacy inputs); "Control objective" and "Estimate age
  limit" in the research options; the results panel shows the executed initial state, requested objective vs
  equilibrium, metric version and estimate age.
* **Sweeps**: any numeric configuration path can be a variable (`path`), e.g. `initial.azimuth_deg`,
  `sensor.latency_ms`, `actuator.wheel_health.x`; a sweep that varies a legacy input of an explicit-state setup is
  refused.
* **Storage, replay, export, reproduction**: the fields are part of the stored configuration and record, survive
  export/import and repeated normalisation unchanged, and a reproduction re-runs them exactly.

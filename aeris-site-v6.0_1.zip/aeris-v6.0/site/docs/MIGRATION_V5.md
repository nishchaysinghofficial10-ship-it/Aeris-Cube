# Migrating from v4 to v5: schemas, database, metrics, API, tests

Nothing stored by v4 is rewritten. v5 reads every v4 file, record and database; changes that would alter old data
are made by creating new records with lineage.

## 1. Versions

| Item | v4 | v5 | Reading older versions |
|---|---|---|---|
| backend / engine | 1.0.0 / aeris-research-engine 1.0.0 | 1.1.0 / aeris-research-engine 1.1.0 | — |
| `aeris-config/1` revision | 1.1 | **1.2** (explicit initial state, reference block, estimate age limit) | 1.0, 1.1 read unchanged |
| `aeris-run/1` revision (backend records) | 1.2 | **1.3** | 1.1 (browser), 1.2 (v4 backend) read and displayed as saved |
| `aeris-sweep/1` revision | 1.1 | **1.2** (declared `criterion`) | older sweeps use the legacy criterion |
| research metrics | version 1 (implicit) | **version 2** ([METRICS.md](METRICS.md)) | version 1 shown as saved, never relabelled |
| parameter sets | revision 1 (bare parameter names) | **revision 2** (configuration paths, per-run coverage, `supersedes`) | bare names mean `params.<name>` |
| database schema | 1 | **2** ([DATABASE.md](DATABASE.md)) | migrated in place when opened; newer schemas refused |
| telemetry | frame format only, no live path | `aeris-telemetry-ndjson/1` ([TELEMETRY.md](TELEMETRY.md)) | — |

## 2. Configuration changes that can refuse a v4 request

* **Recording rate**: a `record_hz` that does not divide the integration rate (backend) or the loop rate (browser
  engine) is now refused with a `record_hz` error and the nearest valid rates ([RECORDING.md](RECORDING.md)). v4
  accepted it and mislabelled the executed rate. Stored v4 records are detected and explained when opened; a
  reproduction uses the rate v4 executed (listed in `config_changes`).
* **Conflicting initial inputs**: an explicit `initial.attitude_q` / `body_rate_dps` together with the legacy
  tilt/rate inputs is refused (v4 had no explicit fields).
* **Unsupported objectives**: `reference.heading: free` with the coupled MIMO LQR, yaw commands or a heading
  offset with a free heading, and a recovery yaw objective the controller does not control are refused
  ([EXPERIMENT_CONTRACT.md](EXPERIMENT_CONTRACT.md)).
* **Parameter sets**: `g` is refused (a constant); every value is checked for unit and shape.
* **Estimator timing**: `estimator.stale_after_s` is range-checked; a sensor model without dynamic acceleration
  combined with a compensating filter gives a warning.

## 3. Engine changes that alter results

aeris-research-engine 1.1.0 changes trajectories only for runs with the **cf3d or mekf** estimator (the controller
now receives the estimate predicted to the control time; MEKF reset Jacobian; compensated alignment) and the
recorded `est_*` columns of estimator runs. Other configurations reproduce v4 records exactly (the metric version
aside): of the six v4 backend records in `site/tests/fixtures/backend_records.json`, the five without a 3-D
estimator reproduce bit-identically on v5 and the MEKF record differs, with the engine change named in the
verdict's `explanations` (`experiments/reproduce.py ENGINE_CHANGES`). (Bit-identical on the Linux x86-64 machine
that generated them; on other platforms within the documented tolerance with the same outcome — see
[MIGRATION_V5_1.md](MIGRATION_V5_1.md) §5 for the v5.1 test rule.)

## 4. Records: new fields (revision 1.3)

`executed.initial_state`, `executed.reference` (requested vs controller target vs plant equilibrium),
`executed.estimator.stats` (accepted, duplicate, out-of-order samples; initialisation time), `samples.schedule`,
per-step `est_age` / `est_valid` columns, `research.metrics_version`, `research.estimator` age statistics,
`research.recovery` (target text, first/sustained recovery, exits and falls after recovery),
`reproduction.metrics_version`, `reproduction.parameter_set.coverage`, `lineage` (reproduction, reanalysis, retry),
timeline events `estimator_init`, `estimate_stale`. The browser shows them when present and old records without
them unchanged.

## 5. Database

Opening a v4 database adds `jobs.attempts`, the unique indexes that prevent a second run for one job or sweep row
(only when the existing data allow them; v4 duplicates are kept and reported as migration warnings by `/health`)
and the `migrations` table. Back up first: `python -m aeris_backend.tools.dbtool backup --db <file>`.

## 6. API and capabilities

New endpoints: `POST /jobs/{id}/retry`, `POST /runs/{id}/reanalyze`, `POST /sweeps/{id}/analyze`,
`GET /datasets/{id}/export`, `GET /hardware/recordings`, `GET /hardware/recordings/{id}/export`,
`GET /telemetry/status | files | frames`, `POST /telemetry/connect | disconnect | recordings/start | recordings/stop`,
`WS /telemetry/live`. Changed: `/capabilities` → `hardware.bridge` is now the bridge **name** (it was a status
object), `hardware.live` is true only for a declared physical source streaming now, a new `telemetry` block
describes the telemetry path, `config.revisions` lists every revision read (1.0, 1.1, 1.2), and new `experiment`,
`metrics`, `sweep.revision` and `sweep.criteria` fields report the v5 contract; `/hardware/status` returns the telemetry status (the old fields `connected`,
`live`, `last_frame_t`, `frames`, `dropped`, `reason` are kept; `frames` and `dropped` count the current source). Final datasets are immutable at the repository
level. `POST /hardware/recordings` refuses a recording whose provenance says synthetic but whose flag says
otherwise. New settings: `AERIS_TELEMETRY_*`, `AERIS_SITE_DIR` / `--serve-site`, `AERIS_MAX_JOB_ATTEMPTS`,
`AERIS_SUBSCRIBER_QUEUE`, `AERIS_ALLOW_FAULT_INJECTION` (tests).

## 7. Browser

HARDWARE mode becomes selectable when a reachable backend reports telemetry (it was always disabled); the Lab has a
Telemetry tab (`#lab/telemetry`). Connected to a v4 backend (which reports configuration revisions 1.0 and 1.1
only), the site refuses revision-1.2 features and declared sweep criteria with a capability error instead of
sending them. The compare panel adds a "Research metrics" table (definition version, research recovery, attitude
error RMS [°], IAE [°·s], ISE [°²·s]); runs of different metric versions are flagged as not comparable and a
version-1 ISE is withheld. The status strip shows `SYNTHETIC TELEMETRY` for emulator data (never HARDWARE).
Config revision 1.2 is written by the browser's normaliser; records saved in the browser are not migrated.

## 8. Test expectations changed on purpose

Each change follows a deliberate behaviour change above; no assertion was weakened to obtain a pass.

| Test | v4 expectation | v5 expectation | Why |
|---|---|---|---|
| `backend/tests/test_schemas.py`, `test_service.py` | run `schema_revision == "1.2"` | `"1.3"` (and a new test that v4 records still validate) | new record revision (§4) |
| `test_service.py` capabilities | `hardware.bridge.connected is False` | `hardware.live is False`, `telemetry.available`, `telemetry.read_only` | capability shape (§6) |
| `test_service.py` parameter sets | bare names (`m`, `a`), "partially measured" | paths (`params.m`), per-run coverage, `g` refused | parameter sets revision 2 ([PARAMETERS.md](PARAMETERS.md)) |
| `site/tests/engine.test.js` | `record_hz: 200` | `record_hz: 125` | 200 Hz does not divide the 500 Hz loop (defect D); the test only uses the first sample and whole-run hashes |
| `site/tests/v4.test.js` | config revision 1.1 | `CFG.REVISION` (1.2) | config revision 1.2 |
| `site/tests/service.test.js` | HARDWARE reason "not implemented"; `connect()` → `not_implemented` | reason names the research backend; `connect()` → `unavailable` without a backend | telemetry path implemented |
| `site/tests/schema.test.js` | event types = browser + v4 fixture | + v5 fixture (`estimator_init`, `estimate_stale`) | new timeline events |
| `site/tests/browser_v3.py` | HARDWARE refusal "not implemented" | "Telemetry reaches this site through the AERIS research backend" | same as above |
| `site/tests/browser_v4.py` | "Research engine 1.0.0" hard-coded; playback checked after a fixed 0.9 s pause | the version the running backend reports; bounded wait until the time advances | engine 1.1.0; frame rate depends on the machine (software WebGL), not on the behaviour under test |
| `site/tests/browser_check.py` | fixed pauses before reading results; Twin-to-Lab checked by outcome only; Play/Pause read after a fixed 0.7 s | bounded waits on the completion condition; Twin-to-Lab checks that a new run of exactly that setup is open; Play/Pause waits (bounded) for t > 0.2 s and also requires that the time does not move after Pause; the benchmark must be labelled UNVERIFIED HISTORICAL | review requirement (bounded waits); stricter checks |

# AERIS · Research platform

What the platform is, what it claims and does not claim, and the rules behind its data, colours and experiments.

## 1. Names and story

**AERIS**: Autonomous Experimental Reaction-wheel Inertial Stabilization. STABLIX is only the umbrella ("a STABLIX project", footer).

| Name | What it is | Colour |
|---|---|---|
| RWIP | The earlier single-axis reaction-wheel inverted pendulum (LQR from Lagrangian dynamics, IMU sensor fusion) | physical (cyan) |
| **AERIS Cube** | The physical three-axis reaction-wheel cube; balances on an edge and on a corner | physical (cyan) |
| **AERIS Twin** | The physics-based digital model of the cube (browser engine `aeris-twin 0.3.0`) | digital model (blue) |
| **AERIS Lab** | The research environment: experiments, controller sets, sweeps, replay, comparison | research (violet) |
| AERIS research backend | The Python engine behind SIMULATION mode (`backend/`, `aeris-research-engine 1.0.0`): reproduces AERIS Twin for every configuration the browser can run and adds the research features (MIMO LQR, nonlinear PD, MEKF, custom plants and wheel sets, events, impulses, research metrics, sweeps at scale) | research (violet) |

The story on the home page: RWIP "I learned feedback control." → AERIS Cube "I extended the concept into a three-axis physical system." → AERIS Twin "I reconstructed the cube's dynamics computationally." → AERIS Lab "I turned the digital model into an experimental attitude-control research platform."

AERIS Twin is called a *physics-based digital model*. It is not called a validated digital twin until hardware runs have been compared with it (§8). The same holds for the research backend: both engines run with nominal design parameters.

## 2. Claim labels

Every result carries text labels; colour only repeats them.

| Family | Label | Used when |
|---|---|---|
| Source (what the screen shows now) | SIMULATION | a run just computed by a model |
| | HARDWARE | data measured on the cube (only imported recordings today) |
| | REPLAY | a saved recording played back |
| Claim (what the data is) | SIMULATED | model output |
| | MEASURED | measured on the cube |
| | NOMINAL | computed with design values, not measurements |
| | VALIDATED | model agrees with hardware runs within stated errors (not used yet) |
| | HARDWARE DATA PENDING | no measurements supplied yet |
| | SIM ↔ HARDWARE VALIDATION PENDING | no comparison exists yet |
| Marks (not research data) | DEMO MODE | computed in the browser in DEMO mode (small, exploratory) |
| | DEMO DATA | illustrative values (not used anywhere at present) |
| | MOCK DATA | returned by the mock research backend |
| | EXAMPLE | a built-in example with a fixed setup |
| | PARTIAL | a cancelled sweep; only finished runs included |

The system status strip under the navigation repeats the state of the current view: AERIS SYSTEM (mode) · SOURCE · MODEL · CONTROLLER · EXPERIMENT · VALIDATION.

## 3. Colour semantics

Tokens: `js/platform/tokens.js`, mirrored in `css/base.css` (a unit test checks they agree).

| Role | Colour | Rule |
|---|---|---|
| Brand | lime `#c0ff00` | brand and active UI only (focus, current tab, primary button, selected object). Never data, never a controller. |
| Status | stable `#3ecf6e`, warning `#ffb020`, failure `#ff5a4f` | outcomes and limits: recovered / settling band; saturation and speed limits; fall and failed wheels. Always with an icon and a label. |
| Systems | physical cyan `#45d4ee`, twin blue `#6d95ff`, research violet `#b69cff`, replay `#c7ccd6` | where data comes from |
| Controllers | PID `#3175a4` ●, LQR `#37a69a` ■, COM-adaptive LQR `#9c84c7` ▲, Nonlinear PD `#b98a3e` ★, Coupled MIMO LQR `#37a69a` □ | equal weight; each has a marker shape |
| Chart neutrals | `#f2f4f7`, `#9aa3af`, `#6f7a88` | single-run series; wheels X/Y/Z by line style (solid / dashed / dotted) |
| Loads | magenta `#e063a7` | external forces and torques |
| 3-D axis triads | red / green / blue x, y, z | the one documented exception (labelled axes) |

Controller palette check (dataviz validator, dark surface `#0b0c0e`): lightness band, chroma floor, normal-vision separation (worst ΔE 15.3) and contrast pass; colour-vision-deficiency separation is in the 6–8 floor band (worst ΔE 6.9, deutan), which is acceptable only with secondary encoding. Hence the marker shapes on every controller line and in every legend. The suggested steel-blue / cyan / violet at equal lightness failed CVD separation (ΔE 2–4), so the chosen trio spreads lightness slightly. v4 adds the backend-only controllers: Nonlinear PD `#b98a3e` ★ (the four-colour set PID/LQR/adaptive/nonlinear re-validated with the same result: all checks pass, CVD worst ΔE 6.9 with markers required) and Coupled MIMO LQR, which shares the LQR colour and is told apart by its open-square marker □ and its label.

Design: small and medium radii (4 / 8 px), no glow, black ground, Exo 2 / Inter / JetBrains Mono.

## 4. Data model

JSON Schemas (draft 2020-12) in `/schemas`, generated from the modules by `build/build_schemas.js` and checked by `tests/schema.test.js` and, against real backend output, by `backend/tests/test_schemas.py`. v4 changes are additive revisions (`SCHEMA_EXTENSIONS.md`).

| Format | Schema file | Notes |
|---|---|---|
| `aeris-config/1` rev 1.0 / 1.1 | `aeris-config-1.schema.json` | one setup; defaults fill omitted fields; revision 1.1 adds optional research blocks (research backend) |
| `aeris-run/1` rev 1.1 / 1.2 | `aeris-run-1.schema.json` | setup, derived data, design, samples, metrics + definitions, outcome, event timeline, `experiment_id`, `collection`, `origin`, `validation`, `group`; revision 1.2 (backend) adds `research`, `termination`, `executed`, `reproduction` |
| `aeris-runs-bundle/1` | `aeris-runs-bundle-1.schema.json` | several runs |
| `aeris-sweep/1` rev 1.0 / 1.1 | `aeris-sweep-1.schema.json` | definition, or result with rows and analysis; revision 1.1 adds path variables, distributions, seed strategies, estimators |
| `aeris-dataset/1` | `aeris-dataset-1.schema.json` | runs and sweeps with provenance (`status: exploratory | final`) |
| `aeris-hardware-run/1` | `aeris-hardware-run-1.schema.json` | real telemetry recordings |
| `aeris-job/1` | `aeris-job-1.schema.json` | batch job status |
| `aeris-telemetry-frame/1` | `aeris-telemetry-frame-1.schema.json` | live frame (no device link exists yet) |
| `aeris-parameter-set/1` | `aeris-parameter-set-1.schema.json` | measured model parameters with unit, method, date and evidence (none supplied yet) |
| `aeris-validation-protocol/1` | `aeris-validation-protocol-1.schema.json` | acceptance thresholds registered before any recording is evaluated |

Backward compatibility: every revision only adds fields. Records saved by site v2 are upgraded once on load (`AERIS_SCHEMA.normalizeRun`): they get an experiment ID, `collection`, `origin`, `validation: nominal` and an event timeline rebuilt from their recorded samples (marked `rebuilt: true`). Old `ARC-EXP-000n` references become `AERIS-EXP-00000n`. Old routes (`#use…`, `#lab-…`, `#hardware`) redirect. Records from the research backend (revision 1.2) are validated strictly and kept exactly as the backend produced them; the browser never rebuilds their derived values or design with its own model.

## 5. AERIS Twin 0.3.0

The engine (`js/core.js`) integrates rigid-body dynamics with RK4 and a zero-order hold at the loop rate; LQR gains come from the continuous algebraic Riccati equation (matrix sign function); PID gains by pole placement; the COM-adaptive law is β̂̇ = γ·Ω, clamped to ±6°. Edge mode is a hinge model; corner mode is a full 3-D model with quaternions and the full inertia tensor.

New in 0.3.0 (all off by default; with defaults the engine is bit-identical to 0.2.0 on 13 reference cases, `tests/fixtures/twin_v0.2_reference.json`):

- sensor model (edge mode, non-ideal estimators): gyro noise, bias, bias random walk, accelerometer noise, quantisation, latency, packet dropout; tiers BASIC / ADVANCED / EXPERT in the Lab;
- actuator model: first-order motor torque lag, per-wheel torque capability (health);
- COM shift of the build (x, y, z) in addition to the base offset;
- metrics: RMS attitude error, control effort ∫Σ|T|dt, time at the speed limit, lean margin;
- an event timeline computed at every integration step;
- `controller.structure: "mimo-lqr"` is recognised and rejected ("planned for the research backend").

Honest gaps of the browser engine: corner mode uses ideal state feedback; the IMU is sampled at the loop rate; corner controllers are designed per axis on averaged inertia while the plant uses the full tensor. The research backend (§5a) closes these gaps in SIMULATION mode; the browser engine refuses such configurations with a capability error instead of simplifying them.

## 5a. AERIS research backend 1.0 (v4)

`backend/` (Python 3.12, FastAPI, NumPy/SciPy, SQLite). The same conventions as AERIS Twin (quaternion body→world, relative wheel speeds, the corner Euler equation with locked-wheel inertia, RK4 with a zero-order hold); every configuration the browser can run gives the browser's results (`backend/tests/test_parity.py`, 25 browser-generated fixtures: without sensor noise, identical outcomes and timelines, metrics within 1e-9 relative and every recorded sample within one unit of its 6th significant digit, most columns bit-identical on the test machine; with sensor noise, identical outcomes and timelines and integral metrics within 0.1 %, because V8 and glibc differ in the last bit of some Gaussian draws). Added: integration rate independent of the control rate; explicit base inertia tensor, rigid components and up to six wheels on arbitrary axes; per-wheel electrical limits, degradation, torque/speed limits and fault durations; impulses and torque bias; lift-off detection; a three-axis IMU at its own rate with dynamic acceleration, latency and dropout; the quaternion MEKF and a 3-D complementary filter; coupled MIMO LQR; a nonlinear model-compensated quaternion PD; bounded least-squares allocation with authority metrics; research recovery criteria; termination reasons; sweeps at scale with paired seeds; jobs, cancellation, persistence and reproduction. Documentation: `PHYSICS.md`, `CONTROLLERS.md`, `ESTIMATION.md`, `SCHEMA_EXTENSIONS.md`, `BACKEND_INTEGRATION.md`.

## 6. Controllers

| | Measures | Assumes | Adapts |
|---|---|---|---|
| **PID** | tilt error, tilt rate, integral of tilt error | linearised tilt model; model mass properties | nothing |
| **LQR** | tilt error, tilt rate, wheel speed | linearised model; model mass properties; nominal inertia | nothing |
| **COM-adaptive LQR** | as LQR | as LQR; a steady wheel speed means a constant COM offset | the balance-angle offset β̂ only (not inertia, gains or motor constants) |
| **Coupled MIMO LQR** (backend) | attitude error vector, body rates, wheel speeds | full-tensor linearisation about upright; model mass properties | nothing |
| **Nonlinear PD** (backend) | quaternion attitude error, body rate, wheel speeds | the model's mass, COM, full inertia tensor, wheel axes (and friction when compensated) | nothing identified; a momentum loop removes a constant COM offset |

Not implemented anywhere: other nonlinear controllers (e.g. sliding mode, energy-based). Source of these descriptions: `js/platform/controllers.js`, checked against the engine by `tests/ui.test.js`; the backend's laws and designs are in `CONTROLLERS.md`. Every run saves the method that actually ran (`executed.controller`); nothing is substituted.

## 7. Experiments

**Single experiment**: one setup, one run, full samples, replay, maths, export.

**Controller set** ("Run PID · LQR · Adaptive"): the same setup run three times; only `controller.type` changes. The runs share a `group` id. Compare shows computed labels per metric: *Lowest settling time* (recovered runs), *Lowest control effort* and *Lowest peak wheel speed* (runs that did not fall), *Largest recovery margin* (fall threshold − peak lean). Ties are reported; there is no overall winner.

**Research sweep**: vary 1–4 parameters (COM x/y/z, initial tilt and rate, torque limit, wheel-speed limit, push magnitude, sensor noise, inertia mismatch), choose controllers and mass configurations, sample by grid, uniform random or Monte Carlo (seeded; each Monte Carlo sample gets its own noise seed). Every controller sees the same points. The browser engine accepts up to 400 runs of up to 10 s (DEMO mode); larger sweeps belong on the research backend.

On the research backend (SIMULATION mode, sweep revision 1.1): any numeric configuration path can be varied; distributions are uniform, untruncated normal (out-of-range samples become invalid rows, never clipped), exact bounded-normal and categorical; seed strategies are paired (default: one noise seed per point shared by every controller), legacy, fixed and independent; controllers include the nonlinear PD and the MIMO LQR; estimators can be crossed with controllers; limits are those the backend reports. Rows keep their sampled values, seed and configuration hash, and the exact configuration of any row can be fetched. A cancelled sweep keeps its finished rows (PARTIAL) with an analysis of those rows only.

Analysis (`AERIS_SWEEP.analyze`, computed only from the rows):

- per controller: runs, valid runs, recovered, recovery rate with a 95 % Wilson interval, recoveries that went through saturation;
- outcome maps for named pairs (domain of attraction tilt × rate, COM stability map, saturation map torque × tilt): one cell per grid point, no interpolation, unrun cells empty;
- recovery probability against each varied parameter (binned when there are more than 10 distinct values);
- distributions (settling time of recovered runs, RMS error, peak wheel speed, effort) as histograms;
- observed limits: largest |value| that recovered and smallest |value| that did not, at the sampled points;
- backend sweeps add the research-criteria recovery rate per controller and paired comparisons (exact two-sided McNemar test on the discordant pairs) when seeds are paired.

Outcome rules (one function for every run): settling band ±0.25° held ≥ 0.5 s; fall at 30° (edge) / 20° (corner) or floor contact; drift by a linear fit over the final window; priority Invalid → Fallen → Drifting → Recovered → Not settled. Event timeline rules: saturation intervals merged across gaps < 50 ms, saturation risk ≥ 90 % and speed limit ≥ 98 % of the wheel-speed limit, estimator warning when |θ̂ − θ| > 0.5° for ≥ 0.2 s.

**Research recovery criteria** (backend records, `config.recovery`, evaluated into `research.recovery`, computed at every integration step): the quaternion geodesic attitude error to the target stays ≤ `attitude_error_deg` (default 0.5°) **and** the body-rate magnitude ≤ `rate_dps` (2 °/s; its vertical component is excluded when yaw is free) continuously for `hold_s` (1 s), reached by `max_time_s` (default: the window). The target is the balance attitude at the commanded heading (`yaw_objective: hold`) or any heading (`free`); if yaw control is given up after a wheel failure, the record says so and the criterion applies to tilt from that time. The legacy outcome keeps its meaning and is reported next to it; the two are never merged (a run can be legacy-*recovered* while failing a heading-hold criterion, `ESTIMATION.md` §8).

## 8. Validation

See the Validation page and `js/platform/validation.js`: RMSE, mean absolute error, peak error, peak-magnitude difference and best time offset per signal, on the overlapping time range, with the simulation interpolated onto the hardware time stamps. Status today: **hardware dataset pending**; the model is NOMINAL. Acceptance thresholds must be set before the first comparison.

Parameter status on the Cube page: NOMINAL (design value) → MEASURED (value, method, date in `hardware.measured`) → VALIDATED (`hardware.validated[key] = true`, only after a published comparison).

The research backend adds the traceable path: measured parameter sets (`POST /parameter-sets`: every value with unit, method, date and evidence; a run is labelled MEASURED only with a complete set), strict ingestion of hardware recordings (`POST /hardware/recordings`, quality report, synthetic data flagged), validation protocols registered **before** evaluation (`POST /validation/protocols`), and comparisons (`POST /hardware/compare`) that are admissible as evidence only for real recordings ingested after their protocol. Software never sets VALIDATED; a person reviews admissible evidence. None of these objects exists for the physical cube yet (`HARDWARE_NEXT_STEPS.md`).

## 9. What is never done

- No invented hardware measurements, controller performance, stability limits, validation errors, findings, domain-of-attraction boundaries, recovery probabilities or datasets. Every number is computed from a run the user can re-run, or comes from `js/site-content.js` with its source.
- No simulated hardware connection; HARDWARE mode stays disabled with its reason.
- No MOCK or DEMO output presented as research output.
- No silent substitution: an engine that cannot run a requested controller, estimator or feature refuses it with the reason; the method that actually ran is saved with every run.
- No guessed backend capabilities: SIMULATION is enabled only after the backend answered its health and capability probe, and only the limits it reported are used.
- The earlier benchmark (PID 6.21 s … Adaptive 1.85 s) is kept on the Results page with its provenance: earlier project simulation runs, traces pending import, not produced by this site.
- Generated visuals (assembly video, render, reference sheet) are labelled AI-generated.

## 10. Adding evidence

Edit `js/site-content.js`: `hardware.status`, `hardware.footage`, `hardware.measured` (value, unit, method, date), `hardware.validated`, `hardware.comparisons`, `evolution` (including failed iterations), `results.findings` (only with a final dataset), `repository` (a real URL), `twin.validation` (only with evidence). Configure the backend in `window.AERIS_CONFIG.researchApi`. On the research backend: store measured parameters with `POST /api/v1/parameter-sets`, register acceptance thresholds with `POST /api/v1/validation/protocols` before recording, ingest recordings with `POST /api/v1/hardware/recordings`, then compare (`HARDWARE_NEXT_STEPS.md`).

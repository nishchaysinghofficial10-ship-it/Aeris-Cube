# AERIS telemetry path (v5, completed in v5.1; v6.0: race-safe resume, one live-provenance rule, device telemetry)

**Status: implemented and tested in software with SYNTHETIC sources only.** No physical cube has been connected
to this software. The protocol below is the reference contract. Since v6.0 the AERIS firmware (`aeris-fw 0.1.0`)
speaks it on its device link ([DEVICE_LINK.md](DEVICE_LINK.md) §7) and each paired device has its own hub on the
backend ([CONNECT.md](CONNECT.md)); other devices either speak it directly or are mapped onto it by a device adapter
(§5, [HARDWARE_HANDOFF.md](HARDWARE_HANDOFF.md)).

```
source ──► transport ──► strict validation ──► normalised stream ──► live clients (WebSocket / polling)
(device,     (TCP NDJSON,    (hello, frame,        (TelemetryHub:          │
 emulator,    file replay,    units, frames,        sequence, gaps,        ├─► recording ──► storage (aeris-hardware-run/1)
 file)        stored rec.)    quaternion)           staleness)             │        └─► export (JSON / NDJSON) ──► replay
                                                                           └─► offline comparison with a simulated run
```

This `/api/v1` path is **read-only**: no transport, adapter, endpoint or page here sends anything to a device. The
v6.0 device path (`/api/v6`, bounded commands over an authenticated device link) is separate: it never adds writes to
recording import, replay or the v1 telemetry endpoints.

## 1. Where the code is

| Part | File |
|---|---|
| Contract (line format, hello, frame checks) | `backend/aeris_backend/telemetry/protocol.py` (frame fields: `hardware/ingest.py parse_frame`) |
| Normalised stream, recording, NDJSON export | `backend/aeris_backend/telemetry/stream.py` (`TelemetryHub`, `recording_to_ndjson`) |
| Conservative provenance (trust, segments, lineage, export identities) — v5.1 | `backend/aeris_backend/telemetry/lineage.py` (`classify`, `export_segments`) |
| Transports (TCP client, file replay, line splitter) | `backend/aeris_backend/telemetry/transport.py` |
| Standalone synthetic emulator | `backend/aeris_backend/telemetry/emulator.py` |
| Device adapter interface and mapping adapter | `backend/aeris_backend/telemetry/device.py` |
| Bridge (the existing abstraction) | `backend/aeris_backend/hardware/bridge.py` (`HubBridge`, `NoBridge`) |
| REST / WebSocket endpoints | `backend/aeris_backend/api/app.py` (`/telemetry/*`, `/hardware/*`) |
| Browser adapter | `site/js/adapters/hardware-telemetry.js` |
| Lab panel (HARDWARE mode, Telemetry tab) | `site/js/ui/telemetry-ui.js` |
| Per-device hubs (v6.0): telemetry of paired devices, continuity across routes, catch-up | `backend/aeris_backend/devices/service.py` |
| Tests | `backend/tests/test_telemetry.py`, `test_provenance.py`, `test_stream_identity.py`, `test_live_provenance.py` (v6.0), `test_devices_telemetry.py` (v6.0), `site/tests/v5.test.js` (T1–T5), `site/tests/v51.test.js` (W1–W8, P1), `site/tests/resume.test.js` (v6.0), `site/tests/procs.test.js` (v6.0), `site/tests/live_backend.test.js` (L13, L14, L15), `site/tests/browser_v5.py`, `site/tests/browser_v51.py` |

## 2. The reference contract `aeris-telemetry-ndjson/1`

One JSON object per line, UTF-8, `\n`-terminated, at most 65 536 bytes. Every object has a `type`.

**hello** — the first line of every connection (session):

```json
{"type": "hello", "protocol": "aeris-telemetry-ndjson/1",
 "device": {"id": "cube-01", "kind": "physical", "firmware": "1.4.2"},
 "synthetic": false, "mode": "corner", "nominal_rate_hz": 200,
 "conventions": {"quaternion": "w,x,y,z; body to world; Hamilton product",
                 "body_axes": "x, y, z along the cube edges from the pivot corner",
                 "world_axes": "z up",
                 "time": "seconds since the session start (monotonic)"}}
```

* `device.kind` is `physical`, `emulator`, `file-replay` or `test`. **`emulator` and `test` must declare
  `synthetic: true`; `physical` must declare `synthetic: false`.** `synthetic` is required and never inferred.
* `conventions` must equal the four strings above exactly. A device with other conventions (x,y,z,w order,
  NED world axes, other body axes, µs counters…) is converted by its device adapter; the hub never guesses.
* `lineage` (optional, additive in v5.1, at most 8 KiB): written by the backend's own NDJSON exports — which
  recording the session was exported from and what its source originally declared:
  `{"derived_from": "AERIS-HW-000123", "exported_by": "AERIS backend NDJSON export", "original_device": {…},
  "original_synthetic": true, "trust": "synthetic" | "declared-physical" | "unknown", "reason": "…",
  "generation": 3, "ancestry": [{"derived_from", "generation", "trust", "original_synthetic", "original_device"}, …],
  "ancestry_trust": "synthetic", "ancestry_omitted": 0, "export": {"converted": {"t": "ms → s"}, …}}`.
  A hello whose lineage says `trust: "synthetic"` (or an `original_synthetic` that is not `false`, or an
  `ancestry_trust`, ancestry reference or v5.1 nested ancestor that is synthetic) makes the session synthetic, whatever
  else the hello says; anything unknown in it makes the session at most unknown. Sources that do not send `lineage`
  are unaffected. **v5.2 (review finding G2 of v5.1):** the lineage is flat and bounded — `ancestry` lists at most 12
  compact references (the parents and the 4 oldest, i.e. the original sources; middle generations are dropped first and
  counted in `ancestry_omitted`); `ancestry_trust` is the least trustworthy status of every ancestor, listed or not;
  every exported lineage stays within 6 KiB. v5.1 wrote nested `ancestors` instead, which grew with every
  export → replay → re-record generation until the hello broke this limit; such documents are still read (and
  flattened by the next export), never rewritten.

**frame** — one sample (the fields of `aeris-telemetry-frame/1`):

| Field | Unit | Rule |
|---|---|---|
| `t` | s | since the session start; finite, ≥ 0, strictly increasing within a session |
| `seq` | count | required in a stream; +1 per sample |
| `q` | – | `[w, x, y, z]`, body → world, unit within ±1e-3 (corner/free) |
| `theta` | rad | tilt about the support edge (required in edge sessions) |
| `w` | rad/s | body rate, body axes |
| `wheel_rpm` | rpm | wheel speeds relative to the body, wheels x, y, z |
| `torque_cmd`, `torque_meas` | N·m | commanded and measured motor torque per wheel |
| `imu.gyro`, `imu.accel` | rad/s, m/s² | raw IMU in body axes |
| `status` | – | `ok`, `idle`, `calibrating`, `fault`, `estop` |
| `units` | – | optional; if present every entry must equal the contract unit — **units are checked, never converted** |

**status** `{"type": "status", "state": "…"}` is recorded as an event (not a sample); **bye** ends the session.

## 3. Normalised stream rules (`TelemetryHub`)

| Situation | Handling | Counter / reason |
|---|---|---|
| not UTF-8, not JSON, not an object, unknown `type`, empty, > 64 KiB | line rejected | `not_utf8`, `not_json`, `not_an_object`, `unknown_type`, `empty_line`, `line_too_long` |
| frame before a valid hello (new connection, after `bye`, after a disconnect) | rejected | `no_valid_hello` |
| invalid hello | reported; frames refused until a valid hello | `invalid_hello` |
| wrong declared unit | rejected | `unit_mismatch` |
| non-unit quaternion | rejected | `non_unit_quaternion` |
| other field error (types, lengths, NaN, mode) | rejected | `invalid_frame` |
| `seq` equal to the last | dropped | `duplicates` |
| `seq` lower than the last | dropped (no re-ordering buffer: late frames are lost) | `out_of_order` |
| `seq` jumps | accepted; missing count added | `gaps`, `dropped_by_source` |
| `t` not increasing | rejected | `time_not_increasing` |
| no frame for `stale_after_s` (0.5 s) while connected | stale event; cleared by the next frame | `stale_events` |
| connection lost / restored | disconnect and connect events; a new hello starts a new session (seq and t may restart) | `disconnects`, `reconnects` |
| line cut by a disconnect | rejected | `truncated_line` |

Accepted frames get a hub-wide index `n` (strictly increasing, never reused **within one backend process**; see
§11 for what a client does across restarts) and the hub's `segment` number (one per valid hello; v5.1). **Slow consumers** have bounded
queues (512 frames): a client that does not keep up loses its *oldest* queued frames, the count is reported to it,
and the reader never blocks. At most 16 subscribers (the API allows 4 live WebSockets by default); the last 2 000
frames are kept for polling clients.

## 4. Transports

* **TCP NDJSON** (`TcpNdjsonSource`): connects to `host:port`; **loopback only** (`127.0.0.1`, `::1`,
  `localhost`) unless the backend is started with `AERIS_TELEMETRY_ALLOW_REMOTE=1`. Bounded exponential
  back-off (0.2 s → 5 s) on refused connections and after disconnects; every attempt, connect and disconnect is
  reported. The socket is never written to.
* **File replay** (`FileReplaySource`): an NDJSON session file from the telemetry directory
  (`AERIS_TELEMETRY_DIR`, default `./data/telemetry`; paths outside it are refused), or a stored recording
  converted by `recording_to_ndjson`. Paced by the recorded `t` (speed factor; 0 = as fast as possible). The
  transport kind is `file`, so the stream is marked **REPLAY**.
* **Standalone emulator** (`python -m aeris_backend.telemetry.emulator`): a separate process serving the
  contract on `127.0.0.1:47100`. Its frames are states simulated by the AERIS research engine with **nominal
  parameters** plus seeded synthetic IMU readings; every session's hello says `kind: emulator`,
  `synthetic: true`. Deterministic faults for testing: `--faults drop=0.01,duplicate=0.005,reorder=0.005,
  malformed=0.002,bad_quaternion=0.002,wrong_units=0.002,disconnect_after=2000,stall_after=500,stall_s=1.0,
  restart_clock=1`. `--write FILE --frames N` writes one session to a file instead of serving.

## 5. Device adapters (`telemetry/device.py`)

`DeviceAdapter` has two methods — `hello()` and `decode(line) → [messages]` — and **no method that sends
anything**. `ContractAdapter` passes a contract-speaking device through; `MappedJsonAdapter` maps a device that
sends one JSON object per line with its own names, units, quaternion order (`wxyz`/`xyzw`), body axes (a proper
rotation `C`: contract vector = C · device vector), world axes (`D`, e.g. NED → z up), clock (scale, counter
wrap) and status codes. Mirrored axes, unknown status codes and missing fields are errors with their field names;
an adapter error is a rejected line, never a crash. `MAPPING_TEMPLATE` lists every entry to fill in. Mappings are
configured without code changes: `AERIS_TELEMETRY_ADAPTERS=adapters.json` (`{name: mapping}`, checked at start-up)
and `"adapter": name` in the connect request. A file replayed through an adapter is fed as fast as it is decoded
(the pacing uses contract time stamps).

## 6. Provenance rules

* The software reports a physical device only as **declared** by its hello (`declared_physical`); it can never
  verify one (`physical_verified` is always `false`).
* A synthetic source is labelled **"SYNTHETIC EMULATOR — not the physical cube"** (or TEST SOURCE, or
  **SYNTHETIC REPLAY** for the replay identity below) in the API status, the Lab banner, the 3-D view label, the
  status strip (**SYNTHETIC TELEMETRY**, never HARDWARE), the recordings list, exports (file names end in
  `-SYNTHETIC`), replays (**REPLAY · SYNTHETIC …**), datasets (`provenance.contains_synthetic`, `synthetic_members`,
  source `synthetic-telemetry`) and comparisons.
* Capabilities report `hardware.live = false` unless a declared-physical, non-replayed, non-stale source is
  streaming.
* **One conservative rule for live sources (v6.0, review finding V52-2 of v5.2).** v5.2 classified a live source by
  its hello's own `kind` and `synthetic` flag only: a hello that declared `physical` / `synthetic: false` while its
  lineage named a synthetic or unknown ancestor (`ancestry_trust`, an ancestry reference, `original_synthetic`, a v5.1
  nested ancestor, `trust: "unknown"`) was reported as a live physical device. The live status, `/capabilities`,
  every WebSocket batch's `provenance`, the recorder, the exports and the comparison evidence now use the same rule
  (`lineage.source_trust`, the recorder's `_hello_trust` plus the whole lineage history): any synthetic sign →
  `synthetic`; a missing or ambiguous declaration or an unknown ancestor → `unknown`; `declared-physical` only when the
  source declared physical and nothing behind it says otherwise. **Unknown is reported as its own class** (`trust:
  "unknown"`, `synthetic: false`, `declared_physical: false`, label *UNKNOWN ORIGIN*, never live hardware), distinct
  from synthetic; a hello with a lineage is a copy (`derived`), never a live measurement. A recording of an
  unknown-origin source is stored with `synthetic: true` and `provenance.synthetic_flag_reason: "unknown-origin"`, so
  it is never evidence while its class stays unknown. `physical_verified` is always `false`.
  Tests: `backend/tests/test_live_provenance.py` (control, `ancestry_trust`, an ancestry reference,
  `original_synthetic`, unknown trust, legacy nesting, missing lineage, ordinary sources — over the status, the
  capabilities, the WebSocket and the recording).
* A comparison with a synthetic recording is computed and stored, but `evidence.admissible_as_validation_evidence`
  is `false` with the reasons; with a validation protocol its acceptance block is inadmissible as well. **No
  comparison ever changes a model's validation status.**

**Conservative provenance end to end (v5.1, review finding F1 of v5).** In v5 a recording that switched from a
declared-physical source to the emulator while recording was stored as synthetic, but its NDJSON export carried only
the FIRST hello (`physical`, `synthetic: false`): replaying it and recording the replay produced a recording that
looked physical. Now trust only ever travels **down** (`telemetry/lineage.py`):

| Trust class | When | Evidence? |
|---|---|---|
| `synthetic` | the document says synthetic; any source segment is synthetic, `emulator` or `test`; any ancestor in the lineage of a replayed export is synthetic | never |
| `declared-physical` | every segment was declared `physical` (or a `file-replay` declared `synthetic: false`) and nothing in the lineage is synthetic — a declaration, never a verification | only an original recording (not `derived`), compared under a validation protocol registered before the recording was stored; even then a person reviews it — the software never changes a model's status |
| `unknown` | no source declared anything (e.g. an uploaded file without hellos), a declaration lacks its flag, or the document does not state `synthetic: false` | never; reported as unknown, never as physical |

* **Segments.** A recording remembers which source declared what for which rows: `provenance.segments`
  (`segment`, `rows: [first, end)`, `session`, `device`, `synthetic`, `mode`, `hello`). Reconnects of one source
  and changes of source are kept as separate segments; frames carry their `segment`.
* **Mode change.** A hello with another mode closes the running recording at the change
  (`provenance.recording_closed`, event `recording_closed`): samples of two modes never share one table. Start a new
  recording for the new mode.
* **NDJSON export** (`recording_to_ndjson(doc, recording_id)`, `telemetry/export.py`): one hello per segment, then
  that segment's frames (a `bye` between segments). A declared-physical recording keeps its sources' own hellos. Any
  recording that is `synthetic` or `unknown` is exported so that **every segment replays as synthetic**: a segment
  whose own hello is already synthetic keeps it; any other segment gets the protocol-valid **synthetic replay
  identity** `device: {"id": "replay:<original id>", "kind": "file-replay", "firmware": <original>}`,
  `synthetic: true`. (A `physical` hello can never say `synthetic: true` — the protocol rejects it — so the identity
  changes instead.) Every exported hello carries `lineage` (§2).
* **Wire units (v5.2, review finding G1 of v5.1).** The export converts every signal to the unit of the frame table
  in §2, with the importer's factors (`hardware/ingest.py` `UNITS`; there is no second table): time → s, angles →
  rad, body and gyro rates → rad/s, wheel speed → rpm (from `wheel_rpm_x…` in any wheel unit or from `omega_x…`),
  torques → N·m, acceleration → m/s². A column already in the wire unit is copied exactly. v5.1 copied the stored
  numbers whatever `samples.units` said (an upload in ms / deg / deg/s replayed as s / rad / rad/s) and left
  `omega_*` out. The conversions are recorded in `lineage.export.converted`. What the stream cannot carry without
  inventing or relabelling data is **HTTP 422 `export_not_possible`** with the column: an incomplete vector, columns
  without a stream field, a `status` column whose codes the recording does not declare (`provenance.status_codes`)
  or a code outside them, two wheel-speed column sets, `t` < 0, a negative `seq`, an edge recording without `theta`,
  segments that do not cover the rows. `?omit_unmapped=true` (and `"omit_unmapped": true` when replaying a stored
  recording) leaves out the incomplete vectors, unmapped columns and undeclared status, recorded in
  `lineage.export.omitted`. Uploads without a `seq` column export the row index as `seq`, recorded in
  `lineage.export.seq`. Before the text is returned it is fed through a scratch `TelemetryHub` exactly as a file
  replay reads it (MAX_LINE, every hello and frame validated, sequence and time rules): an export the hub would not
  accept line for line is refused, never returned. NDJSON copies made by v5/v5.1 from recordings in other units
  cannot be repaired; regenerate them from the original (`dbtool export-audit` lists them; MIGRATION_V5_2.md).
* **Replays and copies.** A recording captured from a replay (transport `file`) is `derived`: a copy of earlier
  data, not an original measurement — never admissible as evidence even when it is declared physical (use the
  original recording). Its lineage names the recording it came from.
* **JSON export / import.** The stored document is exported unchanged; on import the backend recomputes the trust
  from the document: a document whose provenance says synthetic (any segment, hello, lineage or flag) is refused
  with `synthetic: false` (HTTP 422 on `synthetic`) and stored as synthetic otherwise.
* **Datasets and comparisons** use the trust recomputed from the stored, immutable document, combined with what was
  stored (`effective_provenance`): nothing stored earlier can raise trust. A dataset is `hardware` only when every
  member recording is declared-physical; all-synthetic is `synthetic-telemetry`; anything else is `mixed`, and the
  provenance lists `synthetic_members`, `unknown_origin_members` and `derived_members`. Members carry `trust`.
* **Old records are never rewritten.** Recordings stored by v5 are classified by these rules when they are read,
  listed, exported, compared or put in a dataset; their stored documents and rows stay byte-for-byte as they were.
  A v5 recording made from a v5 mixed export (the defect's output: a physical hello captured from a file replay)
  cannot be recognised as synthetic any more — the export lost that information — but it is `derived` and
  therefore never evidence.

## 7. API

| Method | Path | Purpose |
|---|---|---|
| GET | `/telemetry/status` (= `/hardware/status`) | connection, source, provenance, `counters` and `rejected_by_reason` **for the current source since it was connected** (`counters_scope`; a replay never inherits an earlier source's duplicates or gaps), `counters_total` since start-up, latest frame, recording (with `segments` and `closed`); v5.1: `stream_id`, `stream_started`, `segment` |
| POST | `/telemetry/connect` | `{source: "tcp", host, port}` · `{source: "file", path, speed}` · `{source: "recording", recording_id, speed}` — field errors (`host`, `port`, `path`, `source`) |
| POST | `/telemetry/disconnect` | stop the current source |
| GET | `/telemetry/files` | replayable NDJSON files in the telemetry directory |
| GET | `/telemetry/frames?after=n&limit=&stream=` | polling fallback: frames with index > n; `missed` counts frames already dropped from the buffer. v5.1: the answer has `stream_id`; when `stream` names another stream (the backend restarted) n is ignored, the answer starts at this stream's beginning and says `stream_changed: true` |
| WS | `/telemetry/live` | `{"type":"status"}` then batches `{"type":"frames","stream":id,"frames":[…],"dropped":k,"provenance":…}` (`stream` since v5.1); close 4429 when the client limit is reached |
| POST | `/telemetry/recordings/start` `{name}` · `/telemetry/recordings/stop` | record accepted frames; stop validates strictly and stores an `aeris-hardware-run/1` |
| GET | `/hardware/recordings` · `/hardware/recordings/{id}` · `/hardware/recordings/{id}/export?format=json|ndjson[&omit_unmapped=true]` | stored recordings; v5.1: the list has `trust` and `derived` per row (computed from the document for rows stored before v5.1); v5.2: NDJSON in wire units, 422 `export_not_possible` for what the stream cannot carry (§6) |
| POST | `/hardware/compare` | offline comparison with a stored run (evidence block, §6) |

Settings: `AERIS_TELEMETRY_BRIDGE` = `ndjson` (default: available, no source), `none` (switched off),
`ndjson-tcp://127.0.0.1:PORT` (connect at start-up), `file:NAME` (replay at start-up);
`AERIS_TELEMETRY_DIR`; `AERIS_TELEMETRY_ALLOW_REMOTE=1`; `AERIS_TELEMETRY_MAX_LIVE` (4).

## 8. Recording format

`stop` builds `aeris-hardware-run/1` with columns `t, seq, q0–q3 | theta, w_x…, wheel_rpm_x…, torque_cmd_x…,
torque_meas_x…, gyro_x…, accel_x…, status` (units per column) and `provenance` = protocol, source kind,
synthetic flag, transport, every hello, conventions, stream quality during the recording (accepted, duplicates,
out of order, gaps, dropped, rejected, reconnects, stale), the stream events with their times since the start of
the recording, and a note. Across reconnects a source whose clock and sequence continue keeps its values (the
outage shows as a gap); a source that restarted them is re-based to follow the previous segment and a
`time_base_reset` event records that the outage length is unknown. The document then passes the same strict
`validate_recording` as an uploaded file. v5.1 adds `provenance.segments`, `lineage` (the lineage of replayed
exports), `trust`, `trust_reasons`, `mixed_sources`, `derived`, `derived_from`, `recording_closed` and the
`stream_id` it was recorded on (§6); the published schema lists them (`site/schemas/aeris-hardware-run-1.schema.json`).

## 9. Browser

HARDWARE mode is selectable only when the research backend is reachable and reports `telemetry.available`; it opens
the Lab's **Telemetry** tab (also reachable as `#lab/telemetry`). The page reads frames over the WebSocket, falls
back to polling (also after the 4429 client limit), de-duplicates by `n`, and shows the provenance banner, a
3-D view of the reported attitude (drawn with the nominal cube model), the latest values, the stream quality,
recording controls and the stored recordings (replay, JSON/NDJSON export, comparison, dataset). Without a backend
the tab says why it is unavailable; DEMO is unaffected. When the backend restarts while the tab is open, the tab drops
the old frame, shows the new process's state and its frames as they arrive (§11); while the backend does not answer,
the tab asks again every 3 s instead of waiting for the site's one-minute probe.

## 10. Tests (all synthetic)

`backend/tests/test_telemetry.py` (32 tests): malformed lines, hello rules, frames before hello, unit and frame
errors, non-unit quaternions, duplicates, gaps, out-of-order, time, stale/fresh, disconnect/reconnect sessions,
slow consumers and subscriber limits, polling buffer, line splitting, loopback rule, the emulator over real TCP with
every fault type, recording → validation → NDJSON export → replay with identical values, clock-restart re-basing,
stalls, emulator option errors, the mapping adapter (order, units, axes, NED, clock wrap, status), API connect
rules, live WebSocket, polling, recordings, relabelling refusal, replay, file replay, datasets, comparison evidence,
WebSocket client limit, telemetry switched off, failed connections reported without claiming a connection.
`site/tests/v5.test.js` T1–T5, `site/tests/live_backend.test.js` L13 and `site/tests/browser_v5.py` cover the
browser side against the real backend and the standalone emulator. v5.2: `backend/tests/test_export_units.py` (every
accepted unit through API import → NDJSON export → an actual replay → a new recording, physical values and time
intervals compared row by row; identity controls; refusals; the audit of old copies) and
`backend/tests/test_lineage_bounded.py` (24 generations of mixed, reconnecting, declared-physical and unknown chains
through FileReplaySource; near-limit v5.1 lineage; conservative status after truncation; descendants never evidence).

v5.1: `backend/tests/test_provenance.py` (mixed recordings in both source orders, reconnects, identity and mode
changes, export → replay → re-recording twice, recording replays, JSON round trips, forged relabelling, datasets,
comparisons, v5 documents unchanged, unknown declarations, uploads without `seq`, the declared-physical positive
control and its derived copy), `test_stream_identity.py` (stream ids, cursors per stream, a restarted process
answering an old cursor, two API processes one after the other), `site/tests/v51.test.js` (W1–W8: restarts over
WebSocket and polling, stale answers, reconnects without restart, v5 backends without ids, hidden/shown panels, Node's
error-only WebSocket), `live_backend.test.js` L14 (a real backend process restarted with the adapters loaded) and
`browser_v51.py` (two tabs across a real restart; provenance in the Telemetry tab). Everything "physical" in these
tests is an artificial test fixture.

## 11. Backend restarts: stream identity (v5.1, review finding F2 of v5)

Every hub — every backend process — has a `stream_id` (`YYYYMMDDTHHMMSS-<12 hex>`, created at start-up) and
`stream_started`. Frame indices `n` start again at 1 in every process, so **a cursor `n` only means something
together with its stream id**. The id is sent with every status, every live batch (`"stream"`) and every poll
answer (`stream_id`).

The browser adapter (`HardwareTelemetryAdapter.live`) keeps its cursor and de-duplication **per stream**:

* the first id it sees is adopted; a different id later means the backend restarted: the adapter retires the old id,
  starts its cursor at 0 and emits `{"type": "stream", "stream", "previous", "reason"}` **before** delivering the new
  stream's frames; the Telemetry tab then drops the old frame, its session, the drawing state and this page's
  counters, and shows the new process's status and frames as they arrive;
* a poll names its stream (`&stream=`); the backend answers an old stream's cursor from the new stream's start;
* anything that still arrives from a retired stream (a slow answer, a late batch) is ignored;
* within one stream nothing changed: each frame once and in order across WebSocket drops and polling;
* a status fetched by the page itself is checked with `observe(stream_id)` (stale → ignored, new → adopted);
* a panel that is hidden and shown again passes its stream and cursor (`opts.stream`, `opts.after`) to the new live
  stream, which continues it or reports at once that the backend changed;
* a WebSocket attempt that reports only `error` (Node's WebSocket, used by the integration tests) or never opens
  (8 s) falls back to polling; it never stalls the stream.

**Backward compatibility.** All additions are optional fields and an optional query parameter.
* v5.1 page, v5 backend (no stream ids): the adapter falls back to the one restart sign it can trust — the
  backend's frame counter (`last_n` of a poll answer, or of the first status on a new WebSocket) is below the
  cursor — and starts again from 0. A restart after which the new process has already counted past the old cursor
  cannot be told from a gap without stream ids; upgrade the backend.
* v5 page (cached), v5.1 backend: the page ignores the new fields and sends no `stream`; it behaves as in v5
  (it may freeze after a restart until reloaded). Reload the page.
* NDJSON from v5.1 exports is valid `aeris-telemetry-ndjson/1`; a v5 backend reading it ignores `lineage` but
  still sees the synthetic replay identity (`file-replay`, `synthetic: true`) on every non-physical segment.

## 12. Resuming a stream without losing frames (v6.0, review finding V52-1 of v5.2)

v5.2's browser adapter advanced its cursor to whatever the first live batch contained: frames that the backend had
already accepted when a socket subscribed — after a reconnect, or the first frames of a **new backend process** that
arrived before the page's socket was open — were never shown and never reported (the reviewer's probe: delivered
`[2]`, frame 1 never requested, no gap). Now (`site/js/adapters/hardware-telemetry.js` `live`):

* Within one stream the hub's index `n` is contiguous, so the client always knows what it has not seen: its cursor,
  and the **subscription boundary** of a socket — the `last_n` of the socket's first status, which the backend computes
  in the same step as it subscribes the socket (every later frame reaches the socket, every earlier one does not).
* Whenever the stream ahead of the cursor is not contiguous — a socket opened after frames were accepted, a new
  process whose first frames arrived before the subscription, a socket queue that dropped frames for a slow client —
  the missing range is fetched from the backend's retained history (`GET /telemetry/frames`, page after page) while
  the live frames that keep arriving are held in a bounded buffer (`maxBuffer`, 4000; the oldest are dropped and
  fetched again from the history). Buffered frames are delivered as soon as they continue the cursor: **each frame
  once and in order**. Answers that belong to a stream or a catch-up the client has left are ignored.
* What the backend no longer retains (or cannot return after `historyAttempts`, 3, tries) is reported as an explicit
  `{"type":"gap", "stream", "from", "to", "missed", "reason"}` event; only then does the cursor move past it — never
  silently. A `{"type":"catchup", "state":"started"|"done"}` event tells the page that retained history is being read.
* A new viewer (no stream or cursor of its own) still starts at the live edge of the first stream it sees; after a
  stream change the new stream is shown from its first frame.

Tests: `site/tests/resume.test.js` R1–R14 (same-process reconnect, process restart, frames during the handshake and the
catch-up, duplicates, old-stream answers, more than one history page, buffer overflow, history no longer retained,
unreadable history, a slow client's dropped frames, polling, `close()` during a catch-up, the reviewer's fixture) and
`site/tests/live_backend.test.js` **L15**: a real backend process whose first frame is accepted before the page's socket
subscribes (a gated socket makes the order deterministic) — recovered exactly once; the same test fails on the v5.2
adapter (`evidence/v6.0-verification/`). L14 is unchanged. The live suites' process helper (`site/tests/lib/procs.js`,
review finding V52-3) now binds every stop timer to its own child: an old child's timer can never kill a replacement
(`site/tests/procs.test.js` P1–P7).

**Device telemetry (v6.0).** A paired device's frames reach its own hub (`/api/v6/devices/{id}/frames`, `/live`) from
the preferred route; when that route closes or reconnects the backend asks the device to resend from its ring
(`tlm_resume`) and records what the device no longer holds as a gap (`TelemetryHub.source_gap`; DEVICE_LINK.md §7).


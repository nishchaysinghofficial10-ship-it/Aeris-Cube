# Device documents and the device API (v6.0)

The documents that describe a cube, an experiment and what was measured, how they are validated and versioned, and
the REST/WebSocket reference of `/api/v6`. Validation lives in `backend/aeris_backend/devices/schemas.py`; the
service in `devices/service.py`; the routes in `api/devices_api.py`. The journey that uses them is in
[CONNECT.md](CONNECT.md); the device protocol in [DEVICE_LINK.md](DEVICE_LINK.md).

**Validation never coerces.** A wrong type, a non-finite number, a value outside its range or an unknown enum value is
an error with its path; unknown fields are kept and reported as warnings. **Qualification and value sources are
declarations**: the software never sets or upgrades them, and connecting, pairing, flashing or a close comparison
never marks a model MEASURED or VALIDATED.

## 1. The documents

| Schema | What it is | Made by | Stored | Identity |
|---|---|---|---|---|
| `aeris-device-profile/1` | what a cube **is**: body mass model, three wheels (axes, inertias, motors, drivers, signs), IMU, board, electrical limits, value sources | the project (reference) or the owner (revisions) | `profiles` (+ `profile_heads`) | `id` + `revision`, SHA-256 of the canonical text |
| `aeris-experiment-recipe/1` | what an experiment **asks for**: mode, duration, LQR weights, estimator, limits, rates, prerequisites | the project (reference) or the owner | `recipes` | `id` (immutable: a change needs a new id), hash |
| `aeris-calibration/1` | what was **measured** on one device: IMU mounting, gyroscope bias, wheel directions, with the evidence | the backend or the page from device results (CONNECT.md § Calibration) | `calibrations` | `AERIS-CAL-nnnnnn`, hash |
| `aeris-device-config/1` | the **approved configuration** the firmware applies | the backend (`configgen.device_config`) | `device_configs` | its SHA-256 (the device reports the same) |
| `aeris-plant-model/1` | the plant the **synthetic** device simulates | the backend (`configgen.plant_model`) | site data / test fixtures | — |
| `aeris-kit/1`, `aeris-bom/1` | a buildable kit revision and its bill of materials | `hardware/tools/make_kit.py` | `site/data/kits`, `site/data/bom`, a copy in the backend | `id` + `revision` |
| `aeris-firmware-manifest/1`, `aeris-firmware-trust/1` | a signed firmware release; the keys the installer trusts | `firmware/tools/make_release.py` | `site/firmware/` | version + build, signature |
| `aeris-site-profile/1`, `aeris-site-recipe/1`, `aeris-site-config/1` | the reference documents and their approved configurations as the site ships them (for the page's local route) | `backend/aeris_backend/tools/make_site_data.py` | `site/data/` | the backend's hashes |

**Hashes.** A document's hash is the SHA-256 of its canonical JSON text (keys sorted, no insignificant whitespace,
UTF-8, no NaN/Infinity, Python's shortest round-trip numbers; `devices/canonical.py`). The approved configuration is
sent to the device as exactly these bytes, so the hash the backend records is the hash the device reports.

**References.** A configuration names the profile `{id, revision, hash}`, the recipe `{id, hash}` and the calibration
`{id, hash}` it was built from; a calibration names its device and profile revision; a twin run stores
`twin: {profile, recipe, calibration, owner}`; a device recording stores `device_link: {device_id, config_hash,
boot_id, route}`. Nothing is edited in place: a change makes a new revision (profiles), a new id (recipes), a new
calibration or a new configuration hash.

## 2. `aeris-device-profile/1`

| Path | Type / unit | Rule |
|---|---|---|
| `schema` | string | `aeris-device-profile/1` |
| `id` | string | `^[a-z0-9][a-z0-9-]{2,63}$`; `aeris-ref-a1` is reserved for the reference profile |
| `name`, `description` | string | ≤ 120, ≤ 2000 characters |
| `kit` | `{id, revision}` or null | the kit revision the profile describes |
| `qualification` | `{status, evidence?, note?}` | `status`: users may declare only `experimental` or `unqualified`; `qualified` exists only for project profiles with reviewed evidence |
| `g_mps2` | m/s² | 9.7 … 9.9 (default 9.81) |
| `body.edge_m` | m | 0.05 … 0.5 |
| `body.mass_kg` | kg | 0.1 … 20 |
| `body.inertia_factor` or `body.inertia_kgm2` | – or kg·m² | factor 0.05 … 0.5, or a symmetric, positive-definite 3×3 matrix |
| `body.com_m` | m, [3] | optional, each −0.5 … 0.5 (a warning when outside the cube) |
| `body.components[]` | `{id, mass_kg (0…10), com_m [3], inertia_kgm2?}` | optional point/body components |
| `wheels` | exactly 3 | distinct driver nodes; the axes must not be (nearly) coplanar |
| `wheels[].id` | string ≤ 16 | |
| `wheels[].axis` | unit vector | |
| `wheels[].Jw_kgm2` | kg·m² | 1e-6 … 0.05 (rotor inertia about its spin axis) |
| `wheels[].motor` | `{KV_rpm_per_V (10…5000), R_ohm (0.01…20), Imax_A (0.1…60), supply_V (3…60), speed_max_rpm (100…30000)}` | k_t is derived as 60 / (2π·KV) |
| `wheels[].friction` | `{cv (0…0.01) N·m·s, cc (0…0.1) N·m}` | |
| `wheels[].driver` | `{kind: "odrive-cansimple", node (1…62), sign (±1)}` | `sign`: the motor's positive direction relative to the axis (confirmed by a calibration's wheel check) |
| `imu.driver` | `lsm6dsox` | the only IMU driver of firmware 0.1.0 |
| `imu.i2c_address` | 0x6A or 0x6B | |
| `imu.position_m` | m, [3] | ≤ 0.5 m from the pivot |
| `imu.to_body` | 9 numbers, row-major | a signed permutation with determinant +1: body = to_body · sensor (a calibration's measured value overrides it) |
| `imu.odr_hz` | Hz | an LSM6DSOX rate: 12, 26, 52, 104, 208, 416, 833, 1666, 3332, 6664 |
| `imu.accel_range_g`, `imu.gyro_range_dps` | | 2/4/8/16; 125/250/500/1000/2000 |
| `imu.noise` | `{gyro_dps (0…5), accel_mps2 (0…2)}` | used by the synthetic device and the twin |
| `board.id` | string | e.g. `esp32-s3-devkitc-1` |
| `electrical` | `{vbus_min_V < vbus_max_V (1…60), current_abort_A (0.1…60, ≥ every motor's Imax_A), temperature_abort_C (20…120)}` | |
| `value_sources` | map group → `nominal-model`, `datasheet`, `estimated` or `measured` | declarations: where each group of values came from |
| `parameter_set_id`, `notes` | | optional |

**The reference profile** `aeris-ref-a1` revision 1 (`devices/reference.py`, `site/data/profiles/`) is
**experimental**: its mass, inertia, wheel and motor values are the engine's nominal model (`value_sources` all
`nominal-model`); no motor or rotor has been selected and nothing was measured. Release firmware never drives motors
with it. It is the profile the synthetic device and the twin use by default; a real build creates its own revisions.

**Revisions.** `POST /api/v6/profiles` validates (`author_is_user`) and stores the next revision of the owner's
profile id; posting a document identical to the latest revision returns that revision (`unchanged: true`). Stored
revisions are never modified. `POST /api/v6/devices/{id}/profile {id, revision}` assigns a revision to a device;
calibrations and configurations are bound to the revision they were made for.

## 3. `aeris-experiment-recipe/1`

| Path | Rule |
|---|---|
| `id`, `name` | id pattern as profiles (≤ 39 characters); reference ids are reserved |
| `mode` | `edge` or `corner` |
| `duration_s` | 1 … 300 |
| `controller` | `{type: "lqr", weights: {tilt_deg, rate_dps, wheel_rad_s, yaw_deg, yaw_rate_dps, r_scale}}` (positive; omitted weights take the engine's defaults) |
| `estimator` | `{type: "cf3d", tau_s (0.01…10), accel_gate_mps2 (0.01…5), bias_gain (0…1), tau_alpha_s (0.001…1), stale_after_s? (0.0005…1), compensate_dynamic?}` |
| `limits` | `tilt_start_deg` (0.1…15) < `tilt_abort_deg` (0.5…30), `link_loss_max_s` (0…30), `stop_torque_Nm` (0…1), `arm_window_s` (5…120), `wheel_speed_abort_factor` (1.0…1.5) |
| `rates` | `control_hz` integer 100…1000; `telemetry_hz` integer 1…500 dividing it |
| `start` | `{tilt_deg (0…10)}` (the simulated start offset) |
| `requires` | `["edge-trial-completed"]` or empty (a corner recipe without it gets a warning) |

Reference recipes: **`edge-hold-10s`** (edge, 10 s, start within 3°, abort at 12°, link loss 0.5 s, stop torque
0.05 N·m, arm window 30 s, 500 Hz control, 50 Hz telemetry) and **`corner-hold-10s`** (the same limits, corner mode,
`requires: ["edge-trial-completed"]`). Their limits are conservative starting values for a cube in a fall-catching
fixture, **not qualified limits**.

## 4. `aeris-calibration/1`

| Path | Meaning |
|---|---|
| `device_id`, `profile {id, revision}` | the device and the profile revision it was measured for |
| `source` | `device-measurement`, `synthetic-device` (a device that declares itself synthetic) or `manual-entry` |
| `imu.to_body` | the measured mounting (signed permutation, det +1), with `to_body_fit {max_residual_deg, faces, next_best_deg}`, `declared_to_body`, `matches_declared` |
| `imu.gyro_bias_radps` | the bias in the **sensor** frame (|·| ≤ 0.2 rad/s); configurations rotate it into the body frame |
| `imu.gyro_std_radps`, `accel_norm_mps2`, `samples`, `seconds`, `temp_c` | from the measurement |
| `wheels[]` | per wheel `{index, node, encoder_updates, direction_ok, checked, note, travel_rev?, vel_rads_max?, vel_rads_min?}` |
| `wheel_directions_confirmed` | all three confirmed |
| `evidence[]` | per measurement: the command id (or `client-reported`), its origin, completion time, the result's SHA-256, the route |
| `notes[]` | e.g. the measured mounting differs from the declared one; wheel directions not confirmed |

How each value is derived and refused: [CONNECT.md](CONNECT.md) § Calibration.

## 5. Configuration, plant, kit and firmware documents

* **`aeris-device-config/1`** — every field and rule: [DEVICE_LINK.md](DEVICE_LINK.md) §8. Built from the profile
  revision (body, wheels, motors → plant and limits; IMU settings), the recipe (mode, estimator, limits, rates; LQR
  weights → gains designed by the backend, `control/design.py`), and the calibration (mounting, gyroscope bias).
* **`aeris-plant-model/1`** — the synthetic device's plant: DEVICE_LINK.md §8.
* **`aeris-kit/1`** — `id, revision, name, readiness` (`concept`, `candidate`, `engineered`, `manufactured`,
  `bench-tested`, `beginner-validated`), `readiness_note`, `profile`, `firmware {version, manifest, installer_offers,
  not_offered}`, `bom {path, sha256}`, `supported_connections[]`, `downloads[]` (each `available` with path, bytes and
  SHA-256, or `unavailable` with the reason), `sizing`, `steps[]` (`id, section, title, summary, parts, expected_result,
  checkpoint, troubleshooting, requires, illustration, availability`), `revision_history[]` (what a revision change
  invalidates), `progress_note`. Generated from `hardware/bom/aeris-kit-a1.bom.json` by `hardware/tools/make_kit.py`
  (`--check` detects drift); see [`hardware/README.md`](../../hardware/README.md).
* **`aeris-bom/1`** — `kit, readiness, checked` (the date sources were checked), `summary, readiness_levels,
  price_note, items[]` (`id, name, qty, group, status, function, part, facts, compatibility, supplier_links,
  substitutions`), `tools[]`, `open_engineering[]`.
* **`aeris-firmware-manifest/1`, `aeris-firmware-trust/1`** — [FIRMWARE_INSTALL.md](FIRMWARE_INSTALL.md).

## 6. Where a value comes from

| Value | Source |
|---|---|
| Controllers, estimators, drivers, actions, highest control rate, hard current/torque/speed caps, actuation build, board, `synthetic` | the device's `dev_hello` — **declared**, used to refuse what does not fit (DEVICE_LINK.md §2), never to fill in a profile |
| Mass model, inertia, wheel axes and inertias, motor constants, driver nodes and signs, IMU placement and settings, electrical limits | the **profile revision** (nominal or declared values unless its `value_sources` say measured) |
| Mode, duration, LQR weights, estimator settings, start/abort tilt, link-loss time, stop torque, arm window, rates, prerequisites | the **recipe** |
| IMU mounting (`to_body`), gyroscope bias, confirmed wheel directions | the **calibration** (measured on that device) |
| Gains | designed by the backend from profile + recipe (+ the calibration's mounting) |
| The label of a Simulate My Cube run | the parameter-set coverage rule of [PARAMETERS.md](PARAMETERS.md): the profile revision's value groups declared `measured` (body, wheels, motor, imu.noise, imu.placement) become the run's parameter set `profile:<id>:r<revision>` at the engine's parameter paths; every other input stays NOMINAL, so a run is MEASURED only when every model input it uses is covered — never VALIDATED. `datasheet`, `estimated` and `nominal-model` are not measurements; the backend's global parameter set (which describes another cube) is never used for a twin run |
| Attitude, rates, wheel speeds, torques in telemetry | the device (its **estimate**; synthetic devices: the simulated plant) |

## 7. REST reference `/api/v6`

Authentication: `local` mode needs nothing (one owner, loopback only); `jwt` mode needs `Authorization: Bearer …` on
every route except `/api/v6/status` and `/api/v6/kits…` (CONNECT.md § Security). Errors use the backend's envelope
`{"error": {"code", "message", "details", "retryable"}}`. Another owner's device, profile, calibration, configuration, command or
recording answers 404.

| Method | Path | Body / query | Answer |
|---|---|---|---|
| GET | `/status` | — | `api: aeris-devices/1`, `link`, `auth` summary, `devices_connected`, `commands_closed_at_start`, WebSocket paths, `tickets_needed`, `remote_actions`, `usb_local_only` |
| GET | `/me` | — | `{owner, mode}` |
| POST | `/tickets` | `{purpose: live \| relay \| v1-live}` | `{ticket, purpose, expires_in_s: 30}` (201) |
| GET | `/profiles` | — | the reference profile and the owner's profile heads |
| GET | `/profiles/{id}` | `?revision=` | `{owner, id, revision, hash, document, validation?, reference?}` |
| POST | `/profiles` | a profile document | the stored revision (201); 422 `invalid_profile`, 409 `reserved` |
| POST | `/profiles/validate` | a profile document | `{ok, errors, warnings}` (nothing stored) |
| GET | `/recipes`, `/recipes/{id}` | — | reference and own recipes |
| POST | `/recipes` | a recipe | stored (201); 422 `invalid_recipe`, 409 `reserved` / `exists` |
| GET | `/kits`, `/kits/{id}` | `?revision=` | kit summaries; a kit document (public) |
| GET | `/devices`, `/devices/{id}` | — | registrations with `connected`; the view: `routes, state, dev_hello, compat, lease, telemetry, telemetry_route, telemetry_catchups` |
| POST | `/devices/{id}/profile` | `{id, revision}` | assigns a profile revision |
| POST | `/devices/{id}/name` | `{name}` (1…80) | renames |
| POST | `/devices/{id}/revoke` | — | forgets the credential, closes the device's connections |
| POST | `/pairing/start` | — | `{session, nonce, expires}` (201; single use, 5 min) |
| POST | `/pairing/complete` | `{proof, name?}` | the registered device (201); 422 `invalid_proof` / `invalid_signature`, 409 `pairing_refused` / `owned_elsewhere` |
| GET | `/devices/{id}/calibrations`, `/calibrations/{cid}` | — | calibrations of the device; one calibration |
| POST | `/devices/{id}/calibrations` | `{commands: {imu, axes: […], encoders?}}` or `{measurements: {imu, axes, encoders?}}`, `profile?` | the calibration (201); 422 `calibration_inputs` / `calibration_rejected` / `invalid_calibration` |
| POST | `/devices/{id}/configs` | `{recipe, calibration?, profile?}` | the configuration (201): `id` (= hash), `text`, `config`, `profile`, `recipe`, `calibration`, `engine_config`, `design`; 409 `calibration_device` / `calibration_profile` / `calibration_required` / `incompatible`, 422 `config_error` |
| GET | `/configs/{hash}` | — | a stored configuration |
| POST | `/devices/{id}/lease` | `{holder (8…64), takeover?}` | `{device_id, holder, epoch, expires, …}`; 409 `lease_held` |
| POST | `/devices/{id}/lease/release` | `{holder}` | `{released}` |
| POST | `/devices/{id}/commands` | `{action, params?, ttl_ms (100…10000, default 5000), holder?, config_hash?, route?}` | the command record (201, status `sent`); 422 `action_not_available` / `ttl`, 409 `not_connected` / `not_offered` / `lease_required` / `config_device` / `incompatible` / `config_not_applied` / `prerequisite` / `wheel_directions_unconfirmed` / `send_failed` |
| GET | `/devices/{id}/commands`, `/commands/{cid}` | `?limit=` | the command log (status history, device reasons, results) |
| GET | `/devices/{id}/frames` | `?after=&limit=&stream=` | accepted telemetry frames, `provenance`, `stale`, `connected` (as `/api/v1/telemetry/frames`) |
| POST | `/devices/{id}/recordings/start`, `/stop` | `{name?}` | start: the recording state; stop: the stored recording (`AERIS-HW-…`, `device_link`); 409 `not_connected` / `recording_state` |
| GET | `/devices/{id}/recordings` | `?limit=` | the device's recordings |
| POST | `/twin/simulate` | `{device_id? \| profile?, recipe?, calibration?, seed?}` | 202 `{job, engine_config, twin, note}`; 422 `config_error` |
| POST | `/twin/compare` | `{run_id, recording_id, protocol_id?, max_lag_s?}` | the comparison with `alignment`, `signals`, `evidence` (admissibility and reasons) |

**WebSockets** (DEVICE_LINK.md §9): `/api/v6/device-link` (the device's gateway connection), `/api/v6/relay?route=
companion|browser-relay` (relays; ticket or header), `/api/v6/devices/{id}/live` (the owner's view: `device`,
`state`, `frames`, `status` every second, `route`, `command`, `event` messages, including `tlm_catchup`).

## 8. Storage

Database schema 3 (v6.0, additive migration from the v5.2 schema 2): tables `devices`, `pairings`, `leases`,
`commands`, and `runs.owner` (twin runs belong to the owner of the profile they simulate). Profiles, profile heads,
recipes, calibrations and approved configurations are documents in the existing `docs` table (collections `profiles`,
`profile_heads`, `recipes`, `calibrations`, `device_configs`). `dbtool backup` / `restore` / `verify` cover the new
tables ([DATABASE.md](DATABASE.md)); [MIGRATION_V6.md](MIGRATION_V6.md) lists the changes.

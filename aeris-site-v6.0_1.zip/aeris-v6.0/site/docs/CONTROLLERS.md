# AERIS · Controllers and torque allocation

Implemented in `backend/aeris_backend/control/` (design: `design.py`, laws: `controllers.py`) and, for
the browser's decoupled laws, in `site/js/core.js`. Every run record stores the method that actually
ran in `executed.controller` (`type`, `structure`, `law`, gains/model where applicable) and the design
in `design`; the Lab and the Maths panel show those saved values. Nothing is relabelled: a nonlinear
controller is never shown as LQR, three scalar loops are never called MIMO, and an unsupported
request is refused with an error (never substituted).

## 1. One interface

```python
class Controller:
    type, structure, law
    request(t, est, ww, failed) -> Request(per_wheel=[T_i] | body=u)   # reads the Estimate + wheel encoders only
    after(sat, failed_any, ww, dt, T_des, T_lim)                         # saturation feedback (anti-windup, adaptation gates)
    on_event(t, what)                                                    # wheel events, yaw-command steps (PID reset option)
    reset(); summary()
```

* Controllers read an `Estimate` (attitude/tilt, rates, bias) produced by the selected estimator, plus
  the relative wheel speeds `Ω_i` (encoders). They never read or modify the plant state
  (`test_estimator_based_controller_does_not_read_truth` swaps the plant state under a running MEKF
  controller and checks the command does not change). The perfect-state baseline (`ideal`) copies
  the true state into the Estimate and is labelled `truth_access: true`.
* The command is held for one control period (zero-order hold). `per_wheel` requests go straight to
  the driver limits; `body` requests (nonlinear PD) are allocated first (§7).
* Controllers designed "for the bare cube" use the nominal cube (isotropic `k_J m a²`, COM at the
  centre); with `controller.knowsAttachments` they use the run's true mass properties. Inertia scale
  and perturbation (`uncertainty`) are never known to the controller.

## 2. PID (edge and 3-D)

* Error and sign: `e = θ̂ + β_ref` (edge; `β_ref` = balance offset the controller knows, 0 for the bare
  cube). `T = K_p e + K_i ∫e dt + K_d θ̂̇` is the torque on the wheel; the body receives `−T`.
* Corner: the same law per tilt axis on the tilt vector `θ_t = û_B × û_ref` with the rate component
  perpendicular to the balance axis, plus a yaw PID about the balance axis (browser law).
* Gains: pole placement on the LQR closed-loop poles plus an integrator pole
  (`controller.pid.integrator_pole`, default −3 s⁻¹; yaw −1 s⁻¹), as in the browser.
* Integral limit: `|∫e| ≤ τ_max / K_i` (corner: by vector norm).
* Anti-windup `controller.pid.anti_windup`: `clamp` (default, browser: only the limit above) or
  `conditional` (also freeze integration while the driver saturates in the direction the error
  pushes; an error of the opposite sign still integrates).
* Reset: integrators start at zero in every run; with `controller.pid.reset_on_events: true` they are
  reset at wheel events (failure, degradation, imposed limits, clearance) and yaw-command steps; each
  reset is saved in `executed.controller.integrator_resets`. Default off (browser behaviour).
* Tests: `test_pid_integral_limit_conditional_anti_windup_and_reset`,
  `test_pid_reset_in_a_run_is_recorded_and_default_matches_the_browser`, parity fixtures `edge-pid`,
  `corner-pid`, `edge-pid-failure`, `corner-pid-fail-noreconf`.

## 3. Nominal (decoupled) LQR — the browser design

Single-axis tilt model about the balance attitude (edge: the hinge; corner: each tilt axis with the
inertia perpendicular to the balance axis):

```
x = [e, θ̇, Ω],  u = T        ẋ = A x + B u
A = [[0, 1, 0], [mgl/Θ̂, 0, 0], [−mgl/Θ̂, 0, 0]],   B = [0, −1/Θ̂, Θ_0/(J_w Θ̂)]ᵀ        (sin e ≈ e)
Q = diag(1/e_max², 1/θ̇_max², 1/Ω_max²),  R = r_scale / τ_max²          (Bryson weights, controller.lqr)
```

* Riccati: SciPy `solve_continuous_are`; the gain `K = R⁻¹BᵀP`; the relative Riccati residual and the
  closed-loop poles are saved (`design.tilt.riccati_residual`, `cl`, `ol`). Stabilisability is checked
  with the PBH test before solving (`controllability`); non-physical models (non-positive inertia,
  gravity stiffness or torque limit) raise `DesignError` and the configuration is rejected.
* Saved with every run: `design.tilt.M.A`, `M.B`, `Q`, `R`, `K`, `P`, `state`, `input`,
  `operating_point` (e = 0, θ̇ = 0, Ω = 0), and for the corner yaw loop `design.yaw.{A, B, Q, R, K, P, ...}`.
* Gains are cached by their inputs (`functools.lru_cache`), so sweeps do not recompute identical designs.
* In corner mode this is **three decoupled loops** (two tilt axes + yaw), labelled `structure: decoupled`.
* Tests: `test_tilt_design_riccati_residual_and_stability`, `test_unphysical_and_unstabilisable_designs_raise`,
  parity with the browser design to 1e-9 (`test_parity.py::test_outcome_and_design`).

## 4. Coupled MIMO LQR (`controller.structure: "mimo-lqr"`, corner mode, type `lqr`)

A single gain on the full-tensor linearisation of the corner model about the upright equilibrium
(`design.corner_linearization`):

```
state  x = [φ (3), ω (3), Ω (n)]        φ: rotation vector of the error, R = R_ref · exp([φ]×) (body frame)
input  u = [T_1 … T_n]                  (motor torques on the wheels)
φ̇ = ω
Θ̂ ω̇ = M g l (I − û ûᵀ) φ − A_w u                 Θ̂ = Θ_O − Σ J_i a_i a_iᵀ,  A_w = [a_1 … a_n]
Ω̇  = J⁻¹ u − A_wᵀ ω̇                              (relative wheel speeds)
```

The full inertia tensor (off-diagonal terms, components, attachments the controller knows) enters
`Θ̂`, and the wheel states are part of the model, so the gain couples all axes: `K` is `n × (6+n)`
(3 × 9 for the standard wheels) and is not block-diagonal
(`test_mimo_is_not_three_scalar_loops_and_runs`).

**Conserved momentum.** Gravity has no moment about the vertical and the wheels only exchange
momentum with the body, so the angular momentum about the vertical `h_v = ûᵀ(Θ_O ω + Σ J_i Ω_i a_i)` is
conserved: `(A, B)` has an **uncontrollable mode with eigenvalue 0** (controllable rank 8 of 9 for the
standard wheels). A full-state stabilising LQR therefore does not exist; the design instead:

1. computes the controllable subspace `V_c` (orthonormal Kalman decomposition via the SVD of the
   scaled controllability matrix),
2. rejects the design if any uncontrollable mode has `Re λ > 0` (not stabilisable),
3. solves the CARE for `(V_cᵀAV_c, V_cᵀB, V_cᵀQV_c, R)` and uses `K = K_c V_cᵀ`.

Saved in `design.mimo`: `A, B, Q, R, K, K_reduced, Vc, controllable_rank, state_dim,
controllability_singular_values, uncontrollable_eigenvalues, uncontrollable_direction` (the conserved
combination), `riccati_residual, cl_reduced, cl, ol, operating_point, gain_shape`.
Weights: tilt/yaw angle and rate maxima split along and across the balance axis, wheel speed
maxima, `R = diag(r_scale/τ_max,i²)` (`controller.lqr`).

Law: `T = −K [φ; ω̂; Ω]` with the reference `q_ref = q_z(ψ_ref) ⊗ q_eq` (commanded heading about the
world vertical). After a wheel failure with `reconfigureOnFailure` the gain is **redesigned without the
failed wheel**; the result (rank, poles) or the failure to find a stabilising gain is saved in
`executed.controller.redesigns` and shown on the timeline (`test_mimo_redesign_after_failure_is_reported`).

Limitations: linear design about upright (large tilts, wheel-speed saturation and actuator limits
are not in the design); the conserved vertical momentum cannot be removed (an initial yaw rate or
wheel momentum along the vertical stays in the system); with two wheels left the yaw direction
becomes uncontrollable as well and the design keeps only what is stabilisable.

## 5. COM-adaptive LQR (`type: "adp"`) — browser parity

LQR with the balance-offset estimate `β̂` added to the tilt error: `T = −(K₁(e + β̂) + K₂θ̇ + K₃Ω)`,
`dβ̂/dt = γ Ω` (edge; corner: the vector version projected on the tilt plane), clamped to ±6°
(`controller.adaptive.{gamma, clamp_deg}`); adaptation is frozen while saturated or after a wheel
failure (edge), and while saturated unless a wheel failed (corner), exactly as in the browser. It
learns **only** a constant balance offset from the wheel speed; it does not identify the inertia,
motor constants or friction. Parity fixtures: `edge-adp-offset`, `edge-adp-mismatch`, `corner-adp-shift`.

## 6. Nonlinear model-compensated quaternion PD (`type: "nlpd"`, research backend)

```
u = τ_g,m(q̂) − ω̂ × H_m − Θ̂_m α_d + f_m(Ω),        u = Σ T_i a_i   (torque on the wheels; the body gets −u)
τ_g,m = M_m r_c,m × g_B(q̂),   H_m = Θ_O,m ω̂ + Σ J_i Ω_i a_i
α_d = −K_p φ_e,⊥ − K_d ω̂_⊥ − (K_p,ψ φ_e,∥ + K_d,ψ ω̂_∥) û       φ_e = 2 sgn(q_e0) vec(q_e),  q_e = q_r⁻¹ ⊗ q̂
K_p = ω_n², K_d = 2ζω_n (tilt);  K_p,ψ = ω_n,ψ², K_d,ψ = 2ζ_ψ ω_n,ψ (yaw)       (controller.nonlinear)
q_r = q_z(ψ_ref) ⊗ q_eq,m ⊗ exp(δ),   δ = −(k₁ h_⊥ + k₂ ∫h_⊥ dt)  (|δ| ≤ max_ref_tilt_deg)
k₁ = 2ω_o/(m g l)_m,  k₂ = ω_o²/(m g l)_m                             ((m g l)_m about the support edge in edge mode)
Edge: T = (m g l)_m sin(θ̂ + β_m) − Θ̂_m α_d + f_m(Ω),   α_d = −K_p(θ̂ + β_m − δ) − K_d θ̂̇
```

* **Model knowledge:** mass, COM and inertia of the controller's model (bare nominal cube, or the true
  mass properties with `knowsAttachments`), gravity, wheel axes and spin inertias, and — with
  `compensate_friction` — the nominal friction model. It does not know inertia scale/perturbation,
  lag, health or events. The gains, settings and model actually used are saved in
  `executed.controller.{gains, settings, model_used}`.
* **Stability rationale:** substituting `u` into `Θ̂ω̇ = −ω×H + τ_g − u` gives `ω̇ = α_d` when the model
  is exact and no limit is active; the error then obeys the linear second-order dynamics of the PD
  on the (sign-corrected) quaternion error, a standard rigid-body result (e.g. Wen &
  Kreutz-Delgado, IEEE TAC 36(10), 1991). `test_nonlinear_pd_exact_model_gives_the_designed_error_dynamics`
  checks this: with an exact model the simulated attitude error follows `φ̈ + 2ζω_nφ̇ + ω_n²φ = 0`
  within 0.5 % in both modes. The outer momentum loop is slow (`ω_o = 0.8 rad/s` against `ω_n = 14 rad/s`)
  and uses gravity to drain horizontal wheel momentum; its integral removes a constant COM offset.
* **Limitations:** no guarantee under torque saturation (the cancellation is lost — outside the
  torque capability it falls like any controller: `test_nonlinear_controller_limits_are_honest`), under
  model error (the equilibrium and damping change), or with estimator error; after a wheel failure
  the remaining wheels may not realise the 3-D request (yaw is given up and the shortfall is reported
  in `research.authority`); the vertical momentum is conserved and cannot be drained; `sgn(q_e0)` avoids
  unwinding but makes the law discontinuous at 180° errors (irrelevant near upright).

## 7. Allocation and authority

| Controller | How torque reaches the wheels (`executed.allocation.method`) |
|---|---|
| PID / LQR / adaptive (corner) | per body axis (browser law); after a failure with reconfiguration: least squares on the tilt plane, yaw given up |
| MIMO LQR | none needed — the gain produces wheel torques; after a failure the gain is redesigned without the wheel |
| Nonlinear PD | body torque → wheels: `clip` (least squares, then each driver limit) or `bounded-ls` (bounded least squares within each wheel's deliverable torque at its current speed, `scipy.optimize.lsq_linear`) |
| Edge mode | hinge torque to the wheel(s) with an axis component along the support edge |

The driver limits (`PHYSICS.md` §5) act after allocation. Every integration step records the
requested and applied wheel torques and the **body-level shortfall** `r = u_req − Σ T_i a_i`
(`research.authority`: RMS, peak and the time with |r| > 5 % of the request). Allocation never creates
authority that the remaining wheels do not have; when a failure leaves the request unreachable the
shortfall stays non-zero and is reported (`test_authority_residual_matches_saturation_and_reports_lost_authority`).
No fault-tolerance claim is made beyond what the saved runs show.

## 8. No silent substitution

The configuration validator (`backend/aeris_backend/config/validate.py`) refuses: unknown controller
types, `mimo-lqr` in edge mode or with a non-LQR type, decoupled browser laws with non-standard wheel
sets, estimators the mode does not support, and designs without a stabilising solution — each with a
path and message. In DEMO mode the browser refuses every research-only method with a capability
error (`site/js/platform/config.js`). `test_no_silent_controller_substitution` checks that the executed
type and name equal the requested ones.

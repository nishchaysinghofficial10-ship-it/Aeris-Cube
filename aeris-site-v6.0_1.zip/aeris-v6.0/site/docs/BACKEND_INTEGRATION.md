# AERIS · Backend integration

How the AERIS web frontend talks to its data sources, and the REST/WebSocket contract that the
Python research backend (`backend/`, v4) implements. Everything below exists and is tested:
`backend/tests/test_service.py` (API, jobs, WebSocket), `site/tests/live_backend.test.js` (the real
`ResearchApiAdapter` against a running uvicorn server) and `site/tests/browser_v4.py` (Playwright:
the site in Chromium against the running backend). Install and run: `backend/README.md`.

## 1. Architecture

```
UI (workspace, sweep UI, pages)
  │
  ▼
AERIS_SERVICE  (js/platform/service.js) ── picks the adapter for the current system mode
  │
  ├─ LocalSimulatorAdapter     js/adapters/local-simulator.js    AERIS Twin browser engine (js/core.js)   DEMO
  ├─ ResearchApiAdapter        js/adapters/research-api.js       Python research backend, REST + WS       SIMULATION
  ├─ HardwareTelemetryAdapter  js/adapters/hardware-telemetry.js physical cube (interface only)            HARDWARE (unavailable)
  └─ ReplayAdapter             js/adapters/replay.js             saved runs, imports, built-in examples   every mode

backend/aeris_backend
  api/        FastAPI app (/api/v1), CLI (python -m aeris_backend.api.main)
  jobs/       job manager: process pool, cooperative cancellation, restart policy, live updates
  storage/    SQLite repository (jobs, runs, sweeps + rows, datasets, parameter sets, recordings, protocols)
  simulation/ engine (RK4 + ZOH), setup, disturbances/events;  physics/ actuators.py sensors.py estimation/ control/
  metrics/    legacy (browser rules) and research metrics;      experiments/ records, sweeps, comparison
  hardware/   strict frame/recording validation, sim ↔ hardware comparison, telemetry bridge interface
```

The UI never calls a simulator directly; runs, controller sets, sweeps, cancellation and
reproduction go through `AERIS_SERVICE`.

## 2. System modes

| Mode | Single run | Sweep | Replay | Live | Selectable when |
|---|---|---|---|---|---|
| **DEMO** | browser engine | browser engine (≤ 400 runs, ≤ 10 s) | ✓ | — | always |
| **SIMULATION** | research backend | research backend | ✓ | — | the backend is **configured and reachable**: `GET /health` answered `status: ok` and `GET /capabilities` was reported |
| **HARDWARE** | — | — | ✓ | telemetry | never in this build (no telemetry bridge, firmware or device protocol exists) |

*Configured is not reachable.* A `baseUrl` alone does not enable SIMULATION. The site probes at load,
every `probeMs` (while the page is visible) and when the user presses **Check backend** in the Lab;
the Lab shows the backend URL, `reachable` / `not reachable (reason)` / `not checked yet` and the
time of the last check. Only capabilities the backend reported are used (nothing is guessed). If
the backend stops, the next probe disables SIMULATION with the reason; DEMO keeps working offline.

### Enabling SIMULATION while keeping DEMO

1. Start the backend (`backend/README.md`), allowing the site's origin:
   `python -m aeris_backend.api.main --port 8750 --cors http://localhost:8000`
2. Serve the site (`python3 -m http.server 8000` in `site/`) and set, in `js/site-content.js`:

```js
window.AERIS_CONFIG = {
  researchApi: {
    baseUrl: "http://127.0.0.1:8750",   // REST: /api/v1/… is appended
    wsUrl:   "ws://127.0.0.1:8750",     // optional: live job updates (polling is the fallback)
    pollMs: 1000,                       // job polling interval
    probeMs: 60000,                     // health/capability re-check interval
    mock: false                         // true = in-browser MOCK backend (labelled MOCK DATA; never research output)
  }
};
```

3. Open AERIS Lab: the backend line reads *reachable*, SIMULATION becomes selectable, and the status
   strip's MODEL reads the research engine. DEMO stays selectable at all times.

Never put credentials or API keys in the frontend. The client sends cookies (`credentials:
"include"`); for remote use put the backend behind a reverse proxy that authenticates
(`backend/README.md`, "Deployment").

## 3. Validation layers

| Layer | Where | What |
|---|---|---|
| 1 structure | `AERIS_CFG.structural` (browser), `config/normalize.py` (backend) | types, shapes, enumerations of every field (revisions 1.0 and 1.1) |
| 2 engine capability | `AERIS_CFG.validateFor(cfg, engine, caps)` | DEMO: the browser engine's features and limits (research content is refused with `kind: "capability"`); SIMULATION: only the capabilities the backend reported |
| 3 authoritative | `POST /validate`, `POST /simulations`, `POST /sweeps` | the backend's full validation (physics consistency, design feasibility, workload limits) |
| 4 records | `AERIS_RUNS.validateRecord` → `validateBackendRecord` | every record the backend returns is checked strictly before it is shown or saved |

A configuration is never simplified to fit an engine: an unsupported request is an error naming the
engine that can run it (docs/SCHEMA_EXTENSIONS.md).

## 4. REST API (`/api/v1`)

JSON in and out. The client sends `Accept: application/json`, `Content-Type: application/json`,
`X-AERIS-Client: aeris-web/4.0` and cookies. CORS allows exactly the configured origins, methods
`GET`/`POST` and those headers.

| Method | Path | Request | Response |
|---|---|---|---|
| GET | `/health` | — | `{status: "ok", backend, version, engine_version, time, db, workers, max_jobs, jobs: {active, queued}, restart_policy, mock: false}` |
| GET | `/capabilities` | — | engine and versions, `parity_target`, `config` (current revision and the revisions read), `experiment` (v5: explicit initial state, reference headings and commands, estimator timing, recovery breakdown), `metrics` (version, reanalysis), controllers/structures/estimators per mode, sensor/actuator/plant models, disturbances, events, recovery and termination defaults, rate limits, `sweep` (modes, revision, criteria, maxRuns, maxDuration_s, maxSteps_per_job, controllers, variables, distributions, seed strategies), `params` spec, `hardware` (bridge name, `live`), `telemetry`, workers. The site sends revision-1.2 features and declared sweep criteria only to a backend that reports them |
| POST | `/validate` | `{config}` or `{sweep}` | `{ok, errors, warnings, config, workload, config_hash}` / `{ok, errors, warnings, workload, total}` |
| POST | `/simulations` | `{config, meta?: {name, group, note}, client?: {site}, parameter_set?}` | `202 {job}`; the finished job has `result_ref: {kind: "run", id}` |
| POST | `/sweeps` | `{sweep: aeris-sweep/1 definition, parameter_set?}` | `202 {job}`; `result_ref: {kind: "sweep", id: "AERIS-SWP-1xxxxx"}` from the start |
| GET | `/jobs?limit=` | — | `{jobs: [aeris-job/1]}` |
| GET | `/jobs/{id}` | — | `aeris-job/1` with `seq` |
| POST | `/jobs/{id}/cancel` | — | the job after the cancellation took effect (§6) |
| WS | `/live/{id}` | — | job updates (§5) |
| GET | `/runs?limit=&offset=` | — | `{runs: [summary]}` |
| GET | `/runs/{id}` | — | `aeris-run/1` revision 1.2 |
| GET | `/runs/{id}/export?format=json\|csv` | — | the record, or CSV with a provenance header |
| POST | `/runs/{id}/reproduce` | — | `202 {job}`; the new record's `reproduction.reproduces` says `identical`, `same_outcome`, `max_abs_diff`, `rows` |
| POST | `/reproduce` | a backend run record the client holds | `202 {job}` (only for runs this backend stored) |
| GET | `/sweeps/{id}` | — | `aeris-sweep/1` result: definition, rows, analysis, `partial`, `job` |
| GET | `/sweeps/{id}/rows?offset=&limit=&include_config=` | — | `{sweep_id, offset, rows}` |
| GET | `/sweeps/{id}/rows/{index}` | — | one row with the exact configuration simulated for it |
| GET | `/sweeps/{id}/export?format=csv\|json` | — | CSV (one line per row) or JSON |
| POST | `/compare` | `{run_ids: [1–50]}` | per-metric values and computed labels (ties reported, no overall winner) |
| POST | `/datasets` | `{title, run_ids, sweep_ids, recording_ids, description}` | `201 aeris-dataset/1` (`status: exploratory`); unfinished sweeps → `409 not_finished` |
| POST | `/datasets/{id}/finalize` | — | `status: final`, content hash and software versions; again → `409 already_final` |
| GET | `/datasets`, `/datasets/{id}?embed=` | — | list; one dataset (optionally with its runs and sweeps) |
| GET | `/parameter-sets`, `/parameter-sets/{id}` | — | the nominal set plus stored sets |
| POST | `/parameter-sets` | aeris-parameter-set/1 values with unit, method, date, evidence | `201`; immutable (`409 exists`) |
| GET | `/hardware/status` | — | the telemetry bridge's real state (`connected: false` and the reason in this build) |
| POST | `/hardware/frames/validate` | one frame | strict `aeris-telemetry-frame/1` check |
| POST | `/hardware/recordings` | aeris-hardware-run/1 | `201 {id: AERIS-HW-nnnnnn, content_hash, quality, warnings, synthetic}`; invalid → `422 invalid_recording` |
| GET | `/hardware/recordings/{id}` | — | the stored recording |
| POST | `/validation/protocols` | `{name, description, thresholds}` | `201 {id: AERIS-VP-nnnn, created, …}` |
| GET | `/validation/protocols/{id}` | — | the protocol |
| POST | `/hardware/compare` | `{run_id, recording_id, protocol_id?, max_lag_s}` | comparison `AERIS-CMP-nnnnnn` (§8) |

### Errors

```json
{ "error": { "code": "invalid_config", "message": "…", "details": [ { "path": "params.Jw", "message": "…", "kind": "…" } ], "retryable": false } }
```

| Code | HTTP | Meaning |
|---|---|---|
| `invalid_config` | 422 | the setup failed validation (`details`: path, message, kind) |
| `invalid_sweep` | 422 | the sweep definition failed validation (including workload limits) |
| `invalid_request` | 422 | the body does not match the endpoint's schema |
| `invalid_parameter_set` | 422 | unknown parameter, wrong unit or value out of range |
| `invalid_recording` | 422 | a hardware recording failed strict validation |
| `not_reproducible` | 422 | reproduction asked for a run this backend did not produce |
| `not_found` | 404 | unknown job, run, sweep, row, dataset, parameter set, recording or protocol |
| `exists` | 409 | an immutable object with that id exists |
| `already_final` | 409 | the dataset is final |
| `not_finished` | 409 | a dataset cannot include a running sweep |
| `rate_limited` | 429 | retry later (`retryable: true`; for a proxy in front of the backend) |
| `unavailable` | 503 | busy or down (`retryable: true`) |
| `internal` | 500 | an unexpected server error, reported with its type and message |

Client-side codes (`ResearchApiAdapter`): `network`, `timeout`, `bad_response` (not JSON, unknown job
state, malformed sweep), `bad_record` (a run failed record validation or does not name
`aeris-research-backend` / `research-api` as its origin), `unavailable` (not configured/reachable),
`unhealthy` (`/health` without `status: ok`).

## 5. Jobs and live updates

```
QUEUED → INITIALIZING → RUNNING (done / total) → ANALYZING → COMPLETE
   any non-terminal state → FAILED | CANCELLED
```

* `progress.done` only increases and only counts finished simulations; `progress.total` is fixed once
  RUNNING; terminal states never change (the repository enforces the transitions).
* Every update increments `seq`. WebSocket messages:

```json
{ "type": "job",   "seq": 17, "job": { …aeris-job/1… } }
{ "type": "log",   "level": "info", "text": "…" }
{ "type": "error", "error": { "code": "not_found", "message": "…" } }
```

  The server sends the current job on connect and closes after a terminal state. A connection from
  an origin not in the CORS list is closed with code 4403.
* The adapter follows a job over the WebSocket when `wsUrl` is set, with polling as the fallback and
  as a periodic check; after a drop it reconnects (up to 3 failures) and keeps polling. Updates with
  a `seq` not greater than the last one are ignored; the local mirror walks only legal transitions;
  `result_ref` is copied from every job message. Polling and WebSocket deliver the same job objects
  (`test_websocket_and_polling_agree`).
* Jobs run in a process pool (`--workers`), at most `--max-jobs` at a time; the API event loop never
  simulates.

## 6. Cancellation

Cooperative: each running job has a flag that workers check every 1024 integration steps.

| When | Result |
|---|---|
| before execution (queued) | `cancelled` at once, `done = 0`, message "no runs were computed"; the sweep record is kept, `partial: true`, no rows |
| during execution | finished runs are kept, in-flight runs are dropped (not counted), `done` = stored rows, sweep `partial: true`, analysis computed from the finished rows |
| during analysis | all runs kept, analysis not computed (`analysis: null`, `analysis_cancelled: true`), not labelled partial (it can be recomputed from the rows) |
| after completion | the terminal job is returned unchanged (same `seq`) |
| single run cancelled after it finished | the finished run is kept (`result_ref` names it) |

The browser labels a cancelled sweep **PARTIAL** and fetches its rows; a cancel request that fails
in transport is reported on the job and retried (up to 5 times). A sweep run by the browser engine (DEMO) cannot be
cancelled during its analysis — every run has finished; its Cancel button is hidden in that state and a late request
is reported, the complete result kept (v5.2; JOBS_AND_RECOVERY.md §4). An adapter states the states in which a
cancel request still takes effect with the optional `cancellable(job)` (`AERIS_SERVICE.cancellable(job)` asks it; an
adapter that does not say accepts it in every non-terminal state). Tests:
`test_cancel_before_during_after_and_during_analysis`, `live_backend.test.js` (during and before
execution), `browser_v4.py` (PARTIAL in the UI).

## 7. Persistence and restart

SQLite (WAL) stores jobs, runs, sweeps and their rows, datasets, parameter sets, recordings,
protocols and comparisons; sweep rows are written as they finish (idempotent by row index).
`--restart-policy resume` (default) re-dispatches unfinished jobs after a restart: sweeps skip rows
already stored (expansion and seeds are deterministic), single runs are recomputed, and the job
message and `restarts` count say so. `fail` marks them `failed` with `error.code: "interrupted"` and
keeps their partial rows. A restarted job never appears complete without having finished
(`test_restart_resume_completes_without_duplicates`, `test_restart_fail_policy_marks_interruption`).

## 8. Records and validation state

* Runs are `aeris-run/1` revision 1.2 (docs/SCHEMA_EXTENSIONS.md §2) with `origin.engine:
  "aeris-research-backend"`, `experiment_id` from the backend's own sequence (`AERIS-EXP-1xxxxx`) and
  the backend's derived mass properties, design, definitions and research results. The browser never
  regenerates them.
* `validation.status` is `nominal` (default parameter set `nominal-design-v1`) or `measured` (only with
  a complete measured parameter set). Software never assigns `validated`.
* `POST /hardware/compare` interpolates the simulation onto the recording's time stamps within the
  overlap, reports per-signal RMSE, mean/peak absolute error, peak-magnitude difference, the best time
  offset within `max_lag_s` and the RMSE after removing it (quaternion geodesic error for attitude),
  and evaluates a protocol's thresholds only for real (not synthetic) recordings ingested after the
  protocol was registered. No hardware recording has been supplied to this project.

## 9. Experiment and object IDs

| Prefix | Range | Issued by |
|---|---|---|
| `AERIS-EXP-` | 000001–000009 Twin reference · 000010–000099 built-in examples · 000100–099999 browser counter · **100000+ backend** | browser / backend |
| `AERIS-SWP-` | 000001–099999 browser · **100000+ backend** (a client-proposed id is kept as `client_ref`) | browser / backend |
| `AERIS-DS-` | 100000+ | backend |
| `AERIS-HW-`, `AERIS-VP-`, `AERIS-CMP-`, `paramset-` | 1+ | backend |

A run's globally unique key is its `id`; the experiment ID is the human-facing label. An imported run
whose experiment ID clashes with a different local run gets a new local ID and keeps the original in
`original_experiment_id`.

## 10. The MOCK backend

`js/adapters/mock-research-backend.js` is an in-memory implementation of the contract used by
`tests/service.test.js` and, only with `mock: true`, to preview SIMULATION mode. Its results are
computed by the browser engine and marked `mock: true` / `origin.engine: "mock-research-backend"`;
the Lab shows **MOCK DATA** on everything it returns. It is not the research backend.

## 11. Hardware telemetry (v5: implemented, tested with synthetic sources only)

HARDWARE mode is selectable when the research backend is reachable and reports `telemetry.available`. The
backend's bridge (`hardware/bridge.py`, `HubBridge`) connects to one source — NDJSON over TCP on this computer, a
replayed file or a stored recording — validates every line against the reference contract
`aeris-telemetry-ndjson/1`, and streams accepted frames over `WS /telemetry/live` (polling: `GET /telemetry/frames`).
Recordings are stored as `aeris-hardware-run/1` with their provenance and can be exported, replayed and compared
with simulated runs. The standalone emulator (`python -m aeris_backend.telemetry.emulator`) is SYNTHETIC and is
never shown as the physical cube; no comparison with synthetic data is validation evidence. Everything is
read-only. Details: [TELEMETRY.md](TELEMETRY.md); what the hardware stage must supply:
[HARDWARE_HANDOFF.md](HARDWARE_HANDOFF.md).

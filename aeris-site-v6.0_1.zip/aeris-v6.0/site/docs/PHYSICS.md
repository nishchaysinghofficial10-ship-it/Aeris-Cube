# AERIS · Physics model and conventions

The model shared by the browser engine (`site/js/core.js`, AERIS Twin 0.3.0) and the Python research
backend (`backend/aeris_backend`, parity target `aeris-twin 0.3.0`). With default settings the backend
reproduces the browser engine operation by operation (checked by `backend/tests/test_parity.py`
against fixtures generated with the browser code); the research extensions add explicit inertia
tensors, components, per-wheel parameters, more disturbance and event types, separate integration /
control / sensor / recording rates and lift-off detection.

All parameters are **nominal design values** until measured on the physical cube (see
`HARDWARE_NEXT_STEPS.md`). Nothing in this document is a hardware measurement.

---

## 1. Frames, quaternions and signs

| Item | Convention |
|---|---|
| World frame | right-handed, **z up**, gravity `g_W = (0, 0, −g)` |
| Body frame | origin at the **pivot vertex O**; axes along the three cube edges that meet at O |
| Quaternion | **`q = [w, x, y, z]`** (scalar first), unit norm, **body → world**: `v_W = R(q) v_B` |
| Sign ambiguity | `q` and `−q` are the same attitude; every error/angle uses `|⟨q₁, q₂⟩|` (sign-invariant geodesic angle `2·acos|⟨q₁,q₂⟩|`) |
| Kinematics | `q̇ = ½ q ⊗ (0, ω)` with `ω` the body angular velocity **in body axes** |
| Rotation vector | `exp(φ)` / `log(q)` take the short way (`w ≥ 0` before `log`) |
| Wheel *i* | spin axis `a_i` (unit, body frame); standard set: `a_x, a_y, a_z` = body axes |
| Wheel speed | **`Ω_i` relative to the body** (what an encoder measures) |
| Motor torque | `T_i` acts **on wheel i** about `a_i`; the body receives the reaction `−T_i a_i` |
| Edge mode | the cube pivots about the **body x axis** (the support edge through O); tilt `θ` about x |
| Balance | COM lean `e`: angle between the COM direction `r_c/|r_c|` and the world vertical |

`AERIS_TWIN.Q3.rot`, `backend/aeris_backend/physics/quaternion.py:rot` and the tests
`test_quaternion_rotation_maps_body_to_world`, `test_sign_ambiguity_same_attitude`,
`test_exp_log_roundtrip_and_short_way`, `test_kinematics_qdot_matches_body_rate` fix these conventions.

## 2. Mass properties (`physics/mass.py`)

Reference point: the pivot vertex **O**. All tensors are 3×3, symmetric, body axes, kg·m².

```
M      = m_base + Σ m_k (components) + Σ m_j (point attachments)
r_c    = (m_base r_0 + Σ m_k r_k + Σ m_j r_j) / M
Θ_O    = Σ over parts ( I_c,part + m_part S(r_part) ),    S(r) = |r|² I − r rᵀ   (parallel-axis theorem)
```

* **Base** (frame, electronics and the wheels as *locked* rigid parts): mass `m`, COM
  `r_0 = (a/2, a/2, a/2) + δ n̂ + Δr` (browser) or `plant.base_com_m`; inertia about its own COM
  `k_J m a² I` (browser's isotropic approximation) or the full tensor `plant.base_inertia_kgm2`.
* **Components** (`plant.components`): rigid bodies with mass, COM and their own inertia tensor about
  their COM. **Attachments**: point masses (own inertia ignored, as in the browser).
* Off-diagonal terms are kept everywhere.
* `Θ_O` **includes the wheels locked** (their mass and full inertia). The dynamics subtract the spin
  inertia of each wheel about its own axis:  `Θ̂ = s_J Θ_O + ΔΘ − Σ J_i a_i a_iᵀ`
  (`s_J` = `uncertainty.inertiaScale`, `ΔΘ` = `uncertainty.inertia_perturbation_kgm2`, both applied
  to the **plant** only — the controller's model does not know them).
* Validation (`check_tensor`): symmetric (to 1e-9 relative), positive definite (components may be
  positive semidefinite), principal moments satisfy the triangle inequality `I₁ + I₂ ≥ I₃`; `Θ̂` must be
  positive definite; the COM must lie where the cube can balance (edge: `0 < x_c < a`); masses
  and positions are range-checked.

Tests: `test_parallel_axis_and_combination`, `test_tensor_checks`,
`test_validation_rejects_bad_component_tensor`.

## 3. Corner mode (fixed point pivot)

State: `q`, `ω` (body), `Ω_i` (relative). Angular momentum about O (body axes):

```
H = Θ_O ω + Σ J_i Ω_i a_i            (Θ_O with the wheels locked; Ω_i relative ⇒ no double counting)
```

Euler's equation about the fixed pivot and the wheel equations (`T_n,i = T_i − f_i(Ω_i)`, friction
`f(Ω) = c_v Ω + c_c tanh Ω`; a failed wheel has `T_i = 0` but still feels friction):

```
d/dt(Θ_O ω + Σ J_i Ω_i a_i) + ω × H = τ_g + τ_ext
J_i (a_i·ω̇ + Ω̇_i) = T_n,i                                  (wheel i about its axis)

⇒  Θ̂ ω̇ = −ω × H + M r_c × g_B + τ_ext − Σ T_n,i a_i          Θ̂ = Θ_O − Σ J_i a_i a_iᵀ
    Ω̇_i = T_n,i / J_i − a_i·ω̇                                (the body-acceleration coupling)
    g_B = R(q)ᵀ (0, 0, −g)
```

* The motor reaction appears exactly once (`−Σ T_n,i a_i` on the body, `+T_n,i` on the wheel):
  `test_motor_torque_is_equal_and_opposite` checks that with gravity off and no friction the total
  angular momentum stays constant while a motor spins its wheel.
* Torque-free with `g = 0`: `H` in world axes and the kinetic energy
  `½ωᵀΘ_Oω + Σ J_i(½Ω_i² + Ω_i a_i·ω)` are conserved (`test_torque_free_body_conserves_momentum_and_energy`).
* Gyroscopic cross-coupling `−ω × H` is present (`test_gyroscopic_cross_coupling`).
* The balanced attitude (`r_c` straight above O) is an equilibrium; small tilts diverge at
  `λ = sqrt(M g l / Θ̂_⊥)` (`test_balance_attitude_is_an_equilibrium_and_small_tilt_diverges_at_lambda`).

External loads (`disturbances`): a torque `τ` (body or world frame, world vectors rotated into the
body with `Rᵀ`), or a force `F` at the body-frame point `r` giving `τ = r × F_B`.

**Contact assumptions.** The pivot is an ideal fixed point: no slip, no rolling, no bounce, and it can
push but not pull. The vertical pivot reaction is
`N_z = M (a_c,z + g) − F_ext,z` with `a_c = ω̇ × r_c + ω × (ω × r_c)` (world z component). With
`termination.check_lift_off` (default on in the backend) the run ends with termination
`loss_of_support` when `N_z ≤ 0`: the model is no longer valid (`test_lift_off_is_loss_of_support`).
The browser engine has no lift-off check (it keeps integrating the pivot model); for runs where the
reaction stays positive the two agree.

**Fall and floor contact** (outcome rules, both engines): the COM lean passes the fall threshold
(`ASSESS.fallCornerDeg`) or one of the three edges meeting at O reaches the floor; motors stop and
recording continues for `termination.post_fall_s` (1.5 s, browser behaviour) or until floor contact.

## 4. Edge mode (fixed hinge about body x)

The support edge is an ideal hinge along body x through O; only the rotation `θ` about it moves.

```
Θ̂_xx θ̈ = M g l sin(θ + β) + τ_ext,x − Σ a_i,x T_n,i
Ω̇_i    = T_n,i / J_i − a_i,x θ̈
l = sqrt(y_c² + z_c²),   β = atan2(r_c·n̂, r_c·d̂)       (d̂ = (0,1,1)/√2, n̂ = (0,−1,1)/√2)
```

`Θ̂_xx = [Θ_O]_xx·s_J + ΔΘ_xx − Σ J_i a_i,x²`. The hinge carries every other reaction; the vertical
reaction is checked for lift-off as above. Tests: `test_edge_hinge_motor_reaction`,
`test_gravity_torque_sign_edge`.

## 5. Actuators (`actuators.py`)

Per wheel (browser `tauAvail`, extended per wheel):

```
|T| ≤ τ_max·h            τ_max = s_τ k_t I_max,  k_t = 60/(2π K_V),  h = health (degradation events multiply it)
if T·Ω > 0:  |T| ≤ h·max(0, k_t (V_s − k_e|Ω|)/R)      back-EMF / supply limit
             T = 0 once |Ω| ≥ Ω_max                   speed cut-off: loss of authority in that direction
braking (T·Ω ≤ 0): current limit only
```

* Speed saturation is a **loss of authority** (the driver stops accelerating the wheel); the speed
  state itself is never clamped, so no momentum disappears (`test_speed_saturation_is_loss_of_authority_not_clipping`).
* Motor lag: first-order `T ← T + (T_cmd − T)·(1 − e^{−Δt/τ})` at every integration step.
* Electrical limit applied to the command at each control update (`command`, browser) or also to the
  lagged torque at every integration step (`continuous`).
* Requested (allocated command), applied (after limits and lag) and body-level shortfall are
  recorded at every integration step (`research.torque`, `research.authority`).
* Wheel events (`events`): `wheel_failure` (optional `duration_s` → clearance), `wheel_degradation`
  (health factor), `wheel_torque_limit`, `wheel_speed_limit`, each with an optional duration. They
  switch at the first integration step at or after their time and are logged (`executed.schedule`).

## 6. Disturbances and events (`simulation/disturbances.py`)

| Type | Fields | Numerical treatment |
|---|---|---|
| `force` | `magnitude_N`, `point_m`, `direction`, `frame`, `t_start_s`, `duration_s` | continuous, active for `t_start ≤ t < t_start + duration`, inside every RK4 stage |
| `torque` | `magnitude_Nm`, `direction`, `frame`, `t_start_s`, `duration_s` | continuous, as above |
| `bias` (research) | `magnitude_Nm`, `direction`, `frame`, `t_start_s`, `duration_s` (null = to the end) | continuous constant torque |
| `impulse` (research) | `magnitude_Nms` [N·m·s], `direction`, `frame`, `t_s` | **instantaneous momentum jump** at the start of the first step at or after `t_s`: `Δω = Θ̂⁻¹ J_B`, `ΔΩ_i = −a_i·Δω` (the wheels are dragged with the body) |
| `force_impulse` (research) | `impulse_Ns` [N·s], `point_m`, `direction`, `frame`, `t_s` | as `impulse` with `J = r × p` |

A finite pulse is a `torque` or `force` with a short duration; an impulse is the zero-duration
limit with an explicit unit. The schedule actually executed (and each impulse applied, in body
axes) is saved in `executed.schedule` / `executed.impulses_applied`.

## 7. Integration, rates and determinism

* Fixed-step **RK4**; the command is held constant over each control period (zero-order hold).
* Rates: integration `solver.integration_hz` (default = control rate `params.fs`), control `params.fs`
  (an integer divisor of the integration rate), IMU `sensor.rate_hz` (an integer divisor of the
  integration rate), recording `record_hz`. Recording only reads the state, so **the recording rate
  does not change the trajectory or the metrics** (`test_recording_rate_does_not_change_the_trajectory_or_metrics`).
* Research metrics are computed at every integration step, never from the recorded samples.
* The quaternion is renormalised after each step; a drift above `termination.max_quaternion_drift`
  or a non-finite state ends the run as `invalid_state` / `numerical_failure` (outcome invalid).
* Convergence: `test_rk4_against_high_accuracy_reference_and_order` compares against a
  high-accuracy reference (SciPy DOP853, rtol 1e-12, atol 1e-14) at 500–4000 Hz and confirms the 4th-order error reduction (observed order 3.6–4.4, error < 1e-9 at 4 kHz).
* Determinism: the same configuration and software versions on the same platform reproduce every
  sample exactly (demonstrated by the reproduction tests). Across platforms results agree to
  floating-point tolerance; bit-identical results across machines are **not** promised. Parity with the
  browser: cases without sensor noise agree in every recorded sample within one unit of its 6th
  significant digit (most columns bit-identical on the test machine), with identical outcomes and
  timelines; noisy cases differ only through ~1-ulp differences between V8 and glibc `log/cos` in the
  Box–Muller draws (identical outcomes and timelines, integral metrics within 0.1 %; tolerances are
  stated in `test_parity.py`).

## 8. Termination vs outcome

`termination.reason` says why the run stopped: `duration`, `recovery` (only with
`termination.stop_on_recovery`), `fall`, `loss_of_support`, `invalid_state`, `numerical_failure`,
`safety_limit` (`termination.overspeed_rpm`), `cancelled`, `invalid_config`. The **outcome**
(`recovered`, `not_settled`, `drifting`, `fallen`, `invalid`) is decided by the browser's rules on the
recorded window and keeps its legacy meaning; the research recovery criteria are separate
(`RESEARCH_PLATFORM.md` §7, `research.recovery`).

## 9. Known model limits

* Rigid bodies; ideal point pivot / hinge (no slip, no compliance, no bounce); lift-off ends the run.
* Wheels are balanced and axisymmetric; bearing friction is viscous + Coulomb (tanh smoothed).
* Motor electrical dynamics are reduced to a first-order torque lag; the driver delivers the
  commanded current within the current and back-EMF limits.
* No air drag, no cable forces, no floor friction model beyond the pivot assumption.
* Parameters are nominal design values; no identification against the physical cube has been done.

# AERIS · Sensors and state estimation

Implemented in `backend/aeris_backend/sensors.py` (sensor models) and
`backend/aeris_backend/estimation/__init__.py` (estimators); the browser's edge estimators are in
`site/js/core.js` (`simEdge`). All parameters are **nominal**: no sensor on the physical cube has been
characterised yet, so noise densities, biases, latency and dropout are assumptions until a recording
says otherwise (see `HARDWARE_NEXT_STEPS.md`).

## 1. Who may read what

```
true state ──► sensor model ──► time-stamped samples ──► estimator ──► Estimate ──► controller
                                                                  wheel encoders Ω_i ─┘
```

* Sensor models read the true state (that is what a sensor does) and add noise, bias, quantisation,
  latency and dropout.
* Estimators see only the samples. Controllers see only the `Estimate` (attitude or tilt, body rate,
  bias estimate) and the relative wheel speeds.
* The one exception is the **perfect-state baseline** `estimator.type: "ideal"`, which copies the true
  attitude and rates into the Estimate. Every record states which ran: `executed.estimator.type`,
  `name` and `truth_access` (`true` only for `ideal`).
* Tests: `test_estimator_based_controller_does_not_read_truth` (a spy controller receives the
  estimated quaternion — the recorded `qh*` columns — not the true one),
  `test_perfect_state_baseline_is_labelled`.

## 2. Which estimators run where

| `estimator.type` | Edge (hinge) | Corner (point pivot) | Engine |
|---|---|---|---|
| `ideal` | ✓ | ✓ | browser and backend |
| `accel`, `gyro`, `cf`, `kf` | ✓ | — | browser and backend (identical algorithm, parity-tested) |
| `cf3d` (quaternion complementary filter) | ✓ | ✓ | backend only |
| `mekf` (multiplicative EKF) | ✓ | ✓ | backend only |

A request the selected engine cannot run is refused with a `capability` error that names the engine
that can (for example: the browser refuses `mekf`; corner mode refuses `kf`). There is no silent
fallback to another estimator or to ideal sensing.

## 3. Sensor models

### 3.1 Edge sensor of the browser engine (`EdgeImuLegacy`) — used by `accel`, `gyro`, `cf`, `kf`

Reproduced draw for draw from the browser (same random stream and order), sampled at the control rate:

```
b   ← b + σ_bw √Δt · n                     gyro bias random walk
ω_m = θ̇ + b + σ_g · n                      one gyro axis about the hinge
a_m = θ − r_IMU θ̈ / g + σ_a/g · n          accelerometer tilt angle (small angle; θ̈ from the previous step)
```

then quantisation (`gyro_quant_dps`, `accel_quant_deg`; JavaScript `Math.round` semantics), a latency of
`round(latency_ms · f_s)` samples and packet dropout (a dropped packet repeats the previous one).
Parity: `test_parity.py` (fixtures `edge-kf-noisy`, `edge-cf`, `edge-accel`, `edge-gyro`;
`test_noise_cases_within_stated_tolerance`).

### 3.2 Three-axis IMU (`Imu3D`) — used by `cf3d` and `mekf`

Sampled at `sensor.rate_hz` (default: the control rate):

```
gyro  = ω + b + σ_g n                        b_i ← b_i + σ_bw √Δt_s n   (per axis)
accel = g·û_B + a_IMU + b_a + σ_a n          specific force in body axes; û_B = R(q)ᵀ e_z
a_IMU = ω̇ × r + ω × (ω × r)                  the pivot is fixed; r = IMU position (sensor.imu_position_m)
```

* Default IMU position: `r_IMU` (`params.rImu`) along the body diagonal (corner) or the edge direction
  (edge). `sensor.accel_dynamic: false` measures gravity only (a documented approximation).
* Initial gyro bias `sensor.gyro_bias_dps` on **every** axis; accelerometer bias
  `sensor.accel_bias_mps2` (default zero).
* Quantisation: gyro step in °/s; accelerometer step `g · accel_quant_deg` (in rad) m/s².
* Latency: a sample is delivered `latency_ms` after it was taken and keeps its measurement time stamp.
* Dropout: a lost sample is not delivered at all (the estimator coasts on the gyro).
* Tests: `test_seeded_noise_reproducible_and_seed_dependent`,
  `test_latency_delays_delivery_and_keeps_timestamps`, `test_dropout_fraction`.

## 4. Browser edge estimators (unchanged)

Tuned for the nominal sensor (`SENSOR` in `core.js`: `τ_cf = 0.5 s`, `R_kf = 2°`, …); changing the
simulated sensor therefore tests a mismatched filter, as on hardware.

* `accel`: `θ̂ = a_m`. `gyro`: `θ̂ ← θ̂ + ω_m Δt`.
* `cf`: `θ̂ ← α (θ̂ + ω_m Δt) + (1 − α) a_m`, `α = τ_cf / (τ_cf + Δt)`.
* `kf`: two states `[θ, b]`, prediction `θ ← θ + (ω_m − b) Δt`, measurement `a_m`,
  `Q = diag(σ_g² Δt², σ_bw² Δt)`, `R = R_kf²` (`estimator.Rkf_deg` overrides `R_kf`).

## 5. Quaternion complementary filter (`cf3d`)

```
propagate   q̂ ← q̂ ⊗ exp((ω_m − b̂) Δt)
measure     f = a_m − (α̂ × r + ω̂ × (ω̂ × r))          (dynamic compensation, §7)
gate        skip if | |f| − g | > accel_gate_mps2
correct     e = f̂ × û_B(q̂),  q̂ ← q̂ ⊗ exp(k e),  k = Δt / (τ + Δt)
bias        b̂ ← b̂ − k_b Δt e                          (optional, estimator.cf3d.bias_gain; default 0)
```

Settings `estimator.cf3d`: `tau_s` 0.5, `accel_gate_mps2` 0.5, `bias_gain` 0, `tau_alpha_s` 0.02,
`compensate_dynamic` true. Without bias estimation the steady tilt error is about gyro bias × τ.
Test: `test_complementary_filter_converges_in_tilt` (< 0.4° at a static 2° attitude).

## 6. Multiplicative extended Kalman filter (`mekf`)

Error state `δx = [δθ, δb]` (body-frame attitude error, gyro-bias error); the reference quaternion
carries the attitude, so the quaternion is never part of the covariance.

```
propagation (Δt, ω̂ = ω_m − b̂)
  q̂ ← q̂ ⊗ exp(ω̂ Δt)
  Φ   = [[exp(−[ω̂ Δt]×), −I Δt], [0, I]]
  Q_d = [[((σ_g Δt)² + σ_bw² Δt³/3) I, −σ_bw² Δt²/2 I], [−σ_bw² Δt²/2 I, σ_bw² Δt I]]
  P   ← Φ P Φᵀ + Q_d

update with the measured gravity direction
  z = f / |f|  (f as in §5; gated when | |f| − g | > accel_gate_mps2)
  h = R(q̂)ᵀ e_z,   H = [[h]×, 0]
  R_m = ((σ_a / g)² + σ_dir²) I,   σ_dir = accel_direction_sd_deg (default 1°)
  K = P Hᵀ (H P Hᵀ + R_m)⁻¹,   δx = K (z − h)
  P ← (I − K H) P (I − K H)ᵀ + K R_m Kᵀ         (Joseph form, then symmetrised)
  q̂ ← q̂ ⊗ exp(δθ),   b̂ ← b̂ + δb
```

* Noise levels: `estimator.mekf.gyro_noise_dps`, `gyro_bias_walk_dps`, `accel_noise_mps2`; `null`
  (default) means "the configured sensor" (a matched filter). Set them to study a mismatched filter.
* Initial covariance: `init_attitude_sd_deg` 5°, `init_bias_sd_dps` 1 °/s. Static alignment: tilt from
  the first accelerometer sample, heading from the nominal attitude (gravity carries no heading).
* The covariance is kept at the reset (reset Jacobian taken as I — first-order, standard for small
  corrections). `σ_dir` stands for what the dynamic compensation leaves of the motion acceleration;
  it is an assumption, not a measured value.
* Tests: `test_mekf_tilt_converges_bias_estimated_on_observable_axes_quaternion_normalised` (static
  3° tilt: tilt error < 0.05°, horizontal bias component within 0.1 °/s, `|q̂| = 1` to 1e-12,
  symmetric positive-definite `P`, heading variance > 10 × tilt variance),
  `test_mekf_heading_is_unobservable_from_gravity_tilt_is_not`.

## 7. Dynamic-acceleration compensation

The accelerometer is not at the pivot, so it also measures `α × r + ω × (ω × r)`. `cf3d` and `mekf`
subtract `α̂ × r + ω̂ × (ω̂ × r)` with `ω̂ = ω_m − b̂` and `α̂` a first-order low-pass (time constant
`tau_alpha_s`) of the finite difference of `ω̂`, using the configured IMU position `r` (an
installation parameter, not the true state). `compensate_dynamic: false` turns it off.

## 8. Observability: what gravity can and cannot tell

A gravity direction fixes **tilt** (two angles) and the **horizontal** components of the gyro bias. It
says nothing about rotation about the vertical, so neither the heading nor the vertical bias component
is observable. In corner mode the estimated heading drifts at the vertical bias component and the
MEKF's heading variance grows without bound, while the tilt variance converges.

A real backend run shows the consequence (corner, LQR decoupled, 2° initial tilt, 20 s, seed 3,
default sensor with `gyro_bias_dps = 0.5` on every axis; nominal parameters, software result):

| estimator | true heading after 20 s | tilt RMSE | full attitude RMSE | final heading σ (MEKF) | final tilt σ (MEKF) | research recovery, `yaw_objective: hold` | `free` |
|---|---|---|---|---|---|---|---|
| `ideal` | 0.00° | — | — | — | — | recovered | recovered |
| `cf3d` | −17.12° | 0.066° | 9.92° | — | — | **not recovered** | recovered (0.37 s) |
| `mekf` | −17.39° | 0.059° | 9.36° | 19.8° | 0.027° | **not recovered** | recovered (0.37 s) |

The vertical at the corner balance is the body diagonal, so the unobservable bias component is
`0.5 · √3 ≈ 0.87 °/s`; over 20 s that is about 17°, which is the heading the controller "held" while
the cube actually turned. The legacy outcome still reads *recovered* (the browser rules assess tilt
only); the research criterion with `yaw_objective: hold` correctly fails. For tilt-only studies use
`recovery.yaw_objective: "free"`; holding heading needs an absolute yaw reference (magnetometer,
optical or encoder-based heading), which is not modelled.

Reproduce:

```bash
cd backend
python - <<'PY'
from aeris_backend.simulation import simulate
for est in ("ideal", "cf3d", "mekf"):
    r = simulate({"mode": "corner", "controller": {"type": "lqr"}, "estimator": {"type": est},
                  "initial": {"tilt_deg": 2}, "duration_s": 20, "seed": 3})
    print(est, r["samples"]["cols"]["psi"][-1] * 57.29578, r["research"]["estimator"], r["executed"]["estimator"]["stats"])
PY
```

## 9. What a record contains

* `config.sensor`, `config.estimator` (with every setting, defaults filled in) and
  `executed.estimator` (`type`, `name`, `truth_access`, `stats`: samples delivered/dropped,
  accelerometer updates/gated, and for the MEKF `final_heading_sd_deg`, `final_tilt_sd_deg`,
  `final_bias_sd_dps`).
* Samples: edge `thetahat`, `bias_est`, `gyro_bias`; corner with `cf3d`/`mekf` `qh0…qh3`,
  `bias_est_{x,y,z}`, `gyro_bias_{x,y,z}` (true), `est_err` (geodesic estimate error).
* `research.estimator`: `attitude_rmse_deg`, `tilt_rmse_deg` (the observable part),
  `attitude_error_final_deg`, `bias_error_final_dps`, `bias_error_rms_dps`, with a note that the full
  attitude error includes the unobservable heading.
* Timeline: `estimator_warning` when the estimate is more than the configured angle from the truth for
  the configured time (browser rule, extended to the 3-D error).

## 10. Limitations

* No magnetometer, no optical or encoder-based heading: heading is unobservable (§8).
* The MEKF measurement noise `σ_dir` is an assumed allowance for residual motion acceleration.
* The IMU position and noise levels are nominal; accelerometer scale factor, misalignment,
  temperature drift and vibration are not modelled.
* The browser engine has no 3-D estimator; corner mode in the browser uses ideal state feedback.

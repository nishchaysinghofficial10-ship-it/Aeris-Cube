# Research engine audit (v5)

What was retained, what was checked, how, and where the evidence is. Every item names a test or a script that can
be re-run; none of this is a claim of global stability or robustness — each check covers the cases it states.

| Area | What was checked | Evidence |
|---|---|---|
| Mass properties | parallel-axis combination of base, components and attachments; full inertia tensor checks (symmetric, positive definite, triangle inequality); bad component tensors rejected | `test_physics.py::test_parallel_axis_and_combination`, `test_tensor_checks`, `test_validation_rejects_bad_component_tensor`; `test_parameters.py` |
| Quaternion kinematics | rotation body → world, sign ambiguity, exp/log, `q̇ = ½ q ⊗ ω`, balance attitude puts the diagonal vertical | `test_physics.py` (first five tests) |
| Rigid body + wheels | torque-free momentum and energy conserved to 1e-9; motor torque equal and opposite (total H stays 0); hinge momentum in edge mode; lossless **mechanical energy with gravity** conserved to 1e-9 (corner and edge) | `test_physics.py`, `test_engine_audit.py` |
| Torque signs | gravity torque sign (edge); wheels spin up in the torque direction, body the other way; gyroscopic coupling ω × H against the formula | `test_physics.py` |
| Off-diagonal coupling | with products of inertia, a torque on wheel x accelerates the body about y and z exactly as Θ̂⁻¹ says (rtol 2e-3 on a finite difference); removing them changes the response | `test_engine_audit.py` |
| Normalisation | \|q\| renormalised every step (≤ 1e-14 over a long tumble); the per-step drift before renormalisation is monitored and a step beyond `termination.max_quaternion_drift` ends the run as a numerical failure | `test_engine_audit.py` |
| RK4 | order 3.6–4.4 against an **independent** DOP853 solution (SciPy, rtol 1e-12) of the documented equations; errors 4.8e-11 → 9e-15 from 500 to 4000 Hz | `test_physics.py`, `studies/solver_verification.py` → `studies/results/solver-verification/` |
| Recording | the recording rate never changes the trajectory or the metrics; samples are integration-step states | `test_physics.py`, `test_recording.py` |
| Actuators | torque limit and back-EMF speed limit respected under a saturating command; current and back-EMF limits, first-order motor lag, wheel health and degradation caps, friction, failures (friction remains), speed saturation reported as loss of authority | `test_engine_audit.py`, `test_actuators_estimation.py` |
| Disturbances | force windows act during their window and not before (browser and backend share the definitions); impulses and pushes run through the recording and metric paths | `site/tests/browser_check.py`, `test_parity.py` (shared fixtures), `test_recording.py`, `test_control_metrics.py` |
| Sensors, truth vs estimate | seeded noise, latency with time stamps, dropout fraction; controllers see only estimates (an estimator-based controller never reads the truth; the `ideal` baseline is labelled); MEKF tilt converges and the heading is unobservable from gravity; estimator timing lifecycle | `test_actuators_estimation.py`, `test_estimator_timing.py` ([ESTIMATION_TIMING.md](ESTIMATION_TIMING.md)) |
| PID, nominal LQR, COM-adaptive LQR | Riccati residual and closed-loop stability of the designs; anti-windup; browser parity | `test_control_metrics.py`, `test_parity.py` |
| **Controller/model consistency** | a small-tilt edge LQR run with the losses the design ignores switched off follows `exp((A − BK)t)·x₀` of its own design model (≈ 0.8 % of the peak; tolerance 2 % tilt, 3 % wheel speed); the designed closed-loop poles equal the eigenvalues of A − BK | `test_engine_audit.py` |
| Coupled MIMO LQR | linearisation rank 8 of 9: the **vertical angular momentum is conserved** (hᵀA = hᵀB = 0) and cannot be controlled; the design stabilises the controllable subspace and refuses non-stabilisable designs; uses the full tensor; not three scalar loops; redesign after a wheel failure reported; a free heading is refused with it | `test_control_metrics.py`, `test_experiment_contract.py`; [CONTROLLERS.md §4](CONTROLLERS.md) |
| Nonlinear quaternion PD | with an exact model the error follows the designed second-order dynamics within 0.5 %; beyond the torque capability it falls like any controller | `test_control_metrics.py`; limitations in [CONTROLLERS.md §6](CONTROLLERS.md) |
| Allocation | clip / bounded least squares; authority residual equals the saturation shortfall | `test_control_metrics.py::test_authority_residual_matches_saturation_and_reports_lost_authority` |
| No silent substitution | the executed controller/estimator/structure is the requested one or the request is refused with a field error | `test_control_metrics.py::test_no_silent_controller_substitution`, `test_experiment_contract.py` |
| Sweeps | grid / random / Monte Carlo sampling, exact truncated normal, out-of-range samples kept as INVALID rows, paired seeds, workload limits before execution, rows keep values/seed/hash, failed and invalid runs retained, analysis only from rows (Wilson, exact McNemar), declared criterion; **identical rows with 1 and 3 worker processes and after a crash-and-resume** | `test_sweeps.py`, `test_engine_audit.py`, `test_experiment_contract.py` |

## Known limitations (stated, not hidden)

* **Conserved vertical momentum** (corner): no controller can remove an initial yaw rate or wheel momentum along the
  vertical — physics, not a tuning issue ([CONTROLLERS.md §4](CONTROLLERS.md)).
* **Linear designs** (PID, LQR, MIMO LQR) are designed about the balance attitude without actuator limits; their
  region of attraction is finite. In the nominal campaign the edge-mode recoverable set on the sampled
  tilt × rate grid was identical for PID, LQR and COM-adaptive LQR because every failing point was torque-limited
  from the first step ([studies/README.md](../../studies/README.md), S2).
* **Nonlinear PD**: no guarantee under torque saturation, model error or estimator error; discontinuous at 180°
  errors; after a wheel failure the remaining wheels may not realise the 3-D request.
* **Heading** is unobservable from gravity and gyro: the 3-D estimators' heading drifts with the gyro bias (the
  campaign's MEKF full-attitude error of 1–6° is dominated by it; tilt error ≈ 0.1°).
* **Contact**: the support is an ideal fixed pivot/edge with a lift-off check; there is no free-flight or sliding
  contact model (unsupported objectives are refused rather than approximated).
* Everything uses **nominal parameters** until a measured parameter set exists; nothing here is validated against
  the physical cube.

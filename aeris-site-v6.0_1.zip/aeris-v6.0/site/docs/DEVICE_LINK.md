# AERIS device link — `aeris-device-link/1` (v6.0)

The protocol between a **host** (the website over Web Serial, the research backend, a relay in between) and the
**AERIS firmware** (`aeris-fw 0.1.0`). It carries capability negotiation, link sessions, pairing and device
authentication, bounded commands, the device state and the device's telemetry.

**Status.** Implemented on both sides and software-tested: the firmware core's host tests, the native and the
WebAssembly synthetic devices (the same core driving models instead of hardware), a protocol test against the
ESP32-S3 image in the Espressif QEMU emulator, the backend's device tests and the browser suites. **Nothing has run
on a physical board**: real USB-serial adapters, real Wi-Fi/TLS to a public gateway and real-board timing are
untested (§10).

**Principle.** A host requests; the device decides. Nothing a host sends arms the motors: an experiment starts only
after a press of the ARM control **on the cube**, its duration is bounded by the approved configuration, and `stop`
is accepted from any session in every state. Hosts never close a control loop and never resend a command on their
own.

| Side | Implementation |
|---|---|
| Device | `firmware/core/src/link.c` (framing, link messages, sessions, pairing, authentication, service loop), `command.c` (commands), `telemetry.c`, `device.c` and `tasks.c` (state machine, protection, measurements), `config.c` (§8), constants in `firmware/core/include/aeris/device.h` |
| Browser host | `site/js/connect/link.js` (framing, negotiation, sessions, commands), `session.js`, `serial.js` (Web Serial), `synthetic.js` (the WebAssembly device) |
| Backend host | `backend/aeris_backend/devices/linkhost.py`, `compat.py` (§2), `service.py` (leases, commands, telemetry), `api/devices_api.py` (transports, §9) |

The device has two **link slots**, each carrying this protocol independently: `usb` (the board's USB-Serial-JTAG
port; UART0 in the QEMU test image; a pty, stdio or TCP port in the native synthetic device; a function call in the
WebAssembly device) and `net` (the board's own outbound WebSocket to the backend gateway; a TCP port in the native
synthetic device). Link messages carry `"kind"`; telemetry messages carry `"type"` (`aeris-telemetry-ndjson/1`,
[TELEMETRY.md](TELEMETRY.md) §2) and travel on the same links.

Related: [CONNECT.md](CONNECT.md) (the Connect journey and `/api/v6`), [DEVICES.md](DEVICES.md) (profiles, recipes,
calibrations), [FIRMWARE_INSTALL.md](FIRMWARE_INSTALL.md), [`firmware/README.md`](../../firmware/README.md),
[`hardware/INTEGRATION.md`](../../hardware/INTEGRATION.md).

## §1 Framing

One message per line:

```
<json>\t<crc32>\n
```

* `<json>` is one JSON object in UTF-8; `<crc32>` is the CRC-32 (zlib / IEEE 802.3, reflected polynomial
  `0xEDB88320`) of exactly those bytes, written as **8 lower-case hex digits**.
* A framed message is at most **4096 bytes** (`AERIS_MAX_LINE`: JSON + tab + 8 hex digits). A trailing `\r` before
  `\n` is tolerated.
* **Device.** A line that is not framed, has a CRC that is not 8 lower-case hex digits, fails its CRC, is longer than
  4096 bytes (discarded up to the next newline), is not valid JSON, is not an object, has too many tokens or **repeats
  a key** is dropped and answered with `link_error` (`{"kind":"link_error","reason":"frame: CRC mismatch (line
  dropped)"}` …). It never reaches the command handler. Counters per link: `lines`, `bad_crc`, `too_long`,
  `not_json`, `bad_message` (reported by `diagnostics`, §5).
* **Hosts** ignore unframed lines silently — the ESP32-S3 ROM prints boot text on the same port — and drop lines with a
  bad CRC, over-long lines and non-JSON lines, counting them (`stats.unframed`, `bad_crc`, `too_long`, `not_json`).
  Hosts never answer with `link_error`.
* **Transmit side of the device.** Each link has a 16 KiB transmit buffer (`AERIS_TX_BUF`). A message that does not
  fit is dropped and counted (`tx_dropped_lines`). Telemetry frames leave 4096 bytes of the buffer free for control
  messages; a frame that does not fit is dropped and counted (`tx_dropped_tlm`) and can be asked for again (§7).
* Hosts refuse to send a command whose framed line would exceed 4096 bytes (`link.js` throws, `linkhost.py` raises;
  the sequence number is not consumed).

## §2 Versions and capability negotiation

A host opens a link with `host_hello`; until then the device answers every other message with `link_error`
`"send host_hello first"`.

```json
{"kind":"host_hello","versions":[1],"host":"browser"}
```

`host` is a name of `[A-Za-z0-9._:-]` (up to 15 characters; otherwise `"unknown"`). Without version 1 in `versions`
the device answers `link_error` `"host_hello: no common link version …"`. A `host_hello` on a link that has a session
drops that session (`"the host started a new link"`, §3). The device then sends `dev_hello`, its `state` (§6) and —
if a telemetry session exists (an approved configuration is applied) — the telemetry `hello` (§7).

`dev_hello` (from the native synthetic device):

```json
{"kind":"dev_hello","link":"aeris-device-link/1","versions":[1],"device_id":"synthetic-doc-0001","boot_id":"9ccfe1db530ba1bc",
 "fw":{"name":"aeris-fw","version":"0.1.0","build":"dev","actuation_build":true,"commissioning_build":true},
 "board":{"id":"aeris-synthetic","chip":"host","kind":"emulator","synthetic":true},"pubkey":null,"paired":false,
 "state":"DISARMED","config_hash":null,"link_name":"usb",
 "caps":{"actions":["identify","diagnostics","self_test","calibrate_imu","calibrate_axes","check_encoders","apply_config",
         "start_experiment","stop","clear_faults","set_telemetry","enter_update","reboot","set_network","unpair","commission","motor_test"],
         "controllers":["edge-lqr","corner-mimo-lqr"],"estimators":["cf3d"],"imu":"lsm6dsox","motor":"odrive-cansimple",
         "config_schema":"aeris-device-config/1","max_control_hz":1000,"max_ttl_ms":10000,"max_line":4096},
 "limits":{"hard_max_current_A":10,"hard_max_torque_Nm":1,"hard_max_speed_rpm":8000}}
```

| Field | Meaning |
|---|---|
| `device_id` | the device's identity (a board's is `aeris-` + its factory MAC address; the synthetic devices' are given) |
| `boot_id` | random per boot: a host can tell a reboot from a reconnection |
| `fw.version`, `fw.build` | firmware version and build id (source revision and variant, e.g. `…-release`) |
| `fw.actuation_build` | `false` for release images: this build never drives motors; `true` only for experimental builds made from source |
| `fw.commissioning_build` | the per-motor commissioning mode is compiled in (experimental builds only) |
| `board` | board id (`esp32-s3-devkitc-1`, `aeris-synthetic`), chip, `kind` (`physical` for a board, `emulator` for the synthetic devices) and `synthetic` — **declared by the firmware, never verified by the hosts** |
| `pubkey` | the pairing key (P-256, uncompressed point, base64url) or `null` before the first pairing |
| `paired`, `state`, `config_hash` | pairing flag (persisted), current state, SHA-256 of the applied configuration or `null` |
| `link_name` | `usb` or `net`: the slot this hello was sent on |
| `caps` | actions, controllers, estimators, IMU and motor drivers compiled in, the configuration format, the highest control rate, the longest command ttl, the line limit |
| `limits` | the build's hard caps: a configuration can only narrow them |

**Negotiation** (`backend/aeris_backend/devices/compat.py` `negotiate`; the same rule in `link.js`). The link is
supported in **full** when `link` is `aeris-device-link/1`, `versions` contains 1 and `caps.config_schema` is
`aeris-device-config/1`. Otherwise the device is offered **read-only** — `identify`, `diagnostics` and `stop` only —
with the reasons. Nothing is substituted: a controller, estimator, driver or action the device does not advertise is
never sent to it. A device with `fw.actuation_build: false` is labelled "this firmware build never drives motors
(sensing, calibration and telemetry only)". Capabilities are declarations.

**Profile fit** (`compat.profile_fits`, `link.js` `profileFits`): before an approved configuration is built or
applied, the profile and recipe are checked against the hello: the profile's IMU driver and every wheel's driver kind
must be the device's; each wheel's current limit, speed limit and the torque limit implied by its motor model
(`60 / (2π·KV) · Imax`) must be within the hard caps; the recipe's controller (`edge` → `edge-lqr`, `corner` →
`corner-mimo-lqr`) and estimator must be offered, and its control rate must not exceed `max_control_hz`. The backend
refuses a mismatch with HTTP 409 `incompatible` and the list of reasons.

## §3 Link sessions, heartbeats and roles

A host opens a **link session** before sending commands:

```json
{"kind":"session","link_session":"ls-3f9c2a…","lease_epoch":1}
{"kind":"session_ok","link_session":"ls-3f9c2a…","lease_epoch":1,"role":"supervisor"}
```

* `link_session`: 8–47 characters of `[A-Za-z0-9._:-]` (hosts use `ls-` + 20 random hex digits);
  `lease_epoch`: an integer 0 … 2³²−1 (§5).
* On the `net` link a session is accepted only after the device authenticated itself on that connection (§4).
* The **same** `link_session` again updates the lease epoch, which can never decrease (a lease hand-over within the
  session). A **different** one replaces the session: the old one is dropped (`"session replaced by a new one"`) and
  the sequence numbers start again.
* **Role.** `role` is `observer` for a `net` session while a USB session is open on the device, otherwise
  `supervisor`. The rule is enforced for every command at the time it arrives: while a USB session exists, the network
  session may only send `diagnostics` and `stop` (§5).
* **Heartbeats.** Hosts send `{"kind":"heartbeat","link_session":…,"lease_epoch":…}` every **500 ms**. A heartbeat may
  raise the lease epoch (hosts deliver a new epoch this way), never lower it. Every accepted command also counts as a
  heartbeat.
* **Expiry.** Without a heartbeat for **1.5 s** (`AERIS_LINK_TIMEOUT_US`) the device drops the session first and then
  sends `{"kind":"session_expired","link_session":…,"reason":"no heartbeat within 1.5 s"}`. Hosts open a new session at
  once (`linkhost.py` counts `sessions_reopened`; the page's local session does the same); commands of the old session
  are never resent.
* **What dropping a session does** (expiry, replacement, `host_hello`, the link going down): a command waiting for
  the local ARM control on that link fails with the reason; a pairing waiting on that link is cancelled; a running
  experiment started from that link is marked `link_lost` (§6: it ends with a normal stop after
  `limits.link_loss_max_s` unless the **same** session is re-established — a new session id does not resume
  supervision).

## §4 Pairing and device authentication

**Pairing** is a local proof of possession: physical access to the USB port and a press of ARM on the cube.

1. The owner's client obtains a single-use pairing session and nonce from the backend (`POST /api/v6/pairing/start`,
   valid 5 minutes; or the relay's `{"op":"pair"}`, §9).
2. Over **USB only**, in **DISARMED**, with no other local confirmation pending, the host sends
   `{"kind":"pair_begin","session":"pair-…","nonce":"…"}` (session 8–47, nonce 16–96 characters of
   `[A-Za-z0-9._:-]`). The device creates its P-256 key pair if it has none and answers
   `{"kind":"pair_ready","session":…,"expires_in_ms":60000,"confirm":"press the ARM control on the cube"}`; its state
   shows `waiting: {"kind":"pair","local_action":"press ARM",…}`. Otherwise `pair_rejected` with the reason
   (`"pairing needs the local USB link"`, `"pairing needs the DISARMED state"`, `"another local confirmation is
   pending"`).
3. On the ARM press the device signs (ECDSA P-256, SHA-256) the statement

   ```
   AERIS-PAIR-V1\n<session>\n<nonce>\n<device_id>\n<pubkey>\n<board_id>\n<fw_version>\nlocal-confirmed
   ```

   and sends `pair_proof` with `session, nonce, device_id, pubkey, board_id, firmware, build, synthetic,
   local_confirmed: true, alg: "ES256-raw", sig` (`sig`: the 64-byte r‖s, base64url). It stores its paired flag.
4. The backend (`POST /api/v6/pairing/complete`) checks the fields, the local confirmation and the signature against the
   presented key, consumes the pairing session (single use, bound to the owner who started it) and registers the
   device with that public key as its credential. A device registered to another owner is refused (`owned_elsewhere`).

Without a press within 60 s the device sends `pair_rejected` `"no local confirmation within 60 s"`; leaving DISARMED,
a `stop` or the link going down cancels the pairing. Pairing never arms anything.

**Device authentication on the network link.** After `host_hello` the backend's gateway sends

```json
{"kind":"auth_challenge","gateway_id":"aeris-backend","gw_session":"gws-<16 hex>","nonce":"<random>"}
```

and the device (on its `net` link only) answers `{"kind":"auth","device_id":…,"boot_id":…,"pubkey":…,"sig":…,
"alg":"ES256-raw"}` with a signature over

```
AERIS-AUTH-V1\n<gateway_id>\n<gw_session>\n<nonce>\n<device_id>\n<boot_id>
```

or `{"kind":"auth","error":"not paired: this device has no key (pair it over USB first)"}`. The backend verifies the
signature with the key registered at pairing (unknown, revoked or mismatching identities are refused) within
**10 s** of the connection, otherwise it closes the socket (4401). Until then the backend ignores the connection's
state, telemetry and command answers. A socket that presents an HTTP `Origin` is refused (a web page cannot pose as a
device).

**Unpairing and revocation.** `unpair` (USB only, DISARMED) waits for an ARM press, then the device erases its key
and clears its paired flag. `POST /api/v6/devices/{id}/revoke` makes the backend forget the credential and close the
device's connections; the device keeps its key until it is unpaired locally, and a revoked device is refused at
authentication.

## §5 Bounded commands

```json
{"kind":"cmd","id":"b-91c2e07a5d13f4e8","v":1,"link_session":"ls-3f9c2a…","lease_epoch":1,"seq":7,
 "action":"start_experiment","ttl_ms":10000,"config_hash":"8cfbcbed…","params":{"duration_s":10}}
```

| Field | Rule |
|---|---|
| `id` | 1–40 characters of `[A-Za-z0-9._:-]`; idempotency key (without a valid id the answer is `link_error`) |
| `v` | 1 (command format version) |
| `link_session`, `lease_epoch` | the session and lease the command belongs to (§3) |
| `seq` | per-session sequence number, strictly increasing |
| `action` | one of the table below |
| `ttl_ms` | 1 … 10000, measured from the command's **receipt on the device** (no clock synchronisation is assumed) |
| `config_hash` | 64 lower-case hex digits; required by `apply_config` and `start_experiment` |
| `params` | an object (or absent/null) |

**Checks, in order** (the first failure answers `cmd_ack` `rejected` with the reason): id shape → **duplicate id**
(the device remembers its last 32 ids and answers a repeated id with the status it has for it and
`"duplicate":true`, from any session; a command never executes twice) → `v` → `action` present → `link_session`
shape → `lease_epoch` → `seq` → `ttl_ms` → `params` is an object → `config_hash` shape → a session exists on this link
and matches → **local priority** (on `net` while a USB session exists only `diagnostics` and `stop`) → the lease epoch
equals the session's (`"stale lease"`) → `seq` above the last accepted one (`"replayed or reordered command"`; from
here on the sequence number is consumed even if a later check rejects the command) → the action is known → USB-only
actions on USB → actuation build and an applied configuration for `start_experiment` → commissioning build for
`commission` / `motor_test` → the current state allows the action → the action's own parameter and precondition checks.

**Statuses.** `cmd_ack` is `accepted` or `rejected`; then `cmd_result` is `executing` (for actions that take time or
wait for the local control) and finally `completed`, `failed` or `expired` (a wait for the local control that the
command's ttl ended). Both carry the device's `state`; `cmd_result` may carry `reason` and `result`. Delivery is not
execution: a host records what the device said; a command without an answer before its ttl (+2 s) is recorded by
the host as `expired` ("no answer"; never resent automatically — sending the same id again is safe, the device answers
with the cached status). After a backend restart, commands without a final status are marked `expired` and never resent.

| Action | States | Flags | Parameters | Effect / result |
|---|---|---|---|---|
| `identify` | all but UPDATE | | `seconds` 0.5–10 (3) | LED identify pattern; `{seconds}` |
| `diagnostics` | all | observer | — | `imu` (driver, address, present, WHO_AM_I, ODR, reads, bus errors, stale reads, saturated, temperature), `drivers[]` (node, seen, axis state/error, heartbeat and encoder age, bus voltage, temperatures, rx/tx counters), `loop` (period, steps, overruns, last/max/mean step µs), `estimator` (counters), `links[]` (framing counters, dropped lines/telemetry), `telemetry` (session, seq, rate, ring), `inputs` (ARM, stop, dead-man as read now; whether DRIVE_EN is asserted) |
| `self_test` | DISARMED, READY | | — | 3 s with the drivers powered and no torque; refused while the local stop is asserted or a command waits for the local control. Checks (`required`): `local_stop_released`, `imu_present`, `imu_data`, `gravity`, `still`, `estimate`, `configuration`, `driver_wheel_0…2` (heartbeat, no axis error, recent encoder estimates), `bus_voltage` (within the configuration's limits), `loop_timing` (no overrun); informational: `actuation_build`. All pass + a configuration + an actuation build → **READY**; otherwise DISARMED. `{checks[], passed, ready}` |
| `calibrate_imu` | DISARMED, READY | | `seconds` 2–30 (5) | gyroscope bias: averages the raw sensor while the cube rests still; fails when it moved, too few samples arrived or gravity is implausible. `{measurement, frame:"sensor (LSM6DSOX axes, before imu.to_body and gyro bias)", seconds, samples, gyro_mean/std_radps, accel_mean/std_mps2, accel_norm_mps2, temp_c, still, imu, odr_hz, accel_range_g, gyro_range_dps}` |
| `calibrate_axes` | DISARMED, READY | | `seconds` 1–10 (2), `face` (label ≤ 16 characters) | the gravity direction with the cube resting on one face; same result with `face` |
| `check_encoders` | DISARMED, READY | | `seconds` 2–30 (10) | drivers powered and idle (no torque) while each wheel is turned **by hand** in its marked positive direction; refused while the stop is asserted. `{seconds, velocity_sign, wheels[{index, node, seen, heartbeat, axis_error, encoder_updates, pos_rev_min/max, travel_rev, vel_rads_min/max}]}` (velocities with the configured sign) |
| `apply_config` | DISARMED, READY | | `config` (aeris-device-config/1, §8) | `config_hash` must equal the SHA-256 of the `params.config` bytes **as received**; every field is validated (first error with its path). Applies the configuration (not persisted), sets up the IMU and drivers, starts a new telemetry session, → DISARMED (`"configuration applied: run the self-test"`). `{config_hash, profile_hash, recipe, mode, controller, control_hz, telemetry_hz, imu_present, telemetry_session}` |
| `start_experiment` | READY, ARMED | actuation | `duration_s` 0.1 … `limits.duration_max_s` (required), `recipe` (must match) | `config_hash` must equal the applied configuration's. **Waits for the local enable**: in ARMED (ARM pressed within `limits.arm_window_s`) it starts at once; in READY it waits (`executing`, `waiting.kind: "start"`) for an ARM press before the command's ttl, else `expired`. Start conditions: an attitude estimate, tilt ≤ `limits.tilt_start_deg`, no IMU/driver/voltage/temperature/speed/overrun/stop fault, every driver's heartbeat ≤ 300 ms and encoder estimate ≤ 25 ms old, a known bus voltage — else `failed` with the reason. BALANCING for `duration_s`, then a normal stop; final `completed` with `{ended, duration_s, wheels_stopped, balancing_steps, saturated_steps}` (or `failed`, with the same result without `wheels_stopped`, when protection stopped it); `saturated_steps` counts, per wheel, the balancing control steps in which the allocation limited the requested torque (torque limit, speed limit or a non-finite request) |
| `stop` | all | observer | — | always accepted, idempotent, only reduces: cancels a command waiting for the local control and a pending pairing; BALANCING → STOPPING (normal stop), ARMED → READY, a running self-test/measurement → aborted, COMMISSIONING → DISARMED. `{was, action}` |
| `clear_faults` | FAULT | | — | refused while a latched fault's cause is present; otherwise waits for **ARM held 2 s** (holding ARM 2 s in FAULT also clears without a command) → DISARMED |
| `set_telemetry` | all but UPDATE | | `rate_hz` integer 0–min(500, control rate), dividing the control rate (0 = off) | new telemetry session. `{rate_hz, telemetry_session}` |
| `enter_update` | DISARMED, READY, FAULT | USB only | — | cancels pending commands, → UPDATE (drivers idle, driver power off), reboots into the ROM bootloader after 300 ms |
| `reboot` | DISARMED, READY, FAULT | | — | cancels pending commands, reboots after 300 ms (the configuration must be applied again) |
| `set_network` | DISARMED | USB only | `ssid` (1–32), `password` (empty or 8–64), `gateway_url` (`wss://` only) — or `clear: true` | stores the Wi-Fi and gateway settings (NVS); takes effect after a reboot. `{stored, cleared, ssid?, reboot_required}` |
| `unpair` | DISARMED | USB only | — | waits for an ARM press, then erases the key (`{forgotten: true}`) |
| `commission` | DISARMED, COMMISSIONING | USB only, commissioning | `enter` true/false | entering needs an applied configuration, the dead-man control held and the stop released |
| `motor_test` | COMMISSIONING | USB only, commissioning | `wheel` 0–2, `torque_Nm` within the build's commissioning cap and the wheel's configured limit, `duration_ms` 10 … build cap | torque on one wheel while the dead-man control is held; ends at the duration, the build's speed cap, release of the dead-man control or `stop`. `{node, applied_s, omega_max_rads, ended}` |

**Local control.** `start_experiment`, `clear_faults`, `unpair` and pairing wait for the ARM control on the cube;
only one such wait exists at a time. The wait is visible in the state (`waiting`) and ends with the press, the
command's ttl, a `stop`, or the loss of the session it came from.

**Backend side** (`service.py`). The backend sends only `identify, diagnostics, self_test, calibrate_imu,
calibrate_axes, check_encoders, apply_config, start_experiment, stop, clear_faults, set_telemetry, reboot`
(`REMOTE_ACTIONS`); `set_network, unpair, enter_update, commission, motor_test` are offered only by the Connect page
over the USB link. Every action except `diagnostics` and `stop` needs the owner's **control lease** (30 s, renewed by
the holder; `POST …/lease` with `takeover` moves it to another holder and increments the epoch). The lease epoch is
the session's `lease_epoch`: a command from a holder whose lease was taken over carries a stale epoch and is refused
by the device even if the backend's own check were bypassed. `apply_config` is sent with the stored configuration's
exact bytes; `start_experiment` needs the device to report that configuration as applied, the recipe's prerequisites
(the corner recipe follows a completed edge trial of the same device and profile revision — waived for a device that
declares itself synthetic) and, for a device that does not declare itself synthetic, a calibration with three
confirmed wheel directions.

## §6 Device state

The device sends `state` on every change and at least once a second on every active link:

```json
{"kind":"state","state":"SELF_TEST","reason":"self-test running (drivers powered, no torque)","faults":[],"latched":[],
 "config_hash":"8cfbcbed…","mode":"edge","actuation_permitted":true,"experiment":null,"waiting":null,"task":"self_test",
 "link_lost":false,"local_session":true,"uptime_s":3.098,"boot_id":"6666267c149a9b4b",
 "tlm":{"session":"6666267c149a9b4b-2","seq":140,"hz":50},"tilt_deg":1.2504,"vbus_V":11.25}
```

| Field | Meaning |
|---|---|
| `state`, `reason` | BOOT, DISARMED, SELF_TEST, READY, ARMED, BALANCING, STOPPING, FAULT, CALIBRATING, UPDATE, COMMISSIONING; why the device is there |
| `faults`, `latched` | present faults and latched ones (cleared only by the local long press, when their causes are gone) |
| `config_hash`, `mode` | the applied configuration (`null` after boot) |
| `actuation_permitted` | actuation build **and** an applied configuration |
| `experiment` | `{cmd, recipe, elapsed_s, remaining_s, ending}` while BALANCING / STOPPING |
| `waiting` | `{kind: pair, start, clear_faults or unpair, local_action, cmd, remaining_ms}` |
| `task` | `self_test`, `calibrate_imu`, `calibrate_axes`, `check_encoders` or `null` |
| `link_lost`, `local_session` | the experiment's supervisor session was lost; a USB session supervises |
| `uptime_s`, `boot_id`, `tlm` | uptime, boot identity, telemetry session, last frame number and rate |
| `tilt_deg`, `vbus_V` | tilt from the configuration's balance attitude (with an estimate and a configuration), bus voltage (when a driver reports it) |

**States.** BOOT → DISARMED after start-up (motors disabled; a configuration is never assumed). `self_test` →
SELF_TEST → READY (or back to DISARMED). In READY an ARM press (actuation build, configuration applied, no other local
wait) → ARMED for `limits.arm_window_s`, then back to READY. An experiment: ARMED → BALANCING → STOPPING → DISARMED
(a new self-test is needed for the next one). Measurements: CALIBRATING → DISARMED. FAULT is latched. UPDATE before a
reboot into the bootloader. COMMISSIONING only in commissioning builds while the dead-man control is held. Driver
power (DRIVE_EN) is asserted only in SELF_TEST, READY, ARMED, BALANCING, STOPPING, COMMISSIONING and during
`check_encoders`, never with the stop asserted; a release build never asserts it.

**Faults.** `IMU_ABSENT, IMU_STALE, IMU_INVALID, IMU_SATURATED, DRV_ABSENT, DRV_STALE, DRV_ERROR, ENC_STALE,
OVERCURRENT, OVERSPEED, OVERTEMP, UNDERVOLT, OVERVOLT, TILT_LIMIT, EST_INVALID, LOOP_OVERRUN, ESTOP`
(`CONFIG, CALIBRATION, GRAVITY, NOT_STILL` are reserved names that firmware 0.1.0 does not raise). While the motors
are driven, any of them except `IMU_SATURATED` (the estimator gates the accelerometer instead; the tilt and rate
limits act) stops the motors: drivers idle, driver power off, FAULT latched, the experiment's command `failed`, every
pending command cancelled. In a commissioning motor test the attitude-related faults do not apply. The local stop
asserted while the drivers may be powered latches `ESTOP`; in DISARMED it only blocks the self-test and arming. READY
or ARMED falls back to DISARMED when a readiness check fails.

**Communication loss.** A running experiment whose supervisor session is lost (`link_lost`) continues at most
`limits.link_loss_max_s` (0 … 30 s, in the configuration) and then ends with a **normal stop**: the balance
controller is switched off, every wheel is braked with at most `limits.stop_torque_Nm` (the body receives at most that
reaction torque and tips onto its fixture or catch under gravity), and when every wheel is below 5 rad/s — or after
20 s — the drivers go idle and the device is DISARMED. A normal stop is also how the duration ends and how `stop`
ends an experiment. Supervision resumes only if the same `link_session` is re-established in time.

## §7 Telemetry

The device sends the reference telemetry contract `aeris-telemetry-ndjson/1` ([TELEMETRY.md](TELEMETRY.md) §2) on
every active link, so a host can forward it unchanged to the backend's telemetry hub.

```json
{"type":"hello","protocol":"aeris-telemetry-ndjson/1","device":{"id":"synthetic-doc-0001","kind":"emulator","firmware":"aeris-fw 0.1.0 (dev)"},
 "synthetic":true,"mode":"edge","nominal_rate_hz":50,"conventions":{…},"session":"6666267c149a9b4b-2","boot_id":"6666267c149a9b4b",
 "config_hash":"8cfbcbed…","attitude":"estimated on the device (cf3d complementary filter); not ground truth"}
{"type":"frame","t":0.019,"seq":1,"mode":"edge","q":[0.9203963,0.3909865,-0.0005743089,0.0002198914],"theta":0.01800836,
 "w":[0.00733038,-0.00610865,0],"torque_cmd":[0,0,0],"imu":{"gyro":[0.00733038,-0.00610865,0],"accel":[0.0574277,7.01097,6.87936]},"status":"idle"}
```

* **One telemetry session per device**, named `<boot_id>-<n>`: a new one at every boot, every applied configuration and
  every `set_telemetry` (a `bye` with `"reason":"new telemetry session"` ends the previous one on each link). Frame
  numbers `seq` start at 1 and are contiguous within a session; `t` is seconds since the session start.
* **Nothing is fabricated.** No telemetry session exists before an approved configuration (until then the body axes
  are unknown: `imu.to_body` comes with the configuration). No frame is produced without a valid attitude estimate.
  `theta` only in edge mode; `wheel_rpm` only while every driver reports encoder estimates fresher than 100 ms;
  `torque_meas` only while every driver reports torque estimates fresher than 500 ms. `status` is `ok` (BALANCING,
  STOPPING, a commissioning motor test), `calibrating` (SELF_TEST, CALIBRATING), `fault`, `estop` (latched stop) or
  `idle`. The attitude is the device's **estimate**, labelled as such in the hello.
* **Backfill.** The device keeps its last **512 frames** (`AERIS_TLM_RING`). A host that missed frames asks for them:
  `{"kind":"tlm_resume","session":…,"after":<seq>}`. The device resends the frames after `after` that its ring still
  holds (8 per service pass, in order, interleaved with live frames), reports what it no longer holds as
  `{"kind":"tlm_gap","session":…,"from":…,"to":…,"reason":"no longer kept on the device (ring overwritten)"}` and ends
  with `{"kind":"tlm_resumed","session":…,"through":<seq>}`. A `tlm_resume` for a session that is not the current one is
  answered `{"kind":"tlm_gap","session":…,"reason":"session-ended","current":…}`. `tlm_ack` (`{"seq":…}`) is accepted
  and recorded; firmware 0.1.0 does not act on it.
* **Backend use** (`service.py`). The backend feeds one copy of the stream — from the preferred route: USB-side first
  (companion, browser relay), then the gateway — into the device's telemetry hub. When the carrying route changes or
  reconnects, it opens a hub session with that route's telemetry hello (kept also when it arrived before the device
  authenticated), sends `tlm_resume` after the last frame the hub accepted, holds the live frames (at most 3 s and 4096
  frames) until the resent ones have been fed, and records what the device no longer holds, or what never arrived, as
  a gap (`TelemetryHub.source_gap`: counters `gaps` / `dropped_by_source` and a `gap` event, also in a running
  recording). Each frame reaches the hub once and in order; the device view reports `telemetry_route` and the last
  catch-ups. The Connect page's own recorder (direct Web Serial) does not request backfill: a missed frame shows as a
  missing `seq` in its recording.

## §8 Configuration and plant documents

**`aeris-device-config/1`** — the approved configuration, built by the backend from a profile revision, a recipe and
(optionally) a calibration (`devices/configgen.py`; the LQR gains are designed by the backend on the same model the
twin simulates) and validated again, field by field, by the device (`firmware/core/src/config.c`). The first error is
reported with its path (e.g. `config.limits.tilt_start_deg: must be below tilt_abort_deg`); an unsupported controller,
estimator or driver is refused by name, never replaced. Unknown fields are ignored. Its `config_hash` is the SHA-256 of
the exact text sent in `params.config`. The applied configuration lives in RAM: **after every boot or firmware
update it must be applied again.**

| Path | Rule |
|---|---|
| `schema` | `aeris-device-config/1` |
| `profile` | `{id, revision, hash}`; `hash` 64 hex characters |
| `recipe` | the approved recipe id (non-empty) |
| `mode` | `edge` or `corner` |
| `controller` | edge: `{type:"edge-lqr", K:[3] (|K| ≤ 1e4), beta_ref_rad (−0.5…0.5), drive_wheel (0…2, spinning about body x)}`; corner: `{type:"corner-mimo-lqr", K: 3 rows × 9 (wheels × [φ; ω; Ω]), q_eq (unit quaternion), u_ref (unit vector)}` |
| `estimator` | `{type:"cf3d", tau_s (0.01…10), accel_gate_mps2 (0.01…5), bias_gain (0…1), tau_alpha_s (0.001…1), stale_after_s (0.0005…1), g_mps2 (9.7…9.9), imu_position_m [3] (≤ 0.5 m from the pivot), q_nominal (unit quaternion), compensate_dynamic (bool, default true)}` |
| `imu` | `{driver:"lsm6dsox", i2c_address (0x6A or 0x6B), odr_hz (an LSM6DSOX rate 12…6667), accel_range_g (2, 4, 8, 16), gyro_range_dps (125, 250, 500, 1000, 2000), to_body (3×3 signed permutation, determinant +1: axis-aligned mounting), gyro_bias_radps [3] (|·| ≤ 0.2)}` |
| `wheels` | exactly three: `{axis (unit vector), sign (±1), driver:"odrive-cansimple", node (1…62, distinct), Jw_kgm2 (1e-6…0.05), kt_NmA (1e-4…1), current_max_A (≤ hard cap), torque_max_Nm (≤ hard cap and ≤ k_t·I_max), speed_max_rpm (10 … hard cap)}`; the three axes must not be (nearly) coplanar |
| `limits` | `tilt_start_deg` (0.1…15, below `tilt_abort_deg`), `tilt_abort_deg` (0.5…30), `wheel_speed_abort_rpm` (≥ every wheel's speed limit, ≤ 1.1 × hard cap), `current_abort_A` (≥ every wheel's current limit, ≤ 1.1 × hard cap), `temperature_abort_C` (20…120), `vbus_min_V` < `vbus_max_V` (1…60), `link_loss_max_s` (0…30), `duration_max_s` (1…300), `stop_torque_Nm` (≤ every wheel's torque limit), `arm_window_s` (5…120) |
| `rates` | `control_hz` (100 … `max_control_hz`), `imu_hz` (= `imu.odr_hz`), `telemetry_hz` (1…500, dividing `control_hz`) |
| `allocation` | `clip` (the only allocation implemented) |

**`aeris-plant-model/1`** — the plant of the synthetic device for a profile (`configgen.plant_model`; parsed by
`firmware/sim/src/sim.c` `simdev_plant_params_json`): `mode`, `g`, `edge {Thh, mgl, beta}` or
`corner {Th0, Thhi, M, rc}`, three `wheels[{axis, Jw, kt, R, Vs, Imax, wmax_rads, cv, cc, mount_sign (±1), node,
present?}]`, optional `imu {present, address, who_am_i, position_m, to_sensor, gyro_bias_radps, accel_bias_mps2,
gyro_noise_radps, accel_noise_mps2}` and `power {vbus_V, batt_R}`. It describes the **model** the synthetic device
simulates (the research engine's rigid-body plant plus synthetic sensor imperfections), never a measured cube. The
site ships the edge and corner plants of the reference profile (`site/firmware/synthetic/plant_*.json`).

## §9 Transports

| Transport | Who | How |
|---|---|---|
| USB serial | the Connect page (Web Serial, Chromium-based browsers over HTTPS or localhost); the companion (`python -m aeris_backend.companion --serial PORT`, pyserial, 115200 baud) | the link bytes as they are; the device treats it as its `usb` slot (a local session that supervises) |
| Backend relay | `wss://…/api/v6/relay?route=companion` (the companion) or `route=browser-relay` (the page relaying its Web Serial port) | binary WebSocket frames carry link bytes in both directions, unchanged; text frames are control messages: `{"op":"pair","name":…}` starts a pairing over this relay, `{"op":"status"}`; the backend answers `{"type":"relay"|"device"|"pairing"|"status"|"error",…}` |
| Gateway | the device's own outbound WebSocket over TLS to `/api/v6/device-link` (board: `main/net.c`, Wi-Fi station, server verified against the ESP-IDF CA bundle, reconnect after 5 s; the synthetic device: `firmware/tools/synthetic_net_bridge.py`) | binary frames carry link bytes (a frame may hold part of a line or several lines); challenge-response authentication first (§4). The device never listens for connections: no inbound port forwarding |
| In-page synthetic | the WebAssembly synthetic device (`site/firmware/synthetic/aeris-device.wasm`) | a function call per direction; labelled SYNTHETIC everywhere |

WebSocket refusals are sent as close codes after the handshake: **4400** (route must be `companion` or
`browser-relay`), **4401** (authentication required, or the device did not authenticate within 10 s or with a
registered key), **4403** (origin not allowed; a device socket that presents an `Origin`), **4404** (device not
found for this owner), **4429** (too many unauthenticated gateway connections — 32 — or too many live views of one
device — 8), **4503** (the device API is disabled). A binary message above 64 KiB closes the socket.

## §10 Conformance and what is not exercised

| Area | Tests |
|---|---|
| Framing, sessions, expiry and re-open, pairing proof and authentication, every command check and action, states, faults, protection, communication loss, telemetry sessions, ring, `tlm_resume`/`tlm_gap`, configuration validation, estimator and controller parity with the backend, closed-loop runs on the simulated plant | `firmware/tests/test_core.c` (`make -C firmware test`) |
| The ESP32-S3 image speaking the protocol: the boot-time P-256 signature check, `dev_hello` identity and build id, a session, `diagnostics`, a configuration accepted with the backend's SHA-256, a self-test that fails naming the absent IMU and drivers (QEMU models neither), an experiment refused by the release-style build, key creation at `pair_begin` (PSA + NVS), framing errors | `firmware/tests/qemu_link_test.py` (Espressif QEMU, the `qemutest` image with the link on UART0) |
| Browser host: framing, negotiation, profile fit, commands as raw bytes, session re-open, the WebAssembly device | `site/tests/connect.test.js`, `site/tests/browser_v6.py` (a scripted Web Serial port, labelled as such) |
| Backend host: framing, re-open, negotiation, leases, command gates, pairing proofs, ownership, telemetry continuity across routes | `backend/tests/test_devices_unit.py`, `test_devices_api.py`, `test_devices_telemetry.py` |
| End to end with the native synthetic device: companion and gateway routes, pairing with the ARM press, commands, calibration, configuration, an experiment that starts only after the local enable, recording, failover and reconnection without lost frames, revocation | `backend/tests/test_devices_e2e.py` |

**Not exercised** (needs hardware): a physical ESP32-S3 board, its USB-Serial-JTAG port and real USB cables;
Wi-Fi and TLS to a public gateway; real IMU and CAN traffic, the ODrive firmware's actual behaviour and timing;
the control loop's timing on the real chip; the local controls (ARM, stop chain, dead-man) as wired. See
[`hardware/COMMISSIONING.md`](../../hardware/COMMISSIONING.md).

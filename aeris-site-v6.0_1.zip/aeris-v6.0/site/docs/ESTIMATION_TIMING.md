# Estimator timing lifecycle (3-D filters: cf3d, mekf)

Code: `backend/aeris_backend/estimation/__init__.py` (`Estimate`, `Attitude3DBase.accept/predict/align`,
`Mekf`), `sensors.py` (`Imu3D.deliver`, `EdgeImuLegacy.sample`), `simulation/engine.py` (wiring, `est_age`,
`est_valid`), `metrics/research.py` (`_age_stats`), `metrics/legacy.py` (timeline events). Tests:
`backend/tests/test_estimator_timing.py` (28 tests). Review evidence: finding C in
[evidence/README.md](../../evidence/README.md) — v4 held the attitude estimate frozen between IMU samples (216
control intervals with a non-zero rate in the review's probe); v5: 0.

## 1. Times

| Symbol | Meaning |
|---|---|
| `t_m` measurement time | when the IMU sampled the state (the sample's time stamp) |
| `t_r` receipt time | the control tick at which the sample was delivered (`t_r ≥ t_m + latency`) |
| `t_f` filter time | measurement time of the newest processed sample; the filter's update state (q̂_f, b̂, P) refers to it |
| `t` estimate time | the control time the controller-facing estimate refers to |
| age | `t − t_f` |

## 2. Processing

Accepted samples are processed in time-stamp order: propagate the update state from `t_f` to `t_m` with the
previous (held) gyro sample, apply the accelerometer update, then keep the new gyro sample. The controller-facing
estimate is a **prediction that does not change the update state**:

```
q̂(t) = q̂_f ⊗ exp((ω_m − b̂)(t − t_f)),     ω̂(t) = ω_m − b̂        (ω_m: newest gyro sample)
```

so the next update propagates from `t_f` again and no interval is integrated twice. The MEKF covariance of the
prediction, `Φ(t − t_f) P Φᵀ + Q_d(t − t_f)`, is computed on demand (`predicted_covariance`) and never written
back. The MEKF reset after an update uses the reset Jacobian (the covariance is rotated consistently with the
attitude reset). The filters remove the dynamic acceleration α̂×r + ω̂×(ω̂×r) of the IMU lever arm
(`estimator.<cf3d|mekf>.compensate_dynamic`, default on), and so does the initial alignment. When the sensor
model measures gravity only (`sensor.accel_dynamic = false`) but the filter compensates, the validation warns that
the filter is mismatched (the request is kept as given).

## 3. Sequencing, initialisation, staleness

* **Duplicates and out-of-order samples**: a sample whose time stamp equals the filter time is a duplicate; one
  older than the filter time arrives out of order. Both are rejected (the filter does not re-run history) and
  counted in `executed.estimator.stats`.
* **Initialisation**: the first accepted sample aligns the filter (tilt from its accelerometer, heading from the
  nominal attitude). Before that the estimate is the nominal attitude with zero rate and `valid = false`; the
  timeline gets an `estimator_init` event at the receipt time of that sample.
* **Staleness**: the estimate is flagged stale (`valid = false`) while its age exceeds
  `estimator.stale_after_s` (default: sensor latency + 4 IMU periods; configurable in the research options,
  range checked). Stale periods are `estimate_stale` timeline events.
* Controllers always receive the prediction; validity and age travel with it, per step in the record
  (`est_age`, `est_valid` columns) and in the research metrics (`estimator.age_mean_s`, `age_max_s`, `stale_s`,
  `uninitialised_s`, `invalid_s`). **The control law is never changed silently** because an estimate is stale.

## 4. Edge-mode estimators

The browser engine's edge estimators (cf, kf, accel, gyro) keep their exact algorithm and tuning (parity with
`site/js/core.js`); v5 adds the measurement time stamp and a `repeated` flag to each edge IMU sample so that the
same age statistics are reported for them.

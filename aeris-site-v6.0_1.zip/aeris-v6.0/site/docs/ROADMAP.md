# AERIS · Roadmap

Status of every part of the platform after version 4 (research backend). Categories:

- **DONE**: works today, tested.
- **READY, WAITING FOR INPUT**: implemented and tested; it waits for something outside the software.
- **HARDWARE REQUIRED**: needs the physical cube (measurements, recordings, telemetry, firmware).
- **RESEARCH DATA REQUIRED**: needs the full study's data before anything can be claimed.
- **FUTURE EXTENSION**: beyond the current scope.

## DONE

### Frontend (v3, kept)

- AERIS / AERIS Cube / AERIS Twin / AERIS Lab branding; STABLIX only as the umbrella; `AERIS-EXP-######` IDs (legacy ARC ids migrated).
- Pages: Home (story 01–04, evolution), Cube, Twin, Lab, Research, Results, Validation; old links redirect.
- Colour tokens with fixed meaning; controller markers; claim labels and the system status strip.
- Service and adapter layer; job state machine; schemas with migration of v2 records.
- AERIS Twin 0.3.0 (browser engine, DEMO mode): sensor model (edge), motor lag, wheel health, COM shift, metrics, event timeline.
- Lab: timeline synchronised with the 3-D view, plots, telemetry and scrubber; saturation gauges; mass-asymmetry panel; sensor/actuator tiers; controller cards; controller sets with computed labels; exports.
- Research sweeps in the browser (≤ 400 runs, ≤ 10 s) with analysis computed from the rows.
- Simulation ↔ hardware comparison tool for user-supplied recordings.

### Research backend (v4)

- Python backend (`backend/`): the browser engine's physics and conventions reproduced (25 parity fixtures), with an integration rate independent of the loop rate, explicit plants (base tensor, components), up to six wheels on arbitrary axes, per-wheel electrical limits, degradation, torque/speed limits with durations, impulses, torque bias, lift-off detection, termination reasons.
- Sensors and estimation: three-axis IMU at its own rate (dynamic acceleration, latency, dropout, quantisation), quaternion MEKF, 3-D complementary filter, browser edge estimators; the perfect-state baseline is labelled.
- Controllers: PID (anti-windup options, reset on events), decoupled LQR with saved A, B, Q, R, K, P and operating point, coupled MIMO LQR on the full tensor, COM-adaptive LQR, nonlinear model-compensated quaternion PD; bounded least-squares allocation with authority metrics; no silent substitution.
- Research metrics and recovery criteria (separate from the legacy outcome), computed at every integration step.
- Sweeps at scale (revision 1.1): path variables, uniform / untruncated normal / bounded-normal / categorical, paired seeds with McNemar tests, estimators × controllers, per-row configuration retrieval.
- SQLite persistence, process-pool jobs, cancellation before / during / during analysis / after completion, restart policy, reproduction, datasets (exploratory → final), parameter sets, validation protocols, recording ingest, comparison.
- REST + WebSocket API with CORS/origin checks; configured ≠ reachable in the site; SIMULATION mode uses only reported capabilities.
- Frontend integration fixes A–G (validation layers, preserved research fields, backend metadata, remote cancellation, connection behaviour, recovery criteria, strict hardware validation).
- Tests: backend pytest suites, JS suites (including the real adapter against a running backend) and three browser suites; software benchmarks.

## READY, WAITING FOR INPUT

- **Measured parameter set**: `POST /api/v1/parameter-sets` with unit, method, date and evidence per value → runs labelled MEASURED (template in `backend/examples/`).
- **Validation protocol**: register thresholds before recording (draft in `backend/examples/validation_protocol.DRAFT.json`, to be confirmed by the project).
- **Recording ingest and comparison**: `aeris-hardware-run/1` files → quality report → comparison with admissible-evidence rules.
- **Parameter status NOMINAL → MEASURED → VALIDATED** on the Cube page, from `js/site-content.js`.
- **Findings** on the Results page render from `results.findings` once a final dataset exists.
- **Shared deployment** of the backend behind an authenticating reverse proxy (`backend/README.md`).

## HARDWARE REQUIRED

- Measure the cube's parameters (`HARDWARE_NEXT_STEPS.md` §4) → MEASURED.
- Record scripted experiments on the cube as `aeris-hardware-run/1` files.
- Firmware source and telemetry protocol → a `TelemetryBridge` and HARDWARE mode.
- CAD, schematics and BOM → cross-checks of inertia, electrical limits and component masses.
- Footage of edge and corner balance (unedited, dated); RWIP status and footage; documentation of hardware iterations, including failed ones.

## RESEARCH DATA REQUIRED

- Answer the research question from backend sweeps published as a final dataset: recovery maps and probabilities for PID, LQR, adaptive and nonlinear controllers against COM displacement, inertia uncertainty, disturbances and actuator saturation.
- Test hypotheses H1–H4 (Research page); they are predictions today.
- SIM ↔ HARDWARE validation against thresholds fixed in advance.
- Replace the earlier benchmark (provenance only) with results produced by the platform.

## FUTURE EXTENSION

- Further nonlinear controllers (e.g. sliding mode, energy-based).
- An absolute heading reference (magnetometer or optical) in the estimators.
- Contact models beyond the ideal pivot (slip, compliance, impacts).
- Hardware-in-the-loop runs of the same experiment scripts; air-bearing / free-attitude experiments.
- Automated experiment campaigns and a public dataset with DOIs; collaboration features.
- Optional AI assistant service (`AERIS_ASSISTANT_CONFIG`), server-side only, never with keys in the frontend.

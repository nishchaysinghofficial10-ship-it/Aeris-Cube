# Parameter provenance and versioned parameter sets

Code: `backend/aeris_backend/experiments/provenance.py` (`PS_REVISION = 2`, `check_value`, `model_inputs`,
`coverage`, `apply_parameter_set`, `set_status`), `api/app.py` (`/parameter-sets`), `jobs/manager.py` (per-run and
per-row coverage). Tests: `backend/tests/test_parameters.py` (29), `test_service.py`, `test_persistence.py`.

## 1. A parameter set

`aeris-parameter-set/1`, revision 2: configuration **path** → measured value with its unit, measurement method,
date, evidence reference (lab notebook page, file, photo id) and an optional uncertainty. Legacy bare names mean
`params.<name>`. Every value is checked against the path's unit and shape before the set is stored (a wrong unit,
a non-symmetric or non-physical inertia tensor, a vector of the wrong length is a 422 with the path).

| Group | Paths |
|---|---|
| mass and geometry | `params.m`, `params.a`, `params.kJ`, `comOffset_m`, `comShift_m`, `plant.base_com_m`, `plant.base_inertia_kgm2` (full tensor: symmetric, positive definite, triangle inequality), `plant.components.<id>.mass_kg | com_m | inertia_kgm2`, `attachments.<id>.mass_kg | pos_m` |
| wheels and motors | shared `params.Jw | KV | R | Vs | Imax | wmaxRpm | cv | cc`, or per wheel `wheels.<id>.<same fields> | axis` |
| sensing | `params.rImu`, `sensor.imu_position_m`, `sensor.gyro_noise_dps`, `gyro_bias_dps`, `gyro_bias_walk_dps`, `accel_noise_mps2`, `gyro_quant_dps`, `accel_quant_deg`, `dropout` |
| timing | `params.fs`, `sensor.rate_hz`, `sensor.latency_ms`, `actuator.motor_lag_ms` |

`params.g` is a physical constant, not a property of the cube (refused). Wheel health, events, disturbances and
initial conditions describe the experiment, not the build.

**Versioning**: sets are immutable. A correction or a new measurement campaign is a new set with a new id and
`supersedes: <old id>`; the old set stays as it was (a second `POST` with an existing id is a 409). The set's own
status says whether it covers every standard input (`measured`) or not (`partially-measured`, with `missing`).

## 2. Using a set

`POST /simulations {config, parameter_set: id}` or `POST /sweeps {sweep, parameter_set: id}` writes every value at
its path in the configuration (each replacement is reported). **Coverage is computed for every run on the
configuration it actually simulated** (`reproduction.parameter_set`):

| Status of an input | Meaning |
|---|---|
| MEASURED | the set has the path and the run used exactly that value |
| OVERRIDDEN | the set has the path but the run used another value (e.g. a sweep varied it) |
| NOMINAL | the set does not cover the path |

The inputs a run uses depend on the run (`model_inputs`): e.g. per-wheel values replace the shared ones for a custom
wheel set, sensor inputs count only with a sensor model, a full base inertia replaces `params.kJ`. **A run is
labelled MEASURED only when every input it uses is measured**; otherwise it is NOMINAL and the record lists the
nominal and overridden inputs, so an incomplete or overridden set never implies that every parameter was measured.
Sweep rows record the same coverage, and a sweep that varies a measured input marks it as overridden.

## 3. What a parameter set cannot do

It cannot make a model VALIDATED. Validation needs admissible hardware evidence — a real recording, compared
under a validation protocol registered before the data were ingested, with an independent attitude reference
where the estimator is judged — reviewed by a person ([HARDWARE_HANDOFF.md](HARDWARE_HANDOFF.md)). No synthetic
recording and no comparison changes a model's status.

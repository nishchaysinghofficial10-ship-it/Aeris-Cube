# Database: schema, migrations, persistence, backup and restore

The supported deployment is one local research workstation: one backend process per SQLite database file
(`AERIS_DB`, default `./data/aeris.sqlite3`; `scripts/start.sh` uses `data/aeris.sqlite3` under the data
directory). Code: `backend/aeris_backend/storage/sqlite.py`, `tools/dbtool.py`, `experiments/datasets.py`. Tests:
`backend/tests/test_recovery.py` (migrations, locks), `test_persistence.py`, `test_service.py`.

## 1. Schema versions

| Version | Content |
|---|---|
| 1 | AERIS v4 tables: `meta`, `counters`, `jobs`, `runs`, `sweeps`, `sweep_rows`, `docs` (generic documents: datasets, parameter sets, recordings, protocols, comparisons) |
| 2 (v5) | `jobs.attempts` (dispatch counter); at most one run per single-run job and per sweep row (partial unique indexes when the existing data allow them — duplicates written by v4 are kept and listed in the migration notes, and the code enforces uniqueness for new writes); `migrations` table recording what was applied, when, with notes |
| 3 (v6.0) | additive: `devices` (paired devices: owner, public key, board, firmware, synthetic flag, profile revision, revocation), `pairings` (single-use pairing sessions), `leases` (one control lease per device, with its epoch), `commands` (the command log: status history, device reasons, results, route, lease epoch), `runs.owner`; device documents in `docs` (collections `profiles`, `profile_heads`, `recipes`, `calibrations`, `device_configs`) — [DEVICES.md](DEVICES.md), [MIGRATION_V6.md](MIGRATION_V6.md) |

A database is migrated in place when it is opened (each step in one transaction). A database written by a **newer**
schema is refused unchanged (a v5.2 backend refuses a v6.0 database). `GET /health` reports `schema_version` and
migration warnings. Take a backup before opening an important database with a newer version (§4).

## 2. Transactional persistence and stable identifiers

* One connection guarded by a lock, WAL journal, every write in a transaction; large JSON documents compressed.
* Atomic boundaries: [JOBS_AND_RECOVERY.md §2](JOBS_AND_RECOVERY.md).
* Identifiers are never reused: experiments `AERIS-EXP-1xxxxx`, sweeps `AERIS-SWP-1xxxxx`, datasets
  `AERIS-DS-1xxxxx`, recordings `AERIS-HW-xxxxxx`, protocols `AERIS-VP-xxxx`, comparisons `AERIS-CMP-xxxxxx`,
  calibrations `AERIS-CAL-xxxxxx` (v6.0), parameter sets `paramset-xxxx` or a given id (counters in the database
  continue after a restore). Device profiles are `<id>@<revision>`; approved configurations are named by their SHA-256.
* Immutable documents: run records, parameter sets, recordings, protocols and comparisons are inserted once
  (`put_new`; an existing id is a 409, never an overwrite).

## 3. Datasets: exploratory → final

`POST /datasets` creates an **exploratory** dataset of runs, sweeps and recordings; `POST /datasets/{id}/finalize`
makes it **final**: it records the content hash of the member list and a content hash of every member as stored
(`finalized.member_hashes`: run record; sweep definition + rows; recording content hash) with the software
versions. A final dataset can never be changed — the repository refuses the write (`IntegrityError`), not only the
API (409 `already_final`). `GET /datasets/{id}/export` returns one bundle (`aeris-dataset-bundle/1`) with the
dataset, every member (runs, sweeps with rows, recordings) and an integrity check against the finalisation hashes
(`members_hash_ok`, `member_content_ok`, `changed_members`). Datasets record whether they contain synthetic
telemetry ([TELEMETRY.md §6](TELEMETRY.md)).

## 4. Backup, restore, verify (`python -m aeris_backend.tools.dbtool`)

```bash
cd backend
.venv/bin/python -m aeris_backend.tools.dbtool backup  --db ../data/aeris.sqlite3 [--out ../data/backups/NAME.sqlite3]
.venv/bin/python -m aeris_backend.tools.dbtool restore --backup ../data/backups/NAME.sqlite3 --db ../data/restored.sqlite3
.venv/bin/python -m aeris_backend.tools.dbtool verify  --db ../data/aeris.sqlite3
.venv/bin/python -m aeris_backend.tools.dbtool info    --db ../data/aeris.sqlite3
```

* **backup** works while the backend is running: the source is opened read-only (no lock taken, nothing
  written) and copied with SQLite's online backup API; the copy is verified. An existing output file is never
  overwritten.
* **restore** copies a backup to a **new** file (an existing target is refused: nothing is overwritten or
  erased), migrates it if it is older, and verifies it. Start the backend on the restored file (`--db`).
* **verify**: `PRAGMA integrity_check`, schema version and migrations, table and document counts, job states, and
  every final dataset's member list and member content against its finalisation hashes. Exit code 1 when anything
  differs.

Tested (`test_persistence.py`): an online backup while the backend holds its lock → restore into a fresh
instance → identical runs, sweeps (rows and analysis), final dataset, parameter set and recording; the restored
instance reproduces a run exactly and continues the id counters; editing a member behind the backend's back is
detected by `verify`.

## 5. Traceability

Every run record carries its configuration and its hash, the software versions (backend, engine, Python, NumPy,
SciPy, platform), the seed and seed strategy, the parameter set and its per-run coverage, the executed methods
(controller with gains and structure, estimator with settings and timing statistics, rates, solver), the metric
version, the recording schedule and its lineage (reproduction, reanalysis, retry). Sweep rows carry values, seed
and configuration hash, and the exact configuration of each row is retrievable (`GET /sweeps/{id}/rows/{index}`).

## 6. Data location and platform notes

`scripts/start.sh --data DIR` (or `AERIS_DATA_DIR`) keeps the database, backups, telemetry files, logs and PID files
in one directory. The advisory lock uses `flock` (POSIX) or `msvcrt` (Windows); only Linux was tested. Keep the
database on a local disk (SQLite WAL mode is not safe on network file systems).

# AERIS · Hardware: what is blocked, what is ready, what to do next

> **v6.0 update.** The reference cube A1's build content, firmware and device workflow now exist in software:
> [`hardware/README.md`](../../hardware/README.md) (readiness: candidate), [`hardware/COMMISSIONING.md`](../../hardware/COMMISSIONING.md)
> (the physical engineering and measurements still required), [`firmware/README.md`](../../firmware/README.md) and
> [CONNECT.md](CONNECT.md). Nothing has been built or run on hardware. The sections below are the v3–v5 record.

> **v5 update.** The software telemetry path is now implemented and tested with synthetic sources
> ([TELEMETRY.md](TELEMETRY.md)); the exact list of what the hardware stage must supply, in order, is
> [HARDWARE_HANDOFF.md](HARDWARE_HANDOFF.md), which supersedes the telemetry rows below. Sections 1–2 are kept as
> the v3/v4 record of what the supplied material contained.

Everything the software can do without the physical cube is implemented. The remaining hardware work
depends on material that has not been supplied. This page lists what was checked, what is blocked,
what the software already provides, and the order of the next steps.

## 1. What the supplied material contains (checked)

`aeris-site-v3.zip` (sha256 `c3d2f8f2…d943e1`, 116 files) holds the site's code, tests, schemas,
fonts, vendor libraries and six media files (renders, a reference sheet image, an assembly video and
poster), which are **generated visuals** and are labelled as such. It contains **no** hardware
recordings, measured parameters, firmware source, CAD source, circuit schematics or manufacturing BOM.
The subsystem list on the Cube page comes from the project reference sheet and describes the design,
not measurements. The earlier controller benchmark (PID 6.21 s … Adaptive 1.85 s) has no traces and is
not validation evidence.

## 2. Blocked items (external dependencies)

| Item | Needed from the project | What the software does with it |
|---|---|---|
| Measured model parameters | mass, dimensions, COM, inertia tensor, wheel inertia, motor constants, resistance, supply voltage, current and speed limits, friction, IMU position and noise, loop rate — each with method, date and evidence | `POST /api/v1/parameter-sets` (template: `backend/examples/parameter_set.TEMPLATE.json`); runs name the set; MEASURED only when the set is complete |
| Hardware recordings | time-stamped attitude, body rates, wheel speeds, commanded and measured torque, firmware version, controller gains | `POST /api/v1/hardware/recordings` (strict `aeris-hardware-run/1` validation, quality report), `POST /api/v1/hardware/compare` |
| Firmware source and telemetry protocol | frame layout, rates, sequence numbers, status/fault codes | v5: a device mapping or adapter onto `aeris-telemetry-ndjson/1` (`backend/aeris_backend/telemetry/device.py`, [HARDWARE_HANDOFF.md](HARDWARE_HANDOFF.md)) → HARDWARE mode with a declared physical source |
| CAD source | geometry, component placement | cross-check of the inertia tensor; `plant.components` |
| Circuit schematics / driver details | current sensing, current limit behaviour, supply sag | electrical limits (`actuator.electrical_limit`, per-wheel `Imax`, `Vs`) |
| Manufacturing BOM | component masses | `plant.components` masses, cross-check of the total mass |

Until these arrive: the model stays NOMINAL, HARDWARE mode shows only synthetic or replayed telemetry (labelled so), the
Validation page shows *hardware dataset pending*, and no result is labelled MEASURED or VALIDATED.

## 3. What is ready

* **Parameter sets** with per-value unit, method, date, evidence and uncertainty; immutable; partial
  sets keep runs NOMINAL and say which values were measured.
* **Validation protocols**: acceptance thresholds registered before evaluation (a draft to confirm:
  `backend/examples/validation_protocol.DRAFT.json`).
* **Recording ingest**: units checked per column family (time, angle, rate, wheel, torque, accel),
  monotonic time, finite values, unit quaternions, gaps and dropouts reported, content hash stored,
  synthetic data flagged.
* **Comparison**: simulation interpolated onto the recording's time stamps, best time offset, RMSE /
  MAE / peak per signal (quaternion geodesic error for attitude), torque tracking, estimator error
  against an independent reference; acceptance only for admissible evidence (real data, protocol
  registered before ingest). The software never sets VALIDATED.
* **Frames**: strict `aeris-telemetry-frame/1` validation; a bridge interface with no implementation.

## 4. Suggested measurements (standard bench methods)

| Parameter (config key) | Method | Notes |
|---|---|---|
| mass `params.m` | scale | record resolution |
| edge length `params.a` | calipers | |
| COM (`comShift_m`) | balance on a knife edge along each axis, or plumb-line suspension | relative to the geometric centre |
| inertia tensor (`plant.base_inertia_kgm2`) | trifilar pendulum about the three body axes and at least three oblique axes | wheels locked; gives products of inertia |
| wheel inertia `Jw` | trifilar pendulum on the rotor, or spin-down under a known torque | |
| motor constant `KV` (`k_t = 60/(2π·KV)`) | open-circuit back-EMF at a known speed | |
| winding resistance `R` | four-wire measurement | temperature noted |
| supply `Vs`, current limit `Imax` | driver configuration and a stall test at low current | |
| friction `cv`, `cc` | spin-down: fit `J ω̇ = −c_v ω − c_c sign ω` | per wheel |
| IMU position `sensor.imu_position_m` | CAD or calipers | |
| IMU noise and bias walk (`sensor.*`) | static recording, Allan variance | at the firmware's sample rate |
| latency `sensor.latency_ms`, loop rate `params.fs` | firmware time stamps / a loop-back test | |

## 5. Validation sequence (in this order)

1. Fill and post the parameter set (all values measured → MEASURED; otherwise it stays NOMINAL).
2. Confirm or change the thresholds in the draft protocol and register it (`POST /validation/protocols`).
   Thresholds are fixed now, before any recording is compared.
3. Record the scripted experiments on the cube (for example: edge release from a measured tilt; corner
   release; a push of known impulse; a wheel-speed step), with the firmware version and controller gains.
4. Ingest each recording (`POST /hardware/recordings`) and fix anything the quality report flags.
5. Run the same configuration on the backend with the measured parameter set and compare
   (`POST /hardware/compare` with the protocol id).
6. A person reviews the admissible comparisons; only then are `hardware.measured`, `hardware.validated`
   and `twin.validation` updated in `site/js/site-content.js`, each with a reference to its comparison.

## 6. Live telemetry (HARDWARE mode)

1. Define the device protocol (frame fields as in `aeris-telemetry-frame/1`, rate, sequence numbers,
   fault/e-stop codes) from the firmware.
2. Implement `TelemetryBridge` (serial, UDP or BLE) so that every frame passes `parse_frame`, and
   `status()` reports only what the link observed (last frame, rate, dropped sequence numbers).
3. Stream frames over the WebSocket; make `HardwareTelemetryAdapter.available()` true only while real
   frames arrive.
4. Keep safety on the device: the site never sends actuator commands without an e-stop path in firmware.

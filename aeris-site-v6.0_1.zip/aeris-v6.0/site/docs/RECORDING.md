# Recording schedule policy

Code: backend `config/validate.py` (`valid_record_rates`, `record_rate_message`), `simulation/engine.py`
(`_schedule`), `simulation/__init__.py` (`samples.schedule`, `executed.rates.record_hz`); browser `site/js/core.js`
(the same rule for the browser engine), `site/js/platform/config.js` (early feedback for the backend),
`site/js/runs.js` (`recordingInfo` for old records). Tests: `backend/tests/test_recording.py` (29),
`backend/tests/test_physics.py::test_recording_rate_does_not_change_the_trajectory_or_metrics`,
`site/tests/v5.test.js` D1–D2, `site/tests/engine.test.js`. Review evidence: finding D.

## Rule

Recorded samples are the integration-step states themselves — nothing is interpolated. A recording rate is
therefore accepted only when it **divides the integration rate** (backend: `solver.integration_hz`, default the
500 Hz loop rate; browser engine: the loop rate `params.fs`), within the engine's limits. Otherwise the request is
refused with a `record_hz` error that names the rate it could only have been realised as and the nearest valid
rates, e.g.:

> The recording rate 60 Hz does not divide the 500 Hz integration rate. Samples are integration-step states, so it
> could only be realized as 62.5 Hz and would be mislabelled. Choose a divisor of the integration rate (nearest:
> 55.5556 Hz or 62.5 Hz) or change solver.integration_hz.

v4 accepted such rates, recorded every `round(f_int / record_hz)` steps and labelled the requested rate (60 Hz
recorded as 62.5 Hz in the review's probe).

## What a run records

* the state every `stride = f_int / record_hz` integration steps, from t = 0;
* **the final state of the executed run is always the last sample** (early termination, or a window that is not a
  multiple of the stride, makes the last interval shorter);
* `samples.rate_hz` and `executed.rates.record_hz` are the realised rate (equal to the request);
* `samples.schedule`: policy `stride`, text, requested and realised rate, stride, integration rate, whether it
  matches the request, the end-point rule, `t_end_s`, `final_interval_s`, number of rows, "no interpolation".

The recording rate never changes the trajectory or the metrics (the research metrics use every integration step:
[METRICS.md](METRICS.md)).

## Old records

A v4 record whose requested rate did not divide its integration rate is detected when it is opened
(`runs.js recordingInfo`): the panel says which rate was actually recorded and that the label was wrong. The
record itself is not changed. A reproduction of such a record uses the rate v4 actually executed (listed in
`config_changes`), so it reproduces the same samples with a correct label ([REPRODUCIBILITY.md](REPRODUCIBILITY.md)).

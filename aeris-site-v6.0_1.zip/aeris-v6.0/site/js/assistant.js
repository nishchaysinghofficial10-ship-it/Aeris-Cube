/* =====================================================================
   AERIS · ASSISTANT — explanations built only from the selected run's
   saved data. No AI service is connected by default; the answers below are
   generated locally by fixed rules and say so.

   Integration point for a future AI service
   -----------------------------------------
   Set, before this file loads (e.g. in js/site-content.js):
     window.AERIS_ASSISTANT_CONFIG = { endpoint: "https://your-server.example/aeris-assistant", name: "Your service" };
   The browser then POSTs { question, context } as JSON to that endpoint and
   expects { answer: "plain text" }. The endpoint must be a server you
   control that holds any API key itself: never put keys in this site's
   files. `context` is AERIS_ASSISTANT.buildContext(...), the same run data
   the local explainer uses. Numbers in a service answer that do not appear
   in that context are flagged as unverified.
   ===================================================================== */
var AERIS_ASSISTANT = (function () {
  "use strict";
  var DEG = Math.PI / 180, RPM = Math.PI / 30;
  var CFG = (typeof window !== "undefined" && window.AERIS_ASSISTANT_CONFIG) || { endpoint: null };
  var E = function (s) { return typeof U !== "undefined" ? U.esc(s) : String(s); };
  var fx = function (x, d) { return typeof U !== "undefined" ? U.fx(x, d) : (+x).toFixed(d); };
  var sig = function (x, n) { return typeof U !== "undefined" ? U.sig(x, n) : String(x); };
  var CTRL = { pid: "PID", lqr: "LQR", adp: "COM-adaptive LQR", none: "no controller" };

  var QUESTIONS = [
    { id: "whyFall", text: "Why did this run fall?" },
    { id: "comShift", text: "How did the added mass change the centre of mass?" },
    { id: "whySaturate", text: "Why did the reaction wheel saturate?" },
    { id: "explainEquation", text: "What does this equation mean?" },
    { id: "diffRuns", text: "What differs between these two runs?" }
  ];

  /* ---------------- context: exactly the data the explanations may use ---------------- */
  function sampleAt(run, i) {
    if (!run || !run.samples) return null;
    var c = run.samples.cols, o = {}; Object.keys(c).forEach(function (k) { o[k] = c[k][i]; }); return o;
  }
  function buildContext(run, idx, others) {
    if (!run) return null;
    return {
      run: { id: run.id, name: run.name, provenance: run.provenance, model: run.software && run.software.model },
      config: run.config, derived: run.derived, outcome: run.outcome, metrics: run.metrics,
      definitions: run.definitions && run.definitions.assessment, sample: sampleAt(run, idx || 0),
      compare: (others || []).map(function (r) { return { id: r.id, name: r.name, config: r.config, outcome: r.outcome, metrics: r.metrics }; })
    };
  }

  /* ---------------- helpers over a run ---------------- */
  function holdTorque(run) {  // gravity torque if held at the geometric attitude
    var d = run.derived, g = run.config.params.g;
    return run.config.mode === "edge" ? d.M * g * d.edge.l * Math.abs(Math.sin(d.edge.beta)) : d.M * g * d.corner.l * Math.sin(d.corner.beta);
  }
  function staticLimitDeg(run) {  // largest COM lean the motors can hold still
    var d = run.derived, g = run.config.params.g, l = run.config.mode === "edge" ? d.edge.l : d.corner.l, x = d.motor.taumaxRun / (d.M * g * l);
    return x >= 1 ? 90 : Math.asin(x) / DEG;
  }
  function idxAt(run, t) { var T = run.samples.cols.t, i = 0; while (i < T.length - 1 && T[i + 1] <= t + 1e-9) i++; return i; }
  function wheelCols(run) { return run.config.mode === "edge" ? ["omega_x"] : ["omega_x", "omega_y", "omega_z"]; }
  function li(s) { return "<li>" + s + "</li>"; }
  function used(list) { return '<p class="as-used"><b>Data used:</b> ' + list.map(E).join(" · ") + "</p>"; }

  /* ---------------- local explanations ---------------- */
  var H = {};
  H.whyFall = function (run) {
    var m = run.metrics, oc = run.outcome, c = run.config;
    if (oc.code !== "fallen") {
      return "<p>This run did not fall. Its outcome is <b>" + E(oc.label) + "</b>: " + E(oc.reason) + "</p>" + used(["outcome", "outcome reason"]);
    }
    var t = m.fellAt_s, S = run.samples.cols, iF = idxAt(run, t), factors = [], dataUsed = ["fall time", "fall cause", "peak wheel speed", "torque-limited time", "initial lean", "static torque limit"];
    var lim = staticLimitDeg(run);
    factors.push(run.events && run.events.fallCause === "contact" ? "At t = " + fx(t, 2) + " s part of the cube touched the floor." : "At t = " + fx(t, 2) + " s the centre-of-mass lean passed the fall threshold (" + (c.mode === "edge" ? run.definitions.assessment.fallEdgeDeg : run.definitions.assessment.fallCornerDeg) + "°).");
    if (Math.abs(m.e0_deg) > lim) factors.push("It started with the centre of mass " + fx(Math.abs(m.e0_deg), 2) + "° from vertical, beyond the " + fx(lim, 2) + "° that full motor torque (" + sig(run.derived.motor.taumaxRun, 3) + " N·m) can hold against gravity. From there no controller can win.");
    var failed = (c.events || []).filter(function (e) { return e.type === "wheel_failure" && e.t_s <= t && (c.mode === "corner" || e.wheel === "x"); });
    if (failed.length) factors.push("Wheel " + failed.map(function (e) { return e.wheel.toUpperCase() + " failed at " + fx(e.t_s, 2) + " s"; }).join(", ") + (c.mode === "corner" && !c.controller.reconfigureOnFailure ? ", and torque reallocation was switched off, so the controller kept commanding the dead wheel." : "."));
    if (m.peakOmega_frac >= 0.9 && m.peakOmega_t <= t + 0.05) factors.push("Wheel " + String(m.peakOmega_wheel).toUpperCase() + " reached " + fx(m.peakOmega_rpm, 0) + " rpm (" + fx(m.peakOmega_frac * 100, 0) + " % of its limit) at " + fx(m.peakOmega_t, 2) + " s. A wheel at its speed limit can no longer accelerate, so it cannot produce more torque in that direction.");
    if (m.torqueLimited_s > 0.02) factors.push("The motors were torque-limited for " + fx(m.torqueLimited_s, 2) + " s in total: the controller asked for more torque than the driver and the back-EMF allowed.");
    var hold = holdTorque(run);
    if (hold > run.derived.motor.taumaxRun && !c.controller.knowsAttachments && (c.attachments.length || c.comOffset_m)) factors.push("The mass distribution needs " + sig(hold, 3) + " N·m of motor torque to hold the geometric attitude, more than the " + sig(run.derived.motor.taumaxRun, 3) + " N·m available, and the controller was designed for the bare cube, so it steered toward that attitude.");
    var loads = (c.disturbances || []).filter(function (L) { return L.t_start_s <= t; });
    if (loads.length) factors.push("Load" + (loads.length > 1 ? "s " : " ") + loads.map(function (L) { return L.id + " (" + (L.type === "force" ? L.magnitude_N + " N" : L.magnitude_Nm + " N·m") + ", " + L.t_start_s + "–" + (L.t_start_s + L.duration_s) + " s)"; }).join(", ") + " acted before the fall.");
    if (c.controller.type === "none") factors.push("No controller was running, so nothing opposed gravity.");
    if (c.torqueScale < 1) factors.push("The motor torque limit was reduced to " + Math.round(c.torqueScale * 100) + " % of nominal.");
    if (c.estimator.type !== "ideal") factors.push("The controller used the " + c.estimator.type.toUpperCase() + " estimate of the " + (c.mode === "edge" ? "tilt" : "attitude") + " rather than the true value.");
    var wAtF = wheelCols(run).map(function (k) { return fx(S[k][iF] / RPM, 0); }).join(" / ");
    return "<p>The run is <b>Fallen</b>. Contributing factors found in this run's data:</p><ul>" + factors.map(li).join("") + "</ul><p>Wheel speed at the fall: " + E(wAtF) + " rpm.</p>" + used(dataUsed.concat(["configuration (controller, loads, failures)"]));
  };
  H.comShift = function (run) {
    var c = run.config, d = run.derived, a = c.params.a;
    if (!c.attachments.length && !c.comOffset_m) return "<p>This run has no added masses and no base centre-of-mass offset, so the centre of mass is at the geometric centre of the cube: (" + fx(a / 2 * 1000, 1) + ", " + fx(a / 2 * 1000, 1) + ", " + fx(a / 2 * 1000, 1) + ") mm from the pivot corner.</p>" + used(["configuration"]);
    var r0 = d.r0, rc = d.rc, dr = [rc[0] - r0[0], rc[1] - r0[1], rc[2] - r0[2]], shift = Math.hypot(dr[0], dr[1], dr[2]);
    var parts = d.parts.map(function (p) { return "<li>" + E(p.label) + ": " + fx(p.mass, 3) + " kg at (" + p.pos.map(function (v) { return fx(v * 1000, 1); }).join(", ") + ") mm" + (p.ownInertia ? "" : " · point mass") + "</li>"; }).join("");
    var html = "<p>The combined centre of mass is the mass-weighted average of every part:</p><ul>" + parts + "</ul>";
    html += "<p>Total mass " + fx(d.M, 3) + " kg. Centre of mass moved from (" + r0.map(function (v) { return fx(v * 1000, 2); }).join(", ") + ") mm to <b>(" + rc.map(function (v) { return fx(v * 1000, 2); }).join(", ") + ") mm</b>, a shift of " + fx(shift * 1000, 2) + " mm.</p>";
    if (c.mode === "edge") {
      html += "<p>For edge balancing only the part of the centre of mass across the support edge matters. It now sits " + fx(d.edge.l * 1000, 2) + " mm from the edge (bare cube " + fx(d.bare.le * 1000, 2) + " mm) and " + fx(d.edge.beta / DEG, 3) + "° off the geometric balance line, so the cube must lean " + fx(-d.edge.beta / DEG, 3) + "° to put the centre of mass over the edge.</p>";
      html += "<p>Inertia about the edge: " + sig(d.edge.Th0, 4) + " kg·m² (bare cube " + sig(d.bare.Th0e, 4) + "), each point mass adding m·(y² + z²).</p>";
    } else {
      html += "<p>The centre of mass is " + fx(d.corner.l * 1000, 2) + " mm from the pivot corner and " + fx(d.corner.beta / DEG, 3) + "° off the main diagonal, so the balanced attitude tilts the diagonal by that angle. At that attitude the lowest edge is " + fx(d.corner.edgeClear / DEG, 1) + "° above the floor.</p>";
    }
    html += "<p>Held at the geometric attitude instead, gravity would pull with " + sig(holdTorque(run), 3) + " N·m (" + fx(holdTorque(run) / d.motor.taumaxRun * 100, 0) + " % of the motors' " + sig(d.motor.taumaxRun, 3) + " N·m). The controller " + (c.controller.knowsAttachments ? "was told about the masses and aims for the true balance attitude." : "was designed for the bare cube" + (c.controller.type === "adp" ? " but estimates the offset online." : ", so it aims for the geometric attitude.")) + "</p>";
    return html + used(["attachments", "base COM offset", "mass properties saved with the run"]);
  };
  H.whySaturate = function (run) {
    var m = run.metrics, d = run.derived, c = run.config, Jw = c.params.Jw;
    var head = "<p>Peak wheel speed " + fx(m.peakOmega_rpm, 0) + " rpm on wheel " + String(m.peakOmega_wheel).toUpperCase() + " at " + fx(m.peakOmega_t, 2) + " s, " + fx(m.peakOmega_frac * 100, 0) + " % of the " + fx(d.motor.wmax / RPM, 0) + " rpm limit. Torque-limited for " + fx(m.torqueLimited_s, 2) + " s.</p>";
    if (m.peakOmega_frac < 0.9 && m.torqueLimited_s < 0.02 && !(m.drift && m.drift.kind === "wheel")) return head + "<p>No wheel saturated in this run: speed stayed below 90 % of the limit and the motors were not held at their torque limit.</p>" + used(["peak wheel speed", "torque-limited time", "speed limit"]);
    var html = head + "<p>A reaction wheel stores the angular momentum it takes out of the body: h = J<sub>w</sub>Ω, at most " + sig(d.motor.hmax, 3) + " N·m·s here. Any torque the wheel has to supply for a long time, instead of briefly, keeps adding momentum until the speed limit is reached.</p><ul>";
    if (m.drift && m.drift.kind === "wheel") html += li("The wheel speed was still rising at " + fx(m.drift.slope_rpm_s, 0) + " rpm/s at the end of the run. That is a steady net torque of J<sub>w</sub>·dΩ/dt = " + sig(Jw * m.drift.slope_rpm_s * RPM, 3) + " N·m going into the wheel.");
    var hold = holdTorque(run);
    if (hold > 1e-4 && !c.controller.knowsAttachments && c.controller.type === "pid") html += li("PID regulates the tilt but not the wheel speed. With the centre of mass off the geometric line, holding the geometric attitude takes " + sig(hold, 3) + " N·m of motor torque indefinitely, and all of it ends up as wheel momentum.");
    (c.disturbances || []).forEach(function (L) { html += li("Load " + E(L.id) + " (" + (L.type === "force" ? L.magnitude_N + " N" : L.magnitude_Nm + " N·m") + ") from " + L.t_start_s + " to " + (L.t_start_s + L.duration_s) + " s: while it acts, the wheels must absorb its torque about the pivot or the cube must lean against it."); });
    if (m.torqueLimited_s > 0.02) html += li("Near the speed limit the back-EMF leaves less voltage for current: available torque = k<sub>t</sub>(V<sub>s</sub> − k<sub>e</sub>|Ω|)/R, falling to zero at the limit. The controller's demand was clipped for " + fx(m.torqueLimited_s, 2) + " s.");
    if (c.torqueScale < 1) html += li("The torque limit was scaled to " + Math.round(c.torqueScale * 100) + " % of nominal.");
    return html + "</ul>" + used(["peak and final wheel speeds", "drift fit", "torque-limited time", "loads", "mass properties", "motor constants"]);
  };
  var EQUATIONS = {
    dyn: { name: "Balancing dynamics", edge: "Θ̂·θ̈ = τ_g + τ_F − (T − τ_fric)", corner: "Θ̂₀·ω̇ = −ω × (Θ₀ω + J_w·Ω) + M·r_c × g + τ_F − T_net" },
    grav: { name: "Gravity torque", edge: "τ_g = M·g·l·sin(e)", corner: "τ_g = M·r_c × g_B" },
    force: { name: "Applied-force torque", edge: "τ_F = (r × F)·x̂", corner: "τ_F = r × F (body frame)" },
    mom: { name: "Wheel momentum", edge: "h = J_w·Ω", corner: "h = J_w·Ω (each wheel)" },
    lim: { name: "Actuator limit", edge: "|T| ≤ min(τ_max, k_t(V_s − k_e|Ω|)/R)", corner: "|T_i| ≤ min(τ_max, k_t(V_s − k_e|Ω_i|)/R)" },
    ctrl: { name: "Controller output", edge: "T = −K·[θ − θ_ref, θ̇, Ω]", corner: "T = −K₁θ_t − K₂Pω − K₃PΩ + ĉ·T_ψ" }
  };
  H.explainEquation = function (run, idx, opts) {
    var key = (opts && opts.equation) || "dyn", Q = EQUATIONS[key], c = run.config, d = run.derived, s = sampleAt(run, idx), edge = c.mode === "edge", g = c.params.g;
    var ct = c.controller.type, mimo = c.controller.structure === "mimo-lqr" || !!(run.design && run.design.mimo), xc = (run.executed && run.executed.controller) || null;
    var formula = edge ? Q.edge : Q.corner;
    if (key === "ctrl") {   // v4: always name the method that actually ran
      if (ct === "none") formula = "T = 0 (no controller)";
      else if (ct === "nlpd" || mimo) formula = (xc && xc.law) || (ct === "nlpd" ? "nonlinear model-compensated PD" : "T = −K·[φ; ω̂; Ω] (coupled MIMO LQR)");
      else if (ct === "pid") formula = edge ? "T = K_p·e + K_i∫e dt + K_d·θ̇" : formula;
    }
    var html = "<p><b>" + E(Q.name) + ":</b> <span class=\"mono\">" + E(formula) + "</span></p>";
    var t = "at t = " + fx(s.t, 2) + " s";
    if (key === "dyn") {
      if (edge) {
        var Tnet = s.T_x - (c.params.cv * s.omega_x + c.params.cc * Math.tanh(s.omega_x)), Thh = run.design.plant.Thh, acc = (s.tauG + s.tauF - Tnet) / Thh;
        html += "<p>Newton's second law for rotation about the support edge. The left side is the effective inertia (" + sig(Thh, 4) + " kg·m²: body about the edge, minus the wheel's spin inertia, which the motor drives separately) times the angular acceleration. The right side adds up the torques: gravity pulling the centre of mass over, any applied load, and the reaction to the motor spinning the wheel.</p>";
        html += "<p>" + t + ": τ<sub>g</sub> = " + sig(s.tauG, 3) + " N·m, τ<sub>F</sub> = " + sig(s.tauF, 3) + " N·m, motor T = " + sig(s.T_x, 3) + " N·m (friction " + sig(s.T_x - Tnet, 2) + " N·m), so θ̈ = " + sig(acc, 3) + " rad/s².</p>";
      } else html += "<p>Euler's equation for the whole cube rotating about the pivot corner, written in the body frame. It includes the gyroscopic term from the spinning body and wheels, the gravity torque about the pivot, applied loads and the wheel reaction torques. " + t + ": |τ<sub>g</sub>| = " + sig(Math.hypot(s.tauG_x, s.tauG_y, s.tauG_z), 3) + " N·m, motor torques (" + [s.T_x, s.T_y, s.T_z].map(function (v) { return sig(v, 3); }).join(", ") + ") N·m.</p>";
    } else if (key === "grav") {
      if (edge) html += "<p>Gravity acts at the centre of mass. Its lever arm about the edge is l·sin(e), where e is how far the centre of mass leans from vertical. With M = " + fx(d.M, 3) + " kg, g = " + g + " m/s² and l = " + fx(d.edge.l * 1000, 2) + " mm, " + t + " e = " + fx(s.e / DEG, 3) + "° gives τ<sub>g</sub> = " + sig(s.tauG, 3) + " N·m. It is zero only when the centre of mass is directly above the edge, and grows as the cube leans: that is what makes balancing unstable.</p>";
      else html += "<p>The cross product of the pivot-to-COM vector and the weight, both in the body frame. " + t + ": τ<sub>g</sub> = (" + [s.tauG_x, s.tauG_y, s.tauG_z].map(function (v) { return sig(v, 3); }).join(", ") + ") N·m.</p>";
    } else if (key === "force") {
      var act = (c.disturbances || []).filter(function (L) { return s.t >= L.t_start_s && s.t < L.t_start_s + L.duration_s; });
      html += "<p>A force F applied at point r (measured from the pivot) twists the cube about the pivot by r × F. A push through the pivot, or along the support edge in edge mode, produces no turning effect. World-frame forces keep their direction in the room as the cube tilts; body-frame forces turn with the cube.</p>";
      html += "<p>" + t + ": " + (act.length ? act.map(function (L) { return E(L.id) + " active"; }).join(", ") + "; τ<sub>F</sub> = " + (edge ? sig(s.tauF, 3) + " N·m about the edge." : "(" + [s.tauF_x, s.tauF_y, s.tauF_z].map(function (v) { return sig(v, 3); }).join(", ") + ") N·m.") : "no load is active.") + "</p>";
    } else if (key === "mom") {
      var ws = wheelCols(run).map(function (k) { return s[k]; });
      html += "<p>Each wheel's stored angular momentum is its spin inertia (" + sig(c.params.Jw, 3) + " kg·m²) times its speed relative to the body. Speeding a wheel up one way pushes the body the other way; the momentum it has absorbed stays in the wheel until something removes it. " + t + ": h = " + ws.map(function (w) { return sig(c.params.Jw * w, 3); }).join(", ") + " N·m·s, out of at most " + sig(d.motor.hmax, 3) + " N·m·s.</p>";
    } else if (key === "lim") {
      var w0 = edge ? s.omega_x : Math.max(Math.abs(s.omega_x), Math.abs(s.omega_y), Math.abs(s.omega_z)), av = Math.max(0, d.motor.kt * (d.motor.Vs - d.motor.ke * Math.abs(w0)) / d.motor.R);
      html += "<p>The driver limits current, so torque is capped at τ<sub>max</sub> = " + sig(d.motor.taumaxRun, 3) + " N·m. When the motor pushes in the direction the wheel already spins, the back-EMF k<sub>e</sub>|Ω| eats into the supply voltage and the available torque falls to zero at the no-load speed. " + t + " the fastest wheel turns at " + fx(w0 / RPM, 0) + " rpm, leaving " + sig(Math.min(av, d.motor.taumaxRun), 3) + " N·m in that direction.</p>";
    } else if (key === "ctrl") {
      if (ct === "none") html += "<p>No controller was running in this run: the motors were off, so nothing opposed gravity.</p>";
      else if (ct === "nlpd") {
        html += "<p>Nonlinear model-compensated PD (not an LQR): the controller cancels the modelled gravity" + (edge ? "" : " and gyroscopic") + " torque and imposes a PD law on the attitude error, while a slow outer loop tilts the reference so gravity drains the wheel momentum. Its model is " + E((run.design && run.design.model_mass && run.design.model_mass.source) || "the controller's nominal model") + ".</p>";
        if (xc && xc.gains) html += "<p>Gains used: k<sub>p</sub> = " + sig(xc.gains.kp_tilt_per_s2, 4) + " s⁻², k<sub>d</sub> = " + sig(xc.gains.kd_tilt_per_s, 4) + " s⁻¹, momentum loop k₁ = " + sig(xc.gains.k1_momentum_rad_per_Nms, 3) + ", k₂ = " + sig(xc.gains.k2_momentum_rad_per_Nms2, 3) + ".</p>";
        html += "<p>" + t + ": commanded " + (edge ? sig(s.Tc_x, 3) + " N·m, delivered " + sig(s.T_x, 3) + " N·m" : "(" + [s.Tc_x, s.Tc_y, s.Tc_z].map(function (v) { return sig(v, 3); }).join(", ") + ") N·m") + ".</p>";
      } else if (mimo) {
        var mm = run.design && run.design.mimo;
        html += "<p>Coupled MIMO LQR: one " + (mm && mm.K ? mm.K.length + "×" + mm.K[0].length + " " : "") + "gain matrix acts on the attitude error, the body rates and the wheel speeds together, designed on the full-inertia linearisation" + (mm ? " (controllable rank " + mm.controllable_rank + " of " + mm.state_dim + "; the vertical angular momentum is conserved and cannot be controlled)" : "") + ".</p>";
        html += "<p>" + t + ": commanded (" + [s.Tc_x, s.Tc_y, s.Tc_z].map(function (v) { return sig(v, 3); }).join(", ") + ") N·m.</p>";
      } else if (edge && run.design && run.design.tilt) {
        var K = run.design.tilt.K, ref = run.design.betaRef || 0;
        html += c.controller.type === "pid" ? "<p>PID: T = K<sub>p</sub>·e + K<sub>i</sub>∫e + K<sub>d</sub>·θ̇ with K<sub>p</sub> = " + sig(run.design.tilt.pid.Kp, 4) + ", K<sub>i</sub> = " + sig(run.design.tilt.pid.Ki, 4) + ", K<sub>d</sub> = " + sig(run.design.tilt.pid.Kd, 4) + ". It looks only at the tilt, never at the wheel speed.</p>"
          : "<p>State feedback: the torque is a weighted sum of the tilt error, the tilt rate and the wheel speed, with K = [" + K.map(function (v) { return sig(v, 4); }).join(", ") + "]" + (ref ? ", and the tilt reference shifted to the true balance lean " + fx(-ref / DEG, 3) + "°" : "") + ". Including the wheel speed is what lets it bleed stored momentum back out.</p>";
        html += "<p>" + t + ": commanded " + sig(s.Tc_x, 3) + " N·m, delivered " + sig(s.T_x, 3) + " N·m" + (Math.abs(s.Tc_x - s.T_x) > 1e-6 ? " (clipped by the actuator limit)" : "") + ".</p>";
      } else html += "<p>The corner controller applies the tilt law along the two horizontal directions and a separate yaw law about the balance axis.</p>";
    }
    return html + used(["configuration", "mass properties", "controller design", "sample " + t]);
  };
  H.diffRuns = function (run, idx, opts) {
    var others = (opts && opts.compare) || [];
    if (others.length < 2) return "<p>Select two runs in the Compare tab first. The comparison then lists the conditions that differ, the outcomes and the key metrics.</p>";
    var A = others[0], B = others[1], diffs = configDiff(A.config, B.config);
    var html = "<p>Comparing <b>" + E(A.name) + "</b> and <b>" + E(B.name) + "</b>.</p>";
    html += diffs.length ? "<p>Conditions that differ (" + diffs.length + "):</p><ul>" + diffs.map(function (d) { return li(E(d.label) + ": " + E(d.a) + " → " + E(d.b)); }).join("") + "</ul>" : "<p>The configurations are identical. Any difference in the results comes from nothing but the saved samples, so they should match.</p>";
    html += "<p>Outcomes: " + E(A.outcome.label) + " vs " + E(B.outcome.label) + ". Peak wheel speed " + fx(A.metrics.peakOmega_rpm, 0) + " vs " + fx(B.metrics.peakOmega_rpm, 0) + " rpm; energy " + fx(A.metrics.energy_J, 2) + " vs " + fx(B.metrics.energy_J, 2) + " J; settling " + (A.metrics.settle_s == null ? "not settled" : fx(A.metrics.settle_s, 2) + " s") + " vs " + (B.metrics.settle_s == null ? "not settled" : fx(B.metrics.settle_s, 2) + " s") + ".</p>";
    if (diffs.length > 1) html += "<p>Because " + diffs.length + " conditions differ, the difference in results cannot be pinned on any single one of them. Change one condition at a time to attribute an effect.</p>";
    html += "<p>These are two simulations with nominal parameters; they show how these runs behave, not which controller is better in general.</p>";
    return html + used(["both runs' configurations", "outcomes", "metrics"]);
  };

  /* condition differences, readable */
  function flat(o, pre, out) { out = out || {}; Object.keys(o || {}).forEach(function (k) { var v = o[k], p = pre ? pre + "." + k : k; if (v && typeof v === "object" && !Array.isArray(v)) flat(v, p, out); else out[p] = Array.isArray(v) ? JSON.stringify(v) : v; }); return out; }
  var LABELS = { mode: "Balance mode", comOffset_m: "Base COM offset [m]", "controller.type": "Controller", "controller.knowsAttachments": "Controller knows attachments", "controller.reconfigureOnFailure": "Torque reallocation on failure", "estimator.type": "Estimator", seed: "Random seed", "initial.tilt_deg": "Initial tilt [°]", "initial.rate_dps": "Initial rate [°/s]", "initial.azimuth_deg": "Initial tilt direction [°]", "initial.reference": "Tilt measured from", attachments: "Attached masses", disturbances: "Loads", events: "Wheel failures", commands: "Yaw commands", "uncertainty.inertiaScale": "Plant inertia scale", torqueScale: "Torque limit scale", duration_s: "Duration [s]", record_hz: "Recording rate [Hz]" };
  function configDiff(a, b) {
    var fa = flat(a), fb = flat(b), keys = {}, out = [];
    Object.keys(fa).concat(Object.keys(fb)).forEach(function (k) { keys[k] = 1; });
    Object.keys(keys).sort().forEach(function (k) {
      if (k === "schema") return;
      if (String(fa[k]) !== String(fb[k])) {
        var lab = LABELS[k] || (k.indexOf("params.") === 0 ? "Parameter " + k.slice(7) : k);
        out.push({ key: k, label: lab, a: fa[k] === undefined ? "—" : String(fa[k]), b: fb[k] === undefined ? "—" : String(fb[k]) });
      }
    });
    return out;
  }

  function classify(q) {
    var s = String(q || "").toLowerCase();
    if (/fall|fell|topple|tip/.test(s)) return "whyFall";
    if (/mass|centre of mass|center of mass|com\b|weight|attach/.test(s)) return "comShift";
    if (/saturat|wheel speed|limit|momentum|rpm/.test(s)) return "whySaturate";
    if (/equation|formula|mean|torque|dynamics/.test(s)) return "explainEquation";
    if (/differ|compare|two runs|versus|vs\b/.test(s)) return "diffRuns";
    return null;
  }

  /* numbers in a service answer that are not in the context are flagged */
  function numbersIn(obj, out) { out = out || []; if (typeof obj === "number" && isFinite(obj)) out.push(obj); else if (obj && typeof obj === "object") Object.keys(obj).forEach(function (k) { numbersIn(obj[k], out); }); return out; }
  function flagUnverified(text, ctx) {
    var known = numbersIn(ctx);
    return E(text).replace(/−?-?\d+(?:\.\d+)?/g, function (m) {
      var v = parseFloat(m.replace("−", "-")); if (!isFinite(v) || Math.abs(v) < 10 && Math.round(v) === v) return m;
      var dec = (m.split(".")[1] || "").length, tol = Math.max(0.5 * Math.pow(10, -dec), Math.abs(v) * 1e-3);   // the quoted precision, or 0.1 %
      var ok = known.some(function (k) { var cands = [k, k / DEG, k / RPM, k * 1000, k * 100]; return cands.some(function (c) { return Math.abs(Math.abs(c) - Math.abs(v)) <= tol; }); });
      return ok ? m : '<mark class="unverified" title="Not found in this run\'s data">' + m + "</mark>";
    });
  }

  function answer(question, run, idx, opts) {
    var intent = (opts && opts.intent) || classify(question);
    var ctx = buildContext(run, idx, opts && opts.compare);
    if (CFG.endpoint) {
      return fetch(CFG.endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: question, context: ctx }) })
        .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
        .then(function (j) { return { source: "service", service: CFG.name || CFG.endpoint, html: "<p>" + flagUnverified(String(j.answer || ""), ctx).replace(/\n\n+/g, "</p><p>").replace(/\n/g, "<br>") + "</p>" }; })
        .catch(function (e) { var r = local(intent, question, run, idx, opts); r.note = "The connected service did not answer (" + e.message + "); showing the local explanation."; return r; });
    }
    return Promise.resolve(local(intent, question, run, idx, opts));
  }
  function local(intent, question, run, idx, opts) {
    if (!intent) return { source: "local", html: "<p>The local explainer answers a fixed set of questions from this run's data:</p><ul>" + QUESTIONS.map(function (q) { return li(E(q.text)); }).join("") + "</ul><p>No AI service is connected, so free-form questions are not answered.</p>" };
    if (intent !== "diffRuns" && (!run || !run.samples)) return { source: "local", intent: intent, html: "<p>Open or create a run first. The explanations use only the selected run's saved data.</p>" };
    return { source: "local", intent: intent, html: H[intent](run, idx, opts) };
  }
  return { QUESTIONS: QUESTIONS, EQUATIONS: EQUATIONS, answer: answer, local: local, buildContext: buildContext, configDiff: configDiff, classify: classify, flagUnverified: flagUnverified, get connected() { return !!CFG.endpoint; }, get serviceName() { return CFG.name || null; } };
})();
if (typeof module !== "undefined") module.exports = AERIS_ASSISTANT;

/* =====================================================================
   AERIS · RUNS  —  reproducible run records, browser persistence,
   JSON import/export with validation, CSV export of samples.

   A run record (schema "aeris-run/1", revision 1.1) is self-contained: it
   carries its experiment ID, where the data came from (origin) and how far
   the model is validated, the full configuration snapshot, the mass
   properties and controller design derived from it, the recorded samples,
   the metrics and their definitions, the event timeline and the outcome.
   Nothing in a saved run depends on the current state of the setup panel.
   Records from site v2 (revision 1.0) are upgraded on load (AERIS_SCHEMA).
   ===================================================================== */
var AERIS_RUNS = (function (AERIS_TWIN, IDS, SCHEMA, EVENTS, CFG) {
  "use strict";
  var SITE_VERSION = "AERIS site 4.0";
  var BACKEND_ENGINE = "aeris-research-backend";
  /* a record computed by the Python research backend (or any engine other than this browser's) */
  var BACKEND_REVISIONS = ["1.2", "1.3"];   // research-backend records: v4 (1.2) and v5 (1.3: lineage, recording schedule, metric version 2)
  function isBackendRecord(rec) { return !!rec && ((rec.origin && rec.origin.engine === BACKEND_ENGINE) || BACKEND_REVISIONS.indexOf(rec.schema_revision) >= 0); }
  function isBrowserRecord(rec) { return !rec.origin || rec.origin.engine === "aeris-twin-js" || rec.origin.engine === "mock-research-backend"; }
  var KEYS = { index: "aeris.v2.runs.index", run: "aeris.v2.run.", draft: "aeris.v2.draft", prefs: "aeris.v2.prefs" };
  var MAX_IMPORT_CHARS = 25e6;
  var CTRL_NAMES = { pid: "PID", lqr: "LQR", adp: "COM-adaptive LQR", nlpd: "Nonlinear PD", none: "No control" };
  var REQUIRED_COLS = {
    edge: ["t", "theta", "thetadot", "omega_x", "T_x", "e", "tauF", "tauG", "E", "sat"],
    corner: ["t", "q0", "q1", "q2", "q3", "wx", "wy", "wz", "omega_x", "omega_y", "omega_z", "T_x", "T_y", "T_z", "e", "psi", "tauF_x", "tauF_y", "tauF_z", "tauG_x", "tauG_y", "tauG_z", "E", "sat"]
  };

  /* ---------------- storage (localStorage with an in-memory fallback) ---------------- */
  function memoryStore() {
    var m = {};
    return {
      getItem: function (k) { return Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null; },
      setItem: function (k, v) { m[k] = String(v); }, removeItem: function (k) { delete m[k]; },
      key: function (i) { return Object.keys(m)[i] || null; }, get length() { return Object.keys(m).length; }
    };
  }
  var store = null, persistent = false;
  function useStorage(s, isPersistent) { store = s; persistent = !!isPersistent; migrated = false; IDS.useStore(s); }
  var migrated = false;
  (function init() {
    try {
      if (typeof window !== "undefined" && window.localStorage) {
        var k = "aeris.v2.__probe"; window.localStorage.setItem(k, "1"); window.localStorage.removeItem(k);
        useStorage(window.localStorage, true); return;
      }
    } catch (e) { /* blocked (private mode, file:// policy) */ }
    useStorage(memoryStore(), false);
  })();
  function isQuota(e) { return e && (e.name === "QuotaExceededError" || e.name === "NS_ERROR_DOM_QUOTA_REACHED" || e.code === 22 || e.code === 1014); }
  function readJSON(k) { try { var s = store.getItem(k); return s ? JSON.parse(s) : null; } catch (e) { return null; } }

  /* ---------------- ids and names ---------------- */
  function rid() {
    var r = "";
    try { var a = new Uint8Array(4); (typeof crypto !== "undefined" && crypto.getRandomValues ? crypto : null).getRandomValues(a); r = Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); }
    catch (e) { r = Math.floor(Math.random() * 0xffffffff).toString(16); }
    return "run-" + Date.now().toString(36) + "-" + r;
  }
  function fmt(x, d) { return (Math.round(x * Math.pow(10, d)) / Math.pow(10, d)).toString(); }
  function autoName(cfg) {
    var bits = [cfg.mode === "edge" ? "Edge" : "Corner", (CTRL_NAMES[cfg.controller.type] || cfg.controller.type) + (cfg.controller.structure === "mimo-lqr" ? " (MIMO)" : "")];
    if (cfg.comOffset_m) bits.push("COM " + (cfg.comOffset_m > 0 ? "+" : "") + fmt(cfg.comOffset_m * 1000, 1) + " mm");
    if (cfg.attachments.length) bits.push(cfg.attachments.length + (cfg.attachments.length === 1 ? " mass" : " masses"));
    bits.push(cfg.initial.tilt_deg == null && cfg.initial.attitude_q ? "explicit initial q" : "tilt " + fmt(cfg.initial.tilt_deg, 1) + "°");
    if (cfg.disturbances.length) bits.push(cfg.disturbances.length + (cfg.disturbances.length === 1 ? " load" : " loads"));
    if (cfg.events.length) bits.push("wheel " + cfg.events.map(function (e) { return String(e.wheel).toUpperCase(); }).join("/") + " fails");
    if (cfg.torqueScale !== 1) bits.push(Math.round(cfg.torqueScale * 100) + " % torque");
    if (cfg.estimator.type !== "ideal") bits.push(cfg.estimator.type.toUpperCase());
    if (cfg.uncertainty && cfg.uncertainty.inertiaScale !== 1) bits.push("inertia ×" + fmt(cfg.uncertainty.inertiaScale, 2));
    bits.push(fmt(cfg.duration_s, 1) + " s");
    return bits.join(" · ");
  }

  /* ---------------- building a record ---------------- */
  function summarizeMP(mp, cfg) {
    if (!mp) return null;
    var d = AERIS_TWIN.derive(cfg.params);
    return {
      M: mp.M, rc: mp.rc, r0: mp.r0, m0: mp.m0, Jc0: mp.Jc0, ThO: mp.ThO, ThC: mp.ThC, baseCenter: mp.baseCenter,
      parts: mp.parts.map(function (p) { return { id: p.id, label: p.label, mass: p.mass, pos: p.pos, ownInertia: p.ownInertia }; }),
      edge: { l: mp.edge.l, beta: mp.edge.beta, Th0: mp.edge.Th0, Thh: mp.edge.Thh, xc: mp.edge.xc },
      corner: { l: mp.corner.l, u: mp.corner.u, beta: mp.corner.beta, eig: mp.corner.eig, ThPar: mp.corner.ThPar, ThPerp: mp.corner.ThPerp, edgeClear: mp.corner.edgeClear },
      motor: { kt: d.kt, ke: d.ke, taumax: d.taumax, taumaxRun: d.taumax * cfg.torqueScale, wnl: d.wnl, wmax: d.wmax, hmax: d.hmax, R: cfg.params.R, Vs: cfg.params.Vs },
      bare: { Jc: d.Jc, le: d.le, lc: d.lc, Th0e: d.Th0e, Thhe: d.Thhe, mgle: d.mgle, Th0c: d.Th0c, mglc: d.mglc, lame: d.lame, lamc: d.lamc },
      initial: AERIS_TWIN.initialState(cfg, mp)
    };
  }
  function summarizeDesign(dz) {
    if (!dz) return null;
    var t = dz.tilt, out = {
      mode: dz.mode, model: dz.model, betaRef: dz.betaRef != null ? dz.betaRef : null, uRef: dz.uRef || null,
      tilt: { A: t.M.A, B: t.M.B, Thh: t.M.Thh, Th0: t.M.Th0, mgl: t.M.mgl, K: t.K, P: t.P, cl: t.cl, ol: t.ol, pid: t.pid, pidPoles: t.pidPoles, gam: t.gam, adpPoles: t.adpPoles, Q: t.Q, R: t.R },
      actuator: dz.actuator,
      plant: dz.mode === "edge" ? dz.plant : { Th0: dz.plant.Th0, Thh: dz.plant.Thh, M: dz.plant.M, rc: dz.plant.rc, lambda: dz.plant.lambda }
    };
    if (dz.yaw) out.yaw = { K: dz.yaw.K, pid: dz.yaw.pid, cl: dz.yaw.cl };
    return out;
  }
  /* the model's validation state is a site-wide fact (js/site-content.js → twin.validation) */
  function modelValidation() {
    var st = typeof AERIS_CONTENT !== "undefined" && AERIS_CONTENT.twin && SCHEMA.VALIDATION[AERIS_CONTENT.twin.validation] ? AERIS_CONTENT.twin.validation : "nominal";
    var set = typeof AERIS_CONTENT !== "undefined" && AERIS_CONTENT.twin && AERIS_CONTENT.twin.parameterSet ? AERIS_CONTENT.twin.parameterSet : SCHEMA.NOMINAL_PARAMETER_SET;
    return { status: st, parameter_set: set, note: SCHEMA.VALIDATION[st].text };
  }
  function provenanceText(v) { return v.status === "nominal" ? "Simulation with nominal (unvalidated) parameters. Not a hardware measurement." : v.status === "measured" ? "Simulation with parameters measured on the physical cube (" + v.parameter_set + "); the model itself is not yet validated against hardware runs. Not a hardware measurement." : "Simulation with a model validated against hardware runs (" + v.parameter_set + "). Not a hardware measurement."; }
  function takenIds() { return list().map(function (e) { return e.experiment_id; }).filter(Boolean); }
  function fromSimulation(res, meta) {
    meta = meta || {};
    if (!res || !res.config) throw new Error("no simulation result");
    var id = meta.id || rid(), val = meta.validation || modelValidation();
    var coll = meta.collection || (meta.source === "example" ? "example" : "user");
    return {
      schema: AERIS_TWIN.VERSION.run, schema_revision: SCHEMA.VERSIONS.runRevision,
      id: id, experiment_id: meta.experiment_id || IDS.forExample(id) || IDS.next(takenIds()),
      name: meta.name || autoName(res.config), created: meta.created || new Date().toISOString(),
      source: "simulation", collection: coll, note: meta.note || "",
      origin: meta.origin || { kind: "simulation", engine: "aeris-twin-js", engine_version: AERIS_TWIN.VERSION.model, adapter: "local-simulator", mode: meta.mode || "demo" },
      validation: val, group: meta.group || null,
      software: { site: SITE_VERSION, model: AERIS_TWIN.VERSION.model, solver: AERIS_TWIN.VERSION.solver, modelNotes: AERIS_TWIN.VERSION.modelNotes, configSchema: AERIS_TWIN.VERSION.config },
      provenance: provenanceText(val),
      config: AERIS_TWIN.clone(res.config),
      derived: res.ok ? summarizeMP(res.mp, res.config) : null,
      design: res.ok ? summarizeDesign(res.design) : null,
      warnings: AERIS_TWIN.clone(res.warnings || []), errors: AERIS_TWIN.clone(res.errors || []),
      samples: res.samples ? AERIS_TWIN.clone(res.samples) : null,
      metrics: res.metrics ? AERIS_TWIN.clone(res.metrics) : null,
      definitions: { metrics: AERIS_TWIN.METRIC_DEFS, assessment: AERIS_TWIN.ASSESS, outcomes: AERIS_TWIN.OUTCOMES, events: AERIS_TWIN.EVENT_DEFS },
      outcome: AERIS_TWIN.clone(res.outcome),
      timeline: res.timeline ? AERIS_TWIN.clone(res.timeline) : null,
      events: { fellAt: res.fellAt != null ? res.fellAt : null, contactAt: res.contactAt != null ? res.contactAt : null, fallCause: res.fallCause || null, failedWheels: res.failedWheels || [] }
    };
  }

  /* ---------------- validation of a record (used on import and on load) ---------------- */
  var NUM_METRICS = ["window_s", "recorded_s", "e0_deg", "peakLean_deg", "finalLean_deg", "peakOmega_rpm", "peakOmega_frac", "torqueLimited_s", "energy_J", "endOmega_rpm", "endOmega_frac"];
  var NULLABLE_METRICS = ["settle_s", "tOmega_s", "overshoot_deg", "fellAt_s", "yawFinal_deg", "yawRate_dps", "yawErrFinal_deg"];
  function hasPaths(o, paths) { return paths.every(function (p) { var v = p.split(".").reduce(function (a, k) { return a == null ? a : a[k]; }, o); return v !== undefined && v !== null; }); }
  var DERIVED_PATHS = ["M", "rc", "r0", "m0", "Jc0", "ThO", "parts", "edge.l", "edge.beta", "edge.Th0", "corner.l", "corner.u", "corner.eig", "motor.wmax", "motor.taumaxRun", "motor.kt", "motor.hmax", "bare.le", "initial"];
  var DESIGN_PATHS = ["tilt.K", "tilt.pid.Kp", "tilt.cl", "actuator.taumax", "actuator.wmax", "plant.lambda"];
  /* what a backend record must carry: the backend's own mass properties, design and definitions (never rebuilt here) */
  var BACKEND_DERIVED_PATHS = ["M", "rc", "ThO", "parts", "edge.l", "edge.beta", "corner.l", "corner.u", "motor.wmax", "motor.taumaxRun", "motor.kt", "wheels", "initial"];
  var BACKEND_DESIGN_PATHS = ["mode", "structure", "controller", "actuator.taumax", "actuator.wmax", "plant.lambda", "model_mass"];
  function backendColumns(rec, mode) {
    var ws = rec.derived && Array.isArray(rec.derived.wheels) ? rec.derived.wheels.map(function (w) { return w.id; }) : ["x", "y", "z"];
    var std = ws.length === 3 && ws[0] === "x" && ws[1] === "y" && ws[2] === "z";
    if (mode === "edge") return REQUIRED_COLS.edge;
    var names = std ? ["x", "y", "z"] : ws, out = ["t", "q0", "q1", "q2", "q3", "wx", "wy", "wz", "e", "psi", "tauF_x", "tauF_y", "tauF_z", "tauG_x", "tauG_y", "tauG_z", "E", "sat"];
    names.forEach(function (n) { out.push("omega_" + n, "T_" + n); });
    return out;
  }
  function isObj(x) { return x && typeof x === "object" && !Array.isArray(x); }
  /* v4: wheel ids of a record. The browser engine and the backend's default set use x, y, z (edge mode shows
     wheel x); a research-backend record with an explicit 'wheels' block names its own wheels (columns omega_<id>, T_<id>). */
  function customWheels(rec) { var w = rec && rec.config && rec.config.wheels; return Array.isArray(w) && w.length > 0; }
  function wheelIds(rec) {
    if (customWheels(rec)) return rec.config.wheels.map(function (w, i) { return String(w && w.id != null ? w.id : "w" + (i + 1)); });
    return rec && rec.config && rec.config.mode === "edge" ? ["x"] : ["x", "y", "z"];
  }
  function validateRecord(rec, opts) {
    opts = opts || {};
    var E = [], W = [];
    if (!isObj(rec)) return { ok: false, errors: ["The file does not contain a JSON object."], warnings: [] };
    if (rec.schema !== AERIS_TWIN.VERSION.run) { E.push("Unsupported record schema '" + String(rec.schema) + "'. This site reads '" + AERIS_TWIN.VERSION.run + "' runs and '" + AERIS_TWIN.VERSION.config + "' configurations."); return { ok: false, errors: E, warnings: W }; }
    if (typeof rec.id !== "string" || !rec.id) E.push("Missing run id.");
    if (!isObj(rec.config)) { E.push("Missing configuration snapshot ('config')."); return { ok: false, errors: E, warnings: W }; }
    if (rec.schema_revision != null && ["1.0", "1.1", "1.2", "1.3"].indexOf(rec.schema_revision) < 0) { E.push("Unknown aeris-run/1 revision '" + rec.schema_revision + "' (this site reads 1.0, 1.1, 1.2 and 1.3)."); return { ok: false, errors: E, warnings: W }; }
    if (isBackendRecord(rec)) return validateBackendRecord(rec, E, W);
    var v = AERIS_TWIN.validateConfig(rec.config);
    if (!v.ok) v.errors.forEach(function (e) { E.push("config." + e.path + ": " + e.message); });
    var oc = rec.outcome && rec.outcome.code;
    if (!oc || !AERIS_TWIN.OUTCOMES[oc]) E.push("Missing or unknown outcome code '" + String(oc) + "'.");
    if (oc === "invalid") { E.push("This record holds no valid run (its outcome is 'Invalid configuration'), so there is nothing to replay."); return { ok: false, errors: E, warnings: W }; }
    if (!v.ok) return { ok: false, errors: E, warnings: W };
    var S = rec.samples;
    if (!isObj(S) || !isObj(S.cols) || !isObj(S.units)) { E.push("Missing recorded samples ('samples.cols' and 'samples.units')."); return { ok: false, errors: E, warnings: W }; }
    var mode = v.config.mode, req = REQUIRED_COLS[mode], n = Array.isArray(S.cols.t) ? S.cols.t.length : 0;
    if (n < 2) E.push("The sample table needs at least two rows (column 't').");
    req.forEach(function (c) { if (!Array.isArray(S.cols[c])) E.push("Missing sample column '" + c + "' for " + mode + " mode."); });
    Object.keys(S.cols).forEach(function (c) {
      var col = S.cols[c];
      if (!Array.isArray(col)) { E.push("Sample column '" + c + "' is not an array."); return; }
      if (col.length !== n) E.push("Sample column '" + c + "' has " + col.length + " rows; column 't' has " + n + ".");
      for (var i = 0; i < col.length; i++) if (typeof col[i] !== "number" || !isFinite(col[i])) { E.push("Sample column '" + c + "' row " + i + " is not a finite number."); break; }
      if (!S.units[c]) W.push("Sample column '" + c + "' has no unit.");
    });
    if (!E.length) {
      var t = S.cols.t;
      if (Math.abs(t[0]) > 1e-9) E.push("Samples must start at t = 0 s (found " + t[0] + " s).");
      for (var i = 1; i < n; i++) if (!(t[i] > t[i - 1])) { E.push("Sample times must increase (row " + i + ")."); break; }
      if (t[n - 1] > v.config.duration_s + 1e-6) E.push("Samples run to " + t[n - 1] + " s, beyond the configured window of " + v.config.duration_s + " s.");
    }
    if (!isObj(rec.metrics)) E.push("Missing metrics.");
    else {
      NUM_METRICS.forEach(function (k) { var x = rec.metrics[k]; if (typeof x !== "number" || !isFinite(x)) E.push("Metric '" + k + "' is missing or not a finite number."); });
      NULLABLE_METRICS.forEach(function (k) { var x = rec.metrics[k]; if (x !== null && x !== undefined && (typeof x !== "number" || !isFinite(x))) E.push("Metric '" + k + "' must be a number or null."); });
    }
    if (rec.outcome && typeof rec.outcome.reason !== "string") E.push("The outcome has no reason text.");
    if (rec.software && rec.software.model && rec.software.model !== AERIS_TWIN.VERSION.model) W.push("Recorded with model '" + rec.software.model + "'; this site runs '" + AERIS_TWIN.VERSION.model + "'. The saved samples are shown as recorded; re-running may differ.");
    if (rec.experiment_id !== undefined && !IDS.isValid(rec.experiment_id) && !IDS.fromLegacy(rec.experiment_id)) W.push("Experiment ID '" + String(rec.experiment_id) + "' is not in the AERIS-EXP-###### format; a new one is assigned.");
    if (rec.timeline !== undefined && rec.timeline !== null && (!isObj(rec.timeline) || !Array.isArray(rec.timeline.events) || rec.timeline.events.some(function (e) { return !e || typeof e.t !== "number" || !isFinite(e.t) || typeof e.type !== "string"; }))) E.push("The event timeline is malformed (each event needs a numeric 't' and a 'type').");
    if (rec.origin && rec.origin.kind === "hardware") E.push("This is a hardware recording; import it on the Validation page (aeris-hardware-run/1), not as a simulated run.");
    return { ok: E.length === 0, errors: E, warnings: W, validation: v };
  }
  /* A backend record is validated against its own contents: the configuration's structure (layer 1),
     the backend's derived mass properties, design, definitions and research results. The browser engine's
     limits do not apply (the record was not computed here) and nothing is reconstructed with the browser model. */
  function validateBackendRecord(rec, E, W) {
    var st = CFG.structural(rec.config);
    st.errors.forEach(function (e) { E.push("config." + e.path + ": " + e.message); });
    if (rec.config.mode !== "edge" && rec.config.mode !== "corner") E.push("config.mode: must be 'edge' or 'corner'.");
    var oc = rec.outcome && rec.outcome.code;
    if (!oc || !AERIS_TWIN.OUTCOMES[oc]) E.push("Missing or unknown outcome code '" + String(oc) + "'.");
    if (oc === "invalid") { E.push("This record holds no valid run (its outcome is 'Invalid configuration'), so there is nothing to replay."); return { ok: false, errors: E, warnings: W, backend: true }; }
    if (!isObj(rec.origin) || rec.origin.kind !== "simulation" || !rec.origin.engine || !rec.origin.engine_version) E.push("A backend record needs origin { kind: 'simulation', engine, engine_version }.");
    var missing = [];
    if (!isObj(rec.derived)) missing.push("derived"); else BACKEND_DERIVED_PATHS.forEach(function (p) { if (!hasPaths(rec.derived, [p])) missing.push("derived." + p); });
    if (!isObj(rec.design)) missing.push("design"); else BACKEND_DESIGN_PATHS.forEach(function (p) { if (!hasPaths(rec.design, [p])) missing.push("design." + p); });
    if (!isObj(rec.definitions) || !isObj(rec.definitions.metrics) || !isObj(rec.definitions.assessment)) missing.push("definitions");
    if (!isObj(rec.research) || !isObj(rec.research.recovery)) missing.push("research");
    if (!isObj(rec.termination) || typeof rec.termination.reason !== "string") missing.push("termination");
    if (!isObj(rec.executed) || !isObj(rec.executed.controller) || !isObj(rec.executed.estimator)) missing.push("executed");
    if (typeof rec.provenance !== "string" || !rec.provenance) missing.push("provenance");
    if (missing.length) E.push("This backend record is incomplete (missing " + missing.join(", ") + "). The browser does not rebuild backend metadata with its own model; export the complete record from the backend.");
    if (rec.executed && rec.executed.controller && rec.config.controller && rec.executed.controller.type !== rec.config.controller.type) E.push("The executed controller (" + rec.executed.controller.type + ") differs from the configured one (" + rec.config.controller.type + ").");
    var S = rec.samples;
    if (!isObj(S) || !isObj(S.cols) || !isObj(S.units)) { E.push("Missing recorded samples ('samples.cols' and 'samples.units')."); return { ok: false, errors: E, warnings: W, backend: true }; }
    var mode = rec.config.mode, req = backendColumns(rec, mode), n = Array.isArray(S.cols.t) ? S.cols.t.length : 0;
    if (n < 2) E.push("The sample table needs at least two rows (column 't').");
    req.forEach(function (c) { if (!Array.isArray(S.cols[c])) E.push("Missing sample column '" + c + "' for " + mode + " mode."); });
    Object.keys(S.cols).forEach(function (c) {
      var col = S.cols[c];
      if (!Array.isArray(col)) { E.push("Sample column '" + c + "' is not an array."); return; }
      if (col.length !== n) E.push("Sample column '" + c + "' has " + col.length + " rows; column 't' has " + n + ".");
      for (var i = 0; i < col.length; i++) if (typeof col[i] !== "number" || !isFinite(col[i])) { E.push("Sample column '" + c + "' row " + i + " is not a finite number."); break; }
      if (!S.units[c]) W.push("Sample column '" + c + "' has no unit.");
    });
    if (!E.length) {
      var t = S.cols.t;
      if (Math.abs(t[0]) > 1e-9) E.push("Samples must start at t = 0 s (found " + t[0] + " s).");
      for (var i = 1; i < n; i++) if (!(t[i] > t[i - 1])) { E.push("Sample times must increase (row " + i + ")."); break; }
      if (t[n - 1] > rec.config.duration_s + 1e-6) E.push("Samples run to " + t[n - 1] + " s, beyond the configured window of " + rec.config.duration_s + " s.");
    }
    if (!isObj(rec.metrics)) E.push("Missing metrics.");
    else {
      NUM_METRICS.forEach(function (k) { var x = rec.metrics[k]; if (typeof x !== "number" || !isFinite(x)) E.push("Metric '" + k + "' is missing or not a finite number."); });
      NULLABLE_METRICS.forEach(function (k) { var x = rec.metrics[k]; if (x !== null && x !== undefined && (typeof x !== "number" || !isFinite(x))) E.push("Metric '" + k + "' must be a number or null."); });
    }
    if (rec.outcome && typeof rec.outcome.reason !== "string") E.push("The outcome has no reason text.");
    if (rec.timeline !== undefined && rec.timeline !== null && (!isObj(rec.timeline) || !Array.isArray(rec.timeline.events) || rec.timeline.events.some(function (e) { return !e || typeof e.t !== "number" || !isFinite(e.t) || typeof e.type !== "string"; }))) E.push("The event timeline is malformed (each event needs a numeric 't' and a 'type').");
    if (rec.validation && rec.validation.status === "validated") W.push("The record says VALIDATED; this site shows that label only with a published comparison (docs/RESEARCH_PLATFORM.md §8).");
    if (rec.experiment_id !== undefined && !IDS.isValid(rec.experiment_id)) W.push("Experiment ID '" + String(rec.experiment_id) + "' is not in the AERIS-EXP-###### format; a new one is assigned.");
    return { ok: E.length === 0, errors: E, warnings: W, backend: true, validation: null };
  }
  /* fill in derived quantities from the saved configuration if an imported record lacks them */
  /* derived quantities are a pure function of the saved configuration: recompute them when a file lacks them
     (or carries an incomplete copy), so every panel works from the run's own setup */
  function completeRecord(rec, val) {
    if (isBackendRecord(rec) || (val && val.backend)) {
      // backend metadata is the backend's: keep it as it is (validateBackendRecord has checked it is complete)
      if (!Array.isArray(rec.outcome.notes)) rec.outcome.notes = [];
      if (!rec.outcome.label) rec.outcome.label = AERIS_TWIN.OUTCOMES[rec.outcome.code].label;
      if (!rec.name) rec.name = autoName(CFG.normalize(rec.config));
      if (!Array.isArray(rec.warnings)) rec.warnings = [];
      if (!rec.events) rec.events = { fellAt: rec.metrics ? rec.metrics.fellAt_s : null, contactAt: rec.metrics ? rec.metrics.contactAt_s : null, fallCause: null, failedWheels: [] };
      SCHEMA.normalizeRun(rec, { taken: takenIds(), timeline: EVENTS.fromRecord });
      return rec;
    }
    var v = val && val.validation;
    if (v && v.ok) {
      if (!isObj(rec.derived) || !hasPaths(rec.derived, DERIVED_PATHS)) rec.derived = summarizeMP(v.mp, v.config);
      if (!isObj(rec.design) || !hasPaths(rec.design, DESIGN_PATHS) || (v.config.mode === "corner" && !hasPaths(rec.design, ["plant.Th0", "plant.Thh", "yaw.K"]))) rec.design = summarizeDesign(v.design);
    }
    if (!isObj(rec.definitions) || !isObj(rec.definitions.assessment) || !isObj(rec.definitions.metrics) || typeof rec.definitions.assessment.settleTolDeg !== "number") rec.definitions = { metrics: AERIS_TWIN.METRIC_DEFS, assessment: AERIS_TWIN.ASSESS, outcomes: AERIS_TWIN.OUTCOMES };
    if (!Array.isArray(rec.outcome.notes)) rec.outcome.notes = [];
    if (!rec.outcome.label) rec.outcome.label = AERIS_TWIN.OUTCOMES[rec.outcome.code].label;
    if (!rec.provenance) rec.provenance = "Simulation with nominal (unvalidated) parameters. Not a hardware measurement.";
    if (!rec.events) rec.events = { fellAt: rec.metrics ? rec.metrics.fellAt_s : null, contactAt: rec.metrics ? rec.metrics.contactAt_s : null, fallCause: null, failedWheels: [] };
    if (!rec.name) rec.name = autoName(CFG.normalize(rec.config));
    if (!rec.created) rec.created = new Date().toISOString();
    if (!Array.isArray(rec.warnings)) rec.warnings = [];
    if (!rec.definitions.events) rec.definitions.events = AERIS_TWIN.EVENT_DEFS;
    SCHEMA.normalizeRun(rec, { taken: takenIds(), timeline: EVENTS.fromRecord });
    return rec;
  }

  /* ---------------- persistence ---------------- */
  function indexEntry(rec, size) {
    var c = rec.config || {};
    return { id: rec.id, experiment_id: rec.experiment_id || null, name: rec.name, created: rec.created, source: rec.source || "simulation", collection: rec.collection || "user", origin: rec.origin ? rec.origin.kind : "simulation", group: rec.group ? rec.group.id : null, mode: c.mode, controller: c.controller && c.controller.type, duration_s: c.duration_s, outcome: rec.outcome && rec.outcome.code, label: rec.outcome && rec.outcome.label, size: size || 0 };
  }
  function rawList() { var idx = readJSON(KEYS.index); return Array.isArray(idx) ? idx.filter(function (e) { return e && e.id && store.getItem(KEYS.run + e.id) !== null; }) : []; }
  /* one-time upgrade of records saved by site v2: give each an experiment ID and a timeline, and store it back */
  function migrate() {
    migrated = true;
    var idx = rawList(), need = idx.filter(function (e) { return !e.experiment_id; });
    if (!need.length) return;
    var taken = idx.map(function (e) { return e.experiment_id; }).filter(Boolean);
    need.forEach(function (e) {
      var rec = readJSON(KEYS.run + e.id); if (!rec) return;
      SCHEMA.normalizeRun(rec, { taken: taken, timeline: EVENTS.fromRecord });
      taken.push(rec.experiment_id);
      try { var txt = JSON.stringify(rec); store.setItem(KEYS.run + rec.id, txt); e.experiment_id = rec.experiment_id; e.collection = rec.collection; e.origin = rec.origin.kind; e.size = txt.length; } catch (x) { /* storage full: upgrade again next time */ }
    });
    try { writeIndex(idx); } catch (x) { /* ignore */ }
  }
  function list() { if (!migrated) migrate(); return rawList(); }
  function findByExperimentId(xid) { return list().filter(function (e) { return e.experiment_id === xid; })[0] || null; }
  function writeIndex(idx) { store.setItem(KEYS.index, JSON.stringify(idx)); }
  /* fields starting with "_" are view caches (wheel angles, unsaved flags) and never leave the page */
  function noPrivate(k, v) { return typeof k === "string" && k.charAt(0) === "_" ? undefined : v; }
  function save(rec) {
    var txt;
    try { txt = JSON.stringify(rec, noPrivate); } catch (e) { return { ok: false, error: "The run could not be serialised: " + e.message }; }
    var idx = list().filter(function (e) { return e.id !== rec.id; });
    idx.unshift(indexEntry(rec, txt.length));
    try { store.setItem(KEYS.run + rec.id, txt); writeIndex(idx); }
    catch (e) {
      try { store.removeItem(KEYS.run + rec.id); } catch (e2) { /* ignore */ }
      if (isQuota(e)) return { ok: false, quota: true, error: "Browser storage is full (" + Math.round(usage() / 1024) + " kB used by saved runs). The run is still open in this tab: export it, or delete older recordings and save again." };
      return { ok: false, error: "The browser refused to store the run: " + e.message };
    }
    return { ok: true, persistent: persistent, size: txt.length };
  }
  function load(id) {
    var rec = readJSON(KEYS.run + id);
    if (!rec) return { ok: false, error: "Recording '" + id + "' was not found in browser storage." };
    var val = validateRecord(rec);
    if (!val.ok) return { ok: false, error: "Recording '" + (rec.name || id) + "' is damaged: " + val.errors.slice(0, 3).join(" "), errors: val.errors };
    return { ok: true, record: completeRecord(rec, val), warnings: val.warnings };
  }
  function rename(id, name) { var r = load(id); if (!r.ok) return r; r.record.name = String(name).slice(0, 140) || r.record.name; return save(r.record); }
  function remove(id) { try { store.removeItem(KEYS.run + id); writeIndex(list().filter(function (e) { return e.id !== id; })); return { ok: true }; } catch (e) { return { ok: false, error: e.message }; } }
  function clearAll() {
    var ids = list().map(function (e) { return e.id; }), extra = [];
    for (var i = 0; i < store.length; i++) { var k = store.key(i); if (k && k.indexOf(KEYS.run) === 0) extra.push(k); }
    ids.forEach(function (id) { store.removeItem(KEYS.run + id); });
    extra.forEach(function (k) { store.removeItem(k); });
    store.removeItem(KEYS.index);
    return { ok: true, removed: ids.length };
  }
  function usage() { var n = 0; for (var i = 0; i < store.length; i++) { var k = store.key(i); if (k && k.indexOf("aeris.v2.") === 0) { var v = store.getItem(k); n += (v ? v.length : 0) + k.length; } } return n; }
  function saveDraft(cfg) { try { store.setItem(KEYS.draft, JSON.stringify(cfg)); return true; } catch (e) { return false; } }
  function loadDraft() { return readJSON(KEYS.draft); }
  function savePrefs(p) { try { store.setItem(KEYS.prefs, JSON.stringify(p)); } catch (e) { /* ignore */ } }
  function loadPrefs() { return readJSON(KEYS.prefs) || {}; }

  /* ---------------- export ---------------- */
  function exportJSON(recs) {
    if (!Array.isArray(recs)) return JSON.stringify(recs, noPrivate, 1);
    return JSON.stringify({ schema: "aeris-runs-bundle/1", exported: new Date().toISOString(), software: SITE_VERSION, runs: recs }, noPrivate, 1);
  }
  function exportConfig(cfg) { return JSON.stringify(CFG.normalize(cfg), null, 2); }
  function csvCell(v) { var s = String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
  /* The recording schedule of a record. v5 records carry samples.schedule (requested and realized rate, stride,
     endpoint rule); for older records the realized rate is measured from the sample times. AERIS v4 could record
     every round(f/record_hz) steps while labelling the requested rate (defect D): such a mismatch is detected and
     reported here, the record itself is never relabelled. */
  function recordingInfo(rec) {
    var S = rec && rec.samples, t = S && S.cols && S.cols.t, sch = (S && S.schedule) || null;
    var labelled = S ? S.rate_hz : null, requested = rec && rec.config ? rec.config.record_hz : null;
    var realized = sch && isFinite(sch.realized_hz) ? sch.realized_hz : null;
    if (realized == null && t && t.length >= 3 && t[1] > t[0]) realized = 1 / (t[1] - t[0]);
    var mismatch = realized != null && isFinite(labelled) && Math.abs(realized - labelled) > 1e-4 * Math.max(1, labelled);
    var off = requested != null && realized != null && Math.abs(realized - requested) > 1e-4 * Math.max(1, requested);
    return { requested: requested, labelled: labelled, realized: realized, mismatch: mismatch, differsFromRequest: off, schedule: sch,
      note: mismatch ? "Recorded every " + (1000 / realized).toPrecision(4) + " ms (" + (+realized.toPrecision(6)) + " Hz) but labelled " + labelled + " Hz: written by a version with the recording-rate defect (AERIS v4, docs/RECORDING.md). The samples are correct; the label is not." :
        off ? "Recorded at " + (+realized.toPrecision(6)) + " Hz (requested " + requested + " Hz)." : null };
  }
  function metricsVersion(rec) { var R = rec && rec.research; if (!R) return null; return R.metrics_version || (rec.reproduction && rec.reproduction.metrics_version) || "1"; }
  function toCSV(rec) {
    if (!rec.samples) return "# This run has no samples (outcome: " + (rec.outcome && rec.outcome.label) + ")\n";
    var c = rec.config, S = rec.samples, cols = Object.keys(S.cols), n = S.cols.t.length, lines = [];
    lines.push("# AERIS run export (" + rec.schema + ")");
    lines.push("# " + rec.provenance);
    lines.push("# name: " + rec.name);
    lines.push("# experiment: " + (rec.experiment_id || "—") + " ; id: " + rec.id + " ; created: " + rec.created);
    lines.push("# source: " + (rec.origin ? rec.origin.kind + " (" + rec.origin.engine + ", " + (rec.origin.engine_version || "") + ")" : rec.source) + " ; validation: " + (rec.validation ? rec.validation.status + " (" + rec.validation.parameter_set + ")" : "nominal"));
    lines.push("# model: " + (rec.software && rec.software.model) + " ; solver: " + (rec.software && rec.software.solver));
    // research-backend records name the method that actually ran (executed), e.g. "nlpd (nonlinear-full-tensor)"
    var ex = rec.executed || null, ctl = ex && ex.controller ? ex.controller.type + " (" + ex.controller.structure + ")" : c.controller.type, est = ex && ex.estimator ? ex.estimator.type + (ex.estimator.truth_access ? " (perfect-state baseline)" : "") : c.estimator.type;
    var ri = recordingInfo(rec);
    lines.push("# mode: " + c.mode + " ; controller: " + ctl + " ; estimator: " + est + " ; seed: " + c.seed + " ; control loop: " + c.params.fs + " Hz ; recorded at " + (ri.realized != null ? +ri.realized.toPrecision(6) : S.rate_hz) + " Hz" + (ri.mismatch ? " (the record's label says " + S.rate_hz + " Hz: AERIS v4 recording-rate defect)" : ri.differsFromRequest ? " (requested " + ri.requested + " Hz)" : ""));
    if (rec.research) lines.push("# research metrics version: " + metricsVersion(rec) + (metricsVersion(rec) === "1" ? " (pre-v5 definitions: angular ISE in rad²·s mislabelled as deg²·s and one extra interval weight; reanalyse with v5, docs/METRICS.md)" : " (time-weighted trapezoidal integrals; IAE in deg·s, ISE in deg²·s; docs/METRICS.md)"));
    if (rec.lineage) lines.push("# lineage: " + rec.lineage.relation + " of " + (rec.lineage.derived_from_experiment || rec.lineage.derived_from || rec.lineage.retry_of_job || ""));
    lines.push("# outcome: " + rec.outcome.label + " — " + rec.outcome.reason.replace(/\n/g, " "));
    lines.push("# full configuration is in the JSON export of this run");
    lines.push(cols.map(function (k) { return csvCell(k + " [" + (S.units[k] || "") + "]"); }).join(","));
    for (var i = 0; i < n; i++) lines.push(cols.map(function (k) { return S.cols[k][i]; }).join(","));
    return lines.join("\n") + "\n";
  }

  /* ---------------- import ---------------- */
  function parseImport(text) {
    var out = { runs: [], configs: [], errors: [], warnings: [] };
    if (typeof text !== "string" || !text.trim()) { out.errors.push("The file is empty."); return out; }
    if (text.length > MAX_IMPORT_CHARS) { out.errors.push("The file is larger than " + Math.round(MAX_IMPORT_CHARS / 1e6) + " MB."); return out; }
    var obj;
    try { obj = JSON.parse(text); }
    catch (e) { out.errors.push("This is not valid JSON (" + e.message + "). Export files from this site end in .json; CSV exports contain samples only and cannot be imported."); return out; }
    function one(rec, where) {
      if (isObj(rec) && rec.schema === AERIS_TWIN.VERSION.config) {
        // layer 1 always; the browser's physical checks for setups it can run itself. A setup with research-backend
        // features is imported intact (nothing is dropped) and runs in SIMULATION mode.
        var ext = CFG.extensions(rec), st = CFG.structural(rec);
        if (st.errors.length) { st.errors.forEach(function (e) { out.errors.push(where + "configuration: " + e.path + ": " + e.message); }); return; }
        if (!ext.length) {
          var vc = AERIS_TWIN.validateConfig(rec);
          if (!vc.ok) { vc.errors.forEach(function (e) { out.errors.push(where + "configuration: " + e.path + ": " + e.message); }); return; }
          vc.warnings.forEach(function (w) { out.warnings.push(where + "configuration: " + w.message); });
        } else out.warnings.push(where + "configuration uses research-backend features (" + ext.map(CFG.describeFeature).filter(function (x, i, a) { return a.indexOf(x) === i; }).join("; ") + "); it runs in SIMULATION mode and is kept intact.");
        st.warnings.forEach(function (w) { out.warnings.push(where + "configuration: " + w.path + ": " + w.message); });
        out.configs.push(CFG.normalize(rec));
        return;
      }
      var val = validateRecord(rec);
      if (!val.ok) { val.errors.forEach(function (e) { out.errors.push(where + e); }); return; }
      val.warnings.forEach(function (w) { out.warnings.push(where + w); });
      out.runs.push(completeRecord(rec, val));
    }
    if (isObj(obj) && obj.schema === "aeris-runs-bundle/1") {
      if (!Array.isArray(obj.runs)) { out.errors.push("The bundle has no 'runs' list."); return out; }
      obj.runs.forEach(function (r, i) { one(r, "Run " + (i + 1) + (r && r.name ? " ('" + r.name + "')" : "") + ": "); });
    } else one(obj, "");
    return out;
  }
  /* store imported runs; ids that already exist get a fresh id unless the content is identical */
  function importRuns(runs) {
    var added = [], skipped = [], failed = [];
    runs.forEach(function (rec) {
      var existing = readJSON(KEYS.run + rec.id);
      if (existing) {
        if (JSON.stringify(existing.samples) === JSON.stringify(rec.samples) && JSON.stringify(existing.config) === JSON.stringify(rec.config)) { skipped.push(rec); return; }
        rec.id = rid(); rec.name = rec.name + " (imported)";
      }
      if (rec.collection !== "example") rec.collection = "imported";
      var clash = rec.experiment_id ? findByExperimentId(rec.experiment_id) : null;
      if (clash && clash.id !== rec.id) { rec.original_experiment_id = rec.experiment_id; rec.experiment_id = IDS.next(takenIds()); }
      var s = save(rec);
      if (s.ok) added.push(rec); else failed.push({ record: rec, error: s.error });
    });
    return { added: added, skipped: skipped, failed: failed };
  }

  /* ---------------- reproducibility check ---------------- */
  function reproduce(rec) {
    if (!isBrowserRecord(rec)) return { ok: false, identical: false, message: "This run was produced by '" + rec.origin.engine + "'. Reproduce it on that engine (the research backend reproduces its own runs)." };
    var r = AERIS_TWIN.simulate(rec.config);
    if (!r.ok) return { ok: false, identical: false, message: "The saved configuration no longer validates: " + (r.errors[0] && r.errors[0].message) };
    var a = rec.samples.cols, b = r.samples.cols, maxRel = 0, cols = Object.keys(a).filter(function (k) { return b[k]; });
    var same = a.t.length === b.t.length;
    if (same) cols.forEach(function (k) { for (var i = 0; i < a[k].length; i++) { var d = Math.abs(a[k][i] - b[k][i]), s = Math.max(1e-9, Math.abs(a[k][i])); if (d / s > maxRel) maxRel = d / s; } });
    var identical = same && maxRel === 0 && r.outcome.code === rec.outcome.code;
    return { ok: true, identical: identical, sameOutcome: r.outcome.code === rec.outcome.code, maxRelDiff: maxRel, rows: [a.t.length, b.t.length], outcome: r.outcome, model: AERIS_TWIN.VERSION.model };
  }

  return {
    KEYS: KEYS, SITE_VERSION: SITE_VERSION, CTRL_NAMES: CTRL_NAMES, modelValidation: modelValidation, findByExperimentId: findByExperimentId,
    get persistent() { return persistent; }, useStorage: useStorage, memoryStore: memoryStore,
    fromSimulation: fromSimulation, autoName: autoName, validateRecord: validateRecord, completeRecord: completeRecord,
    list: list, save: save, load: load, rename: rename, remove: remove, clearAll: clearAll, usage: usage,
    saveDraft: saveDraft, loadDraft: loadDraft, savePrefs: savePrefs, loadPrefs: loadPrefs,
    exportJSON: exportJSON, exportConfig: exportConfig, toCSV: toCSV, parseImport: parseImport, importRuns: importRuns, reproduce: reproduce, recordingInfo: recordingInfo, metricsVersion: metricsVersion,
    isBackendRecord: isBackendRecord, isBrowserRecord: isBrowserRecord, BACKEND_ENGINE: BACKEND_ENGINE, wheelIds: wheelIds, customWheels: customWheels
  };
})(typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("./core.js"),
   typeof AERIS_IDS !== "undefined" ? AERIS_IDS : require("./platform/ids.js"),
   typeof AERIS_SCHEMA !== "undefined" ? AERIS_SCHEMA : require("./platform/schema.js"),
   typeof AERIS_EVENTS !== "undefined" ? AERIS_EVENTS : require("./platform/events.js"),
   typeof AERIS_CFG !== "undefined" ? AERIS_CFG : require("./platform/config.js"));
if (typeof module !== "undefined") module.exports = AERIS_RUNS;

/* =====================================================================
   AERIS · DEVICE API CLIENT — /api/v6 of the AERIS backend (devices, pairing,
   profiles, recipes, calibrations, approved configurations, control leases,
   bounded commands, telemetry, recordings, the twin). docs/CONNECT.md.

   Authentication: local mode needs nothing (the backend accepts this computer
   only); jwt mode sends "Authorization: Bearer <token>" from the token provider
   (js/connect/auth.js) and opens WebSockets with a single-use ticket. Nothing
   here stores or embeds credentials.
   ===================================================================== */
var AERIS_DEVAPI = (function () {
  "use strict";
  var V6 = "/api/v6";
  function Client(opts) {
    opts = opts || {};
    this.baseUrl = String(opts.baseUrl || "").replace(/\/+$/, "");
    this.wsUrl = opts.wsUrl ? String(opts.wsUrl).replace(/\/+$/, "") : (this.baseUrl ? this.baseUrl.replace(/^http/, "ws") : null);
    this.fetch = opts.fetch || (typeof fetch !== "undefined" ? function (u, o) { return fetch(u, o); } : null);
    this.WS = opts.WebSocket || (typeof WebSocket !== "undefined" ? WebSocket : null);
    this.token = opts.token || function () { return null; };
    this.timeoutMs = opts.timeoutMs || 20000;
    this.statusCache = null;
  }
  var C = Client.prototype;
  C.configured = function () { return !!(this.baseUrl && this.fetch); };
  C.request = function (method, path, body) {
    var self = this;
    if (!this.configured()) return Promise.reject({ code: "unavailable", message: "No AERIS backend is configured for this page." });
    var h = { "Accept": "application/json", "X-AERIS-Client": "aeris-web/6.0" }, tok = this.token();
    if (tok) h.Authorization = "Bearer " + tok;
    var init = { method: method, headers: h };
    if (body !== undefined) { h["Content-Type"] = "application/json"; init.body = JSON.stringify(body); }
    var timer, tmo = new Promise(function (_, rej) { timer = setTimeout(function () { rej({ code: "timeout", message: "The backend did not answer within " + self.timeoutMs / 1000 + " s.", retryable: true }); }, self.timeoutMs); });
    var call = Promise.resolve().then(function () { return self.fetch(self.baseUrl + V6 + path, init); }).then(function (res) {
      return res.text().then(function (t) {
        var data = null; if (t) { try { data = JSON.parse(t); } catch (e) { throw { code: "bad_response", message: "Not JSON (HTTP " + res.status + ").", status: res.status }; } }
        if (!res.ok) { var er = (data && data.error) || {}; throw { code: er.code || "http_" + res.status, message: er.message || ("HTTP " + res.status), details: er.details || [], status: res.status, retryable: !!er.retryable }; }
        return data;
      });
    }, function (e) { throw { code: "network", message: "The backend could not be reached: " + (e && e.message || e), retryable: true }; });
    return Promise.race([call, tmo]).then(function (v) { clearTimeout(timer); return v; }, function (e) { clearTimeout(timer); throw e; });
  };
  function enc(s) { return encodeURIComponent(s); }
  C.status = function () { var self = this; return this.request("GET", "/status").then(function (s) { self.statusCache = s; return s; }); };
  C.me = function () { return this.request("GET", "/me"); };
  C.profiles = function () { return this.request("GET", "/profiles"); };
  C.profile = function (id, rev) { return this.request("GET", "/profiles/" + enc(id) + (rev ? "?revision=" + rev : "")); };
  C.createProfile = function (doc) { return this.request("POST", "/profiles", doc); };
  C.validateProfile = function (doc) { return this.request("POST", "/profiles/validate", doc); };
  C.recipes = function () { return this.request("GET", "/recipes"); };
  C.recipe = function (id) { return this.request("GET", "/recipes/" + enc(id)); };
  C.kits = function () { return this.request("GET", "/kits"); };
  C.devices = function () { return this.request("GET", "/devices"); };
  C.device = function (id) { return this.request("GET", "/devices/" + enc(id)); };
  C.setProfile = function (id, pid, rev) { return this.request("POST", "/devices/" + enc(id) + "/profile", { id: pid, revision: rev }); };
  C.rename = function (id, name) { return this.request("POST", "/devices/" + enc(id) + "/name", { name: name }); };
  C.revoke = function (id) { return this.request("POST", "/devices/" + enc(id) + "/revoke"); };
  C.pairingStart = function () { return this.request("POST", "/pairing/start"); };
  C.pairingComplete = function (proof, name) { return this.request("POST", "/pairing/complete", { proof: proof, name: name || null }); };
  C.calibrations = function (id) { return this.request("GET", "/devices/" + enc(id) + "/calibrations"); };
  C.createCalibration = function (id, body) { return this.request("POST", "/devices/" + enc(id) + "/calibrations", body); };
  C.calibration = function (cid) { return this.request("GET", "/calibrations/" + enc(cid)); };
  C.buildConfig = function (id, body) { return this.request("POST", "/devices/" + enc(id) + "/configs", body); };
  C.config = function (h) { return this.request("GET", "/configs/" + enc(h)); };
  C.lease = function (id, holder, takeover) { return this.request("POST", "/devices/" + enc(id) + "/lease", { holder: holder, takeover: !!takeover }); };
  C.releaseLease = function (id, holder) { return this.request("POST", "/devices/" + enc(id) + "/lease/release", { holder: holder }); };
  C.command = function (id, body) { return this.request("POST", "/devices/" + enc(id) + "/commands", body); };
  C.commands = function (id) { return this.request("GET", "/devices/" + enc(id) + "/commands"); };
  C.getCommand = function (cid) { return this.request("GET", "/commands/" + enc(cid)); };
  C.frames = function (id, after, stream) { return this.request("GET", "/devices/" + enc(id) + "/frames?after=" + (after | 0) + (stream ? "&stream=" + enc(stream) : "")); };
  C.recordingStart = function (id, name) { return this.request("POST", "/devices/" + enc(id) + "/recordings/start", { name: name }); };
  C.recordingStop = function (id) { return this.request("POST", "/devices/" + enc(id) + "/recordings/stop"); };
  C.recordings = function (id) { return this.request("GET", "/devices/" + enc(id) + "/recordings"); };
  C.twinSimulate = function (body) { return this.request("POST", "/twin/simulate", body); };
  C.twinCompare = function (body) { return this.request("POST", "/twin/compare", body); };
  C.ticket = function (purpose) { return this.request("POST", "/tickets", { purpose: purpose }); };
  /* a WebSocket with authentication: a ticket in jwt mode, nothing in local mode */
  C.socket = function (path, purpose) {
    var self = this;
    if (!this.WS || !this.wsUrl) return Promise.reject({ code: "unavailable", message: "WebSockets are not available." });
    var needTicket = this.statusCache ? !!this.statusCache.tickets_needed : !!this.token();
    var t = needTicket ? this.ticket(purpose) : Promise.resolve(null);
    return t.then(function (tk) {
      var u = self.wsUrl + V6 + path + (tk ? (path.indexOf("?") >= 0 ? "&" : "?") + "ticket=" + enc(tk.ticket) : "");
      var ws = new self.WS(u); ws.binaryType = "arraybuffer"; return ws;
    });
  };
  C.liveSocket = function (id) { return this.socket("/devices/" + enc(id) + "/live", "live"); };
  C.relaySocket = function () { return this.socket("/relay?route=browser-relay", "relay"); };
  /* poll a command until it is final (or one of `until`) */
  C.waitCommand = function (cid, until, timeoutMs, wait) {
    var self = this, want = until || ["completed", "failed", "rejected", "expired", "cancelled"], t0 = Date.now(), sleep = wait || function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    function loop() {
      return self.getCommand(cid).then(function (c) {
        if (want.indexOf(c.status) >= 0) return c;
        if (Date.now() - t0 > (timeoutMs || 30000)) throw { code: "timeout", message: "Command " + cid + " is still " + c.status + "." };
        return sleep(150).then(loop);
      });
    }
    return loop();
  };
  return { Client: Client, create: function (o) { return new Client(o); } };
})();
if (typeof module !== "undefined") module.exports = AERIS_DEVAPI;

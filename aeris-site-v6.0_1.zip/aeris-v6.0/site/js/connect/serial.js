/* =====================================================================
   AERIS · WEB SERIAL TRANSPORT — the cube's USB link in the browser.

   Feature detection: Web Serial exists only in some desktop browsers
   (Chrome, Edge) and only in a secure context (https:// or localhost). The
   page never assumes it: support() says what is missing, and the Connect page
   offers the companion (a local program relaying the port to a local backend)
   instead. The visitor always chooses the port (requestPort needs a click);
   the page never opens a port on its own.

   Tested here: against a scripted serial port standing in for navigator.serial
   in Chromium (site/tests/browser_v6.py); not with a physical board.
   ===================================================================== */
var AERIS_SERIAL = (function () {
  "use strict";
  var ESPRESSIF_VID = 0x303A;            // the ESP32-S3's own USB port (USB Serial/JTAG)
  function support(nav, win) {
    nav = nav || (typeof navigator !== "undefined" ? navigator : {}); win = win || (typeof window !== "undefined" ? window : {});
    if (!("serial" in nav)) return { ok: false, reason: "This browser has no Web Serial (desktop Chrome or Edge have it). Use the companion program instead: it relays the cube's USB port to a backend on this computer." };
    if (win.isSecureContext === false) return { ok: false, reason: "Web Serial needs a secure page (https:// or http://localhost)." };
    return { ok: true, reason: null };
  }
  function Transport(port, opts) {
    this.port = port; this.opts = opts || {}; this.listeners = []; this.closeListeners = []; this.open = false; this.reader = null; this.writer = null; this.reading = null;
    var info = port && port.getInfo ? port.getInfo() : {};
    this.info = { usbVendorId: info.usbVendorId != null ? info.usbVendorId : null, usbProductId: info.usbProductId != null ? info.usbProductId : null };
  }
  Transport.prototype.kind = "web-serial";
  Transport.prototype.label = "USB (Web Serial)";
  Transport.prototype.connect = function () {
    var self = this;
    return Promise.resolve(this.port.open({ baudRate: this.opts.baudRate || 115200, bufferSize: 65536 })).then(function () {
      self.open = true; self.writer = self.port.writable.getWriter(); self.reading = self._readLoop();
    });
  };
  Transport.prototype._readLoop = function () {
    var self = this;
    function loop() {
      if (!self.open || !self.port.readable) return Promise.resolve();
      self.reader = self.port.readable.getReader();
      function pump() {
        return self.reader.read().then(function (r) {
          if (r.done) return;
          if (r.value && r.value.length) self.listeners.forEach(function (fn) { fn(r.value); });
          return pump();
        });
      }
      return pump().catch(function (e) { self._lost(e); }).then(function () { try { self.reader.releaseLock(); } catch (e) { /* closed */ } });
    }
    return loop();
  };
  Transport.prototype._lost = function (e) {
    if (!this.open) return;
    this.open = false;
    var why = (e && e.message) || "the serial port closed";
    this.closeListeners.forEach(function (fn) { fn(why); });
  };
  Transport.prototype.write = function (bytes) {
    if (!this.open || !this.writer) return Promise.reject(new Error("the serial port is not open"));
    var self = this;
    return this.writer.write(bytes).catch(function (e) { self._lost(e); throw e; });
  };
  Transport.prototype.onData = function (fn) { this.listeners.push(fn); };
  Transport.prototype.onClose = function (fn) { this.closeListeners.push(fn); };
  Transport.prototype.close = function () {
    var self = this;
    this.open = false;
    var steps = Promise.resolve();
    if (this.reader) steps = steps.then(function () { return self.reader.cancel().catch(function () {}); });
    if (this.writer) steps = steps.then(function () { try { self.writer.releaseLock(); } catch (e) { /* ignore */ } });
    return steps.then(function () { return Promise.resolve(self.reading).catch(function () {}); }).then(function () { return self.port.close(); }).catch(function () { /* already closed */ });
  };
  /* ask the visitor for a port (needs a user gesture); onlyEspressif filters to the ESP32-S3's own USB port */
  function choose(onlyEspressif, nav) {
    nav = nav || navigator;
    return nav.serial.requestPort(onlyEspressif ? { filters: [{ usbVendorId: ESPRESSIF_VID }] } : {});
  }
  return { support: support, Transport: Transport, choose: choose, ESPRESSIF_VID: ESPRESSIF_VID };
})();
if (typeof module !== "undefined") module.exports = AERIS_SERIAL;

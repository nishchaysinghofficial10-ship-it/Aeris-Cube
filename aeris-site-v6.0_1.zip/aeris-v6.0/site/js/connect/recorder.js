/* =====================================================================
   AERIS · DEVICE TELEMETRY RECORDER (browser) — collects the device's
   aeris-telemetry-ndjson/1 frames and writes an aeris-hardware-run/1 document
   with the same columns, units and provenance rules as the backend recorder
   (backend telemetry/stream.py recording_document).

   Provenance is what the device DECLARED in its hello (device.kind, synthetic),
   never verified: a synthetic, emulator or undeclared source makes the whole
   recording synthetic. The attitude columns are the device's ESTIMATE.
   ===================================================================== */
var AERIS_DEVREC = (function () {
  "use strict";
  var STATUS = { ok: 0, idle: 1, calibrating: 2, fault: 3, estop: 4 };
  var AX = "xyz";
  function Recorder(name, ctx) { this.name = name || "device recording"; this.ctx = ctx || {}; this.started = new Date().toISOString(); this.frames = []; this.segments = []; this.hello = null; this.events = []; }
  var R = Recorder.prototype;
  R.feed = function (msg) {
    if (!msg || typeof msg !== "object") return;
    if (msg.type === "hello") {
      if (this.hello && this.hello.mode && msg.mode !== this.hello.mode && this.frames.length) { this.events.push({ type: "mode_changed", detail: "a hello with another mode closed the recording" }); this.closed = true; return; }
      this.hello = msg; this.segments.push({ hello: msg, session: msg.session, from: this.frames.length });
    } else if (msg.type === "frame" && !this.closed) {
      if (!this.hello || msg.session && msg.session !== this.hello.session) return;
      var last = this.frames[this.frames.length - 1];
      if (last && (msg.seq <= last.seq || msg.t <= last.t)) { this.events.push({ type: "dropped", seq: msg.seq, detail: "not after the previous frame" }); return; }
      this.frames.push(msg);
    } else if (msg.type === "bye") this.events.push({ type: "bye", reason: msg.reason || null, session: msg.session || null });
    else if (msg.kind === "tlm_gap") this.events.push({ type: "gap", from: msg.from, to: msg.to, reason: msg.reason });
  };
  R.document = function () {
    var F = this.frames;
    if (F.length < 2) throw new Error("only " + F.length + " frame(s) were recorded; a recording needs at least two (an approved configuration must be applied for the device to send telemetry)");
    var h = this.segments[0].hello, cols = { t: [], seq: [] }, units = { t: "s", seq: "count" };
    F.forEach(function (f) { cols.t.push(f.t); cols.seq.push(f.seq); });
    function put(name, vals, unit) { if (vals.every(function (v) { return v != null && isFinite(v); })) { cols[name] = vals; units[name] = unit; } }
    if (F.every(function (f) { return Array.isArray(f.q); })) for (var j = 0; j < 4; j++) put("q" + j, F.map(function (f) { return f.q[j]; }), "–");
    if (F.every(function (f) { return typeof f.theta === "number"; })) put("theta", F.map(function (f) { return f.theta; }), "rad");
    [["w", "w_", "rad/s"], ["wheel_rpm", "wheel_rpm_", "rpm"], ["torque_cmd", "torque_cmd_", "N·m"], ["torque_meas", "torque_meas_", "N·m"]].forEach(function (s) {
      if (F.every(function (f) { return Array.isArray(f[s[0]]); })) for (var k = 0; k < 3; k++) put(s[1] + AX[k], F.map(function (f) { return f[s[0]][k]; }), s[2]);
    });
    if (F.every(function (f) { return f.imu && Array.isArray(f.imu.gyro); })) for (var a = 0; a < 3; a++) put("gyro_" + AX[a], F.map(function (f) { return f.imu.gyro[a]; }), "rad/s");
    if (F.every(function (f) { return f.imu && Array.isArray(f.imu.accel); })) for (var b = 0; b < 3; b++) put("accel_" + AX[b], F.map(function (f) { return f.imu.accel[b]; }), "m/s²");
    if (F.every(function (f) { return f.status in STATUS; })) put("status", F.map(function (f) { return STATUS[f.status]; }), "count");
    var segs = this.segments.map(function (s, i, all) {
      var to = i + 1 < all.length ? all[i + 1].from : F.length, d = s.hello.device || {};
      return { segment: i + 1, rows: [s.from, to], session: s.session, device: { id: d.id || null, kind: d.kind || null, firmware: d.firmware || null }, synthetic: s.hello.synthetic, mode: s.hello.mode, hello: s.hello };
    }).filter(function (s) { return s.rows[1] > s.rows[0]; });
    var synthetic = segs.some(function (s) { return s.synthetic !== false || s.device.kind !== "physical"; });
    var d0 = segs[0].device, dur = cols.t[cols.t.length - 1] - cols.t[0];
    var prov = { protocol: "aeris-telemetry-ndjson/1", transport: { kind: this.ctx.transport || "browser" }, hellos: segs.map(function (s) { return s.hello; }), segments: segs,
      source_kind: d0.kind, synthetic: synthetic, trust: synthetic ? "synthetic" : "declared-physical", physical_verified: false,
      trust_reasons: synthetic ? ["the device declared kind " + JSON.stringify(d0.kind) + ", synthetic " + JSON.stringify(segs[0].synthetic)] : ["declared by the device; not verified by the software"],
      events: this.events.slice(0, 1000), status_codes: STATUS, recorded_by: "AERIS website (browser recorder)",
      device_link: { config_hash: h.config_hash || null, boot_id: h.boot_id || null, profile: this.ctx.profile || null, calibration: this.ctx.calibration || null, recipe: this.ctx.recipe || null },
      note: synthetic ? "SYNTHETIC telemetry (" + d0.kind + "): not a measurement of the physical cube; it can never be validation evidence."
                      : "Declared by the source as a physical device; the software cannot verify this. Evidence only through a predeclared protocol." };
    return { schema: "aeris-hardware-run/1", synthetic: synthetic, device: { id: d0.id, kind: d0.kind, firmware: d0.firmware },
      recording: { started: this.started, operator: "AERIS website (browser recorder)", notes: this.name }, mode: h.mode,
      parameters: { parameter_set: "nominal-design-v1" }, samples: { rate_hz: dur > 0 ? (F.length - 1) / dur : null, cols: cols, units: units }, provenance: prov };
  };
  /* NDJSON of the recorded session (the device's own messages; replayable by the backend's telemetry bridge) */
  R.ndjson = function () {
    var out = [], self = this; if (!this.segments.length) return "";
    this.segments.forEach(function (s, i, all) {
      out.push(JSON.stringify(s.hello));
      var to = i + 1 < all.length ? all[i + 1].from : self.frames.length;
      for (var k = s.from; k < to; k++) out.push(JSON.stringify(self.frames[k]));
    });
    return out.join("\n") + "\n";
  };
  return { Recorder: Recorder, STATUS: STATUS };
})();
if (typeof module !== "undefined") module.exports = AERIS_DEVREC;

/* =====================================================================
   AERIS · DEVICE LINK (browser host side of aeris-device-link/1)
   docs/DEVICE_LINK.md. One message per line: <json>\t<crc32 as 8 lower-case hex>\n
   (zlib CRC-32 of the JSON bytes), at most 4096 bytes. Link messages carry
   "kind"; telemetry contract messages (aeris-telemetry-ndjson/1) carry "type".

   The host never closes the balance loop and never retries a command on its
   own: a command is sent once with its id; the device answers cmd_ack and
   cmd_result. A command without an answer is reported as "no answer" after
   its ttl (the same id may be sent again: the device answers with the status
   it has). Nothing here arms motors: start_experiment needs ARM on the cube.

   Capability negotiation (negotiate): an unknown protocol or configuration
   format is offered read-only (identify, diagnostics, stop) with the reasons;
   nothing is substituted.
   ===================================================================== */
var AERIS_LINK = (function () {
  "use strict";
  var LINK = "aeris-device-link/1", CONFIG_SCHEMA = "aeris-device-config/1", MAX_LINE = 4096, HEARTBEAT_MS = 500;
  var READ_ONLY = ["identify", "diagnostics", "stop"];
  var CONTROLLER_FOR_MODE = { edge: "edge-lqr", corner: "corner-mimo-lqr" };
  var TE = typeof TextEncoder !== "undefined" ? new TextEncoder() : new (require("util").TextEncoder)();
  var TD = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-8", { fatal: true }) : new (require("util").TextDecoder)("utf-8", { fatal: true });

  var CRC_T = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(b) { var c = 0xFFFFFFFF; for (var i = 0; i < b.length; i++) c = CRC_T[(c ^ b[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function hex8(n) { var s = n.toString(16); return "00000000".slice(s.length) + s; }
  function frameText(js) {
    var b = TE.encode(js), tail = TE.encode("\t" + hex8(crc32(b)) + "\n"), out = new Uint8Array(b.length + tail.length);
    out.set(b); out.set(tail, b.length); return out;
  }
  function frame(obj) { return frameText(JSON.stringify(obj)); }
  function randomHex(n) {
    var b = new Uint8Array(n);
    if (typeof crypto !== "undefined" && crypto.getRandomValues) crypto.getRandomValues(b); else for (var i = 0; i < n; i++) b[i] = Math.floor(Math.random() * 256);
    return Array.prototype.map.call(b, function (x) { return (x < 16 ? "0" : "") + x.toString(16); }).join("");
  }

  /* ---------------- capability negotiation (the same rules as backend devices/compat.py) ---------------- */
  function negotiate(hello) {
    if (!hello || typeof hello !== "object") return { supported: false, mode: "unknown", reasons: ["the device has not introduced itself"], actions: [] };
    var reasons = [];
    if (hello.link !== LINK || !(hello.versions || []).some(function (v) { return v === 1; })) reasons.push("link protocol " + JSON.stringify(hello.link) + " versions " + JSON.stringify(hello.versions) + ": this page speaks " + LINK + " version 1");
    var caps = hello.caps && typeof hello.caps === "object" ? hello.caps : {};
    if (caps.config_schema !== CONFIG_SCHEMA) reasons.push("configuration format " + JSON.stringify(caps.config_schema) + ": this page writes " + CONFIG_SCHEMA);
    var actions = (caps.actions || []).filter(function (a) { return typeof a === "string"; });
    var fw = hello.fw || {}, board = hello.board || {};
    var out = { supported: !reasons.length, mode: reasons.length ? "read-only" : "full", reasons: reasons,
      actions: reasons.length ? actions.filter(function (a) { return READ_ONLY.indexOf(a) >= 0; }) : actions,
      controllers: (caps.controllers || []).slice(), estimators: (caps.estimators || []).slice(), imu: caps.imu || null, motor: caps.motor || null,
      max_control_hz: caps.max_control_hz || null, actuation_build: !!fw.actuation_build, firmware: fw.version || null, build: fw.build || null,
      board: board.id || null, device_kind: board.kind || null, synthetic: !!board.synthetic, hard_limits: hello.limits || {} };
    if (!out.actuation_build) out.note = "this firmware build never drives motors (sensing, calibration and telemetry only)";
    return out;
  }
  function profileFits(hello, profile, recipe) {
    var c = negotiate(hello); if (!c.supported) return c.reasons.slice();
    var why = [], imu = (profile.imu || {}).driver;
    if (imu !== c.imu) why.push("the profile's IMU driver " + JSON.stringify(imu) + " is not the device's (" + JSON.stringify(c.imu) + ")");
    (profile.wheels || []).forEach(function (w, i) {
      var kind = ((w || {}).driver || {}).kind; if (kind !== c.motor) why.push("wheel " + i + ": driver " + JSON.stringify(kind) + " is not the device's (" + JSON.stringify(c.motor) + ")");
      var mo = (w || {}).motor || {}, lim = c.hard_limits || {};
      if (typeof lim.hard_max_current_A === "number" && mo.Imax_A > lim.hard_max_current_A) why.push("wheel " + i + ": current limit " + mo.Imax_A + " A above the firmware's hard limit " + lim.hard_max_current_A + " A");
      if (typeof lim.hard_max_speed_rpm === "number" && mo.speed_max_rpm > lim.hard_max_speed_rpm) why.push("wheel " + i + ": speed limit " + mo.speed_max_rpm + " rpm above the firmware's hard limit " + lim.hard_max_speed_rpm + " rpm");
      if (typeof lim.hard_max_torque_Nm === "number" && typeof mo.KV_rpm_per_V === "number" && mo.KV_rpm_per_V > 0 && typeof mo.Imax_A === "number") {
        var tmax = 60 / (2 * Math.PI * mo.KV_rpm_per_V) * mo.Imax_A;
        if (tmax > lim.hard_max_torque_Nm) why.push("wheel " + i + ": torque limit " + tmax.toFixed(3) + " N·m above the firmware's hard limit " + lim.hard_max_torque_Nm + " N·m");
      }
    });
    if (recipe) {
      var ctl = CONTROLLER_FOR_MODE[recipe.mode];
      if (c.controllers.indexOf(ctl) < 0) why.push("the device does not implement the " + JSON.stringify(recipe.mode) + " controller (" + ctl + "); it offers " + (c.controllers.join(", ") || "none"));
      var est = (recipe.estimator || {}).type; if (c.estimators.indexOf(est) < 0) why.push("the device does not implement the estimator " + JSON.stringify(est));
      var hz = (recipe.rates || {}).control_hz; if (c.max_control_hz && hz > c.max_control_hz) why.push("control rate " + hz + " Hz above the device's " + c.max_control_hz + " Hz");
    }
    return why;
  }

  /* ---------------- the host: one per transport ---------------- */
  function Host(opts) {
    opts = opts || {};
    this.route = opts.route || "browser";
    this._send = opts.send;
    this.now = opts.now || function () { return Date.now(); };
    this.buf = new Uint8Array(0); this.discarding = false;
    this.stats = { lines: 0, unframed: 0, bad_crc: 0, too_long: 0, not_json: 0, link_errors: 0, telemetry: 0, sent: 0 };
    this.devHello = null; this.state = null; this.linkSession = null; this.leaseEpoch = 0; this.sessionOk = false; this.role = null;
    this.seq = 0; this.pending = {}; this.lastHb = 0; this.closed = false; this.heartbeats = opts.heartbeats !== false;
    this.handlers = {};
  }
  var H = Host.prototype;
  H.on = function (ev, fn) { (this.handlers[ev] = this.handlers[ev] || []).push(fn); return this; };
  H.emit = function (ev, a, b) { (this.handlers[ev] || []).slice().forEach(function (fn) { try { fn(a, b); } catch (e) { if (typeof console !== "undefined") console.error(e); } }); };
  H.sendBytes = function (bytes) { if (!this.closed && this._send) { this.stats.sent++; this._send(bytes); } };
  H.send = function (obj) { this.sendBytes(frame(obj)); };
  H.start = function () { this.send({ kind: "host_hello", versions: [1], host: this.route }); };
  H.openSession = function (epoch, sessionId) {
    this.linkSession = sessionId || ("ls-" + randomHex(10)); this.leaseEpoch = epoch | 0; this.seq = 0; this.sessionOk = false;
    this.send({ kind: "session", link_session: this.linkSession, lease_epoch: this.leaseEpoch });
    return this.linkSession;
  };
  H.setLeaseEpoch = function (epoch) {
    if (epoch > this.leaseEpoch && this.linkSession) { this.leaseEpoch = epoch | 0; this.send({ kind: "heartbeat", link_session: this.linkSession, lease_epoch: this.leaseEpoch }); }
  };
  /* one command, sent once. rawParamsText: a params object whose exact bytes matter (apply_config). */
  H.command = function (action, params, o) {
    o = o || {};
    if (!this.linkSession) throw new Error("no session on this link yet");
    var id = o.id || ("b-" + randomHex(8)), ttl = o.ttl_ms || 5000;
    this.seq += 1;
    var head = { kind: "cmd", id: id, v: 1, link_session: this.linkSession, lease_epoch: this.leaseEpoch, seq: this.seq, action: action, ttl_ms: ttl };
    if (o.config_hash) head.config_hash = o.config_hash;
    var text = JSON.stringify(head);
    if (o.rawParamsText != null) text = text.slice(0, -1) + ',"params":' + o.rawParamsText + "}";
    else if (params != null) text = text.slice(0, -1) + ',"params":' + JSON.stringify(params) + "}";
    var bytes = frameText(text);
    if (bytes.length > MAX_LINE) { this.seq -= 1; throw new Error("command too long for one link line (" + bytes.length + " bytes)"); }
    this.pending[id] = { id: id, action: action, deadline: this.now() + ttl + 2000, sent: this.now(), status: "sent", history: [{ status: "sent", t: this.now() }] };
    this.sendBytes(bytes);
    return id;
  };
  H.pairBegin = function (session, nonce) { this.send({ kind: "pair_begin", session: session, nonce: nonce }); };
  H.tlmResume = function (session, after) { this.send({ kind: "tlm_resume", session: session, after: after | 0 }); };
  H.receive = function (chunk) {
    var b = chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk);
    var nb = new Uint8Array(this.buf.length + b.length); nb.set(this.buf); nb.set(b, this.buf.length); this.buf = nb;
    for (;;) {
      var i = this.buf.indexOf(10);
      if (i < 0) { if (this.buf.length > MAX_LINE) { this.buf = new Uint8Array(0); this.discarding = true; } return; }
      var line = this.buf.subarray(0, i); this.buf = this.buf.slice(i + 1);
      if (this.discarding || line.length > MAX_LINE) { this.discarding = false; this.stats.too_long++; continue; }
      var end = line.length; if (end && line[end - 1] === 13) end--;
      this._line(line.subarray(0, end));
    }
  };
  H._line = function (line) {
    if (!line.length) return;
    this.stats.lines++;
    if (line.length < 10 || line[line.length - 9] !== 9) { this.stats.unframed++; return; }        // e.g. the chip's ROM boot text
    var js = line.subarray(0, line.length - 9), crcTxt = String.fromCharCode.apply(null, line.subarray(line.length - 8));
    if (!/^[0-9a-f]{8}$/.test(crcTxt) || parseInt(crcTxt, 16) !== crc32(js)) { this.stats.bad_crc++; return; }
    var msg;
    try { msg = JSON.parse(TD.decode(js)); } catch (e) { this.stats.not_json++; return; }
    if (!msg || typeof msg !== "object" || Array.isArray(msg)) { this.stats.not_json++; return; }
    if (msg.type && !msg.kind) { this.stats.telemetry++; this.emit("telemetry", msg); return; }
    var k = msg.kind;
    if (k === "dev_hello") { this.devHello = msg; this.emit("dev_hello", msg); }
    else if (k === "state") { this.state = msg; this.emit("state", msg); }
    else if (k === "session_ok") { if (msg.link_session === this.linkSession) { this.sessionOk = true; this.role = msg.role; } this.emit("event", k, msg); }
    else if (k === "cmd_ack" || k === "cmd_result") {
      var p = this.pending[msg.id];
      if (p) {
        p.status = msg.status; p.history.push({ status: msg.status, kind: k, reason: msg.reason || null, t: this.now() });
        if (msg.result !== undefined) p.result = msg.result;
        if (["completed", "failed", "rejected", "expired"].indexOf(msg.status) >= 0) p.final = true;
        else if (msg.status === "accepted" || msg.status === "executing") p.deadline = this.now() + 3600000;   // the device owns it now
      }
      this.emit("command", msg, p || null);
    }
    else if (k === "pair_ready" || k === "pair_proof" || k === "pair_rejected") this.emit("pairing", msg);
    else { if (k === "link_error") this.stats.link_errors++; if (k === "session_expired") this.sessionOk = false; this.emit("event", k, msg); }
  };
  H.tick = function () {
    var now = this.now(), self = this;
    if (this.heartbeats && this.linkSession && now - this.lastHb >= HEARTBEAT_MS) { this.lastHb = now; this.send({ kind: "heartbeat", link_session: this.linkSession, lease_epoch: this.leaseEpoch }); }
    Object.keys(this.pending).forEach(function (id) {
      var p = self.pending[id];
      if (!p.final && now > p.deadline) {
        p.final = true; p.status = "expired"; p.history.push({ status: "expired", kind: "host_timeout", reason: "no answer from the device before the command's ttl (never resent automatically)", t: now });
        self.emit("command", { kind: "host_timeout", id: id, status: "expired", reason: "no answer from the device before the command's ttl" }, p);
      }
    });
  };
  /* resolves with the final command record (or rejects on timeout); for UI flows and tests */
  H.waitFor = function (id, statuses, timeoutMs) {
    var self = this, want = statuses || ["completed", "failed", "rejected", "expired"];
    return new Promise(function (resolve, reject) {
      var p0 = self.pending[id]; if (p0 && want.indexOf(p0.status) >= 0) return resolve(p0);
      var t = setTimeout(function () { off(); reject(new Error("timed out waiting for " + id)); }, timeoutMs || 15000);
      function h(msg, p) { if (msg.id === id && p && want.indexOf(p.status) >= 0) { off(); clearTimeout(t); resolve(p); } }
      function off() { self.handlers.command = (self.handlers.command || []).filter(function (f) { return f !== h; }); }
      self.on("command", h);
    });
  };
  H.close = function () { this.closed = true; };

  /* the signed pairing statement (devices: link.c pair_proof; backend: linkhost.pair_message) */
  function pairMessage(p) { return "AERIS-PAIR-V1\n" + [p.session, p.nonce, p.device_id, p.pubkey, p.board_id, p.firmware].join("\n") + "\nlocal-confirmed"; }
  function b64uDecode(s) {
    s = String(s).replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "=";
    var bin = typeof atob !== "undefined" ? atob(s) : Buffer.from(s, "base64").toString("binary"), out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function b64uEncode(b) {
    var s = ""; for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
    var e = typeof btoa !== "undefined" ? btoa(s) : Buffer.from(s, "binary").toString("base64");
    return e.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  /* verify a pair_proof locally (noble P-256 / SHA-256; raw r||s) */
  function verifyPairProof(p, noble) {
    var N = noble || (typeof AERIS_NOBLE !== "undefined" ? AERIS_NOBLE : null);
    if (!N || !p || typeof p.sig !== "string" || typeof p.pubkey !== "string") return false;
    try {
      var msg = TE.encode(pairMessage(p)), h = N.sha256(msg);
      return N.p256.verify(b64uDecode(p.sig), h, b64uDecode(p.pubkey), { prehash: false, lowS: false });
    } catch (e) { return false; }
  }

  return { LINK: LINK, MAX_LINE: MAX_LINE, crc32: crc32, frame: frame, frameText: frameText, Host: Host, negotiate: negotiate, profileFits: profileFits,
    pairMessage: pairMessage, verifyPairProof: verifyPairProof, b64uDecode: b64uDecode, b64uEncode: b64uEncode, randomHex: randomHex, READ_ONLY: READ_ONLY };
})();
if (typeof module !== "undefined") module.exports = AERIS_LINK;

/* AERIS · on-demand scripts: the Build and Connect pages load their data, the synthetic device, the P-256 library and
   the flasher only when a visitor opens them, so the virtual cube's pages load nothing extra. Script tags also work
   for pages opened from a file (fetch does not). */
var AERIS_LAZY = (function () {
  "use strict";
  var done = {}, pending = {};
  function one(src) {
    if (done[src]) return Promise.resolve();
    if (pending[src]) return pending[src];
    pending[src] = new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = src; s.async = false;
      s.onload = function () { done[src] = true; delete pending[src]; resolve(); };
      s.onerror = function () { delete pending[src]; s.remove(); reject(new Error("could not load " + src)); };
      document.head.appendChild(s);
    });
    return pending[src];
  }
  function load(list) { return list.reduce(function (p, src) { return p.then(function () { return one(src); }); }, Promise.resolve()); }
  return { load: load, loaded: function (src) { return !!done[src]; } };
})();

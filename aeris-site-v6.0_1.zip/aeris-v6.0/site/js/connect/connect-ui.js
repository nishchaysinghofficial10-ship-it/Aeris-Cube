/* =====================================================================
   AERIS · CONNECT MY CUBE (#connect) — the device workflow in the browser:
   choose a device (the synthetic device, a USB port, or a device of your
   account on an AERIS backend), install firmware, pair, diagnose, calibrate,
   apply an approved configuration, self-test, run a supported experiment,
   record, simulate the same cube and compare.

   Provenance is always visible: the synthetic device is labelled SYNTHETIC
   everywhere; a board's "physical" is what it DECLARES (never verified); the
   attitude shown is the device's ESTIMATE; a simulation is a prediction.
   Nothing here can start the motors: experiments wait for ARM on the cube;
   the stop button is always available and needs no lease.

   The connect stack (link host, Web Serial, sessions, calibration, recorder,
   installer, synthetic device) and its data load the first time this page is
   opened (js/connect/lazy.js); the virtual cube's pages load none of it.
   ===================================================================== */
var ConnectPage = (function () {
  "use strict";
  var $ = U.$, esc = U.esc;
  var STACK = ["vendor/noble-p256-sha256.min.js", "js/connect/link.js", "js/connect/calib.js", "js/connect/serial.js", "js/connect/recorder.js",
    "js/connect/devapi.js", "js/connect/installer.js", "js/connect/session.js", "js/connect/synthetic.js", "data/aeris-data.js"];
  var WASM_JS = "firmware/synthetic/aeris-device.wasm.js", ESPTOOL = "vendor/esptool-js.min.js";
  var TABS = [["install", "Install"], ["pair", "Pair"], ["diagnostics", "Diagnostics"], ["calibrate", "Calibrate"], ["profile", "Profile"], ["configure", "Configure"], ["experiment", "Experiment"], ["record", "Record & compare"]];
  var FACES = ["+z", "-z", "+x", "-x", "+y", "-y"];
  /* #connect/<sub> → tab (the Build page's step links) */
  var SUB = { install: "install", pair: "pair", diagnostics: "diagnostics", calibrate: "calibrate", profile: "profile", configure: "configure", experiment: "experiment", simulate: "record", compare: "record", record: "record" };
  /* the value groups of a profile and where their values may come from (backend devices/schemas.py VALUE_SOURCES) */
  var VS = [["body", "Body: size, mass, inertia"], ["wheels", "Wheels: rotor inertia"], ["motor", "Motors"], ["imu.placement", "IMU placement"], ["imu.noise", "IMU noise"], ["electrical", "Electrical limits"]];
  var VS_OPTS = ["nominal-model", "datasheet", "estimated", "measured"];
  function freshMeas() { return { imu: null, axes: [], axisIds: {}, encoders: null, ids: {} }; }
  function freshLive() { return { t: [], lean: [], last: null, hello: null, mode: null }; }
  var S = { inited: false, ready: false, tab: "pair", drv: null, dev: null, transport: null, session: null, port: null, mode: null,
    api: null, apiStatus: null, apiError: null, devices: [], choice: { mode: "edge", via: false, allPorts: false },
    meas: freshMeas(), calibration: null, calRef: null, calErr: null, calFace: "+z", face: "+z", recipe: "edge-hold-10s", dur: "5", name: "My cube",
    config: null, diag: null, selftestCmd: null, exp: null, recorder: null, recorderLast: null, recordingOn: false, recording: null, sim: null, cmp: null,
    live: freshLive(), viewer: null, stageEl: null, sceneMode: null, built: null, loop: null, log: [], busy: false,
    install: { allowDev: false, release: null, progress: null, result: null }, history: [],
    prof: null, profCheck: null, profBad: null, profList: null, profSaved: null };

  /* ---------------- small helpers ---------------- */
  function chip(text, cls, title) { return '<span class="bdg ' + (cls || "") + '"' + (title ? ' title="' + esc(title) + '"' : "") + '><i aria-hidden="true"></i>' + esc(text) + "</span>"; }
  function sel(c) { return c ? " selected" : ""; }
  function chk(c) { return c ? " checked" : ""; }
  function off(c) { return c ? " disabled data-off" : ""; }          // disabled by the step's state (busy() keeps it disabled)
  function say(text, tone) { var el = $("cnStatus"); if (!el) return; el.className = "cn-status" + (tone ? " " + tone : ""); el.textContent = text || ""; }
  function log(dir, text) {
    S.log.push((dir || "·") + " " + text); if (S.log.length > 300) S.log.splice(0, S.log.length - 300);
    var el = $("cnLog"); if (el && el.closest("details").open) el.textContent = S.log.slice(-80).join("\n");
  }
  function errText(e) { return (e && (e.message || e.code)) || String(e); }
  function busy(on) {
    S.busy = !!on;
    [].forEach.call(document.querySelectorAll("#view-connect [data-act]"), function (b) { if (!b.hasAttribute("data-always")) b.disabled = S.busy || b.hasAttribute("data-off"); });
  }
  /* one user action: the page is busy until it settles; the outcome is said in the status line */
  function act(fn, okText) {
    var p; try { p = typeof fn === "function" ? fn() : fn; } catch (e) { p = Promise.reject(e); }
    busy(true);
    return Promise.resolve(p).then(function (v) {
      busy(false);
      var m = typeof okText === "function" ? okText(v) : okText;          // a text, or [text, tone] when the outcome decides the tone
      if (m) { if (Array.isArray(m)) say(m[0], m[1]); else say(m, "ok"); }
      render(); return v;
    },
      function (e) { busy(false); say(errText(e), "bad"); render(); });
  }
  function outcome(what) { return function (c) { var last = ((c && c.history) || []).slice(-1)[0] || {}; return [what + ": " + (c && c.status) + (c && c.status !== "completed" && last.reason ? " — " + last.reason : "") + ".", c && c.status === "completed" ? "ok" : "bad"]; }; }
  function download(name, text, type) {
    var b = new Blob([text], { type: type || "application/json" }), a = document.createElement("a");
    a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  function D() { return window.AERIS_DATA; }
  function kit() { return D().kits[0]; }
  function profRef() { return kit().profile; }
  function profKey() { return profRef().id + "@" + profRef().revision; }
  function profileDoc() { return D().profiles[profKey()]; }
  function refConfig(recipe) { return D().configs[profKey() + "/" + recipe]; }
  function recipeDoc(id) { var r = D().recipes[id]; return r ? r.document : null; }
  function recipesFor(mode) { return Object.keys(D().recipes).filter(function (k) { return !mode || recipeDoc(k).mode === mode; }); }
  function releaseBase() { var m = (kit().firmware || {}).manifest || ""; return m.slice(0, m.lastIndexOf("/")); }
  function storage() { return { get: AERIS_DEVSTORE.get, set: AERIS_DEVSTORE.set, remove: AERIS_DEVSTORE.remove }; }
  /* completed trials of a device paired with this browser (the corner recipe's prerequisite) */
  function localTrials(id) { return id ? AERIS_DEVSTORE.getJSON("trials." + id, []) : []; }
  function saveLocalTrial(id, t) { var l = localTrials(id); l.unshift(t); AERIS_DEVSTORE.setJSON("trials." + id, l.slice(0, 50)); }

  /* ---------------- backend ---------------- */
  function apiConfig() { var c = (window.AERIS_CONFIG || {}).researchApi || {}; return c.baseUrl && !c.mock ? { baseUrl: c.baseUrl, wsUrl: c.wsUrl } : null; }
  function api() { if (!S.api && apiConfig() && window.AERIS_DEVAPI) S.api = AERIS_DEVAPI.create({ baseUrl: apiConfig().baseUrl, wsUrl: apiConfig().wsUrl, token: AERIS_AUTH.token }); return S.api; }
  function probeBackend() {
    var a = api(); S.apiError = null;
    if (!a) { S.apiStatus = null; return Promise.resolve(null); }
    return a.status().then(function (st) {
      S.apiStatus = st;
      if (!st.auth || !st.auth.enabled || !AERIS_AUTH.describe(st).signedIn) { S.devices = []; return st; }
      return a.devices().then(function (r) { S.devices = (r && r.devices) || []; return st; }, function (e) { S.devices = []; S.apiError = errText(e); return st; });
    }, function (e) { S.apiStatus = { unreachable: true, error: errText(e) }; return null; });
  }
  function backendUsable() { var st = S.apiStatus; return !!(st && !st.unreachable && st.auth && st.auth.enabled && AERIS_AUTH.describe(st).signedIn); }

  /* ---------------- drivers: who is the link host ---------------- */
  /* Local: this page is the link host (USB or the synthetic device); pairing is with this browser */
  function LocalDriver(session) { this.s = session; this.kind = "local"; }
  LocalDriver.prototype = {
    hello: function () { return this.s.host.devHello; }, state: function () { return this.s.host.state; }, compat: function () { return this.s.compat; },
    paired: function () { return !!this.s.paired; }, pairedRecord: function () { return this.s.paired; },
    pair: function (name) { return this.s.pair(name); },
    run: function (action, params, o) { return this.s.run(action, params, o); },
    waitFinal: function (id, ms) { return this.s.host.waitFor(id, null, ms); },
    deviceId: function () { var h = this.hello(); return h && h.device_id; },
    synthetic: function () { var h = this.hello(); return !!(h && h.board && h.board.synthetic); },
    buildConfig: function (recipe) {
      var ref = refConfig(recipe);
      if (!ref) return Promise.reject(new Error("this site has no approved reference configuration for " + recipe));
      if (!S.calibration && !this.synthetic()) return Promise.reject(new Error("a physical device needs its own calibration first (Calibrate)"));
      var why = AERIS_LINK.profileFits(this.hello(), profileDoc().document, recipeDoc(recipe));
      if (why.length) return Promise.reject(new Error("this configuration does not fit the device: " + why.join("; ")));
      return Promise.resolve(AERIS_DEVSESSION.composeConfig(ref, S.calibration, S.calRef));
    },
    apply: function (built) { return this.s.applyConfig(built); },
    saveCalibration: function (doc) {
      var ref = { id: "LOCAL-CAL-" + AERIS_LINK.randomHex(4), hash: AERIS_DEVSESSION.sha256hex(AERIS_DEVSESSION.canonicalText(doc)) };
      AERIS_DEVSTORE.saveLocalCalibration(this.deviceId(), { ref: ref, document: doc, saved: new Date().toISOString() });
      return Promise.resolve(ref);
    },
    recStart: function (name) {
      S.recorder = new AERIS_DEVREC.Recorder(name, { transport: S.transport && S.transport.kind, profile: profRef(), calibration: S.calRef, recipe: S.recipe });
      if (this.s.tlmHello) S.recorder.feed(this.s.tlmHello);
      return Promise.resolve();
    },
    recStop: function () {
      var r = S.recorder; S.recorder = null; S.recorderLast = r;
      return Promise.resolve().then(function () { return { local: true, document: r.document(), ndjson: r.ndjson() }; });
    },
    close: function () {}
  };
  /* Port: a USB port without (answering) AERIS firmware — only the installer */
  function PortDriver(port) { this.port = port; this.kind = "port"; }
  PortDriver.prototype = {
    hello: function () { return null; }, state: function () { return null; }, compat: function () { return null; }, paired: function () { return false; }, pairedRecord: function () { return null; },
    deviceId: function () { return null; }, synthetic: function () { return false; },
    run: function () { return Promise.reject(new Error("no AERIS firmware answers on this port: install it first")); }, close: function () {}
  };
  /* Backend: the AERIS backend is the link host (companion, gateway, or this page relaying its port); your account */
  function BackendDriver(deviceId, relay) {
    var self = this;
    this.id = deviceId; this.relay = relay || null; this.kind = "backend"; this.holder = "web-" + AERIS_LINK.randomHex(8);
    this.view = null; this.ws = null; this.opening = false; this.unpairedHello = null; this.pairWait = null;
    if (relay) relay.on("control", function (m) { self.onControl(m); });
  }
  BackendDriver.prototype = {
    hello: function () { return (this.view && this.view.dev_hello) || null; }, state: function () { return this.view && this.view.state; }, compat: function () { return this.view && this.view.compat; },
    paired: function () { return !!this.view; }, pairedRecord: function () { return this.view; },
    deviceId: function () { return this.id; },
    synthetic: function () { var h = this.hello() || this.unpairedHello; return !!((this.view && this.view.synthetic) || (h && h.board && h.board.synthetic)); },
    refresh: function () { var self = this; return api().device(this.id).then(function (v) { self.view = v; return v; }); },
    onControl: function (m) {
      var self = this;
      if (m.type === "pairing" && this.pairWait) this.pairWait(m);
      else if (m.type === "device") {
        this.id = m.device_id;
        if (m.paired_to_you) { this.unpairedHello = null; this.refresh().then(function () { self.openLive(); render(); }, function (e) { log("!", errText(e)); }); }
        else { this.view = null; this.unpairedHello = m.dev_hello; render(); }
      } else if (m.type === "error") log("!", m.error || m.code);
    },
    pair: function (name) {
      var self = this;
      if (!this.relay) return Promise.reject(new Error("pairing needs the cube's USB port: connect it on this page (through the backend) or with the companion program"));
      return new Promise(function (resolve, reject) {
        var t = setTimeout(function () { self.pairWait = null; reject(new Error("no pairing answer within 40 s")); }, 40000);
        self.pairWait = function (m) {
          if (m.status === "waiting_for_local_confirmation") say("Press ARM on the cube to confirm the pairing.", "warn");
          else if (m.status === "paired") { clearTimeout(t); self.pairWait = null; self.id = m.device.id; self.refresh().then(function () { self.openLive(); resolve(self.view); }, reject); }
          else if (m.status === "failed") { clearTimeout(t); self.pairWait = null; reject(new Error(m.reason || "pairing failed")); }
        };
        self.relay.pair(name);
      });
    },
    lease: function () {
      return api().lease(this.id, this.holder, false).catch(function (e) { throw new Error(e.code === "lease_held" ? "another window or person holds this device's control lease: " + e.message : errText(e)); });
    },
    run: function (action, params, o) {
      o = o || {}; var self = this;
      var body = { action: action, params: params || null, ttl_ms: o.ttl_ms || 5000, holder: this.holder, config_hash: o.config_hash || null };
      var pre = action === "stop" || action === "diagnostics" ? Promise.resolve() : this.lease();          // stop never needs the lease
      return pre.then(function () { return api().command(self.id, body); }).then(function (c) {
        return api().waitCommand(c.id, o.until, o.waitMs || (o.ttl_ms || 5000) + 60000);
      }).then(function (c) { return { id: c.id, status: c.status, result: c.result, history: c.history }; });
    },
    waitFinal: function (id, ms) { return api().waitCommand(id, null, ms).then(function (c) { return { id: c.id, status: c.status, result: c.result, history: c.history }; }); },
    buildConfig: function (recipe) {
      return api().buildConfig(this.id, { recipe: recipe, calibration: S.calRef ? S.calRef.id : null }).then(function (d) {
        return { hash: d.id, text: d.text, config: d.config, profile: d.profile, recipe: d.recipe, calibration: d.calibration, composed: "built by the AERIS backend for this device" };
      });
    },
    apply: function (built) { return this.run("apply_config", null, { config_hash: built.hash }); },
    saveCalibration: function () {
      var ids = S.meas.ids;
      return api().createCalibration(this.id, { commands: { imu: ids.imu, axes: ids.axes, encoders: ids.encoders || null } }).then(function (c) { S.calibration = c.document; return { id: c.id, hash: c.hash }; });
    },
    recStart: function (name) { return api().recordingStart(this.id, name); },
    recStop: function () { return api().recordingStop(this.id).then(function (r) { return { local: false, stored: r }; }); },
    openLive: function () {
      var self = this;
      if (this.ws || this.opening) return;
      this.opening = true;
      api().liveSocket(this.id).then(function (ws) {
        self.opening = false; self.ws = ws;
        ws.onmessage = function (ev) {
          var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
          if (m.type === "device") { self.view = m.device; liveMode(m.device && m.device.telemetry); render(); }
          else if (m.type === "state") { if (self.view) self.view.state = m.state; onState(m.state); }
          else if (m.type === "frames") (m.frames || []).forEach(onFrame);
          else if (m.type === "status") { if (self.view) { self.view.connected = m.connected; self.view.routes = m.routes; if (m.state) self.view.state = m.state; } liveMode(m.telemetry); updateHeader(); }
          else if (m.type === "route") self.refresh().then(render, function () {});
          else if (m.type === "command") log("←", "command " + m.id + " " + m.status);
          else if (m.type === "event") log("←", eventText(m.event));
        };
        ws.onclose = function () { self.ws = null; };
      }, function (e) { self.opening = false; log("!", "live view: " + errText(e)); });
    },
    close: function () { try { if (this.ws) this.ws.close(); } catch (e) { /* ignore */ } this.ws = null; }
  };
  /* a backend event in one line; a telemetry catch-up (the stream continued on another route or after a reconnection)
     says what the device resent and what it no longer held (docs/DEVICE_LINK.md §7) */
  function eventText(e) {
    if (!e) return "event";
    var m = e.message || {};
    if (e.kind === "tlm_catchup") {
      if (m.status === "requested") return "telemetry continues on the " + e.route + " route: asking the device for the frames after " + m.after;
      return "telemetry catch-up " + (m.status === "done" ? "complete" : "ended (" + (m.reason || m.ended) + ")") + ": " + m.recovered + " frame(s) recovered" +
        (m.missing ? ", " + m.missing + " no longer held by the device (recorded as a gap)" : "");
    }
    return e.kind + (m.reason ? " · " + m.reason : "");
  }
  function liveMode(tlm) { if (tlm && tlm.hello && tlm.hello.mode) S.live.mode = tlm.hello.mode; }

  /* ---------------- connecting ---------------- */
  function resetDeviceState() {
    S.meas = freshMeas(); S.calibration = null; S.calRef = null; S.calErr = null; S.config = null; S.diag = null; S.selftestCmd = null; S.exp = null;
    S.recorder = null; S.recorderLast = null; S.recordingOn = false; S.recording = null; S.sim = null; S.cmp = null; S.live = freshLive(); S.tab = "pair"; S.history = [];
    S.install.progress = null; S.install.result = null;
  }
  function wire(sess) {
    sess.on("state", onState);
    sess.on("telemetry", function (m) { if (m.type === "hello") { S.live.hello = m; if (m.mode) S.live.mode = m.mode; } else if (m.type === "frame") onFrame(m); if (S.recorder) S.recorder.feed(m); });
    sess.on("dev_hello", function () { render(); });
    sess.on("sent", function (c) { log("→", c.action + " " + c.id); });
    sess.on("command", function (m) { log("←", (m.kind || "") + " " + m.id + " " + m.status + (m.reason ? " · " + m.reason : "")); });
    sess.on("event", function (k, m) { log("←", k + (m && m.reason ? " · " + m.reason : "")); });
    sess.on("closed", function (why) { if (S.session === sess) { say("Connection closed: " + why, "bad"); disconnect(); } });
    sess.on("pair_wait", function () { say("Press ARM on the cube within 30 s to confirm the pairing.", "warn"); });
  }
  function startLoop() {
    var last = performance.now();
    if (S.loop) clearInterval(S.loop);
    S.loop = setInterval(function () {
      var now = performance.now(), dt = Math.min(50, now - last); last = now;
      /* the synthetic device's time follows the page's clock, at most 50 ms per step: when the page stalls (or a background
         tab is throttled) the device's time slows down with it instead of jumping past the link's heartbeats */
      if (S.dev) S.dev.advance(dt * 1000);
      updateLive();
    }, 10);
  }
  function connectSynthetic(mode, viaBackend) {
    resetDeviceState();
    say("Starting the synthetic device…");
    return AERIS_LAZY.load([WASM_JS]).then(function () {
      var bin = atob(window.AERIS_SYNTH_WASM_B64), bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      var tr = null;
      return AERIS_SYNTH.create({ wasm: bytes, plant: D().plants[mode], deviceId: "synthetic-web-" + mode, storage: storage(),
        onOut: function (link, b) { if (tr) tr.deliver(b); }, onLog: function (l, m) { log("dev", m); } }).then(function (dev) {
        S.dev = dev; S.mode = mode; S.live.mode = mode; S.recipe = recipesFor(mode)[0] || S.recipe;
        tr = new AERIS_SYNTH.Transport(dev, AERIS_SYNTH.USB); S.transport = tr;
        startLoop();
        return open(tr, viaBackend);
      });
    });
  }
  function connectSerial(viaBackend) {
    var sup = AERIS_SERIAL.support();
    if (!sup.ok) return Promise.reject(new Error(sup.reason));
    /* requestPort needs this click's user activation: ask before anything asynchronous */
    return AERIS_SERIAL.choose(!S.choice.allPorts).then(function (port) {
      resetDeviceState(); S.mode = null;
      S.port = port; var tr = new AERIS_SERIAL.Transport(port); S.transport = tr; startLoop();
      return open(tr, viaBackend).catch(function (e) {
        if (viaBackend || !/introduce itself/.test(errText(e))) throw e;
        /* nothing answered in the AERIS protocol: a new board, or other firmware — offer the installer on this port */
        var s = S.session; S.session = null;
        return Promise.resolve(s && s.close()).catch(function () {}).then(function () {
          S.drv = new PortDriver(port); S.tab = "install"; S.transport = null;
          say("No AERIS firmware answered on this port (a new board, or other firmware). You can install the AERIS firmware.", "warn");
        });
      });
    }, function (e) { throw new Error(e && e.name === "NotFoundError" ? "No port was chosen." : errText(e)); });
  }
  function open(tr, viaBackend) {
    if (viaBackend) {
      var relay = new AERIS_DEVSESSION.Relay(tr, api(), {});
      S.session = relay;
      relay.on("control", function (m) { log("bk", JSON.stringify(m).slice(0, 240)); });
      relay.on("closed", function (why) { if (S.session === relay) { say("Relay closed: " + why, "bad"); disconnect(); } });
      return relay.start().then(function (m) {
        var d = new BackendDriver(m.device_id, relay); S.drv = d;
        d.onControl(m);                                        // the first "device" message arrived before this driver existed
        S.tab = m.paired_to_you ? "diagnostics" : "pair";
        say(m.paired_to_you ? "Connected through your AERIS backend." : "Connected through your AERIS backend. This device is not paired with your account yet.", m.paired_to_you ? "ok" : "warn");
      });
    }
    var sess = new AERIS_DEVSESSION.Local(tr, { store: AERIS_DEVSTORE });
    S.session = sess; wire(sess);
    return sess.start().then(function () {
      S.drv = new LocalDriver(sess);
      var c = sess.compat;
      say(c && c.supported ? "Connected." + (sess.paired ? " Paired with this browser." : " Pair it to continue.") : "Connected read-only: " + (c ? c.reasons.join("; ") : "unknown device"), c && c.supported ? "ok" : "warn");
      S.tab = sess.paired ? "diagnostics" : "pair";
    });
  }
  function openBackendDevice(id) {
    resetDeviceState(); S.mode = null;
    var d = new BackendDriver(id, null);
    return d.refresh().then(function () {
      S.drv = d; S.session = null; S.transport = null; S.dev = null;
      liveMode(d.view && d.view.telemetry); d.openLive(); startLoop(); S.tab = "diagnostics";
      say("Opened " + (d.view.name || id) + " through your AERIS backend.", "ok");
    });
  }
  function disconnect() {
    if (S.loop) { clearInterval(S.loop); S.loop = null; }
    if (S.dev) S.dev.saveNvs();
    var s = S.session, d = S.drv;
    S.session = null; S.drv = null; S.dev = null; S.transport = null; S.port = null;
    if (d && d.close) d.close();
    render();
    return s ? Promise.resolve().then(function () { return s.close(); }).catch(function () {}) : Promise.resolve();
  }

  /* ---------------- live state ---------------- */
  function onState(st) {
    if (st && st.mode) S.live.mode = st.mode;
    updateHeader();
    if (S.tab === "experiment" || S.tab === "configure" || S.tab === "install") renderPanelSoon();
  }
  var panelTimer = null;
  function renderPanelSoon() { if (panelTimer) return; panelTimer = setTimeout(function () { panelTimer = null; renderPanel(); }, 150); }
  /* lean of the centre of mass from the vertical through the support, from the device's estimate q (body → world):
     the COM lies along (0, ½√2, ½√2) from the edge, along (1, 1, 1)/√3 from the corner (AERIS body frame) */
  function leanDeg(q, mode) {
    if (!q || q.length !== 4) return NaN;
    var u = mode === "corner" ? [1 / Math.sqrt(3), 1 / Math.sqrt(3), 1 / Math.sqrt(3)] : [0, Math.SQRT1_2, Math.SQRT1_2];
    var w = q[0], x = q[1], y = q[2], z = q[3];
    var zr = [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)];     // third row of R(q): the world-z component of a body vector
    var c = zr[0] * u[0] + zr[1] * u[1] + zr[2] * u[2];
    return Math.acos(Math.max(-1, Math.min(1, c))) * 180 / Math.PI;
  }
  function onFrame(f) {
    var L = S.live, mode = f.mode || L.mode || "edge";
    var t = typeof f.t === "number" ? f.t : (L.t.length ? L.t[L.t.length - 1] + 0.02 : 0);
    if (L.t.length && t < L.t[L.t.length - 1]) { L.t = []; L.lean = []; }
    L.t.push(t); L.lean.push(leanDeg(f.q, mode));
    while (L.t.length > 2 && L.t[L.t.length - 1] - L.t[0] > 12) { L.t.shift(); L.lean.shift(); }
    L.last = f; L.mode = mode;
  }
  function quatR(q) { var w = q[0], x = q[1], y = q[2], z = q[3]; return [[1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)], [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)], [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]]; }
  var lastDraw = 0;
  function updateLive() {
    var now = performance.now(); if (now - lastDraw < 100) return; lastDraw = now;
    var v = $("view-connect"); if (!v || v.hidden || !S.drv) return;
    var L = S.live, f = L.last, el = $("cnLiveVals"), lean = L.lean[L.lean.length - 1];
    if (el) el.innerHTML = f ? '<div><span>Lean from the support</span><b>' + (isFinite(lean) ? lean.toFixed(2) + "°" : "—") + "</b></div><div><span>Wheel speeds</span><b>" +
      (f.wheel_rpm ? f.wheel_rpm.map(function (x) { return (+x).toFixed(0); }).join(" · ") + " rpm" : "not reported") + "</b></div><div><span>Status · frame</span><b>" + esc(f.status || "—") + " · " + esc(String(f.seq)) + "</b></div>"
      : '<p class="small dim">No telemetry yet: the device streams it once an approved configuration is applied.</p>';
    var cv = $("cnLiveChart"), synth = S.drv.synthetic(), note = $("cnStageNote");
    if (note) note.textContent = f && f.q ? "device estimate · t = " + (+f.t).toFixed(1) + " s" : "no estimate yet";
    if (cv) cv.hidden = L.t.length < 2;
    if (cv && L.t.length > 1 && window.Chart) Chart.line(cv, { xlim: [L.t[L.t.length - 1] - 10, L.t[L.t.length - 1]], ylabel: "lean from the support (°, device estimate)", xlabel: "device time (s)", yzero: true,
      series: [{ x: L.t, y: L.lean, color: synth ? "#d1d5dc" : "#45d4ee", width: 2 }] });
    if (S.viewer && f && f.q) { ensureScene(); S.viewer.setPose({ R: quatR(f.q), wheelAngles: [0, 0, 0], loads: [] }); }
    var tn = $("cnTiltNow"); if (tn) tn.textContent = tiltText(recipeDoc(S.recipe));
    if (S.dev) {
      var tr = $("cnTruth");
      if (tr) tr.textContent = "The model's true state (synthetic only, never telemetry): " + S.dev.tiltDeg().toFixed(2) + "° from balance · " + (S.dev.held() ? (S.dev.posed() ? "resting on a face" : "held by your hand") : "free") +
        (S.dev.caught() ? " · caught by the fixture" : "") + " · motor power " + (S.dev.motorPower() ? "on" : "off");
    }
    updateHeader();
  }
  function stage() {
    if (!S.stageEl) {
      var el = document.createElement("div");
      el.className = "cn-stage"; el.setAttribute("role", "img"); el.setAttribute("aria-label", "3-D view of the cube at the attitude the device estimates");
      el.innerHTML = '<canvas></canvas><div class="ovl tl" id="cnStageNote">no estimate yet</div>';
      S.stageEl = el;
    }
    return S.stageEl;
  }
  function ensureViewer() {
    if (S.viewer || !window.AerisViewer) return;
    try { S.viewer = new AerisViewer(stage(), {}); } catch (e) { S.viewer = null; log("!", "3-D view unavailable: " + errText(e)); }
  }
  function ensureScene() {
    var mode = S.live.mode || S.mode || "edge"; if (!S.viewer || S.sceneMode === mode) return;
    var b = profileDoc().document.body, a = b.edge_m;
    S.sceneMode = mode;
    S.viewer.setScene({ mode: mode, a: a, com_m: b.com_m || [a / 2, a / 2, a / 2], attachments: [], loads: [], showMarkers: false });
  }

  /* ---------------- rendering ---------------- */
  function provenance(d) {
    var h = d.hello() || d.unpairedHello;
    if (d.kind === "port") return chip("USB port · no AERIS firmware answered", "cl-pending");
    if (!h) return "";
    if (h.board && h.board.synthetic) return chip("Synthetic device — not a cube", "mk-mock", "the firmware core running against models in this browser or a test process");
    if (h.board && h.board.kind === "physical") return chip("Declared physical — not verified", "src-hw", "the board says it is physical; the software cannot verify that");
    return chip("Kind: " + ((h.board && h.board.kind) || "undeclared"), "cl-pending");
  }
  function statusStrip() {
    if (!window.AERIS_STATUS) return;
    var d = S.drv, h = d && (d.hello() || d.unpairedHello);
    var src = !h ? "telemetry-none" : h.board && h.board.kind === "physical" && !h.board.synthetic ? "telemetry-declared" : "telemetry-synthetic";
    AERIS_STATUS.update("connect", { source: src, controller: S.config && recipeDoc(S.recipe) ? recipeDoc(S.recipe).name : null, experiment: h ? "device " + h.device_id : null });
  }
  var lastHead = "";
  function updateHeader() {
    var el = $("cnStateLine"); if (!el || !S.drv) return;
    var st = S.drv.state() || {}, faults = st.faults || [], latched = st.latched || [], w = st.waiting, ex = st.experiment;
    var html = '<span class="cn-state st-' + esc(String(st.state || "unknown").toLowerCase()) + '">' + esc(st.state || (S.drv.kind === "port" ? "no AERIS firmware" : "—")) + "</span>" +
      (st.reason ? '<span class="small">' + esc(st.reason) + "</span>" : "") +
      (st.task ? '<span class="small dim">task: ' + esc(st.task) + "</span>" : "") +
      (faults.length ? '<span class="cn-faults">Faults: ' + esc(faults.join(", ")) + "</span>" : "") +
      (latched.length ? '<span class="cn-faults">Latched: ' + esc(latched.join(", ")) + "</span>" : "") +
      (w ? '<span class="cn-wait">Waiting: ' + esc(w.local_action || w.kind) + " on the cube" + (w.remaining_ms != null ? " · " + Math.ceil(w.remaining_ms / 1000) + " s left" : "") + "</span>" : "") +
      (ex ? '<span class="small">Experiment ' + esc(ex.recipe || "") + " · " + (+ex.elapsed_s || 0).toFixed(1) + " s" + (ex.remaining_s != null ? " · " + (+ex.remaining_s).toFixed(1) + " s left" : "") + (ex.ending ? " · " + esc(ex.ending) : "") + "</span>" : "") +
      (st.state === "FAULT" && !faults.length && latched.length ? '<button type="button" class="act" data-act="clear">Clear faults (hold ARM 2 s)</button>' : "");
    if (html !== lastHead) { el.innerHTML = html; lastHead = html; }
  }
  function renderChoose() {
    var sup = AERIS_SERIAL.support(), st = S.apiStatus, au = st && !st.unreachable && st.auth ? AERIS_AUTH.describe(st) : null, viaOk = backendUsable(), C = S.choice;
    var html = '<div class="cn-card"><h3>Synthetic device</h3><p class="small">The AERIS firmware core with models of the IMU, the three wheel drivers and the cube, running in this page. Try every step without hardware. It is <b>not</b> a cube: everything it reports is synthetic.</p>' +
      '<div class="cn-row"><label for="cnSynMode" class="small">Plant</label><select id="cnSynMode"><option value="edge"' + sel(C.mode === "edge") + '>edge</option><option value="corner"' + sel(C.mode === "corner") + ">corner</option></select>" +
      '<button type="button" class="btn btn-sm btn-solid" data-act="syn">Start the synthetic device</button></div></div>';
    html += '<div class="cn-card"><h3>USB (Web Serial)</h3>' + (sup.ok
      ? '<p class="small">Connect the controller board\'s ESP32-S3 USB port with a data cable, then choose the port. You choose it yourself; the page never opens a port on its own. A board without AERIS firmware is offered the installer.</p><div class="cn-row"><label class="small"><input type="checkbox" id="cnAllPorts"' + chk(C.allPorts) + '> show all ports</label><button type="button" class="btn btn-sm" data-act="serial">Choose a USB port</button></div>'
      : '<p class="small">' + esc(sup.reason) + '</p><p class="small">The companion program relays the port to an AERIS backend on this computer: <code>python -m aeris_backend.companion --backend http://127.0.0.1:8750 --serial /dev/ttyACM0 --pair</code> (backend/README.md); then open this page from that backend.</p>') + "</div>";
    html += '<div class="cn-card"><h3>Your AERIS backend</h3>';
    if (!apiConfig()) html += '<p class="small">No backend is configured for this page: pairing stays with this browser, and Simulate My Cube and comparisons are not available. Start one with <code>scripts/start.sh</code> and open the page it serves.</p>';
    else if (!st || st.unreachable) html += '<p class="small">Configured (' + esc(apiConfig().baseUrl) + ") but not reachable" + (st && st.error ? ": " + esc(st.error) : "") + '.</p><button type="button" class="btn btn-sm" data-act="probe" data-always>Check again</button>';
    else if (!st.auth || !st.auth.enabled) html += '<p class="small">The device API is disabled on this backend' + (st.auth && st.auth.problem ? ": " + esc(st.auth.problem) : "") + ".</p>";
    else {
      html += '<p class="small">' + esc(au.text) + "</p>";
      if (!au.signedIn && au.devFixture && AERIS_AUTH.loopback()) html += '<div class="cn-row"><label for="cnDevTok" class="small">Development token</label><input id="cnDevTok" type="password" autocomplete="off" spellcheck="false"><button type="button" class="btn btn-sm" data-act="devtok" data-always>Use</button></div><p class="small dim">From <code>python -m aeris_backend.tools.devauth token --sub you</code> — this computer only.</p>';
      if (!au.signedIn && au.canSignIn) html += '<button type="button" class="btn btn-sm" data-act="signin" data-always>Sign in</button>';
      if (au.signedIn && au.mode === "jwt") html += '<button type="button" class="btn btn-sm" data-act="signout" data-always>Sign out</button>';
      if (au.signedIn) {
        if (S.apiError) html += '<div class="cn-out bad">' + esc(S.apiError) + "</div>";
        html += '<p class="small">Your devices:</p>' + (S.devices.length ? '<ul class="cn-devs">' + S.devices.map(function (d) {
          return "<li><span>" + esc(d.name || d.id) + " " + (d.synthetic ? chip("synthetic", "mk-mock") : chip("declared physical", "src-hw")) + (d.connected ? chip("connected", "cl-ok") : chip("not connected", "cl-pending")) +
            '</span><button type="button" class="btn btn-sm" data-act="open-dev" data-id="' + esc(d.id) + '">Open</button></li>';
        }).join("") + "</ul>" : '<p class="small dim">None paired yet. Pair one over USB: on this page with the option below, or with the companion program.</p>');
        html += '<label class="small cn-via"><input type="checkbox" id="cnVia"' + chk(C.via && viaOk) + (viaOk ? "" : " disabled") + "> Connect the synthetic device or a USB port <b>through</b> this backend (pairing with your account; the backend is the link host)</label>";
      }
    }
    $("cnChoose").innerHTML = html + "</div>";
  }
  function renderEnv() {
    $("cnEnv").innerHTML = '<table class="spec"><thead><tr><th scope="col">Path</th><th scope="col">Implemented</th><th scope="col">Tested</th></tr></thead><tbody>' +
      '<tr><th scope="row">Synthetic device in the browser</th><td>Yes</td><td>Node and Chromium (this repository\'s tests)</td></tr>' +
      '<tr><th scope="row">USB in the browser (Web Serial)</th><td>Yes: desktop Chrome or Edge, on a secure page</td><td>Chromium with a scripted serial port standing in for the board; never with a physical board</td></tr>' +
      '<tr><th scope="row">Companion program (any browser)</th><td>Yes</td><td>With the synthetic device process</td></tr>' +
      '<tr><th scope="row">Wi-Fi (the cube connects out to the backend)</th><td>Yes: the backend gateway and the firmware\'s client</td><td>The backend with the synthetic device through a test bridge; the board\'s own Wi-Fi client is built but untested on hardware</td></tr>' +
      '<tr><th scope="row">Firmware installer</th><td>Yes (esptool-js)</td><td>Release checks and a scripted flasher; never written to a board</td></tr></tbody></table>' +
      '<p class="small dim cn-env-note">Physical balancing, timing on the board and electrical or mechanical safety are not tested: no AERIS reference cube has been built (<a href="#build">Build</a>).</p>';
  }
  function tabsFor(d) { return d && d.kind === "port" ? TABS.slice(0, 1) : TABS.filter(function (t) { return t[0] !== "install" || (S.transport && S.transport.kind === "web-serial"); }); }
  function hands() {
    return '<div class="card cn-hands"><div class="card-h"><span class="label">The synthetic cube\'s hands</span>' + chip("synthetic", "mk-mock") + '</div><div class="cn-ops">' +
      '<button type="button" class="btn btn-sm btn-solid" data-act="op-arm" data-always>Press ARM</button><button type="button" class="btn btn-sm" data-act="op-armhold" data-always>Hold ARM 2 s</button>' +
      '<button type="button" class="btn btn-sm" data-act="op-estop" data-always aria-pressed="false" id="cnEstop">Emergency stop</button>' +
      '<span class="cn-face"><label for="cnFace" class="small">Rest on face</label><select id="cnFace">' + FACES.map(function (f) { return "<option" + sel(f === S.face) + ">" + f + "</option>"; }).join("") + '</select><button type="button" class="btn btn-sm" data-act="op-face" data-always>Rest</button></span>' +
      '<button type="button" class="btn btn-sm" data-act="op-hold" data-always>Hold at the start position</button><button type="button" class="btn btn-sm" data-act="op-spin" data-always>Turn the wheels by hand</button><button type="button" class="btn btn-sm" data-act="op-push" data-always>Push</button></div>' +
      '<p class="small dim cn-truth" id="cnTruth"></p></div>';
  }
  function buildSkeleton(d) {
    S.built = d;
    $("cnDevice").innerHTML =
      '<div class="cn-dev-h"><div class="cn-id" id="cnIdent"></div><div class="cn-dev-btns">' + (d.kind === "port" ? "" : '<button type="button" class="btn btn-sm cn-stop" data-act="stop" data-always title="Always accepted by the device; needs no lease">Stop</button>') +
      '<button type="button" class="btn btn-sm" data-act="disconnect" data-always>Disconnect</button></div></div>' +
      '<div class="cn-grid"><div class="cn-main"><div class="cn-tabs" role="tablist" aria-label="Device steps" id="cnTabs"></div><div id="cnPanel" role="tabpanel" class="cn-panel" tabindex="0"></div></div>' +
      '<aside class="cn-side" aria-label="Live view"><div class="card"><div class="card-h"><span class="label">Live · estimated by the device</span></div><div id="cnStageSlot" class="cn-stage-slot"></div><div class="cn-vals" id="cnLiveVals"></div>' +
      '<canvas id="cnLiveChart" class="cn-chart" width="600" height="230" role="img" aria-label="Lean from the support estimated by the device, last 10 s"></canvas><div class="card-f">The attitude is the device\'s own estimate, not ground truth.</div></div>' +
      (S.dev ? hands() : "") +
      '<details class="card cn-adv"><summary class="card-h"><span class="label">Advanced: link messages</span></summary><pre id="cnLog" class="code-block"></pre></details></aside></div>';
    $("cnStageSlot").appendChild(stage());
    ensureViewer(); S.sceneMode = null;
  }
  function renderIdent(d) {
    var h = d.hello() || d.unpairedHello || {}, c = d.compat() || (h.link ? AERIS_LINK.negotiate(h) : null), rec = d.pairedRecord();
    var via = d.kind === "backend" ? "via your backend (" + ((((d.view && d.view.routes) || []).join(", ")) || "not connected now") + ")" : d.kind === "port" ? "USB (Web Serial)" : "via " + (S.transport ? S.transport.label : "");
    $("cnIdent").innerHTML = '<div class="cn-name"><b>' + esc((rec && rec.name) || h.device_id || d.deviceId() || (d.kind === "port" ? "USB port" : "device")) + "</b> " + provenance(d) + "</div>" +
      (d.kind === "port" ? "" : '<div class="small dim mono cn-meta">' + esc(h.device_id || d.deviceId() || "") + " · board " + esc((h.board && h.board.id) || "?") + " · firmware " + esc((h.fw && h.fw.version) || "?") + " (" + esc((h.fw && h.fw.build) || "?") + ")</div>") +
      '<div class="small dim">' + esc(via) + "</div>" +
      (c ? '<div class="small">' + (c.supported ? "Supported: " + esc((c.controllers || []).join(", ") || "no controllers") + (c.note ? " · " + esc(c.note) : "") : "Read-only: " + esc((c.reasons || []).join("; "))) + "</div>" : "") +
      '<div id="cnStateLine" class="cn-stateline"></div>';
    lastHead = "";
  }
  function renderTabs(d) {
    var tabs = tabsFor(d);
    if (!tabs.some(function (t) { return t[0] === S.tab; })) S.tab = tabs[0][0];
    $("cnTabs").innerHTML = tabs.map(function (t) { var on = t[0] === S.tab; return '<button type="button" role="tab" id="cnTab-' + t[0] + '" aria-controls="cnPanel" aria-selected="' + on + '" tabindex="' + (on ? 0 : -1) + '" data-act="tab" data-tab="' + t[0] + '" data-always>' + esc(t[1]) + "</button>"; }).join("");
    $("cnPanel").setAttribute("aria-labelledby", "cnTab-" + S.tab);
  }
  function renderDevice() {
    var sec = $("connect-device"), d = S.drv;
    sec.hidden = !d;
    if (!d) { if (S.built) { if (S.stageEl && S.stageEl.parentNode) S.stageEl.parentNode.removeChild(S.stageEl); $("cnDevice").innerHTML = ""; S.built = null; } return; }
    if (S.built !== d) buildSkeleton(d);
    renderIdent(d); renderTabs(d); updateHeader(); renderPanel();
  }
  function selectTab(tab, focus) {
    S.tab = tab; renderTabs(S.drv); renderPanel();
    if (focus) { var t = $("cnTab-" + tab); if (t) t.focus(); }
  }
  function stepList(items) {
    return '<ol class="cn-checks">' + items.map(function (x) { var c = x[0] === null ? "maybe" : x[0] ? "ok" : "no"; return '<li class="' + c + '"><span aria-hidden="true">' + (c === "ok" ? "✓" : c === "maybe" ? "?" : "○") + '</span><span class="sr">' + (c === "ok" ? "done: " : c === "maybe" ? "checked later: " : "not yet: ") + "</span>" + esc(x[1]) + "</li>"; }).join("") + "</ol>";
  }
  function cmdOut(c) {
    if (!c) return "";
    var last = (c.history || [])[(c.history || []).length - 1] || {};
    return '<div class="cn-out ' + (c.status === "completed" ? "ok" : c.status === "executing" || c.status === "accepted" ? "" : "bad") + '"><b>' + esc(c.status) + "</b> " + esc(last.reason || "") +
      (c.result ? '<details><summary>The device\'s result</summary><pre class="code-block">' + esc(JSON.stringify(c.result, null, 1)) + "</pre></details>" : "") + "</div>";
  }
  function renderPanel() {
    var p = $("cnPanel"), d = S.drv; if (!p || !d) return;
    var a = document.activeElement, keep = a && p.contains(a) && a.id ? { id: a.id, s: a.selectionStart, e: a.selectionEnd } : null;
    var h = d.hello() || {}, st = d.state() || {}, html = "";
    if (S.tab === "install") html = panelInstall(d);
    else if (S.tab === "pair") html = panelPair(d, h);
    else if (S.tab === "diagnostics") html = '<p class="small">Identify blinks the board\'s LED; diagnostics read the IMU, the wheel drivers, the control loop, the estimator and the links. Nothing moves.</p><div class="cn-row"><button type="button" class="btn btn-sm" data-act="identify">Identify</button><button type="button" class="btn btn-sm btn-solid" data-act="diag">Run diagnostics</button></div>' + (S.diag ? diagSummary(S.diag) + cmdOut(S.diag) : "");
    else if (S.tab === "calibrate") html = panelCalibrate(d);
    else if (S.tab === "profile") html = panelProfile(d);
    else if (S.tab === "configure") html = panelConfigure(d, st);
    else if (S.tab === "experiment") html = panelExperiment(d, st);
    else if (S.tab === "record") html = panelRecord(d);
    p.innerHTML = html;
    busy(S.busy);
    if (keep) { var el = $(keep.id); if (el) { try { el.focus({ preventScroll: true }); if (keep.s != null && el.setSelectionRange) el.setSelectionRange(keep.s, keep.e); } catch (e) { /* not a text field */ } } }
  }
  function panelPair(d, h) {
    if (d.kind === "local") {
      var rec = d.pairedRecord();
      if (rec) return '<p>Paired with <b>this browser</b> on ' + esc(String(rec.paired).slice(0, 10)) + " as “" + esc(rec.name) + "” — no account involved.</p><p class=\"small\">The device keeps its key until it is unpaired on the device itself (USB, with a press of ARM). Forgetting it here only removes this browser's record.</p>" +
        '<div class="cn-row"><button type="button" class="btn btn-sm" data-act="forget">Forget on this page</button><button type="button" class="btn btn-sm" data-act="unpair">Unpair the device (press ARM)</button></div>';
      return '<p>Pairing proves that you are at the cube: the device signs this page\'s request only after a press of its ARM button.</p><div class="cn-row"><label for="cnName" class="small">Name</label><input id="cnName" maxlength="80" value="' + esc(S.name) + '"><button type="button" class="btn btn-sm btn-solid" data-act="pair">Pair with this browser</button></div>' +
        (h.paired ? '<p class="small">This device is already paired with another browser or account; pairing here adds this browser (the device keeps its key).</p>' : "");
    }
    if (d.view) return "<p>Paired with your account as “" + esc(d.view.name || d.id) + "” on " + esc(String(d.view.paired || "").slice(0, 10)) + '.</p><button type="button" class="btn btn-sm" data-act="revoke">Revoke (the backend forgets its key)</button>';
    return '<p>This device is not paired with your account. Pairing proves you are at the cube: press ARM on it when asked.</p><div class="cn-row"><label for="cnName" class="small">Name</label><input id="cnName" maxlength="80" value="' + esc(S.name) + '"><button type="button" class="btn btn-sm btn-solid" data-act="pair">Pair with my account</button></div>';
  }
  function diagSummary(c) {
    var r = c.result || {}; if (!r.imu) return "";
    var inp = r.inputs || null, synth = S.drv && S.drv.synthetic(), unpowered = inp && !inp.drive_enable;
    var drv = (r.drivers || []).map(function (x) {
      return [x.seen ? !x.axis_error : unpowered ? null : false, "Wheel driver node " + x.node + ": " + (x.seen ? (x.axis_error ? "error 0x" + x.axis_error.toString(16) : "heartbeat" + (x.vbus_V != null ? ", bus " + (+x.vbus_V).toFixed(1) + " V" : "")) :
        unpowered ? "not seen — the drivers are unpowered in this state (DRIVE_EN off); the self-test powers them" : "not seen")];
    });
    var rows = [[!!r.imu.present, "IMU " + (r.imu.present ? "LSM6DSOX at 0x" + (+r.imu.i2c_address).toString(16) + (r.imu.who_am_i != null ? " (WHO_AM_I 0x" + (+r.imu.who_am_i).toString(16) + ")" : "") : "not detected")]].concat(drv).concat([
      [!!(r.loop && r.loop.overruns === 0), "Control loop: " + (r.loop ? r.loop.steps + " steps, " + r.loop.overruns + " overruns" + (synth ? " (the synthetic device runs in simulated time: no step durations)" : ", longest step " + r.loop.step_us_max + " µs") : "not reported")],
      [!!(r.estimator && r.estimator.valid), "Estimator: " + (r.estimator && r.estimator.valid ? "valid" : "no valid estimate yet")]]);
    if (inp) rows.push([inp.stop_asserted ? false : true, "Local stop: " + (inp.stop_asserted ? "ASSERTED (open stop line or pressed)" : "released")],
      [null, "ARM button: " + (inp.arm_pressed ? "pressed now" : "released") + " · dead-man: " + (inp.commission_held ? "held" : "released") + " · DRIVE_EN: " + (inp.drive_enable ? "on" : "off")]);
    return stepList(rows);
  }
  function panelCalibrate(d) {
    var m = S.meas, synth = !!S.dev;
    var html = '<p class="small">The device measures; this page computes the calibration with the same rules as the backend and decides nothing about safety. Keep the cube still for each measurement.</p>';
    if (d.kind === "local" && !S.calibration) {
      var saved = AERIS_DEVSTORE.localCalibrations(d.deviceId())[0];
      if (saved && saved.ref) html += '<div class="cn-out"><b>Saved in this browser:</b> calibration ' + esc(saved.ref.id) + (saved.saved ? " of " + esc(saved.saved.slice(0, 10)) : "") + '. Use it only if nothing on the cube was remounted since. <button type="button" class="btn btn-sm" data-act="cal-use">Use it</button></div>';
    }
    html += '<ol class="cn-cal"><li><b>1 · Gyroscope bias</b> — the cube completely still, 5 s. <button type="button" class="btn btn-sm" data-act="cal-imu">Measure</button> ' + (m.imu ? '<span class="small">✓ ' + m.imu.gyro_mean_radps.map(function (v) { return (+v).toFixed(5); }).join(", ") + " rad/s</span>" : "") + "</li>";
    html += '<li><b>2 · Gravity on two faces</b> — rest the cube with a named body axis up, two different axes (e.g. +z, then +x).' + (synth ? " With the synthetic device: “Rest on face” in its hands." : "") +
      ' <span class="cn-face"><label for="cnCalFace" class="small">Axis up</label><select id="cnCalFace">' + FACES.map(function (f) { return "<option" + sel(f === S.calFace) + ">" + f + "</option>"; }).join("") + '</select><button type="button" class="btn btn-sm" data-act="cal-axes">Measure</button></span><br><span class="small">' +
      (m.axes.length ? m.axes.map(function (a) { return "✓ " + esc(a.face); }).join(" · ") : "none yet") + "</span></li>";
    html += '<li><b>3 · Wheel directions</b> — drivers powered, no torque: turn each wheel by hand in its marked positive direction during the 10 s.' + (synth ? " With the synthetic device: “Turn the wheels by hand”." : "") +
      ' <button type="button" class="btn btn-sm" data-act="cal-enc">Start the check</button> ' + (m.encoders ? '<span class="small">✓ measured</span>' : "") + "</li></ol>";
    html += '<div class="cn-row"><button type="button" class="btn btn-sm btn-solid" data-act="cal-compute"' + off(!m.imu || m.axes.length < 2) + '>Compute the calibration</button><button type="button" class="btn btn-sm" data-act="cal-reset">Start over</button></div>';
    if (S.calErr) html += '<div class="cn-out bad">' + esc(S.calErr) + "</div>";
    var c = S.calibration;
    if (c) html += '<div class="cn-out ok"><b>Calibration ' + esc(S.calRef ? S.calRef.id : "(not saved)") + "</b><br>Mounting to_body [" + c.imu.to_body.join(", ") + "] (fit " + (+c.imu.to_body_fit.max_residual_deg).toFixed(2) + "°" + (c.imu.matches_declared ? ", as the profile declares" : ", DIFFERS from the profile") + ")<br>Wheel directions: " +
      (c.wheel_directions_confirmed ? "three confirmed" : "not confirmed (experiments on a physical device stay blocked)") + ((c.notes || []).length ? '<ul class="small">' + c.notes.map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("") + "</ul>" : "") + "</div>";
    return html;
  }
  /* ---------------- the profile editor ---------------- */
  function isIdx(k) { return /^\d+$/.test(k); }
  function getPath(o, path) { return path.split(".").reduce(function (a, k) { return a == null ? undefined : a[isIdx(k) ? +k : k]; }, o); }
  function setPath(o, path, v) { var ks = path.split("."), last = ks.pop(), t = ks.reduce(function (a, k) { return a[isIdx(k) ? +k : k]; }, o); t[isIdx(last) ? +last : last] = v; }
  /* a profile of the visitor's own, started from a document (the reference profile's id is reserved) */
  function newProfile(base) {
    var p = JSON.parse(JSON.stringify(base));
    if (p.id === profRef().id) { p.id = "my-cube"; p.name = "My cube (from the A1 reference)"; p.description = "Started from the AERIS reference profile A1; every value not replaced is still the nominal model's."; }
    p.qualification = { status: "experimental", evidence: [], note: "Declared by its author; the software never qualifies a profile." };
    p.value_sources = p.value_sources || {};
    return p;
  }
  function pf(path, label, unit, kind) {
    var v = getPath(S.prof, path), bad = S.profBad && S.profBad[path], att = bad ? ' aria-invalid="true" title="' + esc(bad) + '"' : "";
    var id = "cnPf-" + path.replace(/\./g, "-");
    var input = kind === "text" ? '<input id="' + id + '" type="text" data-path="' + esc(path) + '" data-str value="' + esc(v == null ? "" : String(v)) + '"' + att + ">"
      : '<input id="' + id + '" type="number" step="any" data-path="' + esc(path) + '" value="' + esc(v == null ? "" : String(v)) + '"' + att + ">";
    return '<div class="cn-pf"><label for="' + id + '">' + esc(label) + (unit ? " <i>" + esc(unit) + "</i>" : "") + "</label>" + input + "</div>";
  }
  function wheelCell(i, path, label) {
    var full = "wheels." + i + "." + path, v = getPath(S.prof, full), bad = S.profBad && S.profBad[full], id = "cnPf-" + full.replace(/\./g, "-");
    if (path === "driver.sign") return '<td><select id="' + id + '" data-path="' + full + '" data-num aria-label="' + esc(label) + '"' + (bad ? ' aria-invalid="true"' : "") + "><option value=\"1\"" + sel(v === 1) + ">+1</option><option value=\"-1\"" + sel(v === -1) + ">−1</option></select></td>";
    return '<td><input id="' + id + '" type="number" step="any" data-path="' + full + '" value="' + esc(v == null ? "" : String(v)) + '" aria-label="' + esc(label) + '"' + (bad ? ' aria-invalid="true" title="' + esc(bad) + '"' : "") + "></td>";
  }
  function panelProfile(d) {
    if (!S.prof) S.prof = newProfile(profileDoc().document);
    var P = S.prof, be = backendUsable(), html = "";
    var cur = d.kind === "backend" && d.view ? (d.view.profile_id ? d.view.profile_id + " revision " + d.view.profile_revision : "the reference profile " + profRef().id + " revision " + profRef().revision)
      : "the reference profile " + profRef().id + " revision " + profRef().revision + " (this browser builds configurations from the reference profile only)";
    html += '<p class="small">A profile says what the cube <b>is</b>: its size and mass, the wheels and motors, where the IMU sits and the electrical limits, and for each group where the values come from. Replace what you measured; everything else stays the nominal model\'s and is labelled so. A profile you make is always <b>experimental</b>: the software never qualifies one.</p>';
    html += '<p class="small">This device uses <b>' + esc(cur) + "</b>." + (d.kind === "local" ? " Designing gains for your own profile needs an AERIS backend: connect the device through it." : "") + "</p>";
    if (be) {
      if (!S.profList) html += '<button type="button" class="btn btn-sm" data-act="prof-list">Show your profiles</button>';
      else html += '<ul class="cn-devs cn-profs">' + S.profList.map(function (x) {
        return "<li><span>" + esc(x.name || x.id) + ' <span class="small dim mono">' + esc(x.id + " r" + x.revision) + "</span> " + chip(x.reference ? "reference" : x.qualification || "experimental", x.reference ? "cl-nominal" : "cl-pending") + '</span><span class="cn-pbtns">' +
          '<button type="button" class="btn btn-sm" data-act="prof-load" data-id="' + esc(x.id) + '" data-rev="' + esc(String(x.revision)) + '">Edit a copy</button>' +
          (d.kind === "backend" ? '<button type="button" class="btn btn-sm" data-act="prof-use" data-id="' + esc(x.id) + '" data-rev="' + esc(String(x.revision)) + '">Use for this device</button>' : "") + "</span></li>";
      }).join("") + "</ul>";
    }
    html += '<h4 class="cn-h4">Your profile</h4><div class="cn-pgrid">' + pf("id", "Profile id", "a–z, 0–9, -", "text") + pf("name", "Name", "", "text") +
      pf("body.edge_m", "Edge length", "m") + pf("body.mass_kg", "Mass", "kg") + pf("body.inertia_factor", "Inertia factor", "Θ = k·m·a²") +
      pf("imu.position_m.0", "IMU position x", "m") + pf("imu.position_m.1", "IMU position y", "m") + pf("imu.position_m.2", "IMU position z", "m") +
      '<div class="cn-pf"><label for="cnPf-imu-i2c_address">IMU I²C address</label><select id="cnPf-imu-i2c_address" data-path="imu.i2c_address" data-num><option value="106"' + sel(P.imu.i2c_address === 106) + '>0x6A</option><option value="107"' + sel(P.imu.i2c_address === 107) + ">0x6B</option></select></div>" +
      pf("electrical.vbus_min_V", "Bus voltage min", "V") + pf("electrical.vbus_max_V", "Bus voltage max", "V") + pf("electrical.current_abort_A", "Current abort", "A") + pf("electrical.temperature_abort_C", "Temperature abort", "°C") + "</div>";
    var cols = [["Jw_kgm2", "J rotor", "kg·m²"], ["motor.KV_rpm_per_V", "KV", "rpm/V"], ["motor.R_ohm", "R", "Ω"], ["motor.Imax_A", "I max", "A"], ["motor.supply_V", "Supply", "V"], ["motor.speed_max_rpm", "Speed max", "rpm"], ["driver.node", "CAN node", ""], ["driver.sign", "Sign", ""]];
    html += '<div class="tblwrap cn-wtbl"><table class="spec"><thead><tr><th scope="col">Wheel</th>' + cols.map(function (c) { return '<th scope="col">' + esc(c[1]) + (c[2] ? " <span class=\"dim\">" + esc(c[2]) + "</span>" : "") + "</th>"; }).join("") + "</tr></thead><tbody>" +
      (P.wheels || []).map(function (w, i) { return '<tr><th scope="row">' + esc(w.id || String(i)) + " <span class=\"dim mono\">[" + esc((w.axis || []).join(", ")) + "]</span></th>" + cols.map(function (c) { return wheelCell(i, c[0], "wheel " + (w.id || i) + " " + c[1]); }).join("") + "</tr>"; }).join("") + "</tbody></table></div>";
    html += '<h4 class="cn-h4">Where the values come from</h4><div class="cn-pgrid">' + VS.map(function (g) {
      var v = (P.value_sources || {})[g[0]] || "nominal-model", id = "cnVs-" + g[0].replace(/\./g, "-");
      return '<div class="cn-pf"><label for="' + id + '">' + esc(g[1]) + '</label><select id="' + id + '" data-vs="' + esc(g[0]) + '">' + VS_OPTS.map(function (o) { return "<option" + sel(o === v) + ">" + o + "</option>"; }).join("") + "</select></div>";
    }).join("") + "</div>";
    html += '<div class="cn-row"><button type="button" class="btn btn-sm" data-act="prof-validate"' + off(!be) + '>Validate</button><button type="button" class="btn btn-sm btn-solid" data-act="prof-save"' + off(!be) + ">Save as a new revision</button>" +
      '<button type="button" class="btn btn-sm" data-act="prof-dl">Download JSON</button><button type="button" class="btn btn-sm" data-act="prof-reset">Start again from the reference</button></div>';
    if (!be) html += '<p class="small dim">Validating and saving profiles needs an AERIS backend. The downloaded JSON (aeris-device-profile/1) works with <code>python hardware/tools/sizing.py --profile your-profile.json</code>.</p>';
    else html += '<p class="small dim">Check the motor sizing of a saved profile with <code>python hardware/tools/sizing.py --profile your-profile.json</code>.</p>';
    var c = S.profCheck;
    if (c) html += '<div class="cn-out ' + (c.ok ? "ok" : "bad") + '" id="cnProfOut"><b>' + (c.ok ? "Valid" : "Not valid") + "</b>" + ((c.errors || []).length ? '<ul class="small">' + c.errors.map(function (e) { return "<li><code>" + esc(e.path || "(document)") + "</code> " + esc(e.message) + "</li>"; }).join("") + "</ul>" : "") +
      ((c.warnings || []).length ? '<p class="small">Warnings: ' + esc(c.warnings.map(function (w) { return (w.path ? w.path + ": " : "") + w.message; }).join("; ")) + "</p>" : "") + "</div>";
    if (S.profSaved) html += '<div class="cn-out ok"><b>Saved: ' + esc(S.profSaved.id + " revision " + S.profSaved.revision) + "</b>" + (S.profSaved.unchanged ? " (unchanged: the same content as the latest revision)" : "") + ' <span class="small mono">' + esc(String(S.profSaved.hash || "").slice(0, 16)) + "…</span>" +
      (d.kind === "backend" ? ' <button type="button" class="btn btn-sm" data-act="prof-use" data-id="' + esc(S.profSaved.id) + '" data-rev="' + esc(String(S.profSaved.revision)) + '">Use for this device</button>' : "") + "</div>";
    return html;
  }
  function panelConfigure(d, st) {
    var modes = S.dev ? [S.mode] : null, recipes = recipesFor(null).filter(function (r) { return !modes || modes.indexOf(recipeDoc(r).mode) >= 0; });
    if (recipes.indexOf(S.recipe) < 0) S.recipe = recipes[0];
    var prof = d.kind === "backend" && d.view && d.view.profile_id ? d.view.profile_id + " revision " + d.view.profile_revision : profileDoc().document.name + " — the reference profile, revision " + profRef().revision;
    var html = '<p class="small">An approved configuration fixes the controller gains (designed by the AERIS backend on the profile\'s model), the limits and this device\'s calibration. The device checks its SHA-256 before applying it.</p>' +
      '<p class="small">Profile: <b>' + esc(prof) + "</b>" + (d.kind === "local" ? ". A custom profile needs an AERIS backend." : "") + (S.dev ? " The synthetic " + esc(S.mode) + " plant runs " + esc(S.mode) + " recipes only." : "") + "</p>";
    html += '<div class="cn-row"><label for="cnRecipe" class="small">Recipe</label><select id="cnRecipe">' + recipes.map(function (r) { return '<option value="' + esc(r) + '"' + sel(r === S.recipe) + ">" + esc(recipeDoc(r).name) + "</option>"; }).join("") + "</select>" +
      '<button type="button" class="btn btn-sm" data-act="cfg-build">Prepare</button><button type="button" class="btn btn-sm btn-solid" data-act="cfg-apply"' + off(!S.config) + ">Apply to the device</button></div>";
    if (S.config) html += '<div class="cn-out"><b>Configuration ' + esc(S.config.hash.slice(0, 16)) + "…</b> " + esc(S.config.composed) + ' · <a href="#" data-act="cfg-dl">download</a></div>';
    var applied = !!(st.config_hash && S.config && st.config_hash === S.config.hash);
    html += stepList([[applied, "Applied on the device (it reports " + (st.config_hash ? st.config_hash.slice(0, 12) + "…" : "none") + ")"], [st.state === "READY" || st.state === "ARMED", "Self-test passed: the device reports READY"]]);
    html += '<button type="button" class="btn btn-sm" data-act="selftest"' + off(!applied) + ">Run the self-test (3 s, drivers powered, no torque)</button>" + (S.selftestCmd ? cmdOut(S.selftestCmd) : "");
    return html;
  }
  function gates(d, st) {
    var rec = recipeDoc(S.recipe), synth = d.synthetic(), c = d.compat() || {};
    var needsEdge = (rec.requires || []).indexOf("edge-trial-completed") >= 0, edgeOk = true;
    if (needsEdge && !synth) edgeOk = d.kind === "local" ? localTrials(d.deviceId()).some(function (t) { return t.mode === "edge" && t.ended === "duration reached" && t.profile === profKey(); }) : null;
    return [[!!(st.config_hash && S.config && st.config_hash === S.config.hash), "the approved configuration for “" + rec.name + "” is applied"],
      [st.state === "READY" || st.state === "ARMED", "self-test passed (the device reports READY)"],
      [synth || !!(S.calibration && S.calibration.wheel_directions_confirmed), synth ? "synthetic device: the wheel-direction check is not needed" : "three wheel directions confirmed by the calibration"],
      [edgeOk, !needsEdge ? "no prerequisite trial" : synth ? "synthetic device: no prerequisite trial" : edgeOk === null ? "a completed edge trial on this device (the backend checks it)" : "a completed edge trial on this device with this profile"],
      [!!c.actuation_build, c.actuation_build ? "this firmware build may drive motors (after ARM)" : "this firmware build never drives motors: the device refuses experiments"]];
  }
  function panelExperiment(d, st) {
    var g = gates(d, st), rec = recipeDoc(S.recipe), blocked = g.some(function (x) { return x[0] === false; }), ex = st.experiment;
    var html = '<p class="small">A request starts nothing by itself: after it, press <b>ARM on the cube</b> within its validity (10 s). The cube balances for at most ' + rec.duration_s + " s, then stops normally. Stop is always available.</p>";
    if (ex || st.state === "ARMED" || st.state === "BALANCING" || st.state === "STOPPING") {
      html += '<div class="cn-out"><b>Running: ' + esc((ex && ex.recipe) || rec.id) + "</b> · " + esc(st.state || "") + (ex ? " · " + (+ex.elapsed_s || 0).toFixed(1) + " s" + (ex.remaining_s != null ? " · " + (+ex.remaining_s).toFixed(1) + " s left" : "") + (ex.ending ? " · " + esc(ex.ending) : "") : "") +
        '<div class="cn-row"><button type="button" class="btn btn-sm cn-stop" data-act="stop" data-always>Stop</button></div></div>';
      if (S.exp) html += cmdOut(S.exp);
      return html;
    }
    html += stepList(g);
    html += '<p class="small cn-tilt" id="cnTiltNow">' + tiltText(rec) + "</p>";
    if (S.dev) html += '<p class="small">Synthetic device: put it at the start position first (“Hold at the start position”) and wait until its estimated tilt settles; it is let go once it balances.</p>';
    html += '<div class="cn-row"><label for="cnDur" class="small">Duration (s)</label><input id="cnDur" type="number" min="1" max="' + rec.duration_s + '" step="1" value="' + esc(String(Math.min(+S.dur || 5, rec.duration_s))) + '">' +
      '<button type="button" class="btn btn-sm btn-solid" data-act="exp-req"' + off(blocked) + ">Request the experiment</button>" + (S.dev ? '<button type="button" class="btn btn-sm" data-act="op-hold" data-always>Hold at the start position</button><button type="button" class="btn btn-sm" data-act="op-arm" data-always>Press ARM (synthetic)</button>' : "") + "</div>";
    if (S.exp) html += cmdOut(S.exp);
    if (S.history.length) html += '<p class="small">This session: ' + S.history.map(function (x) { return esc(x.mode + ": " + x.ended + (x.sat || "")); }).join(" · ") + "</p>";
    return html;
  }
  /* how often the device's allocation limited each wheel's torque during the experiment (v6.0 firmware result) */
  function satText(res) {
    var s = res && res.saturated_steps, n = res && res.balancing_steps;
    if (!s || !s.length || !n) return "";
    return s.some(function (x) { return x > 0; }) ? " (torque limited in " + s.join(" / ") + " of " + n + " control steps)" : " (no torque limit reached)";
  }
  /* the device's estimated tilt now, against the recipe's start limit (the device itself refuses a start above it) */
  function tiltText(rec) {
    var lean = S.live.lean[S.live.lean.length - 1], lim = rec && rec.limits && rec.limits.tilt_start_deg;
    if (!isFinite(lean)) return "Estimated tilt from balance: no estimate yet (the device streams telemetry once a configuration is applied).";
    return "Estimated tilt from balance now: " + lean.toFixed(2) + "°" + (lim != null ? (lean <= lim ? " — within the start limit of " + lim + "°." : " — above the start limit of " + lim + "°: the device refuses to start; hold the cube at its balance point.") : ".");
  }
  function panelRecord(d) {
    var html = '<p class="small">A recording keeps what the device declared about itself (a synthetic device stays synthetic) and the configuration hash. A simulation is a prediction of the profile\'s MODEL; comparing a synthetic recording is never validation evidence.</p>';
    var on = !!(S.recorder || S.recordingOn);
    html += '<div class="cn-row"><button type="button" class="btn btn-sm" data-act="rec-start"' + off(on) + '>Start recording</button><button type="button" class="btn btn-sm" data-act="rec-stop"' + off(!on) + ">Stop recording</button>" + (on ? '<span class="cn-rec small">● recording</span>' : "") + "</div>";
    if (S.recording) {
      var doc = S.recording.document || null, stored = S.recording.stored || null;
      html += '<div class="cn-out ok"><b>Recording</b> ' + (doc ? esc(doc.samples.cols.t.length + " frames, " + (doc.synthetic ? "SYNTHETIC" : "declared physical, not verified") + ", kept in this browser") : "") +
        (stored ? (doc ? "; " : "") + "stored on the backend as " + esc(stored.id) + " (" + (stored.synthetic ? "SYNTHETIC" : "declared physical, not verified") + ")" : "") + "</div>";
      if (doc) html += '<div class="cn-row"><button type="button" class="btn btn-sm" data-act="rec-json">Export JSON</button><button type="button" class="btn btn-sm" data-act="rec-ndjson">Export NDJSON</button>' + (backendUsable() && !stored ? '<button type="button" class="btn btn-sm" data-act="rec-upload">Store on the backend</button>' : "") + "</div>";
    }
    var canTwin = backendUsable();
    html += '<h4 class="cn-h4">Simulate My Cube</h4>' + (canTwin ? '<p class="small">The research engine runs the same profile and recipe' + (d.kind === "backend" ? " with this device's calibration" : " (the calibration stays in this browser, so the simulation uses the profile's declared mounting)") + ': the model the gains were designed on.</p><button type="button" class="btn btn-sm" data-act="simulate">Simulate</button>'
      : '<p class="small">Needs a reachable AERIS backend: the cube\'s estimator and the corner controller run only in the research engine, and AERIS never substitutes a different model in the browser.</p>');
    if (S.sim) html += '<div class="cn-out' + (S.sim.run ? " ok" : "") + '"><b>Simulation</b> ' + esc(S.sim.run ? S.sim.run.id + " · " + ((S.sim.run.outcome && (S.sim.run.outcome.label || S.sim.run.outcome.code)) || "") : S.sim.state || "") + ' <span class="small">(a prediction of the model)</span>' +
      (S.sim.run && window.Workspace ? ' · <a href="#lab" data-act="sim-open">open it in AERIS Lab</a>' : "") + "</div>";
    if (canTwin && S.sim && S.sim.run && S.recording && S.recording.stored) html += '<button type="button" class="btn btn-sm btn-solid" data-act="compare">Compare the recording with the simulation</button>';
    else if (canTwin && S.sim && S.sim.run && S.recording && !S.recording.stored) html += '<p class="small dim">Store the recording on the backend to compare it.</p>';
    if (S.cmp) html += cmpView(S.cmp);
    return html;
  }
  function num(v, d) { return v == null || !isFinite(v) ? "—" : (+v).toFixed(d == null ? 3 : d); }
  function cmpView(c) {
    var ev = c.evidence || {}, res = c.result || {}, sig = res.signals || {}, al = res.alignment || {};
    var rows = Object.keys(sig).map(function (k) { var s = sig[k] || {}; return '<tr><th scope="row">' + esc(k) + "</th><td>" + esc(s.unit || "") + "</td><td>" + num(s.rmse) + "</td><td>" + num(s.mae) + "</td><td>" + num(s.peak) + "</td><td>" + esc(String(s.n == null ? "—" : s.n)) + "</td></tr>"; }).join("");
    return '<div class="cn-out"><b>Comparison ' + esc(c.id || "") + "</b>" + (c.synthetic ? " " + chip("synthetic recording", "mk-mock") : "") +
      ((res.errors || []).length ? '<p class="small">' + esc(res.errors.join(" ")) + "</p>" : "") +
      (al.lag_s != null ? '<p class="small">Aligned' + (al.recording_t0_rule ? " on " + esc(al.recording_t0_rule) : "") + "; best time offset " + num(al.lag_s, 3) + " s (searched ±" + num(al.lag_search_s, 2) + " s).</p>" : "") +
      (rows ? '<div class="tblwrap"><table class="spec"><thead><tr><th scope="col">Signal (recording − simulation)</th><th scope="col">Unit</th><th scope="col">RMSE</th><th scope="col">Mean |error|</th><th scope="col">Peak |error|</th><th scope="col">Samples</th></tr></thead><tbody>' + rows + "</tbody></table></div>" : "") +
      '<p class="small"><b>Evidence:</b> ' + (ev.admissible_as_validation_evidence ? "admissible under its protocol (a person still reviews it)" : "not admissible") + ((ev.reasons || []).length ? " — " + esc(ev.reasons.join(" ")) : "") + "</p></div>";
  }
  function panelInstall(d) {
    var I = S.install, h = d.hello(), st = d.state();
    var html = '<p class="small">Installs the release image, which never drives motors. The page checks the signed manifest and every image\'s SHA-256 before writing, checks the chip and the flash size, and reads the firmware\'s identity afterwards. Never tested on a physical board.</p>';
    if (!I.release) return html + '<button type="button" class="btn btn-sm" data-act="inst-load">Check the release</button>';
    var m = I.release.manifest, v = I.release.verification;
    html += '<div class="cn-out' + (v.ok ? " ok" : "") + '"><b>AERIS firmware ' + esc(m.version) + "</b> · build " + esc(m.build) + " · " + esc(m.target.chip) + " / " + esc(m.target.board) + "<br>" + esc(m.readiness || "") + "<br>" + (v.ok ? "Signature: " + esc(v.level) + " key " + esc(v.key_id) : esc(v.reason)) + "</div>";
    if (v.needsConsent || (v.ok && v.level === "development")) html += '<label class="small cn-consent"><input type="checkbox" id="cnAllowDev"' + chk(I.allowDev) + "> I understand this is a DEVELOPMENT build signed with a test key, not a production release.</label>";
    var pre = h ? AERIS_INSTALLER.preflight(h, st, m) : [];
    if (pre.length) html += '<div class="cn-out bad">' + esc(pre.join(" ")) + "</div>";
    html += '<div class="cn-row"><button type="button" class="btn btn-sm btn-solid" data-act="inst-run"' + off(!(v.ok && !pre.length)) + ">Install</button></div>";
    if (I.progress) html += '<p class="small mono cn-progress" role="status">' + esc(I.progress) + "</p>";
    if (I.result) html += '<div class="cn-out ' + (I.result.ok ? "ok" : "bad") + '">' + esc(I.result.text) + "</div>";
    if (I.result && I.result.reconnect) html += '<button type="button" class="btn btn-sm" data-act="inst-verify">Reconnect and check its identity</button>';
    return html;
  }
  function render() {
    if (!$("cnChoose") || !S.ready) return;
    var d = S.drv;
    $("cnBadges").innerHTML = chip("Optional · the virtual cube needs none of this", "mode-demo") + chip("Motors start only with ARM on the cube", "cl-ok") + (S.dev ? chip("Synthetic device active", "mk-mock") : "");
    $("connect-choose").hidden = !!d;
    if (!d) renderChoose();
    renderDevice();
    statusStrip();
  }

  /* ---------------- actions ---------------- */
  function measure(action, params, key) {
    return S.drv.run(action, params, { ttl_ms: 5000, waitMs: 60000 }).then(function (c) {
      if (c.status !== "completed") throw new Error(action + ": " + c.status + " — " + (((c.history || []).slice(-1)[0] || {}).reason || ""));
      if (key === "axes") {
        S.meas.axes = S.meas.axes.filter(function (a) { return a.face !== c.result.face; }).concat([c.result]);
        S.meas.axisIds[c.result.face] = c.id; S.meas.ids.axes = Object.keys(S.meas.axisIds).map(function (f) { return S.meas.axisIds[f]; });
      } else { S.meas[key] = c.result; S.meas.ids[key] = c.id; }
      return c;
    });
  }
  function computeCalibration() {
    var d = S.drv; S.calErr = null;
    if (d.kind === "backend") return d.saveCalibration().then(function (ref) { S.calRef = ref; S.config = null; }, function (e) { S.calErr = errText(e); throw e; });
    try {
      S.calibration = AERIS_CALIB.build(d.deviceId(), { id: profRef().id, revision: profRef().revision }, profileDoc().document, { imu: S.meas.imu, axes: S.meas.axes, encoders: S.meas.encoders },
        { source: d.synthetic() ? "synthetic-device" : "device-measurement", evidence: [{ origin: "this browser", note: "results received over this page's own link session" }] });
    } catch (e) { S.calErr = errText(e); return Promise.reject(e); }
    return d.saveCalibration(S.calibration).then(function (ref) { S.calRef = ref; S.config = null; });
  }
  function profResult(r) {
    S.profCheck = r; S.profBad = {};
    (r.errors || []).forEach(function (e) { if (e.path) S.profBad[e.path] = e.message; });
  }
  function requestExperiment() {
    var d = S.drv, st = d.state() || {}, bad = gates(d, st).filter(function (g) { return g[0] === false; });
    if (bad.length) return Promise.reject(new Error("Not yet: " + bad.map(function (g) { return g[1]; }).join("; ")));
    var rec = recipeDoc(S.recipe), dur = Math.max(1, Math.min(Math.round(+S.dur) || 5, rec.duration_s)), hash = S.config.hash;
    say("Requested. Press ARM on the cube within 10 s.", "warn");
    return d.run("start_experiment", { duration_s: dur }, { config_hash: hash, ttl_ms: 10000, until: ["executing", "completed", "failed", "rejected", "expired"] }).then(function (c) {
      S.exp = c; renderPanel();
      if (c.status !== "executing") return c;
      return d.waitFinal(c.id, (dur + 40) * 1000).then(function (c2) {
        S.exp = c2;
        if (c2.result && c2.result.ended) {
          S.history.push({ mode: rec.mode, ended: c2.result.ended, sat: satText(c2.result) });
          if (d.kind === "local" && c2.status === "completed") saveLocalTrial(d.deviceId(), { mode: rec.mode, recipe: rec.id, ended: c2.result.ended, config_hash: hash, profile: profKey(), t: new Date().toISOString() });
        }
        return c2;
      });
    });
  }
  function simulate() {
    var d = S.drv, body = { recipe: S.recipe, calibration: d.kind === "backend" && S.calRef ? S.calRef.id : null };
    if (d.kind === "backend") body.device_id = d.deviceId(); else body.profile = { id: profRef().id, revision: profRef().revision };
    var research = window.AERIS_SERVICE && AERIS_SERVICE.adapter ? AERIS_SERVICE.adapter("research-api") : null;
    if (!research || !research.configured()) return Promise.reject(new Error("the research engine of this backend is not available to this page"));
    S.sim = { state: "submitted" };
    return api().twinSimulate(body).then(function (r) {
      S.sim = { state: "running " + r.job.id }; renderPanel();
      var t0 = Date.now();
      function poll() {
        return research.request("GET", "/jobs/" + encodeURIComponent(r.job.id)).then(function (j) {
          if (["complete", "failed", "cancelled"].indexOf(j.state) >= 0) return j;
          if (Date.now() - t0 > 300000) throw new Error("the simulation did not finish within 5 minutes (job " + r.job.id + ")");
          return new Promise(function (res) { setTimeout(res, 400); }).then(poll);
        });
      }
      return poll();
    }).then(function (j) {
      if (j.state !== "complete") throw new Error("the simulation " + j.state + (j.error && j.error.message ? ": " + j.error.message : ""));
      return research.getRun(j.result_ref.id).then(function (run) { S.sim = { state: "complete", run: run }; });
    }, function (e) { S.sim = null; throw e; });
  }
  function storeLocalRecording() {
    var research = AERIS_SERVICE.adapter("research-api");
    return research.request("POST", "/hardware/recordings", S.recording.document).then(function (r) { S.recording.stored = r; });
  }
  function compare() {
    return api().twinCompare({ run_id: S.sim.run.id, recording_id: S.recording.stored.id }).then(function (c) { S.cmp = c; });
  }
  function install() {
    var I = S.install, m = I.release.manifest, port = S.port, d = S.drv, base = releaseBase();
    if (!port) return Promise.reject(new Error("installation needs a USB port chosen on this page"));
    I.result = null; I.progress = "Checking the images…"; renderPanel();
    return AERIS_INSTALLER.fetchParts(m, base).then(function (parts) {
      I.progress = "Images verified against the manifest." + (d && d.hello() ? " Asking the device to enter its bootloader…" : ""); renderPanel();
      var pre = d && d.hello() ? d.run("enter_update", null, { ttl_ms: 3000 }).then(function (c) { if (c.status !== "completed") throw new Error("the device refused enter_update: " + (((c.history || []).slice(-1)[0] || {}).reason || c.status)); }) : Promise.resolve();
      return pre.then(function () { var s = S.session; S.session = null; return s ? s.close() : null; }).then(function () { return AERIS_LAZY.load([ESPTOOL]); }).then(function () {
        I.progress = "Writing…"; renderPanel();
        return AERIS_INSTALLER.flash(port, parts, m, { onProgress: function (f, w, t) { I.progress = "Writing " + f + ": " + Math.round(100 * w / Math.max(1, t)) + "%"; var el = document.querySelector("#cnPanel .cn-progress"); if (el) el.textContent = I.progress; }, onLog: function (s) { log("esp", s); } });
      });
    }).then(function (rep) {
      I.progress = null;
      I.result = { ok: true, reconnect: true, text: "Written to " + rep.chip + " (" + rep.flash_size + " flash). The board restarted: reconnect to check its identity." };
    }, function (e) {
      I.progress = null;
      I.result = { ok: false, reconnect: !!e.interrupted, text: (e.interrupted ? "Interrupted while writing: the board has no complete firmware. Hold BOOT, press RESET, release BOOT, then install again. " : "") + errText(e) };
    });
  }
  function verifyAfterInstall() {
    var m = S.install.release.manifest, tr = new AERIS_SERIAL.Transport(S.port);
    S.transport = tr;
    var sess = new AERIS_DEVSESSION.Local(tr, { store: AERIS_DEVSTORE }); S.session = sess; wire(sess);
    return sess.start().then(function (h) {
      S.drv = new LocalDriver(sess);
      var v = AERIS_INSTALLER.verifyAfter(h, m);
      S.install.result = { ok: v.ok, text: v.ok ? "Installed and verified: firmware " + h.fw.version + " (" + h.fw.build + ") on " + h.board.id + "." : "The device reports something else: " + v.mismatches.map(function (x) { return x.field + " " + x.reported + " (expected " + x.expected + ")"; }).join("; ") };
    });
  }
  function openSimInLab() {
    var run = S.sim && S.sim.run; if (!run || !window.Workspace) return;
    function h() { window.removeEventListener("hashchange", h); setTimeout(function () { Workspace.openRun(run, { fresh: true, autoplay: true }); }, 0); }
    window.addEventListener("hashchange", h); location.hash = "#lab";
  }
  function onClick(e) {
    var b = e.target.closest && e.target.closest("[data-act]"); if (!b || !b.closest("#view-connect") || b.disabled) return;
    var a = b.getAttribute("data-act"), d = S.drv, via = S.choice.via && backendUsable();
    if (b.tagName === "A") e.preventDefault();
    if (a === "tab") return selectTab(b.getAttribute("data-tab"), true);
    if (a === "syn") return act(function () { return connectSynthetic(S.choice.mode, via); });
    if (a === "serial") return act(function () { return connectSerial(via); });
    if (a === "probe") return act(probeBackend);
    if (a === "devtok") { var r = AERIS_AUTH.setDevToken($("cnDevTok").value, S.apiStatus); if (!r.ok) return say(r.reason, "bad"); S.api = null; return act(probeBackend, "Signed in with a development token (this computer only)."); }
    if (a === "signin") { var pv = AERIS_AUTH.provider(); return act(function () { return Promise.resolve(pv && pv.signIn && pv.signIn()).then(probeBackend); }); }
    if (a === "signout") { AERIS_AUTH.signOut(); return act(probeBackend, "Signed out."); }
    if (a === "open-dev") return act(function () { return openBackendDevice(b.getAttribute("data-id")); });
    if (a === "disconnect") return act(disconnect, "Disconnected.");
    if (!d) return;
    if (a === "stop") return act(function () { return d.run("stop", null, { ttl_ms: 3000 }).then(function (c) { S.exp = c; return c; }); }, outcome("Stop"));
    if (a === "clear") { say("Hold ARM on the cube for 2 s to clear the latched faults.", "warn"); return act(function () { return d.run("clear_faults", null, { ttl_ms: 10000 }); }, outcome("Clear faults")); }
    if (a === "pair") return act(function () { return d.pair(S.name).then(function () { S.tab = "diagnostics"; }); }, "Paired.");
    if (a === "forget") { AERIS_DEVSTORE.forgetLocalDevice(d.deviceId()); return act(disconnect, "Forgotten on this page."); }
    if (a === "unpair") { say("Press ARM on the cube to confirm the unpairing.", "warn"); return act(function () { return d.run("unpair", null, { ttl_ms: 10000 }).then(function (c) { if (c.status !== "completed") throw new Error("unpair: " + c.status); AERIS_DEVSTORE.forgetLocalDevice(d.deviceId()); return disconnect(); }); }, "The device forgot its pairing."); }
    if (a === "revoke") return act(function () { return api().revoke(d.deviceId()).then(disconnect).then(probeBackend); }, "Revoked: the backend forgot the device's key.");
    if (a === "identify") return act(function () { return d.run("identify", { seconds: 2 }); }, "Identify sent: the board's LED blinks.");
    if (a === "diag") return act(function () { return d.run("diagnostics").then(function (c) { S.diag = c; return c; }); }, outcome("Diagnostics"));
    if (a === "cal-use") { var sv = AERIS_DEVSTORE.localCalibrations(d.deviceId())[0]; if (sv) { S.calibration = sv.document; S.calRef = sv.ref; S.config = null; } return renderPanel(); }
    if (a === "cal-imu") return act(function () { return measure("calibrate_imu", { seconds: 5 }, "imu"); }, "Gyroscope bias measured.");
    if (a === "cal-axes") return act(function () { return measure("calibrate_axes", { seconds: 2, face: S.calFace }, "axes"); }, "Gravity direction measured.");
    if (a === "cal-enc") { say("Turn each wheel by hand in its marked positive direction now (10 s).", "warn"); return act(function () { return measure("check_encoders", { seconds: 10 }, "encoders"); }, "Wheel directions measured."); }
    if (a === "cal-compute") return act(computeCalibration, "Calibration computed and saved.");
    if (a === "cal-reset") { S.meas = freshMeas(); S.calibration = null; S.calRef = null; S.calErr = null; S.config = null; return renderPanel(); }
    if (a === "prof-list") return act(function () { return api().profiles().then(function (r) { S.profList = r.profiles || []; }); });
    if (a === "prof-load") return act(function () { return api().profile(b.getAttribute("data-id"), +b.getAttribute("data-rev")).then(function (r) { S.prof = newProfile(r.document); S.profCheck = null; S.profBad = null; S.profSaved = null; }); }, "Loaded into the editor (a copy; saving makes a new revision).");
    if (a === "prof-use") return act(function () { return api().setProfile(d.deviceId(), b.getAttribute("data-id"), +b.getAttribute("data-rev")).then(function () { S.config = null; S.calibration = null; S.calRef = null; return d.refresh ? d.refresh() : null; }); },
      function () { return ["This device now uses " + b.getAttribute("data-id") + " revision " + b.getAttribute("data-rev") + ". A calibration belongs to one profile revision: compute it again (Calibrate — the measurements are kept), then prepare a new configuration.", "warn"]; });
    if (a === "prof-validate") return act(function () { return api().validateProfile(S.prof).then(function (r) { profResult(r); }); }, function () { return S.profCheck && S.profCheck.ok ? ["The profile is valid.", "ok"] : ["The profile is not valid: see the fields marked.", "bad"]; });
    if (a === "prof-save") return act(function () { return api().createProfile(S.prof).then(function (r) { S.profSaved = r; S.profCheck = r.validation || { ok: true, errors: [], warnings: [] }; S.profBad = null; S.profList = null; },
      function (e) { if (e && e.details && e.details.length) profResult({ ok: false, errors: e.details, warnings: [] }); throw e; }); }, "Saved.");
    if (a === "prof-dl") return download((S.prof.id || "profile") + ".aeris-profile.json", JSON.stringify(S.prof, null, 1));
    if (a === "prof-reset") { S.prof = newProfile(profileDoc().document); S.profCheck = null; S.profBad = null; S.profSaved = null; return renderPanel(); }
    if (a === "cfg-build") return act(function () { return d.buildConfig(S.recipe).then(function (c) { S.config = c; }); }, "Configuration prepared.");
    if (a === "cfg-apply") return act(function () { return d.apply(S.config).then(function (c) { if (c.status !== "completed") throw new Error("apply_config: " + c.status + " — " + (((c.history || []).slice(-1)[0] || {}).reason || "")); }); }, "Applied: run the self-test.");
    if (a === "cfg-dl") return download("aeris-config-" + S.config.hash.slice(0, 12) + ".json", S.config.text);
    if (a === "selftest") return act(function () { return d.run("self_test", null, { ttl_ms: 8000 }).then(function (c) { S.selftestCmd = c; return c; }); }, outcome("Self-test"));
    if (a === "exp-req") return act(requestExperiment, function (c) { var e = c && c.result && c.result.ended, last = ((c && c.history) || []).slice(-1)[0] || {};
      return ["Experiment " + (c && c.status) + (e ? ": " + e : last.reason ? ": " + last.reason : "") + satText(c && c.result) + ".", c && c.status === "completed" ? (e === "duration reached" ? "ok" : "warn") : "bad"]; });
    if (a === "rec-start") return act(function () { return Promise.resolve(d.recStart("recording " + new Date().toISOString())).then(function () { S.recordingOn = true; S.cmp = null; }); }, "Recording.");
    if (a === "rec-stop") return act(function () { return d.recStop().then(function (r) { S.recordingOn = false; S.recording = r; S.cmp = null; }, function (e) { S.recordingOn = false; throw e; }); }, "Recording stopped.");
    if (a === "rec-json") return download("aeris-recording" + (S.recording.document.synthetic ? "-SYNTHETIC" : "") + ".json", JSON.stringify(S.recording.document, null, 1));
    if (a === "rec-ndjson") return download("aeris-recording" + (S.recording.document.synthetic ? "-SYNTHETIC" : "") + ".ndjson", S.recording.ndjson || "", "application/x-ndjson");
    if (a === "rec-upload") return act(storeLocalRecording, "Stored on the backend.");
    if (a === "simulate") return act(simulate, "Simulation complete (a prediction of the model).");
    if (a === "sim-open") return openSimInLab();
    if (a === "compare") return act(compare, "Compared.");
    if (a === "inst-load") return act(function () { return AERIS_INSTALLER.loadRelease(releaseBase(), null, null, S.install.allowDev).then(function (r) { S.install.release = r; }); });
    if (a === "inst-run") return act(install);
    if (a === "inst-verify") return act(verifyAfterInstall);
    if (S.dev && a.indexOf("op-") === 0) {
      if (a === "op-arm") { S.dev.armPress(); say("ARM pressed (synthetic).", "ok"); }
      if (a === "op-armhold") { var dev = S.dev; dev.setArm(true); say("Holding ARM for 2 s (synthetic)…", "warn"); setTimeout(function () { dev.setArm(false); dev.saveNvs(); say("ARM released (synthetic).", "ok"); }, 2200); }
      if (a === "op-estop") { var on = b.getAttribute("aria-pressed") !== "true"; S.dev.setEstop(on); b.setAttribute("aria-pressed", String(on)); b.classList.toggle("on", on); say(on ? "Emergency stop pressed (synthetic): motor power is cut." : "Emergency stop released (synthetic).", on ? "warn" : "ok"); }
      if (a === "op-face") { S.dev.face(S.face); S.calFace = S.face; say("The synthetic cube rests with " + S.face + " up.", "ok"); if (S.tab === "calibrate") renderPanel(); }
      if (a === "op-hold") { S.dev.hold(); say("The synthetic cube is held at the start position.", "ok"); }
      if (a === "op-spin") { [0, 1, 2].forEach(function (i) { S.dev.spin(i, 20); }); say("Wheels turned by hand in the positive direction (synthetic).", "ok"); }
      if (a === "op-push") { S.dev.push([0.15, 0.1, 0], 0.15); say("A push on the synthetic cube.", "ok"); }
    }
  }
  function onInput(e) {
    var t = e.target; if (!t || !t.id) return;
    if (t.id === "cnSynMode") S.choice.mode = t.value;
    else if (t.id === "cnVia") S.choice.via = t.checked;
    else if (t.id === "cnAllPorts") S.choice.allPorts = t.checked;
    else if (t.id === "cnCalFace") S.calFace = t.value;
    else if (t.id === "cnFace") S.face = t.value;
    else if (t.id === "cnDur") S.dur = t.value;
    else if (t.id === "cnName") S.name = t.value;
    else if (t.hasAttribute("data-path") && S.prof) {
      var raw = t.value, v = t.hasAttribute("data-str") ? raw : raw === "" ? null : Number(raw);
      setPath(S.prof, t.getAttribute("data-path"), v);
      if (S.profCheck || S.profSaved) { S.profCheck = null; S.profSaved = null; var o = $("cnProfOut"); if (o) o.hidden = true; }
      if (S.profBad && S.profBad[t.getAttribute("data-path")]) { delete S.profBad[t.getAttribute("data-path")]; t.removeAttribute("aria-invalid"); }
    }
    else if (t.hasAttribute("data-vs") && S.prof) { (S.prof.value_sources = S.prof.value_sources || {})[t.getAttribute("data-vs")] = t.value; S.profCheck = null; }
    else if (t.id === "cnRecipe" && e.type === "change") { S.recipe = t.value; if (S.config && S.config.recipe && S.config.recipe.id !== t.value) S.config = null; renderPanel(); statusStrip(); }
    else if (t.id === "cnAllowDev" && e.type === "change") {
      S.install.allowDev = t.checked;
      if (S.install.release) S.install.release.verification = AERIS_INSTALLER.verifyManifest(S.install.release.manifest, S.install.release.trust, null, t.checked);
      renderPanel();
    }
  }
  function onKey(e) {
    var t = e.target; if (!t || !t.matches || !t.matches('#cnTabs [role="tab"]')) return;
    var tabs = [].slice.call(document.querySelectorAll('#cnTabs [role="tab"]')), i = tabs.indexOf(t), j = -1;
    if (e.key === "ArrowRight") j = (i + 1) % tabs.length; else if (e.key === "ArrowLeft") j = (i - 1 + tabs.length) % tabs.length; else if (e.key === "Home") j = 0; else if (e.key === "End") j = tabs.length - 1;
    if (j < 0) return;
    e.preventDefault(); selectTab(tabs[j].getAttribute("data-tab"), true);
  }
  function init() {
    if (S.inited) return; S.inited = true;
    var v = $("view-connect"); if (!v) return;
    v.addEventListener("click", onClick);
    v.addEventListener("change", onInput); v.addEventListener("input", onInput);
    v.addEventListener("keydown", onKey);
    v.addEventListener("toggle", function (e) { if (e.target.matches && e.target.matches("details.cn-adv") && e.target.open) { var el = $("cnLog"); if (el) el.textContent = S.log.slice(-80).join("\n"); } }, true);
    window.addEventListener("pagehide", function () { if (S.dev) S.dev.saveNvs(); });
    renderEnv();
  }
  function show(h) {
    init();
    var sub = (h || "").split("/")[1];
    var first = !S.ready;
    (first ? AERIS_LAZY.load(STACK).then(function () { S.ready = true; return probeBackend(); }) : S.drv ? Promise.resolve() : probeBackend()).then(function () {
      render();
      if (sub === "synthetic" && !S.drv) return act(function () { return connectSynthetic(S.choice.mode, false); });
      if (sub && SUB[sub]) {
        if (!S.drv) say("Choose a device first: the synthetic device works without any hardware.", "");
        else if (!tabsFor(S.drv).some(function (t) { return t[0] === SUB[sub]; })) say(sub === "install" ? "The installer needs a USB port chosen on this page (Web Serial); the synthetic device needs no firmware." : "That step is not available for this device.", "warn");
        else selectTab(SUB[sub], false);
      }
    }, function (e) { say("The Connect page could not load: " + errText(e), "bad"); });
  }
  return { show: show, _state: S, _drivers: { LocalDriver: LocalDriver, BackendDriver: BackendDriver, PortDriver: PortDriver }, _leanDeg: leanDeg };
})();

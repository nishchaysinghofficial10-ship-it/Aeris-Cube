/* =====================================================================
   AERIS · SIGN-IN for a backend in AERIS_AUTH=jwt mode.

   The site never creates, stores in files or embeds credentials. A deployment
   that runs the backend with AERIS_AUTH=jwt connects the page to its identity
   provider by defining, before this script loads,

       window.AERIS_AUTH_PROVIDER = { name: "…", token: function () { return accessTokenOrNull; },
                                      signIn: function () { … }, signOut: function () { … } }

   (for example with the provider's own maintained OpenID Connect client). The
   page then sends "Authorization: Bearer <token>" to /api/v1 and /api/v6 and
   opens WebSockets with single-use tickets.

   For local development only, the backend's development identity fixture
   (python -m aeris_backend.tools.devauth) issues tokens on this computer; the
   page accepts a pasted development token only when the backend reports that
   fixture AND the page itself is served from a loopback origin. It is kept in
   sessionStorage (gone when the tab closes).
   ===================================================================== */
var AERIS_AUTH = (function () {
  "use strict";
  var KEY = "aeris.v6.devtoken";
  function provider() { return typeof window !== "undefined" && window.AERIS_AUTH_PROVIDER && typeof window.AERIS_AUTH_PROVIDER.token === "function" ? window.AERIS_AUTH_PROVIDER : null; }
  function loopback() {
    if (typeof location === "undefined") return false;
    return /^(localhost|127\.\d+\.\d+\.\d+|\[::1\])$/.test(location.hostname);
  }
  function devToken() { try { return typeof sessionStorage !== "undefined" ? sessionStorage.getItem(KEY) : null; } catch (e) { return null; } }
  function token() { var p = provider(); if (p) { try { return p.token() || null; } catch (e) { return null; } } return devToken(); }
  function setDevToken(t, backendStatus) {
    var fixture = backendStatus && backendStatus.auth && backendStatus.auth.development_fixture;
    if (!fixture) return { ok: false, reason: "The backend does not run the development identity fixture: sign in with its identity provider." };
    if (!loopback()) return { ok: false, reason: "Development tokens are accepted only on a page served from this computer (localhost)." };
    if (!/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(String(t || "").trim())) return { ok: false, reason: "That is not a JWT (three base64url parts separated by dots)." };
    try { sessionStorage.setItem(KEY, String(t).trim()); } catch (e) { return { ok: false, reason: "This browser does not allow session storage." }; }
    return { ok: true, reason: null };
  }
  function signOut() { var p = provider(); try { sessionStorage.removeItem(KEY); } catch (e) { /* ignore */ } if (p && p.signOut) p.signOut(); }
  function describe(backendStatus) {
    var mode = backendStatus && backendStatus.auth ? backendStatus.auth.mode : null, p = provider();
    if (mode === "local") return { mode: "local", signedIn: true, text: "This backend runs for this computer only (AERIS_AUTH=local): no sign-in." };
    if (mode === "jwt") {
      if (token()) return { mode: "jwt", signedIn: true, text: p ? "Signed in with " + (p.name || "the identity provider") + "." : "Using a development token (this computer only)." };
      return { mode: "jwt", signedIn: false, canSignIn: !!(p && p.signIn), devFixture: !!(backendStatus.auth && backendStatus.auth.development_fixture), text: p ? "Sign in to use your devices." : "This backend needs a sign-in, but this site has no identity provider configured (window.AERIS_AUTH_PROVIDER)." };
    }
    return { mode: null, signedIn: false, text: "No AERIS backend is connected." };
  }
  return { token: token, setDevToken: setDevToken, signOut: signOut, describe: describe, provider: provider, loopback: loopback };
})();
if (typeof module !== "undefined") module.exports = AERIS_AUTH;

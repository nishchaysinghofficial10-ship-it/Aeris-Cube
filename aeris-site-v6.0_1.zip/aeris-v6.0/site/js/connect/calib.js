/* =====================================================================
   AERIS · CALIBRATION from device measurements (aeris-calibration/1) — the
   browser twin of backend/aeris_backend/devices/calibration.py (same rules,
   same thresholds; test: site/tests/connect.test.js compares both on shared
   fixtures).

   imu       calibrate_imu (cube completely still): gyroscope bias, SENSOR frame
   axes      ≥ 2 calibrate_axes with a named BODY axis up ("+x" … "-z"): the
             mounting to_body is the axis-aligned rotation (one of 24) mapping the
             measured up direction onto the named axes, within 10° for every face,
             with two different axes (one axis leaves a rotation undetermined)
   encoders  check_encoders while a person turns each wheel in its MARKED positive
             direction: a positive reading confirms the profile's driver sign
   The device measures; this decides nothing about safety: experiments stay
   blocked until three wheel directions are confirmed.
   ===================================================================== */
var AERIS_CALIB = (function () {
  "use strict";
  var G0 = 9.80665, GRAVITY_TOL = 0.8, FIT_MAX_DEG = 10, STILL_GYRO = 0.02, STILL_ACCEL = 0.15;
  var WHEEL_MIN_TRAVEL_REV = 0.25, WHEEL_MIN_SPEED = 0.5, WHEEL_BACKLASH_RATIO = 0.5;

  function CalibrationError(message, details) { var e = new Error(message); e.name = "CalibrationError"; e.details = details || []; return e; }
  function signedPermutation(m) {
    if (!Array.isArray(m) || m.length !== 9 || m.some(function (x) { return x !== -1 && x !== 0 && x !== 1; })) return false;
    var rows = [m.slice(0, 3), m.slice(3, 6), m.slice(6, 9)];
    if (rows.some(function (r) { return r.filter(function (x) { return x !== 0; }).length !== 1; })) return false;
    for (var c = 0; c < 3; c++) if (rows.filter(function (r) { return r[c] !== 0; }).length !== 1) return false;
    var det = m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6]);
    return det === 1;
  }
  /* the 24 axis-aligned rotations in the same order as the Python module (itertools.permutations × product((1,-1))) */
  var ROTATIONS = (function () {
    var out = [], perms = [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]], signs = [];
    [1, -1].forEach(function (a) { [1, -1].forEach(function (b) { [1, -1].forEach(function (c) { signs.push([a, b, c]); }); }); });
    perms.forEach(function (p) { signs.forEach(function (s) { var m = [0, 0, 0, 0, 0, 0, 0, 0, 0]; for (var r = 0; r < 3; r++) m[3 * r + p[r]] = s[r]; if (signedPermutation(m)) out.push(m); }); });
    return out;
  })();
  function faceVector(face) {
    if (typeof face !== "string" || !/^[+-][xyz]$/.test(face)) throw CalibrationError("face " + JSON.stringify(face) + ": name the body axis pointing up as +x, -x, +y, -y, +z or -z");
    var v = [0, 0, 0]; v["xyz".indexOf(face[1])] = face[0] === "+" ? 1 : -1; return v;
  }
  function mv(m, v) { return [0, 1, 2].map(function (r) { return m[3 * r] * v[0] + m[3 * r + 1] * v[1] + m[3 * r + 2] * v[2]; }); }
  function angleDeg(a, b) {
    var cx = a[1] * b[2] - a[2] * b[1], cy = a[2] * b[0] - a[0] * b[2], cz = a[0] * b[1] - a[1] * b[0];
    return Math.atan2(Math.sqrt(cx * cx + cy * cy + cz * cz), a[0] * b[0] + a[1] * b[1] + a[2] * b[2]) * 180 / Math.PI;
  }
  function norm(v) { return Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); }
  function vec3(r, key, what) {
    var v = r[key];
    if (!(Array.isArray(v) && v.length === 3 && v.every(function (x) { return typeof x === "number" && isFinite(x); }))) throw CalibrationError(what + ": " + key + " must be three finite numbers");
    return v.slice();
  }
  function checkStill(r, what) {
    if (r.still !== true) throw CalibrationError(what + ": the device reported that the cube moved during the measurement");
    if (r.gyro_std_radps != null && norm(vec3(r, "gyro_std_radps", what)) >= STILL_GYRO) throw CalibrationError(what + ": the gyroscope spread shows motion");
    if (r.accel_std_mps2 != null && norm(vec3(r, "accel_std_mps2", what)) >= STILL_ACCEL) throw CalibrationError(what + ": the accelerometer spread shows motion");
  }
  function round(x, d) { var k = Math.pow(10, d); return Math.round(x * k) / k; }

  function solveToBody(axes) {
    if (!Array.isArray(axes) || axes.length < 2) throw CalibrationError("at least two calibrate_axes measurements are needed (the cube resting with two different body axes up)");
    var ups = [], faces = [];
    axes.forEach(function (r, i) {
      var what = "axes[" + i + "]";
      if (!r || typeof r !== "object") throw CalibrationError(what + ": a calibrate_axes result object is required");
      if (r.measurement != null && r.measurement !== "calibrate_axes") throw CalibrationError(what + ": not a calibrate_axes result");
      var e = faceVector(r.face);
      checkStill(r, what);
      var a = vec3(r, "accel_mean_mps2", what), n = norm(a);
      if (!(Math.abs(n - G0) <= GRAVITY_TOL)) throw CalibrationError(what + ": the measured gravity magnitude " + n.toFixed(3) + " m/s² is not plausible");
      ups.push(a.map(function (x) { return x / n; })); faces.push([r.face, e]);
    });
    var letters = {}; faces.forEach(function (f) { letters[f[0][1]] = 1; });
    if (Object.keys(letters).length < 2) throw CalibrationError("the measurements must include two different body axes (for example +z and +x): one axis leaves the rotation about it undetermined");
    var fits = ROTATIONS.map(function (m) { var res = ups.map(function (u, i) { return angleDeg(mv(m, u), faces[i][1]); }); return { worst: Math.max.apply(null, res), m: m, res: res }; });
    fits.sort(function (a, b) { return a.worst - b.worst; });
    var best = fits[0];
    if (best.worst > FIT_MAX_DEG) throw CalibrationError("no axis-aligned mounting fits the measurements within " + FIT_MAX_DEG + "° (best " + best.worst.toFixed(1) + "°): check the face labels and that the IMU is mounted along the body axes",
      faces.map(function (f, i) { return { face: f[0], residual_deg: round(best.res[i], 3) }; }));
    return { to_body: best.m.slice(), max_residual_deg: best.worst, faces: faces.map(function (f, i) { return { face: f[0], residual_deg: round(best.res[i], 4) }; }), next_best_deg: fits[1].worst };
  }
  function gyroBias(r) {
    if (!r || typeof r !== "object") throw CalibrationError("a calibrate_imu result (the cube completely still) is required for the gyroscope bias");
    if (r.measurement != null && r.measurement !== "calibrate_imu") throw CalibrationError("imu: not a calibrate_imu result");
    checkStill(r, "imu");
    var b = vec3(r, "gyro_mean_radps", "imu");
    if (b.some(function (x) { return Math.abs(x) > 0.2; })) throw CalibrationError("imu: a gyroscope bias above 0.2 rad/s is not plausible for this sensor: check the mounting and repeat");
    var out = { gyro_bias_radps: b };
    if (r.gyro_std_radps != null) out.gyro_std_radps = vec3(r, "gyro_std_radps", "imu");
    if (r.accel_mean_mps2 != null) out.accel_norm_mps2 = norm(vec3(r, "accel_mean_mps2", "imu"));
    if (typeof r.samples === "number") out.samples = r.samples;
    if (typeof r.seconds === "number") out.seconds = r.seconds;
    if (typeof r.temp_c === "number") out.temp_c = r.temp_c;
    return out;
  }
  function wheelChecks(r, profile) {
    if (!r || !Array.isArray(r.wheels) || r.wheels.length !== 3) throw CalibrationError("encoders: a check_encoders result with three wheels is required");
    return r.wheels.map(function (w, i) {
      if (!w || typeof w !== "object") throw CalibrationError("encoders.wheels[" + i + "]: an object is required");
      var node = (((profile.wheels || [])[i] || {}).driver || {}).node;
      if (node != null && w.node != null && w.node !== node) throw CalibrationError("encoders.wheels[" + i + "]: CAN node " + w.node + " does not match the profile's node " + node);
      var item = { index: i, node: w.node != null ? w.node : node, encoder_updates: w.encoder_updates | 0 };
      if (!item.encoder_updates) { item.direction_ok = false; item.checked = false; item.note = "no encoder estimates from this wheel's driver"; return item; }
      var travel = +w.travel_rev || 0, vmax = +w.vel_rads_max || 0, vmin = +w.vel_rads_min || 0;
      item.travel_rev = travel; item.vel_rads_max = vmax; item.vel_rads_min = vmin;
      if (travel < WHEEL_MIN_TRAVEL_REV) { item.direction_ok = false; item.checked = false; item.note = "the wheel was not turned (less than a quarter turn): not checked"; }
      else if (vmax >= WHEEL_MIN_SPEED && -vmin <= WHEEL_BACKLASH_RATIO * vmax) { item.direction_ok = true; item.checked = true; item.note = "turned in the marked positive direction: the reading is positive"; }
      else if (-vmin >= WHEEL_MIN_SPEED && vmax <= WHEEL_BACKLASH_RATIO * -vmin) { item.direction_ok = false; item.checked = true; item.note = "the reading is NEGATIVE for the marked positive direction: the profile's driver.sign for this wheel is wrong (create a profile revision with the opposite sign)"; }
      else { item.direction_ok = false; item.checked = true; item.note = "the wheel moved both ways: repeat, turning it in one direction only"; }
      return item;
    });
  }
  function eq(a, b) { return a.length === b.length && a.every(function (x, i) { return x === b[i]; }); }
  /* measurements = { imu, axes: [..], encoders? } (the device's own result objects) */
  function build(deviceId, profileRef, profile, measurements, opts) {
    opts = opts || {};
    if (!measurements || typeof measurements !== "object") throw CalibrationError("measurements must be an object {imu, axes, encoders}");
    var bias = gyroBias(measurements.imu), fit = solveToBody(measurements.axes), declared = ((profile.imu || {}).to_body || []).slice();
    var imu = { to_body: fit.to_body, gyro_bias_radps: bias.gyro_bias_radps, to_body_fit: { max_residual_deg: round(fit.max_residual_deg, 4), faces: fit.faces, next_best_deg: round(fit.next_best_deg, 3) },
      declared_to_body: declared, matches_declared: eq(declared, fit.to_body) };
    ["gyro_std_radps", "accel_norm_mps2", "samples", "seconds", "temp_c"].forEach(function (k) { if (bias[k] != null) imu[k] = bias[k]; });
    var doc = { schema: "aeris-calibration/1", device_id: deviceId, profile: { id: profileRef.id, revision: profileRef.revision | 0 }, source: opts.source || "device-measurement",
      created: new Date(opts.now || Date.now()).toISOString(), imu: imu, evidence: (opts.evidence || []).slice() };
    var notes = [];
    if (!imu.matches_declared) notes.push("the measured IMU mounting differs from the profile's declared imu.to_body: configurations built from this calibration use the MEASURED mounting; consider a profile revision that declares it");
    if (measurements.encoders != null) {
      doc.wheels = wheelChecks(measurements.encoders, profile);
      var bad = doc.wheels.filter(function (w) { return !w.direction_ok; }).map(function (w) { return w.index; });
      if (bad.length) notes.push("wheel direction not confirmed for wheel(s) " + bad.join(", ") + ": experiments stay blocked for a physical device");
    } else notes.push("wheel directions were not checked: experiments stay blocked for a physical device until a calibration includes them");
    doc.wheel_directions_confirmed = !!(doc.wheels && doc.wheels.every(function (w) { return w.direction_ok; }));
    doc.notes = notes;
    return doc;
  }
  return { ROTATIONS: ROTATIONS, signedPermutation: signedPermutation, faceVector: faceVector, solveToBody: solveToBody, gyroBias: gyroBias, wheelChecks: wheelChecks, build: build,
    FIT_MAX_DEG: FIT_MAX_DEG };
})();
if (typeof module !== "undefined") module.exports = AERIS_CALIB;

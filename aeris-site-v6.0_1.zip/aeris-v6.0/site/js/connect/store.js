/* =====================================================================
   AERIS · BROWSER STORAGE for the Build and Connect pages — build progress
   per kit revision, devices paired with THIS browser (no account), local
   calibrations. Everything is optional: a private window or blocked storage
   leaves the pages working (nothing remembered), and nothing here is a
   qualification or a permission: the device, its profile, its self-test and
   the press of ARM decide what may happen.
   ===================================================================== */
var AERIS_DEVSTORE = (function () {
  "use strict";
  var PREFIX = "aeris.v6.";
  function backend() { try { if (typeof localStorage !== "undefined") { localStorage.getItem("__probe"); return localStorage; } } catch (e) { /* blocked */ } return null; }
  var mem = {};
  function get(k) { var b = backend(); try { return b ? b.getItem(PREFIX + k) : (k in mem ? mem[k] : null); } catch (e) { return null; } }
  function set(k, v) { var b = backend(); try { if (b) b.setItem(PREFIX + k, v); else mem[k] = v; return true; } catch (e) { mem[k] = v; return false; } }
  function remove(k) { var b = backend(); try { if (b) b.removeItem(PREFIX + k); delete mem[k]; } catch (e) { delete mem[k]; } }
  function getJSON(k, dflt) { var v = get(k); if (v == null) return dflt; try { return JSON.parse(v); } catch (e) { return dflt; } }
  function setJSON(k, v) { return set(k, JSON.stringify(v)); }
  function persistent() { return !!backend(); }

  /* ---------------- build progress, tied to a kit revision ---------------- */
  function progressKey(kitId) { return "build." + kitId; }
  /* { revision, done: {stepId: iso}, notes } ; returns {progress, changed: {from, to, invalidated: [...], calibration} | null} */
  function loadProgress(kit) {
    var p = getJSON(progressKey(kit.id), null);
    if (!p || typeof p !== "object") return { progress: { revision: kit.revision, done: {} }, changed: null };
    if (p.revision === kit.revision) return { progress: p, changed: null };
    var inval = [], cal = false, seen = false;
    (kit.revision_history || []).forEach(function (h) {
      if (h.revision === p.revision) { seen = true; return; }
      if (seen || !p.revision) { inval = inval.concat((h.invalidates && h.invalidates.steps) || []); cal = cal || !!(h.invalidates && h.invalidates.calibration); }
    });
    var known = (kit.revision_history || []).some(function (h) { return h.revision === p.revision; });
    if (!known) { inval = Object.keys(p.done || {}); cal = true; }       // an unknown earlier revision: nothing carries over
    var done = {};
    Object.keys(p.done || {}).forEach(function (s) { if (inval.indexOf(s) < 0 && (kit.steps || []).some(function (x) { return x.id === s; })) done[s] = p.done[s]; });
    return { progress: { revision: kit.revision, done: done, carried_from: p.revision }, changed: { from: p.revision, to: kit.revision, invalidated: inval.filter(function (s) { return p.done && p.done[s]; }), calibration: cal, known: known } };
  }
  function saveProgress(kit, progress) { progress.revision = kit.revision; return setJSON(progressKey(kit.id), progress); }

  /* ---------------- devices paired with this browser (local mode) ---------------- */
  function localDevices() { return getJSON("devices", {}); }
  function saveLocalDevice(d) { var all = localDevices(); all[d.id] = d; setJSON("devices", all); return d; }
  function forgetLocalDevice(id) { var all = localDevices(); delete all[id]; setJSON("devices", all); }
  function localCalibrations(deviceId) { return getJSON("cal." + deviceId, []); }
  function saveLocalCalibration(deviceId, cal) { var l = localCalibrations(deviceId); l.unshift(cal); setJSON("cal." + deviceId, l.slice(0, 20)); return cal; }

  return { get: get, set: set, remove: remove, getJSON: getJSON, setJSON: setJSON, persistent: persistent, loadProgress: loadProgress, saveProgress: saveProgress,
    localDevices: localDevices, saveLocalDevice: saveLocalDevice, forgetLocalDevice: forgetLocalDevice, localCalibrations: localCalibrations, saveLocalCalibration: saveLocalCalibration,
    raw: { get: get, set: set, remove: remove } };
})();
if (typeof module !== "undefined") module.exports = AERIS_DEVSTORE;

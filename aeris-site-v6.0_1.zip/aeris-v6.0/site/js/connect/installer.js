/* =====================================================================
   AERIS · FIRMWARE INSTALLER — release manifest, trust, image integrity,
   flashing with Espressif's esptool-js, and the identity check afterwards.
   docs/FIRMWARE_INSTALL.md.

   1. The release manifest (firmware/releases/<version>/manifest.json) must be
      signed (ECDSA P-256 over its canonical JSON without "signature") by a
      key listed in firmware/trust.json: a production key, or — only after the
      visitor explicitly allows development builds — a development key. v6.0
      has no production key; its releases are development builds.
   2. Every part is downloaded and checked against the manifest's size and
      SHA-256 before anything is written.
   3. A device already running AERIS firmware must be in a state with the
      motors unpowered (BOOT, DISARMED, FAULT) and must accept enter_update
      (USB only) — the installer never writes to a cube that is balancing.
   4. esptool-js identifies the chip; anything but the manifest's chip, or a
      flash smaller than the manifest's minimum, stops before writing.
   5. After the reset, the device's hello must report the manifest's version,
      build and board; anything else is reported as a mismatch.
   Signing proves which key approved the bytes, not that they are safe.
   ===================================================================== */
var AERIS_INSTALLER = (function () {
  "use strict";
  var SAFE_STATES = ["BOOT", "DISARMED", "FAULT", "UPDATE"];
  var TE = typeof TextEncoder !== "undefined" ? new TextEncoder() : new (require("util").TextEncoder)();
  function hex(b) { return Array.prototype.map.call(b, function (x) { return (x < 16 ? "0" : "") + x.toString(16); }).join(""); }
  function esc(s) {
    var o = '"';
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i), ch = s[i];
      if (ch === '"') o += '\\"'; else if (ch === "\\") o += "\\\\"; else if (ch === "\n") o += "\\n"; else if (ch === "\r") o += "\\r"; else if (ch === "\t") o += "\\t";
      else if (ch === "\b") o += "\\b"; else if (ch === "\f") o += "\\f";
      else if (c < 0x20 || c > 0x7e) o += "\\u" + ("0000" + c.toString(16)).slice(-4);
      else o += ch;
    }
    return o + '"';
  }
  /* Python json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True) for the manifest's value types */
  function canonical(v) {
    if (v === null) return "null";
    if (typeof v === "boolean") return v ? "true" : "false";
    if (typeof v === "number") { if (!Number.isInteger(v)) throw new Error("the manifest holds only integers"); return String(v); }
    if (typeof v === "string") return esc(v);
    if (Array.isArray(v)) return "[" + v.map(canonical).join(",") + "]";
    var keys = Object.keys(v).sort();
    return "{" + keys.map(function (k) { return esc(k) + ":" + canonical(v[k]); }).join(",") + "}";
  }
  function verifyManifest(manifest, trust, noble, allowDevelopment) {
    var N = noble || (typeof AERIS_NOBLE !== "undefined" ? AERIS_NOBLE : null), L = typeof AERIS_LINK !== "undefined" ? AERIS_LINK : require("./link.js");
    if (!manifest || manifest.schema !== "aeris-firmware-manifest/1") return { ok: false, level: null, reason: "not an AERIS firmware manifest" };
    var sig = manifest.signature;
    if (!sig || sig.alg !== "ES256" || typeof sig.sig !== "string") return { ok: false, level: null, reason: "the manifest is not signed" };
    var level = null, key = null;
    ["production", "development"].forEach(function (lv) { (trust[lv] || []).forEach(function (k) { if (!level && k.key_id === sig.key_id && k.public_key === sig.public_key) { level = lv; key = k; } }); });
    if (!level) return { ok: false, level: null, reason: "signed by a key this site does not trust (" + sig.key_id + ")" };
    var body = {}; Object.keys(manifest).forEach(function (k) { if (k !== "signature") body[k] = manifest[k]; });
    var ok = false;
    try { ok = N.p256.verify(L.b64uDecode(sig.sig), N.sha256(TE.encode(canonical(body))), L.b64uDecode(key.public_key), { prehash: false, lowS: false }); } catch (e) { ok = false; }
    if (!ok) return { ok: false, level: level, reason: "the signature does not verify: the manifest was altered or signed with another key" };
    if (level === "development" && !allowDevelopment) return { ok: false, level: level, needsConsent: true, reason: "a DEVELOPMENT build signed with a test key (" + sig.key_id + "): not a production release. Allow development builds to continue." };
    if (manifest.capabilities && (manifest.capabilities.actuation || manifest.capabilities.commissioning)) return { ok: false, level: level, reason: "this manifest describes a build that can drive motors; the website only installs builds that never do" };
    return { ok: true, level: level, reason: null, key_id: sig.key_id };
  }
  function getJSON(fetchFn, url) { return fetchFn(url, { cache: "no-store" }).then(function (r) { if (!r.ok) throw new Error(url + ": HTTP " + r.status); return r.json(); }); }
  function loadRelease(base, fetchFn, noble, allowDevelopment, trustUrl) {
    var f = fetchFn || fetch;
    return Promise.all([getJSON(f, base.replace(/\/$/, "") + "/manifest.json"), getJSON(f, trustUrl || "firmware/trust.json")]).then(function (r) {
      return { manifest: r[0], trust: r[1], verification: verifyManifest(r[0], r[1], noble, allowDevelopment) };
    });
  }
  function fetchParts(manifest, base, fetchFn, noble) {
    var N = noble || AERIS_NOBLE, f = fetchFn || fetch;
    return Promise.all(manifest.parts.map(function (p) {
      return f(base.replace(/\/$/, "") + "/" + p.file, { cache: "no-store" }).then(function (r) { if (!r.ok) throw new Error(p.file + ": HTTP " + r.status); return r.arrayBuffer(); }).then(function (ab) {
        var data = new Uint8Array(ab), h = hex(N.sha256(data));
        if (data.length !== p.bytes) throw new Error(p.file + ": " + data.length + " bytes, the manifest says " + p.bytes);
        if (h !== p.sha256) throw new Error(p.file + ": SHA-256 " + h.slice(0, 12) + "… does not match the manifest (" + p.sha256.slice(0, 12) + "…): nothing was written");
        return { name: p.name, file: p.file, offset: p.offset, data: data, sha256: h };
      });
    }));
  }
  /* reasons not to flash a device that already speaks AERIS (empty when it may be flashed) */
  function preflight(hello, state, manifest) {
    var why = [];
    var st = state && state.state;
    if (st && SAFE_STATES.indexOf(st) < 0) why.push("the device is " + st + ": stop it and wait for DISARMED (the installer never writes to a cube whose motors may be powered)");
    if (hello && hello.board && manifest.target && hello.board.id && hello.board.id !== manifest.target.board) {
      if (hello.board.kind === "emulator") why.push("this is a synthetic device (" + hello.board.id + "): there is nothing to install on it");
      else why.push("the device reports board " + hello.board.id + "; this release is for " + manifest.target.board);
    }
    return why;
  }
  function sizeBytes(s) { var m = /^(\d+)(KB|MB)$/.exec(String(s || "")); return m ? +m[1] * (m[2] === "MB" ? 1048576 : 1024) : null; }
  /* write the verified parts with esptool-js; opts: { esptool, onProgress(file, written, total), onLog(text), baudrate } */
  function flash(port, parts, manifest, opts) {
    opts = opts || {};
    var ET = opts.esptool || (typeof AERIS_ESPTOOL !== "undefined" ? AERIS_ESPTOOL : null);
    if (!ET) return Promise.reject(new Error("the flasher (vendor/esptool-js.min.js) is not loaded"));
    var log = opts.onLog || function () {};
    var term = { clean: function () {}, writeLine: function (s) { log(String(s)); }, write: function (s) { log(String(s)); } };
    var transport = new ET.Transport(port, false), loader = new ET.ESPLoader({ transport: transport, baudrate: opts.baudrate || 460800, romBaudrate: 115200, terminal: term });
    var report = { chip: null, flash_size: null, written: false };
    return loader.main().then(function (desc) {
      report.chip = (loader.chip && loader.chip.CHIP_NAME) || null; report.chip_description = desc;
      if (report.chip !== manifest.target.chip) throw new Error("the board's chip is " + report.chip + "; this release is for " + manifest.target.chip + ": nothing was written");
      return loader.detectFlashSize();
    }).then(function (size) {
      report.flash_size = size || null;
      var b = sizeBytes(size);
      if (b == null) throw new Error("the flash size could not be read: nothing was written");
      if (b < manifest.target.flash_min_bytes) throw new Error("the flash is " + size + "; this release needs at least " + manifest.target.flash_min_bytes / 1048576 + " MB: nothing was written");
      return loader.writeFlash({ fileArray: parts.map(function (p) { return { data: p.data, address: p.offset }; }), flashMode: manifest.flash.mode, flashFreq: manifest.flash.frequency,
        flashSize: "keep", eraseAll: false, compress: true, reportProgress: function (i, w, t) { if (opts.onProgress) opts.onProgress(parts[i] && parts[i].file, w, t); } });
    }).then(function () {
      report.written = true;
      return loader.after("hard_reset");
    }).then(function () { return transport.disconnect(); }).then(function () { return report; }, function (e) {
      return Promise.resolve(transport.disconnect()).catch(function () {}).then(function () {
        e.report = report;
        if (report.chip === manifest.target.chip && !report.written && /write|flash/i.test(String(e && e.message))) e.interrupted = true;
        throw e;
      });
    });
  }
  /* the device's identity after installation, against the manifest's expected hello */
  function verifyAfter(hello, manifest) {
    var exp = manifest.expected_hello || {}, got = {
      "fw.version": hello && hello.fw && hello.fw.version, "fw.build": hello && hello.fw && hello.fw.build,
      "fw.actuation_build": hello && hello.fw && hello.fw.actuation_build, "board.id": hello && hello.board && hello.board.id };
    var mism = Object.keys(exp).filter(function (k) { return got[k] !== exp[k]; }).map(function (k) { return { field: k, expected: exp[k], reported: got[k] }; });
    return { ok: !!hello && !mism.length, mismatches: mism, reported: got };
  }
  return { canonical: canonical, verifyManifest: verifyManifest, loadRelease: loadRelease, fetchParts: fetchParts, preflight: preflight, flash: flash, verifyAfter: verifyAfter, SAFE_STATES: SAFE_STATES };
})();
if (typeof module !== "undefined") module.exports = AERIS_INSTALLER;

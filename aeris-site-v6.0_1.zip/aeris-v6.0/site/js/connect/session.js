/* =====================================================================
   AERIS · DEVICE SESSIONS — how the page talks to one device.

   Local   the page itself is the link host (js/connect/link.js) on a USB port
           (Web Serial) or the synthetic device. Pairing is with THIS BROWSER
           (no account): the device signs the page's random session and nonce
           after a press of ARM, the page verifies the signature and keeps the
           record in browser storage. Approved configurations come from the
           backend-built reference configurations (data/configs) plus this
           device's calibration; custom profiles need a backend.
   Relay   the page relays the port's bytes to the AERIS backend
           (/api/v6/relay?route=browser-relay); the backend is the link host,
           and the page uses /api/v6 for pairing, commands and telemetry.
   Either way commands are sent once, never retried on their own, and the
   device decides: nothing here arms motors.
   ===================================================================== */
var AERIS_DEVSESSION = (function () {
  "use strict";
  var L = typeof AERIS_LINK !== "undefined" ? AERIS_LINK : require("./link.js");
  var TE = typeof TextEncoder !== "undefined" ? new TextEncoder() : new (require("util").TextEncoder)();
  function hex(b) { return Array.prototype.map.call(b, function (x) { return (x < 16 ? "0" : "") + x.toString(16); }).join(""); }

  /* canonical JSON (sorted keys, no whitespace) for documents this page creates */
  function canonicalText(v) {
    if (v === null || typeof v !== "object") { if (typeof v === "number" && !isFinite(v)) throw new Error("non-finite number"); return JSON.stringify(v); }
    if (Array.isArray(v)) return "[" + v.map(canonicalText).join(",") + "]";
    return "{" + Object.keys(v).sort().map(function (k) { return JSON.stringify(k) + ":" + canonicalText(v[k]); }).join(",") + "}";
  }
  function sha256hex(text, noble) { var N = noble || AERIS_NOBLE; return hex(N.sha256(TE.encode(text))); }
  function f32(x) { return Number(Number(x).toPrecision(9)); }
  /* a reference approved configuration with this device's calibration (mounting, gyroscope bias in body axes) */
  function composeConfig(ref, calibration, calRef, noble) {
    var cfg = JSON.parse(JSON.stringify(ref.config));
    if (calibration) {
      var tb = calibration.imu.to_body, b = calibration.imu.gyro_bias_radps;
      cfg.imu.to_body = tb.slice();
      cfg.imu.gyro_bias_radps = [0, 1, 2].map(function (r) { return f32(tb[3 * r] * b[0] + tb[3 * r + 1] * b[1] + tb[3 * r + 2] * b[2]); });
      cfg.calibration = calRef;
    }
    var text = canonicalText(cfg);
    return { config: cfg, text: text, hash: sha256hex(text, noble), profile: ref.profile, recipe: ref.recipe, calibration: calRef || null,
      composed: calibration ? "in this browser from the reference configuration " + ref.hash.slice(0, 12) + "… and calibration " + (calRef && calRef.id) : "the reference configuration as built by the backend" };
  }

  /* ---------------- Local: the page is the link host ---------------- */
  function Local(transport, opts) {
    opts = opts || {};
    var self = this;
    this.t = transport; this.opts = opts; this.handlers = {}; this.closed = false; this.paired = null;
    this.host = new L.Host({ route: transport.kind === "synthetic" ? "browser-synthetic" : "browser-usb", send: function (b) { transport.write(b).catch(function (e) { self.emit("error", e); }); },
      now: opts.now, heartbeats: opts.heartbeats });
    transport.onData(function (b) { self.host.receive(b); });
    if (transport.onClose) transport.onClose(function (why) { self.emit("closed", why); });
    ["dev_hello", "state", "telemetry", "command", "pairing", "event"].forEach(function (ev) { self.host.on(ev, function (a, b) { self.emit(ev, a, b); }); });
    this.host.on("dev_hello", function (h) { self.compat = L.negotiate(h); self._maybeSession(); });
    this.host.on("telemetry", function (m) { if (m.type === "hello") self.tlmHello = m; });      // a recorder started later begins with it
    /* the device dropped the session (no heartbeat within 1.5 s — this page stalled or the link hiccuped; the device has
       already stopped anything that was running): open a new one. Commands of the old session are not resent. */
    this.host.on("event", function (k, m) {
      if (k !== "session_expired" || self.closed || !self.paired || !m || m.link_session !== self.host.linkSession) return;
      self.host.openSession(self.host.leaseEpoch || 1);
      self.reopened = (self.reopened || 0) + 1;
      self.emit("event", "session_reopened", { reason: "the previous link session expired (" + (m.reason || "no reason given") + "); a new session was opened" });
    });
    this.tickTimer = opts.manualTick ? null : setInterval(function () { self.host.tick(); }, 100);
  }
  var P = Local.prototype;
  P.on = function (ev, fn) { (this.handlers[ev] = this.handlers[ev] || []).push(fn); return this; };
  P.emit = function (ev, a, b) { (this.handlers[ev] || []).slice().forEach(function (fn) { try { fn(a, b); } catch (e) { if (typeof console !== "undefined") console.error(e); } }); };
  P.start = function () {
    var self = this;
    return this.t.connect().then(function () {
      return new Promise(function (resolve, reject) {
        var timer = setTimeout(function () { reject(new Error("the device did not introduce itself (no dev_hello within 5 s): is it running AERIS firmware, and is this its USB port?")); }, self.opts.helloTimeoutMs || 5000);
        self.host.on("dev_hello", function (h) { clearTimeout(timer); resolve(h); });
        self.host.start();
      });
    });
  };
  P.localRecord = function () {
    var h = this.host.devHello, store = this.opts.store;
    if (!h || !store) return null;
    var r = store.localDevices()[h.device_id];
    return r && h.pubkey && r.pubkey === h.pubkey ? r : null;          // the device's current key must be the one it paired with
  };
  P._maybeSession = function () {
    var rec = this.localRecord();
    this.paired = rec;
    if (rec && !this.host.linkSession && this.compat && this.compat.supported) this.host.openSession(1);
  };
  /* pairing with this browser: random session and nonce; the device signs them after the ARM press */
  P.pair = function (name) {
    var self = this, h = this.host.devHello;
    if (!h) return Promise.reject(new Error("no device"));
    var session = "local-" + L.randomHex(10), nonce = L.b64uEncode(TE.encode(L.randomHex(18)));
    return new Promise(function (resolve, reject) {
      var done = false;
      function off() { self.host.handlers.pairing = (self.host.handlers.pairing || []).filter(function (f) { return f !== on; }); }
      function on(m) {
        if (m.session !== session || done) return;
        if (m.kind === "pair_ready") { self.emit("pair_wait", m); return; }
        done = true; off();
        if (m.kind === "pair_rejected") return reject(new Error(m.reason || "the device refused the pairing"));
        if (m.nonce !== nonce || m.device_id !== h.device_id) return reject(new Error("the proof does not answer this pairing"));
        if (!L.verifyPairProof(m)) return reject(new Error("the pairing signature does not verify"));
        var rec = { id: m.device_id, name: name || m.device_id, pubkey: m.pubkey, board: m.board_id, firmware: m.firmware, build: m.build || null, synthetic: !!m.synthetic,
          paired: new Date().toISOString(), paired_with: "this browser (no account)", proof: { session: session, nonce: nonce, sig: m.sig } };
        if (self.opts.store) self.opts.store.saveLocalDevice(rec);
        self.host.devHello = Object.assign({}, h, { pubkey: m.pubkey, paired: true });
        self._maybeSession();
        resolve(rec);
      }
      self.host.on("pairing", on);
      self.host.pairBegin(session, nonce);
      setTimeout(function () { if (!done) { done = true; off(); reject(new Error("no pairing answer (the device waits 30 s for ARM; it may be busy or not DISARMED)")); } }, self.opts.pairTimeoutMs || 40000);
    });
  };
  /* one command, resolved when it reaches one of `until` (default: final) */
  P.run = function (action, params, o) {
    o = o || {};
    if (!this.host.linkSession) return Promise.reject(new Error("no session with the device yet (pair it with this browser first)"));
    if (this.compat && this.compat.actions.indexOf(action) < 0) return Promise.reject(new Error("the device does not offer '" + action + "'"));
    var id;
    try { id = this.host.command(action, params, o); } catch (e) { return Promise.reject(e); }
    this.emit("sent", { id: id, action: action });
    return this.host.waitFor(id, o.until, o.waitMs || (o.ttl_ms || 5000) + 60000);
  };
  P.applyConfig = function (built) { return this.run("apply_config", null, { rawParamsText: '{"config":' + built.text + "}", config_hash: built.hash, ttl_ms: 5000 }); };
  P.close = function () { if (this.tickTimer) clearInterval(this.tickTimer); this.closed = true; this.host.close(); return this.t.close(); };

  /* ---------------- Relay: the backend is the link host ---------------- */
  function Relay(transport, api, opts) {
    this.t = transport; this.api = api; this.opts = opts || {}; this.handlers = {}; this.ws = null; this.device = null; this.closed = false;
  }
  var R = Relay.prototype;
  R.on = P.on; R.emit = P.emit;
  R.start = function () {
    var self = this;
    return this.t.connect().then(function () { return self.api.relaySocket(); }).then(function (ws) {
      self.ws = ws;
      return new Promise(function (resolve, reject) {
        var settled = false, timer = setTimeout(function () { if (!settled) { settled = true; reject(new Error("the backend relay did not report a device within 8 s")); } }, self.opts.helloTimeoutMs || 8000);
        ws.onmessage = function (ev) {
          if (typeof ev.data !== "string") { self.t.write(new Uint8Array(ev.data)); return; }
          var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
          if (m.type === "device") { self.device = m; if (!settled) { settled = true; clearTimeout(timer); resolve(m); } }
          self.emit("control", m);
        };
        ws.onclose = function (ev) { self.emit("closed", "relay closed (" + ev.code + (ev.reason ? " " + ev.reason : "") + ")"); if (!settled) { settled = true; clearTimeout(timer); reject(new Error("the backend closed the relay (" + ev.code + " " + (ev.reason || "") + ")")); } };
        ws.onerror = function () { /* the close event follows */ };
        self.t.onData(function (b) { if (ws.readyState === 1) ws.send(b); });
        if (self.t.onClose) self.t.onClose(function (why) { self.emit("closed", why); try { ws.close(); } catch (e) { /* ignore */ } });
      });
    });
  };
  R.pair = function (name) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify({ op: "pair", name: name || null })); };
  R.status = function () { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify({ op: "status" })); };
  R.close = function () { this.closed = true; try { if (this.ws) this.ws.close(); } catch (e) { /* ignore */ } return this.t.close(); };

  return { Local: Local, Relay: Relay, composeConfig: composeConfig, canonicalText: canonicalText, sha256hex: sha256hex };
})();
if (typeof module !== "undefined") module.exports = AERIS_DEVSESSION;

/* =====================================================================
   AERIS · SYNTHETIC DEVICE in the browser — the firmware core and the device
   models (an LSM6DSOX register model, three ODrive CANSimple models, the
   engine's rigid-body plant) compiled to WebAssembly from firmware/
   (firmware/wasm/aeris_wasm.c, firmware/tools/build_wasm.sh).

   It is the SAME firmware code that runs on the board, driven by models
   instead of hardware: pairing, commands, protection, estimator, controllers
   and telemetry are exercised for real, the cube is not. Everything it
   produces is SYNTHETIC: its hello says board.kind "emulator", synthetic: true,
   and every page that shows it labels it "Synthetic device".

   The page owns time (advance) and the operator's hands (ARM button, stop,
   resting the cube on a face, turning a wheel by hand, a push). Its key is a
   synthetic device's key held by this page (P-256 via the vendored @noble
   libraries); it never leaves the browser.
   ===================================================================== */
var AERIS_SYNTH = (function () {
  "use strict";
  var USB = 0, NET = 1;
  var STATES = ["BOOT", "DISARMED", "SELF_TEST", "READY", "ARMED", "BALANCING", "STOPPING", "FAULT", "CALIBRATING", "UPDATE", "COMMISSIONING"];
  var R = Math.SQRT1_2;
  /* the attitude (body → world, w x y z) that turns the named body axis up — as firmware/sim simdev_face_pose */
  var FACES = { "+z": [1, 0, 0, 0], "-z": [0, 1, 0, 0], "+x": [R, 0, -R, 0], "-x": [R, 0, R, 0], "+y": [R, R, 0, 0], "-y": [R, -R, 0, 0] };
  var TE = typeof TextEncoder !== "undefined" ? new TextEncoder() : new (require("util").TextEncoder)();
  var TD = typeof TextDecoder !== "undefined" ? new TextDecoder() : new (require("util").TextDecoder)();

  function hexOf(b) { return Array.prototype.map.call(b, function (x) { return (x < 16 ? "0" : "") + x.toString(16); }).join(""); }
  function bytesOf(h) { var o = new Uint8Array(h.length / 2); for (var i = 0; i < o.length; i++) o[i] = parseInt(h.substr(2 * i, 2), 16); return o; }
  function rnd(n) { var b = new Uint8Array(n); (typeof crypto !== "undefined" && crypto.getRandomValues ? crypto : require("crypto").webcrypto).getRandomValues(b); return b; }

  /* opts: { wasm: ArrayBuffer|Uint8Array, plant: string (aeris-plant-model/1 JSON), deviceId, noble, storage?: {get,set,remove},
             onOut(link, Uint8Array), onLog(level, text), release: bool (a release build: never drives motors) } */
  function create(opts) {
    var N = opts.noble || (typeof AERIS_NOBLE !== "undefined" ? AERIS_NOBLE : null);
    if (!N) return Promise.reject(new Error("the P-256/SHA-256 library (vendor/noble-p256-sha256.min.js) is not loaded"));
    var store = opts.storage || null, keyName = "aeris.synthetic." + opts.deviceId + ".key", nvsName = "aeris.synthetic." + opts.deviceId + ".nvs";
    var sk = null;
    try { var saved = store && store.get(keyName); if (saved && /^[0-9a-f]{64}$/.test(saved)) sk = bytesOf(saved); } catch (e) { sk = null; }
    var mem = null, ex = null;
    function view() { return new Uint8Array(mem.buffer); }
    function cstr(p) { var u = view(), e = p; while (u[e]) e++; return TD.decode(u.subarray(p, e)); }
    var env = {
      aeris_sin: Math.sin, aeris_cos: Math.cos, aeris_atan2: Math.atan2, aeris_acos: Math.acos, aeris_tanh: Math.tanh,
      aeris_sha256: function (p, n, out) { view().set(N.sha256(view().slice(p, p + n)), out); return 0; },
      aeris_key_public: function (out, create) {
        if (!sk) {
          if (!create) return -1;
          sk = N.p256.utils.randomSecretKey();
          try { if (store) store.set(keyName, hexOf(sk)); } catch (e) { /* storage unavailable: the key lives until the page closes */ }
        }
        view().set(N.p256.getPublicKey(sk, false), out); return 0;
      },
      aeris_sign: function (p, n, out) {
        if (!sk) return -1;
        var sig = N.p256.sign(N.sha256(view().slice(p, p + n)), sk, { prehash: false, lowS: false });
        view().set(sig.length === 64 ? sig : sig.slice(0, 64), out); return 0;
      },
      aeris_key_reset: function () { sk = null; try { if (store) store.remove(keyName); } catch (e) { /* ignore */ } return 0; },
      aeris_random: function (p, n) { view().set(rnd(n), p); return 0; },
      aeris_out: function (link, p, n) { if (opts.onOut) opts.onOut(link, view().slice(p, p + n)); },
      aeris_log: function (level, p) { if (opts.onLog) opts.onLog(level, cstr(p)); }
    };
    var bytes = opts.wasm instanceof Uint8Array ? opts.wasm : new Uint8Array(opts.wasm);
    return WebAssembly.instantiate(bytes, { env: env }).then(function (r) {
      ex = r.instance.exports; mem = ex.memory;
      var buf = ex.sd_buffer(), cap = ex.sd_buffer_size(), plant = TE.encode(opts.plant), id = TE.encode(opts.deviceId);
      if (plant.length + id.length > cap) throw new Error("plant model too large");
      view().set(plant, buf); view().set(id, buf + plant.length);
      if (ex.sd_init(plant.length, plant.length, id.length) !== 0) throw new Error("synthetic device: " + cstr(ex.sd_error()));
      if (opts.release) ex.sd_release_build(1);
      try {
        var nv = store && store.get(nvsName);
        if (nv && nv.length === 2 * ex.sd_nvs_size()) view().set(bytesOf(nv), ex.sd_nvs());
      } catch (e) { /* no stored state */ }
      return new Device(ex, view, store, nvsName);
    });
  }

  function Device(ex, view, store, nvsName) { this.ex = ex; this._view = view; this.store = store; this.nvsName = nvsName; this.synthetic = true; }
  var D = Device.prototype;
  D.advance = function (us) { this.ex.sd_advance(Math.max(0, Math.min(200000, Math.round(us)))); };
  D.input = function (link, bytes) {
    var buf = this.ex.sd_buffer(), cap = this.ex.sd_buffer_size();
    for (var o = 0; o < bytes.length; o += cap) { var part = bytes.subarray(o, Math.min(bytes.length, o + cap)); this._view().set(part, buf); this.ex.sd_input(link, part.length); }
  };
  D.linkUp = function (link) { this.ex.sd_link_up(link); };
  D.linkDown = function (link) { this.ex.sd_link_down(link); };
  D.setArm = function (on) { this.ex.sd_set_arm(on ? 1 : 0); };
  D.armPress = function () { this.ex.sd_set_arm(1); this.advance(60000); this.ex.sd_set_arm(0); this.saveNvs(); };
  D.setEstop = function (on) { this.ex.sd_set_estop(on ? 1 : 0); };
  D.setCommission = function (on) { this.ex.sd_set_commission(on ? 1 : 0); };
  D.push = function (t, s) { this.ex.sd_push(t[0], t[1], t[2], s); };
  D.hold = function () { this.ex.sd_hold(); };
  D.release = function () { this.ex.sd_release(); };
  D.pose = function (q) { this.ex.sd_pose(q[0], q[1], q[2], q[3]); };
  D.face = function (name) { var q = FACES[name]; if (!q) throw new Error("face: +x -x +y -y +z -z"); this.pose(q); };
  D.posed = function () { return !!this.ex.sd_posed(); };
  D.spin = function (i, rads) { this.ex.sd_spin(i, rads); };
  /* the MODEL's true state — for the synthetic view only; never telemetry, never shown as the cube's attitude */
  D.trueQ = function () { var e = this.ex; return [0, 1, 2, 3].map(function (i) { return e.sd_true_q(i); }); };
  D.trueWheels = function () { var e = this.ex; return [0, 1, 2].map(function (i) { return e.sd_true_ww(i); }); };
  D.tiltDeg = function () { return this.ex.sd_tilt() * 180 / Math.PI; };
  D.held = function () { return !!this.ex.sd_held(); };
  D.caught = function () { return !!this.ex.sd_caught(); };
  D.timeUs = function () { return this.ex.sd_time_us(); };
  D.state = function () { return STATES[this.ex.sd_state()] || "?"; };
  D.inBootloader = function () { return !!this.ex.sd_in_bootloader(); };
  D.motorPower = function () { return !!this.ex.sd_motor_power(); };
  D.saveNvs = function () {
    if (!this.store) return;
    try { this.store.set(this.nvsName, hexOf(this._view().slice(this.ex.sd_nvs(), this.ex.sd_nvs() + this.ex.sd_nvs_size()))); } catch (e) { /* unavailable */ }
  };

  /* a byte transport around the synthetic device: the page's link host talks to it like to a serial port */
  function Transport(dev, link, clock) {
    this.dev = dev; this.link = link == null ? USB : link; this.listeners = []; this.open = false; this.clock = clock || null;
  }
  Transport.prototype.kind = "synthetic";
  Transport.prototype.label = "Synthetic device (in this browser)";
  Transport.prototype.connect = function () { this.open = true; this.dev.linkUp(this.link); return Promise.resolve(); };
  /* the device's input is delivered after the current call stack: a host answering the device's own output at once must
     not re-enter the firmware core while it is still sending (the core is not re-entrant; a serial port never is) */
  Transport.prototype.write = function (bytes) { var self = this; return Promise.resolve().then(function () { if (self.open) self.dev.input(self.link, bytes); }); };
  Transport.prototype.onData = function (fn) { this.listeners.push(fn); };
  Transport.prototype.deliver = function (bytes) { this.listeners.forEach(function (fn) { fn(bytes); }); };
  Transport.prototype.close = function () { if (this.open) { this.open = false; this.dev.linkDown(this.link); } return Promise.resolve(); };

  return { create: create, Transport: Transport, FACES: FACES, STATES: STATES, USB: USB, NET: NET };
})();
if (typeof module !== "undefined") module.exports = AERIS_SYNTH;

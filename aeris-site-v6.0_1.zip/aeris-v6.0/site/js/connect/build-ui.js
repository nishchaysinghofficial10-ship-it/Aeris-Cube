/* =====================================================================
   AERIS · BUILD YOUR OWN CUBE (#build) — the versioned reference build from
   data/kits (aeris-kit/1) and data/bom (aeris-bom/1): readiness, the BOM with
   its checked sources, the sizing calculation, downloads (available files with
   their SHA-256, unavailable ones with the reason — never a dead button), and
   the guided steps with expected results, checkpoints and troubleshooting.

   Ticked steps are the visitor's notes, saved in this browser per kit
   revision; a revision change says which notes it invalidates. They permit
   nothing: the device, its profile, its self-test and ARM on the cube decide.
   ===================================================================== */
var BuildPage = (function () {
  "use strict";
  var $ = U.$, esc = U.esc;
  var LEVELS = { concept: "Concept", candidate: "Candidate", engineered: "Engineered", manufactured: "Manufactured", "bench-tested": "Bench-tested", "beginner-validated": "Beginner-validated" };
  var SECTIONS = { plan: "Plan", firmware: "Firmware", connect: "Connect", electronics: "Electronics bench", mechanics: "Mechanics", setup: "Your cube's profile", calibrate: "Calibrate", commission: "Commission", experiment: "Experiments" };
  var kit = null, bom = null, state = null, rendered = false, kitId = null;
  function data() { return window.AERIS_DATA || null; }
  function ensure() { return data() ? Promise.resolve() : AERIS_LAZY.load(["data/aeris-data.js"]); }
  function chip(text, cls, title) { return '<span class="bdg ' + (cls || "") + '"' + (title ? ' title="' + esc(title) + '"' : "") + '><i aria-hidden="true"></i>' + esc(text) + "</span>"; }
  function statusChip(st) {
    if (st === "candidate") return chip("Candidate", "cl-nominal", "named development part with its published data; not tested in an AERIS build");
    if (st === "unresolved") return chip("Not selected", "cl-pending", "open engineering work: requirements below, no part named");
    return chip(st, "");
  }
  function bytes(n) { return n >= 1048576 ? (n / 1048576).toFixed(2) + " MB" : n >= 1024 ? (n / 1024).toFixed(1) + " KB" : n + " B"; }
  function item(id) { return (bom.items || []).filter(function (x) { return x.id === id; })[0]; }

  function renderKit() {
    var lv = Object.keys(LEVELS), at = lv.indexOf(kit.readiness);
    $("bdBadges").innerHTML = chip("Optional · the virtual cube needs none of this", "mode-demo") + chip("Readiness: " + (LEVELS[kit.readiness] || kit.readiness), "cl-pending") + chip("No A1 cube built yet", "cl-pending");
    $("bdKitSel").innerHTML = data().kits.map(function (k) { return '<option value="' + esc(k.id) + '"' + (k.id === kit.id ? " selected" : "") + ">" + esc(k.name + " · revision " + k.revision) + "</option>"; }).join("");
    $("bdKitSel").disabled = data().kits.length < 2;
    $("bdLadder").innerHTML = lv.map(function (k, i) {
      return '<li class="' + (i < at ? "past" : i === at ? "now" : "next") + '"' + (i === at ? ' aria-current="step"' : "") + '><span class="bd-lv-n">' + (i + 1) + '</span><span class="bd-lv-t">' + esc(LEVELS[k]) + "</span></li>";
    }).join("");
    $("bdReadyNote").textContent = kit.readiness_note;
    $("bdConn").innerHTML = '<thead><tr><th scope="col">Connection</th><th scope="col">Software</th><th scope="col">Tested</th></tr></thead><tbody>' + (kit.supported_connections || []).map(function (c) {
      return '<tr><th scope="row">' + esc({ "web-serial": "USB in the browser (Web Serial)", companion: "Companion program (any browser)", "wifi-gateway": "Wi-Fi (the cube's own connection)" }[c.id] || c.id) + "</th><td>" + esc(c.status) + (c.browsers ? '<br><span class="dim small">' + esc(c.browsers) + "</span>" : "") + "</td><td>" + esc(c.tested) + "</td></tr>";
    }).join("") + "</tbody>";
  }
  function renderBom() {
    var rows = (bom.items || []).map(function (x) {
      var p = x.part || {}, pn = p.part_number ? esc(p.part_number) : '<span class="dim">' + esc(p.description || "—") + "</span>";
      var det = "";
      if ((x.facts || []).length) det += "<h4>Published data</h4><ul>" + x.facts.map(function (f) { return "<li>" + esc(f.fact) + ' <a href="' + esc(f.source) + '" rel="noopener" target="_blank">source</a> <span class="dim">(checked ' + esc(f.checked) + ")</span></li>"; }).join("") + "</ul>";
      if ((x.requirements || []).length) det += "<h4>Requirements (open)</h4><ul>" + x.requirements.map(function (r) { return "<li>" + esc(r) + "</li>"; }).join("") + "</ul>";
      if ((x.compatibility || []).length) det += "<h4>Compatibility</h4><ul>" + x.compatibility.map(function (r) { return "<li>" + esc(r) + "</li>"; }).join("") + "</ul>";
      det += "<h4>Tested substitutions</h4><p>" + ((x.substitutions && x.substitutions.tested || []).length ? esc(x.substitutions.tested.join(", ")) : "None tested.") + (x.substitutions && x.substitutions.note ? " " + esc(x.substitutions.note) : "") + "</p>";
      if ((x.supplier_links || []).length) det += "<h4>Manufacturer and supplier pages</h4><ul>" + x.supplier_links.map(function (l) { return '<li><a href="' + esc(l.url) + '" rel="noopener" target="_blank">' + esc(l.name) + "</a></li>"; }).join("") + "</ul>";
      return '<tr><td class="mono">' + esc(String(x.qty)) + "</td><th scope=\"row\">" + esc(x.name) + '<div class="dim small">' + esc(x.group) + "</div></th><td>" + (p.manufacturer ? esc(p.manufacturer) + "<br>" : "") + pn + "</td><td>" + statusChip(x.status) +
        '</td></tr><tr class="bd-det"><td></td><td colspan="3"><details><summary>Details: ' + esc(x.id) + "</summary>" + '<p class="small">' + esc(x.function) + "</p>" + det + "</details></td></tr>";
    }).join("");
    $("bdBom").innerHTML = '<thead><tr><th scope="col">Qty</th><th scope="col">Item</th><th scope="col">Part</th><th scope="col">Status</th></tr></thead><tbody>' + rows + "</tbody>";
    $("bdBomNote").textContent = bom.summary + " " + bom.price_note;
    $("bdTools").innerHTML = (bom.tools || []).map(function (t) { return "<li><b>" + esc(t.name || t.id.replace(/-/g, " ")) + "</b> — " + esc(t.purpose) + "</li>"; }).join("");
    $("bdOpen").innerHTML = (bom.open_engineering || []).map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("");
  }
  function renderSizing() {
    var s = kit.sizing || {}, d = s.candidate_driver || {}, w = s.wheel_model || {};
    $("bdSizing").innerHTML = '<thead><tr><th scope="col">Tilt from balance</th><th scope="col">Gravity torque</th><th scope="col">Wheel current (nominal motor)</th><th scope="col">Time to saturate</th></tr></thead><tbody>' +
      ((s.edge && s.edge.rows) || []).map(function (r) { return "<tr><td>" + r.tilt_deg + "°</td><td>" + r.gravity_torque_Nm.toFixed(4) + " N·m</td><td>" + r.current_at_profile_kt_A.toFixed(2) + " A</td><td>" + r.saturation_time_s_at_this_torque.toFixed(2) + " s</td></tr>"; }).join("") + "</tbody>";
    $("bdSizingNote").innerHTML = "<p>" + esc(s.conclusion || "") + "</p><p class=\"dim small\">" + esc(s.source || "") + ". Nominal wheel model: KV " + esc(String(w.KV_rpm_per_V)) + " rpm/V, k<sub>t</sub> " + esc(String(w.kt_NmA_engine)) +
      " N·m/A, J<sub>w</sub> " + esc(String(w.Jw_kgm2)) + " kg·m². Candidate driver " + esc(d.name || "") + ": " + esc(String(d.I_cont_A)) + " A continuous, " + esc(String(d.I_peak_A)) + " A peak, " + esc(String(d.V_min)) + "–" + esc(String(d.V_max)) +
      " V → static limit " + esc(String(d.static_limit_deg_continuous)) + "° (continuous), " + esc(String(d.static_limit_deg_peak)) + "° (peak). Run <code>python hardware/tools/sizing.py --profile your-profile.json</code> for your own values.</p>";
  }
  function renderDownloads() {
    $("bdDownloads").innerHTML = (kit.downloads || []).map(function (d) {
      if (d.status === "available") return '<li class="bd-dl ok"><div><b>' + esc(d.title) + '</b><div class="small dim mono">sha256 ' + esc(d.sha256) + " · " + bytes(d.bytes) + '</div></div><a class="btn btn-sm" href="' + esc(d.path) + '" download>Download</a></li>';
      return '<li class="bd-dl na"><div><b>' + esc(d.title) + '</b><div class="small">' + esc(d.reason) + '</div></div><span class="bd-na" aria-label="Unavailable">Unavailable</span></li>';
    }).join("");
  }
  function progressStats() {
    var avail = kit.steps.filter(function (s) { return s.availability.status === "available"; }), done = avail.filter(function (s) { return state.progress.done[s.id]; });
    return { avail: avail.length, done: done.length, total: kit.steps.length };
  }
  function renderSteps() {
    var lp = state, ch = lp.changed, html = "", last = null, n = 0;
    $("bdRevBanner").hidden = !ch;
    if (ch) $("bdRevBanner").innerHTML = "<b>Kit revision changed: " + esc(ch.from) + " → " + esc(ch.to) + ".</b><p>" +
      (ch.known === false ? "Your notes belong to a revision this page does not know: none of them carry over." : ch.invalidated.length ? "These notes no longer apply and were cleared: " + esc(ch.invalidated.join(", ")) + "." : "Your notes still apply.") +
      (ch.calibration ? " Calibrations made with the earlier revision must be repeated." : "") + "</p>";
    kit.steps.forEach(function (s) {
      n++;
      if (s.section !== last) { if (last) html += "</ol>"; html += '<h3 class="bd-sec-h">' + esc(SECTIONS[s.section] || s.section) + '</h3><ol class="bd-steps" start="' + n + '">'; last = s.section; }
      var blocked = s.availability.status === "blocked", done = !!state.progress.done[s.id];
      var parts = (s.parts || []).map(function (p) { var it = item(p), pn = it && it.part && it.part.part_number; return it ? esc(it.name + (pn ? " (" + pn + ")" : "")) : esc(p); }).join(", ");
      html += '<li class="bd-step' + (blocked ? " blocked" : "") + (done ? " done" : "") + '" id="step-' + esc(s.id) + '"><div class="bd-step-h"><h4>' + esc(s.title) + "</h4>" + (blocked ? chip("Blocked", "cl-pending") : chip("Available", "cl-ok")) + "</div>" +
        (blocked ? '<p class="bd-block"><b>Why blocked:</b> ' + esc(s.availability.reason) + "</p>" : "") +
        '<p class="small">' + esc(s.summary) + "</p>" + (parts ? '<p class="small dim">Parts: ' + parts + "</p>" : "") +
        '<dl class="bd-dl2"><dt>Expected result</dt><dd>' + esc(s.expected_result) + "</dd><dt>Checkpoint</dt><dd>" + esc(s.checkpoint) + "</dd></dl>" +
        ((s.troubleshooting || []).length ? "<details><summary>Troubleshooting</summary><ul>" + s.troubleshooting.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") + "</ul></details>" : "") +
        (s.advanced ? '<details><summary>Advanced</summary><p class="small">' + esc(s.advanced) + "</p></details>" : "") +
        '<p class="small dim">' + esc(s.illustration && s.illustration.note || "") + "</p>" +
        '<div class="bd-step-f">' + (s.action && !blocked ? '<a class="btn btn-sm" href="' + esc(s.action.route) + '">' + esc(s.action.label) + " →</a>" : "") +
        '<label class="bd-note"><input type="checkbox" data-step="' + esc(s.id) + '"' + (done ? " checked" : "") + (blocked ? " disabled" : "") + "> " + (blocked ? "Cannot be noted while blocked" : "I did this (my note)") + "</label></div></li>";
    });
    html += "</ol>";
    $("bdSteps").innerHTML = html;
    var st = progressStats();
    $("bdProgress").innerHTML = '<div class="bd-prog-bar" role="progressbar" aria-valuemin="0" aria-valuemax="' + st.avail + '" aria-valuenow="' + st.done + '" aria-label="Noted steps"><i style="width:' + (st.avail ? 100 * st.done / st.avail : 0) + '%"></i></div><p class="small">' +
      st.done + " of " + st.avail + " available steps noted · " + (st.total - st.avail) + " steps blocked by open engineering · revision " + esc(kit.revision) + (AERIS_DEVSTORE.persistent() ? "" : " · this browser does not keep notes (storage blocked)") + "</p>";
  }
  function bind() {
    $("bdSteps").addEventListener("change", function (e) {
      var cb = e.target; if (!cb || !cb.matches("input[data-step]")) return;
      var id = cb.getAttribute("data-step");
      if (cb.checked) state.progress.done[id] = new Date().toISOString(); else delete state.progress.done[id];
      AERIS_DEVSTORE.saveProgress(kit, state.progress);
      var li = cb.closest(".bd-step"); if (li) li.classList.toggle("done", cb.checked);
      var st = progressStats(), bar = document.querySelector("#bdProgress .bd-prog-bar");
      if (bar) { bar.setAttribute("aria-valuenow", st.done); bar.querySelector("i").style.width = (st.avail ? 100 * st.done / st.avail : 0) + "%"; }
      var p = document.querySelector("#bdProgress p"); if (p) p.firstChild.nodeValue = st.done + " of " + st.avail + " available steps noted · " + (st.total - st.avail) + " steps blocked by open engineering · revision " + kit.revision;
    });
    $("bdReset").addEventListener("click", function () { state.progress = { revision: kit.revision, done: {} }; AERIS_DEVSTORE.saveProgress(kit, state.progress); state.changed = null; renderSteps(); });
    $("bdKitSel").addEventListener("change", function (e) { kitId = e.target.value; render(); });
  }
  function render() {
    var D = data(); if (!D) return;
    kit = D.kits.filter(function (k) { return k.id === kitId; })[0] || D.kits[0]; kitId = kit.id; bom = D.bom[kit.id];
    state = AERIS_DEVSTORE.loadProgress(kit);
    if (state.changed) AERIS_DEVSTORE.saveProgress(kit, state.progress);
    renderKit(); renderBom(); renderSizing(); renderDownloads(); renderSteps();
    if (kit.progress_note) $("bdProgNote").textContent = kit.progress_note;
    if (!rendered) { bind(); rendered = true; }
    $("bdLoading").hidden = true; $("bdBody").hidden = false;
  }
  function show(h) {
    ensure().then(function () {
      var first = !rendered;
      if (!rendered) render();
      /* a step (#build-step-<id>) or, on the first render, a section anchor that was still hidden when the router scrolled */
      var m = /^build-step-(.+)$/.exec(h || ""), el = m ? $("step-" + m[1]) : first && h && h !== "build" ? $(h) : null;
      if (el) el.scrollIntoView({ block: "start" });
    }, function (e) { $("bdLoading").innerHTML = '<div class="pending-box"><b>The build data could not be loaded.</b><p>' + esc(e.message) + "</p></div>"; });
  }
  return { show: show, render: render, _state: function () { return { kit: kit, state: state }; } };
})();

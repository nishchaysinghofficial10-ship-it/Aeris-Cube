/* =====================================================================
   AERIS · charts — minimal canvas charts drawn at device resolution.
   Every chart keeps its config so the page can redraw it on resize.

     line(cv, cfg)   time series; cfg: xlim, ylim?, series[{x,y,color,width,dash,marker}],
                     hlines, vlines, xbands, ybands, xstrips (thin interval bars along the
                     top: saturation), fills (shaded ranges: confidence bands), markers
     poles(cv, cfg)  s-plane scatter
     heat(cv, cfg)   capture-region grid (codes 2 recovered · 1 not settled · 0 fell)
     cells(cv, cfg)  categorical outcome map with a glyph per cell (research sweeps)
     hist(cv, cfg)   histogram bars (research sweeps)
   Colours come from js/platform/tokens.js when it is loaded.
   ===================================================================== */
var Chart = (function () {
  "use strict";
  var reg = [];
  var TK = typeof AERIS_TOKENS !== "undefined" ? AERIS_TOKENS : null;
  var C = {
    grid: "rgba(255,255,255,0.07)", axis: "rgba(255,255,255,0.22)", tick: "#99a1af", label: "#d1d5dc", surface: "#0b0c0e",
    mono: '"JetBrains Mono", ui-monospace, Menlo, monospace',
    stable: TK ? TK.color.status.stable : "#3ecf6e", warning: TK ? TK.color.status.warning : "#ffb020", failure: TK ? TK.color.status.failure : "#ff5a4f"
  };
  function alpha(hex, a) { return TK ? TK.alpha(hex, a) : hex; }
  function nice(lo, hi, n) {
    var span = hi - lo; if (!(span > 0)) { span = Math.abs(hi) || 1; lo -= span / 2; hi += span / 2; span = hi - lo; }
    var raw = span / Math.max(2, n), mag = Math.pow(10, Math.floor(Math.log10(raw))), r = raw / mag;
    var step = (r < 1.5 ? 1 : r < 3 ? 2 : r < 7 ? 5 : 10) * mag;
    var t = [], s = Math.ceil(lo / step - 1e-9) * step;
    for (var v = s; v <= hi + 1e-9 * step; v += step) t.push(Math.abs(v) < step * 1e-9 ? 0 : v);
    return { ticks: t, step: step };
  }
  function fmtTick(v, step) {
    var d = step >= 1 ? 0 : Math.min(4, Math.ceil(-Math.log10(step) - 1e-9));
    var s = v.toFixed(d); return s === "-0" ? "0" : s.replace("-", "−");
  }
  function setup(cv) {
    var ratio = (cv._ratio = cv._ratio || (cv.getAttribute("height") / cv.getAttribute("width")));
    var w = Math.max(240, cv.clientWidth || cv.parentNode.clientWidth || 600), h = Math.round(w * ratio);
    if (w < 520) h = Math.round(w * Math.min(0.78, ratio * 1.35));
    if (cv._fixedH) h = cv._fixedH;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    cv.style.height = h + "px";
    var ctx = cv.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { ctx: ctx, w: w, h: h };
  }
  /* marker shapes (≥ 8 px, with a surface ring so overlapping marks stay legible) */
  function marker(ctx, shape, x, y, size, color) {
    var s = size || 8, h = s / 2;
    ctx.beginPath();
    if (shape === "square") ctx.rect(x - h * 0.85, y - h * 0.85, s * 0.85, s * 0.85);
    else if (shape === "triangle") { ctx.moveTo(x, y - h * 1.05); ctx.lineTo(x + h, y + h * 0.8); ctx.lineTo(x - h, y + h * 0.8); ctx.closePath(); }
    else if (shape === "diamond") { ctx.moveTo(x, y - h * 1.1); ctx.lineTo(x + h * 1.1, y); ctx.lineTo(x, y + h * 1.1); ctx.lineTo(x - h * 1.1, y); ctx.closePath(); }
    else if (shape === "star") { for (var k = 0; k < 10; k++) { var rr = k % 2 ? h * 0.5 : h * 1.15, a = -Math.PI / 2 + k * Math.PI / 5; if (k) ctx.lineTo(x + rr * Math.cos(a), y + rr * Math.sin(a)); else ctx.moveTo(x + rr * Math.cos(a), y + rr * Math.sin(a)); } ctx.closePath(); }
    else if (shape === "square-open") { ctx.rect(x - h * 0.85, y - h * 0.85, s * 0.85, s * 0.85); ctx.lineWidth = 3; ctx.strokeStyle = C.surface; ctx.stroke(); ctx.lineWidth = 2; ctx.strokeStyle = color; ctx.stroke(); return; }
    else ctx.arc(x, y, h, 0, 2 * Math.PI);
    ctx.lineWidth = 2; ctx.strokeStyle = C.surface; ctx.stroke(); ctx.fillStyle = color; ctx.fill();
  }
  function line(cv, cfg) {
    if (!cv) return;
    cv._cfg = cfg; cv._kind = "line"; if (reg.indexOf(cv) < 0) reg.push(cv);
    var S = setup(cv), ctx = S.ctx, W = S.w, H = S.h;
    var small = W < 520;
    var pad = { l: small ? 46 : 58, r: small ? 12 : 18, t: (cfg.title || cfg.ylabel ? 22 : 12) + (cfg.xstrips && cfg.xstrips.length ? 6 : 0), b: small ? 38 : 44 };
    var pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
    var xl = cfg.xlim, yl = cfg.ylim;
    if (!yl) {
      var lo = Infinity, hi = -Infinity;
      cfg.series.forEach(function (s) { for (var i = 0; i < s.y.length; i++) { var x = s.x[i]; if (x < xl[0] || x > xl[1]) continue; var v = s.y[i]; if (isFinite(v)) { if (v < lo) lo = v; if (v > hi) hi = v; } } });
      (cfg.fills || []).forEach(function (f) { for (var i = 0; i < f.x.length; i++) { [f.y0[i], f.y1[i]].forEach(function (v) { if (isFinite(v)) { if (v < lo) lo = v; if (v > hi) hi = v; } }); } });
      (cfg.hlines || []).forEach(function (h) { if (h.fit !== false) { lo = Math.min(lo, h.y); hi = Math.max(hi, h.y); } });
      if (!isFinite(lo)) { lo = -1; hi = 1; }
      var m = (hi - lo) * 0.08 || 1; yl = [lo - m, hi + m];
      if (cfg.yzero) { yl[0] = Math.min(yl[0], 0); yl[1] = Math.max(yl[1], 0); }
    }
    var yt = nice(yl[0], yl[1], small ? 4 : 5), xt = nice(xl[0], xl[1], small ? 4 : 7);
    if (!cfg.ylim) yl = [Math.min(yl[0], yt.ticks[0]), Math.max(yl[1], yt.ticks[yt.ticks.length - 1])];
    function X(x) { return pad.l + (x - xl[0]) / (xl[1] - xl[0]) * pw; }
    function Y(y) { return pad.t + ph - (y - yl[0]) / (yl[1] - yl[0]) * ph; }
    ctx.clearRect(0, 0, W, H);
    ctx.font = "500 " + (small ? 10 : 11) + "px " + C.mono;
    // bands
    (cfg.xbands || []).forEach(function (b) { var x0 = Math.max(pad.l, X(b.x0)), x1 = Math.min(pad.l + pw, X(b.x1)); if (x1 <= x0) return; ctx.fillStyle = b.color || "rgba(255,255,255,0.04)"; ctx.fillRect(x0, pad.t, x1 - x0, ph); if (b.label) { ctx.fillStyle = C.tick; ctx.textAlign = "left"; ctx.textBaseline = "alphabetic"; ctx.fillText(b.label, x0 + 5, pad.t + ph - 6); } });
    (cfg.ybands || []).forEach(function (b) { ctx.fillStyle = b.color || "rgba(255,255,255,0.04)"; ctx.fillRect(pad.l, Y(b.y1), pw, Y(b.y0) - Y(b.y1)); });
    // grid
    ctx.lineWidth = 1; ctx.textBaseline = "middle";
    yt.ticks.forEach(function (v) { if (v < yl[0] - 1e-12 || v > yl[1] + 1e-12) return; var y = Math.round(Y(v)) + 0.5; ctx.strokeStyle = v === 0 ? C.axis : C.grid; ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); ctx.stroke(); ctx.fillStyle = C.tick; ctx.textAlign = "right"; ctx.fillText(fmtTick(v, yt.step), pad.l - 8, y); });
    ctx.textBaseline = "top";
    xt.ticks.forEach(function (v) { var x = Math.round(X(v)) + 0.5; ctx.strokeStyle = C.grid; ctx.beginPath(); ctx.moveTo(x, pad.t); ctx.lineTo(x, pad.t + ph); ctx.stroke(); ctx.fillStyle = C.tick; ctx.textAlign = "center"; ctx.fillText(fmtTick(v, xt.step), x, pad.t + ph + 7); });
    ctx.strokeStyle = C.axis; ctx.beginPath(); ctx.moveTo(pad.l + 0.5, pad.t); ctx.lineTo(pad.l + 0.5, pad.t + ph + 0.5); ctx.lineTo(W - pad.r, pad.t + ph + 0.5); ctx.stroke();
    // axis labels (units in brackets)
    ctx.fillStyle = C.label; ctx.textAlign = "right"; ctx.textBaseline = "bottom";
    if (cfg.xlabel) ctx.fillText(cfg.xlabel, W - pad.r, H - 4);
    ctx.textAlign = "left"; ctx.textBaseline = "top";
    if (cfg.ylabel) ctx.fillText(cfg.ylabel, 4, 3);
    if (cfg.title) { ctx.textAlign = "right"; ctx.fillStyle = C.tick; ctx.fillText(cfg.title, W - pad.r, 3); }
    // interval strips along the top edge (saturation): row 0 at the top
    (cfg.xstrips || []).forEach(function (s) { var x0 = Math.max(pad.l, X(s.x0)), x1 = Math.min(pad.l + pw, X(s.x1)); if (x1 < x0) return; ctx.fillStyle = s.color; ctx.fillRect(x0, pad.t - 7 + (s.row || 0) * 4, Math.max(1.5, x1 - x0), 3); });
    // reference lines
    ctx.save(); ctx.beginPath(); ctx.rect(pad.l, pad.t, pw, ph); ctx.clip();
    (cfg.fills || []).forEach(function (f) {
      if (!f.x.length) return; ctx.fillStyle = f.color; ctx.beginPath();
      for (var i = 0; i < f.x.length; i++) { var px = X(f.x[i]), py = Y(f.y1[i]); if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py); }
      for (var j = f.x.length - 1; j >= 0; j--) ctx.lineTo(X(f.x[j]), Y(f.y0[j]));
      ctx.closePath(); ctx.fill();
    });
    (cfg.hlines || []).forEach(function (h) {
      ctx.strokeStyle = h.color || "rgba(255,255,255,0.5)"; ctx.lineWidth = h.width || 1.2; ctx.setLineDash(h.dash || [5, 4]);
      ctx.beginPath(); ctx.moveTo(pad.l, Y(h.y)); ctx.lineTo(W - pad.r, Y(h.y)); ctx.stroke(); ctx.setLineDash([]);
      if (h.label) { ctx.fillStyle = C.tick; ctx.textAlign = h.left ? "left" : "right"; ctx.textBaseline = "bottom"; ctx.fillText(h.label, h.left ? pad.l + 6 : W - pad.r - 6, Y(h.y) - 3); }
    });
    (cfg.vlines || []).forEach(function (v) {
      ctx.strokeStyle = v.color || "rgba(255,255,255,0.4)"; ctx.lineWidth = 1; ctx.setLineDash(v.dash || [4, 4]);
      ctx.beginPath(); ctx.moveTo(X(v.x), pad.t); ctx.lineTo(X(v.x), pad.t + ph); ctx.stroke(); ctx.setLineDash([]);
      if (v.label) { ctx.fillStyle = C.label; ctx.textAlign = v.align || "left"; ctx.textBaseline = "top"; ctx.fillText(v.label, X(v.x) + (v.align === "right" ? -5 : 5), pad.t + (v.dy || 6)); }
    });
    // series
    cfg.series.forEach(function (s) {
      if (!s.x.length) return;
      ctx.strokeStyle = s.color; ctx.lineWidth = s.width || 2; ctx.globalAlpha = s.alpha == null ? 1 : s.alpha;
      ctx.setLineDash(s.dash || []); ctx.lineJoin = "round"; ctx.beginPath();
      var started = false, lastPx = -1e9;
      for (var i = 0; i < s.x.length; i++) {
        var x = s.x[i]; if (x < xl[0] - 1e-9) continue; if (x > xl[1] + 1e-9) break;
        var px = X(x), yv = s.y[i]; if (!isFinite(yv)) { started = false; continue; }
        if (started && px - lastPx < 0.35 && i < s.x.length - 1) continue;
        var py = Y(Math.max(yl[0] - (yl[1] - yl[0]), Math.min(yl[1] + (yl[1] - yl[0]), yv)));
        if (!started) { ctx.moveTo(px, py); started = true; } else ctx.lineTo(px, py);
        lastPx = px;
      }
      ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
    });
    // series markers (second channel for identity: one shape per controller), spaced along x
    cfg.series.forEach(function (s, si) {
      if (!s.marker || !s.x.length) return;
      var every = s.markerEvery || 96, next = pad.l + (s.markerOffset != null ? s.markerOffset : 18 + si * 22);
      if (s.x.length <= 40) next = -1;   // few points (a probability curve): mark every point
      for (var i = 0; i < s.x.length; i++) {
        var px = X(s.x[i]), yv = s.y[i]; if (!isFinite(yv) || s.x[i] < xl[0] - 1e-9 || s.x[i] > xl[1] + 1e-9) continue;
        if (next >= 0 && px < next) continue;
        marker(ctx, s.marker, px, Y(Math.max(yl[0], Math.min(yl[1], yv))), 8, s.color);
        if (next >= 0) next = px + every;
      }
    });
    (cfg.markers || []).forEach(function (m) {
      var px = X(m.x), py = Y(m.y);
      ctx.fillStyle = m.color || "#fff";
      if (m.shape === "x") { ctx.strokeStyle = m.color; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(px - 5, py - 5); ctx.lineTo(px + 5, py + 5); ctx.moveTo(px + 5, py - 5); ctx.lineTo(px - 5, py + 5); ctx.stroke(); }
      else if (m.shape) marker(ctx, m.shape, px, py, m.r ? m.r * 2 : 8, m.color);
      else { ctx.beginPath(); ctx.arc(px, py, m.r || 4, 0, 2 * Math.PI); ctx.fill(); }
      if (m.label) { var al = m.align || "left"; var tw = ctx.measureText(m.label).width; if (al === "right" && px - 8 - tw < pad.l) al = "left"; if (al === "left" && px + 8 + tw > W - pad.r) al = "right"; ctx.textAlign = al; ctx.textBaseline = "bottom"; ctx.fillStyle = C.label; ctx.fillText(m.label, px + (al === "right" ? -8 : 8), py - 6); }
    });
    ctx.restore();
    var info = { X: X, Y: Y, pad: pad, pw: pw, ph: ph, xl: xl, yl: yl, W: W, H: H };
    cv._map = info;
    return info;
  }
  /* scatter of poles in the s-plane */
  function poles(cv, cfg) {
    if (!cv) return;
    cv._cfg = cfg; cv._kind = "poles"; if (reg.indexOf(cv) < 0) reg.push(cv);
    var series = cfg.sets.map(function (st) { return { x: [], y: [], color: st.color }; });
    var mk = [];
    cfg.sets.forEach(function (st) { st.p.forEach(function (r) { mk.push({ x: r[0], y: r[1], color: st.color, shape: st.shape || "x" }); }); });
    var xs = mk.map(function (m) { return m.x; }), ys = mk.map(function (m) { return m.y; });
    var xl = [Math.min.apply(null, xs.concat([-1])) * 1.12, Math.max.apply(null, xs.concat([1])) * 1.25 + 1];
    var ym = Math.max.apply(null, ys.map(Math.abs).concat([1])) * 1.3;
    line(cv, { xlim: xl, ylim: [-ym, ym], series: series, markers: mk, xlabel: "Re s  [1/s]", ylabel: "Im s  [rad/s]", vlines: [{ x: 0, color: "rgba(255,255,255,0.45)", dash: [2, 3], label: "stable ← | → unstable", align: "right", dy: 4 }] });
    cv._cfg = cfg; cv._kind = "poles";
  }
  /* capture-region grid (codes: 2 recovered, 1 recovered but did not settle, 0 fell; -1 not computed) */
  function heat(cv, cfg) {
    if (!cv) return;
    cv._cfg = cfg; cv._kind = "heat"; if (reg.indexOf(cv) < 0) reg.push(cv);
    var S = setup(cv), ctx = S.ctx, W = S.w, H = S.h, small = W < 300;
    var pad = { l: small ? 40 : 46, r: 10, t: 10, b: 34 }, pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
    ctx.clearRect(0, 0, W, H);
    var nx = cfg.nx, ny = cfg.ny, cw = pw / nx, ch = ph / ny;
    var fill = { 2: alpha(C.stable, 0.8), 1: alpha(C.warning, 0.8), 0: alpha(C.failure, 0.28) };
    for (var j = 0; j < ny; j++) for (var i = 0; i < nx; i++) {
      var v = cfg.data ? cfg.data[j * nx + i] : -1;
      ctx.fillStyle = fill[v] || "rgba(255,255,255,0.04)";
      ctx.fillRect(pad.l + i * cw, pad.t + (ny - 1 - j) * ch, Math.ceil(cw), Math.ceil(ch));
    }
    ctx.strokeStyle = "rgba(255,255,255,0.22)"; ctx.lineWidth = 1; ctx.strokeRect(pad.l + 0.5, pad.t + 0.5, pw, ph);
    ctx.font = "500 10px " + C.mono; ctx.fillStyle = C.tick;
    function X(x) { return pad.l + (x - cfg.xr[0]) / (cfg.xr[1] - cfg.xr[0]) * pw; }
    function Y(y) { return pad.t + ph - (y - cfg.yr[0]) / (cfg.yr[1] - cfg.yr[0]) * ph; }
    ctx.textAlign = "center"; ctx.textBaseline = "top";
    cfg.xt.forEach(function (v) { ctx.fillText(String(v).replace("-", "−"), X(v), pad.t + ph + 6); });
    ctx.textAlign = "right"; ctx.textBaseline = "middle";
    cfg.yt.forEach(function (v) { ctx.fillText(String(v).replace("-", "−"), pad.l - 5, Y(v)); });
    ctx.textAlign = "right"; ctx.textBaseline = "bottom"; ctx.fillStyle = C.label; ctx.fillText(cfg.xlabel, W - pad.r, H - 2);
    ctx.save(); ctx.translate(10, pad.t + ph / 2); ctx.rotate(-Math.PI / 2); ctx.textAlign = "center"; ctx.textBaseline = "top"; ctx.fillText(cfg.ylabel, 0, 0); ctx.restore();
    (cfg.vlines || []).forEach(function (x) { ctx.strokeStyle = "rgba(255,255,255,0.6)"; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.moveTo(X(x), pad.t); ctx.lineTo(X(x), pad.t + ph); ctx.stroke(); ctx.setLineDash([]); });
  }
  /* categorical outcome map: cfg { xs, ys, cells: [{ i, j, code, label }], styles: { code: { fill, glyph } }, xlabel, ylabel }
     returns a map with cellAt(px, py) for hover tooltips */
  function cells(cv, cfg) {
    if (!cv) return;
    cv._cfg = cfg; cv._kind = "cells"; if (reg.indexOf(cv) < 0) reg.push(cv);
    var S = setup(cv), ctx = S.ctx, W = S.w, H = S.h;
    var pad = { l: 54, r: 10, t: 10, b: 38 }, pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
    var nx = cfg.xs.length, ny = cfg.ys.length, cw = pw / nx, ch = ph / ny;
    ctx.clearRect(0, 0, W, H);
    ctx.font = "600 " + Math.max(9, Math.min(13, Math.floor(Math.min(cw, ch) * 0.55))) + "px " + C.mono;
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    (cfg.cells || []).forEach(function (c) {
      var st = (cfg.styles && cfg.styles[c.code]) || { fill: "rgba(255,255,255,0.04)", glyph: "" };
      var x = pad.l + c.i * cw, y = pad.t + (ny - 1 - c.j) * ch;
      ctx.fillStyle = st.fill; ctx.fillRect(x + 1, y + 1, Math.max(1, cw - 2), Math.max(1, ch - 2));   // 2 px surface gap between cells
      if (st.glyph && cw >= 14 && ch >= 12) { ctx.fillStyle = st.ink || "rgba(0,0,0,0.75)"; ctx.fillText(st.glyph, x + cw / 2, y + ch / 2 + 0.5); }
    });
    ctx.strokeStyle = C.axis; ctx.lineWidth = 1; ctx.strokeRect(pad.l + 0.5, pad.t + 0.5, pw, ph);
    ctx.font = "500 10px " + C.mono; ctx.fillStyle = C.tick;
    var stepX = Math.max(1, Math.ceil(nx / Math.max(2, Math.floor(pw / 44)))), stepY = Math.max(1, Math.ceil(ny / Math.max(2, Math.floor(ph / 22))));
    ctx.textAlign = "center"; ctx.textBaseline = "top";
    cfg.xs.forEach(function (v, i) { if (i % stepX) return; ctx.fillText(fmtNum(v), pad.l + (i + 0.5) * cw, pad.t + ph + 6); });
    ctx.textAlign = "right"; ctx.textBaseline = "middle";
    cfg.ys.forEach(function (v, j) { if (j % stepY) return; ctx.fillText(fmtNum(v), pad.l - 6, pad.t + (ny - 1 - j + 0.5) * ch); });
    ctx.fillStyle = C.label; ctx.textAlign = "right"; ctx.textBaseline = "bottom"; ctx.fillText(cfg.xlabel || "", W - pad.r, H - 2);
    ctx.save(); ctx.translate(11, pad.t + ph / 2); ctx.rotate(-Math.PI / 2); ctx.textAlign = "center"; ctx.textBaseline = "top"; ctx.fillText(cfg.ylabel || "", 0, 0); ctx.restore();
    var info = { pad: pad, pw: pw, ph: ph, W: W, H: H, cellAt: function (px, py) { var i = Math.floor((px - pad.l) / cw), jj = ny - 1 - Math.floor((py - pad.t) / ch); if (i < 0 || i >= nx || jj < 0 || jj >= ny) return null; return (cfg.cells || []).filter(function (c) { return c.i === i && c.j === jj; })[0] || null; } };
    cv._map = info; return info;
  }
  function fmtNum(v) { var a = Math.abs(v), s = a >= 100 ? v.toFixed(0) : a >= 10 ? (+v.toFixed(1)).toString() : (+v.toFixed(2)).toString(); return s.replace("-", "−"); }
  /* histogram: cfg { edges: [n+1], counts: [n], color, xlabel, ylabel, ymax? } */
  function hist(cv, cfg) {
    if (!cv) return;
    cv._cfg = cfg; cv._kind = "hist"; if (reg.indexOf(cv) < 0) reg.push(cv);
    var S = setup(cv), ctx = S.ctx, W = S.w, H = S.h;
    var pad = { l: 40, r: 10, t: 16, b: 34 }, pw = W - pad.l - pad.r, ph = H - pad.t - pad.b;
    var e = cfg.edges, n = cfg.counts.length, ymax = cfg.ymax || Math.max(1, Math.max.apply(null, cfg.counts));
    var yt = nice(0, ymax, 3);
    if (yt.step < 1) { yt = { ticks: [], step: 1 }; for (var q = 0; q <= Math.ceil(ymax); q++) yt.ticks.push(q); }   // counts: integer ticks only
    ymax = Math.max(ymax, yt.ticks[yt.ticks.length - 1]);
    function X(x) { return pad.l + (x - e[0]) / (e[n] - e[0] || 1) * pw; }
    function Y(y) { return pad.t + ph - y / ymax * ph; }
    ctx.clearRect(0, 0, W, H); ctx.font = "500 10px " + C.mono; ctx.lineWidth = 1;
    ctx.textBaseline = "middle"; ctx.textAlign = "right";
    yt.ticks.forEach(function (v) { var y = Math.round(Y(v)) + 0.5; ctx.strokeStyle = v === 0 ? C.axis : C.grid; ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(W - pad.r, y); ctx.stroke(); ctx.fillStyle = C.tick; ctx.fillText(fmtTick(v, yt.step), pad.l - 6, y); });
    for (var i = 0; i < n; i++) {
      var x0 = X(e[i]) + 1, x1 = X(e[i + 1]) - 1, y = Y(cfg.counts[i]);
      if (cfg.counts[i] > 0) { ctx.fillStyle = cfg.color; ctx.beginPath(); var w = Math.max(1, x1 - x0), h = pad.t + ph - y, r = Math.min(3, w / 2, h); ctx.moveTo(x0, pad.t + ph); ctx.lineTo(x0, y + r); ctx.quadraticCurveTo(x0, y, x0 + r, y); ctx.lineTo(x0 + w - r, y); ctx.quadraticCurveTo(x0 + w, y, x0 + w, y + r); ctx.lineTo(x0 + w, pad.t + ph); ctx.closePath(); ctx.fill(); }
    }
    ctx.fillStyle = C.tick; ctx.textAlign = "center"; ctx.textBaseline = "top";
    var xt = nice(e[0], e[n], 4); xt.ticks.forEach(function (v) { if (v < e[0] - 1e-12 || v > e[n] + 1e-12) return; ctx.fillText(fmtTick(v, xt.step), X(v), pad.t + ph + 6); });
    ctx.fillStyle = C.label; ctx.textAlign = "right"; ctx.textBaseline = "bottom"; ctx.fillText(cfg.xlabel || "", W - pad.r, H - 2);
    ctx.textAlign = "left"; ctx.textBaseline = "top"; ctx.fillText(cfg.ylabel || "", 2, 1);
    if (cfg.median != null && isFinite(cfg.median)) { var mx = X(cfg.median); ctx.strokeStyle = C.label; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(mx, pad.t); ctx.lineTo(mx, pad.t + ph); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = C.label; ctx.textAlign = mx > W - 80 ? "right" : "left"; ctx.fillText("median", mx + (mx > W - 80 ? -4 : 4), pad.t); }
    var info = { X: X, Y: Y, pad: pad, pw: pw, ph: ph, W: W, H: H, binAt: function (px) { for (var k = 0; k < n; k++) if (px >= X(e[k]) && px < X(e[k + 1])) return k; return -1; } };
    cv._map = info; return info;
  }
  function redraw(cv) { if (!cv || !cv._cfg) return; var k = cv._kind; if (k === "line") line(cv, cv._cfg); else if (k === "heat") heat(cv, cv._cfg); else if (k === "poles") poles(cv, cv._cfg); else if (k === "cells") cells(cv, cv._cfg); else if (k === "hist") hist(cv, cv._cfg); }
  var t = null;
  if (typeof window !== "undefined") window.addEventListener("resize", function () { clearTimeout(t); t = setTimeout(function () { reg.forEach(function (cv) { if (cv.offsetParent) redraw(cv); }); }, 150); });
  /* PNG of a chart (for export); null where the canvas cannot be read */
  function png(cv) { try { return cv.toDataURL("image/png"); } catch (e) { return null; } }
  return { line: line, heat: heat, poles: poles, cells: cells, hist: hist, marker: marker, redraw: redraw, png: png, redrawVisible: function (root) { reg.forEach(function (cv) { if (root.contains(cv)) redraw(cv); }); } };
})();

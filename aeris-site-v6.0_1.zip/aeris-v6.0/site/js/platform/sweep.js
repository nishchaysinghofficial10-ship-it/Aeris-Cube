/* =====================================================================
   AERIS · RESEARCH SWEEP — the data model for parameter-range experiments
   (aeris-sweep/1): what is varied, what is held fixed, what is measured;
   validation; expansion into individual runs; and the analysis that turns
   run outcomes into maps, distributions and probabilities.

   Nothing here simulates. An adapter executes the expanded runs (the local
   browser engine for small sweeps, the research backend for large ones) and
   hands the per-run outcomes back to analyze(). Every number in an analysis
   is computed from those outcomes; nothing is estimated or filled in.
   ===================================================================== */
var AERIS_SWEEP = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var IDS = typeof AERIS_IDS !== "undefined" ? AERIS_IDS : require("./ids.js");
  var CFG = typeof AERIS_CFG !== "undefined" ? AERIS_CFG : require("./config.js");
  var SCHEMA_ID = "aeris-sweep/1";

  /* ---------------- independent variables ---------------- */
  function setDisturbance(c, v, def) {
    var tpl = (def && def.disturbance) || {};
    var a = c.params.a;
    c.disturbances = (c.disturbances || []).filter(function (L) { return L.id !== "SWEEP-F"; });
    if (v > 0) c.disturbances.push({ id: "SWEEP-F", type: "force", magnitude_N: v, point_m: tpl.point_m || (c.mode === "edge" ? [a / 2, a, a] : [a, a, a]), direction: tpl.direction || (c.mode === "edge" ? [0, 1, 0] : [1, 0.4, 0]), frame: tpl.frame || "world", t_start_s: tpl.t_start_s != null ? tpl.t_start_s : 1, duration_s: tpl.duration_s != null ? tpl.duration_s : 0.2 });
  }
  var VARIABLES = {
    com_x_mm: { label: "COM shift x (body)", unit: "mm", min: -50, max: 50, def: [-30, 30], apply: function (c, v) { c.comShift_m[0] = v / 1000; }, note: { edge: "Along the support edge: moves the COM toward one end of the edge but does not change the balance angle." } },
    com_y_mm: { label: "COM shift y (body)", unit: "mm", min: -50, max: 50, def: [-30, 30], apply: function (c, v) { c.comShift_m[1] = v / 1000; } },
    com_z_mm: { label: "COM shift z (body)", unit: "mm", min: -50, max: 50, def: [-30, 30], apply: function (c, v) { c.comShift_m[2] = v / 1000; } },
    tilt_deg: { label: "Initial tilt", unit: "°", min: -30, max: 30, def: [0, 25], apply: function (c, v) { c.initial.tilt_deg = v; } },
    rate_dps: { label: "Initial angular velocity", unit: "°/s", min: -200, max: 200, def: [-60, 60], apply: function (c, v) { c.initial.rate_dps = v; } },
    torque_pct: { label: "Torque limit", unit: "% of nominal", min: 20, max: 200, def: [40, 100], apply: function (c, v) { c.torqueScale = v / 100; } },
    rpm_limit: { label: "Wheel speed limit", unit: "rpm", min: 100, max: 30000, def: [1500, 5000], apply: function (c, v) { c.params.wmaxRpm = v; } },
    disturbance_N: { label: "Push magnitude", unit: "N", min: 0, max: 5, def: [0, 1], apply: setDisturbance },
    noise_scale: { label: "Sensor noise", unit: "× nominal", min: 0, max: 10, def: [0.5, 4], apply: function (c, v) { c.sensor.gyro_noise_dps = TWIN.SENSOR_DEFAULTS.gyro_noise_dps * v; c.sensor.accel_noise_mps2 = TWIN.SENSOR_DEFAULTS.accel_noise_mps2 * v; }, note: { ideal: "Has no effect with ideal sensing; choose an estimator in the base setup.", corner: "Has no effect in corner mode (ideal state feedback in the browser engine)." } },
    inertia_scale: { label: "True inertia (model mismatch)", unit: "× model", min: 0.5, max: 2, def: [0.7, 1.5], apply: function (c, v) { c.uncertainty.inertiaScale = v; } }
  };
  var VARIABLE_ORDER = ["com_x_mm", "com_y_mm", "com_z_mm", "tilt_deg", "rate_dps", "torque_pct", "rpm_limit", "disturbance_N", "noise_scale", "inertia_scale"];
  /* mass configurations: point-mass sets placed at fractions of the edge length (replace the base setup's attachments) */
  var MASS_CONFIGS = {
    base: { label: "As in the base setup", masses: null },
    none: { label: "No added mass", masses: [] },
    top50: { label: "50 g on the top corner", masses: [{ id: "S1", label: "50 g top", mass_kg: 0.05, pos_f: [1, 1, 1] }] },
    face100: { label: "100 g on the +y face", masses: [{ id: "S1", label: "100 g face", mass_kg: 0.1, pos_f: [0.5, 1, 0.5] }] },
    asym2x60: { label: "Two 60 g masses, asymmetric", masses: [{ id: "S1", label: "60 g A", mass_kg: 0.06, pos_f: [0.2, 0.9, 1] }, { id: "S2", label: "60 g B", mass_kg: 0.06, pos_f: [1, 0.3, 0.8] }] }
  };
  /* measured (dependent) variables recorded for every run */
  var MEASURES = [
    { key: "outcome", label: "Outcome", unit: "" }, { key: "settle_s", label: "Settling time", unit: "s" }, { key: "rmsLean_deg", label: "RMS attitude error", unit: "°" },
    { key: "peakLean_deg", label: "Peak COM lean", unit: "°" }, { key: "peakOmega_rpm", label: "Peak wheel speed", unit: "rpm" }, { key: "effort_Nms", label: "Control effort", unit: "N·m·s" },
    { key: "torqueLimited_s", label: "Torque-saturated time", unit: "s" }, { key: "speedLimited_s", label: "Speed-limited time", unit: "s" }, { key: "leanMargin_deg", label: "Lean margin", unit: "°" }, { key: "energy_J", label: "Energy", unit: "J" }
  ];
  var MODES = { grid: "Grid: every combination of evenly spaced values", random: "Random: uniformly sampled points (seeded)", montecarlo: "Monte Carlo: samples from the stated distributions (a normal variable is truncated to [min, max] by redrawing, at most 100 draws; a sample still outside is placed at the bound and flagged 'clipped'), with a different sensor-noise seed per sample" };
  /* the browser's normal sampler: rejection within [min, max]; after 100 failed draws the value is placed at the bound
     and FLAGGED, because such a sample is no longer from the truncated normal distribution */
  var NORMAL_TRIES = 100;
  function erf(x) { var t = 1 / (1 + 0.3275911 * Math.abs(x)), y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return x >= 0 ? y : -y; }
  function Phi(z) { return 0.5 * (1 + erf(z / Math.SQRT2)); }
  function acceptance(v) { return Phi((v.max - v.mean) / v.sd) - Phi((v.min - v.mean) / v.sd); }
  /* the browser engine's own limits; the research backend's limits are only what GET /capabilities reports (never guessed here) */
  var LIMITS = { local: { maxRuns: 400, maxDuration_s: 10 } };
  /* v4 (sweep revision 1.1, docs/SCHEMA_EXTENSIONS.md): the research backend also accepts
       dist "bounded-normal"  exact truncated normal on [min, max] (inverse-CDF sampling),
       dist "normal"          in a revision-1.1 definition: UNtruncated; samples outside [min, max] become
                              invalid rows (kept, not run, never clipped); a definition without a revision
                              keeps the browser meaning and the backend samples it as "bounded-normal",
       dist "categorical"     values[] with optional probabilities[],
       variables by configuration "path", seed_strategy (paired | legacy | fixed | independent),
       estimators[], store_runs, limits.
     These fields are preserved here; the browser engine refuses them (validate) instead of ignoring them. */
  var DISTS = ["uniform", "normal", "bounded-normal", "categorical"], SEED_STRATEGIES = ["paired", "legacy", "fixed", "independent"];
  /* sweep revision 1.2 (v5): the declared success criterion used by every rate, paired test and map (research backend) */
  var CRITERIA = ["legacy", "research", "research_sustained"];
  var CRITERION_LABEL = { legacy: "Legacy outcome 'Recovered' (browser rule)", research: "Research recovery criteria met by the deadline", research_sustained: "Research criteria met and held to the end (no later exit)" };
  function ident(v) { return v.key || v.path; }

  /* ---------------- definition ---------------- */
  function defaultSweep(base) {
    var b = CFG.normalize(base || TWIN.defaultConfig("edge"));   // v4: research fields of the base setup are kept
    return {
      schema: SCHEMA_ID, id: null, name: "", created: null, base: b, mode: "grid", seed: 1, samples: 60,
      controllers: ["pid", "lqr", "adp"], mass_configs: ["base"],
      variables: [{ key: "tilt_deg", min: 0, max: 20, steps: 6, dist: "uniform" }, { key: "rate_dps", min: -40, max: 40, steps: 5, dist: "uniform" }],
      disturbance: null, duration_s: Math.min(b.duration_s, 5), record_hz: 10
    };
  }
  function num(x) { var v = typeof x === "string" ? parseFloat(x) : x; return typeof v === "number" ? v : NaN; }
  function normalize(def) {
    var d = def || {}, o = defaultSweep(d.base);
    ["id", "name", "created"].forEach(function (k) { if (d[k] != null) o[k] = d[k]; });
    if (d.mode) o.mode = String(d.mode);
    if (d.seed !== undefined) o.seed = Math.round(num(d.seed));
    if (d.samples !== undefined) o.samples = Math.round(num(d.samples));
    if (Array.isArray(d.controllers)) o.controllers = d.controllers.map(String);
    if (Array.isArray(d.mass_configs)) o.mass_configs = d.mass_configs.map(String);
    if (Array.isArray(d.variables)) o.variables = d.variables.map(function (v) {
      var x = { key: v.key != null ? String(v.key) : null, min: num(v.min), max: num(v.max), steps: v.steps != null ? Math.round(num(v.steps)) : 5, dist: v.dist == null ? "uniform" : String(v.dist), mean: v.mean != null ? num(v.mean) : null, sd: v.sd != null ? num(v.sd) : null };
      if (v.path != null) x.path = String(v.path);
      if (v.label != null) x.label = String(v.label);
      if (v.unit != null) x.unit = String(v.unit);
      if (Array.isArray(v.values)) x.values = v.values.slice();
      if (Array.isArray(v.probabilities)) x.probabilities = v.probabilities.map(num);
      return x;
    });
    ["revision", "seed_strategy", "store_runs", "limits", "parameter_set", "criterion"].forEach(function (k) { if (d[k] != null) o[k] = TWIN.clone(d[k]); });
    if (Array.isArray(d.estimators)) o.estimators = d.estimators.map(String);
    if (d.disturbance !== undefined) o.disturbance = d.disturbance;
    if (d.duration_s !== undefined) o.duration_s = num(d.duration_s);
    if (d.record_hz !== undefined) o.record_hz = num(d.record_hz);
    return o;
  }
  function pointCount(d) {
    if (d.mode === "grid") return d.variables.reduce(function (p, v) { return p * (v.dist === "categorical" && Array.isArray(v.values) ? v.values.length : Math.max(1, v.steps || 1)); }, 1);
    return d.samples;
  }
  function totalRuns(d) { return pointCount(d) * d.controllers.length * d.mass_configs.length * (d.estimators && d.estimators.length ? d.estimators.length : 1); }
  function validate(defIn, opts) {
    opts = opts || {};
    var d = normalize(defIn), E = [], W = [], lim = opts.limits || LIMITS.local, engine = opts.engine || "browser";
    var backend = engine === "backend", sc = backend && opts.caps && opts.caps.sweep ? opts.caps.sweep : null;
    var allowedCtl = sc && sc.controllers ? sc.controllers : ["pid", "lqr", "adp"];
    function onlyBackend(path, what) { E.push({ path: path, kind: "capability", message: what + " is a research-backend feature (sweep revision 1.1); the browser engine cannot run it. Switch to Simulation mode or remove it." }); }
    if (!backend) {
      if (d.seed_strategy != null && d.seed_strategy !== "legacy") onlyBackend("seed_strategy", "Seed strategy '" + d.seed_strategy + "'");
      if (d.estimators) onlyBackend("estimators", "Varying the estimator");
      if (d.store_runs) onlyBackend("store_runs", "Storing every sweep run");
      if (d.parameter_set) onlyBackend("parameter_set", "Applying a stored parameter set");
      if (d.criterion != null && d.criterion !== "legacy") onlyBackend("criterion", "Success criterion '" + d.criterion + "' (research recovery criteria)");
    } else {
      if (d.criterion != null && CRITERIA.indexOf(d.criterion) < 0) E.push({ path: "criterion", message: "Success criterion must be legacy, research or research_sustained." });
      else if (d.criterion != null && d.criterion !== "legacy" && sc && !(Array.isArray(sc.criteria) && sc.criteria.indexOf(d.criterion) >= 0))
        E.push({ path: "criterion", kind: "capability", message: "The research backend did not report success criterion '" + d.criterion + "' (sweep revision 1.2); an older backend would analyse with the legacy rule. Update the backend or use 'legacy'." });
      if (d.seed_strategy != null && SEED_STRATEGIES.indexOf(d.seed_strategy) < 0) E.push({ path: "seed_strategy", message: "Seed strategy must be paired, legacy, fixed or independent." });
      var reported = sc && sc.seed_strategies ? (Array.isArray(sc.seed_strategies) ? sc.seed_strategies : Object.keys(sc.seed_strategies)) : null;   // list, or {name: description}
      if (reported && d.seed_strategy != null && reported.indexOf(d.seed_strategy) < 0) E.push({ path: "seed_strategy", kind: "capability", message: "The research backend did not report seed strategy '" + d.seed_strategy + "'." });
      if (d.revision == null) W.push({ path: "revision", message: "Definition without a revision: the backend reads it as revision 1.0 (seed strategy 'legacy'; a 'normal' variable is sampled as 'bounded-normal', the exact truncated normal)." });
    }
    var bi = (d.base && d.base.initial) || {};
    d.variables.forEach(function (v, i) {
      if (v.key === "tilt_deg" && bi.attitude_q != null) E.push({ path: "variables." + i, message: "tilt_deg varies the legacy initial tilt, but the base setup gives an explicit initial attitude quaternion; vary a component of initial.attitude_q by path instead." });
      if (v.key === "rate_dps" && bi.body_rate_dps != null) E.push({ path: "variables." + i, message: "rate_dps varies the legacy initial rate, but the base setup gives an explicit body-rate vector; vary initial.body_rate_dps.<i> by path instead." });
    });
    if (!MODES[d.mode]) E.push({ path: "mode", message: "Sweep mode must be grid, random or montecarlo." });
    if (!d.controllers.length) E.push({ path: "controllers", message: "Choose at least one controller." });
    d.controllers.forEach(function (c) { if (allowedCtl.indexOf(c) < 0) E.push({ path: "controllers", message: "Controller '" + c + "' is not available on " + (engine === "backend" ? "the research backend" : "the browser engine") + "." }); });
    if (!d.mass_configs.length) E.push({ path: "mass_configs", message: "Choose at least one mass configuration." });
    d.mass_configs.forEach(function (m) { if (!MASS_CONFIGS[m]) E.push({ path: "mass_configs", message: "Unknown mass configuration '" + m + "'." }); });
    if (!d.variables.length) E.push({ path: "variables", message: "Vary at least one parameter; with nothing varied this is a single experiment." });
    var seen = {};
    d.variables.forEach(function (v, i) {
      var V = v.key ? VARIABLES[v.key] : null, path = "variables." + i, id = ident(v);
      if (DISTS.indexOf(v.dist) < 0) { E.push({ path: path + ".dist", message: "Unknown distribution '" + v.dist + "' (uniform, normal, bounded-normal, categorical)." }); return; }
      if (!backend && (v.path || v.dist === "bounded-normal" || v.dist === "categorical")) { onlyBackend(path, v.path ? "A variable given by configuration path (" + v.path + ")" : "The '" + v.dist + "' distribution"); return; }
      if (!v.key && !v.path) { E.push({ path: path, message: "A variable needs a 'key' (named variable) or a 'path' (configuration path)." }); return; }
      if (seen[id]) E.push({ path: path, message: id + " is listed twice." }); seen[id] = 1;
      if (!V) {
        if (v.key) { E.push({ path: path, message: "Unknown variable '" + v.key + "'." }); return; }
        // configuration path (backend): checked authoritatively by the backend on submission
        if (v.dist === "categorical") { if (!(Array.isArray(v.values) && v.values.length)) E.push({ path: path, message: id + ": a categorical variable needs a non-empty 'values' list." }); }
        else if (!(isFinite(v.min) && isFinite(v.max) && v.max > v.min)) E.push({ path: path, message: id + ": the range needs two numbers with the upper end above the lower end." });
        if (v.dist === "bounded-normal" || v.dist === "normal") { if (!(isFinite(v.mean) && isFinite(v.sd) && v.sd > 0)) E.push({ path: path, message: id + ": a normal distribution needs a mean and a positive standard deviation." }); }
        return;
      }
      if (v.dist === "categorical") {
        if (!(Array.isArray(v.values) && v.values.length)) E.push({ path: path, message: V.label + ": a categorical variable needs a non-empty 'values' list." });
        else if (v.values.some(function (x) { return !(typeof x === "number" && isFinite(x) && x >= V.min && x <= V.max); })) E.push({ path: path, message: V.label + ": categorical values must be numbers within " + V.min + " to " + V.max + " " + V.unit + "." });
        if (v.probabilities && !(v.probabilities.length === (v.values || []).length && Math.abs(v.probabilities.reduce(function (a, b) { return a + b; }, 0) - 1) < 1e-9)) E.push({ path: path, message: V.label + ": 'probabilities' must match 'values' and sum to 1." });
        return;
      }
      if (!(isFinite(v.min) && isFinite(v.max))) E.push({ path: path, message: V.label + ": the range needs two numbers." });
      else if (!(v.max > v.min)) E.push({ path: path, message: V.label + ": the upper end must be above the lower end." });
      else if (v.min < V.min || v.max > V.max) E.push({ path: path, message: V.label + ": the range must lie within " + V.min + " to " + V.max + " " + V.unit + "." });
      if (d.mode === "grid" && !(v.steps >= 2 && v.steps <= 50)) E.push({ path: path, message: V.label + ": a grid needs 2 to 50 values per variable." });
      var isNormal = v.dist === "normal" || v.dist === "bounded-normal";
      if (d.mode === "montecarlo" && isNormal && !(isFinite(v.mean) && isFinite(v.sd) && v.sd > 0)) E.push({ path: path, message: V.label + ": a normal distribution needs a mean and a positive standard deviation." });
      else if (d.mode === "montecarlo" && backend && isNormal && isFinite(v.min) && isFinite(v.max) && v.max > v.min) {
        var pb = acceptance(v);
        if (v.dist === "bounded-normal" && pb < 1e-12) E.push({ path: path, message: V.label + ": [" + v.min + ", " + v.max + "] holds only " + pb.toExponential(1) + " of N(" + v.mean + ", " + v.sd + "); the truncated normal is numerically meaningless there." });
        if (v.dist === "normal" && (d.revision === "1.1" || d.revision === "1.2") && pb < 0.999) W.push({ path: path, message: V.label + ": about " + ((1 - pb) * 100).toFixed(1) + " % of N(" + v.mean + ", " + v.sd + ") lies outside [" + v.min + ", " + v.max + "]; those samples become invalid rows (kept and reported, not run, not clipped). Use 'bounded-normal' for the truncated distribution." });
      }
      else if (d.mode === "montecarlo" && v.dist === "normal" && engine === "browser") {
        var pa = acceptance(v), pFail = Math.pow(1 - pa, NORMAL_TRIES), expected = pFail * d.samples;
        if (pa < 1e-9) E.push({ path: path, message: V.label + ": [" + v.min + ", " + v.max + "] holds only " + pa.toExponential(1) + " of N(" + v.mean + ", " + v.sd + "); the truncated distribution cannot be sampled here." });
        else if (expected > 0.01) W.push({ path: path, message: V.label + ": [" + v.min + ", " + v.max + "] holds " + (pa * 100).toFixed(1) + " % of the normal distribution, so about " + (expected < 1 ? expected.toFixed(2) : Math.round(expected)) + " sample(s) may still be outside after " + NORMAL_TRIES + " draws. Such samples are placed at the bound and flagged 'clipped'; they are not from the truncated normal. The research backend samples the exact truncated normal ('bounded-normal')." });
      }
      var mode = d.base.mode, noEffect = null;
      if (V.note && V.note[mode]) noEffect = V.note[mode];
      if (v.key === "noise_scale" && d.base.estimator.type === "ideal") noEffect = V.note.ideal;
      if (noEffect) W.push({ path: path, message: V.label + ": " + noEffect });
      if ((v.key === "rate_dps" || v.key === "tilt_deg") && d.base.mode === "corner") W.push({ path: path, message: V.label + " is applied about the tilt direction set in the base setup (" + d.base.initial.azimuth_deg + "°)." });
    });
    if ((d.mode === "random" || d.mode === "montecarlo") && !(d.samples >= 1 && d.samples <= 100000)) E.push({ path: "samples", message: "Number of samples must be between 1 and 100 000." });
    if (!isFinite(d.seed)) E.push({ path: "seed", message: "Seed must be an integer." });
    if (!(d.duration_s >= 1 && d.duration_s <= lim.maxDuration_s)) E.push({ path: "duration_s", message: "Observation window must be between 1 and " + lim.maxDuration_s + " s for this engine." });
    var base = CFG.validateFor(d.base, engine, opts.caps);
    if (!base.ok) base.errors.forEach(function (e) { E.push({ path: "base." + e.path, message: "Base setup: " + e.message }); });
    var total = E.length ? 0 : totalRuns(d);
    if (!E.length && total > lim.maxRuns) E.push({ path: "samples", message: total.toLocaleString("en-GB") + " runs is more than this engine accepts (" + lim.maxRuns.toLocaleString("en-GB") + "). Reduce the grid or the sample count, or submit it to the research backend (Simulation mode)." });
    return { ok: E.length === 0, errors: E, warnings: W, def: d, total: total, points: E.length ? 0 : pointCount(d) };
  }

  /* ---------------- expansion into runs ---------------- */
  function rng(seed) { return TWIN.rng(seed); }
  function linspace(a, b, n) { if (n === 1) return [a]; var out = []; for (var i = 0; i < n; i++) out.push(a + (b - a) * i / (n - 1)); return out; }
  function points(d) {
    var P = [];
    if (d.mode === "grid") {
      var axes = d.variables.map(function (v) { return linspace(v.min, v.max, v.steps).map(function (x) { return +x.toPrecision(10); }); });
      (function rec(i, cur) { if (i === axes.length) { P.push(cur.slice()); return; } axes[i].forEach(function (x) { cur.push(x); rec(i + 1, cur); cur.pop(); }); })(0, []);
    } else {
      var R = rng(d.seed >>> 0);
      P.clipped = [];
      for (var k = 0; k < d.samples; k++) P.push(d.variables.map(function (v) {
        if (d.mode === "montecarlo" && v.dist === "normal") {
          var x; var tries = 0; do { x = v.mean + v.sd * R.n(); tries++; } while ((x < v.min || x > v.max) && tries < NORMAL_TRIES);
          if (x < v.min || x > v.max) P.clipped.push({ point: k, key: v.key, drawn: x });
          return +Math.max(v.min, Math.min(v.max, x)).toPrecision(10);
        }
        return +(v.min + (v.max - v.min) * R.u()).toPrecision(10);
      }));
    }
    return P;
  }
  function applyMass(c, key) {
    var M = MASS_CONFIGS[key]; if (!M || !M.masses) return;
    var a = c.params.a;
    c.attachments = M.masses.map(function (m) { return { id: m.id, label: m.label, mass_kg: m.mass_kg, pos_m: m.pos_f.map(function (f) { return +(f * a).toPrecision(10); }) }; });
  }
  function expand(defIn) {
    var d = normalize(defIn), P = points(d), runs = [], idx = 0, clippedAt = {};
    (P.clipped || []).forEach(function (c) { (clippedAt[c.point] = clippedAt[c.point] || []).push(c); });
    P.forEach(function (pt, pi) {
      d.mass_configs.forEach(function (mk) {
        d.controllers.forEach(function (ck) {
          var c = CFG.normalize(TWIN.clone(d.base));
          c.duration_s = d.duration_s; c.record_hz = d.record_hz; c.controller.type = ck;
          applyMass(c, mk);
          var values = {};
          d.variables.forEach(function (v, j) { values[v.key] = pt[j]; VARIABLES[v.key].apply(c, pt[j], d); });
          if (d.mode === "montecarlo") c.seed = (d.seed + pi) >>> 0;
          var spec = { index: idx++, point: pi, controller: ck, mass_config: mk, values: values, seed: c.seed, config: c };
          if (clippedAt[pi]) spec.clipped = clippedAt[pi].map(function (x) { return { key: x.key, drawn: x.drawn }; });
          runs.push(spec);
        });
      });
    });
    return runs;
  }
  /* reduce one simulation result to the row stored with the sweep */
  function rowOf(spec, res) {
    var m = res && res.metrics ? res.metrics : null, code = res && res.outcome ? res.outcome.code : "invalid";
    var row = { index: spec.index, point: spec.point, controller: spec.controller, mass_config: spec.mass_config, values: spec.values, seed: spec.seed, outcome: code, saturated: false, metrics: null, reason: code === "invalid" ? (res && res.outcome && res.outcome.reason) || "invalid" : null };
    if (spec.clipped) row.clipped = spec.clipped;
    if (m) {
      row.metrics = {};
      MEASURES.forEach(function (x) { if (x.key !== "outcome") row.metrics[x.key] = m[x.key] != null && isFinite(m[x.key]) ? +(+m[x.key]).toPrecision(6) : null; });
      row.saturated = (m.torqueLimited_s || 0) > 0 || (m.speedLimited_s || 0) > 0;
    }
    return row;
  }

  /* ---------------- analysis (computed only from the rows) ---------------- */
  function wilson(k, n) { if (!n) return [0, 1]; var z = 1.96, p = k / n, den = 1 + z * z / n, c = (p + z * z / (2 * n)) / den, h = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den; return [Math.max(0, c - h), Math.min(1, c + h)]; }
  function histogram(vals, bins, lo, hi) {
    var n = bins, w = (hi - lo) / n || 1, counts = new Array(n).fill(0);
    vals.forEach(function (v) { var i = Math.floor((v - lo) / w); if (i < 0) i = 0; if (i >= n) i = n - 1; counts[i]++; });
    return { lo: lo, hi: hi, width: w, counts: counts };
  }
  var CELL = { recovered: 2, not_settled: 1, drifting: 1, fallen: 0, invalid: -2 };
  function analyze(defIn, rows) {
    var d = normalize(defIn), out = { schema: "aeris-sweep-analysis/1", computed_from: rows.length + " runs", controllers: {}, maps: [], distributions: {}, probability: [], boundaries: {}, labels: [],
      notes: ["Recovery rates are the fraction of SIMULATED runs that recovered under this sweep's sampling; they are not hardware reliability estimates."] };
    var nClip = rows.filter(function (r) { return r.clipped; }).length;
    if (nClip) out.notes.push(nClip + " run(s) used a normal sample that was still outside [min, max] after " + NORMAL_TRIES + " draws and was placed at the bound (flagged 'clipped'); those values are not from the truncated normal distribution.");
    out.sampling = { clipped_runs: nClip };
    d.controllers.forEach(function (c) {
      var R = rows.filter(function (r) { return r.controller === c; }), k = R.filter(function (r) { return r.outcome === "recovered"; }).length, cnt = {};
      R.forEach(function (r) { cnt[r.outcome] = (cnt[r.outcome] || 0) + 1; });
      var valid = R.filter(function (r) { return r.outcome !== "invalid"; }).length;
      out.controllers[c] = { n: R.length, valid: valid, recovered: k, rate: valid ? k / valid : null, ci95: wilson(k, valid), counts: cnt, saturatedRecoveries: R.filter(function (r) { return r.outcome === "recovered" && r.saturated; }).length };
    });
    // 2-D maps: for grid sweeps, one map per pair of varied variables (the first pair, plus the named research maps when present)
    var keys = d.variables.map(ident);
    function pairMap(xk, yk, title) {
      var xs = uniq(rows.map(function (r) { return r.values[xk]; })), ys = uniq(rows.map(function (r) { return r.values[yk]; }));
      var per = {};
      d.controllers.forEach(function (c) {
        var cells = [];
        ys.forEach(function (y, j) { xs.forEach(function (x, i) {
          var R = rows.filter(function (r) { return r.controller === c && r.values[xk] === x && r.values[yk] === y; });
          if (!R.length) { cells.push({ i: i, j: j, x: x, y: y, n: 0, code: null }); return; }
          var rec = R.filter(function (r) { return r.outcome === "recovered"; }), inv = R.filter(function (r) { return r.outcome === "invalid"; });
          var code = inv.length === R.length ? "invalid" : rec.length === R.length ? (rec.some(function (r) { return r.saturated; }) ? "recovered_saturated" : "recovered") : rec.length ? "mixed" : R.some(function (r) { return r.outcome === "fallen"; }) ? "fallen" : "not_recovered";
          cells.push({ i: i, j: j, x: x, y: y, n: R.length, recovered: rec.length, code: code });
        }); });
        per[c] = cells;
      });
      return { x: xk, y: yk, xs: xs, ys: ys, title: title, cells: per, aggregated_over: d.variables.length > 2 || d.mass_configs.length > 1 ? "other varied parameters and mass configurations (a cell is 'recovered' only if every run in it recovered)" : null };
    }
    function uniq(a) { var s = []; a.forEach(function (v) { if (s.indexOf(v) < 0) s.push(v); }); return s.sort(function (p, q) { return p - q; }); }
    if (d.mode === "grid" && keys.length >= 2) {
      var named = [["tilt_deg", "rate_dps", "Domain of attraction"], ["com_x_mm", "com_y_mm", "COM stability map"], ["torque_pct", "tilt_deg", "Saturation map"], ["com_y_mm", "com_z_mm", "COM stability map (y–z)"]];
      named.forEach(function (nm) { if (keys.indexOf(nm[0]) >= 0 && keys.indexOf(nm[1]) >= 0) out.maps.push(pairMap(nm[0], nm[1], nm[2])); });
      if (!out.maps.length) out.maps.push(pairMap(keys[0], keys[1], "Outcome map"));
    }
    // distributions over recovered (settling) and all valid runs
    [["settle_s", "recovered"], ["rmsLean_deg", "valid"], ["peakOmega_rpm", "valid"], ["effort_Nms", "valid"]].forEach(function (spec) {
      var k = spec[0], pool = rows.filter(function (r) { return r.metrics && r.metrics[k] != null && (spec[1] === "recovered" ? r.outcome === "recovered" : r.outcome !== "invalid"); });
      if (pool.length < 2) return;
      var vals = pool.map(function (r) { return r.metrics[k]; }), lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
      if (hi - lo < 1e-12) hi = lo + 1;
      var bins = Math.max(4, Math.min(16, Math.round(Math.sqrt(pool.length))));
      var per = {};
      d.controllers.forEach(function (c) { var v = pool.filter(function (r) { return r.controller === c; }).map(function (r) { return r.metrics[k]; }); per[c] = { n: v.length, hist: histogram(v, bins, lo, hi), median: median(v) }; });
      out.distributions[k] = { over: spec[1], per: per, lo: lo, hi: hi, bins: bins };
    });
    function median(v) { if (!v.length) return null; var s = v.slice().sort(function (a, b) { return a - b; }), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; }
    // recovery probability against each varied variable
    d.variables.forEach(function (v) {
      var vk = ident(v), vals = rows.map(function (r) { return r.values[vk]; }).filter(function (x) { return typeof x === "number"; }), distinct = uniq(vals);
      if (!distinct.length) return;
      var vmin = isFinite(v.min) ? v.min : distinct[0], vmax = isFinite(v.max) ? v.max : distinct[distinct.length - 1];
      var edges = distinct.length <= 10 ? null : linspace(vmin, vmax, 9);
      var groups = edges ? edges.slice(0, -1).map(function (e0, i) { return { lo: e0, hi: edges[i + 1], x: (e0 + edges[i + 1]) / 2 }; }) : distinct.map(function (x) { return { lo: x, hi: x, x: x }; });
      var per = {};
      d.controllers.forEach(function (c) {
        per[c] = groups.map(function (g, gi) {
          var R = rows.filter(function (r) { var x = r.values[vk]; return r.controller === c && r.outcome !== "invalid" && (edges ? (x >= g.lo && (x < g.hi || (gi === groups.length - 1 && x <= g.hi))) : x === g.x); });
          var k = R.filter(function (r) { return r.outcome === "recovered"; }).length;
          return { x: g.x, lo: g.lo, hi: g.hi, n: R.length, recovered: k, p: R.length ? k / R.length : null, ci95: wilson(k, R.length) };
        });
      });
      out.probability.push({ variable: vk, per: per, binned: !!edges });
    });
    // boundaries: largest |value| that recovered and smallest |value| that did not, per controller and variable
    d.variables.forEach(function (v) {
      var vk = ident(v);
      out.boundaries[vk] = {};
      d.controllers.forEach(function (c) {
        var R = rows.filter(function (r) { return r.controller === c && r.outcome !== "invalid"; });
        var ok = R.filter(function (r) { return r.outcome === "recovered"; }).map(function (r) { return Math.abs(r.values[vk]); });
        var bad = R.filter(function (r) { return r.outcome !== "recovered"; }).map(function (r) { return Math.abs(r.values[vk]); });
        out.boundaries[vk][c] = { maxRecovered: ok.length ? Math.max.apply(null, ok) : null, minNotRecovered: bad.length ? Math.min.apply(null, bad) : null, nRecovered: ok.length, nNot: bad.length };
      });
    });
    // measured labels (never a general ranking): which controller had the highest recovery rate in THIS sweep
    var rated = d.controllers.filter(function (c) { return out.controllers[c].valid > 0; });
    if (rated.length > 1) {
      var best = Math.max.apply(null, rated.map(function (c) { return out.controllers[c].rate; }));
      var top = rated.filter(function (c) { return out.controllers[c].rate === best; });
      out.labels.push({ key: "highest_recovery_rate", controllers: top, value: best, text: "Highest recovery rate in this sweep", tie: top.length > 1 });
    }
    return out;
  }
  /* summary lines computed from an analysis, for the results panel */
  function summarize(an) {
    return Object.keys(an.controllers).map(function (c) { var s = an.controllers[c]; return { controller: c, text: s.recovered + " of " + s.valid + " valid runs recovered" + (s.valid < s.n ? " (" + (s.n - s.valid) + " invalid configurations)" : "") + (s.saturatedRecoveries ? "; " + s.saturatedRecoveries + " of those went through saturation" : "") }; });
  }
  function newId(taken) { return IDS.nextSweep(taken || []); }
  /* rows as CSV: one line per run, varied values and measured metrics with units */
  function toCSV(sw) {
    var d = sw.definition, vars = d.variables.map(ident), ms = MEASURES.filter(function (m) { return m.key !== "outcome"; }), p = sw.provenance || {};
    var lines = ["# AERIS sweep export · " + sw.id + " · " + (sw.name || ""), "# source: " + (p.note || "simulation") + (p.mock ? " · MOCK DATA" : ""), "# engine: " + (sw.engine ? sw.engine.engine + " " + (sw.engine.engine_version || "") : "unknown"), "# " + (sw.partial ? "PARTIAL (cancelled)" : "complete") + " · " + (sw.rows || []).length + " runs",
      ["index", "point", "controller", "mass_config", "seed"].concat(vars).concat(["outcome", "saturated"]).concat(ms.map(function (m) { return m.key + (m.unit ? " [" + m.unit + "]" : ""); })).join(",")];
    (sw.rows || []).forEach(function (r) { lines.push([r.index, r.point, r.controller, r.mass_config, r.seed].concat(vars.map(function (k) { return r.values[k]; })).concat([r.outcome, r.saturated ? 1 : 0]).concat(ms.map(function (m) { return r.metrics && r.metrics[m.key] != null ? r.metrics[m.key] : ""; })).join(",")); });
    return lines.join("\n") + "\n";
  }
  /* aeris-dataset/1 package of one sweep, with its provenance; never labelled as final data */
  function toDataset(sw) {
    var p = sw.provenance || {}, mock = !!p.mock;
    return { schema: "aeris-dataset/1", id: String(sw.id).replace("AERIS-SWP-", "AERIS-DS-"), title: (mock ? "MOCK · " : p.demo ? "DEMO · " : "") + (sw.name || "Research sweep") + " (exploratory)", created: new Date().toISOString(), status: "exploratory", mock: mock,
      provenance: { source: "simulation", engine: sw.engine || null, validation: p.validation || { status: "nominal" }, demo: !!p.demo, mock: mock, note: "Exploratory dataset from one research sweep. Simulated with the AERIS Twin model; not validated against the physical cube; not the project's final research dataset." },
      members: [{ kind: "sweep", id: sw.id, schema: SCHEMA_ID, runs: (sw.rows || []).length, partial: !!sw.partial }], sweeps: [sw] };
  }
  return { SCHEMA_ID: SCHEMA_ID, VARIABLES: VARIABLES, VARIABLE_ORDER: VARIABLE_ORDER, MASS_CONFIGS: MASS_CONFIGS, MEASURES: MEASURES, MODES: MODES, LIMITS: LIMITS, CELL: CELL,
    DISTS: DISTS, SEED_STRATEGIES: SEED_STRATEGIES, CRITERIA: CRITERIA, CRITERION_LABEL: CRITERION_LABEL, ident: ident,
    defaultSweep: defaultSweep, normalize: normalize, validate: validate, points: points, acceptance: acceptance, NORMAL_TRIES: NORMAL_TRIES, expand: expand, rowOf: rowOf, analyze: analyze, summarize: summarize, wilson: wilson, totalRuns: totalRuns, newId: newId, toCSV: toCSV, toDataset: toDataset };
})();
if (typeof module !== "undefined") module.exports = AERIS_SWEEP;

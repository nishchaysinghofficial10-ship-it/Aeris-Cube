/* =====================================================================
   AERIS · CONTROLLERS — what each controller in the AERIS Twin browser
   engine actually is. One source for the Lab's controller cards, the
   Twin page and the Research page, so the descriptions cannot drift
   apart. Every statement here describes js/core.js as implemented
   (designTilt, designYaw, designForConfig, simEdge, simCorner); if the
   engine changes, change this file with it.
   ===================================================================== */
var AERIS_CONTROLLERS = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var W = TWIN.WEIGHTS, DEG = TWIN.DEG;
  function r(x, d) { return (+x).toFixed(d); }
  var LIST = {
    pid: {
      key: "pid", name: "PID", family: "Output feedback (proportional–integral–derivative)",
      summary: "Fixed-gain PID on the tilt error and tilt rate. It does not feed back wheel speed.",
      measures: ["tilt error from the reference attitude", "tilt rate", "the integral of the tilt error"],
      assumes: ["the linearised tilt model about the balance point", "the model's mass properties (the bare cube, unless “controller knows the attached masses” is on)"],
      adapts: "Nothing. The gains are fixed when the run starts.",
      design: "Pole placement on the linearised tilt model: the two oscillatory poles of the LQR design plus an integrator pole at s = " + W.pint + " s⁻¹ (Kp = mgl + Θ̂·a₂, Kd = Θ̂·a₁, Ki = Θ̂·a₃). The integrator is clamped at τmax/Ki (anti-windup).",
      limits: "Wheel momentum is not regulated. Under a constant load or an unmodelled COM offset the wheel keeps spinning up (drift) until it reaches its speed limit.",
      corner: "Corner mode: the same gains act on each tilt axis in the plane perpendicular to the balance axis, plus a separate yaw PID about the balance axis."
    },
    lqr: {
      key: "lqr", name: "LQR", family: "Full-state feedback (linear–quadratic regulator)",
      summary: "Full-state feedback of tilt, tilt rate and wheel speed from a linearised model.",
      measures: ["tilt error", "tilt rate", "wheel speed"],
      assumes: ["the linearised model about the balance point", "the model's mass properties (the bare cube, unless “controller knows the attached masses” is on)", "the nominal inertia (the “true inertia” setting changes the plant, not this design)"],
      adapts: "Nothing. The gain K is fixed when the run starts.",
      design: "Infinite-horizon LQR with Q = diag(1/θw², 1/θ̇w², 1/Ωw²), θw = " + r(W.th / DEG, 0) + "°, θ̇w = " + r(W.thd / DEG, 0) + "°/s, Ωw = " + W.ww + " rad/s, and R = 1/τmax². The Riccati equation is solved with the matrix sign function.",
      limits: "Linear design: large tilts, saturation and a wrong mass model are outside what it was designed for. A constant COM offset it does not know about leaves a steady wheel speed.",
      corner: "Corner mode: decoupled. One tilt design (on the averaged perpendicular inertia) acts on both tilt axes; a separate yaw LQR acts about the balance axis. The plant uses the full 3×3 inertia tensor. A coupled MIMO LQR runs on the research backend (structure 'mimo-lqr')."
    },
    adp: {
      key: "adp", name: "COM-adaptive LQR", family: "LQR with one adapted parameter",
      summary: "The LQR above plus an online estimate β̂ of the balance-angle offset caused by an unmodelled centre-of-mass shift.",
      measures: ["tilt error", "tilt rate", "wheel speed"],
      assumes: ["the same linearised model and gains as LQR", "that a steady wheel speed means the balance point is offset (a constant COM shift)"],
      adapts: "One quantity: the balance-angle offset β̂, updated from the wheel speed, dβ̂/dt = γ·Ω with γ = " + W.gam + ", clamped to ±6°. It is frozen while the torque is saturated (in corner mode it keeps adapting after a wheel failure).",
      design: "LQR gain K unchanged; the tilt error is corrected by β̂. In effect an integral action on wheel speed that moves the set-point to the true balance attitude.",
      limits: "It does not adapt inertia, motor constants or the gains, and it is not a general adaptive or nonlinear controller. Time-varying loads and inertia errors are outside its model.",
      corner: "Corner mode: β̂ is a vector in the plane perpendicular to the balance axis, clamped to 6° in magnitude."
    },
    none: {
      key: "none", name: "No control", family: "Open loop",
      summary: "Motors off. Useful to see the unstable open-loop fall.",
      measures: [], assumes: [], adapts: "Nothing.", design: "No controller.", limits: "The cube falls from any non-zero lean.", corner: ""
    }
  };
  /* research-backend controllers: executed by the Python backend (SIMULATION mode), never by this browser engine */
  LIST.nlpd = {
    key: "nlpd", name: "Nonlinear PD (quaternion, model-compensated)", family: "Nonlinear feedback with model compensation", backend: true,
    summary: "Quaternion attitude PD with the model's gravity and gyroscopic torques cancelled, plus a slow momentum loop that tilts the reference to bring the wheels back to rest.",
    measures: ["attitude error as a quaternion (tilt and heading)", "body rate", "wheel speeds (encoders)"],
    assumes: ["the model's mass, centre of mass and full inertia tensor (bare cube unless “controller knows the attached masses” is on)", "the wheel axes and spin inertias", "the friction model when friction compensation is on"],
    adapts: "Nothing is identified. The momentum loop (proportional + integral on the horizontal wheel momentum) removes a constant COM offset from the balance point.",
    design: "u = τ_g,model(q̂) − ω̂×H − Θ̂_model(−K_p φ_e − K_d ω̂) + friction; tilt ω_n = 14 rad/s, ζ = 0.9; yaw ω_n = 4 rad/s; momentum loop ω = 0.8 rad/s (backend defaults, configurable).",
    limits: "Exact cancellation needs the true model; with a wrong model the error dynamics are perturbed. Bounded torque limits the recoverable tilt like every controller; no global stability claim. Research backend only.",
    corner: "Corner mode: tilt and heading gains differ; after a wheel failure the request is allocated to the healthy wheels on the tilt plane (heading given up)."
  };
  var ORDER = ["pid", "lqr", "adp"];
  var BACKEND = ["nlpd"];
  /* what this BROWSER engine does not run (status "research-backend": implemented in the Python backend since v4;
     "planned": not implemented anywhere yet), so pages never imply otherwise */
  var PLANNED = [
    { key: "mimo-lqr", name: "Coupled MIMO LQR", status: "research-backend", browser: false, where: "research backend (SIMULATION mode)", note: "Uses the full inertia tensor, including products of inertia; designed on the controllable subspace (the vertical angular momentum is conserved)." },
    { key: "nlpd", name: "Nonlinear quaternion PD with model compensation", status: "research-backend", browser: false, where: "research backend (SIMULATION mode)", note: "Gravity and gyroscopic compensation with a momentum loop." },
    { key: "mekf", name: "Quaternion MEKF and 3-D complementary filter (corner mode)", status: "research-backend", browser: false, where: "research backend (SIMULATION mode)", note: "The browser engine uses ideal state feedback in corner mode." },
    { key: "nonlinear-other", name: "Other nonlinear controllers (e.g. sliding mode, energy-based)", status: "planned", browser: false, where: "not implemented", note: "Not implemented in either engine." }
  ];
  function get(k) { return LIST[k] || null; }
  function name(k) { var c = LIST[k]; return c ? c.name : String(k); }
  return { LIST: LIST, ORDER: ORDER, BACKEND: BACKEND, PLANNED: PLANNED, get: get, name: name };
})();
if (typeof module !== "undefined") module.exports = AERIS_CONTROLLERS;

/* =====================================================================
   AERIS · DESIGN TOKENS — the one place colour meaning is defined for
   canvas charts and the three.js view. css/base.css mirrors the same
   values as custom properties (a unit test checks the two agree).

   Colour carries meaning, never rank:
   - brand lime       brand and active UI only (focus, current tab, primary button)
   - status           stable = green, warning / saturation = amber, failure = red.
                      Always shown with an icon and a text label, never colour alone.
   - system           physical hardware = cyan, digital model (AERIS Twin) = blue,
                      research environment = violet, replay = neutral.
   - controller       PID, LQR and COM-adaptive LQR get equally weighted colours
                      (same chroma, validated for colour-vision deficiency with a
                      marker shape per controller as the second channel). No
                      controller is drawn in the brand or a status colour.
   - chart neutrals   primary / secondary / tertiary ink for single-run series;
                      wheels X/Y/Z are told apart by line style, not by hue.
   - 3-D axis triads  keep the red/green/blue x/y/z convention (labelled), the
                      only place those hues appear outside status.
   ===================================================================== */
var AERIS_TOKENS = (function () {
  "use strict";
  var color = {
    brand: "#c0ff00",
    status: { stable: "#3ecf6e", warning: "#ffb020", failure: "#ff5a4f", neutral: "#9aa3af" },
    system: { hardware: "#45d4ee", twin: "#6d95ff", research: "#b69cff", replay: "#c7ccd6" },
    controller: { pid: "#3175a4", lqr: "#37a69a", adp: "#9c84c7", nlpd: "#b98a3e", none: "#6f7a88" },
    ink: { primary: "#f2f4f7", secondary: "#9aa3af", tertiary: "#6f7a88" },
    physics: { load: "#e063a7", gravity: "#8fa1b3", com: "#f2f4f7", comNominal: "#8a93a0", mass: "#d6d9de" },
    axis: { x: "#e57f7f", y: "#7fd49a", z: "#7fb2f0" }
  };
  /* Controllers: display names say what each one actually is (see docs/RESEARCH_PLATFORM.md). */
  var CONTROLLERS = {
    pid: { key: "pid", short: "PID", name: "PID", color: color.controller.pid, marker: "circle", glyph: "●" },
    lqr: { key: "lqr", short: "LQR", name: "LQR", color: color.controller.lqr, marker: "square", glyph: "■" },
    adp: { key: "adp", short: "Adaptive", name: "COM-adaptive LQR", color: color.controller.adp, marker: "triangle", glyph: "▲" },
    none: { key: "none", short: "None", name: "No control", color: color.controller.none, marker: "diamond", glyph: "◆" },
    /* research-backend controllers. Five mutually separable hues are not available on this surface next to the status and
       system colours (dataviz validator), so identity is composite: the nonlinear controller has its own hue (ochre, passes
       every check against the three above; deutan floor ΔE 6.9 as before, hence markers) and a star; the coupled MIMO LQR
       stays in the LQR hue family and is told apart by its hollow square and its name. */
    nlpd: { key: "nlpd", short: "Nonlinear", name: "Nonlinear PD (quaternion)", color: color.controller.nlpd, marker: "star", glyph: "★", backend: true },
    "lqr-mimo": { key: "lqr-mimo", short: "MIMO LQR", name: "Coupled MIMO LQR", color: color.controller.lqr, marker: "square-open", glyph: "□", backend: true }
  };
  var CONTROLLER_ORDER = ["pid", "lqr", "adp"];
  /* Outcome → status tone, icon and short label (the label always travels with the colour). */
  var OUTCOME = {
    recovered: { tone: "stable", icon: "✓" },
    not_settled: { tone: "warning", icon: "…" },
    drifting: { tone: "warning", icon: "↗" },
    fallen: { tone: "failure", icon: "✕" },
    invalid: { tone: "failure", icon: "⊘" }
  };
  /* Wheel series in single-run charts: neutral inks told apart by dash pattern and label. */
  var WHEEL_STYLE = {
    x: { color: color.ink.primary, dash: [], label: "Ωx" },
    y: { color: color.ink.secondary, dash: [7, 4], label: "Ωy" },
    z: { color: color.ink.tertiary, dash: [2, 3], label: "Ωz" }
  };
  function controller(key) { return CONTROLLERS[key] || { key: key, short: String(key), name: String(key), color: color.ink.tertiary, marker: "circle", glyph: "●" }; }
  function outcome(code) { return OUTCOME[code] || { tone: "neutral", icon: "?" }; }
  function statusColor(tone) { return color.status[tone] || color.status.neutral; }
  function alpha(hex, a) {
    var h = String(hex).replace("#", ""), r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
    return "rgba(" + r + "," + g + "," + b + "," + a + ")";
  }
  /* CSS custom properties that must equal the values above (checked by tests/platform.test.js). */
  var CSS_VARS = {
    "--brand": color.brand,
    "--stable": color.status.stable, "--warning": color.status.warning, "--failure": color.status.failure,
    "--sys-hw": color.system.hardware, "--sys-twin": color.system.twin, "--sys-research": color.system.research, "--sys-replay": color.system.replay,
    "--ctl-pid": color.controller.pid, "--ctl-lqr": color.controller.lqr, "--ctl-adp": color.controller.adp, "--ctl-nlpd": color.controller.nlpd,
    "--load": color.physics.load
  };
  return { color: color, CONTROLLERS: CONTROLLERS, CONTROLLER_ORDER: CONTROLLER_ORDER, OUTCOME: OUTCOME, WHEEL_STYLE: WHEEL_STYLE, CSS_VARS: CSS_VARS, controller: controller, outcome: outcome, statusColor: statusColor, alpha: alpha };
})();
if (typeof module !== "undefined") module.exports = AERIS_TOKENS;

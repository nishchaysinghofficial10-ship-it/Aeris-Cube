/* =====================================================================
   AERIS · SIM ↔ HARDWARE VALIDATION — compares one simulated run with one
   recorded hardware run (aeris-hardware-run/1) of the same experiment.

   Nothing here produces a validation result by itself: it needs a real
   hardware recording supplied by the user. Until one exists the Validation
   page says "hardware dataset pending" and shows no numbers.

   Method (docs/RESEARCH_PLATFORM.md §7):
   1. Signals present in both runs are converted to SI (rad, rad/s) using
      the hardware file's own units ("deg", "rpm" and "deg/s" accepted).
   2. The simulation is linearly interpolated onto the hardware time stamps
      inside the overlapping time range (no extrapolation).
   3. For each signal: RMSE, mean absolute error, peak absolute error and
      the difference in peak magnitude; then the time offset that minimises
      the RMSE within ±maxLag (grid search at the hardware sample spacing)
      and the RMSE after removing that offset.
   Metrics describe the agreement of these two runs only.
   ===================================================================== */
var AERIS_VALIDATION = (function () {
  "use strict";
  var SCHEMA = typeof AERIS_SCHEMA !== "undefined" ? AERIS_SCHEMA : require("./schema.js");
  var DEG = Math.PI / 180, RPM = Math.PI / 30;
  /* comparable signals: sim column, accepted hardware columns, SI unit, display unit and scale */
  var SIGNALS = [
    { key: "theta", label: "Tilt θ (edge)", sim: "theta", hw: ["theta"], si: "rad", show: "°", scale: 1 / DEG, mode: "edge" },
    { key: "thetadot", label: "Tilt rate θ̇ (edge)", sim: "thetadot", hw: ["thetadot", "w_x"], si: "rad/s", show: "°/s", scale: 1 / DEG, mode: "edge" },
    { key: "omega_x", label: "Wheel X speed", sim: "omega_x", hw: ["omega_x", "wheel_rpm_x"], si: "rad/s", show: "rpm", scale: 1 / RPM },
    { key: "omega_y", label: "Wheel Y speed", sim: "omega_y", hw: ["omega_y", "wheel_rpm_y"], si: "rad/s", show: "rpm", scale: 1 / RPM, mode: "corner" },
    { key: "omega_z", label: "Wheel Z speed", sim: "omega_z", hw: ["omega_z", "wheel_rpm_z"], si: "rad/s", show: "rpm", scale: 1 / RPM, mode: "corner" }
  ];
  var FACTOR = { rad: 1, deg: DEG, "°": DEG, "rad/s": 1, "deg/s": DEG, "°/s": DEG, rpm: RPM };
  function toSI(col, unit, si) {
    var u = String(unit || "").trim().toLowerCase(), f = FACTOR[u];
    if (f == null) return { ok: false, error: "unit '" + unit + "' is not supported for this signal (use " + (si === "rad" ? "rad or deg" : "rad/s, deg/s or rpm") + ")" };
    if ((si === "rad") !== (u === "rad" || u === "deg" || u === "°")) return { ok: false, error: "unit '" + unit + "' does not match a " + (si === "rad" ? "angle" : "rate") };
    return { ok: true, y: col.map(function (v) { return v * f; }) };
  }
  /* linear interpolation of (xs, ys) at x; null outside [xs0, xsN] */
  function interp(xs, ys, x) {
    var n = xs.length; if (!n || x < xs[0] - 1e-12 || x > xs[n - 1] + 1e-12) return null;
    var lo = 0, hi = n - 1;
    while (hi - lo > 1) { var mid = (lo + hi) >> 1; if (xs[mid] <= x) lo = mid; else hi = mid; }
    if (hi === lo) return ys[lo];
    var f = (x - xs[lo]) / (xs[hi] - xs[lo] || 1); return ys[lo] + f * (ys[hi] - ys[lo]);
  }
  function errors(simT, simY, hwT, hwY, lag) {
    var sq = 0, ab = 0, pk = 0, n = 0, pS = 0, pH = 0;
    for (var i = 0; i < hwT.length; i++) {
      var s = interp(simT, simY, hwT[i] - lag); if (s === null || !isFinite(hwY[i])) continue;
      var e = hwY[i] - s; sq += e * e; ab += Math.abs(e); if (Math.abs(e) > pk) pk = Math.abs(e); n++;
      if (Math.abs(s) > pS) pS = Math.abs(s); if (Math.abs(hwY[i]) > pH) pH = Math.abs(hwY[i]);
    }
    return n ? { n: n, rmse: Math.sqrt(sq / n), mae: ab / n, peakErr: pk, peakDiff: pH - pS } : { n: 0 };
  }
  /* compare(simRecord, hardwareRun, { maxLag_s, protocol, recordingIngested }) →
       { ok, errors[], warnings[], signals[], overlap, alignment, attitude, extra[], quality, acceptance }
     signals[]: per-signal errors as in v3 (each with its own best lag);
     alignment: one lag chosen on the primary attitude signal (θ in edge mode, the quaternion geodesic error otherwise)
       and applied to every signal in `extra` and `attitude`;
     attitude: quaternion geodesic error 2·acos|⟨q_sim, q_hw⟩| (corner / free recordings with q0–q3);
     extra[]: body rates, measured vs simulated torque, commanded vs measured torque (hardware internal), estimator
       error when the recording has an estimate AND an independent reference (qhat0–3 with qref0–3, or thetahat with theta_ref);
     quality: overlap fraction, samples compared, gaps and dropouts from the file;
     acceptance: only against a protocol whose thresholds were registered BEFORE the recording was ingested, and
       never for SYNTHETIC files. Nothing here marks a model VALIDATED. */
  var EXTRA = [
    { key: "rate_x", label: "Body rate ω_x", sim: "wx", hw: ["w_x"], si: "rad/s", show: "°/s", scale: 1 / DEG, mode: "corner" },
    { key: "rate_y", label: "Body rate ω_y", sim: "wy", hw: ["w_y"], si: "rad/s", show: "°/s", scale: 1 / DEG, mode: "corner" },
    { key: "rate_z", label: "Body rate ω_z", sim: "wz", hw: ["w_z"], si: "rad/s", show: "°/s", scale: 1 / DEG, mode: "corner" },
    { key: "torque_x", label: "Wheel X torque (simulated applied vs measured)", sim: "T_x", hw: ["torque_meas_x"], si: "N·m", show: "N·m", scale: 1 },
    { key: "torque_y", label: "Wheel Y torque (simulated applied vs measured)", sim: "T_y", hw: ["torque_meas_y"], si: "N·m", show: "N·m", scale: 1, mode: "corner" },
    { key: "torque_z", label: "Wheel Z torque (simulated applied vs measured)", sim: "T_z", hw: ["torque_meas_z"], si: "N·m", show: "N·m", scale: 1, mode: "corner" }
  ];
  var TORQUE_UNITS = { "N·m": 1, "N*m": 1, "Nm": 1, "mN·m": 1e-3, "mNm": 1e-3 };
  function convert(col, unit, si) {
    if (si === "N·m") { var f = TORQUE_UNITS[String(unit || "").trim()]; return f == null ? { ok: false, error: "unit '" + unit + "' is not a torque unit (N·m, mN·m)" } : { ok: true, y: col.map(function (v) { return v * f; }) }; }
    return toSI(col, unit, si);
  }
  function stats(errs) { if (!errs.length) return null; var sq = 0, ab = 0, pk = 0; errs.forEach(function (e) { sq += e * e; ab += Math.abs(e); if (Math.abs(e) > pk) pk = Math.abs(e); }); return { n: errs.length, rmse: Math.sqrt(sq / errs.length), mae: ab / errs.length, peak: pk }; }
  function scaled(st, k) { return st ? { n: st.n, rmse: st.rmse * k, mae: st.mae * k, peak: st.peak * k } : null; }
  function quatErr(sim, hwT, hwq, idx, lag) {
    var S = sim.samples.cols, sT = S.t, errs = [];
    idx.forEach(function (i) {
      var qs = [0, 1, 2, 3].map(function (j) { return interp(sT, S["q" + j], hwT[i] - lag); });
      if (qs.some(function (x) { return x === null; })) return;
      var n = Math.hypot(qs[0], qs[1], qs[2], qs[3]), d = Math.abs((qs[0] * hwq[0][i] + qs[1] * hwq[1][i] + qs[2] * hwq[2][i] + qs[3] * hwq[3][i]) / n);
      errs.push(2 * Math.acos(Math.min(1, d)));
    });
    return errs;
  }
  function compare(sim, hw, opts) {
    opts = opts || {};
    var E = [], Wn = [], out = { ok: false, errors: E, warnings: Wn, signals: [], overlap: null, alignment: null, attitude: null, extra: [], quality: null, acceptance: null };
    var v = SCHEMA.validateHardwareRun(hw);
    if (!v.ok) { v.errors.forEach(function (e) { E.push("Hardware file: " + e); }); return out; }
    v.warnings.forEach(function (w) { Wn.push("Hardware file: " + w); });
    if (!sim || !sim.samples || !sim.samples.cols || !sim.samples.cols.t) { E.push("The simulation run has no samples."); return out; }
    if (sim.config && hw.mode && hw.mode !== "free" && sim.config.mode !== hw.mode) E.push("The simulation is in " + sim.config.mode + " mode but the hardware run is in " + hw.mode + " mode.");
    if (E.length) return out;
    var tScale = hw.samples.units.t === "ms" ? 1e-3 : 1;
    var sT = sim.samples.cols.t, hT = hw.samples.cols.t.map(function (x) { return x * tScale; }), t0 = Math.max(sT[0], hT[0]), t1 = Math.min(sT[sT.length - 1], hT[hT.length - 1]);
    if (!(t1 > t0)) { E.push("The two runs do not overlap in time."); return out; }
    out.overlap = [t0, t1];
    var dtH = (hT[hT.length - 1] - hT[0]) / Math.max(1, hT.length - 1), maxLag = opts.maxLag_s == null ? 0.25 : opts.maxLag_s;
    var inIdx = []; hT.forEach(function (t, i) { if (t >= t0 - 1e-12 && t <= t1 + 1e-12) inIdx.push(i); });
    var mode = sim.config ? sim.config.mode : hw.mode;
    SIGNALS.forEach(function (sg) {
      if (sg.mode && sim.config && sim.config.mode !== sg.mode) return;
      var sy = sim.samples.cols[sg.sim]; if (!sy) return;
      var hk = sg.hw.filter(function (k) { return Array.isArray(hw.samples.cols[k]); })[0]; if (!hk) return;
      var unit = hw.samples.units[hk] || (hk.indexOf("wheel_rpm") === 0 ? "rpm" : "");
      var conv = toSI(hw.samples.cols[hk], unit, sg.si);
      if (!conv.ok) { Wn.push(sg.label + ": " + conv.error + "; not compared."); return; }
      var hy = conv.y.map(function (x, i) { return hT[i] >= t0 - 1e-12 && hT[i] <= t1 + 1e-12 ? x : NaN; });
      var base = errors(sT, sy, hT, hy, 0);
      if (!base.n) return;
      var best = { lag: 0, rmse: base.rmse }, steps = Math.min(400, Math.floor(maxLag / Math.max(1e-4, dtH)));
      for (var k = -steps; k <= steps; k++) { if (!k) continue; var e = errors(sT, sy, hT, hy, k * dtH); if (e.n >= 0.8 * base.n && e.rmse < best.rmse) best = { lag: k * dtH, rmse: e.rmse }; }
      out.signals.push({ key: sg.key, label: sg.label, hwColumn: hk, unit: sg.show, n: base.n,
        rmse: base.rmse * sg.scale, mae: base.mae * sg.scale, peakErr: base.peakErr * sg.scale, peakDiff: base.peakDiff * sg.scale,
        lag_s: best.lag, rmseAfterLag: best.rmse * sg.scale });
    });
    // one common alignment from the primary attitude signal
    var hasQ = ["q0", "q1", "q2", "q3"].every(function (c) { return Array.isArray(hw.samples.cols[c]); }) && ["q0", "q1", "q2", "q3"].every(function (c) { return Array.isArray(sim.samples.cols[c]); });
    var lag = 0, primary = null;
    if (mode === "edge") { var th = out.signals.filter(function (x) { return x.key === "theta"; })[0]; if (th) { lag = th.lag_s; primary = "theta"; } }
    else if (hasQ) {
      var hq = [0, 1, 2, 3].map(function (j) { return hw.samples.cols["q" + j]; });
      var b0 = stats(quatErr(sim, hT, hq, inIdx, 0)), best2 = { lag: 0, st: b0 }, st2 = Math.min(400, Math.floor(maxLag / Math.max(1e-4, dtH)));
      if (b0) {
        for (var k2 = -st2; k2 <= st2; k2++) { if (!k2) continue; var s2 = stats(quatErr(sim, hT, hq, inIdx, k2 * dtH)); if (s2 && s2.n >= 0.8 * b0.n && s2.rmse < best2.st.rmse) best2 = { lag: k2 * dtH, st: s2 }; }
        lag = best2.lag; primary = "quaternion geodesic error";
        out.attitude = { unit: "°", definition: "2·acos|⟨q_sim, q_hw⟩| (sign-invariant geodesic angle)", aligned: scaled(best2.st, 1 / DEG), unaligned: scaled(b0, 1 / DEG) };
      }
    }
    out.alignment = { lag_s: lag, primary: primary, search_s: maxLag, note: primary ? "The simulation is shifted by lag_s before the attitude and extra signals are compared." : "No attitude signal to align on; extra signals are compared without a shift." };
    EXTRA.forEach(function (sg) {
      if (sg.mode && mode !== sg.mode) return;
      var sy = sim.samples.cols[sg.sim]; if (!sy) return;
      var hk = sg.hw.filter(function (k) { return Array.isArray(hw.samples.cols[k]); })[0]; if (!hk) return;
      var conv = convert(hw.samples.cols[hk], hw.samples.units[hk], sg.si);
      if (!conv.ok) { Wn.push(sg.label + ": " + conv.error + "; not compared."); return; }
      var errs = []; inIdx.forEach(function (i) { var sv = interp(sT, sy, hT[i] - lag); if (sv !== null) errs.push(conv.y[i] - sv); });
      var st = stats(errs); if (st) out.extra.push({ key: sg.key, label: sg.label, hwColumn: hk, unit: sg.show, error: scaled(st, sg.scale) });
    });
    ["x", "y", "z"].forEach(function (w) {
      var c = hw.samples.cols["torque_cmd_" + w], m = hw.samples.cols["torque_meas_" + w];
      if (!Array.isArray(c) || !Array.isArray(m)) return;
      var cc = convert(c, hw.samples.units["torque_cmd_" + w], "N·m"), mm = convert(m, hw.samples.units["torque_meas_" + w], "N·m");
      if (!cc.ok || !mm.ok) { Wn.push("Wheel " + w.toUpperCase() + " commanded vs measured torque: " + (cc.error || mm.error) + "; not compared."); return; }
      out.extra.push({ key: "torque_track_" + w, label: "Wheel " + w.toUpperCase() + " measured − commanded torque (hardware driver tracking)", unit: "N·m", error: stats(mm.y.map(function (x, i) { return x - cc.y[i]; })) });
    });
    var qh = ["qhat0", "qhat1", "qhat2", "qhat3"], qr = ["qref0", "qref1", "qref2", "qref3"];
    if (qh.concat(qr).every(function (c) { return Array.isArray(hw.samples.cols[c]); })) {
      var ee = hT.map(function (_, i) { var d = Math.abs(qh.reduce(function (s, c, j) { return s + hw.samples.cols[c][i] * hw.samples.cols[qr[j]][i]; }, 0)); return 2 * Math.acos(Math.min(1, d)); });
      out.extra.push({ key: "estimator", label: "On-board estimator error (qhat vs independent reference qref)", unit: "°", error: scaled(stats(ee), 1 / DEG) });
    } else if (Array.isArray(hw.samples.cols.thetahat) && Array.isArray(hw.samples.cols.theta_ref)) {
      var a1 = toSI(hw.samples.cols.thetahat, hw.samples.units.thetahat, "rad"), a2 = toSI(hw.samples.cols.theta_ref, hw.samples.units.theta_ref, "rad");
      if (a1.ok && a2.ok) out.extra.push({ key: "estimator", label: "On-board estimator error (thetahat − theta_ref)", unit: "°", error: scaled(stats(a1.y.map(function (x, i) { return x - a2.y[i]; })), 1 / DEG) });
    } else Wn.push("No estimator error: the recording has no independent attitude reference next to the on-board estimate (qhat0–3 with qref0–3, or thetahat with theta_ref).");
    var dur = hT[hT.length - 1] - hT[0];
    out.quality = { overlap_s: t1 - t0, overlap_fraction: dur > 0 ? (t1 - t0) / dur : null, samples_compared: inIdx.length, recording: v.quality };
    if (opts.protocol) out.acceptance = evaluate(out, opts.protocol, { ingested: opts.recordingIngested || null, synthetic: hw.synthetic === true });
    if (!out.signals.length && !out.attitude && !out.extra.length) E.push("No signal is present in both runs (expected e.g. 'theta' and 'omega_x' or 'wheel_rpm_x').");
    out.ok = E.length === 0;
    return out;
  }
  /* protocol: { id, created (ISO), thresholds: { "theta.rmse": 0.5, "attitude.rmse": 1, "omega_x.rmse": 50, ... } } */
  function metricOf(res, key) {
    var parts = key.split("."), sig = parts[0], stat = parts[1] || "rmse";
    if (sig === "attitude") return res.attitude && res.attitude.aligned ? res.attitude.aligned[stat] : null;
    var s = res.signals.filter(function (x) { return x.key === sig; })[0]; if (s) return s[stat === "peak" ? "peakErr" : stat];
    var e = res.extra.filter(function (x) { return x.key === sig; })[0]; return e && e.error ? e.error[stat] : null;
  }
  function evaluate(res, protocol, rec) {
    var notes = [], admissible = true;
    if (rec.synthetic) { admissible = false; notes.push("The recording is SYNTHETIC; it cannot be validation evidence."); }
    if (!rec.ingested) { admissible = false; notes.push("The recording's ingestion time is unknown, so it cannot be shown that the thresholds were fixed before the data were seen."); }
    else if (!(protocol.created < rec.ingested)) { admissible = false; notes.push("The thresholds were registered after the recording was available; acceptance thresholds must be fixed before the data are seen."); }
    var checks = Object.keys(protocol.thresholds || {}).map(function (k) { var v = metricOf(res, k); return { metric: k, threshold: protocol.thresholds[k], value: v, pass: v != null && v <= protocol.thresholds[k], missing: v == null }; });
    return { protocol_id: protocol.id || null, checks: checks, all_pass: checks.length > 0 && checks.every(function (c) { return c.pass; }), admissible_as_evidence: admissible, notes: notes,
      status_change: "none — this page never marks the model VALIDATED; a published comparison with admissible evidence is required (docs/RESEARCH_PLATFORM.md §8)." };
  }
  return { SIGNALS: SIGNALS, EXTRA: EXTRA, compare: compare, evaluate: evaluate, metricOf: metricOf, interp: interp, toSI: toSI };
})();
if (typeof module !== "undefined") module.exports = AERIS_VALIDATION;

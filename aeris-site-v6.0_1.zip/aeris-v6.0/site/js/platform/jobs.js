/* =====================================================================
   AERIS · JOBS — the state machine for batch work (research sweeps,
   controller sets, backend simulations). The same states are used for a
   job run by the research backend and for a small job run in this browser.

     QUEUED → INITIALIZING → RUNNING (n / N) → ANALYZING → COMPLETE
        any non-terminal state → FAILED | CANCELLED

   A job never reports progress it has not made: `done` only increases when
   a simulation has actually finished (see adapters/*.js).
   ===================================================================== */
var AERIS_JOBS = (function () {
  "use strict";
  var STATES = {
    queued: { label: "QUEUED", tone: "info", terminal: false, text: "Waiting to start." },
    initializing: { label: "INITIALIZING", tone: "info", terminal: false, text: "Validating the configuration and preparing the runs." },
    running: { label: "RUNNING", tone: "info", terminal: false, text: "Simulations in progress." },
    analyzing: { label: "ANALYZING", tone: "info", terminal: false, text: "Computing maps, distributions and summary metrics." },
    complete: { label: "COMPLETE", tone: "stable", terminal: true, text: "Finished; results available." },
    failed: { label: "FAILED", tone: "failure", terminal: true, text: "Stopped by an error." },
    cancelled: { label: "CANCELLED", tone: "warning", terminal: true, text: "Stopped on request; partial results are kept if any." }
  };
  var NEXT = {
    queued: ["initializing", "failed", "cancelled"],
    initializing: ["running", "failed", "cancelled"],
    running: ["running", "analyzing", "failed", "cancelled"],
    analyzing: ["complete", "failed", "cancelled"],
    complete: [], failed: [], cancelled: []
  };
  var seq = 0;
  function now() { return new Date().toISOString(); }
  function create(o) {
    o = o || {};
    seq += 1;
    var job = {
      schema: "aeris-job/1", id: o.id || ("job-" + Date.now().toString(36) + "-" + seq), kind: o.kind || "sweep",
      state: "queued", created: now(), updated: now(), started: null, finished: null,
      progress: { done: 0, total: o.total || 0, failed: 0, fraction: 0 },
      adapter: o.adapter || null, mode: o.mode || null, demo: !!o.demo, mock: !!o.mock,
      message: STATES.queued.text, error: null, result: null
    };
    Object.defineProperty(job, "_subs", { value: [], enumerable: false, writable: true });
    return job;
  }
  function canMove(from, to) { return (NEXT[from] || []).indexOf(to) >= 0; }
  function emit(job) { (job._subs || []).slice().forEach(function (fn) { try { fn(job); } catch (e) { /* a listener must not break the job */ } }); }
  function move(job, to, patch) {
    if (!STATES[to]) throw new Error("unknown job state '" + to + "'");
    if (!canMove(job.state, to)) throw new Error("illegal job transition " + job.state + " → " + to);
    job.state = to; job.updated = now();
    if (to === "initializing" && !job.started) job.started = job.updated;
    if (STATES[to].terminal) job.finished = job.updated;
    job.message = (patch && patch.message) || STATES[to].text;
    if (patch) { if (patch.error) job.error = patch.error; if (patch.result !== undefined) job.result = patch.result; if (patch.total != null) { job.progress.total = patch.total; frac(job); } }
    emit(job); return job;
  }
  function frac(job) { var p = job.progress; p.fraction = p.total > 0 ? Math.min(1, p.done / p.total) : 0; }
  /* record finished simulations (never more than the total) */
  function advance(job, n, failedN) {
    if (job.state !== "running") throw new Error("progress can only be reported while running (state " + job.state + ")");
    var p = job.progress; p.done = Math.min(p.total, p.done + (n || 0)); p.failed += failedN || 0; frac(job);
    job.updated = now(); emit(job); return job;
  }
  function subscribe(job, fn) { job._subs.push(fn); return function () { job._subs = job._subs.filter(function (f) { return f !== fn; }); }; }
  function isTerminal(job) { return !!(STATES[job.state] && STATES[job.state].terminal); }
  function describe(job) {
    var s = STATES[job.state], p = job.progress, t = s.label;
    if (job.state === "running" || (job.state !== "queued" && p.total)) t += " · " + p.done.toLocaleString("en-GB") + " / " + p.total.toLocaleString("en-GB") + " simulations · " + (p.fraction * 100).toFixed(1) + " %";
    if (job.demo) t += " · DEMO (runs in this browser)";
    if (job.mock) t += " · MOCK DATA";
    return t;
  }
  /* strip listeners for export / JSON */
  function toJSON(job) { var o = {}; Object.keys(job).forEach(function (k) { if (k !== "result") o[k] = job[k]; }); return JSON.parse(JSON.stringify(o)); }
  return { STATES: STATES, NEXT: NEXT, create: create, move: move, canMove: canMove, advance: advance, subscribe: subscribe, isTerminal: isTerminal, describe: describe, toJSON: toJSON };
})();
if (typeof module !== "undefined") module.exports = AERIS_JOBS;

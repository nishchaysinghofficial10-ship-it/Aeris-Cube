/* =====================================================================
   AERIS · RESEARCH CONFIGURATION (aeris-config/1, revision 1.2)

   Revision 1.0 is the browser engine's setup format (AERIS_TWIN.normalizeConfig).
   Revision 1.1 ADDS optional research blocks that the Python research backend executes
   (docs/SCHEMA_EXTENSIONS.md); revision 1.2 adds the general initial state (explicit attitude
   quaternion and body-rate vector), the reference block and the estimate age limit
   (docs/EXPERIMENT_CONTRACT.md). This module keeps them intact through every step that used to
   drop them (form edits, controller sets, sweep expansion, save/load, import/export,
   backend submission and reproduction) and validates in layers:

     1. structure   shared: types, shapes, enumerations of every field (revision 1.0 and 1.1)
     2. engine      what the ACTIVE engine can run: DEMO = the browser engine (AERIS_TWIN)
                    with its own limits; SIMULATION = the capabilities the backend reported
     3. backend     authoritative: POST /api/v1/validate and /simulations (ResearchApiAdapter)
     4. records     returned records are checked strictly (js/runs.js validateRecord)

   A configuration without revision-1.1 content normalises to exactly what
   AERIS_TWIN.normalizeConfig returns, so browser runs and v3 records are unchanged.
   Nothing is dropped silently: unknown fields are kept and reported as warnings.
   ===================================================================== */
var AERIS_CFG = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var REVISION = "1.2", REVISIONS_READ = ["1.0", "1.1", "1.2"];
  var LEGACY_KEYS = ["schema", "mode", "params", "comOffset_m", "comShift_m", "attachments", "controller", "estimator", "seed", "sensor", "actuator", "initial", "disturbances", "events", "commands", "uncertainty", "torqueScale", "duration_s", "record_hz"];
  var EXT_KEYS = ["config_revision", "solver", "plant", "wheels", "recovery", "termination", "reference"];
  var CONTROLLERS = { browser: ["pid", "lqr", "adp", "none"], research: ["pid", "lqr", "adp", "nlpd", "none"] };
  var ESTIMATORS_ALL = ["ideal", "cf", "kf", "accel", "gyro", "cf3d", "mekf"];
  var DIST_EXT = ["impulse", "force_impulse", "bias"];
  var EVENT_EXT = ["wheel_degradation", "wheel_torque_limit", "wheel_speed_limit"];
  var REV_1_2 = ["initial.attitude_q", "initial.body_rate_dps", "reference", "estimator.stale_after_s"];   // features new in revision 1.2
  var RECOVERY_DEFAULTS = { attitude_error_deg: 0.5, rate_dps: 2.0, hold_s: 1.0, max_time_s: null, yaw_objective: "hold" };
  var TERMINATION_DEFAULTS = { stop_on_recovery: false, post_fall_s: 1.5, check_lift_off: true, overspeed_rpm: null, max_quaternion_drift: 1e-4 };
  /* The research backend's normalised configuration always carries solver, plant, recovery and
     termination blocks (and wheels: null). A block that only restates the defaults does not change
     the model, so it does not count as a research feature; anything else does. */
  function sameAs(v, dflt) { return isObj(v) && Object.keys(v).every(function (k) { return k in dflt && (v[k] === dflt[k] || (v[k] == null && dflt[k] == null)); }); }
  function inUse(k, v) {
    if (v == null) return false;
    if (k === "solver") return !(isObj(v) && (v.method == null || v.method === "rk4") && v.integration_hz == null && Object.keys(v).every(function (x) { return x === "method" || x === "integration_hz"; }));
    if (k === "plant") return !(isObj(v) && v.base_inertia_kgm2 == null && v.base_com_m == null && !(Array.isArray(v.components) && v.components.length) && Object.keys(v).every(function (x) { return ["base_inertia_kgm2", "base_com_m", "components"].indexOf(x) >= 0; }));
    if (k === "recovery") return !sameAs(v, RECOVERY_DEFAULTS);
    if (k === "termination") return !sameAs(v, TERMINATION_DEFAULTS);
    if (k === "reference") return !(isObj(v) && (v.attitude == null || v.attitude === "balance") && (v.heading == null || v.heading === "hold") && (v.yaw_deg == null || v.yaw_deg === 0) && Object.keys(v).every(function (x) { return ["attitude", "heading", "yaw_deg"].indexOf(x) >= 0; }));
    return true;
  }
  var NAMES = {
    controller: { pid: "PID", lqr: "LQR", adp: "COM-adaptive LQR", nlpd: "Nonlinear PD (quaternion, model-compensated)", none: "No control" },
    estimator: { ideal: "Ideal state (perfect-state baseline)", cf: "Complementary filter", kf: "Kalman filter (angle + bias)", accel: "Accelerometer only", gyro: "Gyro integration", cf3d: "Complementary attitude filter (3-D)", mekf: "Quaternion MEKF (attitude + gyro bias)" },
    structure: { decoupled: "Decoupled (per axis)", "mimo-lqr": "Coupled MIMO LQR (full inertia tensor)" }
  };
  function clone(o) { return o == null ? o : JSON.parse(JSON.stringify(o)); }
  function isObj(x) { return !!x && typeof x === "object" && !Array.isArray(x); }
  function isNum(x) { return typeof x === "number" && isFinite(x); }

  /* ---------------- which revision-1.1 features a configuration uses ---------------- */
  function extensions(raw) {
    var used = [];
    if (!isObj(raw)) return used;
    ["solver", "plant", "wheels", "recovery", "termination", "reference"].forEach(function (k) { if (inUse(k, raw[k])) used.push(k); });
    var c = raw.controller || {};
    if (c.type === "nlpd") used.push("controller.type");
    if (c.structure === "mimo-lqr") used.push("controller.structure");
    ["pid", "lqr", "adaptive", "nonlinear", "allocation"].forEach(function (k) { if (c[k] != null) used.push("controller." + k); });
    var e = raw.estimator || {};
    if (e.type === "cf3d" || e.type === "mekf") used.push("estimator.type");
    ["mekf", "cf3d", "stale_after_s"].forEach(function (k) { if (e[k] != null) used.push("estimator." + k); });
    var a = raw.actuator || {}; if (a.electrical_limit != null) used.push("actuator.electrical_limit");
    var s = raw.sensor || {}; ["imu_position_m", "accel_dynamic", "accel_bias_mps2"].forEach(function (k) { if (s[k] != null) used.push("sensor." + k); });
    var u = raw.uncertainty || {}; if (u.inertia_perturbation_kgm2 != null) used.push("uncertainty.inertia_perturbation_kgm2");
    var i = raw.initial || {}; ["wheel_speeds_rpm", "attitude_q", "body_rate_dps"].forEach(function (k) { if (i[k] != null) used.push("initial." + k); });
    (raw.disturbances || []).forEach(function (d, k) { if (d && DIST_EXT.indexOf(d.type) >= 0) used.push("disturbances." + k); });
    (raw.events || []).forEach(function (ev, k) { if (ev && (EVENT_EXT.indexOf(ev.type) >= 0 || ev.duration_s != null)) used.push("events." + k); });
    return used;
  }

  /* ---------------- normalisation that keeps every field ---------------- */
  function normalize(raw) {
    var src = isObj(raw) ? raw : {}, c = TWIN.normalizeConfig(src);
    // the browser normaliser marks unknown enum values with "?"; restore the research values it does not know
    if (isObj(src.controller)) {
      if (src.controller.type === "nlpd") c.controller.type = "nlpd";
      ["pid", "lqr", "adaptive", "nonlinear", "allocation"].forEach(function (k) { if (src.controller[k] != null) c.controller[k] = clone(src.controller[k]); });
      Object.keys(src.controller).forEach(function (k) { if (["type", "knowsAttachments", "reconfigureOnFailure", "structure", "pid", "lqr", "adaptive", "nonlinear", "allocation"].indexOf(k) < 0) c.controller[k] = clone(src.controller[k]); });
    }
    if (isObj(src.estimator)) Object.keys(src.estimator).forEach(function (k) { if (k !== "type" && k !== "Rkf_deg") c.estimator[k] = clone(src.estimator[k]); });
    if (isObj(src.sensor)) Object.keys(src.sensor).forEach(function (k) { if (!(k in c.sensor)) c.sensor[k] = clone(src.sensor[k]); });
    if (isObj(src.actuator)) Object.keys(src.actuator).forEach(function (k) { if (k !== "motor_lag_ms" && k !== "wheel_health") c.actuator[k] = clone(src.actuator[k]); });
    if (isObj(src.uncertainty)) Object.keys(src.uncertainty).forEach(function (k) { if (k !== "inertiaScale") c.uncertainty[k] = clone(src.uncertainty[k]); });
    if (isObj(src.initial)) {
      Object.keys(src.initial).forEach(function (k) { if (["tilt_deg", "rate_dps", "azimuth_deg", "reference"].indexOf(k) < 0) c.initial[k] = clone(src.initial[k]); });
      // revision 1.2: an explicit attitude replaces the legacy tilt inputs, an explicit body rate the legacy rate (they are null)
      if (src.initial.attitude_q != null) { c.initial.tilt_deg = null; c.initial.azimuth_deg = null; c.initial.reference = null; }
      if (src.initial.body_rate_dps != null) c.initial.rate_dps = null;
    }
    if (Array.isArray(src.disturbances)) src.disturbances.forEach(function (d, i) { if (d && (DIST_EXT.indexOf(d.type) >= 0)) c.disturbances[i] = clone(d); else if (d && c.disturbances[i]) Object.keys(d).forEach(function (k) { if (!(k in c.disturbances[i])) c.disturbances[i][k] = clone(d[k]); }); });
    if (Array.isArray(src.events)) src.events.forEach(function (e, i) { if (e && (EVENT_EXT.indexOf(e.type) >= 0)) c.events[i] = clone(e); else if (e && c.events[i]) Object.keys(e).forEach(function (k) { if (!(k in c.events[i])) c.events[i][k] = clone(e[k]); }); });
    if (Array.isArray(src.attachments)) src.attachments.forEach(function (a, i) { if (a && c.attachments[i]) Object.keys(a).forEach(function (k) { if (!(k in c.attachments[i])) c.attachments[i][k] = clone(a[k]); }); });
    EXT_KEYS.forEach(function (k) { if (src[k] != null) c[k] = clone(src[k]); });
    Object.keys(src).forEach(function (k) { if (LEGACY_KEYS.indexOf(k) < 0 && EXT_KEYS.indexOf(k) < 0) c[k] = clone(src[k]); });
    if (extensions(c).length && !c.config_revision) c.config_revision = REVISION;
    // stable key order (legacy keys as the browser normaliser orders them, then the revision-1.1 blocks, then
    // unknown fields), so that normalising or exporting twice gives byte-identical JSON
    var o = {};
    Object.keys(c).forEach(function (k) { if (EXT_KEYS.indexOf(k) < 0 && LEGACY_KEYS.indexOf(k) >= 0) o[k] = c[k]; });
    EXT_KEYS.forEach(function (k) { if (k in c) o[k] = c[k]; });
    Object.keys(c).forEach(function (k) { if (!(k in o)) o[k] = c[k]; });
    return o;
  }

  /* ---------------- layer 1: structure (shared by every engine) ---------------- */
  function structural(cfgIn) {
    var E = [], W = [], c = cfgIn || {};
    function err(path, msg) { E.push({ path: path, message: msg, kind: "structure" }); }
    function num(path, v, nullable) { if (v === null && nullable) return; if (!isNum(v)) err(path, "must be a finite number (got " + JSON.stringify(v) + ")."); }
    function vec(path, v, n) { if (!Array.isArray(v) || v.length !== n || !v.every(isNum)) err(path, "must be a list of " + n + " finite numbers."); }
    function mat3(path, v) { if (!Array.isArray(v) || v.length !== 3 || !v.every(function (r) { return Array.isArray(r) && r.length === 3 && r.every(isNum); })) err(path, "must be a 3×3 list of finite numbers."); }
    function block(path, v, spec) {
      if (v == null) return; if (!isObj(v)) { err(path, "must be an object."); return; }
      Object.keys(v).forEach(function (k) {
        var t = spec[k]; if (!t) { W.push({ path: path + "." + k, message: "unknown field '" + k + "' is kept but no engine uses it.", kind: "structure" }); return; }
        if (t === "num") num(path + "." + k, v[k]); else if (t === "num?") num(path + "." + k, v[k], true); else if (t === "bool") { if (typeof v[k] !== "boolean") err(path + "." + k, "must be true or false."); }
        else if (Array.isArray(t) && t.indexOf(v[k]) < 0) err(path + "." + k, "must be one of " + t.join(", ") + ".");
      });
    }
    if (!isObj(c)) { err("", "The configuration must be a JSON object."); return { errors: E, warnings: W }; }
    if (c.config_revision != null && REVISIONS_READ.indexOf(c.config_revision) < 0) err("config_revision", "Unknown configuration revision '" + c.config_revision + "'.");
    var ct = c.controller || {};
    if (ct.type != null && CONTROLLERS.research.indexOf(ct.type) < 0 && String(ct.type).charAt(0) !== "?") err("controller.type", "Unknown controller '" + ct.type + "'.");
    if (ct.structure != null && ["decoupled", "mimo-lqr"].indexOf(ct.structure) < 0) err("controller.structure", "Unknown controller structure '" + ct.structure + "'.");
    block("controller.lqr", ct.lqr, { tilt_deg: "num", rate_dps: "num", wheel_rad_s: "num", yaw_deg: "num", yaw_rate_dps: "num", r_scale: "num" });
    block("controller.pid", ct.pid, { integrator_pole: "num", yaw_integrator_pole: "num", anti_windup: ["clamp", "conditional"], reset_on_events: "bool" });
    block("controller.adaptive", ct.adaptive, { gamma: "num", clamp_deg: "num" });
    block("controller.nonlinear", ct.nonlinear, { omega_n: "num", zeta: "num", yaw_omega_n: "num", yaw_zeta: "num", momentum_omega: "num", max_ref_tilt_deg: "num", compensate_gravity: "bool", compensate_gyroscopic: "bool", compensate_friction: "bool" });
    block("controller.allocation", ct.allocation, { method: ["clip", "bounded-ls"] });
    var es = c.estimator || {};
    if (es.type != null && ESTIMATORS_ALL.indexOf(es.type) < 0) err("estimator.type", "Unknown estimator '" + es.type + "'.");
    block("estimator.mekf", es.mekf, { gyro_noise_dps: "num?", gyro_bias_walk_dps: "num?", accel_noise_mps2: "num?", init_attitude_sd_deg: "num?", init_bias_sd_dps: "num?", accel_gate_mps2: "num?", accel_direction_sd_deg: "num?", tau_alpha_s: "num?", compensate_dynamic: "bool" });
    block("estimator.cf3d", es.cf3d, { tau_s: "num", accel_gate_mps2: "num", bias_gain: "num", tau_alpha_s: "num", compensate_dynamic: "bool" });
    if (es.stale_after_s != null) { num("estimator.stale_after_s", es.stale_after_s); if (isNum(es.stale_after_s) && !(es.stale_after_s > 0)) err("estimator.stale_after_s", "must be a positive number of seconds."); }
    block("reference", c.reference, { attitude: ["balance"], heading: ["hold", "free", null], yaw_deg: "num?" });   // edge: heading null
    block("solver", c.solver, { method: ["rk4"], integration_hz: "num?" });
    block("recovery", c.recovery, { attitude_error_deg: "num", rate_dps: "num", hold_s: "num", max_time_s: "num?", yaw_objective: ["hold", "free"] });
    block("termination", c.termination, { stop_on_recovery: "bool", post_fall_s: "num", check_lift_off: "bool", overspeed_rpm: "num?", max_quaternion_drift: "num" });
    if (c.actuator && c.actuator.electrical_limit != null && ["command", "continuous"].indexOf(c.actuator.electrical_limit) < 0) err("actuator.electrical_limit", "must be 'command' or 'continuous'.");
    if (c.sensor && c.sensor.imu_position_m != null) vec("sensor.imu_position_m", c.sensor.imu_position_m, 3);
    if (c.uncertainty && c.uncertainty.inertia_perturbation_kgm2 != null) mat3("uncertainty.inertia_perturbation_kgm2", c.uncertainty.inertia_perturbation_kgm2);
    if (c.initial && c.initial.wheel_speeds_rpm != null) { if (!Array.isArray(c.initial.wheel_speeds_rpm) || !c.initial.wheel_speeds_rpm.every(isNum)) err("initial.wheel_speeds_rpm", "must be a list of finite numbers [rpm]."); }
    explicitState(c, err);
    if (c.plant != null) {
      if (!isObj(c.plant)) err("plant", "must be an object.");
      else {
        if (c.plant.base_inertia_kgm2 != null) mat3("plant.base_inertia_kgm2", c.plant.base_inertia_kgm2);
        if (c.plant.base_com_m != null) vec("plant.base_com_m", c.plant.base_com_m, 3);
        (c.plant.components || []).forEach(function (x, i) { var p = "plant.components." + i; if (!isObj(x)) { err(p, "must be an object."); return; } num(p + ".mass_kg", x.mass_kg); vec(p + ".com_m", x.com_m, 3); if (x.inertia_kgm2 != null) mat3(p + ".inertia_kgm2", x.inertia_kgm2); });
      }
    }
    if (c.wheels != null) {
      if (!Array.isArray(c.wheels) || !c.wheels.length) err("wheels", "must be a non-empty list.");
      else c.wheels.forEach(function (w, i) { var p = "wheels." + i; if (!isObj(w)) { err(p, "must be an object."); return; } if (w.axis != null) vec(p + ".axis", w.axis, 3); ["Jw", "KV", "R", "Vs", "Imax", "wmaxRpm", "cv", "cc", "health"].forEach(function (k) { if (w[k] != null) num(p + "." + k, w[k]); }); });
    }
    (c.disturbances || []).forEach(function (d, i) {
      if (!d || DIST_EXT.indexOf(d.type) < 0) return;
      var p = "disturbances." + i;
      if (["world", "body"].indexOf(d.frame) < 0) err(p + ".frame", "must be 'world' or 'body'.");
      vec(p + ".direction", d.direction, 3);
      if (d.type === "impulse") { num(p + ".magnitude_Nms", d.magnitude_Nms); num(p + ".t_s", d.t_s); }
      else if (d.type === "force_impulse") { num(p + ".impulse_Ns", d.impulse_Ns); vec(p + ".point_m", d.point_m, 3); num(p + ".t_s", d.t_s); }
      else { num(p + ".magnitude_Nm", d.magnitude_Nm); num(p + ".t_start_s", d.t_start_s); num(p + ".duration_s", d.duration_s, true); }
    });
    (c.events || []).forEach(function (e, i) {
      if (!e) return; var p = "events." + i;
      if (e.duration_s != null) num(p + ".duration_s", e.duration_s, true);
      if (e.type === "wheel_degradation") num(p + ".health", e.health);
      if (e.type === "wheel_torque_limit") num(p + ".limit_Nm", e.limit_Nm);
      if (e.type === "wheel_speed_limit") num(p + ".limit_rpm", e.limit_rpm);
    });
    return { errors: E, warnings: W };
  }

  /* revision 1.2 initial state (docs/EXPERIMENT_CONTRACT.md): the same rules the backend enforces, for early feedback */
  function edgeThetaOfQ(q) { var h = Math.PI / 8, qr = TWIN.Q3.mul([Math.cos(h), -Math.sin(h), 0, 0], q); return { theta: 2 * Math.atan2(qr[1], qr[0]), offAxisDeg: 2 * Math.atan2(Math.hypot(qr[2], qr[3]), Math.hypot(qr[0], qr[1])) * 180 / Math.PI }; }
  function explicitState(c, err) {
    var ini = c.initial || {}, edge = c.mode === "edge", q = ini.attitude_q, w = ini.body_rate_dps;
    if (q != null) {
      if (!Array.isArray(q) || q.length !== 4 || !q.every(isNum)) err("initial.attitude_q", "must be a list of 4 finite numbers [w, x, y, z] (scalar first, body → world).");
      else {
        var n = Math.hypot(q[0], q[1], q[2], q[3]);
        if (Math.abs(n - 1) > 1e-6) err("initial.attitude_q", "must be a unit quaternion; its norm is " + n.toPrecision(9) + " (tolerance 1e-6). Use Normalise.");
        else if (edge) { var o = edgeThetaOfQ(TWIN.Q3.norm(q)); if (o.offAxisDeg > 1e-4) err("initial.attitude_q", "Edge mode rotates only about the support edge (body x): this attitude is " + o.offAxisDeg.toPrecision(4) + "° off that axis."); }
      }
      ["tilt_deg", "azimuth_deg", "reference"].forEach(function (k) { if (ini[k] != null) err("initial.attitude_q", "An explicit initial attitude replaces initial." + k + ", which must be null."); });
    }
    if (w != null) {
      if (!Array.isArray(w) || w.length !== 3 || !w.every(isNum)) err("initial.body_rate_dps", "must be a list of 3 finite numbers [°/s], body axes.");
      else {
        w.forEach(function (x, j) { if (Math.abs(x) > 200) err("initial.body_rate_dps." + j, "Initial body rate ω_" + "xyz"[j] + " = " + x + " °/s must lie between −200 and 200 °/s."); });
        if (edge && (Math.abs(w[1]) > 1e-9 || Math.abs(w[2]) > 1e-9)) err("initial.body_rate_dps", "Edge mode rotates only about the support edge: the body rate must be [ω_x, 0, 0].");
      }
      if (ini.rate_dps != null) err("initial.body_rate_dps", "An explicit body-rate vector replaces initial.rate_dps, which must be null.");
    } else if (q != null && !edge && isNum(ini.rate_dps) && ini.rate_dps !== 0) err("initial.rate_dps", "With an explicit initial attitude the legacy rate has no axis; give initial.body_rate_dps instead.");
    var ref = c.reference;
    if (isObj(ref)) {
      if (edge && (ref.heading != null || ref.yaw_deg != null)) err("reference." + (ref.heading != null ? "heading" : "yaw_deg"), "Edge mode has no heading: the cube can only rotate about the support edge.");
      if (!edge && ref.heading === "free") {
        if (c.controller && c.controller.type === "lqr" && c.controller.structure === "mimo-lqr") err("reference.heading", "The coupled MIMO LQR regulates the full attitude including the heading; a free heading is not supported with it.");
        if ((c.commands || []).length) err("commands", "Yaw commands need reference.heading = 'hold'.");
        if (isNum(ref.yaw_deg) && ref.yaw_deg !== 0) err("reference.yaw_deg", "A heading offset needs reference.heading = 'hold'.");
        if (c.recovery && c.recovery.yaw_objective === "hold") err("recovery.yaw_objective", "The recovery criteria cannot require a heading that the controller does not control (reference.heading = 'free').");
      }
    }
  }
  /* body → world rotation and body rate of the initial state, whichever inputs describe it (setup preview) */
  function initialPose(cfg, mp) {
    var ini = cfg.initial || {}, edge = cfg.mode === "edge", DEG = Math.PI / 180;
    if (ini.attitude_q != null && Array.isArray(ini.attitude_q) && ini.attitude_q.every(isNum) && Math.hypot.apply(null, ini.attitude_q) > 0) {
      var q = TWIN.Q3.norm(ini.attitude_q);
      if (edge) { var th = edgeThetaOfQ(q).theta; return { R: TWIN.edgeR(th), theta: th, explicit: true }; }
      return { R: TWIN.Q3.rot(q), q: q, explicit: true };
    }
    var st = TWIN.initialState(cfg, mp);
    return edge ? { R: TWIN.edgeR(isFinite(st.theta) ? st.theta : 0), theta: st.theta, explicit: false } : { R: TWIN.Q3.rot(st.q.every(isFinite) ? st.q : TWIN.QEQ), q: st.q, w: st.w, explicit: false };
  }
  /* the explicit state equivalent to the legacy inputs (switching the setup form to the explicit editor) */
  function explicitFromLegacy(cfg, mp) {
    var edge = cfg.mode === "edge", DEG = Math.PI / 180, st = TWIN.initialState(cfg, mp);
    if (edge) { var a = (Math.PI / 4 + (isFinite(st.theta) ? st.theta : 0)) / 2; return { attitude_q: [Math.cos(a), Math.sin(a), 0, 0], body_rate_dps: [isFinite(st.thetadot) ? st.thetadot / DEG : 0, 0, 0] }; }
    var q = st.q.every(isFinite) ? st.q : TWIN.QEQ, w = (st.w || [0, 0, 0]).map(function (x) { return isFinite(x) ? x / DEG : 0; });
    return { attitude_q: q.slice(), body_rate_dps: w };
  }

  /* ---------------- layer 2: can the chosen engine run it? ---------------- */
  var EVALUATION_ONLY = ["recovery"];   // does not change the trajectory: the browser warns instead of refusing
  function describeFeature(path) {
    var map = { "controller.structure": "the coupled MIMO LQR", "controller.type": "the nonlinear quaternion controller", "estimator.type": "the 3-D attitude estimators (cf3d, MEKF)", solver: "an integration rate other than the loop rate", plant: "an explicit inertia tensor or rigid components", wheels: "per-wheel parameters and wheel axes", termination: "research termination rules", recovery: "research recovery criteria",
      "initial.attitude_q": "an explicit initial attitude quaternion", "initial.body_rate_dps": "an explicit initial body-rate vector", "initial.wheel_speeds_rpm": "initial wheel speeds", reference: "a control objective other than the default (free heading or a heading offset)", "estimator.stale_after_s": "an estimate age limit" };
    var base = path.split(".")[0];
    if (/^disturbances\./.test(path)) return "impulses and torque biases";
    if (/^events\./.test(path)) return "wheel degradation, imposed limits and timed faults";
    return map[path] || map[base] || path;
  }
  /* engine: "browser" (DEMO, AERIS_TWIN) or "backend" (SIMULATION, with caps = the reported capabilities) */
  /* the browser normaliser cannot read revision-1.1 disturbances and events; their checks come from layer 1 */
  function extItemPath(cfg, path) {
    var m = /^(disturbances|events)\.(\d+)/.exec(path || ""); if (!m) return false;
    var item = (cfg[m[1]] || [])[+m[2]];
    return !!item && (m[1] === "disturbances" ? DIST_EXT.indexOf(item.type) >= 0 : EVENT_EXT.indexOf(item.type) >= 0);
  }
  function validateFor(cfgIn, engine, caps) {
    var cfg = normalize(cfgIn), S = structural(cfg), E = S.errors.slice(), W = S.warnings.slice(), ext = extensions(cfg);
    var legacy = TWIN.validateConfig(cfg), v = legacy;
    function superseded(path) {   // the browser checks the legacy tilt inputs; an explicit initial state replaces them
      var ini = cfg.initial || {};
      if (ini.attitude_q != null && /^initial(\.(tilt_deg|azimuth_deg|reference))?$/.test(path || "")) return true;
      if (ini.body_rate_dps != null && path === "initial.rate_dps") return true;
      return false;
    }
    legacy = { errors: legacy.errors.filter(function (e) { return !extItemPath(cfg, e.path) && !superseded(e.path); }), warnings: legacy.warnings.filter(function (w) { return !extItemPath(cfg, w.path) && !superseded(w.path); }) };
    if (engine === "browser") {
      legacy.errors.forEach(function (e) { E.push(e); });
      legacy.warnings.forEach(function (w) { W.push(w); });
      ext.forEach(function (path) {
        if (EVALUATION_ONLY.indexOf(path) >= 0) W.push({ path: path, kind: "capability", message: "Research recovery criteria are evaluated by the research backend; this browser run reports the legacy COM-lean outcome only." });
        else if (path !== "controller.type" && path !== "estimator.type" && path !== "controller.structure") E.push({ path: path, kind: "capability", message: "This setup uses " + describeFeature(path) + ", which only the research backend runs. Switch to SIMULATION mode, or remove it to run here." });
      });
      if (cfg.termination != null && ext.indexOf("termination") < 0) W.push({ path: "termination", kind: "capability", message: "The research backend's default termination rules (end at loss of support, quaternion-drift check) are not applied by the browser engine; it records 1.5 s past a fall as before." });
      return result(E, W, cfg, v, engine);
    }
    // backend: keep the physical checks; re-decide the browser-engine limits against the reported capabilities
    caps = caps || {};
    if (!caps.reported) E.push({ path: "", kind: "capability", message: "The research backend has not reported its capabilities yet (not reachable or not checked). Nothing is assumed about its limits." });
    var lim = caps.limits || {}, maxDur = lim.maxDuration_s, minDur = lim.minDuration_s;
    var customPlant = inUse("plant", cfg.plant) || inUse("wheels", cfg.wheels);
    legacy.errors.forEach(function (e) {
      if (e.kind === "capability") return;
      if (customPlant && !e.kind && /^(attachments|initial|controller|params\.fs|params\.Jw|params\.kJ)/.test(e.path)) {
        W.push({ path: e.path, kind: "advisory", message: "Browser pre-check on the base cube only (this setup has its own plant/wheels; the research backend decides): " + e.message }); return;
      }
      if (e.kind === "engine-range") {
        if (e.path === "duration_s" && isNum(maxDur) && cfg.duration_s >= (minDur || 0) && cfg.duration_s <= maxDur) return;
        if (e.path === "record_hz" && /does not divide/.test(e.message)) return;   // re-checked below against the integration rate
        if (e.path === "record_hz" && caps.rates && Array.isArray(caps.rates.record_hz) && cfg.record_hz >= caps.rates.record_hz[0] && cfg.record_hz <= caps.rates.record_hz[1]) return;
        if (e.path === "attachments" && caps.plant && cfg.attachments.length <= caps.plant.maxAttachments) return;
      }
      E.push(e);
    });
    legacy.warnings.forEach(function (w) { if (w.kind !== "capability") W.push(w); });
    // recording rate: the backend records integration-step states, so record_hz must divide the integration rate (docs/RECORDING.md)
    var fInt = (cfg.solver && isNum(cfg.solver.integration_hz)) ? cfg.solver.integration_hz : cfg.params.fs;
    if (isNum(cfg.record_hz) && cfg.record_hz > 0 && isNum(fInt) && fInt > 0 && Math.abs(fInt / cfg.record_hz - Math.round(fInt / cfg.record_hz)) > 1e-9 * Math.max(1, fInt / cfg.record_hz))
      E.push({ path: "record_hz", kind: "range", message: "The recording rate " + cfg.record_hz + " Hz does not divide the " + fInt + " Hz integration rate; it could only be realised as " + +(fInt / Math.max(1, Math.round(fInt / cfg.record_hz))).toPrecision(6) + " Hz. Choose a divisor (nearest: " + +(fInt / Math.ceil(fInt / cfg.record_hz)).toPrecision(6) + " or " + +(fInt / Math.max(1, Math.floor(fInt / cfg.record_hz))).toPrecision(6) + " Hz)." });
    if (caps.reported) {
      // revision-1.2 features only go to a backend that reports reading revision 1.2 (an AERIS v4 backend does not,
      // and must not receive a setup it would run differently): refused here with the feature named
      var revs = caps.config && Array.isArray(caps.config.revisions) ? caps.config.revisions : null;
      if (!revs || revs.indexOf("1.2") < 0) ext.forEach(function (p) {
        if (REV_1_2.indexOf(p) >= 0) E.push({ path: p, kind: "capability", message: "This setup uses " + describeFeature(p) + " (configuration revision 1.2), but the research backend reports " + (revs ? "revisions " + revs.join(", ") + " only" : "no configuration revisions") + ". It would not run this setup as written: update the backend (AERIS v5) or remove it." });
      });
      var ctl = cfg.controller.type;
      if ((caps.controllers || []).indexOf(ctl) < 0) E.push({ path: "controller.type", kind: "capability", message: "The research backend does not report controller '" + ctl + "'." });
      if (cfg.controller.structure === "mimo-lqr" && (caps.structures || []).indexOf("mimo-lqr") < 0) E.push({ path: "controller.structure", kind: "capability", message: "The research backend does not report a MIMO LQR." });
      var ests = caps.estimators && caps.estimators[cfg.mode];
      if (ests && ests.indexOf(cfg.estimator.type) < 0) E.push({ path: "estimator.type", kind: "capability", message: "The research backend offers these estimators in " + cfg.mode + " mode: " + ests.join(", ") + "." });
      if (isNum(maxDur) && (cfg.duration_s > maxDur || cfg.duration_s < (minDur || 0))) E.push({ path: "duration_s", kind: "engine-range", message: "Duration must lie between " + (minDur || 0) + " and " + maxDur + " s on the research backend." });
    }
    // the design and mass properties are only meaningful when the browser can compute them for this setup
    return result(E, W, cfg, v, engine);
  }
  function result(E, W, cfg, v, engine) {
    var ok = E.length === 0;
    return { ok: ok, errors: E, warnings: W, config: cfg, engine: engine, extensions: extensions(cfg), mp: v && v.mp ? v.mp : null, design: ok && v && v.ok ? v.design : null, browserValidation: v };
  }

  return { REVISION: REVISION, REVISIONS_READ: REVISIONS_READ, NAMES: NAMES, CONTROLLERS: CONTROLLERS, ESTIMATORS_ALL: ESTIMATORS_ALL, RECOVERY_DEFAULTS: RECOVERY_DEFAULTS, TERMINATION_DEFAULTS: TERMINATION_DEFAULTS, inUse: inUse,
    extensions: extensions, normalize: normalize, structural: structural, validateFor: validateFor, describeFeature: describeFeature,
    initialPose: initialPose, explicitFromLegacy: explicitFromLegacy, edgeThetaOfQ: edgeThetaOfQ };
})();
if (typeof module !== "undefined") module.exports = AERIS_CFG;

/* =====================================================================
   AERIS · EVENTS — the event timeline of a run.

   New runs carry a timeline computed by the engine at every integration
   step (AERIS_TWIN.buildTimeline). Records saved before revision 1.1 have
   none; fromRecord() rebuilds one from the recorded samples with the same
   rules, at the recording resolution, and says so (resolution_s).
   ===================================================================== */
var AERIS_EVENTS = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var SEVERITY_ORDER = { failure: 0, warning: 1, stable: 2, info: 3 };
  function fromRecord(rec) {
    var S = rec.samples && rec.samples.cols, cfg = TWIN.normalizeConfig(rec.config), edge = cfg.mode === "edge";
    if (!S || !S.t || S.t.length < 2) return { rules: TWIN.EVENT_RULES, resolution_s: null, events: [], rebuilt: true };
    var n = S.t.length - 1, d = rec.derived || {}, wmax = d.motor && d.motor.wmax ? d.motor.wmax : cfg.params.wmaxRpm * TWIN.RPM;
    var om = edge ? [S.omega_x] : [S.omega_x, S.omega_y, S.omega_z];
    var estErr = null;
    if (edge && cfg.estimator.type !== "ideal" && S.thetahat && S.theta) { estErr = S.theta.map(function (th, i) { return S.thetahat[i] - th; }); }
    var M = rec.metrics || {}, ev = rec.events || {};
    var tl = TWIN.buildTimeline({
      mode: cfg.mode, n: n, tAt: function (i) { return S.t[i]; }, satW: [S.sat], satAggregate: !edge, om: om, wmax: wmax, estErr: estErr, cfg: cfg, metrics: M,
      fellAt: M.fellAt_s != null ? M.fellAt_s : (ev.fellAt != null ? ev.fellAt : null), fallCause: ev.fallCause || null, contactAt: M.contactAt_s != null ? M.contactAt_s : (ev.contactAt != null ? ev.contactAt : null),
      failedWheels: ev.failedWheels || [], windowEnd: cfg.duration_s, recordedEnd: S.t[n], resolution_s: S.t[1] - S.t[0]
    });
    tl.rebuilt = true;
    return tl;
  }
  function timelineOf(rec) { return rec && rec.timeline && Array.isArray(rec.timeline.events) ? rec.timeline : fromRecord(rec); }
  /* events active at time t (intervals containing t, or point events within half a sample) */
  function activeAt(tl, t, halfStep) {
    var h = halfStep || 0;
    return (tl.events || []).filter(function (e) { return e.t_end != null ? (t >= e.t - 1e-9 && t < e.t_end + 1e-9) : Math.abs(e.t - t) <= h; });
  }
  function counts(tl) { var c = {}; (tl.events || []).forEach(function (e) { c[e.type] = (c[e.type] || 0) + 1; }); return c; }
  function worstSeverity(list) { var w = "info"; list.forEach(function (e) { if (SEVERITY_ORDER[e.severity] < SEVERITY_ORDER[w]) w = e.severity; }); return w; }
  return { fromRecord: fromRecord, timelineOf: timelineOf, activeAt: activeAt, counts: counts, worstSeverity: worstSeverity, DEFS: TWIN.EVENT_DEFS, RULES: TWIN.EVENT_RULES };
})();
if (typeof module !== "undefined") module.exports = AERIS_EVENTS;

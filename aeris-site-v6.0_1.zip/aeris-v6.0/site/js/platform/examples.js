/* =====================================================================
   AERIS · EXAMPLES — built-in example experiments (fixed setups). Their
   recordings are computed on demand by the AERIS Twin engine in this browser
   and carry the fixed IDs AERIS-EXP-000010 … 000016 (js/platform/ids.js).
   They are examples of the workflow, not research results.
   ===================================================================== */
var AERIS_EXAMPLES = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  function exCfg(mode, o) { var c = TWIN.defaultConfig(mode); Object.keys(o).forEach(function (k) { c[k] = o[k]; }); return c; }
  var LIST = [
    { id: "example-regression", name: "Regression case · PID with a +3 mm COM offset (4 s)", note: "The case that used to report 'Recovered' while the wheel was still spinning up.", cfg: function () { return exCfg("edge", { controller: { type: "pid", knowsAttachments: false, reconfigureOnFailure: true }, initial: { tilt_deg: 0, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, comOffset_m: 0.003, duration_s: 4 }); } },
    { id: "example-edge-recovery", name: "Edge · LQR recovers from a 2° tilt (6 s)", note: "Baseline recovery on the support edge.", cfg: function () { return exCfg("edge", { initial: { tilt_deg: 2, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, duration_s: 6 }); } },
    { id: "example-edge-push", name: "Edge · 0.3 N push on the top edge, world frame (8 s)", note: "A horizontal push fixed in the room, applied for 2 s.", cfg: function () { return exCfg("edge", { initial: { tilt_deg: 0, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, duration_s: 8, disturbances: [{ id: "F1", type: "force", magnitude_N: 0.3, point_m: [0.09, 0.18, 0.18], direction: [0, 1, 0], frame: "world", t_start_s: 1, duration_s: 2 }] }); } },
    { id: "example-edge-mass", name: "Edge · 60 g clip near the top, informed LQR (6 s)", note: "An added point mass moves the centre of mass; the controller is told about it.", cfg: function () { return exCfg("edge", { controller: { type: "lqr", knowsAttachments: true, reconfigureOnFailure: true }, attachments: [{ id: "m1", label: "Clip", mass_kg: 0.06, pos_m: [0.09, 0.03, 0.18] }], initial: { tilt_deg: 1, rate_dps: 0, azimuth_deg: 0, reference: "balance" }, duration_s: 6 }); } },
    { id: "example-corner-push", name: "Corner · recovers from a 2° tilt, then takes a 0.25 N push (10 s)", note: "Three-wheel corner balance; the push acts at the top corner in the room frame.", cfg: function () { return exCfg("corner", { initial: { tilt_deg: 2, rate_dps: 0, azimuth_deg: 40, reference: "geometric" }, duration_s: 10, disturbances: [{ id: "F1", type: "force", magnitude_N: 0.25, point_m: [0.18, 0.18, 0.18], direction: [1, 0.4, 0], frame: "world", t_start_s: 4, duration_s: 0.6 }] }); } },
    { id: "example-corner-failure", name: "Corner · wheel X fails at 0.1 s, torque reallocated (10 s)", note: "Balance survives on two wheels; yaw is given up.", cfg: function () { return exCfg("corner", { initial: { tilt_deg: 2, rate_dps: 0, azimuth_deg: 40, reference: "geometric" }, duration_s: 10, events: [{ id: "E1", type: "wheel_failure", wheel: "x", t_s: 0.1 }] }); } },
    { id: "example-corner-yaw", name: "Corner · 90° yaw turn while balancing (8 s)", note: "Rotation about the balance axis, which gravity does not act on.", cfg: function () { return exCfg("corner", { initial: { tilt_deg: 0, rate_dps: 0, azimuth_deg: 0, reference: "geometric" }, duration_s: 8, commands: [{ id: "C1", type: "yaw_step", t_s: 1, angle_deg: 90 }] }); } }
  ];
  function get(id) { return LIST.filter(function (e) { return e.id === id; })[0] || null; }
  return { LIST: LIST, get: get };
})();
if (typeof module !== "undefined") module.exports = AERIS_EXAMPLES;

/* =====================================================================
   AERIS · COMPARE — computed labels for a set of runs.

   Labels name the run that is best on ONE metric, for THESE runs under
   THIS setup ("Lowest settling time", "Lowest control effort", …). There
   is deliberately no overall winner: the metrics trade off against each
   other and a different setup can reverse them. A metric only takes part
   when it is defined for a run (a fallen run has no settling time and no
   recovery margin; its control effort stops at the fall, so it is left
   out of the effort comparison too). Values equal at display precision
   are reported as a tie.
   ===================================================================== */
var AERIS_COMPARE = (function () {
  "use strict";
  var LABELS = [
    { key: "settle", label: "Lowest settling time", metric: "settle_s", better: "min", unit: "s", digits: 3, eligible: function (r) { return r.outcome && r.outcome.code === "recovered" && r.metrics.settle_s != null; },
      why: "Time after which the COM lean stays within the settling band to the end of the window (recovered runs only)." },
    { key: "effort", label: "Lowest control effort", metric: "effort_Nms", better: "min", unit: "N·m·s", digits: 4, eligible: function (r) { return r.metrics.fellAt_s == null && isFinite(r.metrics.effort_Nms); },
      why: "∫ Σ|T| dt over the window: total motor torque used (runs that did not fall)." },
    { key: "margin", label: "Largest recovery margin", metric: "leanMargin_deg", better: "max", unit: "°", digits: 2, eligible: function (r) { return r.metrics.leanMargin_deg != null && isFinite(r.metrics.leanMargin_deg); },
      why: "Fall threshold minus the peak COM lean: how far the run stayed from falling." },
    { key: "wheel", label: "Lowest peak wheel speed", metric: "peakOmega_frac", better: "min", unit: "% of limit", digits: 0, scale: 100, eligible: function (r) { return r.metrics.fellAt_s == null && isFinite(r.metrics.peakOmega_frac); },
      why: "Highest wheel speed reached, as a share of the speed limit (runs that did not fall)." }
  ];
  function round(v, d) { var f = Math.pow(10, d); return Math.round(v * f) / f; }
  /* labels(records) → [{ key, label, winners: [index], value, tie, eligible: n, excluded: [index], why }] */
  function labels(records) {
    return LABELS.map(function (L) {
      var el = [], ex = [];
      records.forEach(function (r, i) { if (r && r.metrics && L.eligible(r)) el.push(i); else ex.push(i); });
      var out = { key: L.key, label: L.label, metric: L.metric, unit: L.unit, why: L.why, winners: [], value: null, tie: false, eligible: el.length, excluded: ex };
      if (el.length < 2) { out.reason = el.length === 1 ? "only one run has this metric defined" : "no run has this metric defined"; return out; }
      var sc = L.scale || 1, vals = el.map(function (i) { return round(records[i].metrics[L.metric] * sc, L.digits); });
      var best = L.better === "min" ? Math.min.apply(null, vals) : Math.max.apply(null, vals);
      el.forEach(function (i, k) { if (vals[k] === best) out.winners.push(i); });
      out.value = best; out.tie = out.winners.length > 1;
      return out;
    });
  }
  /* flatten a config to dotted paths (arrays and objects inside arrays compared as JSON) */
  function flatten(o, pre, out) {
    out = out || {}; pre = pre || "";
    Object.keys(o || {}).forEach(function (k) {
      var v = o[k], p = pre ? pre + "." + k : k;
      if (v && typeof v === "object" && !Array.isArray(v)) flatten(v, p, out); else out[p] = JSON.stringify(v);
    });
    return out;
  }
  /* which config paths differ across the records */
  function differingPaths(records) {
    var flats = records.map(function (r) { return flatten(r.config); }), keys = {};
    flats.forEach(function (f) { Object.keys(f).forEach(function (k) { keys[k] = true; }); });
    return Object.keys(keys).filter(function (k) { return flats.some(function (f) { return f[k] !== flats[0][k]; }); }).sort();
  }
  /* a controller set: the same setup run with different controllers and nothing else changed */
  function isControllerSet(records) {
    if (!records || records.length < 2) return false;
    var d = differingPaths(records), ctrls = records.map(function (r) { return r.config.controller.type; });
    return d.length === 1 && d[0] === "controller.type" && ctrls.every(function (c, i) { return ctrls.indexOf(c) === i; });
  }
  return { LABELS: LABELS, labels: labels, differingPaths: differingPaths, isControllerSet: isControllerSet, flatten: flatten };
})();
if (typeof module !== "undefined") module.exports = AERIS_COMPARE;

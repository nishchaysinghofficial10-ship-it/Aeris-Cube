/* =====================================================================
   AERIS · EXPERIMENT IDS — AERIS-EXP-###### (six digits).

   Allocation (see docs/BACKEND_INTEGRATION.md, "Experiment IDs"):
     000001–000009  AERIS Twin reference experiments (the scripted, standing
                    experiments on the Twin page; formerly ARC-EXP-0001…0007)
     000010–000099  built-in example recordings in AERIS Lab
     000100+        runs created in this browser (per-browser counter)
   A research backend issues its own IDs from its database sequence. A run's
   globally unique key is its storage `id` (e.g. run-lx3k9f-1a2b3c4d); the
   experiment ID is the human-facing label and is re-issued if an imported
   run's ID clashes with a different run already in the library.
   ===================================================================== */
var AERIS_IDS = (function () {
  "use strict";
  var PREFIX = "AERIS-EXP-", DIGITS = 6, RE = /^AERIS-EXP-(\d{6})$/, LEGACY_RE = /^ARC-EXP-(\d{1,6})$/;
  var RANGES = { reference: [1, 9], example: [10, 99], local: [100, 999999] };
  var EXAMPLES = { "example-regression": 10, "example-edge-recovery": 11, "example-edge-push": 12, "example-edge-mass": 13, "example-corner-push": 14, "example-corner-failure": 15, "example-corner-yaw": 16 };
  var KEY = "aeris.v2.expSeq";
  var store = null;
  function useStore(s) { store = s; }
  function pad(n) { var s = String(n); while (s.length < DIGITS) s = "0" + s; return s; }
  function format(n) { if (!(n >= 1 && n <= 999999) || Math.floor(n) !== n) throw new Error("experiment number out of range: " + n); return PREFIX + pad(n); }
  function parse(id) { var m = RE.exec(String(id)); return m ? parseInt(m[1], 10) : null; }
  function isValid(id) { var n = parse(id); return n !== null && n >= 1; }
  function kind(id) {
    var n = parse(id); if (n === null || n < 1) return null;
    return n <= RANGES.reference[1] ? "reference" : n <= RANGES.example[1] ? "example" : "local";
  }
  /* ARC-EXP-0003 → AERIS-EXP-000003 (the retired naming; same number) */
  function fromLegacy(id) { var m = LEGACY_RE.exec(String(id)); return m ? format(parseInt(m[1], 10)) : null; }
  function forExample(key) { return EXAMPLES[key] ? format(EXAMPLES[key]) : null; }
  function forReference(n) { if (!(n >= RANGES.reference[0] && n <= RANGES.reference[1])) throw new Error("reference experiments are numbered 1–9"); return format(n); }
  function readSeq() { try { var v = store && store.getItem(KEY); var n = v ? parseInt(v, 10) : NaN; return isFinite(n) ? n : RANGES.local[0] - 1; } catch (e) { return RANGES.local[0] - 1; } }
  function writeSeq(n) { try { if (store) store.setItem(KEY, String(n)); } catch (e) { /* storage blocked: ids stay unique within this session */ } }
  var sessionMax = RANGES.local[0] - 1;
  /* next local ID, above the stored counter and above every ID already in use */
  function next(taken) {
    var max = Math.max(readSeq(), sessionMax);
    (taken || []).forEach(function (id) { var n = parse(id); if (n !== null && n > max) max = n; });
    var n = Math.max(RANGES.local[0] - 1, max) + 1;
    sessionMax = n; writeSeq(n);
    return format(n);
  }
  /* research sweeps: AERIS-SWP-###### from their own per-browser counter */
  var SWP_RE = /^AERIS-SWP-(\d{6})$/, SWP_KEY = "aeris.v2.swpSeq", swpMax = 0;
  function nextSweep(taken) {
    var cur = 0; try { cur = parseInt(store && store.getItem(SWP_KEY), 10) || 0; } catch (e) { cur = 0; }
    var max = Math.max(cur, swpMax);
    (taken || []).forEach(function (id) { var m = SWP_RE.exec(String(id)); if (m && +m[1] > max) max = +m[1]; });
    swpMax = max + 1; try { if (store) store.setItem(SWP_KEY, String(swpMax)); } catch (e) { /* ignore */ }
    return "AERIS-SWP-" + pad(swpMax);
  }
  function isSweepId(id) { return SWP_RE.test(String(id)); }
  return { PREFIX: PREFIX, RANGES: RANGES, EXAMPLES: EXAMPLES, KEY: KEY, useStore: useStore, format: format, parse: parse, isValid: isValid, kind: kind, fromLegacy: fromLegacy, forExample: forExample, forReference: forReference, next: next, nextSweep: nextSweep, isSweepId: isSweepId };
})();
if (typeof module !== "undefined") module.exports = AERIS_IDS;

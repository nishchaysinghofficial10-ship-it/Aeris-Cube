/* =====================================================================
   AERIS · EXPERIMENT SERVICE — the single entry point the UI uses to run,
   replay and compare experiments. The UI never calls a simulator directly:

       UI  →  AERIS_SERVICE  →  data-source adapter
                                 ├─ LocalSimulatorAdapter    (AERIS Twin browser engine)
                                 ├─ ResearchApiAdapter       (Python research backend, REST + WS)
                                 ├─ HardwareTelemetryAdapter (telemetry through the research backend; read-only)
                                 └─ ReplayAdapter            (saved runs, imports, examples)

   System modes choose the adapters:
     DEMO        single runs and small sweeps on the local engine; replay
     SIMULATION  single runs and sweeps on the research backend; replay
     HARDWARE    live telemetry from the source connected to the research backend (the source declares
                 whether it is synthetic; the emulator is never shown as the physical cube); replay
   A mode can only be selected when its adapter reports itself available.
   ===================================================================== */
var AERIS_SERVICE = (function () {
  "use strict";
  var SCHEMA = typeof AERIS_SCHEMA !== "undefined" ? AERIS_SCHEMA : require("./schema.js");
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var CFG = typeof AERIS_CFG !== "undefined" ? AERIS_CFG : require("./config.js");
  var SWEEP = typeof AERIS_SWEEP !== "undefined" ? AERIS_SWEEP : require("./sweep.js");
  var JOBS = typeof AERIS_JOBS !== "undefined" ? AERIS_JOBS : require("./jobs.js");
  var ROUTES = {
    demo: { single: "local-simulator", sweep: "local-simulator", replay: "replay", live: null },
    simulation: { single: "research-api", sweep: "research-api", replay: "replay", live: null },
    hardware: { single: null, sweep: null, replay: "replay", live: "hardware-telemetry" }
  };
  var ORDER = ["demo", "simulation", "hardware"];
  var adapters = {}, mode = "demo", subs = [], groupSeq = 0;
  function register(a) { if (a && a.name) adapters[a.name] = a; return a; }
  function adapter(name) { return adapters[name] || null; }
  function primary(m) { var r = ROUTES[m]; return adapter(r.single || r.live); }
  function modeInfo(m) {
    var a = primary(m), av = a ? a.available() : { ok: false, reason: "No adapter is registered for this mode." };
    return { id: m, label: SCHEMA.MODES[m].label, text: SCHEMA.MODES[m].text, available: !!av.ok, reason: av.reason || null, adapter: a ? a.name : null, adapterLabel: a ? a.label : null, mock: !!(a && a.mock) };
  }
  function modes() { return ORDER.map(modeInfo); }
  function getMode() { return mode; }
  function setMode(m) {
    if (!ROUTES[m]) return { ok: false, reason: "Unknown mode '" + m + "'." };
    var info = modeInfo(m); if (!info.available) return { ok: false, reason: info.reason };
    mode = m; emit({ type: "mode", mode: m }); return { ok: true };
  }
  function route(purpose) { var n = ROUTES[mode][purpose]; return n ? adapter(n) : null; }
  function unavailable(purpose) { var info = modeInfo(mode); return Promise.reject({ code: "unavailable", message: purpose === "sweep" ? "Research sweeps are not available in " + info.label + " mode." : purpose === "single" ? "Running experiments is not available in " + info.label + " mode. " + (info.reason || "") : "Not available." }); }
  function emit(ev) { subs.slice().forEach(function (fn) { try { fn(ev); } catch (e) { /* ignore */ } }); }
  function onChange(fn) { subs.push(fn); return function () { subs = subs.filter(function (f) { return f !== fn; }); }; }

  /* ---------------- validation for the ACTIVE engine (docs: js/platform/config.js) ---------------- */
  function engineFor(m) { return (m || mode) === "simulation" ? "backend" : "browser"; }
  function engineCaps(m) { var a = adapter(ROUTES[m || mode].single || "local-simulator"); return a ? a.capabilities() : null; }
  function validateConfig(cfg, m) { return CFG.validateFor(cfg, engineFor(m), engineCaps(m)); }
  function validateSweep(def, m) {
    var eng = engineFor(m), caps = engineCaps(m);
    var lim = eng === "backend" && caps && caps.sweep ? { maxRuns: caps.sweep.maxRuns, maxDuration_s: caps.sweep.maxDuration_s } : SWEEP.LIMITS.local;
    return SWEEP.validate(def, { engine: eng, caps: caps, limits: lim });
  }
  /* authoritative backend check (SIMULATION): POST /validate; resolves null in DEMO */
  function validateRemote(cfg) { var a = route("single"); return a && a.validate && engineFor() === "backend" ? a.validate(cfg) : Promise.resolve(null); }
  function probe() { var a = adapter("research-api"); return a && a.probe ? a.probe().then(function (st) { emit({ type: "backend", status: st }); return st; }) : Promise.resolve(null); }
  function backendStatus() { var a = adapter("research-api"); return a && a.status ? a.status() : null; }

  /* ---------------- operations ---------------- */
  function runSingle(cfg, meta) {
    var a = route("single"); if (!a) return unavailable("single");
    return a.runSingle(cfg, Object.assign({ mode: mode }, meta || {})).then(function (out) { emit({ type: "run", ok: out.ok, record: out.record || null }); return out; }, function (e) {
      if (e && e.code === "invalid_config") return { ok: false, result: { ok: false, outcome: { code: "invalid", label: TWIN.OUTCOMES.invalid.label, reason: e.message }, errors: (e.details || []).map(function (d) { return typeof d === "string" ? { path: "", message: d } : d; }) } };
      throw e;
    });
  }
  /* the same setup run once per controller; nothing else changes between the runs */
  function runControllerSet(cfg, controllers, meta) {
    var a = route("single"); if (!a) return unavailable("single");
    var list = controllers && controllers.length ? controllers : ["pid", "lqr", "adp"];
    groupSeq += 1;
    var group = { id: "AERIS-SET-" + Date.now().toString(36) + "-" + groupSeq, kind: "controller-set", controllers: list.slice(), varied: list.indexOf("lqr-mimo") >= 0 ? "controller.type, controller.structure" : "controller.type" };
    var outs = [];
    return list.reduce(function (p, c) {
      return p.then(function () {
        // the preserving normaliser: research fields of the setup reach every run of the set unchanged
        var copy = CFG.normalize(TWIN.clone(cfg));
        if (c === "lqr-mimo") { copy.controller.type = "lqr"; copy.controller.structure = "mimo-lqr"; }
        else { copy.controller.type = c; if (copy.controller.structure === "mimo-lqr" && c !== "lqr") copy.controller.structure = "decoupled"; }
        return a.runSingle(copy, Object.assign({ mode: mode, group: group }, meta || {})).then(function (o) { outs.push(o); });
      });
    }, Promise.resolve()).then(function () {
      var recs = outs.filter(function (o) { return o.ok; }).map(function (o) { return o.record; });
      if (recs.length) group.label = "Controller set " + recs.map(function (r) { return r.experiment_id; }).join(" / ");
      emit({ type: "set", group: group, records: recs });
      return { group: group, outcomes: outs, records: recs };
    });
  }
  function submitSweep(def) { var a = route("sweep"); if (!a) return { error: { code: "unavailable", message: "Research sweeps are not available in " + modeInfo(mode).label + " mode." } }; return a.submitSweep(def, { mode: mode }); }
  function cancel(job) { var a = adapter(job.adapter); return a && a.cancelJob ? a.cancelJob(job) : Promise.resolve(job); }
  /* v5.2 (review G4): can a cancel request still take effect? The adapter decides (LocalSimulatorAdapter: not once every
     run has finished and the analysis is under way); an adapter that does not say accepts it in every non-terminal state */
  function cancellable(job) {
    if (!job || JOBS.isTerminal(job)) return false;
    var a = adapter(job.adapter);
    return a && typeof a.cancellable === "function" ? !!a.cancellable(job) : true;
  }
  /* re-run a saved run on the engine that produced it: browser runs here (synchronously), backend runs on the
     research backend (reproduceAsync) — never a backend run on the browser engine */
  function reproduceAsync(rec) {
    var eng = rec.origin && rec.origin.engine;
    if (eng === "aeris-research-backend") {
      var a = adapter("research-api");
      if (!a || !a.available().ok) return Promise.resolve({ ok: false, identical: false, message: "This run was produced by the research backend. Connect the backend (SIMULATION mode) to reproduce it there; the browser engine does not re-run backend runs." + (a ? " " + a.available().reason : "") });
      return a.reproduce(rec).catch(function (e) { return { ok: false, identical: false, message: "The research backend could not reproduce this run: " + (e && e.message || e) }; });
    }
    return Promise.resolve(reproduce(rec));
  }
  /* v5: current research metrics for a record saved with an older metric definition — the research backend simulates the
     saved setup again as a NEW record with lineage; the old record never changes (docs/METRICS.md) */
  function reanalyzeAsync(rec) {
    var a = adapter("research-api");
    if (!a || !a.available().ok) return Promise.resolve({ ok: false, message: "Reanalysis runs on the research backend (SIMULATION mode). " + (a ? a.available().reason : "") });
    return a.reanalyze(rec).catch(function (e) { return { ok: false, message: "The research backend could not reanalyse this run: " + (e && e.message || e) }; });
  }
  function reproduce(rec) {
    var eng = rec.origin && rec.origin.engine;
    if (eng && eng !== "aeris-twin-js") return { ok: false, identical: false, message: "This run was produced by '" + eng + "'. Only runs from the browser engine can be re-run here; " + (eng === "aeris-research-backend" ? "the research backend reproduces its own runs (SIMULATION mode)." : "ask that engine to reproduce it.") };
    var L = adapter("local-simulator"), r = L.simulateSync(rec.config);
    if (!r.ok) return { ok: false, identical: false, message: "The saved configuration no longer validates: " + (r.errors[0] && r.errors[0].message) };
    var a = rec.samples.cols, b = r.samples.cols, maxRel = 0, same = a.t.length === b.t.length;
    if (same) Object.keys(a).filter(function (k) { return b[k]; }).forEach(function (k) { for (var i = 0; i < a[k].length; i++) { var d = Math.abs(a[k][i] - b[k][i]), s = Math.max(1e-9, Math.abs(a[k][i])); if (d / s > maxRel) maxRel = d / s; } });
    return { ok: true, identical: same && maxRel === 0 && r.outcome.code === rec.outcome.code, sameOutcome: r.outcome.code === rec.outcome.code, maxRelDiff: maxRel, rows: [a.t.length, b.t.length], outcome: r.outcome, model: TWIN.VERSION.model };
  }
  function capabilities() { var a = route("single") || route("live"); return a ? a.capabilities() : null; }
  /* inputs that the active engine records but does not model (shown next to the setup, never silent) */
  function unsupportedInputs(cfg) {
    var v = engineFor() === "backend" ? validateConfig(cfg) : TWIN.validateConfig(cfg), out = [];
    v.warnings.forEach(function (w) { if (/no effect|not modelled|recorded .* but|recorded for the research backend/.test(w.message)) out.push({ path: w.path, message: w.message }); });
    return out;
  }
  function validationState() {
    var st = typeof AERIS_CONTENT !== "undefined" && AERIS_CONTENT.twin && SCHEMA.VALIDATION[AERIS_CONTENT.twin.validation] ? AERIS_CONTENT.twin.validation : "nominal";
    return { status: st, label: SCHEMA.VALIDATION[st].label, short: SCHEMA.VALIDATION[st].short, text: SCHEMA.VALIDATION[st].text };
  }
  function local() { return adapter("local-simulator"); }
  function replay() { return adapter("replay"); }

  /* ---------------- default wiring in the browser ---------------- */
  function wire() {
    if (typeof LocalSimulatorAdapter !== "undefined") register(LocalSimulatorAdapter);
    if (typeof ReplayAdapter !== "undefined") register(ReplayAdapter);
    if (typeof HardwareTelemetryAdapter !== "undefined") register(HardwareTelemetryAdapter);
    if (typeof ResearchApiAdapter !== "undefined") {
      var cfg = (typeof window !== "undefined" && window.AERIS_CONFIG && window.AERIS_CONFIG.researchApi) || {};
      var opts = { baseUrl: cfg.baseUrl || null, wsUrl: cfg.wsUrl || null, pollMs: cfg.pollMs || 1000, mock: !!cfg.mock,
                   token: typeof AERIS_AUTH !== "undefined" ? AERIS_AUTH.token : null };
      if (cfg.mock && typeof MockResearchBackend !== "undefined") { opts.baseUrl = "mock://aeris-backend"; opts.transport = MockResearchBackend.createTransport(); opts.pollMs = cfg.pollMs || 400; }
      var api = register(ResearchApiAdapter.create(opts));
      if (typeof HardwareTelemetryAdapter !== "undefined" && HardwareTelemetryAdapter.bind) HardwareTelemetryAdapter.bind(api);
      // configured is not reachable: probe now and every minute (capabilities are only what the backend reports)
      if (api.configured() && typeof window !== "undefined") {
        probe();
        setInterval(function () { if (!document.hidden) probe(); }, cfg.probeMs || 60000);
      }
    }
  }
  wire();
  return { ROUTES: ROUTES, register: register, adapter: adapter, modes: modes, modeInfo: modeInfo, getMode: getMode, setMode: setMode, route: route, onChange: onChange,
    runSingle: runSingle, runControllerSet: runControllerSet, submitSweep: submitSweep, cancel: cancel, cancellable: cancellable, reproduce: reproduce, reproduceAsync: reproduceAsync, reanalyzeAsync: reanalyzeAsync, capabilities: capabilities, unsupportedInputs: unsupportedInputs, validationState: validationState, local: local, replay: replay, wire: wire,
    engineFor: engineFor, validateConfig: validateConfig, validateSweep: validateSweep, validateRemote: validateRemote, probe: probe, backendStatus: backendStatus };
})();
if (typeof module !== "undefined") module.exports = AERIS_SERVICE;

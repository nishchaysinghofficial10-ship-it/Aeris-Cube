/* =====================================================================
   AERIS · SCHEMAS — versions, enumerations, normalisation and structural
   validation for every file the platform reads or writes.

     aeris-config/1        one experiment setup (js/core.js normalizeConfig)
     aeris-run/1  rev 1.1  one run: setup, derived data, samples, metrics,
                           outcome, event timeline, source and validation state
     aeris-runs-bundle/1   several runs in one file
     aeris-sweep/1         a research sweep: definition, job state, results
     aeris-dataset/1       a published collection of runs / sweeps with provenance
     aeris-hardware-run/1  telemetry recorded on the physical cube
     aeris-job/1           status of a batch job (research backend or local runner)

   Revision 1.1 of aeris-run/1 only ADDS fields (experiment_id, collection,
   origin, validation, timeline, group). Records written by site v2 (revision
   1.0) are upgraded on load by normalizeRun(); readers of revision 1.0 ignore
   the new fields. JSON Schemas for all formats are in /schemas.
   ===================================================================== */
var AERIS_SCHEMA = (function () {
  "use strict";
  var IDS = typeof AERIS_IDS !== "undefined" ? AERIS_IDS : require("./ids.js");
  var VERSIONS = {
    config: "aeris-config/1", run: "aeris-run/1", runRevision: "1.1", bundle: "aeris-runs-bundle/1",
    sweep: "aeris-sweep/1", dataset: "aeris-dataset/1", hardwareRun: "aeris-hardware-run/1", job: "aeris-job/1"
  };
  /* where the data came from (a property of the data) */
  var SOURCE_KINDS = ["simulation", "hardware"];
  /* what the screen is showing right now (a property of the view): a fresh simulation, live
     hardware telemetry, or a replay of a saved record of either */
  var DISPLAY_SOURCES = ["simulation", "hardware", "replay"];
  /* how far the model behind a simulation has been checked against the cube */
  var VALIDATION = {
    nominal: { label: "Nominal model", short: "NOMINAL", text: "Design values; not yet compared with measurements from the physical cube." },
    measured: { label: "Measured parameters", short: "MEASURED", text: "Parameters measured on the physical cube; the model has not yet been validated against hardware runs." },
    validated: { label: "Validated model", short: "VALIDATED", text: "Model outputs compared with hardware runs under stated conditions and error bounds." }
  };
  var MODES = {
    demo: { label: "Demo", text: "Saved and example experiments, plus small experiments computed by the AERIS Twin engine in this browser. No backend needed." },
    simulation: { label: "Simulation", text: "Experiments run by the AERIS research backend (Python). Needs a configured backend." },
    hardware: { label: "Hardware", text: "Read-only telemetry from the source connected to the research backend. Each source declares what it is: the synthetic emulator is labelled SYNTHETIC and is never shown as the physical cube; a device that declares itself physical is shown as declared, not verified." }
  };
  var COLLECTIONS = ["user", "example", "imported", "reference"];
  var ENGINES = { "aeris-twin-js": "AERIS Twin browser engine (JavaScript)", "aeris-research-backend": "AERIS research backend (Python)", "mock-research-backend": "MOCK research backend (computed in this browser)", hardware: "Physical AERIS Cube" };
  var NOMINAL_PARAMETER_SET = "nominal-design-v1";

  function isObj(x) { return !!x && typeof x === "object" && !Array.isArray(x); }
  function clone(o) { return o == null ? o : JSON.parse(JSON.stringify(o)); }

  /* ---------------- runs ---------------- */
  function legacyCollection(rec) {
    if (rec.collection && COLLECTIONS.indexOf(rec.collection) >= 0) return rec.collection;
    if (rec.source === "example" || /^example-/.test(String(rec.id || ""))) return "example";
    if (rec.source === "imported") return "imported";
    return "user";
  }
  /* Upgrade a run record to revision 1.1 in place. ctx: { taken: [experiment ids], assign: bool, timeline: fn(rec) } */
  function normalizeRun(rec, ctx) {
    ctx = ctx || {};
    if (!isObj(rec)) return rec;
    var changed = false;
    // 1.0 → 1.1 upgrade; revisions 1.2 and 1.3 (research-backend records: 1.1 plus research fields; 1.3 adds lineage,
    // the recording schedule and metric version 2) are kept as they are
    if (rec.schema_revision !== VERSIONS.runRevision && rec.schema_revision !== "1.2" && rec.schema_revision !== "1.3") { rec.schema_revision = VERSIONS.runRevision; changed = true; }
    var coll = legacyCollection(rec);
    if (rec.collection !== coll) { rec.collection = coll; changed = true; }
    if (rec.source !== "hardware" && rec.source !== "simulation") { rec.source = "simulation"; changed = true; }
    if (!isObj(rec.origin)) {
      rec.origin = rec.source === "hardware"
        ? { kind: "hardware", engine: "hardware", engine_version: null, adapter: "hardware-telemetry", mode: "hardware" }
        : { kind: "simulation", engine: "aeris-twin-js", engine_version: (rec.software && rec.software.model) || null, adapter: "local-simulator", mode: "demo" };
      changed = true;
    }
    if (!isObj(rec.validation) || !VALIDATION[rec.validation.status]) {
      rec.validation = { status: "nominal", parameter_set: NOMINAL_PARAMETER_SET, note: VALIDATION.nominal.text };
      changed = true;
    }
    if (!IDS.isValid(rec.experiment_id)) {
      var fixed = IDS.forExample(rec.id) || IDS.fromLegacy(rec.experiment_id) || null;
      if (fixed) rec.experiment_id = fixed;
      else if (ctx.assign !== false) rec.experiment_id = IDS.next(ctx.taken || []);
      changed = true;
    }
    if (rec.group === undefined) { rec.group = null; changed = true; }
    if ((!isObj(rec.timeline) || !Array.isArray(rec.timeline.events)) && typeof ctx.timeline === "function") {
      try { rec.timeline = ctx.timeline(rec); changed = true; } catch (e) { /* leave without a timeline */ }
    }
    return { record: rec, changed: changed };
  }
  /* What should the status strip say for this record? view: "fresh" (just computed) or "saved" */
  function describeSource(rec, view) {
    var kind = rec && rec.origin && rec.origin.kind === "hardware" ? "hardware" : "simulation";
    var display = view === "fresh" ? kind : "replay";
    var engine = rec && rec.origin ? (ENGINES[rec.origin.engine] || rec.origin.engine) : null;
    return { display: display, origin: kind, engine: engine, engine_version: rec && rec.origin ? rec.origin.engine_version : null };
  }

  /* ---------------- hardware runs (aeris-hardware-run/1) ---------------- */
  /* Strict on types: every sample must be a finite JSON number (strings, null, NaN and booleans are errors, never coerced);
     time must be in s (or ms) and strictly increasing; quaternion columns must be unit (±1e-2); sequence numbers must be
     integers without duplicates. A column with an unknown unit is reported and not compared (AERIS_VALIDATION). */
  var HW_REQUIRED_COLS = ["t"];
  var HW_ATTITUDE_ANY = [["q0", "q1", "q2", "q3"], ["theta"]];
  var ISO_TS = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2})$/;
  function validateHardwareRun(h) {
    var E = [], W = [];
    if (!isObj(h)) return { ok: false, errors: ["The file does not contain a JSON object."], warnings: W };
    if (h.schema !== VERSIONS.hardwareRun) E.push("Expected schema '" + VERSIONS.hardwareRun + "', found '" + String(h.schema) + "'.");
    if (!isObj(h.device) || typeof h.device.id !== "string" || !h.device.id) E.push("Missing device description ('device.id', firmware version, IMU, wheels).");
    if (!isObj(h.recording) || typeof h.recording.started !== "string" || !ISO_TS.test(h.recording.started)) E.push("Missing recording metadata ('recording.started', ISO 8601 with a time zone).");
    if (!h.mode || (h.mode !== "edge" && h.mode !== "corner" && h.mode !== "free")) E.push("'mode' must be 'edge', 'corner' or 'free'.");
    if (h.synthetic === true) W.push("This recording is marked SYNTHETIC: it is not a measurement and cannot support MEASURED or VALIDATED claims.");
    var S = h.samples;
    if (!isObj(S) || !isObj(S.cols) || !isObj(S.units)) { E.push("Missing 'samples.cols' and 'samples.units'."); return { ok: false, errors: E, warnings: W }; }
    HW_REQUIRED_COLS.forEach(function (c) { if (!Array.isArray(S.cols[c])) E.push("Missing sample column '" + c + "'."); });
    if (!HW_ATTITUDE_ANY.some(function (set) { return set.every(function (c) { return Array.isArray(S.cols[c]); }); })) E.push("Attitude is missing: give quaternion columns q0–q3 (corner/free) or 'theta' (edge).");
    var n = Array.isArray(S.cols.t) ? S.cols.t.length : 0;
    if (n < 2) E.push("At least two samples are needed.");
    Object.keys(S.cols).forEach(function (c) {
      var col = S.cols[c];
      if (!Array.isArray(col)) { E.push("Column '" + c + "' is not an array."); return; }
      if (col.length !== n) E.push("Column '" + c + "' has " + col.length + " rows; 't' has " + n + ".");
      for (var i = 0; i < col.length; i++) if (typeof col[i] !== "number" || !isFinite(col[i])) { E.push("Column '" + c + "' row " + i + ": " + JSON.stringify(col[i]) + " is not a finite number (strings, null, NaN and booleans are rejected)."); break; }
      if (!S.units[c]) W.push("Column '" + c + "' has no unit.");
    });
    if (S.units.t != null && ["s", "ms"].indexOf(S.units.t) < 0) E.push("Column 't' must be in s or ms (found '" + S.units.t + "').");
    var quality = null;
    if (!E.length) {
      var t = S.cols.t.map(function (x) { return S.units.t === "ms" ? x / 1000 : x; });
      for (var i = 1; i < n; i++) if (!(t[i] > t[i - 1])) { E.push("Sample times must increase (row " + i + ")."); break; }
      if (["q0", "q1", "q2", "q3"].every(function (c) { return Array.isArray(S.cols[c]); })) {
        var dev = 0; for (i = 0; i < n; i++) dev = Math.max(dev, Math.abs(Math.hypot(S.cols.q0[i], S.cols.q1[i], S.cols.q2[i], S.cols.q3[i]) - 1));
        if (dev > 1e-2) E.push("q0–q3 are not unit quaternions (largest |‖q‖ − 1| = " + dev.toPrecision(3) + "; tolerance 1e-2).");
      }
      var dts = []; for (i = 1; i < n; i++) dts.push(t[i] - t[i - 1]); dts.sort(function (a, b) { return a - b; });
      var med = dts[dts.length >> 1] || 0;
      quality = { n: n, duration_s: t[n - 1] - t[0], rate_hz_median: med > 0 ? 1 / med : null, gaps: dts.filter(function (d) { return d > 1.5 * med; }).length, dropouts: null };
      if (Array.isArray(S.cols.seq)) {
        var drops = 0, dup = 0;
        for (i = 1; i < n; i++) { var dsq = S.cols.seq[i] - S.cols.seq[i - 1]; if (!Number.isInteger(S.cols.seq[i])) { E.push("Sequence numbers must be integers (row " + i + ")."); break; } if (dsq > 1) drops += dsq - 1; else if (dsq < 1) dup++; }
        quality.dropouts = drops; quality.duplicates_or_reorders = dup;
        if (dup) E.push(dup + " duplicate or out-of-order sequence numbers.");
      }
    }
    if (!isObj(h.parameters) || !h.parameters.parameter_set) W.push("No 'parameters.parameter_set': the comparison cannot say which model parameters were used.");
    return { ok: E.length === 0, errors: E, warnings: W, quality: quality };
  }

  /* ---------------- datasets (aeris-dataset/1) ---------------- */
  function validateDataset(d) {
    var E = [];
    if (!isObj(d)) return { ok: false, errors: ["Not a JSON object."] };
    if (d.schema !== VERSIONS.dataset) E.push("Expected schema '" + VERSIONS.dataset + "'.");
    if (!d.id) E.push("Missing dataset id.");
    if (!isObj(d.provenance) || !d.provenance.source) E.push("Missing provenance.source (simulation, hardware or mixed).");
    if (!Array.isArray(d.members)) E.push("Missing 'members' (run or sweep references).");
    if (d.mock === true && !/MOCK/i.test(String(d.title || ""))) E.push("A mock dataset must say MOCK in its title.");
    return { ok: E.length === 0, errors: E };
  }

  return {
    VERSIONS: VERSIONS, SOURCE_KINDS: SOURCE_KINDS, DISPLAY_SOURCES: DISPLAY_SOURCES, VALIDATION: VALIDATION, MODES: MODES,
    COLLECTIONS: COLLECTIONS, ENGINES: ENGINES, NOMINAL_PARAMETER_SET: NOMINAL_PARAMETER_SET,
    normalizeRun: normalizeRun, describeSource: describeSource, validateHardwareRun: validateHardwareRun, validateDataset: validateDataset, clone: clone
  };
})();
if (typeof module !== "undefined") module.exports = AERIS_SCHEMA;

/* =====================================================================
   HOME — hero telemetry and 3-D teaser (both replay one example
   recording computed on this device) and the standing experiments.
   Also fills the evidence slots that live on other pages from
   js/site-content.js: the Cube page's parameter table and footage, and
   the Results page's earlier benchmark (with its provenance).
   ===================================================================== */
var Home = (function () {
  "use strict";
  var DEG = AERIS_TWIN.DEG, RPM = AERIS_TWIN.RPM, $ = U.$, fx = U.fx, esc = U.esc;
  var HERO_EX = "example-corner-push";
  var S = { rec: null, i: 0, clock: 0, last: 0, playing: false, viewer: null, visible: false, heroVisible: true, user: false };
  var RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var C = window.AERIS_CONTENT || {};
  var TK = AERIS_TOKENS, ST = TK.color.status, INK = TK.color.ink;

  /* ---------------- example replay shared by the telemetry strip and the teaser ---------------- */
  function heroRecord() {
    return AERIS_SERVICE.replay().exampleRecord(HERO_EX);
  }
  function phase(rec, i) {
    var s = rec.samples.cols, t = s.t[i];
    if (rec.metrics.fellAt_s != null && t >= rec.metrics.fellAt_s) return { k: "bad", t: "Fallen" };
    if ((rec.config.disturbances || []).some(function (L) { return AERIS_TWIN.loadActive(L, t); })) return { k: "warn", t: "Push active" };
    return Math.abs(s.e[i]) <= rec.definitions.assessment.settleTolDeg * DEG ? { k: "ok", t: "Balanced" } : { k: "warn", t: "Recovering" };
  }
  function set(id, v) { var el = $(id); if (el && el.textContent !== v) el.textContent = v; }
  function telemetry() {
    var r = S.rec; if (!r) return;
    var c = r.samples.cols, i = S.i, wmax = r.derived.motor.wmax;
    set("tT", fx(c.t[i], 2) + " s");
    set("tQ", [c.q0[i], c.q1[i], c.q2[i], c.q3[i]].map(function (v) { return fx(v, 3); }).join(" "));
    set("tTilt", fx(c.e[i] / DEG, 3) + "°");
    set("tW", [c.wx[i], c.wy[i], c.wz[i]].map(function (v) { return fx(v, 2); }).join(" "));
    ["x", "y", "z"].forEach(function (a, j) {
      var w = c["omega_" + a][i], f = Math.min(1, Math.abs(w) / wmax);
      set("tW" + (j + 1), fx(w / RPM, 0));
      var b = $("bW" + (j + 1)); if (b) { b.style.width = (f * 100).toFixed(1) + "%"; b.style.background = f >= AERIS_TWIN.EVENT_RULES.speedRiskFrac ? "var(--warning)" : "var(--ink-2)"; }
    });
    var ph = phase(r, i), ts = $("tS"); if (ts) { ts.textContent = ph.t.toUpperCase(); ts.style.color = ph.k === "ok" ? "var(--stable)" : ph.k === "warn" ? "var(--warning)" : "var(--failure)"; }
    if (S.viewer && S.visible) { S.viewer.setPose(poseAt(r, i)); set("tzT", "t = " + fx(c.t[i], 2) + " s"); }
  }
  function poseAt(r, i) {
    var c = r.samples.cols, R = AERIS_TWIN.Q3.rot([c.q0[i], c.q1[i], c.q2[i], c.q3[i]]), t = c.t[i], tq = [0, 0, 0], loads = [];
    if (!S.ang) { S.ang = [0, 1, 2].map(function () { return new Float64Array(c.t.length); }); ["omega_x", "omega_y", "omega_z"].forEach(function (k, j) { for (var q = 1; q < c.t.length; q++) S.ang[j][q] = S.ang[j][q - 1] + 0.5 * (c[k][q] + c[k][q - 1]) * (c.t[q] - c.t[q - 1]); }); }
    (r.config.disturbances || []).forEach(function (L) { var act = AERIS_TWIN.loadActive(L, t); if (L.type === "force") loads.push({ id: L.id, point_m: L.point_m, F_world: AERIS_TWIN.loadForceWorld(L, R), active: act, label: L.id }); if (act) tq = AERIS_TWIN.vec.add3(tq, AERIS_TWIN.vec.mv(R, AERIS_TWIN.loadTorqueBody(L, R))); });
    return { R: R, wheelAngles: [S.ang[0][i], S.ang[1][i], S.ang[2][i]], failed: [false, false, false], loads: loads, torque_world: tq, gravity_N: r.derived.M * r.config.params.g, t: t, idx: i, runId: r.id };
  }
  function loop(ts) {
    if (!S.playing) return;
    var dt = S.last ? Math.min(0.1, (ts - S.last) / 1000) : 0; S.last = ts;
    var home = $("view-home");
    if (home && !home.hidden && !document.hidden && (S.heroVisible || S.visible)) {
      S.clock += dt;
      var T = S.rec.samples.cols.t, n = T.length;
      if (S.clock > T[n - 1] + 1.5) { S.clock = 0; S.i = 0; }
      while (S.i < n - 1 && T[S.i + 1] <= S.clock) S.i++;
      if (S.clock < T[S.i]) S.i = 0;
      telemetry();
    }
    requestAnimationFrame(loop);
  }
  function setPlaying(on) {
    S.playing = on; S.last = 0;
    [].forEach.call(document.querySelectorAll("[data-replay-toggle]"), function (b) { b.textContent = on ? "Pause replay" : "Play replay"; b.setAttribute("aria-pressed", on ? "false" : "true"); });
    if (on) requestAnimationFrame(loop);
  }
  function initReplay() {
    try { S.rec = heroRecord(); } catch (e) { if (window.console) console.error(e); return; }
    var r = S.rec;
    set("tSrc", "example recording · simulated · corner · " + r.config.params.fs + " Hz loop · nominal parameters");
    var stage = $("teaserStage");
    if (stage && window.AerisViewer) {
      S.viewer = new AerisViewer(stage, { autoSpin: true });
      S.viewer.setScene({ mode: "corner", a: r.config.params.a, attachments: [], com_m: r.derived.rc, nominal_com_m: [r.config.params.a / 2, r.config.params.a / 2, r.config.params.a / 2], loads: r.config.disturbances.map(function (L) { return { id: L.id, type: L.type, point_m: L.point_m, frame: L.frame, label: L.id + " " + fx(L.magnitude_N, 2) + " N" }; }), failed: [false, false, false] });
      if ("IntersectionObserver" in window) new IntersectionObserver(function (es) { S.visible = es[0].isIntersecting; }, { rootMargin: "100px 0px" }).observe(stage); else S.visible = true;
      set("tzName", r.name.replace(/^Example · /, ""));
      var ob = $("tzOutcome"); if (ob) ob.innerHTML = U.badge(r.outcome);
    }
    var tel = document.querySelector(".telemetry");
    if (tel && "IntersectionObserver" in window) new IntersectionObserver(function (es) { S.heroVisible = es[0].isIntersecting; }, { rootMargin: "60px 0px" }).observe(tel);
    S.i = 0; telemetry();
    if (S.viewer) { S.viewer.setPose(poseAt(r, 0)); set("tzT", "t = 0.00 s"); }
    [].forEach.call(document.querySelectorAll("[data-replay-toggle]"), function (b) { b.addEventListener("click", function () { S.user = true; setPlaying(!S.playing); }); });
    [].forEach.call(document.querySelectorAll("[data-open-example]"), function (a) { a.addEventListener("click", function (e) { e.preventDefault(); location.hash = "#lab"; setTimeout(function () { Workspace.openExample(a.getAttribute("data-open-example")); }, 40); }); });
    setPlaying(!RM);
  }

  /* ---------------- standing experiments (this simulator, nominal parameters) ---------------- */
  function cfg(mode, o) { var c = AERIS_TWIN.defaultConfig(mode); Object.keys(o).forEach(function (k) { c[k] = o[k]; }); return c; }
  function ini(t, az) { return { tilt_deg: t || 0, rate_dps: 0, azimuth_deg: az || 0, reference: "geometric" }; }
  var CFGS = {};
  function out(host, key, html) { var el = document.querySelector("#" + host + ' [data-o="' + key + '"]'); if (el) el.innerHTML = html; }
  function tone(o) { return o.code === "recovered" ? "v-ok" : o.code === "fallen" ? "v-bad" : "v-warn"; }
  function experiments() {
    var ctr = ["pid", "lqr", "adp"], R2 = {}, R3 = {};
    ctr.forEach(function (c) {
      CFGS["mass-" + c] = cfg("edge", { controller: { type: c, knowsAttachments: false, reconfigureOnFailure: true }, initial: ini(0), comOffset_m: 0.003, duration_s: 20, record_hz: 50 });
      R2[c] = AERIS_SERVICE.local().simulateSync(CFGS["mass-" + c]);
      CFGS["push-" + c] = cfg("edge", { controller: { type: c, knowsAttachments: false, reconfigureOnFailure: true }, initial: ini(0), duration_s: 15, disturbances: [{ id: "L1", type: "torque", magnitude_Nm: 0.05, direction: [1, 0, 0], frame: "body", t_start_s: 1, duration_s: 5 }] });
      R3[c] = AERIS_SERVICE.local().simulateSync(CFGS["push-" + c]);
    });
    ctr.forEach(function (c) {
      var r = R2[c], m = r.metrics;
      out("outMass", c, '<span class="' + tone(r.outcome) + '">' + r.outcome.label + "</span> · " + (r.outcome.code === "fallen" ? "at " + fx(m.fellAt_s, 2) + " s, wheel saturated" : "wheel " + fx(m.finalOmega_rpm.x, 0) + " rpm at 20 s"));
      var q = R3[c].metrics;
      out("outPush", c, '<span class="' + tone(R3[c].outcome) + '">' + R3[c].outcome.label + "</span> · peak " + fx(q.peakOmega_rpm, 0) + " rpm (" + fx(q.peakOmega_frac * 100, 0) + " %)" + (Math.abs(q.finalOmega_rpm.x) < 60 ? ", back to 0" : ", still " + fx(Math.abs(q.finalOmega_rpm.x), 0) + " rpm"));
    });
    var ev = [{ id: "E1", type: "wheel_failure", wheel: "x", t_s: 0.1 }];
    CFGS["fail-yes"] = cfg("corner", { initial: ini(2, 0.7 / DEG), duration_s: 10, events: ev, controller: { type: "lqr", knowsAttachments: false, reconfigureOnFailure: true } });
    CFGS["fail-no"] = cfg("corner", { initial: ini(2, 0.7 / DEG), duration_s: 10, events: ev, controller: { type: "lqr", knowsAttachments: false, reconfigureOnFailure: false } });
    var yes = AERIS_SERVICE.local().simulateSync(CFGS["fail-yes"]), no = AERIS_SERVICE.local().simulateSync(CFGS["fail-no"]);
    out("outFail", "no", '<span class="' + tone(no.outcome) + '">' + no.outcome.label + "</span>" + (no.metrics.fellAt_s != null ? " · " + fx(no.metrics.fellAt_s - 0.1, 2) + " s after the fault" : ""));
    out("outFail", "yes", '<span class="' + tone(yes.outcome) + '">' + yes.outcome.label + "</span> · on two wheels");
    out("outFail", "cost", "Yaw not controlled: " + fx(yes.metrics.yawFinal_deg, 0) + "° after 10 s");
    // stress chart (EXP-02, this simulator)
    var wl = AERIS_TWIN.derive(AERIS_TWIN.NOMINAL).wmax / RPM;
    var pf = R2.pid.metrics.fellAt_s;
    Chart.line($("stressChart"), { xlim: [0, 20], ylim: [-wl * 0.06, wl * 1.14], xlabel: "t [s]", ylabel: "wheel speed Ω [rpm]",
      series: ctr.map(function (c, k) { var S = R2[c].samples.cols, cc = TK.controller(c); return { x: S.t, y: S.omega_x.map(function (v) { return v / RPM; }), color: cc.color, width: 2.2, marker: cc.marker, markerOffset: 20 + k * 26 }; }),
      hlines: [{ y: wl, color: TK.alpha(ST.warning, 0.75), label: "speed limit " + fx(wl, 0) + " rpm" }],
      markers: pf != null ? [{ x: pf, y: R2.pid.samples.cols.omega_x[R2.pid.samples.cols.omega_x.length - 1] / RPM, color: ST.failure, shape: "x", label: "PID falls", align: "right" }] : [] });
    function sres(key, html) { var el = document.querySelector('#stressRes [data-s="' + key + '"]'); if (el) el.innerHTML = html; }
    var d = AERIS_TWIN.derive(AERIS_TWIN.NOMINAL), lq = R2.lqr, ad = R2.adp;
    sres("pid", R2.pid.outcome.code === "fallen" ? "Holds the frame at 0°, stores the offset's torque as spin and falls at " + fx(pf, 2) + " s when its wheel reaches " + fx(d.wmax / RPM, 0) + " rpm. Cut to 4 s, the same run is still upright but reported as Drifting." : R2.pid.outcome.label + ": " + esc(R2.pid.outcome.reason));
    var lqS = lq.samples.cols, adS = ad.samples.cols;
    sres("lqr", lq.outcome.code === "fallen" ? "Falls at " + fx(lq.metrics.fellAt_s, 2) + " s." : "Leans " + fx(Math.abs(lqS.theta[lqS.t.length - 1] / DEG), 2) + "° to put the COM over the pivot, but parks its wheel at " + fx(lq.metrics.finalOmega_rpm.x, 0) + " rpm (" + fx(lq.metrics.energy_J, 1) + " J in 20 s).");
    sres("adp", ad.outcome.code === "fallen" ? "Falls at " + fx(ad.metrics.fellAt_s, 2) + " s." : "Estimates the offset (β̂ = " + fx(adS.betahat[adS.t.length - 1] / DEG, 3) + "°, true " + fx(ad.mp ? ad.mp.edge.beta / DEG : 0, 3) + "°) and returns its wheel to zero, using " + fx(ad.metrics.energy_J, 1) + " J.");
    [].forEach.call(document.querySelectorAll("[data-home-cfg]"), function (b) {
      b.addEventListener("click", function () { var c = CFGS[b.getAttribute("data-home-cfg")]; if (!c) return; location.hash = "#lab"; setTimeout(function () { Workspace.openConfig(AERIS_TWIN.clone(c), { run: true }); }, 40); });
    });
  }

  /* ---------------- benchmark from earlier project runs (provenance kept) ---------------- */
  function benchmark() {
    var B = C.benchmark, tb = $("benchBody"); if (!B || !tb) return;
    var cols = ["settle_s", "overshoot_deg", "sse_deg", "energy_J"], low = {};
    cols.forEach(function (k) { low[k] = Math.min.apply(null, B.rows.map(function (r) { return r[k]; })); });
    tb.innerHTML = B.rows.map(function (r) { return "<tr><td>" + esc(r.controller) + "</td>" + cols.map(function (k) { return '<td class="' + (r[k] === low[k] ? "low" : "") + '">' + r[k] + "</td>"; }).join("") + "</tr>"; }).join("");
    set("benchSrc", (B.status ? B.status + " material. " : "") + B.source + ". Supporting traces: " + B.traces + ". Not produced by this site's simulator and not reproducible here; not a finding.");
  }

  /* ---------------- hardware evidence ---------------- */
  var SPEC_ROWS = [
    ["mass", "Total mass", function (d) { return fx(d.m, 2) + " kg"; }, "Scale"],
    ["edge", "Edge length", function (d) { return fx(d.a * 1000, 0) + " mm"; }, "Calipers"],
    ["bodyInertia", "Body inertia J<sub>c</sub>", function (d) { return U.sig(d.Jc, 3) + " kg·m²"; }, "Trifilar pendulum (Twin §12)"],
    ["wheelInertia", "Wheel inertia J<sub>w</sub>", function (d) { return U.sig(d.Jw, 2) + " kg·m²"; }, "Spin-down / trifilar"],
    ["torqueConstant", "Torque constant k<sub>t</sub>", function (d) { return U.sig(d.kt, 3) + " N·m/A"; }, "Stall test"],
    ["peakTorque", "Peak wheel torque", function (d) { return fx(d.taumax, 3) + " N·m"; }, "Stall test at the current limit"],
    ["wheelSpeedLimit", "Wheel speed limit", function (d) { return fx(d.wmaxRpm, 0) + " rpm"; }, "Firmware setting"],
    ["loopRate", "Control loop rate", function (d) { return fx(d.fs, 0) + " Hz"; }, "Firmware timing log"],
    ["supply", "Supply voltage", function (d) { return fx(d.Vs, 1) + " V"; }, "Multimeter"]
  ];
  function hardware() {
    var H = C.hardware || {}, d = AERIS_TWIN.derive(AERIS_TWIN.NOMINAL);
    set("hwStatus", H.status || "");
    var fg = $("hwFootage");
    if (fg) {
      var f = H.footage || [];
      fg.innerHTML = f.length ? f.map(function (x) {
        var media = x.type === "video" ? '<video controls preload="metadata" playsinline src="' + esc(x.src) + '"' + (x.poster ? ' poster="' + esc(x.poster) + '"' : "") + "></video>" : '<img src="' + esc(x.src) + '" alt="' + esc(x.caption || "Hardware photo") + '" loading="lazy">';
        return '<figure class="hw-fig">' + media + "<figcaption>" + esc(x.caption || "") + (x.date ? ' <span class="dim">· ' + esc(x.date) + "</span>" : "") + " " + AERIS_BADGES.source("hardware") + "</figcaption></figure>";
      }).join("") : '<div class="slot"><span class="label">Hardware footage</span><p>Not uploaded yet. Videos of the physical cube balancing on its edge and corner go here, unedited and dated.</p><p class="dim small">To add them: put the files in <code>assets/</code> and list them under <code>hardware.footage</code> in <code>js/site-content.js</code>.</p></div>';
    }
    var tb = $("hwSpecs"), nMeas = 0, nVal = 0;
    if (tb) tb.innerHTML = SPEC_ROWS.map(function (r) {
      var m = H.measured && H.measured[r[0]], v = !!(m && H.validated && H.validated[r[0]]);
      if (m) nMeas++; if (v) nVal++;
      var st = v ? AERIS_BADGES.claim("validated") : m ? AERIS_BADGES.claim("measuredParams").replace("MEASURED PARAMETERS", "MEASURED") : AERIS_BADGES.claim("nominal");
      return '<tr><th scope="row">' + r[1] + '</th><td class="mono">' + r[2](d) + "</td><td>" + (m ? '<span class="mono">' + esc(m.value) + " " + esc(m.unit || "") + "</span>" + (m.method ? '<span class="dim small"> · ' + esc(m.method) + (m.date ? ", " + esc(m.date) : "") + "</span>" : "") : '<span class="pending">Pending measurement</span>') + "</td><td>" + st + '</td><td class="dim small">' + r[3] + "</td></tr>";
    }).join("");
    set("cubeParamCount", nMeas + " of " + SPEC_ROWS.length + " measured · " + nVal + " validated");
    var cp = $("hwCompare");
    if (cp) {
      var list = H.comparisons || [];
      cp.innerHTML = list.length ? "<ul>" + list.map(function (x) { return "<li><b>" + esc(x.title) + "</b>" + (x.note ? " · " + esc(x.note) : "") + (x.hardwareLog ? ' · <a class="more" href="' + esc(x.hardwareLog) + '">hardware log</a>' : "") + (x.simulationRun ? ' · <a class="more" href="' + esc(x.simulationRun) + '">simulated run</a>' : "") + "</li>"; }).join("") + "</ul>"
        : '<div class="slot"><span class="label">Simulation vs hardware</span><p>No comparisons yet. Each one will pair a hardware log with a run from <a href="#lab">AERIS Lab</a> under the same conditions (see <a href="#validation">Validation</a>).</p><p class="dim small">Add them under <code>hardware.comparisons</code> in <code>js/site-content.js</code>.</p></div>';
    }
  }
  function repository() {
    var R = C.repository;
    [].forEach.call(document.querySelectorAll("[data-repo]"), function (el) {
      if (R && R.url) { el.innerHTML = '<a class="' + (el.getAttribute("data-repo") || "") + '" href="' + esc(R.url) + '" target="_blank" rel="noopener">' + esc(R.label || R.url) + "</a>"; }
      else el.innerHTML = '<span class="forthcoming">Repository forthcoming</span>';
    });
    var mail = C.contactEmail; if (mail) [].forEach.call(document.querySelectorAll("[data-mail]"), function (el) { el.innerHTML = '<a href="mailto:' + esc(mail) + '">' + esc(mail) + "</a>"; var b = el.parentNode.querySelector("[data-copy]"); if (b) b.setAttribute("data-copy", mail); });
  }
  function params() {
    var d = AERIS_TWIN.derive(AERIS_TWIN.NOMINAL), kv = $("homeParams"); if (!kv) return;
    kv.innerHTML = [["Base mass", fx(d.m, 2) + " kg"], ["Edge length", fx(d.a * 1000, 0) + " mm"], ["Body inertia J<sub>c</sub>", U.sig(d.Jc, 4) + " kg·m²"], ["Wheel inertia J<sub>w</sub>", U.sig(d.Jw, 2) + " kg·m²"], ["Peak wheel torque", fx(d.taumax, 3) + " N·m"], ["Momentum capacity", fx(d.hmax, 3) + " N·m·s"], ["Open-loop instability (corner)", fx(d.lamc, 2) + " s⁻¹"]]
      .map(function (r) { return "<div>" + r[0] + "</div><div>" + r[1] + "</div>"; }).join("");
  }
  function init() {
    repository(); params(); benchmark(); hardware();
    setTimeout(function () { initReplay(); }, 30);
    setTimeout(function () { try { experiments(); } catch (e) { if (window.console) console.error(e); } }, 120);
  }
  return { init: init, redraw: function () { Chart.redrawVisible($("view-home")); if (S.viewer) S.viewer.resize(); } };
})();

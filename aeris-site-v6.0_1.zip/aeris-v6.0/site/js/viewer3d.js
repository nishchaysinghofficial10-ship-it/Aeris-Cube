/* =====================================================================
   AERIS · 3-D VIEWER — the detailed cube model (three.js) driven by a
   saved run or by the setup preview. It never simulates anything: the
   workspace hands it a pose taken from the same sample that the plots,
   telemetry and calculations are showing.

   Frames. Body frame B: origin at the pivot vertex O, axes along the cube
   edges, cube occupies [0,a]³. World frame N: z up, pivot at the origin.
   three.js is y-up, so world (x, y, z) is drawn at (x, z, −y). Scene units
   are centimetres.
   ===================================================================== */
var AerisViewer = (function () {
  "use strict";
  /* colours from js/platform/tokens.js: axis triads keep the conventional red/green/blue (labelled);
     the COM is white, the nominal COM a grey ghost, loads magenta, wheel rings neutral → amber when
     saturating → red when failed; brand lime marks only the selected object (UI state) */
  var TK = typeof AERIS_TOKENS !== "undefined" ? AERIS_TOKENS.color : null;
  var AX = TK ? [TK.axis.x, TK.axis.y, TK.axis.z] : ["#e57f7f", "#7fd49a", "#7fb2f0"];
  var SEL = TK ? TK.brand : "#c0ff00", COM = TK ? TK.physics.com : "#f2f4f7", COM0 = TK ? TK.physics.comNominal : "#8a93a0";
  var FORCE = TK ? TK.physics.load : "#e063a7", TORQUE = FORCE, NEUTRAL = TK ? TK.ink.secondary : "#9aa3af";
  var RING = { ok: TK ? TK.ink.secondary : "#9aa3af", risk: TK ? TK.status.warning : "#ffb020", sat: TK ? TK.status.warning : "#ffb020", failed: TK ? TK.status.failure : "#ff5a4f" };
  var RM = typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var VIEWS = {
    iso: { yaw: 0.65, pitch: 0.28, label: "Iso" },
    side: { yaw: Math.PI / 2, pitch: 0.06, label: "Side" },
    front: { yaw: 0, pitch: 0.06, label: "Front" },
    top: { yaw: 0.0001, pitch: 1.5, label: "Top" }
  };
  function w2t(v) { return [v[0], v[2], -v[1]]; }                 // physics world → three
  function mv(R, v) { return [R[0][0] * v[0] + R[0][1] * v[1] + R[0][2] * v[2], R[1][0] * v[0] + R[1][1] * v[1] + R[1][2] * v[2], R[2][0] * v[0] + R[2][1] * v[1] + R[2][2] * v[2]]; }
  function add(a, b) { return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]; }
  function scl(a, s) { return [a[0] * s, a[1] * s, a[2] * s]; }
  function nrm(a) { return Math.hypot(a[0], a[1], a[2]); }
  /* arrow magnification for a COM shift of length d on a cube of edge a (same units): a round factor
     that draws the shift at roughly a quarter of the edge, between ×1 and ×50 */
  function magnification(d, a) { var k = 0.25 * a / d, steps = [1, 2, 5, 10, 20, 50]; for (var i = steps.length - 1; i >= 0; i--) if (steps[i] <= k) return steps[i]; return 1; }

  function Viewer(host, opts) {
    opts = opts || {};
    var self = this;
    this.host = host; this.opts = opts;
    this.loop = function (now) { self.raf = null; self.frame(now); };
    this.canvas = host.querySelector("canvas") || host.appendChild(document.createElement("canvas"));
    this.scene = null; this.pose = null; this.pickMode = false; this.onPick = null; this.selected = null;
    this.cam = { yaw: VIEWS.iso.yaw, pitch: VIEWS.iso.pitch, ty: VIEWS.iso.yaw, tp: VIEWS.iso.pitch, zoom: 1, tz: 1, drag: false, moved: 0, lx: 0, ly: 0 };
    this.view = "iso"; this.dirty = true; this.visible = true; this.autoSpin = !!opts.autoSpin && !RM;
    this.three = this.initThree();
    this.mode2d = !this.three;
    if (this.mode2d) { this.ctx2d = this.canvas.getContext("2d"); host.classList.add("no3d"); }
    this.bind();
    this.resize();
    if ("ResizeObserver" in window) { this.ro = new ResizeObserver(function () { self.resize(); }); this.ro.observe(host); }
    window.addEventListener("resize", function () { self.resize(); });
    if ("IntersectionObserver" in window) { this.io = new IntersectionObserver(function (es) { self.visible = es[0].isIntersecting; if (self.visible) self.request(); }, { rootMargin: "80px 0px" }); this.io.observe(host); }
    this.request();
  }

  /* ---------------- three.js scene (ported from the v1 twin model) ---------------- */
  Viewer.prototype.initThree = function () {
    if (typeof THREE === "undefined" || this.opts.force2d) return null;
    var renderer;
    try { renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, alpha: true, preserveDrawingBuffer: !!this.opts.preserve }); }
    catch (e) { return null; }
    if (!renderer || !renderer.getContext()) return null;
    renderer.setClearColor(0x000000, 0);
    renderer.outputEncoding = THREE.sRGBEncoding; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.18;
    var scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(30, 1, 0.5, 2000);
    (function env() {
      var c = document.createElement("canvas"); c.width = 512; c.height = 256;
      var g = c.getContext("2d"), gr = g.createLinearGradient(0, 0, 0, 256);
      gr.addColorStop(0, "#39424a"); gr.addColorStop(0.45, "#161a1e"); gr.addColorStop(0.6, "#0a0c0e"); gr.addColorStop(1, "#040506");
      g.fillStyle = gr; g.fillRect(0, 0, 512, 256);
      function blob(x, y, w, h, a) { var r = g.createRadialGradient(x, y, 0, x, y, Math.max(w, h)); r.addColorStop(0, "rgba(255,255,255," + a + ")"); r.addColorStop(1, "rgba(255,255,255,0)"); g.fillStyle = r; g.fillRect(x - w, y - h, 2 * w, 2 * h); }
      blob(140, 44, 120, 70, 1); blob(390, 96, 90, 60, 0.45);
      g.fillStyle = "rgba(255,255,255,.9)"; g.fillRect(0, 10, 512, 12); g.fillStyle = "rgba(255,255,255,.3)"; g.fillRect(0, 76, 512, 6);
      g.fillStyle = "rgba(200,220,240,.18)"; g.fillRect(0, 110, 512, 5); g.fillStyle = "rgba(0,0,0,.6)"; g.fillRect(0, 150, 512, 26);
      var t = new THREE.CanvasTexture(c); t.mapping = THREE.EquirectangularReflectionMapping; t.encoding = THREE.sRGBEncoding;
      var pm = new THREE.PMREMGenerator(renderer); pm.compileEquirectangularShader();
      scene.environment = pm.fromEquirectangular(t).texture; t.dispose(); pm.dispose();
    })();
    scene.add(new THREE.HemisphereLight(0x8fa0b0, 0x050607, 0.35));
    var key = new THREE.DirectionalLight(0xffffff, 1.5); key.position.set(30, 60, 40); scene.add(key);
    var rim = new THREE.DirectionalLight(0xbfd4e6, 0.9); rim.position.set(-40, 25, -30); scene.add(rim);
    var fill = new THREE.DirectionalLight(0xffffff, 0.35); fill.position.set(-10, -20, 30); scene.add(fill);
    var M = {
      alu: new THREE.MeshStandardMaterial({ color: 0xdfe3e7, metalness: 1.0, roughness: 0.24 }),
      aluDk: new THREE.MeshStandardMaterial({ color: 0x80878e, metalness: 0.95, roughness: 0.4 }),
      blk: new THREE.MeshStandardMaterial({ color: 0x0c0e11, metalness: 0.45, roughness: 0.55 }),
      steel: new THREE.MeshStandardMaterial({ color: 0xd4d8dc, metalness: 1.0, roughness: 0.18 }),
      steelDk: new THREE.MeshStandardMaterial({ color: 0x8a9197, metalness: 1.0, roughness: 0.32 }),
      hole: new THREE.MeshStandardMaterial({ color: 0x050607, metalness: 0.2, roughness: 0.9 }),
      pcb: new THREE.MeshStandardMaterial({ color: 0x0f4d33, metalness: 0.15, roughness: 0.6 }),
      chip: new THREE.MeshStandardMaterial({ color: 0x111316, metalness: 0.3, roughness: 0.5 }),
      gold: new THREE.MeshStandardMaterial({ color: 0xd2a94c, metalness: 1.0, roughness: 0.35 }),
      brass: new THREE.MeshStandardMaterial({ color: 0xc9a15a, metalness: 1.0, roughness: 0.28 }),
      batt: new THREE.MeshStandardMaterial({ color: 0xd9b21f, metalness: 0.35, roughness: 0.45 }),
      red: new THREE.MeshStandardMaterial({ color: 0xb4231c, metalness: 0.2, roughness: 0.45 }),
      wire: new THREE.MeshStandardMaterial({ color: 0x9a1d18, metalness: 0.05, roughness: 0.6 }),
      wireB: new THREE.MeshStandardMaterial({ color: 0x151515, metalness: 0.05, roughness: 0.6 }),
      acr: new THREE.MeshPhysicalMaterial({ color: 0xcfe3ef, metalness: 0, roughness: 0.08, transparent: true, opacity: 0.12, depthWrite: false, side: THREE.DoubleSide }),
      cap: new THREE.MeshPhysicalMaterial({ color: 0xe6f0f6, metalness: 0, roughness: 0.15, transparent: true, opacity: 0.35, depthWrite: false })
    };
    var stage = new THREE.Group(); scene.add(stage);                      // world content (shifted in edge mode)
    var body = new THREE.Group(); body.matrixAutoUpdate = false; stage.add(body);
    var model = new THREE.Group(); body.add(model);                      // the 18 cm hardware model, scaled to a
    var A = 18, R = 1.0, h = R / 2;
    function box(w, hh, d, mat, x, y, z, parent) { var m = new THREE.Mesh(new THREE.BoxGeometry(w, hh, d), mat); m.position.set(x, y, z); (parent || model).add(m); return m; }
    [h, A - h].forEach(function (a1) { [h, A - h].forEach(function (a2) { box(A - 1.6, R, R, M.alu, A / 2, a1, a2); box(R, A - 1.6, R, M.alu, a1, A / 2, a2); box(R, R, A - 1.6, M.alu, a1, a2, A / 2); }); });
    [0.95, A - 0.95].forEach(function (x) { [0.95, A - 0.95].forEach(function (y) { [0.95, A - 0.95].forEach(function (z) { box(1.9, 1.9, 1.9, M.blk, x, y, z); }); }); });
    box(0.22, 15.2, 15.2, M.acr, A - 0.62, A / 2, A / 2); box(15.2, 0.22, 15.2, M.acr, A / 2, A - 0.62, A / 2); box(15.2, 15.2, 0.22, M.acr, A / 2, A / 2, A - 0.62);
    var wheels = [], wheelMats = [], ringMats = [];
    function wheel(i) {
      var g = new THREE.Group(), rot = new THREE.Group(), wm = M.steel.clone(); wheelMats.push(wm);
      rot.add(new THREE.Mesh(new THREE.CylinderGeometry(4.9, 4.9, 0.45, 64), wm));
      var rimT = new THREE.Mesh(new THREE.TorusGeometry(4.75, 0.62, 18, 80), wm); rimT.rotation.x = Math.PI / 2; rot.add(rimT);
      var hub = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.25, 1.5, 32), M.steelDk); hub.position.y = 0.2; rot.add(hub);
      var rmat = new THREE.MeshBasicMaterial({ color: RING.ok }); ringMats.push(rmat);
      var ring = new THREE.Mesh(new THREE.TorusGeometry(1.55, 0.13, 8, 40), rmat); ring.rotation.x = Math.PI / 2; ring.position.y = 0.32; rot.add(ring);
      for (var k = 0; k < 6; k++) {
        var an = k / 6 * Math.PI * 2;
        var hl = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.5, 20), M.hole); hl.position.set(Math.cos(an) * 3.0, 0.01, Math.sin(an) * 3.0); rot.add(hl);
        var bt = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.55, 8), M.steelDk); bt.position.set(Math.cos(an + 0.52) * 1.9, 0.08, Math.sin(an + 0.52) * 1.9); rot.add(bt);
      }
      g.add(rot);
      var can = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.3, 2.6, 32), M.blk); can.position.y = -1.75; g.add(can);
      var capM = new THREE.Mesh(new THREE.CylinderGeometry(2.35, 2.35, 0.3, 32), M.aluDk); capM.position.y = -0.4; g.add(capM);
      var brk = new THREE.Mesh(new THREE.BoxGeometry(6.4, 0.35, 1.2), M.aluDk); brk.position.y = -3.1; g.add(brk);
      var off = A - 2.25;
      if (i === 0) { g.rotation.z = -Math.PI / 2; g.position.set(off, A / 2, A / 2); }
      if (i === 1) { g.position.set(A / 2, off, A / 2); }
      if (i === 2) { g.rotation.x = Math.PI / 2; g.position.set(A / 2, A / 2, off); }
      model.add(g); wheels.push(rot);
    }
    wheel(0); wheel(1); wheel(2);
    box(10, 0.16, 8.6, M.pcb, 9, 1.4, 10.6);
    box(1.9, 0.3, 1.9, M.chip, 9.2, 1.62, 11.2); box(1.1, 0.26, 1.1, M.chip, 12.1, 1.6, 8.4); box(0.9, 0.24, 0.9, M.chip, 6.3, 1.6, 13.2);
    box(3.6, 0.45, 0.45, M.gold, 8.2, 1.7, 14.4); box(0.45, 0.45, 2.6, M.gold, 13.3, 1.7, 12.2);
    for (var e = 0; e < 4; e++) { box(1.8, 1.4, 2.3, M.blk, 5.1 + e * 2.6, 2.0, 3.6); box(1.5, 1.1, 1.9, M.cap, 5.1 + e * 2.6, 3.2, 3.6); }
    box(11, 2.1, 2.3, M.batt, 9, 6.2, 1.5); box(0.9, 2.2, 2.4, M.blk, 5.4, 6.2, 1.5); box(0.9, 2.2, 2.4, M.blk, 12.6, 6.2, 1.5);
    var stop = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 0.9, 24), M.red); stop.position.set(3.2, -0.25, 2.6); model.add(stop);
    box(1.3, 0.45, 0.8, M.blk, 5.3, -0.05, 2.4); box(1.1, 0.8, 0.7, M.batt, 7.3, 0.55, 2.2);
    [[A - 5, A / 2, A / 2], [A / 2, A - 5, A / 2], [A / 2, A / 2, A - 5]].forEach(function (end, i) {
      var st = new THREE.Vector3(7 + i * 1.5, 1.7, 9.5), en = new THREE.Vector3(end[0], end[1], end[2]);
      var mid = st.clone().lerp(en, 0.5); mid.x += i === 0 ? 1.5 : -2.5; mid.y += 2.5; mid.z += i === 2 ? -2.5 : 2;
      model.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([st, mid, en]), 30, 0.14, 8, false), M.wire));
      model.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([st.clone().add(new THREE.Vector3(0.35, 0, 0)), mid.clone().add(new THREE.Vector3(0.35, 0, 0.2)), en.clone().add(new THREE.Vector3(0.3, 0, 0))]), 30, 0.12, 8, false), M.wireB));
    });
    // invisible pick box (body coordinates, cm; resized with a)
    var pickBox = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial({ visible: false })); body.add(pickBox);
    // overlays inside the body frame
    var overlay = new THREE.Group(); body.add(overlay);
    // world: floor, rings, vertical, contact shadow, world axes
    var fc = document.createElement("canvas"); fc.width = fc.height = 256;
    var fg = fc.getContext("2d"), frg = fg.createRadialGradient(128, 128, 0, 128, 128, 128);
    frg.addColorStop(0, "rgba(30,34,38,1)"); frg.addColorStop(0.55, "rgba(12,14,16,.9)"); frg.addColorStop(1, "rgba(0,0,0,0)");
    fg.fillStyle = frg; fg.fillRect(0, 0, 256, 256);
    var floor = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(fc), transparent: true, depthWrite: false }));
    floor.rotation.x = -Math.PI / 2; scene.add(floor);
    var rings = [];
    [10, 20, 30, 40].forEach(function (r, i) {
      var ring = new THREE.Mesh(new THREE.RingGeometry(r - 0.06, r + 0.06, 128), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.07 - i * 0.012, depthWrite: false }));
      ring.rotation.x = -Math.PI / 2; ring.position.y = 0.01; scene.add(ring); rings.push(ring);
    });
    var sc = document.createElement("canvas"); sc.width = sc.height = 128;
    var sg = sc.getContext("2d"), srg = sg.createRadialGradient(64, 64, 0, 64, 64, 64); srg.addColorStop(0, "rgba(0,0,0,.75)"); srg.addColorStop(1, "rgba(0,0,0,0)");
    sg.fillStyle = srg; sg.fillRect(0, 0, 128, 128);
    var shadow = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(sc), transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2; shadow.position.y = 0.02; stage.add(shadow);
    var worldOv = new THREE.Group(); stage.add(worldOv);
    return { renderer: renderer, scene: scene, camera: camera, stage: stage, body: body, model: model, wheels: wheels, wheelMats: wheelMats, ringMats: ringMats, pickBox: pickBox, overlay: overlay, worldOv: worldOv, floor: floor, rings: rings, shadow: shadow, M: M, raycaster: new THREE.Raycaster() };
  };

  /* ---------------- helpers for overlay objects ---------------- */
  function clear(g) { while (g.children.length) { var c = g.children.pop(); c.traverse(function (o) { if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } }); } }
  function line(pts, color, opacity, dashed) {
    var geo = new THREE.BufferGeometry().setFromPoints(pts.map(function (p) { return new THREE.Vector3(p[0], p[1], p[2]); }));
    var mat = dashed ? new THREE.LineDashedMaterial({ color: color, dashSize: 0.9, gapSize: 0.7, transparent: true, opacity: opacity == null ? 1 : opacity }) : new THREE.LineBasicMaterial({ color: color, transparent: true, opacity: opacity == null ? 1 : opacity });
    var l = new THREE.Line(geo, mat); if (dashed) l.computeLineDistances(); return l;
  }
  function arrow(from, to, color, head, opacity) {
    var d = new THREE.Vector3(to[0] - from[0], to[1] - from[1], to[2] - from[2]), len = d.length();
    if (len < 1e-6) return new THREE.Group();
    var a = new THREE.ArrowHelper(d.clone().normalize(), new THREE.Vector3(from[0], from[1], from[2]), len, new THREE.Color(color), Math.min(len * 0.35, head || 2.2), Math.min(len * 0.2, (head || 2.2) * 0.55));
    if (opacity != null && opacity < 1) a.traverse(function (o) { if (o.material) { o.material.transparent = true; o.material.opacity = opacity; } });
    return a;
  }
  function label(text, color, size) {
    var c = document.createElement("canvas"), g = c.getContext("2d"), fs = 44;
    g.font = "700 " + fs + "px 'JetBrains Mono', monospace"; var w = Math.ceil(g.measureText(text).width) + 24;
    c.width = w; c.height = fs + 22; g.font = "700 " + fs + "px 'JetBrains Mono', monospace";
    g.fillStyle = "rgba(0,0,0,.62)"; g.fillRect(0, 0, w, c.height); g.fillStyle = color; g.textBaseline = "middle"; g.fillText(text, 12, c.height / 2 + 2);
    var tex = new THREE.CanvasTexture(c); tex.encoding = THREE.sRGBEncoding;
    var s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
    var hgt = size || 1.6; s.scale.set(hgt * w / c.height, hgt, 1); s.renderOrder = 10; return s;
  }

  /* ---------------- scene description (what exists: cube size, masses, loads) ---------------- */
  /* desc = { mode, a, attachments:[{id,label,mass_kg,pos_m}], com_m, nominal_com_m, loads:[{id,type,point_m,frame}], failed:[bool×3], selected, showMarkers }
     nominal_com_m: the design COM of the bare cube; when the COM differs from it by more than 0.05 mm a grey
     ghost marks it and an arrow shows Δr_COM, magnified by the factor written on its label */
  Viewer.prototype.setScene = function (desc) {
    this.scene = desc; this.dirty = true;
    if (!this.three) { this.request(); return; }
    var T = this.three, a = desc.a * 100, s = a / 18;
    T.model.scale.set(s, s, s);
    T.pickBox.scale.set(a, a, a); T.pickBox.position.set(a / 2, a / 2, a / 2);
    var fsz = Math.max(150, a * 8.5); T.floor.scale.set(fsz, fsz, 1);
    T.rings.forEach(function (r, i) { var k = a / 18; r.scale.set(k, k, k); });
    T.shadow.scale.set(a * 1.45, a * 1.45, 1);
    T.stage.position.set(desc.mode === "edge" ? -a / 2 : 0, 0, 0);
    // body-frame overlays
    clear(T.overlay); this.markerMeshes = [];
    var ov = T.overlay, self = this;
    if (desc.showMarkers !== false) {
      var L = a * 1.22;
      [[1, 0, 0], [0, 1, 0], [0, 0, 1]].forEach(function (u, i) { ov.add(arrow([0, 0, 0], [u[0] * L, u[1] * L, u[2] * L], AX[i], a * 0.08, 0.85)); var lb = label("xyz"[i] + "_B", AX[i], a * 0.06); lb.position.set(u[0] * (L + a * 0.07), u[1] * (L + a * 0.07), u[2] * (L + a * 0.07)); ov.add(lb); });
      var com = desc.com_m.map(function (v) { return v * 100; });
      var comMesh = new THREE.Mesh(new THREE.SphereGeometry(a * 0.028, 20, 14), new THREE.MeshBasicMaterial({ color: COM, depthTest: false })); comMesh.position.set(com[0], com[1], com[2]); comMesh.renderOrder = 6; ov.add(comMesh);
      ov.add(line([[0, 0, 0], com], COM, 0.55));
      var cl = label("COM", COM, a * 0.055); cl.position.set(com[0] + a * 0.07, com[1] + a * 0.04, com[2]); ov.add(cl);
      this.comShift = null;
      if (desc.nominal_com_m) {
        var c0 = desc.nominal_com_m.map(function (v) { return v * 100; }), dr = [com[0] - c0[0], com[1] - c0[1], com[2] - c0[2]], drn = nrm(dr);
        if (drn > 0.005) {   // > 0.05 mm (scene units are cm)
          var ghost = new THREE.Mesh(new THREE.SphereGeometry(a * 0.03, 16, 10), new THREE.MeshBasicMaterial({ color: COM0, wireframe: true, transparent: true, opacity: 0.8, depthTest: false }));
          ghost.position.set(c0[0], c0[1], c0[2]); ghost.renderOrder = 5; ov.add(ghost);
          var k = magnification(drn, a), tip = add(c0, scl(dr, k));
          ov.add(arrow(c0, tip, COM, a * 0.05, 0.95));
          var gl = label("Δr ×" + k, COM, a * 0.05); gl.position.set(tip[0] + a * 0.05, tip[1] + a * 0.05, tip[2]); ov.add(gl);
          var nl = label("nominal", COM0, a * 0.042); nl.position.set(c0[0] - a * 0.1, c0[1] - a * 0.06, c0[2]); ov.add(nl);
          this.comShift = { dr_mm: dr.map(function (v) { return v * 10; }), magnification: k };
        }
      }
      (desc.attachments || []).forEach(function (at, i) {
        var p = at.pos_m.map(function (v) { return v * 100; }), sz = Math.max(a * 0.035, Math.min(a * 0.14, a * 0.2 * Math.cbrt(Math.max(1e-4, at.mass_kg))));
        var sel = desc.selected === at.id;
        var mesh = new THREE.Mesh(new THREE.BoxGeometry(sz, sz, sz), sel ? new THREE.MeshStandardMaterial({ color: 0xe8c77a, metalness: 1, roughness: 0.25, emissive: 0x3a3a00 }) : T.M.brass.clone());
        mesh.position.set(p[0], p[1], p[2]); mesh.userData = { kind: "mass", id: at.id }; ov.add(mesh); self.markerMeshes.push(mesh);
        if (sel) { var hl = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(sz * 1.5, sz * 1.5, sz * 1.5)), new THREE.LineBasicMaterial({ color: SEL, depthTest: false })); hl.position.copy(mesh.position); hl.renderOrder = 7; ov.add(hl); }
        var lb = label("m" + (i + 1), sel ? SEL : "#d6d9de", a * 0.05); lb.position.set(p[0], p[1] + sz * 0.9, p[2]); ov.add(lb);
      });
      (desc.loads || []).forEach(function (Ld) {
        if (Ld.type !== "force") return;
        var p = Ld.point_m.map(function (v) { return v * 100; }), sel = desc.selected === Ld.id;
        var dot = new THREE.Mesh(new THREE.SphereGeometry(a * (sel ? 0.03 : 0.02), 14, 10), new THREE.MeshBasicMaterial({ color: FORCE, depthTest: false }));
        dot.position.set(p[0], p[1], p[2]); dot.renderOrder = 6; dot.userData = { kind: "load", id: Ld.id }; ov.add(dot); self.markerMeshes.push(dot);
      });
    }
    this.buildWorld();
    for (var i = 0; i < 3; i++) this.tintWheel(i, desc.failed && desc.failed[i] ? "failed" : "ok");
    this.setPose(this.pose || { R: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], wheelAngles: [0, 0, 0], loads: [] });
  };
  /* wheel state: "ok" (neutral ring), "risk" / "sat" (amber: near the speed limit or torque-limited), "failed" (red) */
  Viewer.prototype.tintWheel = function (i, state) {
    if (!this.three) return;
    if (state === true) state = "failed"; else if (!state) state = "ok";
    var T = this.three, dead = state === "failed"; T.wheelMats[i].color.setHex(dead ? 0x5a3432 : 0xd4d8dc); T.wheelMats[i].roughness = dead ? 0.55 : 0.18;
    T.ringMats[i].color.set(RING[state] || RING.ok);
    (this.wheelStates || (this.wheelStates = ["ok", "ok", "ok"]))[i] = state;
  };

  /* ---------------- pose at one sample ---------------- */
  /* pose = { R: body→world 3×3, wheelAngles:[3] (rad), failed:[3], loads:[{id, point_m (body), F_world, active, label}], torque_world, gravity_N, t } */
  Viewer.prototype.buildWorld = function () {
    var T = this.three, sc = this.scene, a = sc.a * 100;
    clear(T.worldOv);
    var W = T.worldOv, dyn = {};
    W.add(line([[0, 0, 0], [0, a * 2.2, 0]], 0xffffff, 0.35, true));                        // vertical through the pivot
    if (sc.mode === "edge") W.add(line([[0, 0.05, 0], [a, 0.05, 0]], NEUTRAL, 0.7));        // support edge on the floor
    var o = [-a * 0.9, 0.05, a * 0.9], wl = a * 0.28;                                        // world axes
    [[1, 0, 0], [0, 1, 0], [0, 0, 1]].forEach(function (u, i) { var d = w2t(u); W.add(arrow(o, add(o, scl(d, wl)), AX[i], a * 0.05, 0.6)); var lb = label("xyz"[i] + "_N", AX[i], a * 0.042); var q = add(o, scl(d, wl + a * 0.06)); lb.position.set(q[0], q[1], q[2]); W.add(lb); });
    dyn.ring = new THREE.Mesh(new THREE.RingGeometry(a * 0.03, a * 0.045, 32), new THREE.MeshBasicMaterial({ color: COM, transparent: true, opacity: 0.7, depthWrite: false, side: THREE.DoubleSide }));
    dyn.ring.rotation.x = -Math.PI / 2; W.add(dyn.ring);
    dyn.drop = line([[0, 0, 0], [0, 1, 0]], COM, 0.25, true); W.add(dyn.drop);
    dyn.grav = new THREE.ArrowHelper(new THREE.Vector3(0, -1, 0), new THREE.Vector3(), a * 0.3, 0xdddddd, a * 0.05, a * 0.03); W.add(dyn.grav);
    dyn.loads = {};
    (sc.loads || []).forEach(function (Ld) {
      if (Ld.type !== "force") return;
      var ar = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(), a * 0.3, new THREE.Color(FORCE), a * 0.07, a * 0.04);
      ar.traverse(function (x) { if (x.material) x.material.transparent = true; });
      var lb = label(Ld.label || Ld.id, FORCE, a * 0.05); W.add(ar); W.add(lb); dyn.loads[Ld.id] = { arrow: ar, label: lb };
    });
    dyn.tq = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(), a * 0.3, new THREE.Color(TORQUE), a * 0.08, a * 0.045); W.add(dyn.tq);
    dyn.tqLabel = label("τ_F", TORQUE, a * 0.05); W.add(dyn.tqLabel);
    this.dyn = dyn;
  };
  Viewer.prototype.setPose = function (pose) {
    this.pose = pose; this.dirty = true;
    if (!this.three || !this.scene) { this.request(); return; }
    if (!this.dyn) this.buildWorld();
    var T = this.three, D = this.dyn, R = pose.R, a = this.scene.a * 100, m = new THREE.Matrix4();
    m.set(R[0][0], R[0][1], R[0][2], 0, R[2][0], R[2][1], R[2][2], 0, -R[1][0], -R[1][1], -R[1][2], 0, 0, 0, 0, 1);
    T.body.matrix.copy(m); T.body.matrixWorldNeedsUpdate = true;
    for (var i = 0; i < 3; i++) { T.wheels[i].rotation.y = (pose.wheelAngles ? pose.wheelAngles[i] : 0) / 12; if (pose.wheelState) this.tintWheel(i, pose.wheelState[i]); else if (pose.failed) this.tintWheel(i, pose.failed[i] ? "failed" : "ok"); }
    var comW = w2t(mv(R, this.scene.com_m.map(function (v) { return v * 100; })));
    D.ring.position.set(comW[0], 0.06, comW[2]); T.shadow.position.set(comW[0], 0.02, comW[2]);
    var pa = D.drop.geometry.attributes.position; pa.setXYZ(0, comW[0], 0.06, comW[2]); pa.setXYZ(1, comW[0], comW[1], comW[2]); pa.needsUpdate = true; D.drop.computeLineDistances();
    D.grav.visible = !!pose.gravity_N;
    if (pose.gravity_N) { var gl = Math.max(a * 0.12, Math.min(a * 0.6, a * 0.08 * Math.log(1 + pose.gravity_N))); D.grav.position.set(comW[0], comW[1], comW[2]); D.grav.setLength(gl, a * 0.05, a * 0.03); }
    Object.keys(D.loads).forEach(function (id) { D.loads[id].arrow.visible = false; D.loads[id].label.visible = false; });
    (pose.loads || []).forEach(function (Ld) {
      var o = D.loads[Ld.id]; if (!o || !Ld.F_world) return;
      var pW = w2t(mv(R, Ld.point_m.map(function (v) { return v * 100; }))), Fw = w2t(Ld.F_world), mag = nrm(Fw);
      if (!(mag > 0)) return;
      var len = Ld.active ? Math.max(a * 0.18, Math.min(a * 0.9, a * 0.28 * (1 + Math.log(1 + mag)))) : a * 0.22, u = scl(Fw, 1 / mag), tail = add(pW, scl(u, -len));
      o.arrow.position.set(tail[0], tail[1], tail[2]); o.arrow.setDirection(new THREE.Vector3(u[0], u[1], u[2])); o.arrow.setLength(len, a * 0.07, a * 0.04);
      o.arrow.setColor(new THREE.Color(Ld.active ? FORCE : "#777777"));
      o.arrow.traverse(function (x) { if (x.material) x.material.opacity = Ld.active ? 1 : 0.45; });
      o.arrow.visible = true; o.label.visible = !!Ld.active;
      var q = add(tail, scl(u, -a * 0.06)); o.label.position.set(q[0], q[1], q[2]);
    });
    var tw = pose.torque_world ? w2t(pose.torque_world) : [0, 0, 0], tm = nrm(tw);
    D.tq.visible = D.tqLabel.visible = tm > 1e-9;
    if (tm > 1e-9) {
      var tl = Math.max(a * 0.25, Math.min(a * 0.9, a * 0.35 * (1 + Math.log(1 + tm * 20))));
      D.tq.position.set(0, 0, 0); D.tq.setDirection(new THREE.Vector3(tw[0] / tm, tw[1] / tm, tw[2] / tm)); D.tq.setLength(tl, a * 0.08, a * 0.045);
      D.tqLabel.position.set(tw[0] / tm * tl * 1.1, tw[1] / tm * tl * 1.1 + a * 0.03, tw[2] / tm * tl * 1.1);
    }
    this.request();
  };

  /* ---------------- camera ---------------- */
  Viewer.prototype.setView = function (name) { var v = VIEWS[name]; if (!v) return; this.view = name; this.cam.ty = v.yaw; this.cam.tp = v.pitch; this.cam.tz = 1; this.request(); };
  Viewer.prototype.resetCamera = function () { this.setView("iso"); };
  Viewer.prototype.zoomBy = function (f) { this.cam.tz = Math.max(0.45, Math.min(2.4, this.cam.tz * f)); this.request(); };
  Viewer.prototype.orbit = function (dyaw, dpitch) { this.cam.ty += dyaw; this.cam.tp = Math.max(-0.05, Math.min(1.5, this.cam.tp + dpitch)); this.request(); };
  Viewer.prototype.camPos = function () {
    var a = this.scene ? this.scene.a * 100 : 18, corner = this.scene && this.scene.mode === "corner", c = this.cam;
    var dist = (corner ? 5.3 : 4.9) * a * c.zoom * (this.aspect < 1.05 ? 1.25 : 1), tgt = [0, a * (corner ? 0.82 : 0.66), 0];
    return { pos: [tgt[0] + dist * Math.cos(c.pitch) * Math.sin(c.yaw), tgt[1] + dist * Math.sin(c.pitch), tgt[2] + dist * Math.cos(c.pitch) * Math.cos(c.yaw)], tgt: tgt };
  };

  /* ---------------- input: orbit, pick ---------------- */
  Viewer.prototype.bind = function () {
    var self = this, el = this.host;
    el.addEventListener("pointerdown", function (e) { if (e.button !== 0) return; self.cam.drag = true; self.cam.moved = 0; self.cam.lx = e.clientX; self.cam.ly = e.clientY; self.autoSpin = false; try { el.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } });
    el.addEventListener("pointermove", function (e) {
      if (!self.cam.drag) return;
      var dx = e.clientX - self.cam.lx, dy = e.clientY - self.cam.ly; self.cam.moved += Math.abs(dx) + Math.abs(dy);
      self.orbit(dx * 0.007, dy * 0.005); self.cam.lx = e.clientX; self.cam.ly = e.clientY;
    });
    function end(e) {
      if (!self.cam.drag) return; self.cam.drag = false;
      if (self.cam.moved < 5 && e && e.type === "pointerup") self.pick(e);
    }
    el.addEventListener("pointerup", end); el.addEventListener("pointercancel", function () { self.cam.drag = false; });
    el.addEventListener("keydown", function (e) {
      var k = e.key, used = true;
      if (k === "ArrowLeft") self.orbit(-0.12, 0); else if (k === "ArrowRight") self.orbit(0.12, 0);
      else if (k === "ArrowUp") self.orbit(0, 0.08); else if (k === "ArrowDown") self.orbit(0, -0.08);
      else if (k === "+" || k === "=") self.zoomBy(0.85); else if (k === "-" || k === "_") self.zoomBy(1 / 0.85);
      else if (k === "0") self.resetCamera(); else used = false;
      if (used) e.preventDefault();
    });
  };
  Viewer.prototype.pick = function (e) {
    if (!this.onPick || !this.scene) return;
    var r = this.canvas.getBoundingClientRect(), nx = (e.clientX - r.left) / r.width * 2 - 1, ny = -((e.clientY - r.top) / r.height * 2 - 1);
    if (this.three) {
      var T = this.three; this.updateCamera(); T.body.updateMatrixWorld(true);
      T.raycaster.setFromCamera({ x: nx, y: ny }, T.camera);
      var hits = T.raycaster.intersectObjects(this.markerMeshes || [], false);
      if (hits.length) { var ud = hits[0].object.userData; this.onPick({ kind: ud.kind, id: ud.id }); return; }
      if (!this.pickMode) return;
      var hb = T.raycaster.intersectObject(T.pickBox, false);
      if (hb.length) {
        var loc = T.body.worldToLocal(hb[0].point.clone()), a = this.scene.a;
        var pb = [loc.x / 100, loc.y / 100, loc.z / 100].map(function (v) { return Math.max(0, Math.min(a, v)); });
        var n = hb[0].face ? hb[0].face.normal : null;
        this.onPick({ kind: "surface", point_m: pb, normal_body: n ? [n.x, n.y, n.z] : null });
      } else this.onPick({ kind: "miss" });
    } else if (this.pickMode) this.pick2d(nx, ny);
  };

  /* ---------------- frame loop ---------------- */
  Viewer.prototype.request = function () { if (!this.raf) this.raf = requestAnimationFrame(this.loop); };
  Viewer.prototype.resize = function () {
    var w = this.host.clientWidth, h = this.host.clientHeight; if (!w || !h) return;
    this.aspect = w / h; this.w = w; this.h = h;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    if (this.three) { this.three.renderer.setPixelRatio(dpr); this.three.renderer.setSize(w, h, false); this.three.camera.aspect = w / h; this.three.camera.updateProjectionMatrix(); }
    else { this.canvas.width = Math.round(w * dpr); this.canvas.height = Math.round(h * dpr); this.ctx2d.setTransform(dpr, 0, 0, dpr, 0, 0); }
    this.dirty = true; this.request();
  };
  Viewer.prototype.updateCamera = function () { var cp = this.camPos(), T = this.three; T.camera.position.set(cp.pos[0], cp.pos[1], cp.pos[2]); T.camera.lookAt(cp.tgt[0], cp.tgt[1], cp.tgt[2]); };
  Viewer.prototype.frame = function (now) {
    var dt = this.last ? Math.min(0.1, (now - this.last) / 1000) : 0.016; this.last = now;
    var c = this.cam, k = Math.min(1, dt * 7), moving = false;
    if (this.autoSpin && !c.drag) { c.ty += dt * 0.08; moving = true; }
    c.yaw += (c.ty - c.yaw) * k; c.pitch += (c.tp - c.pitch) * k; c.zoom += (c.tz - c.zoom) * k;
    if (Math.abs(c.ty - c.yaw) > 1e-4 || Math.abs(c.tp - c.pitch) > 1e-4 || Math.abs(c.tz - c.zoom) > 1e-4) moving = true;
    if (!document.hidden && this.visible && (moving || this.dirty)) {
      if (this.three) { this.updateCamera(); this.three.renderer.render(this.three.scene, this.three.camera); }
      else this.draw2d();
      this.dirty = false; this.renders = (this.renders || 0) + 1;
    }
    if (moving) this.request(); else this.last = 0;
  };

  /* ---------------- 2-D fallback (WebGL unavailable): orthographic wireframe ---------------- */
  Viewer.prototype.draw2d = function () {
    var g = this.ctx2d, W = this.w, H = this.h; if (!g || !W) return;
    g.clearRect(0, 0, W, H);
    if (!this.scene || !this.pose) return;
    var c = this.cam, a = this.scene.a, R = this.pose.R, sh = this.scene.mode === "edge" ? a / 2 : 0;
    var corner = this.scene.mode === "corner", s = Math.min(W, H) / (a * (corner ? 3.6 : 3.2)) / c.zoom, ox = W / 2, oy = H / 2, tgt = [sh, 0, a * (corner ? 0.82 : 0.66)];
    // camera basis in the physics world (z up), matching the three.js orbit camera
    var fwd = [-Math.sin(c.yaw) * Math.cos(c.pitch), Math.cos(c.yaw) * Math.cos(c.pitch), -Math.sin(c.pitch)];
    var right = [Math.cos(c.yaw), Math.sin(c.yaw), 0], up = [right[1] * fwd[2] - right[2] * fwd[1], right[2] * fwd[0] - right[0] * fwd[2], right[0] * fwd[1] - right[1] * fwd[0]];
    function P(pw) { var d = [pw[0] - tgt[0], pw[1] - tgt[1], pw[2] - tgt[2]]; return [ox + s * (d[0] * right[0] + d[1] * right[1] + d[2] * right[2]), oy - s * (d[0] * up[0] + d[1] * up[1] + d[2] * up[2])]; }
    function B(pb) { return P(mv(R, pb)); }
    g.lineWidth = 1; g.strokeStyle = "rgba(255,255,255,.12)";
    g.beginPath(); var f0 = P([-a * 1.5 + sh, 0, 0]), f1 = P([a * 1.5 + sh, 0, 0]); g.moveTo(f0[0], f0[1]); g.lineTo(f1[0], f1[1]); var f2 = P([sh, -a * 1.5, 0]), f3 = P([sh, a * 1.5, 0]); g.moveTo(f2[0], f2[1]); g.lineTo(f3[0], f3[1]); g.stroke();
    var V = []; for (var i = 0; i < 8; i++) V.push(B([(i & 1) * a, (i >> 1 & 1) * a, (i >> 2 & 1) * a]));
    g.strokeStyle = "rgba(223,227,231,.85)"; g.lineWidth = 2; g.beginPath();
    [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]].forEach(function (e) { g.moveTo(V[e[0]][0], V[e[0]][1]); g.lineTo(V[e[1]][0], V[e[1]][1]); });
    g.stroke();
    var o = P([0, 0, 0]), vt = P([0, 0, a * 2]); g.setLineDash([5, 4]); g.strokeStyle = "rgba(255,255,255,.4)"; g.lineWidth = 1; g.beginPath(); g.moveTo(o[0], o[1]); g.lineTo(vt[0], vt[1]); g.stroke(); g.setLineDash([]);
    var cm = B(this.scene.com_m); g.strokeStyle = COM; g.beginPath(); g.moveTo(o[0], o[1]); g.lineTo(cm[0], cm[1]); g.stroke();
    g.fillStyle = COM; g.beginPath(); g.arc(cm[0], cm[1], 5, 0, 7); g.fill();
    if (this.scene.nominal_com_m) { var c0 = B(this.scene.nominal_com_m); g.strokeStyle = COM0; g.lineWidth = 1.5; g.beginPath(); g.arc(c0[0], c0[1], 5, 0, 7); g.stroke(); }
    (this.scene.attachments || []).forEach(function (at) { var p = B(at.pos_m); g.fillStyle = "#c9a15a"; g.fillRect(p[0] - 5, p[1] - 5, 10, 10); });
    (this.pose.loads || []).forEach(function (Ld) {
      if (!Ld.F_world) return; var p = B(Ld.point_m), mag = nrm(Ld.F_world); if (!(mag > 0)) return;
      var u = scl(Ld.F_world, 1 / mag), tail = P(add(mv(R, Ld.point_m), scl(u, -a * 0.5)));
      g.strokeStyle = Ld.active ? FORCE : "rgba(150,150,150,.5)"; g.lineWidth = 2.5; g.beginPath(); g.moveTo(tail[0], tail[1]); g.lineTo(p[0], p[1]); g.stroke();
      g.fillStyle = g.strokeStyle; g.beginPath(); g.arc(p[0], p[1], 4, 0, 7); g.fill();
    });
    g.fillStyle = "rgba(255,255,255,.55)"; g.font = "600 11px 'JetBrains Mono', monospace"; g.fillText("2-D view · WebGL unavailable", 12, H - 12);
    this.proj2dFn = B;
  };
  Viewer.prototype.pick2d = function (nx, ny) { if (this.onPick) this.onPick({ kind: "unsupported", message: "Click-to-place needs the 3-D view (WebGL). Enter the position numerically instead." }); };

  /* ---------------- test hook ---------------- */
  Viewer.prototype.snapshot = function () {
    return { mode: this.scene && this.scene.mode, a: this.scene && this.scene.a, t: this.pose && this.pose.t, comShift: this.comShift || null, wheelStates: (this.wheelStates || []).slice(), idx: this.pose && this.pose.idx, runId: this.pose && this.pose.runId, R: this.pose && this.pose.R, webgl: !!this.three, view: this.view, renders: this.renders || 0, attachments: this.scene ? (this.scene.attachments || []).length : 0, loads: this.pose ? (this.pose.loads || []).filter(function (l) { return l.active; }).length : 0 };
  };
  Viewer.VIEWS = VIEWS;
  return Viewer;
})();

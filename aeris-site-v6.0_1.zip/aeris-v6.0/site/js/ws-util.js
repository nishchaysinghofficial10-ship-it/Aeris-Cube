/* =====================================================================
   AERIS · small UI helpers shared by the workspace, Lab and home page
   ===================================================================== */
var U = (function () {
  "use strict";
  var DEG = Math.PI / 180, RPM = Math.PI / 30;
  function $(id) { return document.getElementById(id); }
  function qa(sel, root) { return [].slice.call((root || document).querySelectorAll(sel)); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function minus(s) { return String(s).replace(/^-/, "−").replace(/([\s(=,])-/g, "$1−"); }
  /* fixed decimals, true minus sign, no "−0.00" */
  function fx(x, d) {
    if (x === null || x === undefined || !isFinite(x)) return "—";
    var s = (+x).toFixed(d); if (/^-0(\.0+)?$/.test(s)) s = s.slice(1);
    return s.replace("-", "−");
  }
  /* significant figures, switching to ×10ⁿ for very small/large values */
  var SUP = { "-": "⁻", "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹" };
  function sig(x, n) {
    n = n || 4; if (x === null || x === undefined || !isFinite(x)) return "—"; if (x === 0) return "0";
    var e = Math.floor(Math.log10(Math.abs(x)));
    if (e < -3 || e > 5) { var m = x / Math.pow(10, e); if (Math.abs(+m.toFixed(n - 1)) >= 10) { m /= 10; e += 1; } return fx(m, n - 1) + "×10" + String(e).split("").map(function (c) { return SUP[c] || c; }).join(""); }
    return fx(x, Math.max(0, n - 1 - e));
  }
  /* number for TeX */
  function tn(x, n) {
    n = n || 4; if (x === null || x === undefined || !isFinite(x)) return "\\text{—}"; if (x === 0) return "0";
    var e = Math.floor(Math.log10(Math.abs(x)));
    if (e < -3 || e > 5) { var m = x / Math.pow(10, e); if (Math.abs(+m.toFixed(n - 1)) >= 10) { m /= 10; e += 1; } return "{" + m.toFixed(n - 1) + "\\times10^{" + e + "}}"; }   // braced so a following ^ is safe
    var s = x.toFixed(Math.max(0, n - 1 - e)); return /^-0(\.0+)?$/.test(s) ? s.slice(1) : s;
  }
  function vecT(v, n) { return "\\begin{bmatrix}" + v.map(function (x) { return tn(x, n || 3); }).join("\\\\ ") + "\\end{bmatrix}"; }
  function rowT(v, n) { return "(" + v.map(function (x) { return tn(x, n || 3); }).join(",\\ ") + ")"; }
  function matT(M, n) { return "\\begin{bmatrix}" + M.map(function (r) { return r.map(function (x) { return tn(x, n || 4); }).join(" & "); }).join("\\\\ ") + "\\end{bmatrix}"; }
  function tex(el, s, display) {
    if (!el) return;
    if (window.katex) { try { katex.render(s, el, { displayMode: !!display, throwOnError: false, strict: "ignore", trust: false }); return; } catch (e) { /* fall through */ } }
    el.textContent = s; el.classList.add("tex-err");
  }
  function texStr(s, display) {
    if (window.katex) { try { return katex.renderToString(s, { displayMode: !!display, throwOnError: false, strict: "ignore", trust: false }); } catch (e) { /* fall through */ } }
    return '<code class="tex-err">' + esc(s) + "</code>";
  }
  function el(tag, attrs, html) {
    var e = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) { if (attrs[k] === null || attrs[k] === undefined || attrs[k] === false) return; if (k === "text") e.textContent = attrs[k]; else if (k === "cls") e.className = attrs[k]; else e.setAttribute(k, attrs[k] === true ? "" : attrs[k]); });
    if (html != null) e.innerHTML = html;
    return e;
  }
  /* debounce with cancel() and pending(): a caller that changes context (e.g. the view mode) cancels work
     scheduled for the old context instead of letting it run late */
  function debounce(fn, ms) {
    var t = null;
    function d() { var a = arguments, s = this; clearTimeout(t); t = setTimeout(function () { t = null; fn.apply(s, a); }, ms); }
    d.cancel = function () { clearTimeout(t); t = null; };
    d.pending = function () { return t !== null; };
    return d;
  }

  /* accessible tabs: roving tabindex, arrows/Home/End, aria-selected, hidden panels */
  function tabs(list, onChange, opts) {
    var btns = qa('[role="tab"]', list), noHide = opts && opts.noHide;
    function select(b, focus) {
      btns.forEach(function (x) { var on = x === b; x.setAttribute("aria-selected", on ? "true" : "false"); x.tabIndex = on ? 0 : -1; var p = $(x.getAttribute("aria-controls")); if (p && !noHide) p.hidden = !on; });
      if (focus) b.focus();
      if (onChange) onChange(b.id, b);
    }
    btns.forEach(function (b, i) {
      b.addEventListener("click", function () { select(b, false); });
      b.addEventListener("keydown", function (e) {
        var k = e.key, j = null;
        if (k === "ArrowRight" || k === "ArrowDown") j = (i + 1) % btns.length; else if (k === "ArrowLeft" || k === "ArrowUp") j = (i - 1 + btns.length) % btns.length;
        else if (k === "Home") j = 0; else if (k === "End") j = btns.length - 1;
        if (j !== null) { e.preventDefault(); select(btns[j], true); }
      });
    });
    var cur = btns.filter(function (b) { return b.getAttribute("aria-selected") === "true"; })[0] || btns[0];
    select(cur, false);
    return { select: function (id, focus) { var b = btns.filter(function (x) { return x.id === id; })[0]; if (b) select(b, focus); }, current: function () { var b = btns.filter(function (x) { return x.getAttribute("aria-selected") === "true"; })[0]; return b && b.id; } };
  }

  /* downloads with a copy-as-text fallback (sandboxed viewers can block downloads) */
  function download(name, text, mime) {
    try {
      var blob = new Blob([text], { type: mime || "application/octet-stream" }), url = URL.createObjectURL(blob), a = document.createElement("a");
      a.href = url; a.download = name; a.rel = "noopener"; document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1500);
      return true;
    } catch (e) { return false; }
  }
  var modalEl = null, lastFocus = null;
  function modal(opts) {
    closeModal(); lastFocus = document.activeElement;
    modalEl = el("div", { cls: "ws-modal", role: "dialog", "aria-modal": "true", "aria-labelledby": "wsModalTitle" });
    var box = el("div", { cls: "ws-modal-box" });
    box.appendChild(el("h2", { id: "wsModalTitle", text: opts.title }));
    if (opts.text) box.appendChild(el("p", { cls: "ws-modal-p", text: opts.text }));
    var ta = null;
    if (opts.textarea !== undefined) { ta = el("textarea", { cls: "ws-ta", spellcheck: "false", "aria-label": opts.taLabel || opts.title }); ta.value = opts.textarea || ""; if (opts.readonly) ta.readOnly = true; box.appendChild(ta); }
    if (opts.body) box.appendChild(opts.body);
    var row = el("div", { cls: "ws-modal-acts" });
    (opts.actions || []).forEach(function (a) {
      var b = el("button", { type: "button", cls: "btn btn-sm" + (a.primary ? " btn-solid" : ""), text: a.label });
      b.addEventListener("click", function () { var r = a.run ? a.run(ta ? ta.value : null, b) : true; if (r !== false) closeModal(); });
      row.appendChild(b);
    });
    var close = el("button", { type: "button", cls: "btn btn-sm", text: opts.closeLabel || "Close" }); close.addEventListener("click", closeModal); row.appendChild(close);
    box.appendChild(row); modalEl.appendChild(box); document.body.appendChild(modalEl);
    modalEl.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { e.preventDefault(); closeModal(); return; }
      if (e.key === "Tab") { var f = qa("button, textarea, input, select, a[href]", box).filter(function (x) { return !x.disabled; }); if (!f.length) return; var first = f[0], lastF = f[f.length - 1]; if (e.shiftKey && document.activeElement === first) { e.preventDefault(); lastF.focus(); } else if (!e.shiftKey && document.activeElement === lastF) { e.preventDefault(); first.focus(); } }
    });
    modalEl.addEventListener("click", function (e) { if (e.target === modalEl) closeModal(); });
    (ta || box.querySelector("button")).focus();
    if (ta && opts.readonly) ta.select();
    return { textarea: ta, box: box };
  }
  function closeModal() { if (modalEl) { modalEl.remove(); modalEl = null; if (lastFocus && lastFocus.focus) try { lastFocus.focus(); } catch (e) { /* ignore */ } } }
  function copyText(text, done) {
    function fallback() { var ta = el("textarea"); ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0"; document.body.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand("copy"); } catch (e) { ok = false; } ta.remove(); done && done(ok); }
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(function () { done && done(true); }, fallback); return; } } catch (e) { /* ignore */ }
    fallback();
  }
  /* keep Greek letters lower-case inside upper-case labels (θ must not become Θ) */
  function fixGreek(root) {
    if (!root) return;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null), nodes = [], n;
    while ((n = walker.nextNode())) { if (/[Ͱ-Ͽ]/.test(n.nodeValue)) nodes.push(n); }
    nodes.forEach(function (t) {
      var p = t.parentNode; if (!p || !p.closest || p.closest(".katex") || p.classList.contains("nt")) return;
      if (getComputedStyle(p).textTransform !== "uppercase") return;
      var frag = document.createDocumentFragment();
      t.nodeValue.split(/([Ͱ-Ͽ][̀-ͯ̂̇₀-ₜ]*)/).forEach(function (part) {
        if (!part) return;
        if (/^[Ͱ-Ͽ]/.test(part)) { var s = document.createElement("span"); s.className = "nt"; s.textContent = part; frag.appendChild(s); }
        else frag.appendChild(document.createTextNode(part));
      });
      p.replaceChild(frag, t);
    });
  }
  /* wrap Greek letters in HTML meant for upper-case labels so θ does not turn into Θ */
  function nt(html) { return String(html).replace(/([\u0370-\u03ff][\u0300-\u036f]*)/g, '<span class="nt">$1</span>'); }
  function tone(code) { return code === "recovered" ? "ok" : code === "fallen" || code === "invalid" ? "bad" : "warn"; }
  /* outcome badge: the icon is drawn from data-icon by CSS, so the element's text is exactly the label */
  function icon(code) { return typeof AERIS_TOKENS !== "undefined" ? AERIS_TOKENS.outcome(code).icon : ""; }
  function badge(outcome) { if (!outcome) return ""; return '<span class="oc-badge ' + tone(outcome.code) + '" data-icon="' + icon(outcome.code) + '">' + esc(outcome.label) + "</span>"; }
  return { nt: nt, DEG: DEG, RPM: RPM, $: $, qa: qa, esc: esc, minus: minus, fx: fx, sig: sig, tn: tn, vecT: vecT, rowT: rowT, matT: matT, tex: tex, texStr: texStr, el: el, debounce: debounce, tabs: tabs, download: download, modal: modal, closeModal: closeModal, copyText: copyText, fixGreek: fixGreek, tone: tone, badge: badge, icon: icon };
})();
window.fixGreek = U.fixGreek;

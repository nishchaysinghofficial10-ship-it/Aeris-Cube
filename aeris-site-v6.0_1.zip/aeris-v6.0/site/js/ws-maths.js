/* =====================================================================
   AERIS · MATHS PANEL — the equations behind the selected run, with the
   run's own numbers substituted. Fixed quantities come from the saved
   configuration, mass properties and controller design; time-varying ones
   from the saved sample at the playback time. Nothing here re-simulates.
   ===================================================================== */
var WSMaths = (function () {
  "use strict";
  var DEG = Math.PI / 180, RPM = Math.PI / 30;
  var tn = U.tn, T = U.texStr, esc = U.esc;
  function v3(v, n) { return "\\begin{pmatrix}" + v.map(function (x) { return tn(x, n || 4); }).join("\\\\ ") + "\\end{pmatrix}"; }
  function mm3(v) { return "(" + v.map(function (x) { return tn(x * 1000, 4); }).join(",\\,") + ")\\ \\text{mm}"; }
  function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
  function mv(M, v) { return [0, 1, 2].map(function (i) { return M[i][0] * v[0] + M[i][1] * v[1] + M[i][2] * v[2]; }); }
  function mtv(M, v) { return [0, 1, 2].map(function (i) { return M[0][i] * v[0] + M[1][i] * v[1] + M[2][i] * v[2]; }); }
  function unit(v) { var n = Math.hypot(v[0], v[1], v[2]); return n > 0 ? v.map(function (x) { return x / n; }) : [0, 0, 0]; }
  function quiet(title, text, live) { return '<article class="mx' + (live ? " live" : "") + ' mx-quiet"><header><span class="mx-k">' + (live ? "Time-varying · at t" : "Fixed for this run") + "</span><h4>" + esc(title) + '</h4></header><p class="mx-say">' + text + "</p></article>"; }
  /* v4: records from the research backend may use its extended model (full plant tensors, custom
     wheel sets, nonlinear / MIMO controllers). The cards read the backend's saved values and never
     present a different method than the one that ran. */
  function customPlant(c) { var pl = c.plant; return !!(pl && (pl.base_inertia_kgm2 || pl.base_com_m || (pl.components || []).length)); }
  function customWheels(c) { return !!(c.wheels && c.wheels.length); }
  function fromBackend(run) { return !!(run.origin && run.origin.engine === "aeris-research-backend"); }
  function isMimo(run) { return run.config.controller.structure === "mimo-lqr" || !!(run.design && run.design.mimo); }
  function execCtl(run) { return (run.executed && run.executed.controller) || null; }
  function integHz(run) { return (run.executed && run.executed.rates && run.executed.rates.integration_hz) || run.config.params.fs; }
  function row(sym, meaning, val, u) { return "<tr><td>" + T(sym) + "</td><td>" + esc(meaning) + "</td><td class=\"mono\">" + val + "</td><td class=\"mono u\">" + esc(u || "") + "</td></tr>"; }
  function card(o) {
    var h = '<article class="mx' + (o.live ? " live" : "") + '"><header><span class="mx-k">' + (o.live ? "Time-varying · at t" : "Fixed for this run") + "</span><h4>" + esc(o.title) + "</h4></header>";
    h += '<div class="mx-eq">' + T(o.eq, true) + "</div>";
    if (o.sub) h += '<div class="mx-sub"><span class="mx-lab">Substitute</span>' + T(o.sub, true) + "</div>";
    if (o.res) h += '<div class="mx-res"><span class="mx-lab">Result</span>' + T(o.res, true) + "</div>";
    if (o.say) h += '<p class="mx-say">' + o.say + "</p>";
    if (o.vars && o.vars.length) h += '<details class="mx-vars"><summary>Variables and units</summary><table><thead><tr><th>Symbol</th><th>Meaning</th><th>Value</th><th>Unit</th></tr></thead><tbody>' + o.vars.join("") + "</tbody></table></details>";
    if (o.ass) h += '<p class="mx-ass"><b>Assumption.</b> ' + o.ass + "</p>";
    return h + "</article>";
  }
  function fric(p, w) { return p.cv * w + p.cc * Math.tanh(w); }
  function sampleAt(run, i) { var c = run.samples.cols, o = {}; Object.keys(c).forEach(function (k) { o[k] = c[k][i]; }); return o; }
  function activeLoads(cfg, t) { return (cfg.disturbances || []).filter(function (L) { return t >= L.t_start_s && t < L.t_start_s + L.duration_s; }); }

  /* ---------------- fixed quantities ---------------- */
  function fixedCards(run) {
    var c = run.config, p = c.params, d = run.derived, z = run.design, edge = c.mode === "edge", out = [];
    var parts = d.parts, a = p.a, custom = customPlant(c);
    if (fromBackend(run)) out.push(quiet("Computed by the research backend", "This run was simulated by the Python research backend (" + esc((run.origin && run.origin.engine_version) || "aeris-research-backend") + "). Every value below is read from its saved record (mass properties, controller design, samples); nothing is recomputed with the browser's model." + (custom ? " It uses the backend's full plant model (base inertia tensor and components), so the inertia cards show the backend's tensor." : "") + (customWheels(c) ? " It uses a custom set of " + c.wheels.length + " wheels; the per-wheel equations are documented in docs/PHYSICS.md and the wheel cards below are omitted." : "")));
    // 1. mass and COM
    var sumM = parts.map(function (q) { return tn(q.mass, 3); }).join("+"), vars = [row("m_0", "Base cube mass (frame, wheels, electronics)", tn(d.m0, 4), "kg")];
    parts.slice(1).forEach(function (q, i) { vars.push(row("m_{" + (i + 1) + "}", q.label + (q.kind === "component" ? " (component; its own inertia tensor is included)" : " (point mass)"), tn(q.mass, 4), "kg")); vars.push(row("\\mathbf r_{" + (i + 1) + "}", q.label + " position from the pivot, body frame", q.pos.map(function (x) { return U.fx(x * 1000, 1); }).join(", "), "mm")); });
    vars.push(row("\\mathbf r_0", "Base cube centre of mass" + (c.comOffset_m ? " (geometric centre + " + U.fx(c.comOffset_m * 1000, 2) + " mm offset)" : " (geometric centre)"), d.r0.map(function (x) { return U.fx(x * 1000, 2); }).join(", "), "mm"));
    out.push(card({
      title: "Total mass and centre of mass", eq: "M=m_0+\\sum_i m_i,\\qquad \\mathbf r_c=\\frac{m_0\\,\\mathbf r_0+\\sum_i m_i\\,\\mathbf r_i}{M}",
      sub: "M=" + sumM + (parts.length > 1 ? "" : "\\ \\text{(no attachments)}"), res: "M=" + tn(d.M, 4) + "\\ \\text{kg},\\qquad \\mathbf r_c=" + mm3(d.rc),
      say: "The centre of mass is the mass-weighted average position of every part, measured from the pivot corner along the cube's own edges.", vars: vars,
      ass: custom ? "Research plant model: the base cube's inertia about its own centre of mass is " + (c.plant.base_inertia_kgm2 ? "the full tensor given in plant.base_inertia_kgm2" : "isotropic, k<sub>J</sub>·m<sub>0</sub>·a²") + (c.plant.base_com_m ? ", with its centre of mass at plant.base_com_m" : "") + "; each listed component adds its own inertia tensor plus the parallel-axis term, and attachments are point masses. The locked wheels are part of the base." : "Added masses are point masses: their own inertia about their centre is ignored. The base cube is a rigid body whose centre-of-mass inertia is isotropic, J<sub>c0</sub> = k<sub>J</sub>·m<sub>0</sub>·a² = " + U.sig(d.Jc0, 4) + " kg·m²; the wheels are part of it."
    }));
    if (edge) {
      var dn = d.rc[1] * Math.SQRT1_2 + d.rc[2] * Math.SQRT1_2, nn = -d.rc[1] * Math.SQRT1_2 + d.rc[2] * Math.SQRT1_2;
      out.push(card({
        title: "Lever arm and balance lean about the support edge", eq: "l=\\sqrt{y_c^2+z_c^2},\\qquad \\beta=\\operatorname{atan2}\\!\\big(\\mathbf r_c\\cdot\\hat{\\mathbf n},\\ \\mathbf r_c\\cdot\\hat{\\mathbf d}\\big)",
        sub: "l=\\sqrt{" + tn(d.rc[1], 4) + "^2+" + tn(d.rc[2], 4) + "^2},\\qquad \\beta=\\operatorname{atan2}(" + tn(nn, 4) + ",\\ " + tn(dn, 4) + ")",
        res: "l=" + tn(d.edge.l * 1000, 4) + "\\ \\text{mm},\\qquad \\beta=" + tn(d.edge.beta / DEG, 4) + "^\\circ",
        say: "The support edge runs along the body x axis through the pivot, so only the y and z coordinates of the centre of mass set its lever arm. β is how far the centre of mass sits off the edge's geometric balance line; the cube balances when it leans by −β (COM lean e = θ + β = 0).",
        vars: [row("\\hat{\\mathbf d}", "Balance line in the body frame, (0, 1, 1)/√2", "0, 0.7071, 0.7071", "–"), row("\\hat{\\mathbf n}", "In-plane normal to it, (0, −1, 1)/√2", "0, −0.7071, 0.7071", "–"), row("x_c", "Centre of mass along the edge (must lie between 0 and a)", U.fx(d.edge.xc * 1000, 2), "mm")],
        ass: "The edge is an ideal hinge: it never slips or lifts and carries every reaction force and torque except the one about its own axis."
      }));
      var terms = parts.map(function (q, i) { return tn(q.mass, 3) + "(" + tn(q.pos[1], 3) + "^2+" + tn(q.pos[2], 3) + "^2)"; });
      out.push(card({
        title: "Inertia about the support edge (parallel-axis theorem)", eq: custom ? "\\Theta_0=\\hat{\\mathbf x}^{\\mathsf T}\\,\\Theta_O\\,\\hat{\\mathbf x},\\qquad \\Theta_O=\\sum_k\\big(J_k+m_k\\,S(\\mathbf r_k)\\big),\\qquad \\hat\\Theta=s_J\\,\\Theta_0-J_w" : "\\Theta_0=J_{c0}+m_0\\,(y_0^2+z_0^2)+\\sum_i m_i\\,(y_i^2+z_i^2),\\qquad \\hat\\Theta=s_J\\,\\Theta_0-J_w",
        sub: custom ? "\\Theta_0=[\\Theta_O]_{xx}=" + tn(d.ThO[0][0], 5) : "\\Theta_0=" + tn(d.Jc0, 4) + "+" + terms.join("+"), res: "\\Theta_0=" + tn(d.edge.Th0, 5) + "\\ \\text{kg}\\cdot\\text{m}^2,\\qquad \\hat\\Theta=" + tn(z.plant.Thh, 5) + "\\ \\text{kg}\\cdot\\text{m}^2",
        say: "Each part adds its mass times the square of its distance from the edge. The wheel's own spin inertia J<sub>w</sub> is taken out because the motor drives the wheel relative to the body." + (c.uncertainty.inertiaScale !== 1 ? " This run multiplies the true inertia by s<sub>J</sub> = " + c.uncertainty.inertiaScale + " to test a model error; the controller does not know." : ""),
        vars: [row("J_{c0}", "Base cube inertia about its centre, k_J·m_0·a²", tn(d.Jc0, 4), "kg·m²"), row("J_w", "Wheel spin inertia", tn(p.Jw, 3), "kg·m²"), row("s_J", "Plant inertia scale (model-error test)", tn(c.uncertainty.inertiaScale, 3), "–")]
      }));
    } else {
      var ev = d.corner.eig;
      out.push(card({
        title: "Lever arm and balance axis about the pivot corner", eq: "l=\\lVert\\mathbf r_c\\rVert,\\qquad \\hat{\\mathbf u}=\\mathbf r_c/l,\\qquad \\beta=\\arccos(\\hat{\\mathbf u}\\cdot\\hat{\\mathbf c})",
        sub: "l=\\lVert" + mm3(d.rc) + "\\rVert", res: "l=" + tn(d.corner.l * 1000, 4) + "\\ \\text{mm},\\qquad \\hat{\\mathbf u}=" + U.rowT(d.corner.u, 4) + ",\\qquad \\beta=" + tn(d.corner.beta / DEG, 4) + "^\\circ",
        say: "The cube balances when û points straight up. With the bare cube û is the main diagonal ĉ = (1, 1, 1)/√3. At the balanced attitude the lowest of the three edges meeting at the pivot is " + U.fx(d.corner.edgeClear / DEG, 1) + "° above the floor.",
        ass: "The corner is an ideal point pivot: it never slips, rolls or lifts."
      }));
      out.push(card({
        title: "Inertia tensor about the pivot (parallel-axis theorem)", eq: (custom ? "\\Theta_O=\\sum_k\\big(J_k+m_k\\,S(\\mathbf r_k)\\big)" : "\\Theta_O=J_{c0}\\,I+m_0\\,S(\\mathbf r_0)+\\sum_i m_i\\,S(\\mathbf r_i)") + ",\\qquad S(\\mathbf r)=\\lVert\\mathbf r\\rVert^2 I-\\mathbf r\\mathbf r^{\\mathsf T}",
        sub: "\\Theta_O=" + U.matT(d.ThO, 4) + "\\ \\text{kg}\\cdot\\text{m}^2", res: "\\hat\\Theta_0=s_J\\,\\Theta_O-J_w I,\\qquad \\operatorname{eig}(\\Theta_O-J_wI)=\\{" + ev.map(function (x) { return tn(x, 4); }).join(",\\ ") + "\\}",
        say: "Off-diagonal terms appear as soon as a mass sits off the cube's symmetry lines. All eigenvalues must stay positive; the configuration check rejects runs where they do not.",
        vars: [row("J_{c0}", "Base cube inertia about its centre", tn(d.Jc0, 4), "kg·m²"), row("s_J", "Plant inertia scale", tn(c.uncertainty.inertiaScale, 3), "–")]
      }));
    }
    var mo = d.motor;
    out.push(card({
      title: "Actuator limits", eq: "k_t=\\frac{60}{2\\pi K_V},\\quad \\tau_{\\max}=s_\\tau\\,k_t I_{\\max},\\quad \\Omega_{nl}=\\frac{V_s}{k_e},\\quad h_{\\max}=J_w\\,\\Omega_{\\max}",
      sub: "k_t=\\frac{60}{2\\pi\\times" + tn(p.KV, 4) + "},\\quad \\tau_{\\max}=" + tn(c.torqueScale, 3) + "\\times" + tn(mo.kt, 4) + "\\times" + tn(p.Imax, 3) + ",\\quad \\Omega_{nl}=\\frac{" + tn(p.Vs, 3) + "}{" + tn(mo.ke, 4) + "}",
      res: "k_t=" + tn(mo.kt, 4) + "\\ \\tfrac{\\text{N}\\cdot\\text{m}}{\\text{A}},\\ \\ \\tau_{\\max}=" + tn(mo.taumaxRun, 4) + "\\ \\text{N}\\cdot\\text{m},\\ \\ \\Omega_{nl}=" + tn(mo.wnl / RPM, 4) + "\\ \\text{rpm},\\ \\ h_{\\max}=" + tn(mo.hmax, 4) + "\\ \\text{N}\\cdot\\text{m}\\cdot\\text{s}",
      say: "Torque follows current, so the driver's current limit caps it. The spinning motor's back-EMF also leaves less voltage for current as the wheel speeds up, and the firmware stops accelerating a wheel at Ω<sub>max</sub> = " + U.fx(mo.wmax / RPM, 0) + " rpm.",
      vars: [row("K_V", "Motor velocity constant", tn(p.KV, 4), "rpm/V"), row("I_{\\max}", "Driver current limit", tn(p.Imax, 3), "A"), row("V_s", "Supply voltage", tn(p.Vs, 3), "V"), row("R", "Phase resistance", tn(p.R, 3), "Ω"), row("s_\\tau", "Torque-limit scale for this run", tn(c.torqueScale, 3), "–")],
      ass: "Motor electrical dynamics are neglected: the driver delivers the commanded current within its limits."
    }));
    var lam = z.plant.lambda, l = edge ? d.edge.l : d.corner.l, x = mo.taumaxRun / (d.M * p.g * l), thmax = x >= 1 ? 90 : Math.asin(x) / DEG;
    out.push(card({
      title: "Why it needs control, and the hard limit", eq: "\\lambda=\\sqrt{\\frac{M g l}{\\hat\\Theta}},\\qquad \\theta_{\\max}=\\arcsin\\!\\Big(\\frac{\\tau_{\\max}}{M g l}\\Big)",
      sub: "\\lambda=\\sqrt{\\frac{" + tn(d.M, 4) + "\\times" + tn(p.g, 3) + "\\times" + tn(l, 4) + "}{" + tn(edge ? z.plant.Thh : d.M * p.g * l / (lam * lam), 4) + "}},\\qquad \\theta_{\\max}=\\arcsin\\!\\Big(\\frac{" + tn(mo.taumaxRun, 4) + "}{" + tn(d.M * p.g * l, 4) + "}\\Big)",
      res: "\\lambda=" + tn(lam, 4) + "\\ \\text{s}^{-1}\\ (1/\\lambda=" + tn(1 / lam, 3) + "\\ \\text{s}),\\qquad \\theta_{\\max}=" + tn(thmax, 4) + "^\\circ",
      say: "Without control a small lean grows roughly like e<sup>λt</sup>. And no controller can hold the centre of mass further than θ<sub>max</sub> from vertical for long, because gravity would then need more torque than the motors have." + (edge ? "" : " (Corner mode: λ uses the smallest eigenvalue of the effective inertia.)")
    }));
    if (z && c.controller.type !== "none" && c.controller.type === "nlpd") out.push(nlpdCard(run));
    else if (z && c.controller.type !== "none" && isMimo(run)) out.push(mimoCard(run));
    else if (z && c.controller.type !== "none" && !z.tilt) out.push(quiet("Controller design used in this run", "This record does not include a tilt-loop design block, so the design card cannot be shown."));
    else if (z && c.controller.type !== "none") {
      var tl = z.tilt, cl = tl.cl.filter(function (r) { return r[1] >= -1e-9; }).map(function (r) { return Math.abs(r[1]) > 1e-9 ? tn(r[0], 3) + "\\pm" + tn(Math.abs(r[1]), 3) + "j" : tn(r[0], 3); });
      var lawEq = c.controller.type === "pid" ? "T=K_p\\,e_\\theta+K_i\\!\\int\\! e_\\theta\\,dt+K_d\\,\\dot\\theta" : c.controller.type === "adp" ? "T=-K\\begin{bmatrix}\\theta-\\theta_{\\text{ref}}+\\hat\\beta\\\\ \\dot\\theta\\\\ \\Omega\\end{bmatrix},\\qquad \\dot{\\hat\\beta}=\\gamma\\,\\Omega" : "T=-K\\begin{bmatrix}\\theta-\\theta_{\\text{ref}}\\\\ \\dot\\theta\\\\ \\Omega\\end{bmatrix}";
      out.push(card({
        title: "Controller design used in this run", eq: lawEq + ",\\qquad K=R^{-1}B^{\\mathsf T}P",
        sub: "K=\\big[" + tl.K.map(function (k) { return tn(k, 4); }).join(",\\ ") + "\\big],\\quad K_p=" + tn(tl.pid.Kp, 4) + ",\\ K_i=" + tn(tl.pid.Ki, 4) + ",\\ K_d=" + tn(tl.pid.Kd, 4),
        res: "\\operatorname{eig}(A-BK)=\\{" + cl.join(",\\ ") + "\\}\\ \\text{s}^{-1}" + (edge ? ",\\qquad \\theta_{\\text{ref}}=" + tn(-(z.betaRef || 0) / DEG, 4) + "^\\circ" : ""),
        say: (z.model === "actual" ? "Designed for the run's true mass properties (the controller was told about the attached masses), aiming at the true balance attitude." : "Designed for the bare, nominal cube; it is not told about added masses or offsets.") + (c.controller.type === "pid" ? " PID sees only the tilt, never the wheel speed." : "") + (c.controller.type === "adp" ? " The adaptive loop adds a slow estimate β̂ of the balance offset, learned from the wheel speed (γ = " + tn(tl.gam, 2) + ")." : ""),
        ass: "Gains come from LQR on the linearised model (PID by pole placement on the same poles). The loop runs at " + p.fs + " Hz with the command held between updates."
      }));
    }
    return out.join("");
  }

  function nlpdCard(run) {
    var c = run.config, z = run.design, edge = c.mode === "edge", xc = execCtl(run) || {}, g = xc.gains, mm = z.model_mass || {};
    return card({
      title: "Controller used in this run: nonlinear model-compensated PD", eq: edge
        ? "T=m g l_m\\sin(\\hat\\theta+\\beta_m)-\\hat\\Theta_m\\big(-k_p(\\hat\\theta+\\beta_m-\\delta)-k_d\\dot{\\hat\\theta}\\big)+\\tau_{\\text{fric},m}(\\Omega),\\qquad \\delta=-\\big(k_1h+k_2\\!\\int\\! h\\,dt\\big)"
        : "\\mathbf u=M\\,\\mathbf r_c\\times\\hat{\\mathbf g}_B-\\hat{\\boldsymbol\\omega}\\times\\mathbf H-\\hat\\Theta_m\\boldsymbol\\alpha_d,\\qquad \\boldsymbol\\alpha_d=-K_p\\boldsymbol\\varphi_e-K_d\\hat{\\boldsymbol\\omega},\\qquad \\boldsymbol\\delta=-\\big(k_1\\mathbf h_\\perp+k_2\\!\\int\\!\\mathbf h_\\perp dt\\big)",
      sub: g ? "k_p=" + tn(g.kp_tilt_per_s2, 4) + ",\\ k_d=" + tn(g.kd_tilt_per_s, 4) + (edge ? "" : ",\\ k_{p,\\psi}=" + tn(g.kp_yaw_per_s2, 4) + ",\\ k_{d,\\psi}=" + tn(g.kd_yaw_per_s, 4)) + ",\\ k_1=" + tn(g.k1_momentum_rad_per_Nms, 4) + ",\\ k_2=" + tn(g.k2_momentum_rad_per_Nms2, 4) : undefined,
      res: g ? "\\lvert\\delta\\rvert\\le" + tn(g.max_ref_tilt_deg, 3) + "^\\circ" : undefined,
      say: "This is not LQR and has no linear gain matrix. The law, as saved with the run: " + esc(xc.law || "(not recorded)") + ". The model terms use " + esc(mm.source || "the controller's model") + ". The slow momentum loop tilts the reference by δ so that gravity drains the stored wheel momentum.",
      ass: "Stability rationale and limitations: docs/CONTROLLERS.md. With exact model knowledge the error dynamics reduce to α = α<sub>d</sub>; model errors, torque limits and estimator errors break that, which the simulation shows rather than assumes."
    });
  }
  function mimoCard(run) {
    var z = run.design, m = z.mimo || {}, K = m.K || [], xc = execCtl(run) || {};
    var cl = (m.cl || []).filter(function (r) { return r[1] >= -1e-9; }).map(function (r) { return Math.abs(r[1]) > 1e-9 ? tn(r[0], 3) + "\\pm" + tn(Math.abs(r[1]), 3) + "j" : tn(r[0], 3); });
    return card({
      title: "Controller used in this run: coupled MIMO LQR", eq: "\\mathbf T=-K\\begin{bmatrix}\\boldsymbol\\varphi\\\\ \\hat{\\boldsymbol\\omega}\\\\ \\boldsymbol\\Omega\\end{bmatrix},\\qquad K=K_c V_c^{\\mathsf T},\\quad K_c=R^{-1}B_c^{\\mathsf T}P_c",
      sub: K.length ? "K\\in\\mathbb R^{" + K.length + "\\times" + (K[0] || []).length + "},\\qquad \\operatorname{rank}\\mathcal C=" + m.controllable_rank + "\\ \\text{of}\\ " + m.state_dim : undefined,
      res: cl.length ? "\\operatorname{eig}(A_c-B_cK_c)=\\{" + cl.join(",\\ ") + "\\}\\ \\text{s}^{-1}" : undefined,
      say: "One gain matrix designed on the full-tensor linearisation about the upright operating point, coupling all axes (not three scalar loops). The vertical angular momentum is conserved (gravity has no moment about the vertical), so one state direction is uncontrollable; the Riccati design runs on the controllable subspace V<sub>c</sub>. Law saved with the run: " + esc(xc.law || "(not recorded)") + ".",
      ass: "Riccati residual " + (m.riccati_residual != null ? U.sig(m.riccati_residual, 2) : "—") + ". A, B, Q, R, K and the operating point are saved in design.mimo for reproduction."
    });
  }

  /* ---------------- time-varying quantities ---------------- */
  function liveCards(run, idx) {
    var c = run.config, p = c.params, d = run.derived, z = run.design, edge = c.mode === "edge", s = sampleAt(run, idx), t = s.t, out = [];
    var tag = "t=" + tn(t, 4) + "\\ \\text{s}";
    if (edge) {
      out.push(card({
        live: true, title: "Gravity torque", eq: "\\tau_g=M\\,g\\,l\\,\\sin e,\\qquad e=\\theta+\\beta",
        sub: "e=" + tn(s.theta / DEG, 4) + "^\\circ+" + tn(d.edge.beta / DEG, 4) + "^\\circ=" + tn(s.e / DEG, 4) + "^\\circ,\\quad \\tau_g=" + tn(d.M, 4) + "\\times" + tn(p.g, 3) + "\\times" + tn(d.edge.l, 4) + "\\times\\sin(" + tn(s.e / DEG, 4) + "^\\circ)",
        res: "\\tau_g(" + tag + ")=" + tn(s.tauG, 4) + "\\ \\text{N}\\cdot\\text{m}", say: "Positive τ<sub>g</sub> pushes the lean further in the positive direction. It vanishes only with the centre of mass straight above the edge.",
        vars: [row("\\theta", "Body tilt from the geometric attitude", tn(s.theta / DEG, 4), "°"), row("e", "Centre-of-mass lean from vertical", tn(s.e / DEG, 4), "°")]
      }));
      var al = activeLoads(c, t), R = rotX(Math.PI / 4 + s.theta);
      if (al.length) {
        var parts = al.map(function (L) {
          var dir = unit(L.direction);
          if (L.type === "torque") { var tb = L.frame === "world" ? mtv(R, dir.map(function (x) { return x * L.magnitude_Nm; })) : dir.map(function (x) { return x * L.magnitude_Nm; }); return { L: L, tau: tb, tex: "\\tau_{" + L.id + "}=" + tn(tb[0], 4) + "\\ (\\text{pure torque, " + L.frame + " frame})" }; }
          var Fb = L.frame === "world" ? mtv(R, dir.map(function (x) { return x * L.magnitude_N; })) : dir.map(function (x) { return x * L.magnitude_N; }), tq = cross(L.point_m, Fb);
          return { L: L, tau: tq, tex: "\\big(\\mathbf r\\times\\mathbf F_B\\big)_x=" + U.rowT(L.point_m, 4) + "\\times" + U.rowT(Fb, 4) + "\\big|_x=" + tn(tq[0], 4) };
        });
        out.push(card({
          live: true, title: "Applied-load torque about the edge", eq: "\\tau_F=\\sum_j\\big(\\mathbf r_j\\times\\mathbf F_{B,j}\\big)\\cdot\\hat{\\mathbf x},\\qquad \\mathbf F_B=R^{\\mathsf T}\\mathbf F_N\\ \\text{(world-frame loads)}",
          sub: parts.map(function (q) { return q.tex; }).join(",\\quad "), res: "\\tau_F(" + tag + ")=" + tn(s.tauF, 4) + "\\ \\text{N}\\cdot\\text{m}",
          say: "Forces act at their application point, measured from the pivot in the body frame. A world-frame force keeps its direction in the room, so it is rotated into the body frame at every step; a body-frame force turns with the cube. Only the component about the support edge moves the cube.",
          vars: al.map(function (L) { return row(L.id, (L.type === "force" ? "Force " + L.magnitude_N + " N, " : "Torque " + L.magnitude_Nm + " N·m, ") + L.frame + " frame, " + L.t_start_s + "–" + (L.t_start_s + L.duration_s) + " s", L.type === "force" ? L.point_m.map(function (x) { return U.fx(x * 1000, 0); }).join(", ") + " mm" : "—", "") })
        }));
      } else out.push('<article class="mx live mx-quiet"><header><span class="mx-k">Time-varying · at t</span><h4>Applied-load torque</h4></header><p class="mx-say">No load acts at t = ' + U.fx(t, 2) + " s" + ((c.disturbances || []).length ? " (" + c.disturbances.length + " scheduled in this run)." : ".") + "</p></article>");
      if (customWheels(c)) {
        out.push(quiet("Wheels, controller output and dynamics", "This run used a custom set of " + c.wheels.length + " wheels (" + c.wheels.map(function (w) { return esc(w.id); }).join(", ") + "). The per-wheel equations are in docs/PHYSICS.md; the recorded per-wheel speeds and torques are in the samples and charts.", true));
        return out.join("");
      }
      var h = p.Jw * s.omega_x;
      out.push(card({
        live: true, title: "Wheel momentum", eq: "h=J_w\\,\\Omega", sub: "h=" + tn(p.Jw, 3) + "\\times" + tn(s.omega_x, 4) + "\\ \\text{rad/s}\\ (" + tn(s.omega_x / RPM, 4) + "\\ \\text{rpm})",
        res: "h=" + tn(h, 4) + "\\ \\text{N}\\cdot\\text{m}\\cdot\\text{s}=" + tn(Math.abs(h) / d.motor.hmax * 100, 3) + "\\%\\ \\text{of}\\ h_{\\max}", say: "Momentum the wheel has taken out of the body. It stays in the wheel until the controller leans the cube so that gravity takes it back out."
      }));
      var same = s.T_x * s.omega_x > 0, lim = same ? Math.max(0, d.motor.kt * (d.motor.Vs - d.motor.ke * Math.abs(s.omega_x)) / d.motor.R) : Infinity, avail = Math.min(d.motor.taumaxRun, lim), atSpd = Math.abs(s.omega_x) >= d.motor.wmax;
      out.push(card({
        live: true, title: "Actuator limit at this wheel speed", eq: "\\lvert T\\rvert\\le\\begin{cases}\\min\\!\\big(\\tau_{\\max},\\ k_t\\,\\frac{V_s-k_e\\lvert\\Omega\\rvert}{R}\\big) & T\\,\\Omega\\gt0\\\\ \\tau_{\\max} & \\text{otherwise}\\end{cases}",
        sub: same ? "\\min\\!\\big(" + tn(d.motor.taumaxRun, 4) + ",\\ " + tn(d.motor.kt, 4) + "\\times\\frac{" + tn(d.motor.Vs, 3) + "-" + tn(d.motor.ke, 4) + "\\times" + tn(Math.abs(s.omega_x), 4) + "}{" + tn(d.motor.R, 3) + "}\\big)" : "T\\,\\Omega\\le0:\\ \\text{braking, only the current limit applies}",
        res: "T_{\\text{avail}}=" + (atSpd && same ? "0\\ (\\text{at the speed limit})" : tn(avail, 4)) + "\\ \\text{N}\\cdot\\text{m};\\quad T_{\\text{cmd}}=" + tn(s.Tc_x, 4) + ",\\ T=" + tn(s.T_x, 4) + "\\ \\text{N}\\cdot\\text{m}",
        say: s.sat ? "The command exceeds what the motor can deliver here, so it is clipped. While clipped, the controller is not getting the torque it asked for." : "The command is within the limit, so the motor delivers it."
      }));
      if (z && c.controller.type === "nlpd") {
        var xg = (execCtl(run) || {}).gains;
        out.push(card({
          live: true, title: "Controller output (nonlinear model-compensated PD)", eq: "T=m g l_m\\sin(\\hat\\theta+\\beta_m)-\\hat\\Theta_m\\big(-k_p(\\hat\\theta+\\beta_m-\\delta)-k_d\\dot{\\hat\\theta}\\big)+\\tau_{\\text{fric},m}(\\Omega)",
          sub: s.ref_tilt != null ? "\\hat\\theta=" + tn(s.thetahat / DEG, 4) + "^\\circ,\\quad \\delta=" + tn(s.ref_tilt / DEG, 4) + "^\\circ" : undefined,
          res: "T_{\\text{cmd}}(" + tag + ")=" + tn(s.Tc_x, 4) + "\\ \\text{N}\\cdot\\text{m}\\ \\text{(recorded)}",
          say: "The momentum loop's reference tilt δ is recorded with the run; the integral ∫h dt is internal, so the recorded command is shown rather than recomputed." + (xg ? " Gains: k<sub>p</sub> = " + U.sig(xg.kp_tilt_per_s2, 4) + " s⁻², k<sub>d</sub> = " + U.sig(xg.kd_tilt_per_s, 4) + " s⁻¹." : ""),
          ass: "Not an LQR: no linear state-feedback gain is used."
        }));
      } else if (z && c.controller.type !== "none" && z.tilt) {
        var K = z.tilt.K, ref = z.betaRef || 0, pid = z.tilt.pid, ideal = c.estimator.type === "ideal", thm = s.thetahat, sub, res2, say;
        if (c.controller.type === "pid") {
          var ee = thm + ref, integ = (s.Tc_x - pid.Kp * ee - pid.Kd * s.thetadot) / pid.Ki;
          sub = "T=" + tn(pid.Kp, 4) + "\\times" + tn(ee, 4) + "+" + tn(pid.Ki, 4) + "\\times" + tn(integ, 4) + "+" + tn(pid.Kd, 4) + "\\times" + tn(s.thetadot, 4);
          say = "The integral ∫e dt = " + U.sig(integ, 3) + " rad·s is not stored separately; it is recovered here from the recorded command. PID drives the tilt error to zero but ignores the wheel speed.";
        } else {
          var bh = c.controller.type === "adp" ? s.betahat : 0, x1 = thm + ref + bh;
          sub = "T=-\\big[" + K.map(function (k) { return tn(k, 4); }).join(",\\ ") + "\\big]\\cdot\\big[" + tn(x1, 4) + ",\\ " + tn(s.thetadot, 4) + ",\\ " + tn(s.omega_x, 4) + "\\big]^{\\mathsf T}";
          say = (c.controller.type === "adp" ? "β̂ = " + U.fx(s.betahat / DEG, 4) + "° is the current estimate of the balance offset. " : "") + "The wheel-speed term lets the controller lean the cube to drain stored momentum.";
        }
        if (!ideal) say += " The controller sees the " + c.estimator.type.toUpperCase() + " tilt estimate θ̂ = " + U.fx(thm / DEG, 4) + "° and the measured gyro rate (not stored), so the substitution uses θ̂ and the true rate.";
        out.push(card({
          live: true, title: "Controller output", eq: c.controller.type === "pid" ? "T=K_p\\,e_\\theta+K_i\\!\\int\\! e_\\theta\\,dt+K_d\\,\\dot\\theta,\\qquad e_\\theta=\\hat\\theta-\\theta_{\\text{ref}}" : "T=-K\\begin{bmatrix}\\hat\\theta-\\theta_{\\text{ref}}" + (c.controller.type === "adp" ? "+\\hat\\beta" : "") + "\\\\ \\dot\\theta\\\\ \\Omega\\end{bmatrix}",
          sub: sub, res: "T_{\\text{cmd}}(" + tag + ")=" + tn(s.Tc_x, 4) + "\\ \\text{N}\\cdot\\text{m}\\ \\text{(recorded)}", say: say,
          ass: "The command is computed from the state at t and held for one control period (" + U.fx(1000 / p.fs, 1) + " ms)."
        }));
      }
      var Tn = s.T_x - fric(p, s.omega_x), acc = (s.tauG + s.tauF - Tn) / z.plant.Thh;
      out.push(card({
        live: true, title: "Balancing dynamics", eq: "\\hat\\Theta\\,\\ddot\\theta=\\tau_g+\\tau_F-\\big(T-\\tau_{\\text{fric}}(\\Omega)\\big),\\qquad \\tau_{\\text{fric}}=c_v\\Omega+c_c\\tanh\\Omega",
        sub: tn(z.plant.Thh, 4) + "\\,\\ddot\\theta=" + tn(s.tauG, 4) + "+" + tn(s.tauF, 4) + "-(" + tn(s.T_x, 4) + "-" + tn(fric(p, s.omega_x), 3) + ")",
        res: "\\ddot\\theta(" + tag + ")=" + tn(acc, 4) + "\\ \\text{rad/s}^2,\\qquad \\dot\\Omega=\\frac{T-\\tau_{\\text{fric}}}{J_w}-\\ddot\\theta=" + tn(Tn / p.Jw - acc, 4) + "\\ \\text{rad/s}^2",
        say: "Newton's law for rotation about the edge. Speeding the wheel up with torque T pushes the body the other way; gravity and applied loads add their own torques. The same equation, integrated with RK4 at " + integHz(run) + " Hz, produced this run.",
        ass: "Rigid bodies, ideal hinge, wheels balanced and aligned with the body axes."
      }));
    } else {
      var q = [s.q0, s.q1, s.q2, s.q3], Rq = qrot(q), gB = mtv(Rq, [0, 0, -p.g]), tg = [s.tauG_x, s.tauG_y, s.tauG_z], tf = [s.tauF_x, s.tauF_y, s.tauF_z], Om = [s.omega_x, s.omega_y, s.omega_z], w = [s.wx, s.wy, s.wz], Tm = [s.T_x, s.T_y, s.T_z], Tcm = [s.Tc_x, s.Tc_y, s.Tc_z];
      out.push(card({
        live: true, title: "Gravity torque about the pivot", eq: "\\boldsymbol\\tau_g=M\\,\\mathbf r_c\\times\\mathbf g_B,\\qquad \\mathbf g_B=R^{\\mathsf T}(0,0,-g)^{\\mathsf T}",
        sub: tn(d.M, 4) + "\\times" + v3(d.rc, 4) + "\\times" + v3(gB, 4), res: "\\boldsymbol\\tau_g(" + tag + ")=" + v3(tg, 4) + "\\ \\text{N}\\cdot\\text{m},\\qquad e=" + tn(s.e / DEG, 4) + "^\\circ",
        say: "Gravity in the body frame changes as the cube turns; the torque is zero only with the centre of mass straight above the corner (e = 0)."
      }));
      var al2 = activeLoads(c, t);
      out.push(al2.length ? card({
        live: true, title: "Applied-load torque", eq: "\\boldsymbol\\tau_F=\\sum_j\\mathbf r_j\\times\\mathbf F_{B,j},\\qquad \\mathbf F_B=R^{\\mathsf T}\\mathbf F_N\\ \\text{(world-frame loads)}",
        sub: al2.map(function (L) { return L.id + ":\\ " + (L.type === "force" ? U.rowT(L.point_m, 4) + "\\times\\mathbf F_B" : "\\text{pure torque}"); }).join(",\\quad "), res: "\\boldsymbol\\tau_F(" + tag + ")=" + v3(tf, 4) + "\\ \\text{N}\\cdot\\text{m}",
        say: "World-frame loads keep their direction in the room; body-frame loads turn with the cube."
      }) : '<article class="mx live mx-quiet"><header><span class="mx-k">Time-varying · at t</span><h4>Applied-load torque</h4></header><p class="mx-say">No load acts at t = ' + U.fx(t, 2) + " s.</p></article>");
      if (customWheels(c)) {
        out.push(quiet("Wheels, controller output and dynamics", "This run used a custom set of " + c.wheels.length + " wheels (" + c.wheels.map(function (w) { return esc(w.id); }).join(", ") + "). The per-wheel form of Euler's equation, Θ̂ω̇ = −ω×(Θ<sub>O</sub>ω + Σ J<sub>i</sub>Ω<sub>i</sub>a<sub>i</sub>) + τ<sub>g</sub> + τ<sub>F</sub> − Σ(T<sub>i</sub> − f<sub>i</sub>)a<sub>i</sub>, is documented in docs/PHYSICS.md; the per-wheel samples are in the charts.", true));
        return out.join("");
      }
      out.push(card({
        live: true, title: "Wheel momenta", eq: "\\mathbf h=J_w\\,\\boldsymbol\\Omega", sub: tn(p.Jw, 3) + "\\times" + v3(Om, 4) + "\\ \\text{rad/s}",
        res: "\\mathbf h=" + v3(Om.map(function (x) { return x * p.Jw; }), 4) + "\\ \\text{N}\\cdot\\text{m}\\cdot\\text{s}\\quad(\\max\\ " + tn(d.motor.hmax, 3) + ")", say: "One wheel per body axis. Momentum stored along the balance axis cannot be removed by leaning; the yaw loop keeps it in check."
      }));
      if (c.controller.type === "nlpd" || isMimo(run)) {
        var nl = c.controller.type === "nlpd", uq = s.u_x != null ? [s.u_x, s.u_y, s.u_z] : null, rt = s.ref_tilt_x != null ? [s.ref_tilt_x, s.ref_tilt_y, s.ref_tilt_z] : null;
        out.push(card({
          live: true, title: "Controller output and actuator limits (" + (nl ? "nonlinear model-compensated PD" : "coupled MIMO LQR") + ")",
          eq: (nl ? "\\mathbf u=M\\,\\mathbf r_c\\times\\hat{\\mathbf g}_B-\\hat{\\boldsymbol\\omega}\\times\\mathbf H-\\hat\\Theta_m\\boldsymbol\\alpha_d" : "\\mathbf T_{\\text{cmd}}=-K\\begin{bmatrix}\\boldsymbol\\varphi\\\\ \\hat{\\boldsymbol\\omega}\\\\ \\boldsymbol\\Omega\\end{bmatrix}") + ",\\qquad \\lvert T_i\\rvert\\le\\tau_{\\text{avail}}(\\Omega_i)",
          sub: (uq ? "\\mathbf u_{\\text{req}}=" + v3(uq, 4) + ",\\quad " : "") + "\\mathbf T_{\\text{cmd}}=" + v3(Tcm, 4) + (rt ? ",\\quad \\boldsymbol\\delta=" + v3(rt.map(function (x) { return x / DEG; }), 3) + "^\\circ" : ""),
          res: "\\mathbf T=" + v3(Tm, 4) + "\\ \\text{N}\\cdot\\text{m}" + (s.sat ? "\\ \\text{(clipped)}" : ""),
          say: nl ? "The requested body torque u is allocated to the wheels within their limits; δ is the reference tilt set by the momentum loop. Values are the recorded ones." : "One coupled gain matrix acts on the attitude error, body rates and wheel speeds; the command is recorded, then clipped to each wheel's available torque."
        }));
      } else out.push(card({
        live: true, title: "Controller output and actuator limits", eq: "\\mathbf T_{\\text{cmd}}=P\\big(-K_1\\boldsymbol\\theta_t-K_2\\boldsymbol\\omega-K_3\\boldsymbol\\Omega\\big)+\\hat{\\mathbf u}\\,T_\\psi,\\qquad \\lvert T_i\\rvert\\le\\tau_{\\text{avail}}(\\Omega_i)",
        sub: "\\mathbf T_{\\text{cmd}}=" + v3(Tcm, 4), res: "\\mathbf T=" + v3(Tm, 4) + "\\ \\text{N}\\cdot\\text{m}" + (s.sat ? "\\ \\text{(clipped)}" : ""),
        say: "P removes the component along the balance axis û, which the tilt loop cannot use; T<sub>ψ</sub> is the yaw loop. " + ((run.events && run.events.failedWheels || []).length ? "After a wheel failure the tilt torque is reallocated to the healthy wheels (least squares)." : "")
      }));
      var L = mv(z.plant.Th0, w).map(function (x, i) { return x + p.Jw * Om[i]; }), gyro = cross(w, L).map(function (x) { return -x; }), Tn2 = Tm.map(function (x, i) { return x - fric(p, Om[i]); });
      var rhs = [0, 1, 2].map(function (i) { return gyro[i] + tg[i] + tf[i] - Tn2[i]; }), wd = solve3(z.plant.Thh, rhs);
      out.push(card({
        live: true, title: "Balancing dynamics (Euler's equation about the pivot)", eq: "\\hat\\Theta_0\\,\\dot{\\boldsymbol\\omega}=-\\boldsymbol\\omega\\times\\big(\\Theta_0\\boldsymbol\\omega+J_w\\boldsymbol\\Omega\\big)+\\boldsymbol\\tau_g+\\boldsymbol\\tau_F-\\big(\\mathbf T-\\boldsymbol\\tau_{\\text{fric}}\\big)",
        sub: "-\\boldsymbol\\omega\\times(\\dots)=" + v3(gyro, 3) + ",\\quad \\boldsymbol\\omega=" + v3(w, 4), res: "\\dot{\\boldsymbol\\omega}(" + tag + ")=" + v3(wd, 4) + "\\ \\text{rad/s}^2",
        say: "The gyroscopic term comes from the spinning body and wheels. The attitude follows from q̇ = ½ q ⊗ (0, ω), integrated with RK4 at " + integHz(run) + " Hz.", ass: "Rigid bodies, ideal point pivot, wheels balanced and aligned with the body axes."
      }));
    }
    return out.join("");
  }
  function rotX(a) { var c = Math.cos(a), s = Math.sin(a); return [[1, 0, 0], [0, c, -s], [0, s, c]]; }
  function qrot(q) { var a = q[0], b = q[1], c = q[2], d = q[3]; return [[1 - 2 * (c * c + d * d), 2 * (b * c - a * d), 2 * (b * d + a * c)], [2 * (b * c + a * d), 1 - 2 * (b * b + d * d), 2 * (c * d - a * b)], [2 * (b * d - a * c), 2 * (c * d + a * b), 1 - 2 * (b * b + c * c)]]; }
  function solve3(A, b) {
    var m = A.map(function (r, i) { return r.concat([b[i]]); });
    for (var c = 0; c < 3; c++) { var p = c; for (var r = c + 1; r < 3; r++) if (Math.abs(m[r][c]) > Math.abs(m[p][c])) p = r; var tmp = m[c]; m[c] = m[p]; m[p] = tmp; for (r = 0; r < 3; r++) if (r !== c) { var f = m[r][c] / m[c][c]; for (var k = c; k < 4; k++) m[r][k] -= f * m[c][k]; } }
    return [m[0][3] / m[0][0], m[1][3] / m[1][1], m[2][3] / m[2][2]];
  }

  function render(host, run, idx) {
    if (!run || !run.samples) { host.innerHTML = '<p class="ws-empty">Open or create a run to see its calculations. The equations are always evaluated with the selected run\'s saved parameters and samples.</p>'; return; }
    host.innerHTML = '<div class="mx-intro"><p>Every number below comes from <b>' + esc(run.name) + '</b>: fixed quantities from its saved setup, time-varying ones from the sample at the playback time. Nominal parameters, not hardware measurements.</p></div>' +
      '<section class="mx-group"><h3 class="mx-gh">Setup quantities <span>fixed for the whole run</span></h3>' + fixedCards(run) + "</section>" +
      '<section class="mx-group"><h3 class="mx-gh">At <span class="mono" id="mxT">t = ' + U.fx(run.samples.cols.t[idx], 3) + ' s</span> <span>changes with the playback time</span></h3><div id="mxLive">' + liveCards(run, idx) + "</div></section>";
    host._run = run.id;
  }
  function update(host, run, idx) {
    if (!run || host._run !== run.id) return render(host, run, idx);
    var live = host.querySelector("#mxLive"), tt = host.querySelector("#mxT");
    if (live) live.innerHTML = liveCards(run, idx);
    if (tt) tt.textContent = "t = " + U.fx(run.samples.cols.t[idx], 3) + " s";
    host._idx = idx;
  }
  return { render: render, update: update, fixedCards: fixedCards, liveCards: liveCards };
})();

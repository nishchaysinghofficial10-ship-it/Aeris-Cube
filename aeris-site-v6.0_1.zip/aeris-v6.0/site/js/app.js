/* =====================================================================
   APP — routing between the AERIS views, navigation, hero video, lightbox,
   copy buttons and the system status strip.

   Views and routes
     #top (home)                 project story
     #cube[-…]                   AERIS Cube: the physical hardware
     #twin[-…]                   AERIS Twin: the physics-based digital model
     #lab[/replay|/create|/sweep] AERIS Lab: experiments (single runs and research sweeps)
     #research[-…]  #results[-…]  #validation[-…]
     #build[-…]                  Build Your Own Cube (optional): the reference build, parts, steps
     #connect[/…]                Connect My Cube (optional): a device, the synthetic device, a backend
   Old links keep working: #use… → #lab…, #lab-… (old physics page) → #twin-…,
   #hardware → #cube.
   ===================================================================== */
var App = (function () {
  "use strict";
  var $ = U.$, views = {};
  var TITLES = { home: "AERIS · Reaction-wheel attitude-control platform", cube: "AERIS Cube · hardware", twin: "AERIS Twin · physics-based digital model", lab: "AERIS Lab · experiments", research: "Research · AERIS", results: "Results · AERIS", validation: "Validation · AERIS", build: "Build Your Own Cube · AERIS", connect: "Connect My Cube · AERIS" };
  var PAGES = ["cube", "twin", "lab", "research", "results", "validation", "build", "connect"];
  /* old routes → current routes */
  function canonical(h) {
    if (h === "use") return "lab";
    if (h.indexOf("use/") === 0) return "lab/" + h.slice(4);
    if (h.indexOf("lab-") === 0) return "twin-" + h.slice(4);
    if (h === "hardware") return "cube";
    return h;
  }
  function viewFor(h) {
    for (var i = 0; i < PAGES.length; i++) { var p = PAGES[i]; if (h === p || h.indexOf(p + "-") === 0 || h.indexOf(p + "/") === 0) return p; }
    return "home";
  }
  var current = null;
  function route() {
    var raw = decodeURIComponent((location.hash || "").slice(1)), h = canonical(raw), prev = current;
    if (h !== raw) { try { history.replaceState(null, "", "#" + h); } catch (e) { /* file:// in some browsers */ } }
    var v = h === "contact" && current ? current : viewFor(h);
    Object.keys(views).forEach(function (k) { if (views[k]) views[k].hidden = k !== v; });
    current = v;
    document.body.setAttribute("data-view", v);
    document.body.classList.remove("menu-open"); var bg = $("burger"); if (bg) bg.setAttribute("aria-expanded", "false");
    [].forEach.call(document.querySelectorAll(".nav-links a, .overlay a"), function (a) {
      var href = (a.getAttribute("href") || "").slice(1), on = href === v || (v === "home" && href === "top");
      a.classList.toggle("is-on", on); if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });
    document.title = TITLES[v];
    if (v === "twin") TwinPage.show();
    if (v === "lab") Workspace.show(h.indexOf("lab/") === 0 ? h.slice(4) : null);
    if (window.Pages && Pages.show) Pages.show(v, h);
    if (v === "build" && window.BuildPage) BuildPage.show(h);
    if (v === "connect" && window.ConnectPage) ConnectPage.show(h);
    if (window.AERIS_STATUS) AERIS_STATUS.setView(v);
    var anchored = h && h !== v && h !== "top" && h.indexOf("/") < 0;
    var target = anchored ? $(h) : h === "contact" ? $("contact") : null;
    if (target) requestAnimationFrame(function () { requestAnimationFrame(function () { target.scrollIntoView({ block: "start" }); }); });
    else if (prev !== v || h === "top" || PAGES.indexOf(h) >= 0 || !h) window.scrollTo(0, 0);
    if (v === "home" && prev && prev !== "home") Home.redraw();
    var main = views[v]; if (main && prev && prev !== v) { main.setAttribute("tabindex", "-1"); try { main.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
  }
  function initNav() {
    var b = $("burger"); if (!b) return;
    b.addEventListener("click", function () {
      var open = !document.body.classList.contains("menu-open");
      document.body.classList.toggle("menu-open", open); b.setAttribute("aria-expanded", open ? "true" : "false"); b.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      if (open) { var f = document.querySelector(".overlay a"); if (f) f.focus(); }
    });
    [].forEach.call(document.querySelectorAll(".overlay a"), function (a) { a.addEventListener("click", function () { document.body.classList.remove("menu-open"); b.setAttribute("aria-expanded", "false"); }); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") { if (document.body.classList.contains("menu-open")) { document.body.classList.remove("menu-open"); b.setAttribute("aria-expanded", "false"); b.focus(); } closeLightbox(); } });
  }
  function initVideo() {
    var v = $("heroVid"), tg = $("vidToggle"); if (!v || !tg) return;
    var RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches, user = RM;
    var PAUSE = '<svg viewBox="0 0 12 12" aria-hidden="true"><rect x="2" y="1.5" width="2.6" height="9"/><rect x="7.4" y="1.5" width="2.6" height="9"/></svg>', PLAY = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5 L10.5 6 L3 10.5 Z"/></svg>';
    function ui() { var on = !v.paused; tg.innerHTML = on ? PAUSE : PLAY; tg.setAttribute("aria-label", on ? "Pause the assembly video" : "Play the assembly video"); }
    function play() { var pr = v.play(); if (pr && pr.catch) pr.catch(function () { ui(); }); }
    v.addEventListener("play", ui); v.addEventListener("pause", ui);
    tg.addEventListener("click", function () { if (v.paused) { user = false; play(); } else { user = true; v.pause(); } });
    if ("IntersectionObserver" in window) new IntersectionObserver(function (es) { if (es[0].isIntersecting) { if (!user) play(); } else v.pause(); }, { threshold: 0.2 }).observe(v);
    else if (!user) play();
    ui();
  }
  var lb = null, lbFrom = null;
  function closeLightbox() { if (lb) { lb.remove(); lb = null; if (lbFrom) lbFrom.focus(); } }
  function initLightbox() {
    [].forEach.call(document.querySelectorAll("[data-lightbox]"), function (f) {
      function open() {
        lbFrom = f; lb = document.createElement("div"); lb.className = "lightbox"; lb.setAttribute("role", "dialog"); lb.setAttribute("aria-label", "Image enlarged. Press Escape to close."); lb.tabIndex = -1;
        var im = document.createElement("img"); im.src = f.getAttribute("data-lightbox"); im.alt = (f.querySelector("img") || {}).alt || ""; lb.appendChild(im);
        lb.addEventListener("click", closeLightbox); document.body.appendChild(lb); lb.focus();
      }
      f.addEventListener("click", open); f.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
    });
  }
  function initCopy() {
    document.addEventListener("click", function (e) {
      var b = e.target.closest && e.target.closest("[data-copy]"); if (!b) return;
      U.copyText(b.getAttribute("data-copy"), function (ok) { b.textContent = ok ? "Copied" : "Copy failed"; setTimeout(function () { b.textContent = "Copy"; }, 1600); });
    });
  }
  function initSkip() {
    var a = document.querySelector("[data-skip]"); if (!a) return;
    a.addEventListener("click", function (e) { e.preventDefault(); var m = views[current || "home"]; if (!m) return; m.setAttribute("tabindex", "-1"); m.focus(); });
  }
  function init() {
    views = { home: $("view-home"), cube: $("view-cube"), twin: $("view-twin"), lab: $("view-lab"), research: $("view-research"), results: $("view-results"), validation: $("view-validation"), build: $("view-build"), connect: $("view-connect") };
    initSkip();
    initNav(); initVideo(); initLightbox(); initCopy();
    TwinPage.renderStaticTex(views.home); U.fixGreek(views.home); U.fixGreek(document.querySelector(".nav"));
    if (window.AERIS_STATUS) AERIS_STATUS.init($("sysbar"));
    if (window.Pages && Pages.init) Pages.init();
    Home.init();
    window.addEventListener("hashchange", route);
    route();
  }
  return { init: init, route: route, canonical: canonical, viewFor: viewFor };
})();
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", App.init); else App.init();

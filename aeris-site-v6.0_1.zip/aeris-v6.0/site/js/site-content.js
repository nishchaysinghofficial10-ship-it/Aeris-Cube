/* =====================================================================
   AERIS · SITE CONTENT — the one file to edit when real project evidence
   becomes available. Nothing here is invented: empty entries render as
   clearly marked placeholders ("pending", "not uploaded yet", "forthcoming").
   ===================================================================== */
var AERIS_CONTENT = {
  /* Public source repository. Leave null until a real URL exists; the site then
     shows "Repository forthcoming" instead of a link. Example:
     repository: { url: "https://github.com/<account>/<repo>", label: "github.com/<account>/<repo>" } */
  repository: null,

  contactEmail: "contact@stablix.dev",

  /* AERIS Twin: how far the digital model has been checked against the physical cube.
     "nominal"   design values only (today)
     "measured"  parameters measured on the cube (set parameterSet to name that set)
     "validated" model outputs compared with hardware runs under stated conditions
     Change this only when the evidence exists; every run records the state it was made under. */
  twin: { validation: "nominal", parameterSet: "nominal-design-v1" },

  hardware: {
    /* What the physical cube does today, in your words. */
    status: "The physical AERIS cube balances on an edge and on a corner.",

    /* Videos or photos of the physical cube. Put the files in assets/ and list them here:
       { type: "video", src: "assets/hw-edge.mp4", poster: "assets/hw-edge.jpg", caption: "Edge balance, unedited, 60 s", date: "2026-10-01" }
       { type: "image", src: "assets/hw-bench.jpg", caption: "Bench set-up", date: "2026-10-01" } */
    footage: [],

    /* Measured values from the physical cube. null → "Pending measurement".
       Give each as { value: 1.84, unit: "kg", method: "kitchen scale ±1 g", date: "2026-10-01" }. */
    measured: {
      mass: null,            // total mass
      edge: null,            // edge length
      bodyInertia: null,     // J_c about the centre (trifilar pendulum)
      wheelInertia: null,    // J_w of one wheel
      torqueConstant: null,  // k_t (stall test)
      wheelSpeedLimit: null, // highest wheel speed used
      peakTorque: null,      // peak wheel torque
      loopRate: null,        // control loop rate of the firmware
      supply: null           // battery / supply voltage
    },

    /* Simulation-versus-hardware comparisons. Each entry pairs a hardware log with a run
       exported from AERIS Lab under the same conditions:
       { title: "2° edge recovery, LQR", hardwareLog: "data/hw-edge-2deg.csv", simulationRun: "data/sim-edge-2deg.json", note: "…" } */
    comparisons: []
  },

  /* The project story shown on the home page: the author's own words, one line per stage. */
  story: [
    { n: "01", key: "rwip", system: "hardware", title: "RWIP", subtitle: "Reaction-wheel inverted pendulum", quote: "I learned feedback control.",
      text: "A single-axis reaction-wheel inverted pendulum: LQR derived from Lagrangian dynamics, with IMU sensor fusion. The one-degree-of-freedom version of the attitude-control problem.", status: "Earlier project · footage and documentation pending", href: "#research-evolution" },
    { n: "02", key: "cube", system: "hardware", title: "AERIS Cube", subtitle: "Physical three-axis system", quote: "I extended the concept into a three-axis physical system.",
      text: "Three reaction wheels on orthogonal axes let the cube balance on an edge or on a single corner.", status: "Built · balances on an edge and on a corner", href: "#cube" },
    { n: "03", key: "twin", system: "twin", title: "AERIS Twin", subtitle: "Physics-based digital model", quote: "I reconstructed the cube's dynamics computationally.",
      text: "Rigid-body dynamics, wheel and motor limits, sensing and the three controllers, derived and computed in the browser.", status: "Nominal parameters · SIM ↔ hardware validation pending", href: "#twin" },
    { n: "04", key: "lab", system: "research", title: "AERIS Lab", subtitle: "Experimental research platform", quote: "I turned the digital model into an experimental attitude-control research platform.",
      text: "Reproducible experiments with IDs, event timelines, controller sets and research sweeps, built so a Python research backend and hardware telemetry can plug in.", status: "DEMO mode in the browser · SIMULATION mode with the Python research backend · nominal parameters", href: "#lab" }
  ],

  /* Evolution of the project, oldest first. status: done | in-progress | next | planned | failed.
     Failed iterations belong here too: add them with status "failed" and what was learned.
     Only the author can supply dates and failed iterations; none are invented here. */
  evolution: [
    { stage: "RWIP", system: "hardware", status: "done", title: "Reaction-wheel inverted pendulum (1 DOF)", text: "LQR from Lagrangian dynamics, IMU sensor fusion. Current functional status and footage: to be documented." },
    { stage: "Iterations", system: "hardware", status: "undocumented", title: "Hardware iterations, including failed attempts", text: "Not yet documented on this site. Failed builds and what they taught belong in this timeline." },
    { stage: "AERIS Cube", system: "hardware", status: "done", title: "Three-axis cube balancing on an edge and on a corner", text: "Three BLDC reaction wheels, 9-DOF IMU, STM32 microcontroller, motor drivers, power system, aluminium frame." },
    { stage: "AERIS Twin 0.2", system: "twin", status: "done", title: "Browser model with nominal parameters", text: "Edge and corner models, PID, LQR and COM-adaptive LQR, one outcome function for every run." },
    { stage: "AERIS Lab 3.0", system: "research", status: "done", title: "Research-platform frontend", text: "Experiment IDs, schemas, service and adapter layer, sensor and actuator models, event timeline, controller sets and research sweeps in DEMO mode." },
    { stage: "Research backend", system: "research", status: "done", title: "Python research backend (this version, v4)", text: "Physics, sensors, MEKF, PID / LQR / coupled MIMO LQR / nonlinear PD, research metrics, sweeps, SQLite storage, jobs and a REST/WebSocket API, connected through the ResearchApiAdapter (SIMULATION mode). Runs on your machine; nominal parameters." },
    { stage: "Measurement", system: "hardware", status: "next", title: "Measure the cube's parameters", text: "Mass, inertia (trifilar pendulum), motor constants, wheel friction, loop rate: NOMINAL → MEASURED." },
    { stage: "Validation", system: "twin", status: "planned", title: "SIM ↔ HARDWARE validation", text: "The same scripted runs on the cube and in the model, compared by RMSE, peak error and time offset." },
    { stage: "Final results", system: "research", status: "planned", title: "Final dataset and findings", text: "Answering the research question with a published, reproducible dataset." }
  ],

  /* Hardware subsystems (from the project reference sheet). Parameter status is derived from
     hardware.measured (MEASURED) and hardware.validated (VALIDATED); everything else is NOMINAL. */
  subsystems: [
    { key: "wx", label: "Reaction wheel X", part: "BLDC motor + flywheel", role: "Torque about the body x axis; the only wheel used in edge balance." },
    { key: "wy", label: "Reaction wheel Y", part: "BLDC motor + flywheel", role: "Torque about the body y axis." },
    { key: "wz", label: "Reaction wheel Z", part: "BLDC motor + flywheel", role: "Torque about the body z axis." },
    { key: "motors", label: "Motor drivers", part: "Three-phase drivers", role: "Current-limited drive of the three wheel motors." },
    { key: "imu", label: "IMU", part: "9-DOF inertial measurement unit", role: "Gyroscope and accelerometer for attitude estimation." },
    { key: "mcu", label: "MCU", part: "STM32 microcontroller", role: "Estimator and control loop." },
    { key: "pcb", label: "Control board (PCB)", part: "Custom board", role: "Connects the MCU, IMU, drivers and power. Design files to be published with the repository." },
    { key: "battery", label: "Battery and power", part: "Battery + regulation", role: "Supplies the motors and electronics." },
    { key: "frame", label: "Frame", part: "Aluminium", role: "Rigid cube structure carrying the wheels on three orthogonal faces." },
    { key: "link", label: "Communication", part: "USB / wireless", role: "Telemetry downlink and command uplink (live telemetry into AERIS Lab is planned)." }
  ],

  /* The research question and plan (Research page). Hypotheses are predictions to be tested,
     not results. */
  research: {
    question: "How do PID, LQR, and adaptive/nonlinear attitude controllers differ in their ability to stabilize a three-axis reaction-wheel system as center-of-mass displacement, inertia uncertainty, disturbances and actuator saturation increase?",
    hypotheses: [
      { id: "H1", text: "As the centre-of-mass displacement grows, PID (which does not feed back wheel speed) will lose stability first, through wheel-speed drift into saturation; LQR will hold longer; COM-adaptive LQR, which estimates the balance offset, will hold longest.", test: "COM stability map and recovery probability against COM shift, same points for every controller." },
      { id: "H2", text: "Under inertia mismatch between model and plant, the recovery region of every controller will shrink, and the COM-adaptive law will give no advantage, because it adapts the balance offset only, not inertia.", test: "Recovery probability against true inertia (× model) for all three controllers." },
      { id: "H3", text: "Actuator saturation, not the control law, will set the edge of the domain of attraction for large initial tilts and pushes: near that edge all three controllers will fail together.", test: "Saturation map (torque limit × initial tilt) and the observed limits per controller." },
      { id: "H4", text: "Sensor noise and bias will matter little for LQR with a Kalman filter at nominal levels, but estimator bias will dominate once gyro bias is not estimated.", test: "Monte Carlo over sensor noise and bias with a fixed estimator per series." }
    ],
    variables: {
      independent: ["Controller (PID, LQR, COM-adaptive LQR)", "COM displacement x, y, z (mm)", "Inertia mismatch (× model)", "Disturbance magnitude (N)", "Torque limit (% of nominal) and wheel-speed limit (rpm)", "Initial tilt (°) and angular velocity (°/s)", "Sensor noise level (× nominal)"],
      controlled: ["Cube geometry and nominal parameter set (nominal-design-v1)", "Control-loop rate and integration method (RK4, zero-order hold)", "Observation window and outcome rules (one assessment function)", "Estimator for each series", "Random seeds (recorded)"],
      dependent: ["Outcome: recovered / not settled / drifting / fallen", "Settling time (s)", "RMS attitude error (°)", "Peak COM lean and lean margin (°)", "Peak wheel speed (rpm) and time at the speed limit (s)", "Torque-saturated time (s)", "Control effort ∫Σ|T|dt (N·m·s)", "Energy (J)"]
    },
    methodology: [
      "Fix the base setup and the nominal parameter set; record both with every run.",
      "Vary one or two parameters at a time on a grid (maps) or sample them (random, Monte Carlo); every controller sees the same points.",
      "Score every run with the same assessment function; keep invalid configurations visible as invalid, never drop them.",
      "Report recovery rates with 95 % Wilson intervals and observed limits at the sampled points; do not draw boundaries between points.",
      "Repeat the key experiments on the physical cube after measuring its parameters, and compare simulation and hardware (Validation page).",
      "Publish the definitions, seeds and rows so every number can be regenerated."
    ],
    metrics: ["settle", "rms", "peakLean", "leanMargin", "peakOmega", "speedLimited", "saturation", "effort", "energy"],
    limitations: [
      "All current numbers come from the nominal model; none are validated against the physical cube.",
      "Browser sweeps are limited to 400 runs and 10 s windows (DEMO mode); the full study needs the research backend (SIMULATION mode).",
      "In DEMO mode (browser engine) corner-mode sensing is ideal and its controllers are decoupled; the research backend adds the quaternion MEKF, a 3-D complementary filter and the coupled MIMO LQR. With gravity-only attitude correction the heading is not observable, so heading-hold results with an estimator include the drift.",
      "The adaptive controller compared here is COM-adaptive LQR. One nonlinear controller (model-compensated quaternion PD) runs on the research backend; other nonlinear designs (e.g. sliding mode, energy-based) are not implemented.",
      "Motor dynamics, frame flexibility and pivot slip are simplified or neglected (AERIS Twin §12)."
    ],
    future: [
      "Shared deployment of the research backend behind an authenticating proxy.",
      "Further nonlinear controllers (e.g. sliding mode, energy-based) in the backend.",
      "An absolute heading reference (magnetometer or optical) for the attitude estimators.",
      "Live hardware telemetry (HARDWARE mode) and hardware-in-the-loop runs.",
      "Measured parameter set and a validated model."
    ]
  },

  /* Findings for the Results page. Stays empty until a final dataset exists; each finding then
     lists { id, title, statement, figure, runs, range, dataset, method }. */
  results: { findings: [], datasets: [] },

  /* Controller benchmark from the project's earlier simulation runs (10° command), as
     printed on the reference sheet. These numbers were NOT produced by the simulator
     on this site. The traces behind them are not included yet (pending import), so
     they cannot be reproduced or checked: UNVERIFIED HISTORICAL material, not a finding.
     The traceable v5 results are in studies/results/nominal-v5 (nominal simulation). */
  benchmark: {
    status: "UNVERIFIED HISTORICAL",
    source: "Earlier AERIS project simulation runs (10° command), as listed on the project reference sheet",
    traces: "pending import",
    rows: [
      { controller: "PID", settle_s: 6.21, overshoot_deg: 8.7, sse_deg: 1.35, energy_J: 24.6 },
      { controller: "LQR", settle_s: 3.02, overshoot_deg: 2.1, sse_deg: 0.38, energy_J: 18.7 },
      { controller: "Adaptive", settle_s: 1.85, overshoot_deg: 0.9, sse_deg: 0.12, energy_J: 15.3 }
    ]
  }
};

/* Research backend (Python, REST + WebSocket; backend/README.md, docs/BACKEND_INTEGRATION.md).
   While baseUrl is null, SIMULATION mode stays disabled and every experiment runs on the browser
   engine (DEMO mode). A configured baseUrl is not enough: the site probes GET /health and
   GET /capabilities (at load, every probeMs and on "Check backend") and enables SIMULATION only while
   the backend answers; only the capabilities it reports are used. To enable it locally:
     python -m aeris_backend.api.main --port 8750          (in backend/, see backend/README.md)
     researchApi: { baseUrl: "http://127.0.0.1:8750", wsUrl: "ws://127.0.0.1:8750", pollMs: 1000, probeMs: 60000 }
   wsUrl (optional) gives live job updates over WebSocket; polling is the fallback.
   mock: true switches on an in-browser MOCK backend for previewing the job workflow; everything it
   returns is labelled MOCK and must not be presented as research output.
   Never put credentials here: authentication belongs in a reverse proxy in front of the backend
   (cookies are sent with credentials: "include"; see backend/README.md, "Deployment"). */
window.AERIS_CONFIG = window.AERIS_CONFIG || { researchApi: { baseUrl: null, wsUrl: null, pollMs: 1000, probeMs: 60000, mock: false } };

/* Optional AI service for the workspace assistant (see js/assistant.js). Keep null unless
   you run your own server-side endpoint; never put an API key in these files.
   window.AERIS_ASSISTANT_CONFIG = { endpoint: "https://your-server.example/aeris-assistant", name: "Your service" }; */
window.AERIS_ASSISTANT_CONFIG = window.AERIS_ASSISTANT_CONFIG || { endpoint: null };

/* =====================================================================
   AERIS TWIN page — the physics-based digital model: live parameters,
   worked calculations and the reference experiments AERIS-EXP-000001…7.
   ===================================================================== */
var TwinPage = (function () {
  "use strict";
  var DEG = AERIS_TWIN.DEG, RPM = AERIS_TWIN.RPM, esc = U.esc;
  var p = AERIS_TWIN.clone(AERIS_TWIN.NOMINAL), D = AERIS_TWIN.design(p);
  var inited = false, texDone = false;
  /* colours and markers from js/platform/tokens.js: controllers are equally weighted (no lime for data) */
  var TK = AERIS_TOKENS, ST = TK.color.status, INK = TK.color.ink;
  var COLORS = { pid: TK.controller("pid").color, lqr: TK.controller("lqr").color, adp: TK.controller("adp").color, bad: ST.failure, warn: ST.warning, ok: ST.stable };
  var MARK = { pid: TK.controller("pid").marker, lqr: TK.controller("lqr").marker, adp: TK.controller("adp").marker };
  var NAMES = { pid: "PID", lqr: "LQR", adp: "COM-adaptive LQR", none: "No control" };
  var CTRLS = ["pid", "lqr", "adp"];

  /* ---------------- formatting ---------------- */
  function fx(x, d) { var s = (+x).toFixed(d); return s === "-" + (0).toFixed(d) ? (0).toFixed(d) : s; }
  function tn(x, sig) {                      // number for TeX
    sig = sig || 4; if (!isFinite(x)) return "\\infty"; if (x === 0) return "0";
    var e = Math.floor(Math.log10(Math.abs(x)));
    if (e < -2 || e > 5) { var m = x / Math.pow(10, e); if (Math.abs(+m.toFixed(sig - 1)) >= 10) { m /= 10; e += 1; } return "{" + m.toFixed(sig - 1) + "\\times10^{" + e + "}}"; }
    return x.toFixed(Math.max(0, sig - 1 - e));
  }
  function tp(x, sig) {                      // number for plain text
    sig = sig || 4; if (!isFinite(x)) return "∞"; if (x === 0) return "0";
    var e = Math.floor(Math.log10(Math.abs(x)));
    if (e < -2 || e > 5) { var m = x / Math.pow(10, e); return m.toFixed(sig - 1) + "×10" + sup(e); }
    return x.toFixed(Math.max(0, sig - 1 - e)).replace("-", "−");
  }
  function sup(e) { var map = { "-": "⁻", "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹" }; return String(e).split("").map(function (c) { return map[c] || c; }).join(""); }
  function mm(v) { return v.replace("-", "−"); }
  function bm(M, sig) { return "\\begin{bmatrix}" + M.map(function (r) { return r.map(function (v) { return tn(v, sig || 4); }).join(" & "); }).join("\\\\ ") + "\\end{bmatrix}"; }
  function cpx(r, d) { d = d == null ? 2 : d; if (Math.abs(r[1]) < 1e-9) return fx(r[0], d); return fx(r[0], d) + (r[1] >= 0 ? "+" : "-") + fx(Math.abs(r[1]), d) + "j"; }
  function uniqPoles(ps, d) { var out = [], seen = {}; ps.forEach(function (r) { if (r[1] < -1e-9) return; var k = cpx(r, d); if (!seen[k]) { seen[k] = 1; out.push(Math.abs(r[1]) > 1e-9 ? fx(r[0], d) + "\\pm " + fx(Math.abs(r[1]), d) + "j" : fx(r[0], d)); } }); return out.join(",\\ "); }
  function $(id) { return document.getElementById(id); }

  /* ---------------- KaTeX ---------------- */
  function tex(el, s, display) {
    if (window.katex) {
      try { katex.render(s, el, { displayMode: !!display, throwOnError: false, strict: "ignore", trust: false }); return; }
      catch (e) { /* fall through */ }
    }
    el.textContent = s; el.classList.add("tex-err");
  }
  function renderStaticTex(root) {
    [].forEach.call(root.querySelectorAll(".tx"), function (el) { if (!el._t) { el._t = el.textContent; } tex(el, el._t, false); });
    [].forEach.call(root.querySelectorAll(".tx-d"), function (el) { if (!el._t) { el._t = el.textContent; } tex(el, el._t, true); });
  }

  /* ---------------- parameters ---------------- */
  var SPEC = [
    { k: "a", s: "a", n: "Edge length", u: "m", min: 0.08, max: 0.4, d: 3 },
    { k: "m", s: "m", n: "Total mass", u: "kg", min: 0.3, max: 5, d: 2 },
    { k: "kJ", s: "k_J", n: "Inertia factor", e: "Sets the body inertia: 0.167 solid block, 0.278 thin shell", u: "–", min: 0.1, max: 0.35, d: 3 },
    { k: "Jw", s: "J_w", n: "Wheel spin inertia", u: "kg·m²", min: 1e-5, max: 5e-3, d: "e" },
    { k: "KV", s: "K_V", n: "Motor velocity constant", u: "rpm/V", min: 50, max: 3000, d: 0 },
    { k: "R", s: "R", n: "Phase resistance", u: "Ω", min: 0.02, max: 5, d: 2 },
    { k: "Vs", s: "V_s", n: "Supply voltage", e: "3S LiPo nominal", u: "V", min: 3, max: 50, d: 1 },
    { k: "Imax", s: "I_{\\max}", n: "Driver current limit", u: "A", min: 0.5, max: 40, d: 1 },
    { k: "wmaxRpm", s: "\\Omega_{\\max}", n: "Wheel speed limit", u: "rpm", min: 500, max: 20000, d: 0 },
    { k: "cv", s: "c_v", n: "Viscous wheel friction", u: "N·m·s", min: 0, max: 1e-3, d: "e" },
    { k: "cc", s: "c_c", n: "Coulomb wheel friction", u: "N·m", min: 0, max: 0.05, d: 4 },
    { k: "fs", s: "f_s", n: "Control loop rate", u: "Hz", min: 100, max: 2000, d: 0 },
    { k: "rImu", s: "r_{\\text{IMU}}", n: "IMU distance from pivot", u: "m", min: 0, max: 0.3, d: 3 },
    { k: "g", s: "g", n: "Gravity", u: "m/s²", min: 0.5, max: 25, d: 2 }
  ];
  function pval(sp, v) { return sp.d === "e" ? (+v).toExponential(2) : (+v).toFixed(sp.d); }
  function buildParams() {
    var host = $("ptable"); if (!host) return;
    host.innerHTML = "";
    SPEC.forEach(function (sp) {
      var row = document.createElement("div"); row.className = "prow";
      var sy = document.createElement("span"); sy.className = "sy"; tex(sy, sp.s, false);
      var nm = document.createElement("span"); nm.className = "nm"; nm.textContent = sp.n;
      if (sp.e) { var em = document.createElement("em"); em.textContent = sp.e; nm.appendChild(em); }
      var inp = document.createElement("input"); inp.type = "text"; inp.inputMode = "decimal"; inp.id = "p_" + sp.k; inp.value = pval(sp, p[sp.k]);
      inp.setAttribute("aria-label", sp.n + " in " + sp.u);
      var un = document.createElement("span"); un.className = "un"; un.textContent = sp.u;
      row.appendChild(sy); row.appendChild(nm); row.appendChild(inp); row.appendChild(un); host.appendChild(row);
      inp.addEventListener("input", function () {
        var v = parseFloat(inp.value.replace("−", "-"));
        if (!isFinite(v) || v < sp.min || v > sp.max) { inp.classList.add("bad"); inp.title = "Allowed range " + sp.min + " to " + sp.max + " " + sp.u; return; }
        inp.classList.remove("bad"); inp.title = ""; p[sp.k] = v; schedule();
      });
      inp.addEventListener("blur", function () { if (!inp.classList.contains("bad")) inp.value = pval(sp, p[sp.k]); });
    });
  }
  function syncInputs() { SPEC.forEach(function (sp) { var i = $("p_" + sp.k); if (i) { i.value = pval(sp, p[sp.k]); i.classList.remove("bad"); } }); }
  var tmr = null;
  function schedule() { clearTimeout(tmr); tmr = setTimeout(recompute, 320); }
  function edited() { var ch = SPEC.some(function (sp) { return Math.abs(p[sp.k] - AERIS_TWIN.NOMINAL[sp.k]) > 1e-12; }); var el = $("pChanged"); if (el) el.hidden = !ch; }

  function derivedGrid() {
    var d = D.d, host = $("derived"); if (!host) return;
    var items = [
      ["J_c", tp(d.Jc, 4) + " kg·m²"], ["l_e", tp(d.le, 4) + " m"], ["l_c", tp(d.lc, 4) + " m"],
      ["k_t", tp(d.kt, 4) + " N·m/A"], ["\\tau_{\\max}", tp(d.taumax, 4) + " N·m"], ["\\Omega_{nl}", fx(d.wnl / RPM, 0) + " rpm"],
      ["h_{\\max}", tp(d.hmax, 4) + " N·m·s"], ["\\hat\\Theta_e", tp(d.Thhe, 4) + " kg·m²"], ["\\hat\\Theta_{c\\perp}", tp(d.Thhc, 4) + " kg·m²"],
      ["mgl_e", tp(d.mgle, 4) + " N·m"], ["\\lambda_e", tp(d.lame, 4) + " s⁻¹"], ["\\lambda_c", tp(d.lamc, 4) + " s⁻¹"],
      ["\\theta_{\\max,e}", fx(d.thmaxe / DEG, 2) + "°"], ["\\theta_{\\max,c}", fx(d.thmaxc / DEG, 2) + "°"], ["\\Delta t", fx(d.dt * 1000, 2) + " ms"]
    ];
    host.innerHTML = "";
    items.forEach(function (it) {
      var c = document.createElement("div"); var k = document.createElement("span"); k.className = "k"; tex(k, it[0], false);
      var v = document.createElement("span"); v.className = "val"; v.textContent = it[1]; c.appendChild(k); c.appendChild(v); host.appendChild(c);
    });
  }

  /* ---------------- live values ---------------- */
  function LIVE() {
    var d = D.d;
    return {
      lam_e: tp(d.lame, 3) + "<small>s⁻¹</small>",
      tfall: fx(Math.acosh(10) / d.lame, 2) + "<small>s</small>",
      thmax_e: fx(d.thmaxe / DEG, 2) + "<small>°</small>",
      tsat: fx(d.hmax / (d.m * d.g * 0.003), 2) + "<small>s</small>",
      dtms: fx(d.dt * 1000, 2) + " ms",
      rimu: fx(d.rImu * 1000, 0) + " mm",
      dmm: "3 mm",
      beta3: fx(Math.atan2(0.003, d.le) / DEG, 3) + "°"
    };
  }
  function updateLive() {
    var L = LIVE();
    [].forEach.call(document.querySelectorAll("[data-live]"), function (el) { var k = el.getAttribute("data-live"); if (L[k] != null) el.innerHTML = L[k]; });
    var d = D.d, M = D.e.M;
    var T = { AB: "A=" + bm(M.A, 4) + ",\\qquad B=" + bm(M.B, 4) };
    [].forEach.call(document.querySelectorAll("[data-live-tex]"), function (el) { var k = el.getAttribute("data-live-tex"); if (T[k]) tex(el, T[k], el.getAttribute("data-display") === "1"); });
  }

  /* ---------------- worked calculations ---------------- */
  function CALCS() {
    var d = D.d, e = D.e, c = D.c, y = D.yaw, a = d.a, m = d.m, g = d.g;
    var M = e.M, B = M.B, A = M.A;
    var AB = AERIS_TWIN.la.mul(A, B), A2B = AERIS_TWIN.la.mul(A, AB);
    var Cm = [[B[0][0], AB[0][0], A2B[0][0]], [B[1][0], AB[1][0], A2B[1][0]], [B[2][0], AB[2][0], A2B[2][0]]];
    var detC = AERIS_TWIN.la.det(Cm);
    var fast = e.cl.filter(function (r) { return Math.abs(r[1]) > 1e-9; });
    var pdom = fast.length ? Math.hypot(fast[0][0], fast[0][1]) : Math.abs(e.cl[0][0]);
    var poly = AERIS_TWIN.la.polyFromRoots(fast.concat([[AERIS_TWIN.WEIGHTS.pint, 0]]));
    var slow = e.adpPoles.filter(function (r) { return Math.hypot(r[0], r[1]) < 5; });
    var zeta = slow.length ? -slow[0][0] / Math.hypot(slow[0][0], slow[0][1]) : 1;
    var ranks = [AERIS_TWIN.cornerRank(D, [0, 1, 2]), AERIS_TWIN.cornerRank(D, [1, 2]), AERIS_TWIN.cornerRank(D, [0])];
    var Wmax = d.wmax, tAv = Math.max(0, d.kt * (d.Vs - d.ke * Wmax) / d.R);
    var wsat = d.hmax / (m * g * 0.003);
    var thdd = d.taumax / d.Thhe, lever = d.rImu * thdd / g;
    var BP = (window.AERIS_CONTENT && AERIS_CONTENT.benchmark && AERIS_CONTENT.benchmark.rows.filter(function (r) { return r.controller === "PID"; })[0]) || { overshoot_deg: 8.7, settle_s: 6.21 };
    var Mp = BP.overshoot_deg / 10, lnM = Math.log(Mp), z0 = -lnM / Math.sqrt(Math.PI * Math.PI + lnM * lnM), wn0 = 4 / (z0 * BP.settle_s);
    return {
      kin1: { t: "Gimbal-lock amplification at θ = 89°", f: "\\frac{1}{\\cos\\theta}", s: "\\frac{1}{\\cos 89^\\circ}=\\frac{1}{0.017452}", r: "57.3\\quad\\text{(rate errors amplified }57\\times\\text{; unbounded at }90^\\circ)" },
      kin2: { t: "Integrate ω = 0.1 rad/s about x for 1 s from identity", f: "\\mathbf q=\\mathbf q_0\\otimes\\big[\\cos(\\lVert\\boldsymbol\\omega\\rVert\\Delta t/2),\\ \\hat{\\boldsymbol\\omega}\\sin(\\lVert\\boldsymbol\\omega\\rVert\\Delta t/2)\\big]^{\\mathsf T}", s: "\\cos(0.05)=0.998750,\\quad \\sin(0.05)=0.049979", r: "\\mathbf q=[\\,0.99875,\\ 0.04998,\\ 0,\\ 0\\,]^{\\mathsf T}\\quad(\\alpha=5.73^\\circ)" },
      kin3: { t: "Attitude that puts the main diagonal vertical", f: "\\alpha=\\arccos(\\hat{\\mathbf c}\\cdot\\hat{\\mathbf z}),\\quad \\hat{\\mathbf e}=\\frac{\\hat{\\mathbf c}\\times\\hat{\\mathbf z}}{\\lVert\\hat{\\mathbf c}\\times\\hat{\\mathbf z}\\rVert}", s: "\\alpha=\\arccos\\!\\big(1/\\sqrt3\\big),\\quad \\hat{\\mathbf e}=\\tfrac{1}{\\sqrt2}(1,-1,0)", r: "\\alpha=54.7356^\\circ,\\qquad \\mathbf q_{eq}=[\\,0.8881,\\ 0.3251,\\ -0.3251,\\ 0\\,]^{\\mathsf T}" },
      dyn1: { t: "Body inertia about the centre", f: "J_c=k_J\\,m\\,a^2", s: tn(d.kJ, 3) + "\\times" + tn(m, 3) + "\\times" + tn(a, 3) + "^2", r: "J_c=" + tn(d.Jc, 4) + "\\ \\text{kg m}^2" },
      dyn2: { t: "Wheel inertia as a steel rim of radius 45 mm", f: "J_w\\approx m_w r^2\\ \\Rightarrow\\ m_w=J_w/r^2", s: tn(d.Jw, 3) + "/0.045^2", r: "m_w=" + tn(d.Jw / 0.045 / 0.045 * 1000, 3) + "\\ \\text{g of rim mass}" },
      wh1: { t: "Free-space counter-rotation: one wheel spun to 1000 rpm", f: "\\omega=-\\frac{J_w}{J_c}\\,\\Omega", s: "-\\frac{" + tn(d.Jw, 3) + "}{" + tn(d.Jc, 4) + "}\\times104.72\\ \\text{rad/s}", r: "\\omega=" + tn(-d.Jw / d.Jc * 104.72, 4) + "\\ \\text{rad/s}=" + tn(-d.Jw / d.Jc * 104.72 / DEG, 4) + "^\\circ\\!/\\text{s}\\quad(" + tn(d.Jc / d.Jw, 3) + "\\times\\text{ slower than the wheel})" },
      wh2: { t: "Momentum one wheel can store", f: "h_{\\max}=J_w\\,\\Omega_{\\max}", s: tn(d.Jw, 3) + "\\times" + tn(d.wmax, 5), r: "h_{\\max}=" + tn(d.hmax, 4) + "\\ \\text{N m s}" },
      wh3: { t: "Gyroscopic torque: wheel X at 3000 rpm, body turning 0.5 rad/s about Y", f: "\\boldsymbol\\tau=-\\boldsymbol\\omega\\times\\big(J_w\\boldsymbol\\omega_w\\big),\\qquad \\lvert\\tau_z\\rvert=J_w\\,\\Omega_x\\,\\omega_y", s: tn(d.Jw, 3) + "\\times314.16\\times0.5", r: "\\lvert\\tau_z\\rvert=" + tn(d.Jw * 314.16 * 0.5, 4) + "\\ \\text{N m}=" + fx(d.Jw * 314.16 * 0.5 / d.taumax * 100, 0) + "\\%\\text{ of }\\tau_{\\max}\\text{, on the third axis}" },
      bal1: { t: "Pivot-to-COM distances", f: "l_e=\\tfrac{\\sqrt2}{2}a,\\qquad l_c=\\tfrac{\\sqrt3}{2}a", s: "0.70711\\times" + tn(a, 3) + ",\\qquad 0.86603\\times" + tn(a, 3), r: "l_e=" + tn(d.le, 5) + "\\ \\text{m},\\qquad l_c=" + tn(d.lc, 5) + "\\ \\text{m}" },
      bal4: { t: "Gravity torque at a 1° lean on an edge", f: "\\tau_g=m\\,g\\,l_e\\sin\\theta", s: tn(m, 3) + "\\times" + tn(g, 3) + "\\times" + tn(d.le, 5) + "\\times\\sin1^\\circ", r: "\\tau_g=" + tn(d.mgle * Math.sin(DEG), 4) + "\\ \\text{N m}\\ =\\ " + fx(d.mgle * Math.sin(DEG) / d.taumax * 100, 0) + "\\%\\text{ of }\\tau_{\\max}" },
      bal2: { t: "Edge inertia about the pivot", f: "\\Theta_0=J_c+m\\,l_e^2,\\qquad \\hat\\Theta=\\Theta_0-J_w", s: tn(d.Jc, 4) + "+" + tn(m, 3) + "\\times" + tn(d.le, 5) + "^2", r: "\\Theta_0=" + tn(d.Th0e, 5) + ",\\qquad \\hat\\Theta=" + tn(d.Thhe, 5) + "\\ \\text{kg m}^2" },
      bal3: { t: "Corner inertia: tilt axes and the vertical axis", f: "\\hat\\Theta_\\perp=J_c+m\\,l_c^2-J_w,\\qquad \\hat\\Theta_\\parallel=J_c-J_w", s: tn(d.Jc, 4) + "+" + tn(m, 3) + "\\times" + tn(d.lc, 5) + "^2-" + tn(d.Jw, 3), r: "\\hat\\Theta_\\perp=" + tn(d.Thhc, 5) + ",\\qquad \\hat\\Theta_\\parallel=" + tn(d.Thy, 5) + "\\ \\text{kg m}^2" },
      bal5: { t: "Open-loop instability rate", f: "\\lambda=\\sqrt{mgl/\\hat\\Theta}", s: "\\lambda_e=\\sqrt{" + tn(d.mgle, 4) + "/" + tn(d.Thhe, 4) + "},\\qquad \\lambda_c=\\sqrt{" + tn(d.mglc, 4) + "/" + tn(d.Thhc, 4) + "}", r: "\\lambda_e=" + tn(d.lame, 4) + "\\ \\text{s}^{-1}\\ (1/\\lambda=" + tn(1 / d.lame, 3) + "\\ \\text{s}),\\qquad \\lambda_c=" + tn(d.lamc, 4) + "\\ \\text{s}^{-1}" },
      bal6: { t: "Time for a 1° lean to become 10° with no control", f: "t=\\frac{\\operatorname{arccosh}(\\theta_1/\\theta_0)}{\\lambda}", s: "\\frac{\\operatorname{arccosh}(10)}{" + tn(d.lame, 4) + "}=\\frac{2.9932}{" + tn(d.lame, 4) + "}", r: "t=" + tn(Math.acosh(10) / d.lame, 3) + "\\ \\text{s}\\quad\\text{(edge)}" },
      bal7: { t: "Largest lean the wheels can hold", f: "\\theta_{\\max}=\\arcsin\\!\\big(\\tau_{\\max}/mgl\\big)", s: "\\arcsin\\!\\big(" + tn(d.taumax, 4) + "/" + tn(d.mgle, 4) + "\\big),\\qquad \\arcsin\\!\\big(" + tn(d.taumax, 4) + "/" + tn(d.mglc, 4) + "\\big)", r: "\\theta_{\\max,e}=" + fx(d.thmaxe / DEG, 2) + "^\\circ,\\qquad \\theta_{\\max,c}=" + fx(d.thmaxc / DEG, 2) + "^\\circ" },
      bal8: { t: "A 3 mm COM offset as a lean angle (edge)", f: "\\beta=\\arctan(\\delta/l_e)", s: "\\arctan(0.003/" + tn(d.le, 5) + ")", r: "\\beta=" + tn(Math.atan2(0.003, d.le), 4) + "\\ \\text{rad}=" + fx(Math.atan2(0.003, d.le) / DEG, 3) + "^\\circ" },
      act1: { t: "Motor torque constant", f: "k_t=\\frac{60}{2\\pi K_V}", s: "\\frac{60}{2\\pi\\times" + tn(d.KV, 4) + "}", r: "k_t=" + tn(d.kt, 5) + "\\ \\text{N m/A}" },
      act2: { t: "Peak torque at the current limit", f: "\\tau_{\\max}=k_t\\,I_{\\max}", s: tn(d.kt, 5) + "\\times" + tn(d.Imax, 3), r: "\\tau_{\\max}=" + tn(d.taumax, 4) + "\\ \\text{N m}" },
      act3: { t: "No-load speed", f: "\\Omega_{nl}=V_s/k_e", s: tn(d.Vs, 3) + "/" + tn(d.ke, 5), r: "\\Omega_{nl}=" + tn(d.wnl, 4) + "\\ \\text{rad/s}=" + fx(d.wnl / RPM, 0) + "\\ \\text{rpm}" },
      act4: { t: "Torque left at the speed limit", f: "T_{\\text{avail}}=k_t\\,\\frac{V_s-k_e\\Omega_{\\max}}{R}", s: tn(d.kt, 5) + "\\times\\frac{" + tn(d.Vs, 3) + "-" + tn(d.ke, 5) + "\\times" + tn(Wmax, 5) + "}{" + tn(d.R, 3) + "}", r: "T_{\\text{avail}}=" + tn(Math.min(tAv, d.taumax), 4) + "\\ \\text{N m}=" + fx(Math.min(tAv, d.taumax) / d.taumax * 100, 0) + "\\%\\text{ of }\\tau_{\\max}" },
      act5: { t: "Copper loss at the current limit; friction at 3000 rpm", f: "P_{Cu}=I_{\\max}^2R,\\qquad f(\\Omega)=c_v\\Omega+c_c", s: tn(d.Imax, 3) + "^2\\times" + tn(d.R, 3) + ",\\qquad " + tn(d.cv, 3) + "\\times314.16+" + tn(d.cc, 3), r: "P_{Cu}=" + tn(d.Imax * d.Imax * d.R, 3) + "\\ \\text{W per wheel},\\qquad f=" + tn(d.cv * 314.16 + d.cc, 3) + "\\ \\text{N m}" },
      act6: { t: "Time to saturate a wheel with a 3 mm COM offset held upright", f: "t_{\\text{sat}}=\\frac{h_{\\max}}{m\\,g\\,\\delta}", s: "\\frac{" + tn(d.hmax, 4) + "}{" + tn(m, 3) + "\\times" + tn(g, 3) + "\\times0.003}", r: "t_{\\text{sat}}=" + tn(wsat, 3) + "\\ \\text{s}\\quad\\text{(EXP-02: the twin's PID falls at }" + (window.__e2pid ? fx(window.__e2pid, 2) : "\\ldots") + "\\ \\text{s)}" },
      est3: { t: "Accelerometer tilt error from the lever arm at full torque", f: "\\Delta\\theta_a=\\frac{r_{\\text{IMU}}\\,\\ddot\\theta_{\\max}}{g},\\qquad \\ddot\\theta_{\\max}=\\frac{\\tau_{\\max}}{\\hat\\Theta}", s: "\\frac{" + tn(d.rImu, 3) + "\\times(" + tn(d.taumax, 4) + "/" + tn(d.Thhe, 4) + ")}{" + tn(g, 3) + "}", r: "\\Delta\\theta_a=" + tn(lever, 3) + "\\ \\text{rad}=" + fx(lever / DEG, 2) + "^\\circ" },
      est1: { t: "Complementary-filter blend", f: "\\alpha=\\frac{\\tau}{\\tau+\\Delta t}", s: "\\frac{0.5}{0.5+" + tn(d.dt, 3) + "}", r: "\\alpha=" + fx(0.5 / (0.5 + d.dt), 5) },
      est2: { t: "Complementary-filter error from gyro bias", f: "e_{ss}=b\\,\\tau", s: "0.5^\\circ\\!/\\text{s}\\times0.5\\ \\text{s}", r: "e_{ss}=0.25^\\circ\\quad\\text{(a constant offset the filter cannot remove)}" },
      ss0: { t: "Controllability of the edge model", f: "\\mathcal C=\\begin{bmatrix}B&AB&A^2B\\end{bmatrix}", s: "\\mathcal C=" + bm(Cm, 4), r: "\\det\\mathcal C=" + tn(detC, 4) + "\\ne0\\quad\\Rightarrow\\quad\\text{controllable}" },
      ss1: { t: "Controllability rank of the nine-state corner model", f: "\\operatorname{rank}\\begin{bmatrix}B&AB&\\cdots&A^8B\\end{bmatrix}", s: "\\text{three wheels}\\ \\mid\\ \\text{wheel X failed}\\ \\mid\\ \\text{one wheel left}", r: ranks[0] + "\\text{ of }9\\ \\mid\\ " + ranks[1] + "\\text{ of }9\\ \\mid\\ " + ranks[2] + "\\text{ of }9\\qquad\\text{(computed in your browser)}" },
      ss2: { t: "Sampling margin at the loop rate", f: "\\frac{\\omega_s}{\\lvert p\\rvert}=\\frac{2\\pi f_s}{\\lvert p_{\\text{dom}}\\rvert},\\qquad \\varphi_{\\text{ZOH}}=\\frac{\\lvert p\\rvert\\,\\Delta t}{2}", s: "\\frac{2\\pi\\times" + tn(d.fs, 3) + "}{" + tn(pdom, 3) + "},\\qquad \\frac{" + tn(pdom, 3) + "\\times" + tn(d.dt, 3) + "}{2}", r: "\\omega_s/\\lvert p\\rvert=" + fx(2 * Math.PI * d.fs / pdom, 0) + ",\\qquad \\varphi_{\\text{ZOH}}=" + fx(pdom * d.dt / 2 / DEG, 2) + "^\\circ\\ \\text{of phase}" },
      c_pid: { t: "PID gains by pole placement (edge)", f: "p_{1,2}=" + fx((fast[0] || [0, 0])[0], 2) + "\\pm " + fx(Math.abs((fast[0] || [0, 0])[1]), 2) + "j,\\quad p_3=-3", s: "s^3+" + tn(poly[1], 4) + "\\,s^2+" + tn(poly[2], 4) + "\\,s+" + tn(poly[3], 4), r: "K_p=" + tn(e.pid.Kp, 4) + ",\\quad K_i=" + tn(e.pid.Ki, 4) + ",\\quad K_d=" + tn(e.pid.Kd, 4) + "\\quad(K_p\\gt mgl=" + tn(d.mgle, 4) + ")" },
      c_lqr: { t: "LQR weights and Riccati solution (edge)", f: "Q=\\operatorname{diag}(" + tn(e.Q[0][0], 4) + ",\\ " + tn(e.Q[1][1], 4) + ",\\ " + tn(e.Q[2][2], 3) + "),\\quad R=" + tn(e.R[0][0], 4), s: "\\text{matrix sign function, }" + e.iters + "\\text{ iterations}", r: "P=" + bm(e.P, 4) },
      c_lqr2: { t: "LQR gain and closed-loop poles (edge)", f: "K=R^{-1}B^{\\mathsf T}P", s: "K=\\big[\\," + tn(e.K[0], 4) + ",\\ \\ " + tn(e.K[1], 4) + ",\\ \\ " + tn(e.K[2], 4) + "\\,\\big]", r: "\\operatorname{eig}(A-BK)=\\{" + uniqPoles(e.cl, 2) + "\\}\\ \\text{s}^{-1}" },
      c_adp: { t: "Adaptive loop: estimator gain and augmented poles", f: "\\gamma=" + tn(e.gam, 2) + ",\\qquad A_a\\ \\text{from (8.10)}", s: "\\operatorname{eig}(A_a)", r: "\\{" + uniqPoles(e.adpPoles, 3) + "\\}\\quad\\text{estimator pair }\\zeta=" + fx(zeta, 2) },
      c_yaw: { t: "Yaw loop about the gravity-free diagonal (corner)", f: "Q_\\psi=\\operatorname{diag}\\!\\big(1/(5^\\circ)^2,\\ 1/(30^\\circ\\!/\\text{s})^2\\big),\\quad R_\\psi=1/(3\\tau_{\\max}^2)", s: "K_\\psi=\\big[\\," + tn(y.K[0], 4) + ",\\ \\ " + tn(y.K[1], 4) + "\\,\\big]", r: "\\operatorname{eig}=\\{" + uniqPoles(y.cl, 2) + "\\}\\ \\text{s}^{-1},\\qquad K_{\\text{tilt,corner}}=[" + tn(c.K[0], 4) + ",\\ " + tn(c.K[1], 4) + ",\\ " + tn(c.K[2], 3) + "]" },
      ref1: { t: "Implied damping of the benchmark's PID row (earlier project runs)", f: "M_p=" + BP.overshoot_deg + "^\\circ/10^\\circ,\\qquad \\zeta=\\frac{-\\ln M_p}{\\sqrt{\\pi^2+\\ln^2M_p}},\\qquad \\omega_n=\\frac{4}{\\zeta t_s}", s: "\\zeta=\\frac{-\\ln" + fx(Mp, 3) + "}{\\sqrt{\\pi^2+(\\ln" + fx(Mp, 3) + ")^2}},\\qquad \\omega_n=\\frac{4}{\\zeta\\times" + BP.settle_s + "}", r: "\\zeta=" + fx(z0, 4) + ",\\qquad \\omega_n=" + fx(wn0, 2) + "\\ \\text{rad/s}" }
    };
  }
  function renderCalcs() {
    var C = CALCS();
    [].forEach.call(document.querySelectorAll("[data-calc]"), function (el) {
      var id = el.getAttribute("data-calc"), c = C[id]; if (!c) return;
      if (!el._built) {
        el.innerHTML = '<div class="calc-h"><span class="cid">CALC ' + id.toUpperCase().replace("_", "-") + '</span><span class="ct"></span></div>' +
          '<div class="calc-r"><span class="k">Formula</span><span class="x f"></span></div>' +
          '<div class="calc-r"><span class="k">Substitute</span><span class="x s"></span></div>' +
          '<div class="calc-r res"><span class="k">Result</span><span class="x r"></span></div>';
        el._built = true;
      }
      el.querySelector(".ct").textContent = c.t;
      tex(el.querySelector(".f"), "\\displaystyle " + c.f); tex(el.querySelector(".s"), "\\displaystyle " + c.s); tex(el.querySelector(".r"), "\\displaystyle " + c.r);
    });
  }

  /* ---------------- figures ---------------- */
  function figures() {
    var d = D.d, M = D.e.M;
    // uncontrolled fall (wheel locked, no motor torque)
    var th = DEG, thd = 0, dt = 0.002, xs = [], yN = [], yL = [], t = 0;
    while (t < 0.7 && th < 30 * DEG) {
      xs.push(t); yN.push(th / DEG); yL.push(DEG * Math.cosh(d.lame * t) / DEG);
      var f = function (a, b) { return [b, M.mgl * Math.sin(a) / d.Th0e]; };
      var k1 = f(th, thd), k2 = f(th + dt / 2 * k1[0], thd + dt / 2 * k1[1]), k3 = f(th + dt / 2 * k2[0], thd + dt / 2 * k2[1]), k4 = f(th + dt * k3[0], thd + dt * k3[1]);
      th += dt / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]); thd += dt / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]); t += dt;
    }
    var t10 = Math.acosh(10) / d.lame;
    Chart.line($("figFall"), { xlim: [0, xs[xs.length - 1]], ylim: [0, 32], xlabel: "t [s]", ylabel: "θ [deg]",
      series: [{ x: xs, y: yL, color: INK.secondary, width: 1.5, dash: [5, 4] }, { x: xs, y: yN, color: INK.primary, width: 2.2 }],
      hlines: [{ y: 10, color: TK.alpha(ST.failure, 0.6), dash: [3, 4], label: "10°" }], vlines: [{ x: t10, color: TK.alpha(INK.primary, 0.6), label: "t = " + fx(t10, 3) + " s" }] });
    // torque-speed envelope
    var ws = [], ta = [], tv = [];
    for (var i = 0; i <= 300; i++) {
      var w = d.wnl * 1.05 * i / 300; ws.push(w / RPM);
      var lim = Math.max(0, d.kt * (d.Vs - d.ke * w) / d.R);
      tv.push(lim); ta.push(w >= d.wmax ? 0 : Math.min(d.taumax, lim));
    }
    Chart.line($("figTorque"), { xlim: [0, d.wnl * 1.05 / RPM], ylim: [0, d.taumax * 1.35], xlabel: "Ω [rpm]", ylabel: "T [N·m]",
      series: [{ x: ws, y: tv, color: INK.tertiary, width: 1.3, dash: [5, 4] }, { x: ws, y: ta, color: INK.primary, width: 2.4 }],
      vlines: [{ x: d.wmax / RPM, color: TK.alpha(ST.warning, 0.85), label: "Ω max", align: "right" }, { x: d.wnl / RPM, color: "rgba(255,255,255,.35)", label: "no-load", dy: 24, align: "right" }],
      hlines: [{ y: d.taumax, color: "rgba(255,255,255,.35)", label: "τ max = " + fx(d.taumax, 3) + " N·m", left: true }] });
    // pole map
    Chart.poles($("figPoles"), { sets: [
      { color: INK.secondary, p: D.e.ol, shape: "x" }, { color: COLORS.pid, p: D.e.pidPoles, shape: "circle" }, { color: COLORS.lqr, p: D.e.cl, shape: "square" }, { color: COLORS.adp, p: D.e.adpPoles, shape: "triangle" }] });
    // reference table: the project's earlier simulation benchmark (see js/site-content.js)
    var tb = document.querySelector("#refTable tbody"), B = (window.AERIS_CONTENT && AERIS_CONTENT.benchmark) || null;
    if (tb && B) {
      var pidRow = B.rows.filter(function (r) { return r.controller === "PID"; })[0];
      tb.innerHTML = B.rows.map(function (r) {
        var Mp = r.overshoot_deg / 10, ln = Math.log(Mp), z = -ln / Math.sqrt(Math.PI * Math.PI + ln * ln), wn = 4 / (z * r.settle_s);
        return "<tr><td>" + r.controller + "</td><td>" + r.settle_s.toFixed(2) + "</td><td>" + r.overshoot_deg.toFixed(1) + "</td><td>" + r.sse_deg.toFixed(2) + "</td><td>" + r.energy_J.toFixed(1) + "</td><td>" + (Mp * 100).toFixed(0) + "</td><td>" + z.toFixed(3) + "</td><td>" + wn.toFixed(2) + "</td><td>" + (r === pidRow || !pidRow ? "—" : (pidRow.settle_s / r.settle_s).toFixed(2) + "×") + "</td><td>" + (r === pidRow || !pidRow ? "—" : ((1 - r.energy_J / pidRow.energy_J) * 100).toFixed(1) + "%") + "</td></tr>";
      }).join("");
    }
  }

  /* ---------------- reference experiments: this page documents the browser engine itself, so it uses the
     local-simulator adapter directly (AERIS_SERVICE.local()), with the shared outcome rules ---------------- */
  function labCfg(mode, o) { var c = AERIS_TWIN.defaultConfig(mode); c.params = AERIS_TWIN.clone(p); c.record_hz = 100; Object.keys(o).forEach(function (k) { c[k] = o[k]; }); return c; }
  function ini(tilt, az) { return { tilt_deg: tilt || 0, rate_dps: 0, azimuth_deg: az || 0, reference: "geometric" }; }
  function sim(mode, o) {
    var cfg = labCfg(mode, o), res = AERIS_SERVICE.local().simulateSync(cfg);
    if (!res.ok) return { ok: false, cfg: cfg, res: res, fell: null, m: null, L: null, outcome: res.outcome };
    var S = res.samples.cols, L = { t: S.t, th: S.theta, ww: S.omega_x, T: S.T_x, bh: S.betahat, thHat: S.thetahat, e: S.e, psi: S.psi, geo: S.geo };
    var Tpk = 0; (S.T_x || []).forEach(function (v) { if (Math.abs(v) > Tpk) Tpk = Math.abs(v); });
    return { ok: true, cfg: cfg, res: res, L: L, m: res.metrics, outcome: res.outcome, fell: res.metrics.fellAt_s, E: res.metrics.energy_J, Tpk: Tpk, final: { th: S.theta ? S.theta[S.t.length - 1] : null, ww: S.omega_x[S.t.length - 1], bh: S.betahat ? S.betahat[S.t.length - 1] : null } };
  }
  function series(r, key, scale, color, extra) {
    var L = r.L, y = L[key].map(function (v) { return v * scale; });
    var s = { x: L.t, y: y, color: color, width: 2 }; if (extra) for (var k in extra) s[k] = extra[k];
    CTRLS.forEach(function (c, i) { if (COLORS[c] === color && !s.marker) { s.marker = MARK[c]; s.markerOffset = 14 + i * 22; } });   // shape as a second channel
    return s;
  }
  function table(id, head, rows) {
    var el = $(id); if (!el) return;
    var h = "<thead><tr>" + head.map(function (x) { return "<th>" + x + "</th>"; }).join("") + "</tr></thead><tbody>";
    h += rows.map(function (r) { return "<tr" + (r.hl ? ' class="hl"' : "") + ">" + r.c.map(function (x) { return "<td>" + x + "</td>"; }).join("") + "</tr>"; }).join("");
    el.innerHTML = h + "</tbody>";
    if (typeof fixGreek === "function") fixGreek(el);
  }
  function sw(c) { return '<span class="sw" style="background:' + COLORS[c] + '"></span>' + NAMES[c]; }
  /* the one outcome label, as computed by AERIS_TWIN.assess for that run */
  function oc(r) { if (!r.outcome) return "—"; var t = r.outcome.code === "recovered" ? "v-ok" : r.outcome.code === "fallen" || r.outcome.code === "invalid" ? "v-bad" : "v-warn"; return '<span class="' + t + '" title="' + String(r.outcome.reason).replace(/"/g, "&quot;") + '">' + r.outcome.label + (r.outcome.code === "fallen" && r.fell != null ? " " + fx(r.fell, 2) + " s" : "") + "</span>"; }
  function ts(m) { return m.settle_s == null ? "not settled" : fx(m.settle_s, 2); }
  /* "open in the workspace" buttons under each experiment */
  var WSCFG = {};
  function wsButtons(id, items) {
    var el = document.querySelector('[data-ws="' + id + '"]'); if (!el) return;
    items.forEach(function (it, i) { WSCFG[id + ":" + i] = it.cfg; });
    el.innerHTML = '<span class="label dim">Open in the workspace</span>' + items.map(function (it, i) { return '<button type="button" class="act" data-wscfg="' + id + ":" + i + '">' + it.label + "</button>"; }).join("");
  }
  function bindWs() {
    document.addEventListener("click", function (e) {
      var b = e.target.closest && e.target.closest("[data-wscfg]"); if (!b) return;
      var cfg = WSCFG[b.getAttribute("data-wscfg")]; if (!cfg || !window.Workspace) return;
      location.hash = "#lab"; setTimeout(function () { Workspace.openConfig(AERIS_TWIN.clone(cfg), { run: true }); }, 30);
    });
  }

  var R = {};
  function exp1() {
    var runs = {}; CTRLS.forEach(function (c) { runs[c] = sim("edge", { controller: { type: c, knowsAttachments: false, reconfigureOnFailure: true }, initial: ini(2), duration_s: 10 }); });
    R.e1 = runs;
    Chart.line($("e1a"), { xlim: [0, 4], xlabel: "t [s]", ylabel: "θ [deg]", yzero: true, ybands: [{ y0: -AERIS_TWIN.ASSESS.settleTolDeg, y1: AERIS_TWIN.ASSESS.settleTolDeg, color: TK.alpha(ST.stable, 0.08) }], series: CTRLS.map(function (c) { return series(runs[c], "th", 1 / DEG, COLORS[c]); }) });
    Chart.line($("e1b"), { xlim: [0, 10], xlabel: "t [s]", ylabel: "Ω [rpm]", yzero: true, series: CTRLS.map(function (c) { return series(runs[c], "ww", 1 / RPM, COLORS[c]); }) });
    table("e1t", ["Controller", "Outcome", "t<sub>s</sub> (s)", "M<sub>p</sub> (°)", "Final-window lean (°)", "t<sub>Ω</sub> (s)", "Peak Ω (rpm)", "Final Ω (rpm)", "Peak T (N·m)", "E (J)"],
      CTRLS.map(function (c) { var r = runs[c], m = r.m; return { c: [sw(c), oc(r), ts(m), fx(m.overshoot_deg || 0, 2), fx(m.finalLean_deg, 4), m.tOmega_s == null ? "not settled" : fx(m.tOmega_s, 2), fx(m.peakOmega_rpm, 0), mm(fx(m.finalOmega_rpm.x, 1)), fx(r.Tpk, 3), fx(m.energy_J, 2)] }; }));
    var mp = runs.pid.m, ml = runs.lqr.m, ma = runs.adp.m;
    var allRec = CTRLS.every(function (c) { return runs[c].outcome.code === "recovered"; }), allSat = CTRLS.every(function (c) { return runs[c].Tpk >= D.d.taumax * 0.999; });
    $("e1f").innerHTML = (allRec ? "All three runs end Recovered. " : "Not every controller recovers with these parameters. ") +
      "Settling times into the ±" + AERIS_TWIN.ASSESS.settleTolDeg + "° band: PID " + ts(mp) + " s, LQR " + ts(ml) + " s, adaptive " + ts(ma) + " s; energy " + fx(mp.energy_J, 2) + ", " + fx(ml.energy_J, 2) + " and " + fx(ma.energy_J, 2) + " J. " +
      (allSat ? "All three hit the " + fx(D.d.taumax, 3) + " N·m torque ceiling in the first instant, so each recovery starts the same way. " : "") +
      "The difference is what happens to the wheel: LQR and the adaptive loop regulate wheel momentum (LQR is back within 50 rpm by " + (ml.tOmega_s == null ? "the end" : fx(ml.tOmega_s, 2) + " s") + "), while PID only looks at tilt, so the momentum left in its wheel stays there (final Ω " + mm(fx(mp.finalOmega_rpm.x, 1)) + " rpm).";
    wsButtons("e1", CTRLS.map(function (c) { return { label: NAMES[c], cfg: runs[c].cfg }; }));
  }
  function exp2() {
    var runs = {}, dl = 0.003, beta = Math.atan2(dl, D.d.le);
    CTRLS.forEach(function (c) { runs[c] = sim("edge", { controller: { type: c, knowsAttachments: false, reconfigureOnFailure: true }, initial: ini(0), comOffset_m: dl, duration_s: 20 }); });
    R.e2 = runs; window.__e2pid = runs.pid.fell;
    var wl = D.d.wmax / RPM;
    Chart.line($("e2a"), { xlim: [0, 20], ylim: [-wl * 0.08, wl * 1.12], xlabel: "t [s]", ylabel: "Ω [rpm]", series: CTRLS.map(function (c) { return series(runs[c], "ww", 1 / RPM, COLORS[c]); }),
      hlines: [{ y: wl, color: "rgba(255,255,255,.5)", label: "Ω max" }],
      markers: runs.pid.fell != null ? [{ x: runs.pid.fell, y: runs.pid.L.ww[runs.pid.L.ww.length - 1] / RPM, color: COLORS.bad, label: "PID falls " + fx(runs.pid.fell, 2) + " s", align: "right" }] : [] });
    var ser = CTRLS.map(function (c) { return series(runs[c], "th", 1 / DEG, COLORS[c]); });
    ser.push({ x: runs.adp.L.t, y: runs.adp.L.bh.map(function (v) { return -v / DEG; }), color: COLORS.adp, width: 1.2, dash: [2, 3], alpha: 0.8 });
    Chart.line($("e2b"), { xlim: [0, 20], ylim: [-(beta / DEG) * 2.2, (beta / DEG) * 1.6], xlabel: "t [s]", ylabel: "θ [deg]  (dotted: −β̂)", series: ser,
      hlines: [{ y: -beta / DEG, color: "rgba(255,255,255,.5)", label: "true balance lean −β = " + mm(fx(-beta / DEG, 3)) + "°" }] });
    table("e2t", ["Controller", "Outcome", "Final lean θ (°)", "Final Ω (rpm)", "Peak Ω (rpm)", "β̂ final (°)", "E (J)"],
      CTRLS.map(function (c) { var r = runs[c], m = r.m; return { c: [sw(c), oc(r), r.fell != null ? "—" : mm(fx(r.final.th / DEG, 3)), r.fell != null ? "—" : mm(fx(r.final.ww / RPM, 1)), fx(m.peakOmega_rpm, 0), c === "adp" ? fx(r.final.bh / DEG, 3) : "—", fx(m.energy_J, 2)] }; }));
    var mp = runs.pid, ml = runs.lqr, ma = runs.adp, tq = D.d.m * D.d.g * dl;
    $("e2f").innerHTML = "The offset puts a constant " + fx(tq, 4) + " N·m of gravity torque on the cube. " +
      (mp.fell != null ? "PID holds the frame at exactly the wrong angle, 0°, so that torque is stored in the wheel until it reaches " + fx(D.d.wmax / RPM, 0) + " rpm and the cube falls at " + fx(mp.fell, 2) + " s (§05 predicts about " + fx(D.d.hmax / tq, 2) + " s to saturation). " : "PID survives with these parameters, but its wheel reaches " + fx(mp.m.peakOmega_rpm, 0) + " rpm. ") +
      (ml.fell == null ? "LQR leans to " + mm(fx(ml.final.th / DEG, 3)) + "°, putting the COM over the pivot, but it parks the wheel at " + fx(ml.final.ww / RPM, 0) + " rpm and pays friction for it (" + fx(ml.m.energy_J, 2) + " J). " : "LQR falls at " + fx(ml.fell, 2) + " s. ") +
      (ma.fell == null ? "The adaptive loop learns β̂ = " + fx(ma.final.bh / DEG, 3) + "° (true " + fx(beta / DEG, 3) + "°), brings the wheel back to " + mm(fx(ma.final.ww / RPM, 1)) + " rpm and uses " + fx(ma.m.energy_J, 2) + " J." : "The adaptive loop falls at " + fx(ma.fell, 2) + " s.") +
      " The same case cut to 4 s is the regression example in the workspace: there the PID run is still upright but its wheel is climbing, so it is reported as Drifting, not Recovered.";
    wsButtons("e2", CTRLS.map(function (c) { return { label: NAMES[c], cfg: runs[c].cfg }; }).concat([{ label: "PID, 4 s (regression case)", cfg: labCfg("edge", { controller: { type: "pid", knowsAttachments: false, reconfigureOnFailure: true }, initial: ini(0), comOffset_m: dl, duration_s: 4 }) }]));
  }
  function exp3() {
    var runs = {}, push = [{ id: "L1", type: "torque", magnitude_Nm: 0.05, direction: [1, 0, 0], frame: "body", t_start_s: 1, duration_s: 5 }];
    CTRLS.forEach(function (c) { runs[c] = sim("edge", { controller: { type: c, knowsAttachments: false, reconfigureOnFailure: true }, initial: ini(0), duration_s: 15, disturbances: push }); });
    R.e3 = runs;
    var band = [{ x0: 1, x1: 6, color: "rgba(255,176,32,0.07)", label: "push 0.05 N·m" }];
    Chart.line($("e3a"), { xlim: [0, 15], xlabel: "t [s]", ylabel: "θ [deg]", yzero: true, xbands: band, series: CTRLS.map(function (c) { return series(runs[c], "th", 1 / DEG, COLORS[c]); }) });
    Chart.line($("e3b"), { xlim: [0, 15], xlabel: "t [s]", ylabel: "Ω [rpm]", yzero: true, xbands: band, series: CTRLS.map(function (c) { return series(runs[c], "ww", 1 / RPM, COLORS[c]); }), hlines: [{ y: D.d.wmax / RPM, color: "rgba(255,255,255,.5)", label: "Ω max", fit: true }] });
    table("e3t", ["Controller", "Outcome", "Max lean (°)", "Peak Ω (rpm)", "% of Ω max", "Final Ω (rpm)", "t<sub>Ω</sub> (s)", "E (J)"],
      CTRLS.map(function (c) { var r = runs[c], m = r.m; return { c: [sw(c), oc(r), fx(m.peakLean_deg, 3), fx(m.peakOmega_rpm, 0), fx(m.peakOmega_frac * 100, 0) + "%", mm(fx(m.finalOmega_rpm.x, 0)), m.tOmega_s == null ? "not settled" : fx(m.tOmega_s, 2), fx(m.energy_J, 2)] }; }));
    var mp = runs.pid.m, ml = runs.lqr.m, ma = runs.adp.m;
    $("e3f").innerHTML = "The push delivers 0.25 N·m·s of angular momentum in total. " +
      (runs.pid.fell == null ? "PID keeps the frame upright and lets the wheel absorb all of it: " + fx(mp.peakOmega_rpm, 0) + " rpm, " + fx(mp.peakOmega_frac * 100, 0) + "% of its limit, still spinning at " + fx(Math.abs(mp.finalOmega_rpm.x), 0) + " rpm when the run ends. Its outcome is Recovered because the lean settled, with a note that the wheel has almost no margin left. " : "PID stores it all in the wheel, saturates and falls at " + fx(runs.pid.fell, 2) + " s. ") +
      (runs.lqr.fell == null ? "LQR leans " + fx(ml.peakLean_deg, 2) + "° into the push so gravity carries part of the load, which caps the wheel at " + fx(ml.peakOmega_rpm, 0) + " rpm and returns it to zero. " : "LQR falls at " + fx(runs.lqr.fell, 2) + " s. ") +
      (runs.adp.fell == null ? "The adaptive loop leans " + fx(ma.peakLean_deg, 2) + "° and peaks at " + fx(ma.peakOmega_rpm, 0) + " rpm, but it treats the push as a mass offset and needs " + (ma.tOmega_s == null ? "longer than the run" : fx(ma.tOmega_s, 1) + " s") + " to unlearn it afterwards." : "The adaptive loop falls at " + fx(runs.adp.fell, 2) + " s.");
    wsButtons("e3", CTRLS.map(function (c) { return { label: NAMES[c], cfg: runs[c].cfg }; }));
  }
  var doaState = { running: false, done: false, res: [], token: 0 };
  function exp4(restart) {
    if (doaState.running && !restart) return;
    var token = ++doaState.token;
    doaState.running = true; doaState.res = []; var st = $("e4st"); if (st) st.textContent = "edge · simulated · running";
    var ctr = 0, order = CTRLS.slice(), bar = $("e4p");
    function next() {
      if (token !== doaState.token) return;
      if (!order.length) { doaState.running = false; doaState.done = true; if (st) st.textContent = "edge · simulated · 3 × 1089 runs"; finish(); return; }
      var c = order.shift(), idx = CTRLS.indexOf(c);
      AERIS_TWIN.doaEdge(p, D, c, { nth: 33, nthd: 33, T: 4 }, function (res) {
        if (token !== doaState.token) return;
        doaState.res[idx] = res; drawDoa(idx, res); ctr++; next();
      }, function (f) { if (bar && token === doaState.token) bar.style.width = (((ctr + f) / 3) * 100).toFixed(1) + "%"; });
    }
    next();
  }
  function drawDoa(i, res) {
    var tm = D.d.thmaxe / DEG;
    Chart.heat($("e4c" + i), { nx: res.nth, ny: res.nthd, data: res.res, xr: [-8, 8], yr: [-80, 80], xt: [-8, -4, 0, 4, 8], yt: [-80, -40, 0, 40, 80], xlabel: "θ₀ [deg]", ylabel: "θ̇₀ [deg/s]", vlines: [-tm, tm] });
    var n = $("e4n" + i); if (n) n.textContent = fx(res.frac * 100, 1) + "% captured";
  }
  function finish() {
    var r = doaState.res; if (r.length < 3) return;
    $("e4f").innerHTML = "Share of the sampled initial states each controller captures within 4 s: PID " + fx(r[0].frac * 100, 1) + "%, LQR " + fx(r[1].frac * 100, 1) + "%, adaptive " + fx(r[2].frac * 100, 1) + "%. " +
      "From rest, LQR captures leans up to ±" + fx(r[1].capHi / DEG, 2) + "°, close to the hard physical limit θ<sub>max</sub> = " + fx(D.d.thmaxe / DEG, 2) + "° (dashed lines), past which no controller can win. Almost every capture near the edge of the region passes through torque saturation (amber). The size of this region is one measure of robustness; how it shrinks as δ, ΔJ and τ<sub>max</sub> are swept is an open question for the physical cube.";
  }
  function exp5() {
    var out = {}, ev = [{ id: "E1", type: "wheel_failure", wheel: "x", t_s: 0.1 }];
    CTRLS.forEach(function (c) {
      out[c] = {
        yes: sim("corner", { controller: { type: c, knowsAttachments: false, reconfigureOnFailure: true }, initial: ini(2, 0.7 / DEG), duration_s: 10, events: ev }),
        no: sim("corner", { controller: { type: c, knowsAttachments: false, reconfigureOnFailure: false }, initial: ini(2, 0.7 / DEG), duration_s: 10, events: ev })
      };
    });
    R.e5 = out;
    var ser = [];
    CTRLS.forEach(function (c) {
      ser.push({ x: out[c].no.L.t, y: out[c].no.L.geo.map(function (v) { return Math.min(v / DEG, 25); }), color: COLORS[c], width: 1.4, dash: [5, 4], alpha: 0.85 });
      ser.push({ x: out[c].yes.L.t, y: out[c].yes.L.geo.map(function (v) { return v / DEG; }), color: COLORS[c], width: 2.2 });
    });
    Chart.line($("e5a"), { xlim: [0, 2], ylim: [0, 22], xlabel: "t [s]", ylabel: "tilt from the diagonal [deg]", series: ser, vlines: [{ x: 0.1, color: "rgba(255,90,79,.8)", label: "wheel X off" }], hlines: [{ y: AERIS_TWIN.ASSESS.fallCornerDeg, color: "rgba(255,90,79,.45)", label: "fall threshold (COM lean)", dash: [2, 4] }] });
    Chart.line($("e5b"), { xlim: [0, 10], xlabel: "t [s]", ylabel: "yaw ψ [deg], reconfigured", yzero: true, series: CTRLS.map(function (c) { return { x: out[c].yes.L.t, y: out[c].yes.L.psi.map(function (v) { return v / DEG; }), color: COLORS[c], width: 2 }; }) });
    table("e5t", ["Controller", "No reconfiguration", "With reconfiguration", "Max tilt after fault (°)", "Yaw at 10 s (°)", "E (J)"],
      CTRLS.map(function (c) {
        var y = out[c].yes, n = out[c].no, mx = 0; y.L.t.forEach(function (t, i) { if (t > 0.1) mx = Math.max(mx, y.L.geo[i]); });
        return { c: [sw(c), oc(n), oc(y), fx(mx / DEG, 2), mm(fx(y.m.yawFinal_deg, 0)), fx(y.m.energy_J, 2)] };
      }));
    var l = out.lqr, ranks = [AERIS_TWIN.cornerRank(D, [0, 1, 2]), AERIS_TWIN.cornerRank(D, [1, 2])];
    $("e5f").innerHTML = "Losing wheel X 0.1 s into the recovery is fatal if nothing changes: with the original allocation the cube falls about " + fx((l.no.fell || 0) - 0.1, 2) + " s after the fault. " +
      "Re-allocating the tilt torque to the two healthy wheels (8.12) " + (CTRLS.every(function (c) { return out[c].yes.fell == null; }) ? "holds the corner for all three controllers." : "holds the corner for " + CTRLS.filter(function (c) { return out[c].yes.fell == null; }).map(function (c) { return NAMES[c]; }).join(", ") + ".") + " The rank analysis in §07 predicts this trade: the controllability rank drops from " + ranks[0] + " to " + ranks[1] + " of 9, and the direction lost is yaw. The cube stays balanced but turns freely about its vertical diagonal (" + mm(fx(l.yes.m.yawFinal_deg, 0)) + "° after 10 s under LQR), and its margin against new pushes shrinks.";
    wsButtons("e5", [{ label: "LQR, reallocation on", cfg: out.lqr.yes.cfg }, { label: "LQR, reallocation off", cfg: out.lqr.no.cfg }]);
  }
  function exp6() {
    var ests = ["accel", "gyro", "cf", "kf"], out = {}, cols = { accel: INK.tertiary, gyro: INK.secondary, cf: INK.secondary, kf: INK.primary };
    ests.forEach(function (e) { out[e] = sim("edge", { initial: ini(1), duration_s: 30, estimator: { type: e }, seed: 7 }); });
    out.naive = sim("edge", { initial: ini(1), duration_s: 30, estimator: { type: "kf", Rkf_deg: 0.3 }, seed: 7 });
    R.e6 = out;
    Chart.line($("e6a"), { xlim: [0, 30], ylim: [-6, 6], xlabel: "t [s]", ylabel: "estimate error θ̂ − θ [deg]",
      series: ests.map(function (e) { var L = out[e].L; return { x: L.t, y: L.t.map(function (_, i) { return (L.thHat[i] - L.th[i]) / DEG; }), color: cols[e], width: e === "accel" ? 1 : 1.8, alpha: e === "accel" ? 0.6 : 1, dash: e === "gyro" ? [6, 3] : e === "cf" ? [2, 3] : [] }; }) });
    function stats(r) { var L = r.L, n0 = Math.floor(L.t.length / 4), se = 0, st = 0, c = 0; for (var i = n0; i < L.t.length; i++) { se += Math.pow(L.thHat[i] - L.th[i], 2); st += L.th[i] * L.th[i]; c++; } return { e: Math.sqrt(se / Math.max(1, c)) / DEG, t: Math.sqrt(st / Math.max(1, c)) / DEG }; }
    var names = { accel: "Accelerometer only", gyro: "Gyro integration", cf: "Complementary (τ = 0.5 s)", kf: "Kalman θ, b  (√R = 2°)", naive: "Kalman, √R = 0.3° (noise only)" };
    table("e6t", ["Estimator", "RMS estimate error (°)", "RMS true tilt (°)", "Outcome"],
      ["accel", "gyro", "cf", "kf", "naive"].map(function (e) { var s2 = stats(out[e]), r = out[e]; return { c: ['<span class="sw" style="background:' + (cols[e] || INK.tertiary) + '"></span>' + names[e], r.fell != null && r.fell < 2 ? "—" : fx(s2.e, 3), r.fell != null && r.fell < 2 ? "—" : fx(s2.t, 3), oc(r)] }; }));
    var sc = stats(out.cf), sk = stats(out.kf), sa = stats(out.accel);
    $("e6f").innerHTML = "The accelerometer alone is noisy and, on a pivoting body, corrupted by the cube's own acceleration (RMS error " + fx(sa.e, 2) + "°). Integrating the gyro alone drifts with its 0.5 °/s bias" + (out.gyro.fell != null ? " until the cube falls at " + fx(out.gyro.fell, 1) + " s" : "") + ". The complementary filter balances well but keeps the " + fx(sc.e, 2) + "° bias offset predicted in §06. The Kalman filter estimates the bias and cuts the error to " + fx(sk.e, 3) + "°. " +
      (out.naive.fell != null ? "Tuned with the accelerometer's white noise only, the same filter trusts the corrupted tilt during the first recovery and the cube falls at " + fx(out.naive.fell, 2) + " s." : "");
    wsButtons("e6", ["kf", "cf", "gyro"].map(function (e) { return { label: names[e].split(" (")[0].split("  ")[0], cfg: out[e].cfg }; }));
  }
  function exp7() {
    var out = {}, cmdDeg = 10, cmd = cmdDeg * DEG;
    ["pid", "lqr"].forEach(function (c) { [1, 1.5].forEach(function (js) { out[c + js] = sim("corner", { controller: { type: c, knowsAttachments: false, reconfigureOnFailure: true }, initial: ini(0), duration_s: 8, commands: [{ id: "C1", type: "yaw_step", t_s: 0.5, angle_deg: cmdDeg }], uncertainty: { inertiaScale: js } }); }); });
    R.e7 = out;
    var ser = [];
    ["pid", "lqr"].forEach(function (c) { ser.push({ x: out[c + 1.5].L.t, y: out[c + 1.5].L.psi.map(function (v) { return v / DEG; }), color: COLORS[c], width: 1.4, dash: [5, 4], alpha: 0.85 }); ser.push({ x: out[c + 1].L.t, y: out[c + 1].L.psi.map(function (v) { return v / DEG; }), color: COLORS[c], width: 2.2 }); });
    Chart.line($("e7a"), { xlim: [0, 8], ylim: [-1, 12.5], xlabel: "t [s]", ylabel: "yaw ψ [deg]", series: ser, hlines: [{ y: cmdDeg, color: TK.alpha(INK.primary, 0.55), label: "command 10°" }] });
    function met(r) { var L = r.L, tsv = 0, os = 0, s2 = 0, n = 0, mt = 0, tEnd = L.t[L.t.length - 1]; for (var i = 0; i < L.t.length; i++) { var t = L.t[i]; if (t >= 0.5 && Math.abs(L.psi[i] - cmd) > 0.02 * cmd) tsv = t; os = Math.max(os, L.psi[i] - cmd); mt = Math.max(mt, L.geo[i]); if (t > tEnd - 1) { s2 += Math.abs(L.psi[i] - cmd); n++; } } return { ts: tsv - 0.5, os: os / DEG, sse: s2 / n / DEG, mt: mt / DEG, E: r.E, fell: r.fell }; }
    var rows = [];
    ["pid", "lqr"].forEach(function (c) { [1, 1.5].forEach(function (js) { var m = met(out[c + js]); rows.push({ m: m, c: [sw(c), "×" + fx(js, 1), fx(m.ts, 2), fx(m.os, 2), fx(m.sse, 3), fx(m.mt, 3), fx(m.E, 3), oc(out[c + js])] }); }); });
    table("e7t", ["Controller", "Plant inertia", "Yaw t<sub>s</sub>, 2 % (s)", "M<sub>p</sub> (°)", "e<sub>ss</sub> (°)", "Max tilt (°)", "E (J)", "Balance outcome"], rows);
    var mp = rows[0].m, ml = rows[2].m, ml5 = rows[3].m;
    $("e7f").innerHTML = "Rotation about the vertical diagonal feels no gravity, so this is the same problem as slewing a spacecraft, carried out while the cube stays balanced (max tilt " + fx(ml.mt, 3) + "°). LQR settles the 10° slew in " + fx(ml.ts, 2) + " s" + (ml.os < 0.01 ? " with no overshoot" : " with " + fx(ml.os, 2) + "° overshoot") + ", and in " + fx(ml5.ts, 2) + " s when the plant is 50% heavier than its model. The PID's integral term adds " + fx(mp.os, 2) + "° of overshoot and stretches settling to " + fx(mp.ts, 2) + " s. (The yaw settling time here uses a 2 % band around the command; the balance outcome uses the shared rules of §09.)";
    wsButtons("e7", [{ label: "LQR, inertia ×1", cfg: out.lqr1.cfg }, { label: "LQR, inertia ×1.5", cfg: out["lqr1.5"].cfg }, { label: "PID, inertia ×1", cfg: out.pid1.cfg }]);
  }
  var runGen = 0;
  function runAll() {
    var gen = ++runGen, q = [exp1, exp2, exp3, exp5, exp6, exp7];
    function step() {
      if (gen !== runGen) return;
      var f = q.shift();
      if (f) { try { f(); } catch (e) { if (window.console) console.error(e); } setTimeout(step, 0); return; }
      renderCalcs();
    }
    setTimeout(step, 0);
    if (doaState.done || doaState.running) { doaState.done = false; exp4(true); }
    else { var st = $("e4st"); if (st) st.textContent = "edge · simulated · queued"; }
  }

  /* ---------------- TOC scrollspy ---------------- */
  function initToc() {
    var links = [].slice.call(document.querySelectorAll("#toc a")), map = {};
    links.forEach(function (a) { map[a.getAttribute("href").slice(1)] = a; });
    if (!("IntersectionObserver" in window)) return;
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (e.isIntersecting) {
          links.forEach(function (a) { a.classList.remove("on"); });
          var a = map[e.target.id]; if (a) { a.classList.add("on"); if (window.innerWidth <= 900) { var toc = $("toc"); toc.scrollTo({ left: a.offsetLeft - 16, behavior: "smooth" }); } }
          if (e.target.id === "twin-results") { /* start DOA when results come into view */ }
        }
      });
    }, { rootMargin: "-30% 0px -60% 0px" });
    [].forEach.call(document.querySelectorAll(".twin-sec"), function (s) { io.observe(s); });
    var io2 = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting && !doaState.done && !doaState.running) exp4(); }); }, { rootMargin: "200px 0px" });
    io2.observe($("exp4"));
  }

  /* ---------------- lifecycle ---------------- */
  function showValidity(v, err) {
    var box = $("pValid"), main = document.querySelector(".twin-main");
    var bad = err || (v && v.errors.length);
    if (box) box.innerHTML = bad ? '<div class="vb err"><b>These parameters are not physically consistent, so nothing below was recomputed.</b><ul>' + (err ? "<li>" + err + "</li>" : v.errors.map(function (e) { return "<li>" + e.message + "</li>"; }).join("")) + "</ul><p>Results further down still show the last consistent parameter set.</p></div>" : (v && v.warnings.length ? '<div class="vb warn"><ul>' + v.warnings.map(function (e) { return "<li>" + e.message + "</li>"; }).join("") + "</ul></div>" : "");
    if (main) main.classList.toggle("stale", !!bad);
  }
  function recompute() {
    var v = AERIS_TWIN.validateParams(AERIS_TWIN.clone(p));
    if (v.errors.length) { showValidity(v); return; }
    var D2; try { D2 = AERIS_TWIN.design(p); } catch (e) { showValidity(null, "Controller design failed: " + e.message); return; }
    showValidity(v); D = D2; edited();
    derivedGrid(); updateLive(); renderCalcs(); figures(); runAll();
  }
  /* what each controller measures, assumes and adapts (one source: js/platform/controllers.js) */
  function controllerSummary() {
    var tb = document.querySelector("#ctlSummary tbody"), pl = $("ctlPlanned"); if (!tb || typeof AERIS_CONTROLLERS === "undefined") return;
    function list(a) { return a.map(function (x) { return esc(x); }).join("; "); }
    tb.innerHTML = AERIS_CONTROLLERS.ORDER.map(function (k) { var c = AERIS_CONTROLLERS.get(k); return "<tr><th scope=\"row\">" + (typeof AERIS_BADGES !== "undefined" ? AERIS_BADGES.controller(k, { long: true }) : esc(c.name)) + "</th><td>" + list(c.measures) + "</td><td>" + list(c.assumes) + "</td><td>" + esc(c.adapts) + "</td></tr>"; }).join("");
    if (pl) pl.textContent = "Not implemented in this browser engine: " + AERIS_CONTROLLERS.PLANNED.map(function (x) { return x.name + " (" + x.where + ")"; }).join("; ") + ".";
  }
  function show() {
    if (!inited) {
      inited = true;
      controllerSummary();
      renderStaticTex($("view-twin"));
      buildParams(); derivedGrid(); updateLive(); figures(); runAll(); renderCalcs(); initToc(); bindWs();
      fixGreek($("view-twin"));
      [].forEach.call(document.querySelectorAll("[data-g]"), function (b) { b.addEventListener("click", function () { p.g = +b.getAttribute("data-g"); syncInputs(); recompute(); }); });
      $("pReset").addEventListener("click", function () { p = AERIS_TWIN.clone(AERIS_TWIN.NOMINAL); syncInputs(); recompute(); });
    } else {
      Chart.redrawVisible($("view-twin"));
    }
  }
  function params() { return { p: p, D: D }; }
  /* the exact setup behind an "Open in the workspace" button (read-only copy; used by the browser tests) */
  function workspaceConfig(key) { return WSCFG[key] ? AERIS_TWIN.clone(WSCFG[key]) : null; }
  return { show: show, params: params, tex: tex, renderStaticTex: renderStaticTex, workspaceConfig: workspaceConfig };
})();

/* =====================================================================
   AERIS · ReplayAdapter — saved experiments: runs in this browser's
   library, imported files and the built-in examples. It never computes
   new results except to build an example recording that is not stored
   yet (through the local engine, from the example's fixed setup).
   ===================================================================== */
var ReplayAdapter = (function () {
  "use strict";
  var RUNS = typeof AERIS_RUNS !== "undefined" ? AERIS_RUNS : require("../runs.js");
  var EX = typeof AERIS_EXAMPLES !== "undefined" ? AERIS_EXAMPLES : require("../platform/examples.js");
  var LOCAL = typeof LocalSimulatorAdapter !== "undefined" ? LocalSimulatorAdapter : require("./local-simulator.js");
  var name = "replay";
  function available() { return { ok: true, reason: null }; }
  function capabilities() { return { kind: "replay", single: false, sweep: null, persistent: RUNS.persistent, live: false }; }
  function list() { return RUNS.list(); }
  function load(id) { return RUNS.load(id); }
  /* an example recording: the stored copy if present, otherwise computed from the fixed setup and stored */
  function example(id) {
    var ex = EX.get(id); if (!ex) return { ok: false, error: "Unknown example '" + id + "'." };
    var l = RUNS.load(id); if (l.ok) return { ok: true, record: l.record, stored: true };
    var res = LOCAL.simulateSync(ex.cfg());
    if (!res.ok) return { ok: false, error: "Example setup failed validation: " + res.outcome.reason };
    var rec = RUNS.fromSimulation(res, { id: ex.id, name: "Example · " + ex.name, collection: "example", note: ex.note, origin: LOCAL.origin({ mode: "demo" }) });
    var s = RUNS.save(rec); rec._unsaved = !s.ok;
    return { ok: true, record: rec, stored: s.ok, saveError: s.ok ? null : s.error };
  }
  /* the same example computed without touching storage (used by the home page's preview replay) */
  function exampleRecord(id) {
    var ex = EX.get(id); if (!ex) return null;
    var res = LOCAL.simulateSync(ex.cfg()); if (!res.ok) return null;
    return RUNS.fromSimulation(res, { id: ex.id, name: "Example · " + ex.name, collection: "example", note: ex.note, origin: LOCAL.origin({ mode: "demo" }) });
  }
  return { name: name, kind: "replay", label: "Saved experiments", available: available, capabilities: capabilities, list: list, load: load, example: example, exampleRecord: exampleRecord, examples: EX.LIST };
})();
if (typeof module !== "undefined") module.exports = ReplayAdapter;

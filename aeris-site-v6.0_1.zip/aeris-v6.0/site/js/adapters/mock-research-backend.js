/* =====================================================================
   AERIS · MOCK research backend — an in-memory stand-in for the Python
   backend's REST API, used by the tests and, only when explicitly enabled
   (AERIS_CONFIG.researchApi.mock = true), to preview SIMULATION mode.

   It is a protocol mock, not a physics source. Jobs step through the real
   state machine one state per poll so the job UI can be exercised; the
   numbers inside its runs and sweeps are computed by the browser engine and
   every result it returns is marked MOCK (provenance.mock = true,
   origin.engine = "mock-research-backend"). Nothing it returns may be
   presented as backend research output.
   ===================================================================== */
var MockResearchBackend = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var RUNS = typeof AERIS_RUNS !== "undefined" ? AERIS_RUNS : require("../runs.js");
  var SWEEP = typeof AERIS_SWEEP !== "undefined" ? AERIS_SWEEP : require("../platform/sweep.js");
  function createTransport(opts) {
    opts = opts || {};
    var jobs = {}, runs = {}, sweeps = {}, seq = 0, log = [];
    function reply(status, obj) { var txt = JSON.stringify(obj); return Promise.resolve({ ok: status < 400, status: status, text: function () { return Promise.resolve(txt); } }); }
    function err(status, code, message, details) { return reply(status, { error: { code: code, message: message, details: details || [], retryable: status >= 500 } }); }
    function newJob(kind, total) { seq += 1; var id = "mock-job-" + seq; var j = { schema: "aeris-job/1", id: id, kind: kind, state: "queued", progress: { done: 0, total: total, failed: 0, fraction: 0 }, message: "MOCK backend: queued", error: null, result_ref: null, mock: true }; jobs[id] = j; return j; }
    var ORDER = ["queued", "initializing", "running", "analyzing", "complete"];
    function step(j) {   // advance one state (or one quarter of the runs) per poll
      if (j.state === "complete" || j.state === "failed" || j.state === "cancelled") return;
      if (j.state === "running" && j.progress.done < j.progress.total) { j.progress.done = Math.min(j.progress.total, j.progress.done + Math.max(1, Math.ceil(j.progress.total / 4))); j.progress.fraction = j.progress.done / j.progress.total; j.message = "MOCK backend: running"; return; }
      j.state = ORDER[ORDER.indexOf(j.state) + 1]; j.message = "MOCK backend: " + j.state;
    }
    function transport(url, init) {
      log.push({ method: init.method, url: url, body: init.body ? JSON.parse(init.body) : null });
      if (opts.failAll) return Promise.reject(new Error("mock network failure"));
      var m = /\/api\/v1(\/.*)$/.exec(url); if (!m) return err(404, "not_found", "Unknown path");
      var path = m[1], body = init.body ? JSON.parse(init.body) : null, x;
      if (init.method === "GET" && path === "/health") return reply(200, { status: "ok", mock: true, engine_version: "mock (browser engine " + TWIN.VERSION.model + ")" });
      if (init.method === "GET" && path === "/capabilities") return reply(200, { kind: "simulation", engine: "mock-research-backend", single: true, controllerSet: true, sweep: { modes: ["grid", "random", "montecarlo"], maxRuns: 2000, maxDuration_s: 20 }, mock: true });
      if (init.method === "POST" && path === "/simulations") {
        var v = TWIN.validateConfig(body && body.config);
        if (!v.ok) return err(422, "invalid_config", "The configuration is not valid.", v.errors);
        var res = TWIN.simulate(body.config), rec = RUNS.fromSimulation(res, { name: "MOCK backend · " + ((body.meta && body.meta.name) || RUNS.autoName(v.config)), note: "Returned by the MOCK research backend (computed in this browser). Not backend output.", origin: { kind: "simulation", engine: "mock-research-backend", engine_version: TWIN.VERSION.model, adapter: "research-api", mode: "simulation" } });
        rec.provenance = "MOCK backend: " + rec.provenance; runs[rec.id] = rec;
        var j = newJob("single", 1); j.result_ref = { kind: "run", id: rec.id };
        return reply(202, { job: j });
      }
      if (init.method === "POST" && path === "/sweeps") {
        var sv = SWEEP.validate(body && body.sweep, { limits: { maxRuns: 2000, maxDuration_s: 20 } });
        if (!sv.ok) return err(422, "invalid_sweep", "The sweep is not valid.", sv.errors);
        var specs = SWEEP.expand(sv.def), rows = specs.map(function (sp) { return SWEEP.rowOf(sp, TWIN.simulate(sp.config)); });
        var sid = "mock-sweep-" + (seq + 1), sw = { schema: SWEEP.SCHEMA_ID, id: sid, name: "MOCK · " + (sv.def.name || "sweep"), created: new Date().toISOString(), definition: sv.def, engine: { engine: "mock-research-backend", engine_version: TWIN.VERSION.model }, provenance: { source: "simulation", mock: true, note: "MOCK backend output computed in this browser. Not research data." }, rows: rows, analysis: SWEEP.analyze(sv.def, rows) };
        sweeps[sid] = sw; var js = newJob("sweep", rows.length); js.result_ref = { kind: "sweep", id: sid };
        return reply(202, { job: js });
      }
      if ((x = /^\/jobs\/([^/]+)$/.exec(path)) && init.method === "GET") { var jj = jobs[decodeURIComponent(x[1])]; if (!jj) return err(404, "not_found", "No such job"); step(jj); return reply(200, jj); }
      if ((x = /^\/jobs\/([^/]+)\/cancel$/.exec(path)) && init.method === "POST") { var jc = jobs[decodeURIComponent(x[1])]; if (!jc) return err(404, "not_found", "No such job"); if (["complete", "failed", "cancelled"].indexOf(jc.state) < 0) { jc.state = "cancelled"; jc.message = "MOCK backend: cancelled"; } return reply(200, jc); }
      if ((x = /^\/runs\/([^/]+)$/.exec(path)) && init.method === "GET") { var r = runs[decodeURIComponent(x[1])]; return r ? reply(200, r) : err(404, "not_found", "No such run"); }
      if ((x = /^\/sweeps\/([^/]+)$/.exec(path)) && init.method === "GET") { var s = sweeps[decodeURIComponent(x[1])]; return s ? reply(200, s) : err(404, "not_found", "No such sweep"); }
      if (init.method === "POST" && path === "/compare") return reply(200, { mock: true, runs: (body && body.run_ids) || [], note: "MOCK backend: comparison is computed in the browser." });
      return err(404, "not_found", "Unknown endpoint " + init.method + " " + path);
    }
    transport.log = log; transport.jobs = jobs;
    return transport;
  }
  return { createTransport: createTransport };
})();
if (typeof module !== "undefined") module.exports = MockResearchBackend;

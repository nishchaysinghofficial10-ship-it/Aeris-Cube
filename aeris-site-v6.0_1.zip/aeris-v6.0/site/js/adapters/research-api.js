/* =====================================================================
   AERIS · ResearchApiAdapter — client for the Python research backend
   (backend/, REST + WebSocket under /api/v1; contract in docs/BACKEND_INTEGRATION.md).

   Availability distinguishes CONFIGURED from REACHABLE: a base URL alone does not make
   SIMULATION mode selectable. probe() calls GET /health and GET /capabilities; only a
   successful probe marks the backend reachable, and only the capabilities it REPORTED
   are used (nothing is guessed). Probes repeat while the page is open.

   Jobs are followed over the WebSocket /live/{jobId} when a wsUrl is configured, with
   polling as the fallback (and after a dropped connection, with reconnection attempts).
   Every job message carries the server's update sequence number; stale and duplicate
   updates are ignored; a terminal job never changes again. result_ref is copied from
   every job the server returns (poll, cancel, WebSocket). A cancelled sweep's partial
   result is fetched and labelled PARTIAL; a failed cancel request is reported and retried.
   It never invents results: every run or sweep it returns was fetched and validated here.
   ===================================================================== */
var ResearchApiAdapter = (function () {
  "use strict";
  var JOBS = typeof AERIS_JOBS !== "undefined" ? AERIS_JOBS : require("../platform/jobs.js");
  var RUNS = typeof AERIS_RUNS !== "undefined" ? AERIS_RUNS : require("../runs.js");
  var SCHEMA = typeof AERIS_SCHEMA !== "undefined" ? AERIS_SCHEMA : require("../platform/schema.js");
  var SWEEP = typeof AERIS_SWEEP !== "undefined" ? AERIS_SWEEP : require("../platform/sweep.js");
  var API = "/api/v1";
  var CHAIN = ["queued", "initializing", "running", "analyzing", "complete"];
  var TERMINAL = ["complete", "failed", "cancelled"];

  function ApiError(code, message, extra) { var e = { code: code, message: message, retryable: false, status: null, details: [] }; Object.keys(extra || {}).forEach(function (k) { e[k] = extra[k]; }); return e; }
  function Adapter(opts) {
    opts = opts || {};
    this.name = "research-api"; this.kind = "simulation"; this.label = opts.mock ? "Research backend (MOCK)" : "AERIS research backend (Python)";
    this.baseUrl = String(opts.baseUrl || "").replace(/\/+$/, "");
    this.wsUrl = opts.wsUrl ? String(opts.wsUrl).replace(/\/+$/, "") : null;
    this.transport = opts.transport || (typeof fetch !== "undefined" ? function (u, o) { return fetch(u, o); } : null);
    this.WS = opts.WebSocket || (typeof WebSocket !== "undefined" ? WebSocket : null);
    this.pollMs = opts.pollMs == null ? 1000 : opts.pollMs; this.timeoutMs = opts.timeoutMs || 15000; this.maxPolls = opts.maxPolls || 100000;
    this.cancelRetries = opts.cancelRetries || 5;
    this.mock = !!opts.mock; this._caps = null;
    this.reachable = null; this.probeError = null; this.lastProbe = null; this.health = null; this._probing = null;
    this.wait = opts.wait || function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    this.now = opts.now || function () { return Date.now(); };
    this.listeners = [];
    this.token = typeof opts.token === "function" ? opts.token : null;   // v6.0: bearer token of a jwt-mode backend (js/connect/auth.js)
  }
  var P = Adapter.prototype;
  P.configured = function () { return !!this.baseUrl && !!this.transport; };
  P.available = function () {
    if (!this.baseUrl) return { ok: false, reason: "No research backend is configured. Set researchApi.baseUrl in js/site-content.js once the Python backend is running (backend/README.md)." };
    if (!this.transport) return { ok: false, reason: "This browser cannot make HTTP requests (no fetch)." };
    if (this.reachable === true && this._caps && this._caps.reported) return { ok: true, reason: null };
    if (this.reachable === false) return { ok: false, reason: "The research backend is configured (" + this.baseUrl + ") but not reachable: " + (this.probeError && this.probeError.message || "no answer") + ". Check that it is running and allows this site's origin (CORS)." };
    return { ok: false, reason: "The research backend at " + this.baseUrl + " is configured; its health and capabilities have not been confirmed yet." };
  };
  P.status = function () { return { configured: this.configured(), reachable: this.reachable, lastProbe: this.lastProbe, error: this.probeError, health: this.health, capabilitiesReported: !!(this._caps && this._caps.reported) }; };
  P.onStatus = function (fn) { this.listeners.push(fn); var self = this; return function () { self.listeners = self.listeners.filter(function (f) { return f !== fn; }); }; };
  P._emit = function () { var s = this.status(); this.listeners.slice().forEach(function (fn) { try { fn(s); } catch (e) { /* ignore */ } }); };
  /* only what the backend REPORTED; before a successful probe nothing is claimed */
  P.capabilities = function () { return this._caps || { kind: "simulation", engine: "aeris-research-backend", label: this.label, reported: false, single: null, controllerSet: null, sweep: null, live: !!this.wsUrl }; };
  /* health + capability discovery; concurrent calls share one probe */
  P.probe = function () {
    var self = this;
    if (!this.configured()) return Promise.resolve(this.status());
    if (this._probing) return this._probing;
    this._probing = this.request("GET", "/health").then(function (h) {
      if (!h || h.status !== "ok") throw ApiError("unhealthy", "The backend answered /health without status 'ok'.");
      self.health = h;
      return self.refreshCapabilities();
    }).then(function () { self.reachable = true; self.probeError = null; }, function (e) { self.reachable = false; self.probeError = { code: e && e.code || "network", message: e && e.message || String(e) }; self._caps = null; })
      .then(function () { self.lastProbe = new Date(self.now()).toISOString(); self._probing = null; self._emit(); return self.status(); });
    return this._probing;
  };
  /* one HTTP request with JSON in and out; errors are normalised to { code, message, status, retryable, details } */
  P.request = function (method, path, body) {
    var self = this;
    if (!this.configured()) return Promise.reject(ApiError("unavailable", this.available().reason));
    var init = { method: method, headers: { "Accept": "application/json", "X-AERIS-Client": "aeris-web/5.1" }, credentials: "include" };
    var tok = this.token ? this.token() : null;
    if (tok) init.headers.Authorization = "Bearer " + tok;
    if (body !== undefined) { init.headers["Content-Type"] = "application/json"; init.body = JSON.stringify(body); }
    var timer, timeout = new Promise(function (_, rej) { timer = setTimeout(function () { rej(ApiError("timeout", "The research backend did not answer within " + self.timeoutMs / 1000 + " s.", { retryable: true })); }, self.timeoutMs); });
    var call = Promise.resolve().then(function () { return self.transport(self.baseUrl + API + path, init); }).then(function (res) {
      return Promise.resolve(res.text ? res.text() : res.json ? res.json().then(JSON.stringify) : "").then(function (txt) {
        var data = null; if (txt) { try { data = JSON.parse(txt); } catch (e) { throw ApiError("bad_response", "The research backend sent a response that is not JSON (HTTP " + res.status + ").", { status: res.status }); } }
        if (res.ok === false || (res.status && res.status >= 400)) {
          var er = data && data.error ? data.error : {};
          throw ApiError(er.code || ("http_" + res.status), er.message || ("The research backend returned HTTP " + res.status + "."), { status: res.status, retryable: !!er.retryable || res.status >= 500 || res.status === 429, details: er.details || [] });
        }
        return data;
      });
    }, function (e) { throw e && e.code ? e : ApiError("network", "Could not reach the research backend: " + (e && e.message || e), { retryable: true }); });
    return Promise.race([call, timeout]).then(function (d) { clearTimeout(timer); return d; }, function (e) { clearTimeout(timer); throw e; });
  };
  P.getHealth = function () { return this.request("GET", "/health"); };
  P.refreshCapabilities = function () { var self = this; return this.request("GET", "/capabilities").then(function (c) { if (!c || typeof c !== "object") throw ApiError("bad_response", "Capabilities are not an object."); c.reported = true; self._caps = c; return c; }); };
  P.validate = function (cfg) { return this.request("POST", "/validate", { config: cfg }); };
  P.validateSweep = function (def) { return this.request("POST", "/validate", { sweep: def }); };

  /* ---------------- jobs ---------------- */
  function checkJob(j) {
    if (!j || typeof j !== "object" || !j.id || !JOBS.STATES[j.state]) throw ApiError("bad_response", "The research backend sent a job without a known state (got '" + (j && j.state) + "').");
    return j;
  }
  /* move the local mirror to the server's state through legal transitions (servers may skip states);
     stale (lower seq) and duplicate updates are ignored; a terminal mirror never changes */
  function syncState(local, remote) {
    if (JOBS.isTerminal(local)) return false;
    if (remote.seq != null) { if (local._seq != null && remote.seq <= local._seq) return false; local._seq = remote.seq; }
    if (remote.result_ref) local.result_ref = remote.result_ref;
    if (remote.cancel_requested) local.cancel_requested = true;
    var to = remote.state, rp = remote.progress || {};
    if (local.state === to) {
      if (rp.total && !local.progress.total) local.progress.total = rp.total;
      if ((to === "running" || to === "analyzing") && rp.done != null) { var add = Math.max(0, rp.done - local.progress.done); if (add && local.state === "running") JOBS.advance(local, add, Math.max(0, (rp.failed || 0) - local.progress.failed)); }
      if (remote.message) local.message = remote.message;   // shown with the next state or progress update
      return true;
    }
    if (to === "failed" || to === "cancelled") {
      if (rp.done > local.progress.done) {
        // finished runs the mirror has not seen yet: walk to RUNNING so the count is kept, then stop
        for (var k = CHAIN.indexOf(local.state) + 1; k <= CHAIN.indexOf("running"); k++) JOBS.move(local, CHAIN[k], { total: rp.total });
        if (local.state === "running") JOBS.advance(local, rp.done - local.progress.done, Math.max(0, (rp.failed || 0) - local.progress.failed));
      }
      JOBS.move(local, to, { error: remote.error || null, message: remote.message }); return true;
    }
    var a = CHAIN.indexOf(local.state), b = CHAIN.indexOf(to);
    if (b < a) return false;   // never step backwards
    for (var i = a + 1; i <= b; i++) {
      JOBS.move(local, CHAIN[i], { message: i === b ? remote.message : undefined, total: rp.total });
      if (CHAIN[i] === "running") {
        var done = b > i ? (rp.done != null ? rp.done : local.progress.total) : (rp.done || 0);
        if (done > local.progress.done) JOBS.advance(local, done - local.progress.done, Math.max(0, (rp.failed || 0) - local.progress.failed));
      }
    }
    return true;
  }
  /* send (or retry) a requested cancellation; transport failures are reported on the job and retried */
  P._sendCancel = function (local, serverId) {
    var self = this;
    local._cancelTries = (local._cancelTries || 0) + 1;
    return this.request("POST", "/jobs/" + encodeURIComponent(serverId) + "/cancel").then(function (j) {
      local._cancelSent = true; local.cancelError = null; syncState(local, checkJob(j)); return j;
    }, function (e) {
      local.cancelError = { code: e.code, message: "The cancel request did not reach the backend (" + e.message + "); " + (local._cancelTries < self.cancelRetries ? "retrying." : "giving up; the job may still be running on the backend.") };
      if (local._cancelTries >= self.cancelRetries) local._cancelSent = true;
      (local._subs || []).forEach(function (fn) { try { fn(local); } catch (x) { /* ignore */ } });
    });
  };
  P.follow = function (local, serverId) {
    var self = this, polls = 0, ws = null, wsFailures = 0, wsLive = false;
    function openWs() {
      var url = self.liveUrl(serverId);
      if (!url || !self.WS || wsFailures >= 3 || JOBS.isTerminal(local)) return;
      try { ws = new self.WS(url); } catch (e) { wsFailures++; return; }
      ws.onopen = function () { wsLive = true; local.transport = "websocket"; };
      ws.onmessage = function (ev) {
        var m; try { m = JSON.parse(typeof ev.data === "string" ? ev.data : String(ev.data)); } catch (e) { return; }
        if (m && m.type === "job" && m.job) { try { syncState(local, checkJob(m.job)); } catch (e) { /* malformed: polling decides */ } }
      };
      ws.onclose = function () { wsLive = false; if (!JOBS.isTerminal(local)) { wsFailures++; local.transport = "polling"; } };
      ws.onerror = function () { wsLive = false; };
    }
    function poll() {
      if (JOBS.isTerminal(local)) return done();
      if (local._cancelRequested && !local._cancelSent) return self._sendCancel(local, serverId).then(next);
      if (ws && wsLive && polls % 10 !== 0) return next();          // WebSocket carries the updates; poll now and then as a check
      if (ws && !wsLive && wsFailures < 3 && ws.readyState === 3) openWs();   // reconnect after a drop
      return self.request("GET", "/jobs/" + encodeURIComponent(serverId)).then(function (j) { syncState(local, checkJob(j)); return next(); });
    }
    function next() { if (JOBS.isTerminal(local)) return done(); if (++polls > self.maxPolls) throw ApiError("timeout", "Stopped following the job after " + polls + " polls."); return self.wait(self.pollMs).then(poll); }
    function done() { if (ws) { try { ws.close(); } catch (e) { /* ignore */ } } return local; }
    local.transport = "polling";
    openWs();
    return poll();
  };
  function mirror(self, kind, j, total) {
    var local = JOBS.create({ id: j.id, kind: kind, total: total || (j.progress && j.progress.total) || 0, adapter: self.name, mode: "simulation", mock: self.mock });
    local.server_id = j.id; syncState(local, j); return local;
  }
  P.runSingle = function (cfg, meta) {
    var self = this;
    var body = { config: cfg, meta: meta || {}, client: { site: RUNS.SITE_VERSION } };
    if (meta && meta.parameter_set) body.parameter_set = meta.parameter_set;   // a stored (measured) parameter set, applied by the backend
    return this.request("POST", "/simulations", body).then(function (resp) {
      var local = mirror(self, "single", checkJob(resp.job), 1);
      self.lastJob = local;
      return self.follow(local, local.server_id).then(function () { return self._finishSingle(local); });
    });
  };
  P._finishSingle = function (local) {
    var self = this;
    if (local.state !== "complete") {
      var partial = local.result_ref && local.result_ref.kind === "run";
      if (partial) return this.getRun(local.result_ref.id).then(function (rec) { return { ok: true, record: rec, job: local, note: "The job was cancelled after the run finished; the finished run is kept." }; });
      return { ok: false, job: local, result: { ok: false, outcome: { code: "invalid", label: local.state === "cancelled" ? "Run cancelled" : "Invalid configuration", reason: (local.error && local.error.message) || local.message }, errors: (local.error && local.error.details) || [] } };
    }
    var ref = local.result_ref; if (!ref || ref.kind !== "run") throw ApiError("bad_response", "The finished job did not name a run.");
    return self.getRun(ref.id).then(function (rec) { return { ok: true, record: rec, job: local }; });
  };
  P.getRun = function (id) {
    var self = this;
    return this.request("GET", "/runs/" + encodeURIComponent(id)).then(function (rec) {
      if (!self.mock && (!rec || !rec.origin || rec.origin.engine !== "aeris-research-backend" || rec.origin.adapter !== "research-api")) throw ApiError("bad_record", "The backend's run does not identify aeris-research-backend / research-api as its origin.");
      var v = RUNS.validateRecord(rec);
      if (!v.ok) throw ApiError("bad_record", "The backend's run failed validation: " + v.errors.slice(0, 3).join(" "));
      return RUNS.completeRecord(rec, v);
    });
  };
  P.submitSweep = function (def) {
    var self = this, local = JOBS.create({ kind: "sweep", total: 0, adapter: this.name, mode: "simulation", mock: this.mock });
    local.definition = def;
    this.request("POST", "/sweeps", def && def.parameter_set ? { sweep: def, parameter_set: def.parameter_set } : { sweep: def }).then(function (resp) {
      var j = checkJob(resp.job); local.server_id = j.id; local.id = j.id; syncState(local, j);
      return self.follow(local, j.id);
    }).then(function () { return self._fetchSweepResult(local); }).catch(function (e) {
      if (!JOBS.isTerminal(local)) JOBS.move(local, "failed", { error: e });
      else local.error = local.error || e;
      (local._subs || []).forEach(function (fn) { try { fn(local); } catch (x) { /* ignore */ } });
    });
    return local;
  };
  /* the result of a finished, cancelled (partial) or interrupted sweep, fetched and labelled */
  P._fetchSweepResult = function (local) {
    var self = this;
    if (!local.result_ref || local.result_ref.kind !== "sweep") return;
    if (local.state === "failed" && !(local.error && local.error.code === "interrupted")) return;
    // cancelled before any run finished: the backend keeps the (empty) sweep record for provenance; there is no result to show
    if (local.state === "cancelled" && !(local.progress && local.progress.done > 0)) return;
    return this.request("GET", "/sweeps/" + encodeURIComponent(local.result_ref.id)).then(function (sw) {
      if (!sw || sw.schema !== SCHEMA.VERSIONS.sweep || !Array.isArray(sw.rows)) throw ApiError("bad_response", "The backend's sweep is not an aeris-sweep/1 result with rows.");
      if (local.state !== "complete") sw.partial = sw.partial || sw.rows.length < (sw.total || local.progress.total);
      if (!sw.analysis && sw.rows.length) {
        try { sw.analysis = SWEEP.analyze(sw.definition, sw.rows); sw.analysis_note = "Analysis computed in this browser from the backend's saved rows (the backend did not finish its analysis)."; } catch (e) { sw.analysis = null; }
      }
      if (self.mock) { sw.provenance = sw.provenance || {}; sw.provenance.mock = true; }
      sw.job = JOBS.toJSON(local);
      local.result = sw;
      (local._subs || []).forEach(function (fn) { try { fn(local); } catch (e) { /* ignore */ } });
      return sw;
    });
  };
  P.cancelJob = function (job) {
    if (JOBS.isTerminal(job)) return Promise.resolve(job);
    job._cancelRequested = true;
    if (job.server_id && !job._cancelSent) return this._sendCancel(job, job.server_id).then(function () { return job; });
    return Promise.resolve(job);
  };
  /* re-run a stored backend run on the backend and compare (identical / max difference) */
  P.reproduce = function (rec) {
    var self = this;
    return this.request("POST", "/runs/" + encodeURIComponent(rec.id) + "/reproduce").then(function (resp) {
      var local = mirror(self, "single", checkJob(resp.job), 1);
      return self.follow(local, local.server_id).then(function () { return self._finishSingle(local); });
    }).then(function (out) {
      if (!out.ok) return { ok: false, identical: false, message: out.result.outcome.reason };
      var rep = (out.record.reproduction && out.record.reproduction.reproduces) || {};
      return { ok: true, identical: !!rep.identical, withinTolerance: !!rep.within_tolerance, verdict: rep.verdict || (rep.identical ? "identical" : "different"), explanations: rep.explanations || [], configChanges: rep.config_changes || [], sameOutcome: !!rep.same_outcome, maxAbsDiff: rep.max_abs_diff, rows: rep.rows, outcome: out.record.outcome, model: out.record.origin.engine_version, record: out.record, report: rep, engine: "aeris-research-backend" };
    });
  };
  /* v5: simulate the saved setup again under the current metric definitions, as a new record with lineage */
  P.reanalyze = function (rec) {
    var self = this;
    return this.request("POST", "/runs/" + encodeURIComponent(rec.id) + "/reanalyze").then(function (resp) {
      var local = mirror(self, "single", checkJob(resp.job), 1);
      return self.follow(local, local.server_id).then(function () { return self._finishSingle(local); });
    }).then(function (out) {
      if (!out.ok) return { ok: false, message: out.result.outcome.reason };
      return { ok: true, record: out.record, lineage: out.record.lineage || null };
    });
  };
  /* v5: the analysis of the rows stored for a sweep that stopped (cancelled / interrupted); returned, not stored */
  P.analyzeSweep = function (id) { return this.request("POST", "/sweeps/" + encodeURIComponent(id) + "/analyze"); };
  P.retryJob = function (id) { return this.request("POST", "/jobs/" + encodeURIComponent(id) + "/retry"); };
  P.getSweep = function (id) { return this.request("GET", "/sweeps/" + encodeURIComponent(id)); };
  /* one saved sweep row with the exact configuration the backend simulated for it */
  P.getSweepRow = function (id, index) { return this.request("GET", "/sweeps/" + encodeURIComponent(id) + "/rows/" + encodeURIComponent(String(index))); };
  P.getDataset = function (id) { return this.request("GET", "/datasets/" + encodeURIComponent(id)).then(function (d) { var v = SCHEMA.validateDataset(d); if (!v.ok) throw ApiError("bad_response", v.errors.join(" ")); return d; }); };
  P.createDataset = function (body) { return this.request("POST", "/datasets", body); };
  P.finalizeDataset = function (id) { return this.request("POST", "/datasets/" + encodeURIComponent(id) + "/finalize"); };
  P.compare = function (runIds) { return this.request("POST", "/compare", { run_ids: runIds }); };
  P.hardwareStatus = function () { return this.request("GET", "/hardware/status"); };
  /* live channel (WebSocket): messages { type: "job", seq, job } | { type: "log", level, text } | { type: "error", error } */
  P.liveUrl = function (jobId) { return this.wsUrl ? this.wsUrl + API + "/live/" + encodeURIComponent(jobId) : null; };
  return { create: function (o) { return new Adapter(o); }, Adapter: Adapter, syncState: syncState, API_PREFIX: API, TERMINAL: TERMINAL };
})();
if (typeof module !== "undefined") module.exports = ResearchApiAdapter;

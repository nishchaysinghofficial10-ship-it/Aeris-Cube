/* =====================================================================
   AERIS · LocalSimulatorAdapter — runs experiments on the AERIS Twin
   browser engine (js/core.js). Used in DEMO mode and offline. It is a
   real simulation of the nominal model, not canned data; its limits
   (run count, window length, corner-mode estimator) are stated in
   capabilities() and enforced before anything runs.

   Adapter interface (shared by every data source; see
   docs/BACKEND_INTEGRATION.md §4):
     name, kind, label
     available()        → { ok, reason }
     capabilities()     → what this engine models and accepts
     runSingle(cfg, meta)      → Promise<{ ok, record | result }>
     submitSweep(def, opts)    → job (js/platform/jobs.js), progress via AERIS_JOBS.subscribe
     cancelJob(job)
     cancellable(job)          → optional (v5.2): false once a cancel request can no longer take effect
   ===================================================================== */
var LocalSimulatorAdapter = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var RUNS = typeof AERIS_RUNS !== "undefined" ? AERIS_RUNS : require("../runs.js");
  var SWEEP = typeof AERIS_SWEEP !== "undefined" ? AERIS_SWEEP : require("../platform/sweep.js");
  var JOBS = typeof AERIS_JOBS !== "undefined" ? AERIS_JOBS : require("../platform/jobs.js");
  var name = "local-simulator";
  function available() { return { ok: true, reason: null }; }
  function capabilities() {
    return {
      kind: "simulation", engine: "aeris-twin-js", engine_version: TWIN.VERSION.model, label: "AERIS Twin browser engine",
      single: true, controllerSet: true,
      sweep: { modes: ["grid", "random", "montecarlo"], maxRuns: SWEEP.LIMITS.local.maxRuns, maxDuration_s: SWEEP.LIMITS.local.maxDuration_s },
      controllers: ["pid", "lqr", "adp", "none"], structures: ["decoupled"],
      estimators: { edge: ["ideal", "cf", "kf", "accel", "gyro"], corner: ["ideal"] },
      sensorModel: { edge: true, corner: false, imuRateIndependent: false },
      actuatorModel: { motorLag: true, wheelHealth: true },
      trueVsEstimated: { edge: "tilt and (Kalman filter) gyro bias", corner: null },
      live: false,
      // v5.2 (review G4): the job states in which cancelJob takes effect. Once every run has finished (ANALYZING) the
      // browser engine does not interrupt its analysis — one short synchronous computation; a cancel request that
      // arrives after the last run is reported on the job and the complete result is kept (never labelled PARTIAL).
      cancel: { states: ["queued", "initializing", "running"] }
    };
  }
  function origin(meta) { return { kind: "simulation", engine: "aeris-twin-js", engine_version: TWIN.VERSION.model, adapter: name, mode: (meta && meta.mode) || "demo" }; }
  /* synchronous access for pages that document this engine itself (AERIS Twin reference experiments) */
  function simulateSync(cfg, opts) { return TWIN.simulate(cfg, opts); }
  function recordFrom(res, meta) { return RUNS.fromSimulation(res, Object.assign({}, meta || {}, { origin: origin(meta) })); }
  var CFG = typeof AERIS_CFG !== "undefined" ? AERIS_CFG : require("../platform/config.js");
  function runSingle(cfg, meta) {
    return new Promise(function (resolve, reject) {
      setTimeout(function () {
        var res;
        // research-backend features are refused, never dropped: the browser engine would otherwise ignore them
        var cap = CFG.validateFor(cfg, "browser").errors.filter(function (e) { return e.kind === "capability"; });
        if (cap.length) { resolve({ ok: false, result: { ok: false, outcome: { code: "invalid", label: TWIN.OUTCOMES.invalid.label, reason: cap.map(function (e) { return e.message; }).join(" ") }, errors: cap } }); return; }
        try { res = TWIN.simulate(cfg); } catch (e) { reject({ code: "solver", message: "The solver stopped: " + e.message, retryable: false }); return; }
        if (!res.ok) { resolve({ ok: false, result: res }); return; }
        resolve({ ok: true, record: recordFrom(res, meta), result: res });
      }, 0);
    });
  }

  /* ---------------- sweeps: real simulations, chunked so the page stays responsive ---------------- */
  function submitSweep(defIn, opts) {
    opts = opts || {};
    var v = SWEEP.validate(defIn, { limits: SWEEP.LIMITS.local });
    var job = JOBS.create({ kind: "sweep", total: v.total, adapter: name, mode: opts.mode || "demo", demo: true });
    job.definition = v.def; job.validation = { errors: v.errors, warnings: v.warnings };
    function fail(msg) { JOBS.move(job, "failed", { error: { code: "invalid_sweep", message: msg, details: v.errors } }); }
    var rows = [], specs = null, i = 0, budget = opts.budgetMs || 24;
    function step() {
      if (job._cancel) { finish(true); return; }
      var t0 = Date.now(), n0 = rows.length;
      while (i < specs.length && (opts.sync || Date.now() - t0 < budget)) {
        var sp = specs[i++], res;
        try { res = TWIN.simulate(sp.config); } catch (e) { res = { ok: false, outcome: { code: "invalid", reason: "solver: " + e.message } }; }
        rows.push(SWEEP.rowOf(sp, res));
        if (opts.sync && job._cancel) break;
      }
      var failedN = rows.slice(n0).filter(function (r) { return r.outcome === "invalid"; }).length;
      JOBS.advance(job, rows.length - n0, failedN);
      if (i < specs.length && !job._cancel) { if (opts.sync) step(); else setTimeout(step, 0); }
      else finish(!!job._cancel && rows.length < specs.length);       // every run finished: a cancel came too late (v5.2)
    }
    function finish(cancelled) {
      var def = job.definition;
      var result = { schema: SWEEP.SCHEMA_ID, id: def.id || SWEEP.newId(), name: def.name || "Research sweep", created: new Date().toISOString(), definition: def,
        engine: { adapter: name, engine: "aeris-twin-js", engine_version: TWIN.VERSION.model },
        provenance: { source: "simulation", validation: RUNS.modelValidation(), demo: true, mock: false, note: "Computed in this browser by the AERIS Twin engine on " + RUNS.modelValidation().status + " parameters. Exploratory; not a published research dataset." },
        rows: rows, partial: cancelled, analysis: null, job: null };
      if (cancelled) { result.analysis = rows.length ? SWEEP.analyze(def, rows) : null; job.result = result; result.job = JOBS.toJSON(job); JOBS.move(job, "cancelled", { result: result, message: "Cancelled after " + rows.length + " of " + specs.length + " runs; partial results kept." }); return; }
      JOBS.move(job, "analyzing");
      var go = function () {
        try { result.analysis = SWEEP.analyze(def, rows); } catch (e) { JOBS.move(job, "failed", { error: { code: "analysis", message: "Analysis failed: " + e.message } }); return; }
        result.job = JOBS.toJSON(job); result.job.state = "complete";
        // a cancel request that arrived after the last run (v5.2, review G4): said, not silently dropped
        var late = job._cancel ? "Finished all " + rows.length + " runs. A cancel request arrived after the last run had finished; the browser engine does not interrupt its analysis, so the complete result is kept." : undefined;
        JOBS.move(job, "complete", { result: result, message: late });
      };
      if (opts.sync) go(); else setTimeout(go, 0);
    }
    function start() {
      if (!v.ok) { JOBS.move(job, "initializing"); fail("The sweep is not valid: " + v.errors.map(function (e) { return e.message; }).join(" ")); return; }
      JOBS.move(job, "initializing");
      try { specs = SWEEP.expand(v.def); } catch (e) { fail("Could not expand the sweep: " + e.message); return; }
      JOBS.move(job, "running", { total: specs.length });
      step();
    }
    if (opts.sync) start(); else setTimeout(start, 0);
    return job;
  }
  function cancelJob(job) { if (!JOBS.isTerminal(job)) job._cancel = true; return Promise.resolve(job); }
  /* v5.2 (review G4): whether a cancel request can still take effect (see capabilities().cancel) */
  function cancellable(job) { return !!job && !JOBS.isTerminal(job) && capabilities().cancel.states.indexOf(job.state) >= 0; }
  return { name: name, kind: "simulation", label: "Browser engine (AERIS Twin, JavaScript)", available: available, capabilities: capabilities, simulateSync: simulateSync, runSingle: runSingle, submitSweep: submitSweep, cancelJob: cancelJob, cancellable: cancellable, origin: origin };
})();
if (typeof module !== "undefined") module.exports = LocalSimulatorAdapter;

/* =====================================================================
   AERIS · MASS ASYMMETRY — how far the setup's centre of mass is from
   the nominal design, which parts put it there, and the full inertia
   tensor (with products of inertia) about the COM and about the pivot.

   Nominal COM: the geometric centre of the bare cube (a/2, a/2, a/2) in
   the body frame, i.e. the design value. Δr_COM = r_COM − r_nominal is
   exactly the mass-weighted sum of each part's offset from that point,
   so the contribution column adds up to Δr_COM.
   ===================================================================== */
var AERIS_MASSUI = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var DEG = TWIN.DEG;
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fx(x, d) { if (!isFinite(x)) return "—"; var s = (+x).toFixed(d); if (/^-0(\.0+)?$/.test(s)) s = s.slice(1); return s.replace("-", "−"); }
  function sgn(x, d) { var s = fx(x, d); return s === "—" || s.charAt(0) === "−" || +x === 0 ? s : "+" + s; }
  /* pure: the numbers the panel shows */
  function asymmetry(cfg, mp) {
    var a = cfg.params.a, rNom = [a / 2, a / 2, a / 2], rc = mp.rc, M = mp.M;
    var dr = [rc[0] - rNom[0], rc[1] - rNom[1], rc[2] - rNom[2]];
    var parts = mp.parts.map(function (p) { return { id: p.id, label: p.label, mass: p.mass, pos: p.pos, contrib: [0, 1, 2].map(function (k) { return p.mass * (p.pos[k] - rNom[k]) / M; }) }; });
    var C = mp.ThC, off = [Math.abs(C[0][1]), Math.abs(C[0][2]), Math.abs(C[1][2])], diag = [C[0][0], C[1][1], C[2][2]];
    var principal = TWIN.la.sym3eig(C);
    return { rNom: rNom, rc: rc, dr: dr, drNorm: Math.hypot(dr[0], dr[1], dr[2]), M: M, parts: parts, ThC: C, ThO: mp.ThO, principal: principal,
      maxProduct: Math.max.apply(null, off), productRatio: Math.max.apply(null, off) / Math.min.apply(null, diag),
      balance_deg: cfg.mode === "edge" ? mp.edge.beta / DEG : mp.corner.beta / DEG };
  }
  function tensor(Mx, caption) {
    var ax = ["x", "y", "z"];
    return '<figure class="ma-t"><figcaption>' + caption + ' <span class="u">[10⁻³ kg·m²]</span></figcaption><table class="mtx" aria-label="' + esc(caption.replace(/<[^>]+>/g, "")) + '"><thead><tr><th></th>' + ax.map(function (c) { return '<th scope="col">' + c + "</th>"; }).join("") + "</tr></thead><tbody>" +
      [0, 1, 2].map(function (i) { return '<tr><th scope="row">' + ax[i] + "</th>" + [0, 1, 2].map(function (j) { return '<td class="mono' + (i !== j ? " off" : "") + '">' + fx(Mx[i][j] * 1000, 3) + "</td>"; }).join("") + "</tr>"; }).join("") + "</tbody></table></figure>";
  }
  function render(cfg, mp) {
    if (!mp) return '<p class="small dim">Fix the setup errors to see the mass properties.</p>';
    var A = asymmetry(cfg, mp), mm = function (v) { return "(" + v.map(function (x) { return fx(x * 1000, 1); }).join(", ") + ") mm"; };
    var h = '<dl class="ma-dl"><dt>Nominal COM <span class="dim">(bare cube, design)</span></dt><dd class="mono">' + mm(A.rNom) + "</dd>" +
      "<dt>COM of this setup</dt><dd class=\"mono\">" + mm(A.rc) + "</dd>" +
      '<dt><b>Δr<sub>COM</sub></b></dt><dd class="mono"><b>(' + A.dr.map(function (x) { return sgn(x * 1000, 2); }).join(", ") + ") mm</b> · |Δr| " + fx(A.drNorm * 1000, 2) + " mm</dd>" +
      "<dt>Total mass</dt><dd class=\"mono\">" + fx(A.M * 1000, 1) + " g</dd>" +
      "<dt>Balance attitude lean β</dt><dd class=\"mono\">" + fx(A.balance_deg, 3) + "°</dd></dl>";
    h += '<div class="tblx"><table class="ma-parts"><caption class="sr">Contribution of each part to Δr_COM</caption><thead><tr><th scope="col">Part</th><th scope="col">Mass [g]</th><th scope="col">Position [mm]</th><th scope="col">Share of Δr [mm]</th></tr></thead><tbody>' +
      A.parts.map(function (p) { return "<tr><th scope=\"row\">" + esc(p.label) + '</th><td class="mono">' + fx(p.mass * 1000, 1) + '</td><td class="mono">' + p.pos.map(function (x) { return fx(x * 1000, 1); }).join(", ") + '</td><td class="mono">' + p.contrib.map(function (x) { return sgn(x * 1000, 2); }).join(", ") + "</td></tr>"; }).join("") + "</tbody></table></div>";
    h += '<div class="ma-ts">' + tensor(A.ThC, "Inertia about the COM, I<sub>C</sub>") + tensor(A.ThO, "Inertia about the pivot O, I<sub>O</sub>") + "</div>";
    h += '<p class="small">Principal moments about the COM: <span class="mono">' + A.principal.map(function (x) { return fx(x * 1000, 3); }).join(", ") + "</span> ×10⁻³ kg·m². Largest product of inertia: <span class=\"mono\">" + fx(A.maxProduct * 1000, 4) + "</span> ×10⁻³ kg·m² (" + fx(A.productRatio * 100, 2) + " % of the smallest diagonal term).</p>";
    h += '<p class="small dim">The simulated plant uses the full tensor about the pivot, products of inertia included. In corner mode the controllers are designed per axis on averaged inertia (decoupled); edge mode uses the exact inertia about the support edge. A coupled MIMO LQR that uses the off-diagonal terms runs on the research backend (SIMULATION mode, structure “mimo-lqr”). In the 3-D view the grey ghost is the nominal COM and the arrow is Δr<sub>COM</sub>, magnified by the factor on its label.</p>';
    return h;
  }
  return { asymmetry: asymmetry, render: render };
})();
if (typeof module !== "undefined") module.exports = AERIS_MASSUI;

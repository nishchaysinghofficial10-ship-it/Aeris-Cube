/* =====================================================================
   AERIS LAB · RESEARCH SWEEP (loaded on demand when the Research sweep
   tab is first opened).

   Design → validate → submit → follow the job → analyse:
   - the base setup is held fixed (CONTROLLED · FIXED);
   - the chosen variables, controllers and mass configurations are varied
     (CHANGED · INDEPENDENT) — every controller sees the same points;
   - outcome and metrics are recorded for every run (MEASURED · DEPENDENT).

   The sweep runs through the experiment service: in DEMO mode on the
   AERIS Twin engine in this browser (up to its run limit), in SIMULATION
   mode on the research backend. Every number shown is computed from the
   finished runs (js/platform/sweep.js analyze()); nothing is estimated,
   interpolated into unrun regions, or filled in.
   ===================================================================== */
var AERIS_SWEEP_UI = (function () {
  "use strict";
  var SW = AERIS_SWEEP, JOBS = AERIS_JOBS, TWIN = AERIS_TWIN, TK = AERIS_TOKENS, B = AERIS_BADGES, $ = U.$, esc = U.esc, fx = U.fx, sig = U.sig;
  var CTL = ["pid", "lqr", "adp"], STORE_KEY = "aeris.v3.sweeps", MAX_SAVED = 5;
  var CFGN = typeof AERIS_CFG !== "undefined" ? AERIS_CFG.normalize : TWIN.normalizeConfig;
  /* v4: the engine of the active mode decides what can be swept (validation through the service) */
  function sim() { return !!(S.ctx.service && S.ctx.service.getMode && S.ctx.service.getMode() === "simulation"); }
  function ctlList() {
    var c = sim() ? S.ctx.service.capabilities() : null, list = c && c.sweep && Array.isArray(c.sweep.controllers) ? c.sweep.controllers.slice() : CTL.slice();
    (S.def && S.def.controllers || []).forEach(function (k) { if (list.indexOf(k) < 0) list.push(k); });   // keep a chosen controller visible (validation explains it)
    return list;
  }
  var DIST_LABEL = { uniform: "uniform", normal: "normal", "bounded-normal": "truncated normal (exact)", categorical: "categorical" };
  var SEED_LABEL = { legacy: "legacy (browser-compatible)", paired: "paired (same noise per point)", independent: "independent (per run)", fixed: "fixed (base seed)" };
  var S = { el: null, ctx: null, def: null, val: null, job: null, result: null, unsub: null, t0: 0, tick: null, mem: [] };

  /* ---------------- presets: real sweep definitions, run only when the user presses Run ---------------- */
  var PRESETS = [
    { key: "doa", label: "Domain of attraction", text: "Initial tilt × initial angular velocity, grid, all three controllers.", apply: function (d) { d.mode = "grid"; d.variables = [{ key: "tilt_deg", min: -6, max: 6, steps: 7 }, { key: "rate_dps", min: -60, max: 60, steps: 7 }]; d.duration_s = 3; } },
    { key: "com", label: "COM stability map", text: "COM shift y × z of the build (edge mode), grid.", apply: function (d) { d.base.mode = "edge"; d.mode = "grid"; d.variables = [{ key: "com_y_mm", min: -12, max: 12, steps: 5 }, { key: "com_z_mm", min: -12, max: 12, steps: 5 }]; d.duration_s = 5; } },
    { key: "sat", label: "Saturation map", text: "Torque limit × initial tilt: where the actuator limits decide the outcome.", apply: function (d) { d.mode = "grid"; d.variables = [{ key: "torque_pct", min: 30, max: 100, steps: 5 }, { key: "tilt_deg", min: 1, max: 7, steps: 4 }]; d.duration_s = 4; } },
    { key: "inertia", label: "Inertia uncertainty", text: "True inertia 0.6–1.6 × the model's: controller robustness to a model error.", apply: function (d) { d.mode = "grid"; d.variables = [{ key: "inertia_scale", min: 0.6, max: 1.6, steps: 6 }, { key: "tilt_deg", min: 1, max: 5, steps: 3 }]; d.duration_s = 4; } },
    { key: "mc", label: "Monte Carlo: push and COM", text: "Random push magnitude and COM shift, 40 samples per controller (seeded).", apply: function (d) { d.mode = "montecarlo"; d.samples = 40; d.variables = [{ key: "disturbance_N", min: 0, max: 1.2, dist: "uniform" }, { key: "com_y_mm", min: -8, max: 8, dist: "normal", mean: 0, sd: 3 }]; d.duration_s = 5; } }
  ];

  /* ---------------- storage of recent sweep results (this browser only) ---------------- */
  function loadSaved() { try { var s = window.localStorage.getItem(STORE_KEY); return s ? JSON.parse(s) : []; } catch (e) { return S.mem; } }
  function saveList(list) { try { window.localStorage.setItem(STORE_KEY, JSON.stringify(list)); return true; } catch (e) { S.mem = list; return false; } }
  function remember(sw) { var list = loadSaved().filter(function (x) { return x.id !== sw.id; }); list.unshift(sw); while (list.length > MAX_SAVED) list.pop(); if (!saveList(list)) { while (list.length > 1 && !saveList(list.slice(0, list.length - 1))) list.pop(); } }
  function takenIds() { return loadSaved().map(function (x) { return x.id; }).filter(Boolean); }

  /* ---------------- mount ---------------- */
  function mount(el, ctx) {
    S.el = el; S.ctx = ctx || {};
    var base = ctx && ctx.draft ? ctx.draft() : TWIN.defaultConfig("edge");
    S.def = SW.defaultSweep(base);
    el.innerHTML = '<div class="sw-grid"><section class="sw-def" id="swDef" aria-label="Sweep definition"></section><section class="sw-out" id="swOut" aria-label="Sweep job and results" aria-live="off"></section></div>';
    el.addEventListener("input", onInput); el.addEventListener("change", onInput); el.addEventListener("click", onClick);
    renderDef(); renderOut(); status();
  }
  function show() { if (S.result) drawCharts(S.result); status(); }
  function limits() { var c = S.ctx.service && S.ctx.service.capabilities(); return c && c.sweep ? { maxRuns: c.sweep.maxRuns, maxDuration_s: c.sweep.maxDuration_s } : SW.LIMITS.local; }
  function engineLabel() { var a = S.ctx.service && S.ctx.service.route("sweep"); return a ? a.label : "no engine (this mode cannot run sweeps)"; }
  function status() {
    if (!S.ctx.status) return;
    var j = S.job, sw = S.result;
    S.ctx.status({ source: j && !JOBS.isTerminal(j) ? "simulation" : sw ? (S.fresh ? "simulation" : "replay") : "setup", controller: (S.def.controllers || []).map(function (c) { return TK.controller(c).short; }).join(" · ") || "—", experiment: j && !JOBS.isTerminal(j) ? (j.sweep_id || (j.result_ref && j.result_ref.id) || "sweep") + " · " + JOBS.STATES[j.state].label + " " + Math.round(j.progress.fraction * 100) + " %" : sw ? sw.id + " · " + (sw.partial ? "partial" : "complete") : "research sweep (not run)" });
  }

  /* ---------------- definition panel ---------------- */
  function varOptions(cur) {
    var used = S.def.variables.map(function (v) { return v.key; });
    return SW.VARIABLE_ORDER.map(function (k) { var V = SW.VARIABLES[k]; return '<option value="' + k + '"' + (k === cur ? " selected" : used.indexOf(k) >= 0 ? " disabled" : "") + ">" + esc(V.label) + " [" + esc(V.unit) + "]</option>"; }).join("");
  }
  function baseSummary(b) {
    var varied = S.def.variables.map(function (v) { return v.key; }), vv = function (k) { return varied.indexOf(k) >= 0; };
    var rows = [["Balance mode", b.mode], ["Edge length a", fx(b.params.a * 1000, 0) + " mm"], ["Base mass", fx(b.params.m, 3) + " kg"],
      ["COM offset δ / shift", fx(b.comOffset_m * 1000, 1) + " mm / (" + (b.comShift_m || [0, 0, 0]).map(function (x) { return fx(x * 1000, 1); }).join(", ") + ") mm" + (vv("com_x_mm") || vv("com_y_mm") || vv("com_z_mm") ? " · shift varied" : "")],
      ["Attached masses", b.attachments.length + (S.def.mass_configs.join() !== "base" ? " · replaced by the mass configurations" : "")],
      ["Initial tilt / rate", (vv("tilt_deg") ? "varied" : b.initial.tilt_deg == null && b.initial.attitude_q ? "explicit q" : fx(b.initial.tilt_deg, 2) + "°") + " / " + (vv("rate_dps") ? "varied" : b.initial.rate_dps == null && b.initial.body_rate_dps ? "explicit ω" : fx(b.initial.rate_dps, 1) + " °/s")],
      ["Sensing", b.mode === "edge" || b.estimator.type !== "ideal" ? b.estimator.type : "ideal (corner)"], ["Torque limit", vv("torque_pct") ? "varied" : fx(b.torqueScale * 100, 0) + " %"], ["Wheel speed limit", vv("rpm_limit") ? "varied" : fx(b.params.wmaxRpm, 0) + " rpm"],
      ["True inertia", vv("inertia_scale") ? "varied" : fx(b.uncertainty.inertiaScale, 2) + " × model"], ["Loads in the setup", String((b.disturbances || []).length) + (vv("disturbance_N") ? " + the swept push" : "")], ["Knows attached masses", b.controller.knowsAttachments ? "yes" : "no"]];
    return '<dl class="sw-base">' + rows.map(function (r) { return "<dt>" + esc(r[0]) + "</dt><dd>" + esc(r[1]) + "</dd>"; }).join("") + "</dl>";
  }
  function renderDef() {
    var d = S.def, el = $("swDef"); if (!el) return;
    var grid = d.mode === "grid", mc = d.mode === "montecarlo";
    var h = '<header class="sw-h"><h2>Research sweep</h2><p>Vary parameters over ranges and run each point with every chosen controller. The same points are used for every controller, so the controllers are compared on identical conditions.</p>' +
      '<p class="sw-legend">' + B.role("controlled") + B.role("independent") + B.role("dependent") + "</p></header>";
    h += '<div class="sw-presets" role="group" aria-label="Start from a template"><span class="sw-k">Templates</span>' + PRESETS.map(function (p) { return '<button type="button" class="act" data-preset="' + p.key + '" title="' + esc(p.text) + '">' + esc(p.label) + "</button>"; }).join("") + "</div>";
    h += '<fieldset class="sw-sec"><legend><span class="n">1</span> Base setup ' + B.role("controlled") + "</legend><p class=\"help\">Everything that is not varied comes from this setup and is identical in every run.</p>" + baseSummary(d.base) +
      '<div class="btnrow"><button type="button" class="act" data-sw="useDraft">Use the current Lab setup</button><button type="button" class="act" data-sw="editBase">Edit it in Single experiment</button></div></fieldset>';
    h += '<fieldset class="sw-sec"><legend><span class="n">2</span> Varied ' + B.role("independent") + "</legend>";
    h += '<div class="tblx"><table class="sw-vars"><caption class="sr">Varied parameters and their ranges</caption><thead><tr><th scope="col">Parameter</th><th scope="col">From</th><th scope="col">To</th><th scope="col">' + (grid ? "Values" : mc ? "Distribution" : "Sampling") + '</th><th scope="col"><span class="sr">Remove</span></th></tr></thead><tbody>' +
      d.variables.map(function (v, i) {
        var dOpts = sim() ? ["uniform", "bounded-normal", "normal"] : ["uniform", "normal"];
        if (dOpts.indexOf(v.dist) < 0) dOpts.push(v.dist);
        var dist = mc ? '<select data-v="' + i + '" data-f="dist" aria-label="Distribution">' + dOpts.map(function (o) { return '<option value="' + esc(o) + '"' + (v.dist === o ? " selected" : "") + ">" + esc(sim() && o === "normal" && (S.def.revision === "1.1" || S.def.revision === "1.2") ? "normal (untruncated)" : DIST_LABEL[o] || o) + "</option>"; }).join("") + "</select>" + (v.dist === "normal" || v.dist === "bounded-normal" ? '<input data-v="' + i + '" data-f="mean" type="number" step="any" value="' + (v.mean != null ? v.mean : "") + '" aria-label="Mean" placeholder="mean"><input data-v="' + i + '" data-f="sd" type="number" step="any" value="' + (v.sd != null ? v.sd : "") + '" aria-label="Standard deviation" placeholder="sd">' : "") : grid ? '<input data-v="' + i + '" data-f="steps" type="number" min="2" max="50" step="1" value="' + v.steps + '" aria-label="Number of values">' : '<span class="dim">uniform</span>';
        if (!v.key) return '<tr><td class="mono">' + esc(v.label || v.path) + ' <span class="dim small">(configuration path, from an imported definition)</span></td><td class="mono">' + esc(String(v.min)) + '</td><td class="mono">' + esc(String(v.max)) + '</td><td class="sw-dist">' + esc(DIST_LABEL[v.dist] || v.dist) + '</td><td><button type="button" class="icon" data-sw="rmVar" data-i="' + i + '" aria-label="Remove ' + esc(v.path) + '">×</button></td></tr>';
        return '<tr><td><select data-v="' + i + '" data-f="key" aria-label="Parameter">' + varOptions(v.key) + '</select></td><td><input data-v="' + i + '" data-f="min" type="number" step="any" value="' + v.min + '" aria-label="From"></td><td><input data-v="' + i + '" data-f="max" type="number" step="any" value="' + v.max + '" aria-label="To"></td><td class="sw-dist">' + dist + '</td><td><button type="button" class="icon" data-sw="rmVar" data-i="' + i + '" aria-label="Remove ' + esc(SW.VARIABLES[v.key] ? SW.VARIABLES[v.key].label : v.key) + '">×</button></td></tr>';
      }).join("") + "</tbody></table></div>";
    h += '<div class="btnrow"><button type="button" class="act" data-sw="addVar"' + (d.variables.length >= 4 ? " disabled" : "") + ">+ Vary another parameter</button></div>";
    h += '<p class="sub-h">Controllers (each runs every point)</p><div class="sw-checks">' + ctlList().map(function (c) { return '<label class="sw-chk"><input type="checkbox" data-ctl="' + c + '"' + (d.controllers.indexOf(c) >= 0 ? " checked" : "") + ">" + B.controller(c, { long: true }) + "</label>"; }).join("") + "</div>";
    h += '<p class="sub-h">Mass configurations</p><div class="sw-checks">' + Object.keys(SW.MASS_CONFIGS).map(function (k) { return '<label class="sw-chk"><input type="checkbox" data-mass="' + k + '"' + (d.mass_configs.indexOf(k) >= 0 ? " checked" : "") + "><span>" + esc(SW.MASS_CONFIGS[k].label) + "</span></label>"; }).join("") + "</div></fieldset>";
    h += '<fieldset class="sw-sec"><legend><span class="n">3</span> Sampling</legend><div class="sw-modes" role="radiogroup" aria-label="Sampling mode">' + Object.keys(SW.MODES).map(function (m) { return '<label class="sw-mode"><input type="radio" name="swMode" value="' + m + '"' + (d.mode === m ? " checked" : "") + "><span><b>" + (m === "montecarlo" ? "Monte Carlo" : m.charAt(0).toUpperCase() + m.slice(1)) + "</b> " + esc(SW.MODES[m].split(": ")[1] || "") + "</span></label>"; }).join("") + "</div>" +
      '<div class="row3">' + (grid ? "" : '<div class="fld"><label for="swN">Samples <span class="u">per controller and mass configuration</span></label><input id="swN" data-f="samples" type="number" min="1" step="1" value="' + d.samples + '"></div>') +
      '<div class="fld"><label for="swSeed">Seed</label><input id="swSeed" data-f="seed" type="number" step="1" value="' + d.seed + '"></div><div class="fld"><label for="swDur">Window <span class="u">s</span></label><input id="swDur" data-f="duration_s" type="number" min="1" step="any" value="' + d.duration_s + '"></div></div>' +
      (sim() || d.seed_strategy ? '<div class="row3"><div class="fld"><label for="swSeedStr">Seed strategy <span class="u">sensor noise per run</span></label><select id="swSeedStr" data-f="seed_strategy">' + Object.keys(SEED_LABEL).map(function (k) { var cur = (d.seed_strategy || "legacy") === k; return '<option value="' + k + '"' + (cur ? " selected" : "") + (!sim() && k !== "legacy" && !cur ? " disabled" : "") + ">" + esc(SEED_LABEL[k]) + "</option>"; }).join("") + "</select></div>" +
        (sim() || d.criterion ? '<div class="fld"><label for="swCrit">Success criterion <span class="u">rates, paired test, maps</span></label><select id="swCrit" data-f="criterion">' + SW.CRITERIA.map(function (k) { var cur = (d.criterion || (d.revision === "1.2" ? "research" : "legacy")) === k; return '<option value="' + k + '"' + (cur ? " selected" : "") + (!sim() && k !== "legacy" && !cur ? " disabled" : "") + ">" + esc(SW.CRITERION_LABEL[k]) + "</option>"; }).join("") + "</select></div>" : "") + "</div>" : "") +
      '<p class="help">' + (grid ? "Grid points are evenly spaced and include both ends." : mc ? (sim() ? "Monte Carlo on the research backend: 'truncated normal (exact)' samples the truncated normal by inverse CDF; 'normal' in a revision-1.1 definition is untruncated and out-of-range samples become invalid rows (kept, not run, never clipped)." : "Monte Carlo samples follow the stated distributions (a normal sample is redrawn until it lies in the range, at most 100 times; one still outside is placed at the bound and flagged 'clipped').") : "Random points are uniform over the ranges.") + " The seed makes the point set reproducible." + (sim() ? " Seed strategy 'paired' gives every controller the same sensor-noise seed at a point, so their outcomes can be compared pair by pair (McNemar test)." : "") + "</p></fieldset>";
    h += '<fieldset class="sw-sec"><legend><span class="n">4</span> Measured ' + B.role("dependent") + '</legend><p class="sw-meas">' + SW.MEASURES.map(function (m) { return '<span class="sw-m">' + esc(m.label) + (m.unit ? ' <span class="u">[' + esc(m.unit) + "]</span>" : "") + "</span>"; }).join("") + '</p><p class="help">Recorded for every run. Samples are not kept for sweep runs; open a point in Single experiment to replay it in full.</p></fieldset>';
    h += '<div class="sw-sec sw-run"><div id="swVal" class="valbox" aria-live="polite"></div><div class="btnrow main"><button type="button" class="btn btn-solid btn-sm" data-sw="run" id="swRun">Run sweep</button><button type="button" class="act" data-sw="cancel" id="swCancel" hidden>Cancel</button></div>' +
      '<div class="btnrow"><button type="button" class="act" data-sw="exportDef">Export definition</button><button type="button" class="act" data-sw="import">Import…</button></div></div>';
    el.innerHTML = h;
    validate();
  }
  function validate() {
    var lim = limits(), v = S.ctx.service && S.ctx.service.validateSweep ? S.ctx.service.validateSweep(S.def) : SW.validate(S.def, { limits: lim }); S.val = v;
    var box = $("swVal"); if (!box) return v;
    var d = v.def, pts = v.points, h = "";
    if (v.ok) h += '<div class="vb ok"><b>' + v.total.toLocaleString("en-GB") + " runs</b> = " + pts + " point" + (pts === 1 ? "" : "s") + " × " + d.controllers.length + " controller" + (d.controllers.length === 1 ? "" : "s") + " × " + d.mass_configs.length + " mass configuration" + (d.mass_configs.length === 1 ? "" : "s") + ". Engine: " + esc(engineLabel()) + " (limit " + lim.maxRuns.toLocaleString("en-GB") + " runs, windows up to " + lim.maxDuration_s + " s).</div>";
    if (v.errors.length) h += '<div class="vb err"><b>Cannot run yet:</b><ul>' + v.errors.map(function (e) { return "<li>" + esc(e.message) + "</li>"; }).join("") + "</ul></div>";
    if (v.warnings.length) h += '<div class="vb warn"><b>Check:</b><ul>' + v.warnings.map(function (e) { return "<li>" + esc(e.message) + "</li>"; }).join("") + "</ul></div>";
    box.innerHTML = h;
    var running = S.job && !JOBS.isTerminal(S.job), canRun = v.ok && !running && !!(S.ctx.service && S.ctx.service.route("sweep"));
    var rb = $("swRun"); if (rb) { rb.disabled = !canRun; rb.textContent = running ? "Running…" : "Run sweep"; }
    syncCancel();
    return v;
  }
  /* The Cancel button (v5.2, review G4): shown only while a cancel request can still take effect — the adapter decides
     (the browser engine does not interrupt its analysis once every run has finished) — and reset for the next job
     (v5.1 left it disabled as "Cancelling…" after a cancelled sweep, so the next sweep could not be cancelled). */
  function syncCancel() {
    var cb = $("swCancel"); if (!cb) return;
    var running = S.job && !JOBS.isTerminal(S.job);
    cb.hidden = !(running && (S.ctx.service && S.ctx.service.cancellable ? S.ctx.service.cancellable(S.job) : true));
    if (!running) { cb.disabled = false; cb.textContent = "Cancel"; }
  }
  var validateSoon = U.debounce(validate, 150);
  function onInput(e) {
    var t = e.target; if (!$("swDef") || !$("swDef").contains(t)) return;
    var d = S.def;
    if (t.name === "swMode") { if (t.checked) { d.mode = t.value; if (d.mode !== "grid" && !(d.samples >= 1)) d.samples = 40; renderDef(); } return; }
    if (t.hasAttribute("data-ctl")) { d.controllers = ctlList().filter(function (k) { var box = S.el.querySelector('[data-ctl="' + k + '"]'); return box && box.checked; }); validateSoon(); status(); return; }
    if (t.hasAttribute("data-mass")) { d.mass_configs = Object.keys(SW.MASS_CONFIGS).filter(function (k) { var box = S.el.querySelector('[data-mass="' + k + '"]'); return box && box.checked; }); if (e.type === "change") renderDef(); else validateSoon(); return; }
    var vi = t.getAttribute("data-v"), f = t.getAttribute("data-f");
    if (vi != null) {
      var v = d.variables[+vi]; if (!v) return;
      if (f === "key") { var V = SW.VARIABLES[t.value]; v.key = t.value; v.min = V.def[0]; v.max = V.def[1]; if (e.type === "change") renderDef(); return; }
      if (f === "dist") { v.dist = t.value; if (v.dist === "bounded-normal" && d.revision !== "1.2") d.revision = "1.1"; if (v.dist === "normal" || v.dist === "bounded-normal") { if (v.mean == null) v.mean = +((v.min + v.max) / 2).toPrecision(6); if (v.sd == null) v.sd = +((v.max - v.min) / 6).toPrecision(4); } if (e.type === "change") renderDef(); return; }
      v[f] = t.value === "" ? NaN : parseFloat(t.value);
      validateSoon(); return;
    }
    if (f === "criterion") { d.criterion = t.value; d.revision = "1.2"; if (e.type === "change") renderDef(); return; }
    if (f === "seed_strategy") { d.seed_strategy = t.value; if (t.value !== "legacy" && d.revision !== "1.2") d.revision = "1.1"; if (e.type === "change") renderDef(); return; }
    if (f) { d[f] = t.value === "" ? NaN : parseFloat(t.value); validateSoon(); }
  }
  function onClick(e) {
    var b = e.target.closest("button"); if (!b || !S.el.contains(b)) return;
    var a = b.getAttribute("data-sw"), p = b.getAttribute("data-preset");
    if (p) { var pr = PRESETS.filter(function (x) { return x.key === p; })[0]; if (pr) { pr.apply(S.def); S.def.controllers = CTL.slice(); S.def.mass_configs = ["base"]; renderDef(); toast("Template '" + pr.label + "' loaded. Nothing has run yet: press Run sweep."); } return; }
    if (a === "addVar") { var used = S.def.variables.map(function (v) { return v.key; }), k = SW.VARIABLE_ORDER.filter(function (x) { return used.indexOf(x) < 0; })[0]; if (k) { var V = SW.VARIABLES[k]; S.def.variables.push({ key: k, min: V.def[0], max: V.def[1], steps: 4, dist: "uniform" }); renderDef(); } }
    else if (a === "rmVar") { S.def.variables.splice(+b.getAttribute("data-i"), 1); renderDef(); }
    else if (a === "useDraft") { if (S.ctx.draft) { S.def.base = CFGN(S.ctx.draft()); S.def.duration_s = Math.min(S.def.duration_s, limits().maxDuration_s); renderDef(); toast("Base setup copied from Single experiment."); } }
    else if (a === "editBase") { if (S.ctx.openConfig) S.ctx.openConfig(TWIN.clone(S.def.base)); }
    else if (a === "run") run();
    else if (a === "cancel") { if (S.job) S.ctx.service.cancel(S.job); if (S.job && S.ctx.service.cancellable && !S.ctx.service.cancellable(S.job)) syncCancel(); else { b.disabled = true; b.textContent = "Cancelling…"; } }
    else if (a === "exportDef") { var v = validate(); S.ctx.exportText("aeris-sweep-definition.json", JSON.stringify(Object.assign({}, v.def, { schema: SW.SCHEMA_ID, kind: "definition" }), null, 2), "application/json", "Sweep definition (aeris-sweep/1)"); }
    else if (a === "import") importDialog();
    else if (a === "exportSweep" && S.result) S.ctx.exportText(S.result.id + ".json", JSON.stringify(S.result, null, 1), "application/json", "Sweep with results (aeris-sweep/1)");
    else if (a === "exportCSV" && S.result) S.ctx.exportText(S.result.id + ".csv", rowsCSV(S.result), "text/csv", "Sweep rows (CSV)");
    else if (a === "exportDataset" && S.result) S.ctx.exportText(S.result.id + "-dataset.json", JSON.stringify(datasetOf(S.result), null, 1), "application/json", "Dataset (aeris-dataset/1)");
    else if (a === "beAnalyze" && S.result) beAnalyze();
    else if (a === "beDataset" && S.result) beDataset();
    else if (a === "beFinalize" && S.ds) beFinalize();
    else if (a === "beExport" && S.ds) beExport();
    else if (a === "openRow" && S.result) openRow(+b.getAttribute("data-row"));
    else if (a === "openSaved") { var sv = loadSaved().filter(function (x) { return x.id === b.getAttribute("data-id"); })[0]; if (sv) { S.result = sv; S.job = null; S.fresh = false; renderOut(); status(); } }
    else if (a === "delSaved") { saveList(loadSaved().filter(function (x) { return x.id !== b.getAttribute("data-id"); })); renderOut(); }
  }
  function toast(m) { if (S.ctx.toast) S.ctx.toast(m); }

  /* ---------------- running ---------------- */
  function run() {
    var v = validate(); if (!v.ok || (S.job && !JOBS.isTerminal(S.job))) return;
    // browser sweeps get a local id; the research backend numbers its own sweeps (AERIS-SWP-1xxxxx)
    var def = TWIN.clone(v.def); if (!sim()) def.id = SW.newId(takenIds()); def.created = new Date().toISOString(); def.name = def.name || (PRESET_NAME(def) + (def.id ? " · " + def.id : ""));
    var job = S.ctx.service.submitSweep(def);
    if (job && job.error) { toast(job.error.message); return; }
    S.job = job; job.sweep_id = def.id || null; S.result = null; S.fresh = true; S.t0 = Date.now();
    if (S.unsub) S.unsub();
    S.unsub = JOBS.subscribe(job, function (j) {
      // the engine's own sweep id is kept (the research backend numbers its sweeps); the local id names browser sweeps
      if (j.result && (j.state === "complete" || j.state === "cancelled" || j.state === "failed")) { if (!j.result.id) j.result.id = def.id; S.result = j.result; remember(j.result); }
      renderJob(); syncCancel(); if (JOBS.isTerminal(j)) { clearInterval(S.tick); S.tick = null; validate(); renderOut(); } status();
    });
    clearInterval(S.tick); S.tick = setInterval(renderJob, 500);
    validate(); renderOut(); status();
  }
  function PRESET_NAME(d) { return d.variables.map(function (v) { return SW.VARIABLES[v.key] ? SW.VARIABLES[v.key].label : v.key; }).join(" × "); }
  function renderJob() {
    var el = $("swJob"), j = S.job; if (!el || !j) return;
    var st = JOBS.STATES[j.state], p = j.progress, secs = ((j.finished ? Date.parse(j.finished) : Date.now()) - S.t0) / 1000;
    var tone = st.tone === "stable" ? "ok" : st.tone === "failure" ? "bad" : st.tone === "warning" ? "warn" : "info";
    el.innerHTML = '<div class="job-h"><span class="mono xid">' + esc(j.sweep_id || (j.result_ref && j.result_ref.id) || j.id) + '</span><span class="job-st ' + tone + '">' + esc(st.label) + "</span>" + (j.demo ? B.mark("demoMode") : "") + (j.mock ? B.mark("mockData") : "") + "</div>" +
      '<div class="job-bar" role="progressbar" aria-label="Sweep progress" aria-valuemin="0" aria-valuemax="' + p.total + '" aria-valuenow="' + p.done + '" aria-valuetext="' + esc(JOBS.describe(j)) + '"><i style="width:' + (p.fraction * 100).toFixed(1) + '%"></i></div>' +
      '<p class="job-d mono">' + esc(JOBS.describe(j)) + " · " + fx(secs, 1) + " s</p><p class=\"small dim\">" + esc(j.message || st.text) + (j.error ? ' <span class="v-bad">' + esc(j.error.message || String(j.error)) + "</span>" : "") + (p.failed ? ' <span class="v-warn">' + p.failed + " run(s) rejected as invalid configurations.</span>" : "") + "</p>" +
      (j.cancelError ? '<p class="small v-warn" role="alert">' + esc(j.cancelError.message) + "</p>" : "") + (j.transport ? '<p class="small dim">Updates: ' + esc(j.transport === "websocket" ? "live (WebSocket)" : "polling") + "</p>" : "");
  }

  /* ---------------- results ---------------- */
  var CELL = {
    recovered: { label: "Recovered in every run of the cell", glyph: "✓", fill: TK.alpha(TK.color.status.stable, 0.78), ink: "rgba(0,0,0,.78)" },
    recovered_saturated: { label: "Recovered, through actuator saturation", glyph: "✓", fill: TK.alpha(TK.color.status.stable, 0.36), ink: "rgba(255,255,255,.9)" },
    mixed: { label: "Some runs recovered, some did not", glyph: "◐", fill: TK.alpha(TK.color.status.warning, 0.45), ink: "rgba(0,0,0,.8)" },
    not_recovered: { label: "Did not recover (not settled or drifting), did not fall", glyph: "…", fill: TK.alpha(TK.color.status.warning, 0.85), ink: "rgba(0,0,0,.8)" },
    fallen: { label: "Fell", glyph: "✕", fill: TK.alpha(TK.color.status.failure, 0.75), ink: "rgba(0,0,0,.8)" },
    invalid: { label: "Invalid configuration (not run)", glyph: "⊘", fill: "rgba(255,255,255,.14)", ink: "rgba(255,255,255,.8)" }
  };
  function vlabel(k) {
    var V = SW.VARIABLES[k]; if (V) return V.label + " [" + V.unit + "]";
    var dv = S.result && S.result.definition && (S.result.definition.variables || []).filter(function (v) { return v.path === k; })[0];
    return dv ? (dv.label || dv.path) + (dv.unit ? " [" + dv.unit + "]" : "") : k;
  }
  function fromBackend(sw) { return !!(sw && sw.engine && sw.engine.engine === "aeris-research-backend"); }
  function engineName(sw) { return fromBackend(sw) ? "the AERIS research backend (" + ((sw.engine && sw.engine.engine_version) || "Python") + ")" : "AERIS Twin"; }
  function pct(x) { return x == null ? "—" : fx(x * 100, 1) + " %"; }
  function renderOut() {
    var el = $("swOut"); if (!el) return;
    var h = '<div class="sw-job" id="swJob">' + (S.job ? "" : '<p class="ws-empty">No sweep running. Define one on the left (or load a template) and press <b>Run sweep</b>. Results appear here as soon as the runs finish; nothing is shown before it has been computed.</p>') + "</div>";
    var saved = loadSaved();
    if (saved.length) h += '<details class="sw-saved"' + (S.result || S.job ? "" : " open") + "><summary>Recent sweeps in this browser (" + saved.length + ")</summary><ul>" + saved.map(function (x) { return '<li><button type="button" class="act" data-sw="openSaved" data-id="' + esc(x.id) + '">Open</button> <span class="mono xid">' + esc(x.id) + "</span> " + esc(x.name || "") + ' <span class="dim small">' + esc(new Date(x.created).toLocaleString()) + " · " + (x.rows || []).length + " runs" + (x.partial ? " · partial" : "") + '</span> <button type="button" class="icon" data-sw="delSaved" data-id="' + esc(x.id) + '" aria-label="Delete ' + esc(x.id) + '">×</button></li>'; }).join("") + "</ul></details>";
    if (S.result) h += resultHTML(S.result);
    el.innerHTML = h;
    if (S.job) renderJob();
    if (S.result) drawCharts(S.result);
  }
  function resultHTML(sw) {
    var an = sw.analysis, d = sw.definition, prov = sw.provenance || {};
    var h = '<div class="sw-res"><div class="rid"><span class="xid mono">' + esc(sw.id) + "</span>" + B.forSweep(sw) + "</div><h3 class=\"sw-rt\">" + esc(sw.name || "Research sweep") + "</h3>";
    h += '<p class="small dim">' + esc(prov.note || "") + " " + (sw.rows || []).length + " runs · engine " + esc((sw.engine && (sw.engine.engine + " " + (sw.engine.engine_version || ""))) || "unknown") + " · created " + esc(new Date(sw.created).toLocaleString()) + "</p>";
    var stopped = sw.status === "interrupted" ? "was interrupted (the backend restarted)" : "was cancelled";
    if (sw.partial) h += '<div class="vb warn"><b>PARTIAL sweep.</b> The job ' + stopped + " after " + (sw.rows || []).length + (sw.total ? " of " + sw.total : "") + " runs; the completed runs are kept and the analysis below uses only those runs, so some points are missing." + (sw.analysis_cancelled ? " The analysis itself was cancelled on the backend." : "") + "</div>";
    var nFailed = (sw.rows || []).filter(function (r) { return r.status === "failed"; }).length, nInvalid = (sw.rows || []).filter(function (r) { return r.status === "invalid" || (r.status == null && r.outcome === "invalid"); }).length;
    if (nFailed || nInvalid) h += '<p class="small v-warn">' + (nInvalid ? nInvalid + " run(s) are invalid (configuration rejected or sample out of range) " : "") + (nFailed ? (nInvalid ? "and " : "") + nFailed + " run(s) failed " : "") + "— they stay in the table below with their reason and count as not run.</p>";
    var notes = [].concat(sw.analysis_note ? [sw.analysis_note] : [], d && d.sampling_notes || [], an && an.notes || []);
    if (notes.length) h += '<ul class="small dim sw-notes">' + notes.map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("") + "</ul>";
    if (!an) return h + '<p class="ws-empty">No runs finished, so there is nothing to analyse.</p></div>';
    // design summary
    h += '<details class="sw-design"><summary>Design of this sweep</summary><dl class="sw-base"><dt>' + B.role("independent") + "</dt><dd>" + d.variables.map(function (v) { return esc(vlabel(SW.ident(v))) + ": " + (v.dist === "categorical" ? "values " + esc((v.values || []).join(", ")) : fx(v.min, 3) + " to " + fx(v.max, 3) + (d.mode === "grid" ? ", " + v.steps + " values" : v.dist === "normal" || v.dist === "bounded-normal" ? ", " + esc(DIST_LABEL[v.dist]) + "(" + v.mean + ", " + v.sd + ")" : ", uniform")); }).join("<br>") + "<br>Controllers: " + d.controllers.map(function (c) { return B.controller(c); }).join(" ") + (d.seed_strategy ? "<br>Seed strategy: " + esc(SEED_LABEL[d.seed_strategy] || d.seed_strategy) : "") + (d.estimators ? "<br>Estimators: " + esc(d.estimators.join(", ")) : "") + "<br>Mass configurations: " + d.mass_configs.map(function (k) { return esc(SW.MASS_CONFIGS[k] ? SW.MASS_CONFIGS[k].label : k); }).join(", ") + "</dd><dt>" + B.role("controlled") + "</dt><dd>Base setup (" + esc(d.base.mode) + " mode, " + fx(d.duration_s, 1) + " s window, seed " + d.seed + ", " + esc(d.mode) + " sampling). Everything else as in the base setup.</dd><dt>" + B.role("dependent") + "</dt><dd>" + SW.MEASURES.map(function (m) { return esc(m.label); }).join(", ") + "</dd></dl></details>";
    // robustness summary
    var ctls = Object.keys(an.controllers);
    var hasResearch = ctls.some(function (c) { return an.controllers[c].research_rate !== undefined; });
    var hasSust = ctls.some(function (c) { return an.controllers[c].research_sustained !== undefined; });
    if (an.criterion) h += '<p class="small"><b>Declared success criterion:</b> ' + esc(an.criterion_text || an.criterion) + ' — the paired comparison, the maps and the labels below use it.</p>';
    h += '<h4 class="rh">Controller robustness</h4><div class="tblx"><table class="ct sw-sum"><thead><tr><th scope="col">Controller</th><th scope="col">Runs (valid)</th><th scope="col">Recovered</th><th scope="col">Recovery rate · 95 % CI</th>' + (hasResearch ? '<th scope="col">Research criteria met · 95 % CI</th>' : "") + (hasSust ? '<th scope="col">Sustained · later exits · fell after</th>' : "") + '<th scope="col">Through saturation</th><th scope="col">Fell</th></tr></thead><tbody>' +
      ctls.map(function (c) { var s = an.controllers[c]; return "<tr><th scope=\"row\">" + B.controller(c, { long: true }) + "</th><td class=\"mono\">" + s.n + " (" + s.valid + ")</td><td class=\"mono\">" + s.recovered + '</td><td><div class="ci" aria-label="' + esc(pct(s.rate) + ", 95 % interval " + pct(s.ci95[0]) + " to " + pct(s.ci95[1])) + '"><span class="ci-bar"><b style="left:' + (s.ci95[0] * 100).toFixed(1) + "%;width:" + ((s.ci95[1] - s.ci95[0]) * 100).toFixed(1) + '%"></b>' + (s.rate != null ? '<i style="left:' + (s.rate * 100).toFixed(1) + "%;color:" + TK.controller(c).color + '">' + TK.controller(c).glyph + "</i>" : "") + '</span><span class="mono">' + pct(s.rate) + " [" + pct(s.ci95[0]) + ", " + pct(s.ci95[1]) + "]</span></div></td>" + (hasResearch ? '<td class="mono">' + (s.research_rate == null ? "—" : s.research_recovered + " · " + pct(s.research_rate) + " [" + pct(s.research_ci95[0]) + ", " + pct(s.research_ci95[1]) + "]") + "</td>" : "") + (hasSust ? '<td class="mono">' + (s.research_sustained == null ? "—" : s.research_sustained + " · " + s.research_exits + " · " + s.research_fell_after) + "</td>" : "") + "<td class=\"mono\">" + s.saturatedRecoveries + "</td><td class=\"mono\">" + (s.counts.fallen || 0) + "</td></tr>"; }).join("") + "</tbody></table></div>" +
      (hasResearch ? '<p class="small dim">"Recovered" is the legacy COM-lean rule (it allows a yaw rotation). "Research criteria" use the recovery criteria saved in the base setup: quaternion attitude error and body rate below their thresholds for the hold time, within the maximum recovery time, with the declared yaw objective.' + (hasSust ? " Sustained: the criteria still held at the end of the run; later exits: runs that left the criteria after their first recovery; fell after: runs that fell after recovering. Simulated rates on nominal parameters, not hardware reliability." : "") + "</p>" : "") +
      (an.paired && an.paired.length ? '<h4 class="rh">Paired comparison</h4><div class="tblx"><table class="ct"><thead><tr><th scope="col">Pair</th><th scope="col">Pairs</th><th scope="col">Both</th><th scope="col">Only first</th><th scope="col">Only second</th><th scope="col">Neither</th><th scope="col">McNemar exact p</th></tr></thead><tbody>' + an.paired.map(function (q) { return "<tr><th scope=\"row\">" + B.controller(q.a) + " vs " + B.controller(q.b) + '</th><td class="mono">' + q.pairs + '</td><td class="mono">' + q.both + '</td><td class="mono">' + q.only_a + '</td><td class="mono">' + q.only_b + '</td><td class="mono">' + q.neither + '</td><td class="mono">' + (q.mcnemar_exact_p == null ? "—" : sig(q.mcnemar_exact_p, 3)) + "</td></tr>"; }).join("") + '</tbody></table></div><p class="small dim">' + esc((an.paired[0] && an.paired[0].note) || "") + (an.paired.some(function (q) { return q.paired_seeds === false; }) ? " Some pairs did not share sensor-noise seeds." : "") + "</p>" : "");
    (an.labels || []).forEach(function (lb) { h += '<p class="small">' + esc(lb.text) + (lb.tie ? " (tie)" : "") + ": " + lb.controllers.map(function (c) { return B.controller(c, { long: true }); }).join(", ") + " · " + pct(lb.value) + '. <span class="dim">This describes this sweep only: its ranges, base setup and nominal parameters. It is not a general ranking; overlapping confidence intervals mean the difference may not be meaningful.</span></p>'; });
    // maps
    if (an.maps.length) {
      h += '<h4 class="rh">Outcome maps</h4><p class="small dim">One cell per grid point, computed from the runs at that point' + (an.maps[0].aggregated_over ? "; each cell aggregates " + esc(an.maps[0].aggregated_over) : "") + ". Unrun regions stay empty: no boundary is drawn or interpolated between points.</p>";
      an.maps.forEach(function (m, mi) {
        h += '<figure class="sw-map"><figcaption><b>' + esc(m.title) + "</b> · " + esc(vlabel(m.x)) + " × " + esc(vlabel(m.y)) + '</figcaption><div class="sw-mults">' + Object.keys(m.cells).map(function (c) { return '<div class="sw-mult"><p class="sw-mt">' + B.controller(c, { long: true }) + '</p><div class="pcv"><canvas id="swMap' + mi + "-" + c + '" width="360" height="300" role="img" aria-label="' + esc(m.title + " for " + TK.controller(c).name) + '"></canvas><div class="ptip" id="swTip' + mi + "-" + c + '" hidden></div></div></div>'; }).join("") + "</div></figure>";
      });
      h += '<ul class="sw-key">' + Object.keys(CELL).map(function (k) { return '<li><i style="background:' + CELL[k].fill + '">' + CELL[k].glyph + "</i>" + esc(CELL[k].label) + "</li>"; }).join("") + "</ul>";
    }
    // recovery probability
    if (an.probability.length) {
      h += '<h4 class="rh">Recovery probability</h4><p class="small dim">Share of valid runs that recovered, per value (or bin) of one varied parameter, over all other varied parameters. Shaded: 95 % Wilson interval. Markers: ' + ctls.map(function (c) { return TK.controller(c).glyph + " " + esc(TK.controller(c).name); }).join(", ") + ".</p>";
      an.probability.forEach(function (p, pi) { h += '<figure class="plot"><figcaption><span class="pt">P(recovered) vs ' + esc(vlabel(p.variable)) + (p.binned ? " (binned)" : "") + '</span></figcaption><canvas id="swProb' + pi + '" width="900" height="300" role="img" aria-label="' + esc("Recovery probability against " + vlabel(p.variable)) + '"></canvas></figure>'; });
    }
    // distributions
    var dk = Object.keys(an.distributions);
    if (dk.length) {
      var MLAB = { settle_s: "Settling time [s] (recovered runs)", rmsLean_deg: "RMS attitude error [°]", peakOmega_rpm: "Peak wheel speed [rpm]", effort_Nms: "Control effort [N·m·s]" };
      h += '<h4 class="rh">' + (d.mode === "montecarlo" ? "Monte Carlo histograms" : "Distributions over the sweep") + "</h4>";
      dk.forEach(function (k, ki) { var dist = an.distributions[k]; h += '<figure class="sw-hist"><figcaption>' + esc(MLAB[k] || k) + '</figcaption><div class="sw-mults">' + Object.keys(dist.per).map(function (c) { var pc = dist.per[c]; return '<div class="sw-mult"><p class="sw-mt">' + B.controller(c) + ' <span class="dim small">n = ' + pc.n + (pc.median != null ? " · median " + sig(pc.median, 3) : "") + '</span></p><canvas id="swHist' + ki + "-" + c + '" width="360" height="200" role="img" aria-label="' + esc("Histogram of " + (MLAB[k] || k) + " for " + TK.controller(c).name) + '"></canvas></div>'; }).join("") + "</div></figure>"; });
    }
    // boundaries
    h += '<h4 class="rh">Observed limits</h4><p class="small dim">Per varied parameter: the largest |value| at which a run recovered and the smallest |value| at which one did not. These are observations at the sampled points, not a computed stability boundary.</p><div class="tblx"><table class="ct"><thead><tr><th scope="col">Parameter</th>' + ctls.map(function (c) { return '<th scope="col">' + B.controller(c) + "</th>"; }).join("") + "</tr></thead><tbody>" +
      Object.keys(an.boundaries).map(function (k) { return "<tr><th scope=\"row\">" + esc(vlabel(k)) + "</th>" + ctls.map(function (c) { var b = an.boundaries[k][c]; return "<td class=\"mono\">" + (b.maxRecovered == null ? "none recovered" : "≤ " + sig(b.maxRecovered, 3) + " recovered") + "<br>" + (b.minNotRecovered == null ? "all recovered" : "≥ " + sig(b.minNotRecovered, 3) + " not") + "</td>"; }).join("") + "</tr>"; }).join("") + "</tbody></table></div>";
    // rows
    var rows = sw.rows || [], shown = rows.slice(0, 120);
    h += '<details class="sw-rows"><summary>All runs (' + rows.length + ")</summary><div class=\"tblx\"><table class=\"ct\"><thead><tr><th scope=\"col\">#</th><th scope=\"col\">Controller</th>" + d.variables.map(function (v) { return '<th scope="col">' + esc(SW.VARIABLES[v.key] ? SW.VARIABLES[v.key].label : v.label || v.path) + "</th>"; }).join("") + '<th scope="col">Mass</th><th scope="col">Outcome</th><th scope="col">t<sub>s</sub> [s]</th><th scope="col">Peak Ω [rpm]</th><th scope="col"><span class="sr">Open</span></th></tr></thead><tbody>' +
      shown.map(function (r) { return "<tr><td class=\"mono\">" + r.index + "</td><td>" + B.controller(r.controller) + "</td>" + d.variables.map(function (v) { var x = r.values[SW.ident(v)]; return '<td class="mono">' + (typeof x === "number" ? sig(x, 4) : esc(String(x))) + "</td>"; }).join("") + "<td>" + esc(r.mass_config) + "</td><td" + (r.reason ? ' title="' + esc(r.reason) + '"' : "") + ">" + (r.status === "failed" ? '<span class="v-bad">failed</span>' : U.badge({ code: r.outcome, label: TWIN.OUTCOMES[r.outcome] ? TWIN.OUTCOMES[r.outcome].label : r.outcome })) + '</td><td class="mono">' + (r.metrics && r.metrics.settle_s != null ? fx(r.metrics.settle_s, 3) : "—") + '</td><td class="mono">' + (r.metrics && r.metrics.peakOmega_rpm != null ? fx(r.metrics.peakOmega_rpm, 0) : "—") + '</td><td><button type="button" class="act" data-sw="openRow" data-row="' + r.index + '">Open</button></td></tr>'; }).join("") + "</tbody></table></div>" + (rows.length > shown.length ? '<p class="small dim">First ' + shown.length + " of " + rows.length + " runs shown; the CSV export has all of them.</p>" : "") + '<p class="small dim"><b>Open</b> ' + (fromBackend(sw) ? "loads the exact configuration the backend saved for that run into Single experiment" : "re-creates that run\'s exact configuration in Single experiment") + ' so it can be run and replayed with full samples.</p></details>';
    h += '<div class="acts2"><button type="button" class="act" data-sw="exportSweep">Export sweep (JSON)</button><button type="button" class="act" data-sw="exportCSV">Export rows (CSV)</button><button type="button" class="act" data-sw="exportDataset">Export as dataset</button></div>';
    // v5: a research-backend sweep can be analysed again from its stored rows and turned into a dataset ON the backend
    // (created → finalised: immutable, member hashes → exported as one bundle with an integrity check)
    if (fromBackend(sw) && sw.id) h += '<div class="acts2 sw-be"><span class="small dim">Research backend:</span>' + (sw.partial ? '<button type="button" class="act" data-sw="beAnalyze">Analyse stored rows</button>' : "") +
      '<button type="button" class="act" data-sw="beDataset">Create dataset</button></div><div class="sw-beout" id="swBeOut" aria-live="polite">' + (S.ds && S.ds.members && S.ds.members.some(function (m) { return m.id === sw.id; }) ? dsHTML(S.ds) : "") + "</div>";
    h += '<div class="caveat"><p>All values above are computed from these ' + rows.length + " runs of " + esc(engineName(sw)) + " with " + esc((prov.validation && prov.validation.status) || "nominal") + " parameters" + (prov.mock ? ", returned by the MOCK research backend" : prov.demo ? ", in DEMO mode in this browser" : "") + ". They are not validated against the physical cube and are not the project's final research dataset.</p></div></div>";
    return h;
  }
  function drawCharts(sw) {
    var an = sw.analysis; if (!an || !S.el || S.el.hidden) return;
    an.maps.forEach(function (m, mi) {
      Object.keys(m.cells).forEach(function (c) {
        var cv = $("swMap" + mi + "-" + c); if (!cv) return;
        var cells = m.cells[c].map(function (x) { return { i: x.i, j: x.j, code: x.code, x: x.x, y: x.y, n: x.n, recovered: x.recovered }; });
        var map = Chart.cells(cv, { xs: m.xs, ys: m.ys, cells: cells, styles: CELL, xlabel: vlabel(m.x), ylabel: vlabel(m.y) });
        var tip = $("swTip" + mi + "-" + c);
        cv.onpointermove = function (e) { var r = cv.getBoundingClientRect(), mp = cv._map || map, cell = mp.cellAt(e.clientX - r.left, e.clientY - r.top); if (!cell || !cell.code) { tip.hidden = true; return; } tip.innerHTML = "<b>" + esc(CELL[cell.code].label) + "</b><span>" + esc(vlabel(m.x)) + " = " + sig(cell.x, 4) + "</span><span>" + esc(vlabel(m.y)) + " = " + sig(cell.y, 4) + '</span><span class="mono">' + cell.recovered + " of " + cell.n + " run(s) recovered</span>"; tip.hidden = false; tip.style.left = Math.max(4, Math.min(r.width - 190, e.clientX - r.left + 12)) + "px"; tip.style.top = Math.max(4, e.clientY - r.top - 60) + "px"; };
        cv.onpointerleave = function () { tip.hidden = true; };
      });
    });
    an.probability.forEach(function (p, pi) {
      var cv = $("swProb" + pi); if (!cv) return;
      var V = SW.VARIABLES[p.variable], ctls = Object.keys(p.per), xs = [];
      ctls.forEach(function (c) { p.per[c].forEach(function (g) { xs.push(g.x); }); });
      var lo = Math.min.apply(null, xs), hi = Math.max.apply(null, xs); if (!(hi > lo)) { lo -= 1; hi += 1; }
      cv._fixedH = window.innerWidth < 640 ? 180 : 210;
      Chart.line(cv, { xlim: [lo, hi], ylim: [0, 100], xlabel: V ? V.label + " [" + V.unit + "]" : p.variable, ylabel: "P(recovered) [%]",
        fills: ctls.map(function (c) { var g = p.per[c].filter(function (x) { return x.n > 0; }); return { x: g.map(function (x) { return x.x; }), y0: g.map(function (x) { return x.ci95[0] * 100; }), y1: g.map(function (x) { return x.ci95[1] * 100; }), color: TK.alpha(TK.controller(c).color, 0.13) }; }),
        series: ctls.map(function (c, i) { var g = p.per[c].filter(function (x) { return x.n > 0; }); return { x: g.map(function (x) { return x.x; }), y: g.map(function (x) { return x.p * 100; }), color: TK.controller(c).color, width: 2, marker: TK.controller(c).marker, markerOffset: 14 + i * 20 }; }) });
    });
    Object.keys(an.distributions).forEach(function (k, ki) {
      var dist = an.distributions[k];
      Object.keys(dist.per).forEach(function (c) {
        var cv = $("swHist" + ki + "-" + c); if (!cv) return; var hh = dist.per[c].hist, edges = [];
        for (var i = 0; i <= hh.counts.length; i++) edges.push(hh.lo + i * hh.width);
        cv._fixedH = 150;
        Chart.hist(cv, { edges: edges, counts: hh.counts, color: TK.controller(c).color, xlabel: "", ylabel: "runs", median: dist.per[c].median });
      });
    });
  }
  function openRow(index) {
    var sw = S.result; if (!sw || !sw.definition) return;
    if (fromBackend(sw)) {
      var api = S.ctx.service && S.ctx.service.adapter("research-api");
      if (!api || !api.available().ok) { toast("This sweep ran on the research backend. Connect it (Simulation mode) to open run " + index + " with the exact configuration it saved; the browser does not re-create backend runs."); return; }
      api.getSweepRow(sw.id, index).then(function (row) {
        if (!row || !row.config) { toast("The backend has no saved configuration for run " + index + "."); return; }
        if (S.ctx.openConfig) { S.ctx.openConfig(row.config); toast("Run " + index + " of " + sw.id + " loaded from the backend's saved configuration (" + TK.controller(row.controller).name + "). Press Run to run it on the backend with full samples."); }
      }, function (e) { toast("Could not load run " + index + ": " + (e && e.message || e)); });
      return;
    }
    var specs; try { specs = SW.expand(sw.definition); } catch (e) { toast("Could not rebuild the run: " + e.message); return; }
    var sp = specs[index]; if (!sp) { toast("Run " + index + " is not in this sweep's definition."); return; }
    if (S.ctx.openConfig) { S.ctx.openConfig(sp.config); toast("Run " + index + " of " + sw.id + " loaded into Single experiment (" + TK.controller(sp.controller).name + "). Press Run to replay it with full samples."); }
  }
  function rowsCSV(sw) { return SW.toCSV(sw); }
  function datasetOf(sw) { return SW.toDataset(sw); }
  /* ---------------- research-backend datasets (create → finalise → export) ---------------- */
  function beApi() { return S.ctx.service && S.ctx.service.adapter ? S.ctx.service.adapter("research-api") : null; }
  function beOut(html) { var o = $("swBeOut"); if (o) o.innerHTML = html; }
  function beErr(e) { beOut('<p class="v-bad small">' + esc(e && e.message || String(e)) + "</p>"); }
  function beAnalyze() {
    var api = beApi(), sw = S.result; if (!api) return;
    beOut('<p class="small dim">Asking the research backend to analyse the ' + (sw.rows || []).length + " stored rows…</p>");
    api.analyzeSweep(sw.id).then(function (r) {
      sw.analysis = r.analysis; sw.analysis_note = "Analysis of the " + r.rows + " stored rows of this " + r.status + " sweep, computed by the research backend on request (the stored sweep itself is unchanged).";
      renderOut(); beOut('<p class="small v-ok">Analysed ' + r.rows + " stored rows" + (r.total ? " of " + r.total : "") + ".</p>");
    }, beErr);
  }
  function dsHTML(d) {
    var fin = d.finalized;
    return '<div class="sw-ds"><p class="small"><b class="mono">' + esc(d.id) + "</b> · dataset <b>" + esc(d.status === "final" ? "FINAL" : "exploratory") + "</b> · " + d.members.length + " member(s)" + (d.provenance && d.provenance.contains_synthetic ? " · contains SYNTHETIC telemetry" : "") + "</p>" +
      (fin ? '<p class="small dim">Finalised ' + esc(fin.at) + " · content hash <span class=\"mono\">" + esc(String(fin.content_hash).slice(0, 16)) + "…</span> · final datasets never change.</p>" : '<p class="small dim">Exploratory: finalise it to freeze its member list and member content (hashes are recorded).</p>') +
      '<div class="btnrow">' + (fin ? "" : '<button type="button" class="act" data-sw="beFinalize">Finalise</button>') + '<button type="button" class="act" data-sw="beExport">Export dataset (JSON bundle)</button></div></div>';
  }
  function beDataset() {
    var api = beApi(), sw = S.result; if (!api) return;
    beOut('<p class="small dim">Creating a dataset on the research backend…</p>');
    api.createDataset({ title: sw.name || sw.id, sweep_ids: [sw.id], description: "Created from the Lab's research sweep view." }).then(function (d) { S.ds = d; beOut(dsHTML(d)); }, beErr);
  }
  function beFinalize() {
    var api = beApi(); if (!api) return;
    api.finalizeDataset(S.ds.id).then(function (d) { S.ds = d; beOut(dsHTML(d)); toast("Dataset " + d.id + " is final."); }, beErr);
  }
  function beExport() {
    var api = beApi(); if (!api) return;
    api.request("GET", "/datasets/" + encodeURIComponent(S.ds.id) + "/export").then(function (bundle) {
      S.lastBundle = bundle;
      S.ctx.exportText(S.ds.id + ".json", JSON.stringify(bundle, null, 1), "application/json", "Dataset bundle (aeris-dataset-bundle/1)");
      var ig = bundle.integrity;
      beOut(dsHTML(S.ds) + '<p class="small ' + (ig && ig.member_content_ok === false ? "v-bad" : "v-ok") + '">Exported ' + esc(S.ds.id) + ".json" + (ig ? " · integrity: member list " + (ig.members_hash_ok ? "unchanged" : "CHANGED") + ", member content " + (ig.member_content_ok === false ? "CHANGED (" + ig.changed_members.join(", ") + ")" : ig.member_content_ok ? "unchanged" : "not recorded") : "") + "</p>");
    }, beErr);
  }
  function importDialog() {
    var out = U.el("div", { cls: "imp-out", "aria-live": "polite" });
    var m = U.modal({ title: "Import a sweep", text: "Paste an aeris-sweep/1 file: a definition (loaded into the form) or a sweep with results (opened read-only).", textarea: "", taLabel: "Paste JSON here", actions: [{ label: "Import", primary: true, run: function (v) {
      var obj; try { obj = JSON.parse(v); } catch (e) { out.innerHTML = '<p class="v-bad">Not valid JSON: ' + esc(e.message) + "</p>"; return false; }
      if (!obj || obj.schema !== SW.SCHEMA_ID) { out.innerHTML = '<p class="v-bad">Expected schema "' + SW.SCHEMA_ID + '".</p>'; return false; }
      if (Array.isArray(obj.rows) && obj.definition) { obj.imported = true; S.result = obj; S.job = null; S.fresh = false; renderOut(); out.innerHTML = '<p class="v-ok">Sweep ' + esc(obj.id || "") + " opened (" + obj.rows.length + " runs).</p>"; if (!obj.analysis && obj.rows.length) { try { obj.analysis = SW.analyze(obj.definition, obj.rows); renderOut(); } catch (e) { /* keep rows only */ } } return false; }
      var v2 = S.ctx.service && S.ctx.service.validateSweep ? S.ctx.service.validateSweep(obj) : SW.validate(obj, { limits: SW.LIMITS.local }); S.def = v2.def; renderDef(); out.innerHTML = '<p class="v-ok">Definition loaded into the form.' + (v2.errors.length ? ' <span class="v-warn">' + v2.errors.length + " problem(s) listed under the form.</span>" : "") + "</p>"; return false;
    } }] });
    m.box.appendChild(out);
  }
  return { mount: mount, show: show, PRESETS: PRESETS, CELL: CELL, datasetOf: datasetOf, rowsCSV: rowsCSV, _state: S };
})();

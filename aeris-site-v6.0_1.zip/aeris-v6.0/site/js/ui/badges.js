/* =====================================================================
   AERIS · BADGES — the small labels that say where data came from and
   how far it can be trusted. Pure string builders (no DOM), shared by
   every page and tested in node.

   Three families, never mixed:
   - SOURCE (what the screen shows now):  SIMULATION · HARDWARE · REPLAY
   - CLAIM  (what the data is):           SIMULATED · MEASURED · NOMINAL · VALIDATED ·
                                          HARDWARE DATA PENDING · SIM ↔ HARDWARE VALIDATION PENDING
   - MARKS  (not research data):          DEMO MODE · DEMO DATA · MOCK DATA · EXAMPLE · PARTIAL
   Every badge is text first; colour only repeats what the text says.
   ===================================================================== */
var AERIS_BADGES = (function () {
  "use strict";
  var T = typeof AERIS_TOKENS !== "undefined" ? AERIS_TOKENS : require("../platform/tokens.js");
  var SCHEMA = typeof AERIS_SCHEMA !== "undefined" ? AERIS_SCHEMA : require("../platform/schema.js");
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  var SOURCE = {
    simulation: { text: "SIMULATION", cls: "src-sim", title: "Computed by a physics-based digital model (AERIS Twin)." },
    hardware: { text: "HARDWARE", cls: "src-hw", title: "Measured on the physical AERIS Cube." },
    replay: { text: "REPLAY", cls: "src-replay", title: "A saved recording played back; nothing is being computed or measured now." }
  };
  var CLAIM = {
    simulated: { text: "SIMULATED", cls: "cl-sim", title: "Output of the AERIS Twin model, not a measurement." },
    measured: { text: "MEASURED", cls: "cl-hw", title: "Measured on the physical cube." },
    nominal: { text: "NOMINAL", cls: "cl-nominal", title: SCHEMA.VALIDATION.nominal.text },
    measuredParams: { text: "MEASURED PARAMETERS", cls: "cl-hw", title: SCHEMA.VALIDATION.measured.text },
    validated: { text: "VALIDATED", cls: "cl-ok", title: SCHEMA.VALIDATION.validated.text },
    hwPending: { text: "HARDWARE DATA PENDING", cls: "cl-pending", title: "No measurements from the physical cube have been added yet." },
    valPending: { text: "SIM ↔ HARDWARE VALIDATION PENDING", cls: "cl-pending", title: "The model has not been compared with hardware runs yet." }
  };
  var MARK = {
    demoMode: { text: "DEMO MODE", cls: "mk-demo", title: "Computed in this browser by the AERIS Twin engine (small runs, nominal parameters). Exploratory, not a research dataset." },
    demoData: { text: "DEMO DATA", cls: "mk-demo", title: "Illustrative values, not results." },
    mockData: { text: "MOCK DATA", cls: "mk-mock", title: "Returned by the mock research backend used for interface testing. Not research output." },
    example: { text: "EXAMPLE", cls: "mk-example", title: "A built-in example experiment with a fixed setup." },
    partial: { text: "PARTIAL", cls: "mk-partial", title: "The job was cancelled; only the runs finished before cancelling are included." }
  };
  var ROLE = {
    controlled: { text: "CONTROLLED · FIXED", cls: "role-fixed", title: "Held constant across the experiment." },
    independent: { text: "CHANGED · INDEPENDENT", cls: "role-indep", title: "Deliberately varied by the experiment." },
    dependent: { text: "MEASURED · DEPENDENT", cls: "role-dep", title: "Measured as the result." }
  };
  var MODE = {
    demo: { text: "DEMO", cls: "mode-demo" },
    simulation: { text: "SIMULATION", cls: "mode-sim" },
    hardware: { text: "HARDWARE", cls: "mode-hw" }
  };
  function chip(def, extra) { return '<span class="bdg ' + def.cls + (extra ? " " + extra : "") + '"' + (def.title ? ' title="' + esc(def.title) + '"' : "") + "><i aria-hidden=\"true\"></i>" + esc(def.text) + "</span>"; }
  function source(kind) { return chip(SOURCE[kind] || { text: String(kind).toUpperCase(), cls: "src-other" }); }
  function claim(key) { var d = CLAIM[key]; return d ? chip(d) : ""; }
  function mark(key) { var d = MARK[key]; return d ? chip(d) : ""; }
  function role(key) { var d = ROLE[key]; return d ? chip(d) : ""; }
  function mode(key) { var d = MODE[key]; return d ? chip(d) : ""; }
  /* validation state of a model/parameter set → claim key */
  function validationKey(status) { return status === "validated" ? "validated" : status === "measured" ? "measuredParams" : "nominal"; }
  /* the badge set for one run record. view: "fresh" (just computed here) or "saved" */
  function keysForRecord(rec, view) {
    if (!rec) return [];
    var ds = SCHEMA.describeSource(rec, view), out = [{ family: "source", key: ds.display }];
    out.push({ family: "claim", key: ds.origin === "hardware" ? "measured" : "simulated" });
    if (ds.origin !== "hardware") out.push({ family: "claim", key: validationKey(rec.validation && rec.validation.status) });
    if (rec.origin && rec.origin.engine === "mock-research-backend") out.push({ family: "mark", key: "mockData" });
    if (rec.collection === "example") out.push({ family: "mark", key: "example" });
    return out;
  }
  function render(keys) { return keys.map(function (k) { return k.family === "source" ? source(k.key) : k.family === "claim" ? claim(k.key) : k.family === "mark" ? mark(k.key) : k.family === "role" ? role(k.key) : mode(k.key); }).join(""); }
  function forRecord(rec, view) { return '<span class="bdgs">' + render(keysForRecord(rec, view)) + "</span>"; }
  /* the badge set for a sweep result */
  function keysForSweep(sw) {
    var out = [{ family: "source", key: "simulation" }, { family: "claim", key: "simulated" }];
    var p = (sw && sw.provenance) || {};
    out.push({ family: "claim", key: validationKey(p.validation && p.validation.status) });
    if (p.mock) out.push({ family: "mark", key: "mockData" });
    else if (p.demo) out.push({ family: "mark", key: "demoMode" });
    if (sw && sw.partial) out.push({ family: "mark", key: "partial" });
    return out;
  }
  function forSweep(sw) { return '<span class="bdgs">' + render(keysForSweep(sw)) + "</span>"; }
  /* controller chip: marker glyph in the controller colour + name in text ink */
  function controller(key, opts) {
    var c = T.controller(key), label = opts && opts.long ? c.name : c.short;
    return '<span class="cchip cchip-' + esc(c.key) + '" title="' + esc(c.name) + '"><i aria-hidden="true" style="color:' + c.color + '">' + c.glyph + "</i>" + esc(label) + "</span>";
  }
  /* outcome badge with icon (tone class matches css: ok / warn / bad) */
  function outcome(o) {
    if (!o) return "";
    var d = T.outcome(o.code), cls = d.tone === "stable" ? "ok" : d.tone === "failure" ? "bad" : "warn";
    return '<span class="oc-badge ' + cls + '" data-icon="' + d.icon + '">' + esc(o.label || o.code) + "</span>";
  }
  return { SOURCE: SOURCE, CLAIM: CLAIM, MARK: MARK, ROLE: ROLE, MODE: MODE, source: source, claim: claim, mark: mark, role: role, mode: mode,
    validationKey: validationKey, keysForRecord: keysForRecord, forRecord: forRecord, keysForSweep: keysForSweep, forSweep: forSweep, render: render, controller: controller, outcome: outcome, esc: esc };
})();
if (typeof module !== "undefined") module.exports = AERIS_BADGES;

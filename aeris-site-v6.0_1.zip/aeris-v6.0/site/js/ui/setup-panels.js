/* =====================================================================
   AERIS · SETUP PANELS — parts of the Lab's “Create experiment” form that
   are driven by engine metadata rather than hand-written markup:

   - sensor and actuator settings in three tiers (BASIC / ADVANCED / EXPERT),
     generated from AERIS_TWIN.SENSOR_SPEC so the form and the engine
     cannot disagree about names, units or ranges;
   - the COM shift (x, y, z) that models an asymmetric build;
   - the controller card: what the selected controller measures, assumes
     and adapts (js/platform/controllers.js).

   The workspace passes its own field renderers (ctx.num / ctx.sel), so
   these panels use the same data-path binding and validation as the rest
   of the form.
   ===================================================================== */
var AERIS_SETUP_UI = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var CTRL = typeof AERIS_CONTROLLERS !== "undefined" ? AERIS_CONTROLLERS : require("../platform/controllers.js");
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  var TIERS = [{ key: "basic", label: "Basic" }, { key: "advanced", label: "Advanced" }, { key: "expert", label: "Expert" }];
  var RANK = { basic: 0, advanced: 1, expert: 2 };
  /* every sensor / actuator input with its tier (sensor fields come from the engine's own spec) */
  function fields() {
    var S = TWIN.SENSOR_SPEC, out = [];
    ["gyro_noise_dps", "accel_noise_mps2", "gyro_bias_dps", "latency_ms", "dropout", "gyro_bias_walk_dps", "gyro_quant_dps", "accel_quant_deg"].forEach(function (k) { var sp = S[k]; out.push({ group: "sensor", path: "sensor." + k, label: sp.label, unit: sp.unit, tier: sp.tier, min: sp.min, max: sp.max }); });
    out.push({ group: "sensor", path: "sensor.rate_hz", label: "IMU sample rate", unit: "Hz", tier: "advanced", nullable: true, help: "Empty = the control-loop rate. The browser engine samples at the loop rate; another value is recorded for the research backend." });
    out.push({ group: "actuator", path: "actuator.motor_lag_ms", label: "Motor torque lag τm", unit: "ms", tier: "advanced", min: 0, max: 200 });
    ["x", "y", "z"].forEach(function (w) { out.push({ group: "actuator", path: "actuator.wheel_health." + w, label: "Wheel " + w.toUpperCase() + " torque capability", unit: "× nominal", tier: "expert", min: 0, max: 1 }); });
    return out;
  }
  function visible(tier) { var r = RANK[tier] == null ? 0 : RANK[tier]; return fields().filter(function (f) { return RANK[f.tier] <= r; }); }
  /* notes that say when settings have no effect (the same conditions the engine warns about) */
  function effectNotes(draft) {
    var n = [];
    if (draft.mode === "corner") n.push("Corner mode uses ideal state feedback: sensor settings are saved with the run but have no effect in this engine.");
    else if (draft.estimator && draft.estimator.type === "ideal") n.push("Sensing is set to “Ideal state”: sensor settings have no effect until you choose an estimator.");
    if (draft.mode === "edge") n.push("Edge mode drives wheel X only; wheel Y and Z capability have no effect.");
    return n;
  }
  function sensorGroup(ctx) {
    var d = ctx.draft, tier = RANK[ctx.tier] == null ? "basic" : ctx.tier, list = visible(tier), hidden = fields().length - list.length;
    var h = '<details class="grp" id="grpSensors"' + (ctx.open ? " open" : "") + '><summary>Sensors and actuators <span class="cnt">' + tier.toUpperCase() + "</span></summary>";
    h += '<div class="tiers" role="radiogroup" aria-label="Detail level">' + TIERS.map(function (t) { return '<label><input type="radio" name="sensorTier" value="' + t.key + '"' + (t.key === tier ? " checked" : "") + "><span>" + t.label + "</span></label>"; }).join("") + "</div>";
    ["sensor", "actuator"].forEach(function (g) {
      var fs = list.filter(function (f) { return f.group === g; }); if (!fs.length) return;
      h += '<p class="sub-h">' + (g === "sensor" ? "IMU (gyro and accelerometer)" : "Motors and wheels") + '</p><div class="row2">' + fs.map(function (f) { return ctx.num(f.path, f.label, f.unit, 1, { nullable: f.nullable }); }).join("") + "</div>";
      fs.filter(function (f) { return f.help; }).forEach(function (f) { h += '<p class="help">' + esc(f.help) + "</p>"; });
    });
    if (hidden) h += '<p class="help">' + hidden + " more setting" + (hidden === 1 ? "" : "s") + " at a higher detail level. Hidden settings keep their values.</p>";
    effectNotes(d).forEach(function (t) { h += '<p class="help note">' + esc(t) + "</p>"; });
    h += '<p class="help">Defaults reproduce the fixed sensor model of engine 0.2 (0.16 °/s gyro noise, 0.5 °/s initial bias, 0.047 m/s² accelerometer noise; no latency, dropout, quantisation or motor lag). They are nominal values, not measurements of the cube’s IMU.</p></details>';
    return h;
  }
  function comShiftFields(ctx) {
    return '<p class="sub-h">COM shift of the build <span class="dim">(body frame)</span></p><div class="row3">' + ["x", "y", "z"].map(function (w, i) { return ctx.num("comShift_m." + i, "Δ" + w, "mm", 1000); }).join("") + '</div><p class="help">Moves the bare cube\'s centre of mass by (Δx, Δy, Δz), for example to model an asymmetric build. Unlike the offset δ above it can point in any direction. Nominal: 0.</p>';
  }
  function controllerCard(type) {
    var c = CTRL.get(type); if (!c) return "";
    function li(a) { return a.length ? "<ul>" + a.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul>" : '<p class="dim">—</p>'; }
    return '<div class="ctl-card" data-ctl="' + esc(type) + '"><div class="cc-h">' + (typeof AERIS_BADGES !== "undefined" ? AERIS_BADGES.controller(type, { long: true }) : esc(c.name)) + '<span class="cc-f">' + esc(c.family) + "</span></div>" +
      '<p class="cc-s">' + esc(c.summary) + "</p>" +
      (type === "none" ? "" : '<dl class="cc-dl"><dt>Measures</dt><dd>' + li(c.measures) + "</dd><dt>Assumes</dt><dd>" + li(c.assumes) + "</dd><dt>Adapts</dt><dd><p>" + esc(c.adapts) + "</p></dd></dl>" +
      '<details class="cc-more"><summary>Design and limits</summary><p>' + esc(c.design) + "</p><p>" + esc(c.limits) + "</p>" + (c.corner ? "<p>" + esc(c.corner) + "</p>" : "") + "</details>") + "</div>";
  }
  return { TIERS: TIERS, fields: fields, visible: visible, effectNotes: effectNotes, sensorGroup: sensorGroup, comShiftFields: comShiftFields, controllerCard: controllerCard };
})();
if (typeof module !== "undefined") module.exports = AERIS_SETUP_UI;

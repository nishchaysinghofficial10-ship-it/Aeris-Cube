/* =====================================================================
   AERIS · EVENT TIMELINE (Lab) — one strip under the playback bar that
   marks every event of the open run on the same time axis as the plots:
   inputs (loads, wheel failures, yaw commands), actuator limits
   (saturation, speed risk / limit), control (reconfiguration, estimator
   warnings) and outcome (recovered, fall, end).

   Clicking a mark, or a row of the event list, moves the playback time
   there; update(t) moves the cursor and lists what is active now, so the
   3-D view, plots, telemetry and timeline always show the same instant.
   The strip is for pointer users; the list (real buttons) is the keyboard
   and screen-reader route to the same events.
   ===================================================================== */
var AERIS_TIMELINE = (function () {
  "use strict";
  var EV = typeof AERIS_EVENTS !== "undefined" ? AERIS_EVENTS : require("../platform/events.js");
  var T = typeof AERIS_TOKENS !== "undefined" ? AERIS_TOKENS : require("../platform/tokens.js");
  var LANES = [
    { key: "input", label: "Inputs", types: ["disturbance", "wheel_failure", "yaw_command"] },
    { key: "actuator", label: "Actuators", types: ["saturation", "speed_risk", "speed_limit"] },
    { key: "control", label: "Control", types: ["controller_mode", "estimator_warning"] },
    { key: "outcome", label: "Outcome", types: ["recovered", "fall", "floor_contact", "termination", "numerical_failure"] }
  ];
  var ICON = { failure: "✕", warning: "▲", stable: "✓", info: "●" };
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function f3(x) { return (+x).toFixed(3).replace("-", "−"); }
  function laneOf(type) { for (var i = 0; i < LANES.length; i++) if (LANES[i].types.indexOf(type) >= 0) return LANES[i].key; return "outcome"; }
  /* events grouped by lane (pure) */
  function lanes(tl) {
    var out = {}; LANES.forEach(function (L) { out[L.key] = []; });
    (tl.events || []).forEach(function (e, i) { out[laneOf(e.type)].push({ i: i, e: e }); });
    return out;
  }
  function colorOf(e) { return e.type === "disturbance" ? T.color.physics.load : e.type === "speed_risk" ? T.alpha(T.color.status.warning, 0.55) : T.statusColor(e.severity === "info" ? "neutral" : e.severity); }
  function when(e) { return e.t_end != null ? f3(e.t) + "–" + f3(e.t_end) + " s" : f3(e.t) + " s"; }
  function render(el, run, opts) {
    if (!el) return;
    opts = opts || {};
    if (!run) { el.innerHTML = ""; el.hidden = true; el._tl = null; el.removeAttribute("data-run"); el.removeAttribute("data-t"); return; }
    el.hidden = false; el.setAttribute("data-run", run.id); el.removeAttribute("data-t");
    var tl = EV.timelineOf(run), dur = Math.max(run.config.duration_s, (run.samples.cols.t || [0]).slice(-1)[0] || 0) || 1, L = lanes(tl);
    var visible = tl.events.filter(function (e) { return e.type !== "termination"; });
    var h = '<div class="tl-head"><span class="tl-title">Event timeline</span><span class="tl-count mono">' + visible.length + " event" + (visible.length === 1 ? "" : "s") + "</span>" +
      '<span class="tl-now" id="tlNow" aria-live="off"></span></div>';
    h += '<div class="tl-track" aria-hidden="true">' + LANES.map(function (ln) {
      return '<div class="tl-lane" data-lane="' + ln.key + '"><span class="tl-ll">' + ln.label + '</span><div class="tl-lt">' + L[ln.key].map(function (o) {
        var e = o.e, left = Math.max(0, Math.min(100, e.t / dur * 100)), col = colorOf(e);
        if (e.type === "termination") return "";
        if (e.t_end != null && e.t_end > e.t) { var w = Math.max(0.35, (Math.min(dur, e.t_end) - e.t) / dur * 100); return '<span class="tl-iv" data-i="' + o.i + '" style="left:' + left.toFixed(3) + "%;width:" + w.toFixed(3) + "%;background:" + col + '" title="' + esc(e.label + " · " + when(e)) + '"></span>'; }
        return '<span class="tl-pt sev-' + e.severity + '" data-i="' + o.i + '" style="left:' + left.toFixed(3) + "%;color:" + col + '" title="' + esc(e.label + " · " + when(e)) + '">' + (ICON[e.severity] || "●") + "</span>";
      }).join("") + "</div></div>";
    }).join("") + '<div class="tl-cwrap"><div class="tl-cursor" id="tlCursor"></div></div></div>';
    h += '<details class="tl-more"><summary>All events (' + visible.length + ")</summary><ol class=\"tl-list\">" + tl.events.map(function (e, i) {
      return '<li data-i="' + i + '"><button type="button" class="tl-go" data-t="' + e.t + '"><span class="mono">' + when(e) + '</span></button><span class="tl-ic sev-' + e.severity + '" aria-hidden="true" style="color:' + colorOf(e) + '">' + (ICON[e.severity] || "●") + '</span><span class="tl-lb"><b>' + esc(e.label) + "</b> " + esc(e.detail || "") + "</span></li>";
    }).join("") + "</ol>" + (tl.rebuilt ? '<p class="small dim">This run was saved before event timelines existed; the events were rebuilt from its recorded samples (' + (tl.resolution_s ? Math.round(1 / tl.resolution_s) + " Hz" : "recording") + " resolution).</p>" : '<p class="small dim">Detected by the engine at every integration step' + (tl.resolution_s ? " (" + f3(tl.resolution_s * 1000) + " ms)" : "") + ". Definitions travel with the run.</p>") + "</details>";
    el.innerHTML = h;
    el._tl = tl; el._dur = dur;
    var track = el.querySelector(".tl-track");
    track.addEventListener("click", function (ev) {
      var mk = ev.target.closest("[data-i]");
      if (mk) { var e = tl.events[+mk.getAttribute("data-i")]; if (e && opts.onSeek) opts.onSeek(e.t); return; }
      var lt = ev.target.closest(".tl-lt") || track.querySelector(".tl-lt"); if (!lt || !opts.onSeek) return;
      var r = lt.getBoundingClientRect(); opts.onSeek(Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)) * dur);
    });
    el.querySelectorAll(".tl-go").forEach(function (b) { b.addEventListener("click", function () { if (opts.onSeek) opts.onSeek(+b.getAttribute("data-t")); }); });
  }
  function update(el, t, halfStep) {
    if (!el || !el._tl) return;
    var tl = el._tl, dur = el._dur, cur = el.querySelector("#tlCursor");
    el.setAttribute("data-t", String(t));      // the time the cursor shows (tests compare it with the replay)
    if (cur) cur.style.left = (Math.max(0, Math.min(1, t / dur)) * 100).toFixed(3) + "%";
    var act = EV.activeAt(tl, t, halfStep || 0.006).filter(function (e) { return e.type !== "termination"; });
    var on = {}; act.forEach(function (e) { on[tl.events.indexOf(e)] = true; });
    el.querySelectorAll(".tl-track [data-i]").forEach(function (s) { s.classList.toggle("on", !!on[s.getAttribute("data-i")]); });
    el.querySelectorAll(".tl-list li").forEach(function (li) { if (on[li.getAttribute("data-i")]) li.setAttribute("aria-current", "true"); else li.removeAttribute("aria-current"); });
    var now = el.querySelector("#tlNow");
    if (now) now.innerHTML = act.length ? "Now: " + act.map(function (e) { return '<span class="sev-' + e.severity + '"><i aria-hidden="true" style="color:' + colorOf(e) + '">' + (ICON[e.severity] || "●") + "</i> " + esc(e.label) + "</span>"; }).join(" · ") : '<span class="dim">No event active at this time.</span>';
  }
  return { LANES: LANES, ICON: ICON, lanes: lanes, laneOf: laneOf, render: render, update: update };
})();
if (typeof module !== "undefined") module.exports = AERIS_TIMELINE;

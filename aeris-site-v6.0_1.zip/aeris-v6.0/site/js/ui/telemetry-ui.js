/* =====================================================================
   AERIS LAB · TELEMETRY (loaded on demand when the Telemetry tab is first
   opened). docs/TELEMETRY.md

   source → research backend (strict validation, normalised stream) → this
   panel (live pose, values, stream quality) → recording (stored on the
   backend) → export / replay / offline comparison with a simulated run.

   Read-only: nothing here sends anything to a device. The banner always
   shows what the SOURCE declared: the synthetic emulator is "SYNTHETIC …
   not the physical cube"; a declared physical device is "declared, not
   verified". A comparison with synthetic data is computed but is never
   validation evidence, and no telemetry changes a model's status.

   Backend restarts (v5.1): frame indices belong to the backend's stream
   (stream_id). When the stream changes while this page is open, the frame,
   the drawing state and the per-page counters of the old stream are
   dropped and the new stream's frames are shown as they arrive.
   ===================================================================== */
var AERIS_TELEMETRY_UI = (function () {
  "use strict";
  var $ = U.$, esc = U.esc, fx = U.fx, B = AERIS_BADGES, TWIN = AERIS_TWIN, DEG = TWIN.DEG;
  var S = { el: null, ctx: null, hw: null, stream: null, status: null, latest: null, viewer: null, sceneMode: null, ang: [0, 0, 0], lastT: null,
    raf: 0, lastRead: 0, transport: null, dropped: 0, missed: 0, recs: [], runs: null, files: [], srcKind: "tcp", visible: false, cmp: null, busy: false, statusTimer: null,
    streamId: null, streamChanges: 0, streamNote: null };

  function adapter() { return S.ctx.service && S.ctx.service.adapter ? S.ctx.service.adapter("hardware-telemetry") : (typeof HardwareTelemetryAdapter !== "undefined" ? HardwareTelemetryAdapter : null); }

  /* ---------------- mount ---------------- */
  function mount(el, ctx) {
    S.el = el; S.ctx = ctx || {}; S.hw = adapter();
    el.innerHTML =
      '<div class="tm-banner" id="tmBanner" data-kind="none" role="status" aria-live="polite"><b id="tmBannerT">No telemetry source</b><span id="tmBannerS"></span></div>' +
      '<div class="sw-grid tm-grid">' +
      '<section class="sw-def tm-side" aria-label="Telemetry source and recording">' +
      '<p class="sub-h">Source</p>' +
      '<div class="seg2 tm-kind" role="radiogroup" aria-label="Source type"><label><input type="radio" name="tmKind" value="tcp" checked><span>NDJSON over TCP</span></label><label><input type="radio" name="tmKind" value="file"><span>File replay</span></label><label><input type="radio" name="tmKind" value="recording"><span>Stored recording</span></label></div>' +
      '<div id="tmFields"></div>' +
      '<div class="btnrow"><button type="button" class="btn btn-solid btn-sm" id="tmConnect">Connect</button><button type="button" class="act" id="tmDisconnect">Disconnect</button></div>' +
      '<p class="small" id="tmSrc" aria-live="polite"></p>' +
      '<p class="help">Read-only: the backend only listens; nothing is ever sent to a device. The source must describe itself in its first line (hello). For a SYNTHETIC test stream start the emulator on this computer: <code>python -m aeris_backend.telemetry.emulator</code> (port 47100). It simulates the cube with nominal parameters and says so in every session.</p>' +
      '<p class="sub-h">Recording</p>' +
      '<div class="fld"><label for="tmRecName">Name</label><input id="tmRecName" type="text" maxlength="200" value="telemetry recording"></div>' +
      '<div class="btnrow"><button type="button" class="act" id="tmRecStart">Start recording</button><button type="button" class="act" id="tmRecStop" disabled>Stop and save</button></div>' +
      '<p class="small" id="tmRecState" aria-live="polite"></p>' +
      '</section>' +
      '<section class="sw-out tm-main" aria-label="Live telemetry">' +
      '<div class="tm-live"><div class="vw-stage tm-stage" id="tmStage" aria-label="3-D view of the attitude reported by the telemetry source"><canvas id="tmCanvas"></canvas><div class="ovl tl" id="tmTag"></div><div class="ovl tr mono" id="tmT"></div>' +
      '<div class="vw-fallback">3-D view unavailable (WebGL is off). The values beside it are unaffected.</div></div>' +
      '<dl class="tm-read" id="tmRead"></dl></div>' +
      '<p class="sub-h">Stream quality <span class="u">this source, since it was connected</span></p><div id="tmQuality"></div>' +
      '<p class="sub-h">Stored recordings <button type="button" class="act tm-mini" id="tmRecsRefresh">Refresh</button></p><div id="tmRecs"></div>' +
      '<div id="tmCmp" aria-live="polite"></div>' +
      '</section></div>';
    el.addEventListener("click", onClick);
    el.addEventListener("change", onChange);
    renderFields(); renderRead(null); renderQuality(); renderRecs();
    // availability follows the research backend's probe (configured is not reachable): re-check when it reports
    if (S.ctx.service && S.ctx.service.onChange) S.ctx.service.onChange(function (ev) { if (ev.type === "backend" && S.visible) show(); });
    show();
  }

  function show() {
    S.visible = true;
    var hw = S.hw, av = hw ? hw.available() : { ok: false, reason: "No telemetry adapter is registered." };
    setDisabled(!av.ok);
    if (!av.ok) { banner({ cls: "none", text: "Telemetry unavailable" }, av.reason); stopStream(); reprobeSoon(); return; }
    ensureViewer();
    startStream();
    refreshStatus(); refreshRecs(); if (S.srcKind === "file") refreshFiles();
    if (!S.statusTimer) S.statusTimer = setInterval(function () { if (S.visible && !document.hidden) refreshStatus(); }, 2000);
  }
  function hide() { S.visible = false; stopStream(); if (S.statusTimer) { clearInterval(S.statusTimer); S.statusTimer = null; } if (S.reprobe) { clearTimeout(S.reprobe); S.reprobe = null; } }
  /* the research backend is configured but did not answer (e.g. it is being restarted): while this tab is open, ask
     again every few seconds instead of waiting for the site's periodic probe (a minute), so the telemetry comes back
     as soon as the backend does (v5.1). A backend that answers but has telemetry switched off is not asked again. */
  function reprobeSoon() {
    var api = S.hw && S.hw.bound ? S.hw.bound() : null, svc = S.ctx.service;
    if (S.reprobe || !S.visible || !api || !api.configured || !api.configured() || api.available().ok || !svc || !svc.probe) return;
    S.reprobe = setTimeout(function () { S.reprobe = null; if (S.visible && !document.hidden) svc.probe(); else reprobeSoon(); }, 3000);
  }
  function setDisabled(off) { ["tmConnect", "tmDisconnect", "tmRecStart"].forEach(function (id) { var b = $(id); if (b) b.disabled = off; }); }

  /* ---------------- source form ---------------- */
  function renderFields() {
    var h = "";
    if (S.srcKind === "tcp") h = '<div class="row2"><div class="fld"><label for="tmHost">Host</label><input id="tmHost" type="text" value="127.0.0.1" spellcheck="false" aria-describedby="tmHostHelp"></div><div class="fld"><label for="tmPort">Port</label><input id="tmPort" type="number" min="1" max="65535" step="1" value="47100"></div></div><p class="help" id="tmHostHelp">This computer only (loopback) unless the backend was started with AERIS_TELEMETRY_ALLOW_REMOTE=1. The backend reconnects if the source drops.</p>';
    else if (S.srcKind === "file") h = '<div class="fld"><label for="tmFile">NDJSON file in the backend\'s telemetry directory</label><select id="tmFile">' + (S.files.length ? S.files.map(function (f) { return '<option value="' + esc(f.name) + '">' + esc(f.name) + " (" + Math.round(f.bytes / 1024) + " kB)</option>"; }).join("") : '<option value="">No .ndjson files found</option>') + '</select></div>' + speedField();
    else h = '<div class="fld"><label for="tmRec">Stored recording</label><select id="tmRec">' + (S.recs.length ? S.recs.map(function (r) { return '<option value="' + esc(r.id) + '">' + esc(r.id + " · " + (r.name || "") + (r.synthetic ? " · SYNTHETIC" : "")) + "</option>"; }).join("") : '<option value="">No stored recordings yet</option>') + "</select></div>" + speedField();
    $("tmFields").innerHTML = h;
  }
  function speedField() { return '<div class="fld"><label for="tmSpeed">Replay speed <span class="u">× recorded time; 0 = as fast as possible</span></label><input id="tmSpeed" type="number" min="0" max="100" step="any" value="1"></div>'; }
  function spec() {
    if (S.srcKind === "tcp") { var port = Number($("tmPort").value); return { source: "tcp", host: String($("tmHost").value || "").trim(), port: Number.isInteger(port) ? port : $("tmPort").value }; }
    var sp = Number($("tmSpeed").value);
    if (S.srcKind === "file") return { source: "file", path: $("tmFile").value, speed: isFinite(sp) ? sp : 1 };
    return { source: "recording", recording_id: $("tmRec").value, speed: isFinite(sp) ? sp : 1 };
  }
  function onChange(e) {
    if (e.target.name === "tmKind") { S.srcKind = e.target.value; renderFields(); if (S.srcKind === "file") refreshFiles(); if (S.srcKind === "recording") refreshRecs(); }
  }
  function errText(e) { return esc(e && e.message || String(e)) + (e && e.details && e.details.length ? " (" + e.details.map(function (d) { return esc((d.path ? d.path + ": " : "") + d.message); }).join("; ") + ")" : ""); }
  function onClick(e) {
    var t = e.target.closest("button"); if (!t || t.disabled) return;
    var hw = S.hw;
    if (t.id === "tmConnect") {
      var sp = spec(); $("tmSrc").innerHTML = '<span class="dim">Asking the backend to connect…</span>';
      hw.connect(sp).then(applyStatus, function (er) { $("tmSrc").innerHTML = '<span class="v-bad">' + errText(er) + "</span>"; });
    } else if (t.id === "tmDisconnect") {
      hw.disconnect().then(applyStatus, function (er) { $("tmSrc").innerHTML = '<span class="v-bad">' + errText(er) + "</span>"; });
    } else if (t.id === "tmRecStart") {
      hw.startRecording($("tmRecName").value).then(function () { refreshStatus(); }, function (er) { $("tmRecState").innerHTML = '<span class="v-bad">' + errText(er) + "</span>"; });
    } else if (t.id === "tmRecStop") {
      $("tmRecState").innerHTML = '<span class="dim">Validating and storing the recording…</span>';
      hw.stopRecording().then(function (r) {
        $("tmRecState").innerHTML = '<span class="v-ok">Stored as <b class="mono">' + esc(r.id) + "</b></span> · " + r.quality.n + " samples, " + fx(r.quality.duration_s, 2) + " s" + (r.synthetic ? " · " + synthChip() : "") + '<br><span class="small dim">' + esc(r.provenance && r.provenance.label || "") + "</span>";
        refreshRecs(); refreshStatus();
      }, function (er) { $("tmRecState").innerHTML = '<span class="v-bad">' + errText(er) + "</span>"; refreshStatus(); });
    } else if (t.id === "tmRecsRefresh") refreshRecs();
    else if (t.hasAttribute("data-replay")) {
      S.srcKind = "recording"; [].forEach.call(S.el.querySelectorAll('input[name="tmKind"]'), function (r) { r.checked = r.value === "recording"; }); renderFields();
      $("tmRec").value = t.getAttribute("data-replay");
      hw.connect({ source: "recording", recording_id: t.getAttribute("data-replay"), speed: 1 }).then(applyStatus, function (er) { $("tmSrc").innerHTML = '<span class="v-bad">' + errText(er) + "</span>"; });
    } else if (t.hasAttribute("data-cmp")) openCompare(t.getAttribute("data-cmp"));
    else if (t.id === "tmCmpGo") runCompare();
    else if (t.hasAttribute("data-ds")) makeDataset(t.getAttribute("data-ds"));
  }

  /* ---------------- status (source, provenance, recording) ---------------- */
  function refreshStatus() { var hw = S.hw; if (!hw || !hw.available().ok) return; hw.status().then(applyStatus, function (er) { $("tmSrc").innerHTML = '<span class="v-bad">Telemetry status not available: ' + errText(er) + "</span>"; }); }
  function applyStatus(st) {
    if (!st) return;
    // a status fetched outside the live stream (the 2-s refresh, connect, disconnect): an answer from a backend process this
    // page has left is ignored; a new stream is adopted by the live stream first (which resets the display)
    if (S.stream && S.stream.observe && st.stream_id && S.stream.observe(st.stream_id) === "stale") return;
    if (st.stream_id) S.streamId = st.stream_id;
    S.status = st;
    var p = st.provenance || {}, lab = S.hw.provenanceLabel(p);
    var sub = !p.source_kind ? (st.connected ? "Connected; waiting for the source to identify itself (hello)." : "Connect a source to see its telemetry.")
      : (p.synthetic ? "Simulated data from a " + (p.source_kind === "emulator" ? "software emulator" : "test source") + " (" + esc(p.device_id || "") + "). It is not a measurement and never validation evidence."
        : p.declared_physical ? "The source says it is a physical device (" + esc(p.device_id || "") + ", firmware " + esc(p.firmware || "?") + "). The software cannot verify that."
          : "");
    if (p.source_kind && !p.active) sub += " Session ended.";
    banner(lab, sub);
    var key = !p.source_kind ? "telemetry-none" : p.synthetic ? "telemetry-synthetic" : p.replay ? "telemetry-replay" : p.declared_physical ? "telemetry-declared" : "telemetry-none";
    var fields = { source: key, controller: "— (read-only telemetry)", experiment: p.device_id ? p.device_id + (p.replay ? " · replay" : "") + (p.active ? "" : " · ended") : "telemetry" };
    if (S.ctx.status && JSON.stringify(fields) !== S.lastFields) { S.lastFields = JSON.stringify(fields); S.ctx.status(fields); }
    var src = st.source, h = "";
    if (!src) h = '<span class="dim">No source.</span>';
    else {
      var ok = st.connected ? '<span class="v-ok">connected</span>' : src.state === "failed" ? '<span class="v-bad">failed</span>' : src.state === "waiting" ? '<span class="v-warn">not connected · retrying</span>' : src.state === "finished" ? '<span class="dim">replay finished</span>' : '<span class="dim">' + esc(src.state) + "</span>";
      h = "Source <span class=\"mono\">" + esc(src.kind + " " + (src.address || "")) + "</span>: " + ok + (src.last_error ? ' <span class="v-bad small">(' + esc(src.last_error) + ")</span>" : "");
      if (st.connected && st.stale) h += ' · <span class="v-warn"><b>STALE</b> — no frame for more than ' + fx(st.stale_after_s, 2) + " s</span>";
    }
    if (st.startup_error) h += '<br><span class="v-bad small">Start-up source failed: ' + esc(st.startup_error) + "</span>";
    $("tmSrc").innerHTML = h;
    var rec = st.recording;
    $("tmRecStart").disabled = !!rec || !st.hello; $("tmRecStop").disabled = !rec;
    if (rec) $("tmRecState").innerHTML = '<span class="v-warn">● Recording</span> “' + esc(rec.name) + "” · " + rec.frames + " frames";
    renderQuality();
    if (!S.latest && st.latest) onFrames([st.latest]);
  }
  function synthChip() { return '<span class="bdg mk-mock tm-synth" title="Synthetic telemetry: simulated, not measured"><i aria-hidden="true"></i>SYNTHETIC</span>'; }
  function banner(lab, sub) {
    var b = $("tmBanner"); if (!b) return;
    b.setAttribute("data-kind", lab.cls); $("tmBannerT").textContent = lab.text; $("tmBannerS").innerHTML = sub ? " " + sub : "";
    tagView();
  }
  /* the label on the 3-D view: the same provenance as the banner, on the picture itself */
  function tagView() {
    var tag = $("tmTag"); if (!tag) return;
    var lab = S.hw.provenanceLabel(S.status && S.status.provenance);
    tag.innerHTML = S.latest ? '<span class="vtag' + (lab.cls === "synthetic" ? " tm-vs" : "") + '">' + esc(lab.cls === "synthetic" ? "SYNTHETIC telemetry · not the cube" : lab.cls === "declared" ? "Telemetry · declared physical source (not verified)" : "Telemetry") + "</span>" : "";
  }

  /* ---------------- live frames ---------------- */
  function startStream() {
    if (S.stream || !S.hw) return;
    S.stream = S.hw.live(function (ev) {
      if (ev.type === "frames") { S.dropped = ev.dropped || S.dropped; onFrames(ev.frames); }
      else if (ev.type === "stream") resetForStream(ev);
      else if (ev.type === "status") applyStatus(ev.status);
      else if (ev.type === "transport") { S.transport = ev; renderQuality(); }
      else if (ev.type === "gap") { S.missed += ev.missed; renderQuality(); }
    }, { stream: S.streamId, after: S.latest && S.streamId ? S.latest.n : 0 });   // shown again: continue the stream on display, or learn that it changed
  }
  function stopStream() { if (S.stream) { S.stream.close(); S.stream = null; } }
  /* the backend's stream changed (the backend process was restarted): the frame on display, its session, the wheel
     angles and this page's counters belong to the old stream. Drop them; the next frames of the new stream are drawn
     as they arrive, and the next status (the live stream fetches it at once) replaces the source description. */
  function resetForStream(ev) {
    S.streamChanges++;
    S.streamId = ev.stream || null;
    S.streamNote = ev.reason || "The backend's telemetry stream changed.";
    S.latest = null; S.lastT = null; S.ang = [0, 0, 0]; S.dropped = 0; S.missed = 0; S.sceneMode = null; S.status = null;
    if (S.viewer) S.viewer.frameInfo = null;
    banner({ cls: "none", text: "Telemetry backend restarted" }, "Waiting for the new backend process to describe its source.");
    renderRead(null); renderQuality();
  }
  function onFrames(frames) {
    var f = frames[frames.length - 1];
    frames.forEach(function (fr) {                     // wheel angles for drawing only (integrated from the reported speeds)
      if (S.lastT != null && fr.t > S.lastT && fr.wheel_rpm && fr.session === (S.latest && S.latest.session)) { var dt = Math.min(0.2, fr.t - S.lastT); for (var j = 0; j < 3; j++) S.ang[j] += fr.wheel_rpm[j] * Math.PI / 30 * dt; }
      S.lastT = fr.t; S.latest = fr;
    });
    S.latest = f;
    if (!S.raf) S.raf = requestAnimationFrame(draw);
  }
  function modeOf() { var h = S.status && (S.status.hello || null), p = S.latest && S.latest.mode; return p || (h && h.mode) || "corner"; }
  function ensureViewer() {
    if (S.viewer || typeof AerisViewer === "undefined") return;
    S.viewer = new AerisViewer($("tmStage"), { preserve: true });
  }
  function sceneFor(mode) {
    var cfg = TWIN.defaultConfig(mode === "edge" ? "edge" : "corner"), mp = TWIN.massProps(cfg);
    return { mode: mode === "edge" ? "edge" : "corner", a: cfg.params.a, attachments: [], com_m: mp.rc, nominal_com_m: null, loads: [], failed: [false, false, false] };
  }
  function draw() {
    S.raf = 0;
    var f = S.latest; if (!f) return;
    var mode = modeOf();
    if (S.viewer) {
      if (S.sceneMode !== mode) { S.viewer.setScene(sceneFor(mode)); S.sceneMode = mode; }
      var R = f.q ? TWIN.Q3.rot(f.q) : TWIN.edgeR(f.theta || 0);
      S.viewer.setPose({ R: R, wheelAngles: S.ang.slice(), failed: [false, false, false], loads: [], torque_world: null, gravity_N: null, t: f.t, idx: f.n, runId: "telemetry" });
      S.viewer.frameInfo = { n: f.n, seq: f.seq, t: f.t };
    }
    var now = performance.now();
    if (now - S.lastRead > 100) { S.lastRead = now; renderRead(f); }
  }
  function tiltDeg(f) {
    if (typeof f.theta === "number") return f.theta / DEG;
    var R = TWIN.Q3.rot(f.q), z = R[2], m = TWIN.massProps(TWIN.defaultConfig("corner")).rc;
    // tilt of the body diagonal (pivot → nominal COM) from the vertical: the attitude error a balance controller sees at the nominal COM
    var c = TWIN.vec.mv(R, m), n = Math.hypot(c[0], c[1], c[2]);
    return Math.acos(Math.max(-1, Math.min(1, c[2] / n))) / DEG;
  }
  function renderRead(f) {
    var el = $("tmRead"); if (!el) return;
    var t = $("tmT");
    if (!f) { el.innerHTML = '<p class="ws-empty">No frames yet.</p>'; if (t) t.textContent = ""; return; }
    if (t) t.textContent = "t = " + fx(f.t, 3) + " s · seq " + f.seq;
    var v3 = function (v, k, d) { return v ? v.map(function (x) { return fx(x * k, d); }).join(" · ") : "—"; };
    el.innerHTML = [["Frame", "n " + f.n + " · seq " + f.seq + " · session " + f.session],
      ["Time t", fx(f.t, 3) + " s"],
      [typeof f.theta === "number" ? "Tilt θ" : "COM lean from vertical", fx(tiltDeg(f), 2) + " °"],
      ["Body rate ω", v3(f.w, 1 / DEG, 1) + " °/s"],
      ["Wheel speeds", v3(f.wheel_rpm, 1, 0) + " rpm"],
      ["Torque command", v3(f.torque_cmd, 1000, 2) + " mN·m"],
      ["Torque measured", v3(f.torque_meas, 1000, 2) + " mN·m"],
      ["Status", f.status || "—"]].map(function (r) { return "<dt>" + esc(r[0]) + '</dt><dd class="mono">' + esc(r[1]) + "</dd>"; }).join("");
    tagView();
  }
  function renderQuality() {
    var el = $("tmQuality"); if (!el) return;
    var st = S.status, c = st && st.counters;
    if (!c) { el.innerHTML = '<p class="ws-empty">' + (S.streamChanges && S.streamNote ? esc(S.streamNote) : "No stream yet.") + "</p>"; return; }
    var rej = st.rejected_by_reason || {}, rk = Object.keys(rej);
    var rows = [["Frames accepted", c.frames_accepted], ["Rate (source time)", st.rate_hz ? fx(st.rate_hz, 1) + " Hz" : "—"], ["Duplicates dropped", c.duplicates], ["Out of order (dropped)", c.out_of_order],
      ["Gaps · frames missing", c.gaps + " · " + c.dropped_by_source], ["Lines rejected", c.rejected + (rk.length ? " (" + rk.map(function (k) { return k + " " + rej[k]; }).join(", ") + ")" : "")],
      ["Connects · reconnects", c.connects + " · " + c.reconnects], ["Stale periods", c.stale_events],
      ["This page", (S.transport ? (S.transport.kind === "websocket" ? "WebSocket live" : S.transport.kind === "polling" ? "polling (" + (S.transport.reason || "") + ")" : S.transport.kind) : "—") + (S.dropped ? " · " + S.dropped + " frames dropped for this page (slow client)" : "") + (S.missed ? " · " + S.missed + " frames missed while polling" : "")],
      ["Backend stream", (st.stream_id || "— (backend without stream ids)") + (S.streamChanges ? " · the backend restarted " + S.streamChanges + "× while this page was open; the display was reset" : "")]];
    el.innerHTML = '<table class="tm-q"><tbody>' + rows.map(function (r) { return "<tr><th scope=\"row\">" + esc(r[0]) + '</th><td class="mono" data-q="' + esc(r[0]) + '">' + esc(String(r[1])) + "</td></tr>"; }).join("") + "</tbody></table>" +
      (st.last_errors && st.last_errors.length ? '<details class="tm-err"><summary>Last rejected lines</summary><ul>' + st.last_errors.map(function (e) { return "<li><b>" + esc(e.reason) + "</b> " + esc(e.detail || "") + "</li>"; }).join("") + "</ul></details>" : "");
  }

  /* ---------------- stored recordings, export, replay, comparison ---------------- */
  function refreshFiles() { S.hw.files().then(function (d) { S.files = d.files || []; if (S.srcKind === "file") renderFields(); }, function () { S.files = []; }); }
  function refreshRecs() {
    var hw = S.hw; if (!hw || !hw.available().ok) { renderRecs(); return; }
    hw.recordings().then(function (d) { S.recs = d.recordings || []; renderRecs(); if (S.srcKind === "recording") renderFields(); }, function (er) { $("tmRecs").innerHTML = '<p class="v-bad small">' + errText(er) + "</p>"; });
  }
  function renderRecs() {
    var el = $("tmRecs"); if (!el) return;
    if (!S.recs.length) { el.innerHTML = '<p class="ws-empty">No stored recordings.</p>'; return; }
    el.innerHTML = '<table class="tm-recs"><thead><tr><th>Recording</th><th>Origin</th><th>Samples</th><th></th></tr></thead><tbody>' + S.recs.map(function (r) {
      return '<tr data-rec="' + esc(r.id) + '"><td><b class="mono">' + esc(r.id) + '</b><br><span class="small dim">' + esc(r.name || "") + " · " + esc((r.created || "").replace("T", " ").slice(0, 19)) + "</span></td>" +
        "<td>" + (r.synthetic ? synthChip() + ' <span class="small dim">' + esc(r.source_kind || "") + "</span>" : '<span class="small">' + esc(originText(r)) + "</span>") + "</td>" +
        '<td class="mono">' + (r.samples != null ? r.samples : "—") + "</td>" +
        '<td class="tm-acts"><button type="button" class="act tm-mini" data-replay="' + esc(r.id) + '">Replay</button>' +
        '<a class="act tm-mini" href="' + esc(S.hw.exportUrl(r.id, "json")) + '" download>JSON</a><a class="act tm-mini" href="' + esc(S.hw.exportUrl(r.id, "ndjson")) + '" download>NDJSON</a>' +
        '<button type="button" class="act tm-mini" data-cmp="' + esc(r.id) + '">Compare</button><button type="button" class="act tm-mini" data-ds="' + esc(r.id) + '">Dataset</button></td></tr>';
    }).join("") + "</tbody></table>";
  }
  /* the origin of a stored recording that is not synthetic: declared (never verified), a copy, or not declared at all */
  function originText(r) {
    if (r.trust === "unknown") return "origin not declared (unknown: never evidence)";
    if (r.trust === "declared-physical" || r.source_kind === "physical") return "declared physical (not verified)" + (r.derived ? " · copy captured from a replay" : "");
    return r.source_kind || "uploaded";
  }
  function openCompare(recId) {
    var el = $("tmCmp"); S.cmp = { rec: recId };
    el.innerHTML = '<div class="tm-cmp"><p class="sub-h">Compare ' + esc(recId) + ' with a simulated run</p><p class="small dim">Loading research-backend runs…</p></div>';
    S.hw.runs().then(function (d) {
      var runs = (d.runs || []);
      el.innerHTML = '<div class="tm-cmp"><p class="sub-h">Compare ' + esc(recId) + " with a simulated run</p>" +
        (runs.length ? '<div class="fld"><label for="tmCmpRun">Research-backend run (same mode as the recording)</label><select id="tmCmpRun">' + runs.map(function (r) { return '<option value="' + esc(r.id) + '">' + esc((r.experiment_id || r.id) + " · " + (r.name || "") + " · " + (r.mode || "")) + "</option>"; }).join("") + '</select></div><div class="btnrow"><button type="button" class="act" id="tmCmpGo">Compare</button></div>' : '<p class="small v-warn">No research-backend runs yet: run an experiment in SIMULATION mode first.</p>') +
        '<div id="tmCmpOut"></div></div>';
    }, function (er) { el.innerHTML = '<p class="v-bad small">' + errText(er) + "</p>"; });
  }
  function runCompare() {
    var out = $("tmCmpOut"), run = $("tmCmpRun").value; out.innerHTML = '<p class="small dim">Comparing on the backend…</p>';
    S.hw.compare(run, S.cmp.rec).then(function (c) {
      var ev = c.evidence || {}, res = c.result || {}, sig = res.signals || {};
      out.innerHTML = '<p class="' + (ev.admissible_as_validation_evidence ? "v-ok" : "v-warn") + '"><b>' + (ev.admissible_as_validation_evidence ? "Admissible as evidence for review" : "Not validation evidence") + "</b> · comparison " + esc(c.id) + "</p>" +
        (ev.reasons && ev.reasons.length ? '<ul class="small tm-why">' + ev.reasons.map(function (r) { return "<li>" + esc(r) + "</li>"; }).join("") + "</ul>" : "") +
        '<p class="small dim">' + esc(ev.model_status_change || "") + "</p>" +
        (res.errors && res.errors.length ? '<p class="v-bad small">' + res.errors.map(esc).join(" ") + "</p>" : "") +
        (Object.keys(sig).length ? '<table class="tm-q"><thead><tr><th>Signal</th><th>RMSE</th><th>MAE</th><th>Peak</th><th>n</th></tr></thead><tbody>' + Object.keys(sig).map(function (k) { var s = sig[k]; return "<tr><th scope=\"row\">" + esc(k) + ' <span class="u">[' + esc(s.unit || "") + ']</span></th><td class="mono">' + fx(s.rmse, 3) + '</td><td class="mono">' + fx(s.mae, 3) + '</td><td class="mono">' + fx(s.peak, 3) + '</td><td class="mono">' + s.n + "</td></tr>"; }).join("") + "</tbody></table>" : "") +
        (res.alignment ? '<p class="small dim">Overlap ' + fx(res.alignment.overlap_s[0], 2) + "–" + fx(res.alignment.overlap_s[1], 2) + " s, lag " + fx(res.alignment.lag_s * 1000, 1) + " ms (" + esc(res.alignment.primary) + ").</p>" : "");
    }, function (er) { out.innerHTML = '<p class="v-bad small">' + errText(er) + "</p>"; });
  }
  function makeDataset(recId) {
    var out = $("tmCmp"), api = S.hw.bound();
    out.innerHTML = '<p class="small dim">Creating a dataset with ' + esc(recId) + "…</p>";
    api.createDataset({ title: "Telemetry " + recId, recording_ids: [recId] }).then(function (d) {
      var p = d.provenance || {};
      out.innerHTML = '<div class="tm-cmp"><p class="sub-h">Dataset ' + esc(d.id) + '</p><p class="small">Source: <b>' + esc(p.source) + "</b>" + (p.contains_synthetic ? " · " + synthChip() : "") + '</p><p class="small dim">' + esc(p.note || "") + "</p></div>";
    }, function (er) { out.innerHTML = '<p class="v-bad small">' + errText(er) + "</p>"; });
  }

  /* test and debugging hook: what the panel shows now */
  function snapshot() {
    return { banner: $("tmBannerT") ? $("tmBannerT").textContent : null, kind: $("tmBanner") ? $("tmBanner").getAttribute("data-kind") : null, latest: S.latest ? { n: S.latest.n, seq: S.latest.seq, t: S.latest.t, session: S.latest.session } : null,
      viewer: S.viewer && S.viewer.frameInfo ? S.viewer.frameInfo : null, transport: S.transport ? S.transport.kind : null, connected: !!(S.status && S.status.connected), recording: !!(S.status && S.status.recording),
      stream: S.streamId, streamChanges: S.streamChanges, adapterStream: S.stream && S.stream.streamId ? S.stream.streamId() : null, cursor: S.stream && S.stream.lastN ? S.stream.lastN() : null,
      readout: $("tmT") ? $("tmT").textContent : null };
  }
  return { mount: mount, show: show, hide: hide, snapshot: snapshot };
})();

/* =====================================================================
   AERIS · RUN PLOTS — what the Lab plots for one run, as data (no DOM).

   Colour follows meaning (js/platform/tokens.js):
   - measured/simulated quantities of the run: neutral inks, told apart by
     line style and a legend (wheels X/Y/Z: solid / dashed / dotted)
   - external load torque τF: load magenta; gravity torque τg: slate
   - limits and saturation: amber (warning); settling band: green (stable);
     fall and wheel failure: red (failure)
   Events come from the run's timeline (AERIS_EVENTS), so the plots, the
   timeline strip and the 3-D view mark the same instants.
   ===================================================================== */
var AERIS_RUNPLOTS = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var T = typeof AERIS_TOKENS !== "undefined" ? AERIS_TOKENS : require("../platform/tokens.js");
  var EV = typeof AERIS_EVENTS !== "undefined" ? AERIS_EVENTS : require("../platform/events.js");
  var DEG = TWIN.DEG, RPM = TWIN.RPM, C = T.color, a = T.alpha;
  var INK = C.ink, ST = C.status;
  function fx(x, d) { return isFinite(x) ? (+x).toFixed(d).replace("-", "−") : "—"; }
  function mapCol(S, k, f) { var src = S[k], out = new Array(src.length); for (var i = 0; i < src.length; i++) out[i] = f(src[i]); return out; }
  /* event overlays shared by every plot of the run */
  function overlays(r) {
    var tl = EV.timelineOf(r), marks = [], bands = [], strips = [], c = r.config;
    tl.events.forEach(function (e) {
      if (e.type === "fall") marks.push({ x: e.t, color: a(ST.failure, 0.9), label: "fall", kind: e.type });
      else if (e.type === "wheel_failure" && e.severity === "failure") marks.push({ x: e.t, color: a(ST.failure, 0.75), label: String(e.wheel).toUpperCase() + " fails", dash: [3, 3], kind: e.type });
      else if (e.type === "recovered" && e.t > 0) marks.push({ x: e.t, color: a(ST.stable, 0.75), label: "t_s", dash: [2, 3], kind: e.type });
      else if (e.type === "estimator_warning") marks.push({ x: e.t, color: a(ST.warning, 0.8), label: "est.", dash: [2, 2], kind: e.type });
      else if (e.type === "yaw_command") marks.push({ x: e.t, color: a(INK.secondary, 0.7), label: "ψ cmd", dash: [4, 3], kind: e.type });
      else if (e.type === "disturbance") bands.push({ x0: e.t, x1: e.t_end, color: a(C.physics.load, 0.09), label: e.ref || "load", kind: e.type });
      else if (e.type === "saturation") strips.push({ x0: e.t, x1: e.t_end, row: 0, color: a(ST.warning, 0.95), kind: e.type });
      else if (e.type === "speed_limit") strips.push({ x0: e.t, x1: e.t_end, row: 1, color: a(ST.warning, 0.95), kind: e.type });
      else if (e.type === "speed_risk") strips.push({ x0: e.t, x1: e.t_end, row: 1, color: a(ST.warning, 0.45), kind: e.type });
    });
    marks.sort(function (p, q) { return p.x - q.x; });
    marks.forEach(function (mk, k) { mk.dy = 10 + (k % 3) * 14; });
    return { vlines: marks, xbands: bands, xstrips: strips, timeline: tl, windowEnd: c.duration_s };
  }
  function defs(r) {
    var S = r.samples.cols, c = r.config, d = r.derived, A = r.definitions.assessment, edge = c.mode === "edge";
    var wl = d.motor.wmax / RPM, tl = d.motor.taumaxRun, out = [];
    var deg = function (k) { return mapCol(S, k, function (v) { return v / DEG; }); }, rpm = function (k) { return mapCol(S, k, function (v) { return v / RPM; }); };
    var band = A.settleTolDeg, fall = edge ? A.fallEdgeDeg : A.fallCornerDeg;
    // 1 · lean
    out.push({ id: "lean", title: edge ? "COM lean e and body tilt θ" : "COM lean e and tilt from the diagonal", unit: "°", ylabel: "angle [°]",
      series: [{ name: "e", key: "e", y: deg("e"), color: INK.primary, width: 2 }, { name: edge ? "θ" : "tilt", key: edge ? "theta" : "geo", y: deg(edge ? "theta" : "geo"), color: INK.secondary, width: 1.4, dash: [6, 4] }],
      ybands: [{ y0: -band, y1: band, color: a(ST.stable, 0.08) }],
      hlines: [{ y: fall, color: a(ST.failure, 0.6), label: "fall " + fall + "°", fit: false }].concat(edge ? [{ y: -fall, color: a(ST.failure, 0.6), fit: false }] : []),
      yzero: true, note: "Green band: ±" + band + "° settling tolerance. Red line: fall threshold." });
    // 2 · true vs estimated tilt (edge, non-ideal sensing only; corner mode uses ideal state feedback)
    if (edge && c.estimator && c.estimator.type !== "ideal" && S.thetahat) {
      out.push({ id: "est", title: "True vs estimated tilt θ, θ̂", unit: "°", ylabel: "angle [°]",
        series: [{ name: "θ true", key: "theta", y: deg("theta"), color: INK.primary, width: 2 }, { name: "θ̂ estimate", key: "thetahat", y: deg("thetahat"), color: INK.secondary, width: 1.5, dash: [5, 3] }],
        yzero: true, note: "θ is the simulated true tilt; θ̂ is what the " + c.estimator.type + " estimator reports to the controller. An estimator warning is raised when they differ by more than " + TWIN.EVENT_RULES.estErrDeg + "° for " + TWIN.EVENT_RULES.estErrHoldS + " s." });
    }
    // 3 · adapted balance offset (COM-adaptive LQR, edge)
    if (edge && c.controller.type === "adp" && S.betahat && r.design && r.design.betaRef != null) {
      var target = (d.edge.beta - r.design.betaRef) / DEG, clamp = 6;
      out.push({ id: "adapt", title: "Adapted balance offset β̂", unit: "°", ylabel: "angle [°]",
        series: [{ name: "β̂", key: "betahat", y: deg("betahat"), color: INK.primary, width: 2 }],
        hlines: [{ y: target, color: a(INK.secondary, 0.9), label: "true unmodelled offset " + fx(target, 3) + "° (known in simulation)", fit: true, left: true }, { y: clamp, color: a(ST.warning, 0.55), label: "clamp ±6°", fit: Math.abs(target) > 4 }, { y: -clamp, color: a(ST.warning, 0.55), fit: Math.abs(target) > 4 }],
        yzero: true, note: "β̂ converges to the offset between the true balance attitude and the one the controller was designed for. It is frozen while the torque is saturated." });
    }
    // 4 · wheel speed (neutral inks + dash per wheel), amber limits
    var custom = Array.isArray(c.wheels) && c.wheels.length > 0, wids = custom ? c.wheels.map(function (w, i) { return String(w && w.id != null ? w.id : "w" + (i + 1)); }) : null;
    var NEU = [{ color: INK.primary, dash: [] }, { color: INK.secondary, dash: [7, 4] }, { color: INK.tertiary, dash: [2, 3] }, { color: INK.secondary, dash: [9, 3, 2, 3] }, { color: INK.tertiary, dash: [12, 4] }, { color: INK.primary, dash: [1, 3] }];
    function wstyle(w, j) { return custom ? { label: "Ω" + w, color: NEU[j % NEU.length].color, dash: NEU[j % NEU.length].dash } : T.WHEEL_STYLE[w]; }   // custom wheel sets: neutral inks, dash per wheel
    var ws = custom ? wids.map(function (w, j) { var st = wstyle(w, j); return { name: st.label, key: "omega_" + w, y: rpm("omega_" + w), color: st.color, width: 1.7, dash: st.dash }; })
      : edge ? [{ name: "Ωx", key: "omega_x", y: rpm("omega_x"), color: INK.primary, width: 2 }]
      : ["x", "y", "z"].map(function (w) { var st = T.WHEEL_STYLE[w]; return { name: st.label, key: "omega_" + w, y: rpm("omega_" + w), color: st.color, width: 1.7, dash: st.dash }; });
    var pk = r.metrics.peakOmega_rpm, fitLim = pk > 0.4 * wl, risk = TWIN.EVENT_RULES.speedRiskFrac;
    out.push({ id: "wheel", title: "Wheel speed", unit: "rpm", ylabel: "speed [rpm]", series: ws,
      hlines: [{ y: wl, color: a(ST.warning, 0.75), label: "limit " + fx(wl, 0), fit: fitLim }, { y: -wl, color: a(ST.warning, 0.75), fit: fitLim }, { y: risk * wl, color: a(ST.warning, 0.35), dash: [2, 4], label: Math.round(risk * 100) + " %", fit: false, left: true }, { y: -risk * wl, color: a(ST.warning, 0.35), dash: [2, 4], fit: false }],
      yzero: true, note: fitLim ? "Amber lines: speed limit and the " + Math.round(risk * 100) + " % saturation-risk level." : "Speed limit ±" + fx(wl, 0) + " rpm is off scale." });
    // 5 · torques
    var ts = edge && !custom ? [{ name: "T", key: "T_x", y: S.T_x, color: INK.primary, width: 2 }, { name: "T cmd", key: "Tc_x", y: S.Tc_x, color: INK.tertiary, width: 1.2, dash: [4, 3] }, { name: "τg", key: "tauG", y: S.tauG, color: C.physics.gravity, width: 1.4, dash: [8, 3] }, { name: "τF", key: "tauF", y: S.tauF, color: C.physics.load, width: 1.5 }]
      : (custom ? wids : ["x", "y", "z"]).map(function (w, j) { var st = wstyle(w, j); return { name: "T" + w, key: "T_" + w, y: S["T_" + w], color: st.color, width: 1.6, dash: st.dash }; })
        .concat([{ name: "|τF|", key: null, y: S.t.map(function (_, i) { return edge ? Math.abs(S.tauF[i]) : Math.hypot(S.tauF_x[i], S.tauF_y[i], S.tauF_z[i]); }), color: C.physics.load, width: 1.4 }]);
    out.push({ id: "torque", title: edge && !custom ? "Torques about the edge" : "Motor torques", unit: "N·m", ylabel: "torque [N·m]", series: ts,
      hlines: [{ y: tl, color: a(ST.warning, 0.6), label: "τmax " + fx(tl, 3), fit: true }, { y: -tl, color: a(ST.warning, 0.6), fit: true }], yzero: true,
      note: edge && !custom ? "T: delivered motor torque; T cmd: commanded; τg: gravity; τF: external load (magenta)." : "Motor torque per wheel; |τF|: external load torque magnitude (magenta)." });
    // 6 · yaw (corner)
    if (!edge) out.push({ id: "yaw", title: "Yaw about the balance axis", unit: "°", ylabel: "angle [°]", series: [{ name: "ψ", key: "psi", y: deg("psi"), color: INK.primary, width: 2 }, { name: "ψ ref", key: "psiRef", y: deg("psiRef"), color: INK.secondary, width: 1.3, dash: [5, 4] }], yzero: true });
    var ov = overlays(r);
    out.forEach(function (df) { df.vlines = ov.vlines; df.xbands = ov.xbands; df.xstrips = ov.xstrips; });
    return out;
  }
  /* one plot as CSV (time plus its series, SI units as displayed) */
  function toCSV(r, df) {
    var S = r.samples.cols, cols = ["t [s]"].concat(df.series.map(function (s) { return s.name + " [" + df.unit + "]"; })), lines = ["# AERIS " + (r.experiment_id || r.id) + " · " + df.title, cols.join(",")];
    for (var i = 0; i < S.t.length; i++) lines.push([S.t[i]].concat(df.series.map(function (s) { var v = s.y[i]; return isFinite(v) ? +(+v).toPrecision(7) : ""; })).join(","));
    return lines.join("\n") + "\n";
  }
  return { defs: defs, overlays: overlays, toCSV: toCSV };
})();
if (typeof module !== "undefined") module.exports = AERIS_RUNPLOTS;

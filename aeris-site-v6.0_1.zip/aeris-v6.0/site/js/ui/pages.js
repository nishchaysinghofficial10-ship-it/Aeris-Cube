/* =====================================================================
   AERIS · PAGES — the content pages built from js/site-content.js and the
   platform modules: the home story and evolution timeline, AERIS Cube
   (subsystems, parameter status), Research (question, hypotheses,
   variables, controllers, method, metrics), Results (findings — none
   until the final dataset exists) and Validation (sim ↔ hardware).

   Nothing here produces data. Pages show what the content file and the
   modules state, and say "pending" where evidence does not exist yet.
   ===================================================================== */
var Pages = (function () {
  "use strict";
  var $ = U.$, esc = U.esc, fx = U.fx, sig = U.sig, B = AERIS_BADGES, TK = AERIS_TOKENS;
  function C() { return window.AERIS_CONTENT || {}; }
  var SYS = { hardware: "Physical system", twin: "Digital model", research: "Research environment" };
  var STATUS = { done: { t: "DONE", cls: "st-done" }, "in-progress": { t: "IN PROGRESS", cls: "st-prog" }, next: { t: "NEXT", cls: "st-next" }, planned: { t: "PLANNED", cls: "st-plan" }, failed: { t: "FAILED", cls: "st-fail" }, undocumented: { t: "NOT YET DOCUMENTED", cls: "st-undoc" } };
  function statusChip(s) { var d = STATUS[s] || { t: String(s).toUpperCase(), cls: "st-plan" }; return '<span class="evo-st ' + d.cls + '">' + d.t + "</span>"; }
  function sysDot(s) { return '<i class="sys-dot sys-' + esc(s) + '" aria-hidden="true"></i>'; }

  /* ---------------- home: story 01–04 ---------------- */
  function story() {
    var el = $("storyList"), S = C().story || []; if (!el) return;
    el.innerHTML = S.map(function (x) {
      return '<li class="story-i sys-' + esc(x.system) + '"><div class="story-top"><span class="story-n">' + esc(x.n) + '</span><span class="story-sys">' + sysDot(x.system) + esc(SYS[x.system] || "") + "</span></div>" +
        "<h3>" + esc(x.title) + '</h3><p class="story-sub">' + esc(x.subtitle) + "</p>" +
        '<blockquote class="story-q"><p>“' + esc(x.quote) + '”</p></blockquote><p class="story-t">' + esc(x.text) + '</p><p class="story-st">' + esc(x.status) + '</p><a class="more" href="' + esc(x.href) + '">' + (x.key === "rwip" ? "In the project timeline" : "Open " + esc(x.title)) + " →</a></li>";
    }).join("");
  }
  /* ---------------- evolution timeline (compact on home, full on Research) ---------------- */
  function evolution(el, compact) {
    var E = C().evolution || []; if (!el) return;
    el.innerHTML = E.map(function (x) {
      return '<li class="evo-i ' + (STATUS[x.status] ? STATUS[x.status].cls : "") + '"><span class="evo-m" aria-hidden="true">' + sysDot(x.system) + "</span><div class=\"evo-b\"><div class=\"evo-h\"><span class=\"evo-stage\">" + esc(x.stage) + "</span>" + statusChip(x.status) + "</div><p class=\"evo-t\">" + esc(x.title) + "</p>" + (compact ? "" : '<p class="evo-x">' + esc(x.text) + "</p>") + "</div></li>";
    }).join("");
  }

  /* ---------------- AERIS Cube ---------------- */
  var AXK = { wx: "x", wy: "y", wz: "z" };
  function cube() {
    var H = C().hardware || {}, meas = H.measured || {}, nM = Object.keys(meas).filter(function (k) { return meas[k]; }).length, nAll = Object.keys(meas).length;
    var b = $("cubeBadges"); if (b) b.innerHTML = B.source("hardware") + (nM ? B.claim("measuredParams") : B.claim("hwPending")) + B.claim("valPending");
    var f = $("cubeFacts"); if (f) f.innerHTML = fact("Balances on an edge", "Yes (author's statement)", "ok") + fact("Balances on a corner", "Yes (author's statement)", "ok") + fact("Parameters measured", nM + " of " + nAll, nM ? "ok" : "pend") + fact("Footage uploaded", String((H.footage || []).length), (H.footage || []).length ? "ok" : "pend") + fact("Hardware runs recorded", String((H.comparisons || []).length), (H.comparisons || []).length ? "ok" : "pend") + fact("Model validated", "No (pending)", "pend");
    var g = $("cubeSubsystems"), S = C().subsystems || [];
    if (g) g.innerHTML = S.map(function (s) {
      var ax = AXK[s.key], col = ax ? TK.color.axis[ax] : null;
      return '<article class="sub-c"><div class="sub-h"><span class="sub-k"' + (col ? ' style="color:' + col + ";border-color:" + TK.alpha(col, 0.5) + '"' : "") + ">" + esc(ax ? ax.toUpperCase() : s.key.toUpperCase()) + "</span><h3>" + esc(s.label) + '</h3></div><p class="sub-p">' + esc(s.part) + '</p><p class="sub-r">' + esc(s.role) + "</p></article>";
    }).join("");
  }
  function fact(k, v, tone) { return '<div class="fact ' + tone + '"><span class="fact-k">' + esc(k) + '</span><span class="fact-v">' + esc(v) + "</span></div>"; }

  /* ---------------- Research ---------------- */
  function research() {
    var R = C().research; if (!R || !$("rqText")) return;
    $("rqText").innerHTML = "<p>" + esc(R.question) + "</p>";
    $("rhList").innerHTML = R.hypotheses.map(function (h) { return '<article class="hyp"><div class="hyp-h"><span class="hyp-id">' + esc(h.id) + '</span><span class="bdg cl-pending"><i aria-hidden="true"></i>PREDICTION · NOT YET TESTED</span></div><p>' + esc(h.text) + '</p><p class="hyp-test"><b>Test:</b> ' + esc(h.test) + "</p></article>"; }).join("");
    var V = R.variables;
    $("rvList").innerHTML = [["independent", V.independent, "Varied on purpose, one or two at a time."], ["controlled", V.controlled, "Held fixed and recorded with every run."], ["dependent", V.dependent, "Measured for every run."]].map(function (c) {
      return '<div class="var-col"><div class="var-h">' + B.role(c[0]) + '</div><p class="small dim">' + esc(c[2]) + "</p><ul>" + c[1].map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul></div>";
    }).join("");
    var CT = AERIS_CONTROLLERS;
    $("rcTable").innerHTML = '<thead><tr><th scope="col">Controller</th><th scope="col">Family</th><th scope="col">Measures</th><th scope="col">Assumes</th><th scope="col">Adapts</th><th scope="col">Limits</th></tr></thead><tbody>' +
      CT.ORDER.map(function (k) { var c = CT.get(k); return '<tr><th scope="row">' + B.controller(k, { long: true }) + "</th><td>" + esc(c.family) + "</td><td>" + esc(c.measures.join("; ")) + "</td><td>" + esc(c.assumes.join("; ")) + "</td><td>" + esc(c.adapts) + "</td><td>" + esc(c.limits) + "</td></tr>"; }).join("") + "</tbody>";
    $("rcPlanned").textContent = "Not in the browser engine: " + CT.PLANNED.map(function (p) { return p.name + " (" + p.where + ")"; }).join("; ") + ". The research question names adaptive/nonlinear controllers; the nonlinear part is future work.";
    $("rmList").innerHTML = R.methodology.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("");
    var MD = AERIS_TWIN.METRIC_DEFS;
    $("rmeList").innerHTML = R.metrics.filter(function (k) { return MD[k]; }).map(function (k) { var d = MD[k], i = d.indexOf(":"); return "<dt>" + esc(i > 0 ? d.slice(0, i) : k) + "</dt><dd>" + esc(i > 0 ? d.slice(i + 1).trim() : d) + "</dd>"; }).join("");
    $("rlList").innerHTML = R.limitations.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("");
    $("rfList").innerHTML = R.future.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("");
    evolution($("evoFull"), false);
  }

  /* ---------------- Results ---------------- */
  function results() {
    var R = C().results || { findings: [] }, el = $("resFindings"); if (!el) return;
    var b = $("resBadges"); if (b) b.innerHTML = B.claim("hwPending") + B.claim("valPending");
    if (!R.findings.length) {
      el.innerHTML = '<div class="pending-box big"><b>Final dataset not yet generated.</b><p>No findings are claimed yet. A finding needs the full study (research backend), its dataset and, for claims about the physical cube, hardware runs compared on the Validation page.</p></div>' +
        '<p class="pg-p">Each finding will be listed in this form:</p><div class="finding tpl" aria-label="Finding template, empty"><div class="f-row"><span class="f-k">Finding</span><span class="f-v">One sentence, stated for the tested range only</span></div><div class="f-row"><span class="f-k">Graph</span><span class="f-v">The figure it rests on, with units, legend and data export</span></div><div class="f-row"><span class="f-k">Runs</span><span class="f-v">How many simulations or hardware runs, how many invalid</span></div><div class="f-row"><span class="f-k">Range</span><span class="f-v">The parameter ranges covered; nothing is claimed outside them</span></div><div class="f-row"><span class="f-k">Dataset</span><span class="f-v">aeris-dataset/1 identifier, engine version and parameter set</span></div><div class="f-row"><span class="f-k">Methodology</span><span class="f-v">Sampling design, seeds, outcome rules and statistics used</span></div><span class="tpl-tag">TEMPLATE · NO DATA</span></div>';
    } else {
      el.innerHTML = R.findings.map(function (f) { return '<article class="finding"><h3>' + esc(f.id) + " · " + esc(f.title) + '</h3><p>' + esc(f.statement) + '</p><div class="f-row"><span class="f-k">Runs</span><span class="f-v">' + esc(f.runs) + '</span></div><div class="f-row"><span class="f-k">Range</span><span class="f-v">' + esc(f.range) + '</span></div><div class="f-row"><span class="f-k">Dataset</span><span class="f-v">' + esc(f.dataset) + '</span></div><div class="f-row"><span class="f-k">Methodology</span><span class="f-v">' + esc(f.method) + "</span></div></article>"; }).join("");
    }
    sweeps();
  }
  function sweeps() {
    var el = $("resSweeps"); if (!el) return;
    var list = []; try { list = JSON.parse(window.localStorage.getItem("aeris.v3.sweeps") || "[]"); } catch (e) { list = []; }
    el.innerHTML = list.length ? '<ul class="res-sw">' + list.map(function (sw) {
      var an = sw.analysis || {}, ctl = Object.keys(an.controllers || {});
      return '<li><div class="res-sw-h"><span class="mono xid">' + esc(sw.id) + "</span>" + B.forSweep(sw) + '</div><p class="small">' + esc(sw.name || "") + ' · <span class="dim">' + esc(new Date(sw.created).toLocaleString()) + " · " + (sw.rows || []).length + " runs</span></p>" +
        (ctl.length ? '<p class="small">' + ctl.map(function (c) { var s = an.controllers[c]; return B.controller(c) + " " + s.recovered + "/" + s.valid + " recovered"; }).join(" · ") + "</p>" : "") + "</li>";
    }).join("") + '</ul><p class="small dim">Open them in <a href="#lab/sweep">AERIS Lab → Research sweep</a> (recent sweeps list).</p>' : '<p class="ws-empty">No sweeps in this browser yet. Run one in <a href="#lab/sweep">AERIS Lab → Research sweep</a>.</p>';
  }

  /* ---------------- Validation ---------------- */
  var V = { hw: null, runs: [], out: null };
  function validation() {
    var b = $("valBadges"); if (b) b.innerHTML = B.claim("valPending") + B.claim("hwPending") + B.claim("nominal");
    var H = C().hardware || {}, meas = H.measured || {}, nM = Object.keys(meas).filter(function (k) { return meas[k]; }).length;
    var f = $("valFacts"); if (f) f.innerHTML = fact("Model state", ((AERIS_SCHEMA.VALIDATION[(C().twin || {}).validation || "nominal"] || {}).label || "Nominal model"), "pend") + fact("Parameters measured", nM + " of " + Object.keys(meas).length, nM ? "ok" : "pend") + fact("Hardware recordings published", String((H.comparisons || []).length), "pend") + fact("Acceptance thresholds", "Not defined yet", "pend");
    var fm = $("valFormat");
    if (fm) fm.textContent = JSON.stringify({ schema: "aeris-hardware-run/1", device: { id: "aeris-cube-1", firmware: "<version>", imu: "<part>", wheels: "<part>" }, recording: { started: "<ISO 8601 time>", operator: "<name>", notes: "<conditions>" }, mode: "edge | corner | free", experiment_id: "<AERIS-EXP-###### of the matching simulation, if any>", parameters: { parameter_set: "<name of the measured set>" }, samples: { rate_hz: "<number>", cols: { t: ["<s>", "…"], theta: ["<rad or deg>", "…"], wheel_rpm_x: ["<rpm>", "…"] }, units: { t: "s", theta: "deg", wheel_rpm_x: "rpm" } } }, null, 2);
    tool();
  }
  function tool() {
    var el = $("valTool"); if (!el) return;
    V.runs = AERIS_RUNS.list();
    el.innerHTML = '<div class="val-grid"><div><label class="small" for="valHw">1 · Hardware recording (aeris-hardware-run/1)</label><input type="file" id="valFile" accept=".json,application/json" aria-label="Choose a hardware recording file"><textarea id="valHw" class="val-ta" rows="6" placeholder="…or paste the JSON here"></textarea></div>' +
      '<div><label class="small" for="valSim">2 · Simulation run from this browser</label><select id="valSim">' + (V.runs.length ? V.runs.map(function (e) { return '<option value="' + esc(e.id) + '">' + esc((e.experiment_id || e.id) + " · " + e.name) + "</option>"; }).join("") : '<option value="">No saved runs: create one in AERIS Lab first</option>') + '</select><p class="small dim">Use a run with the same setup, controller and parameter set as the hardware recording.</p><button type="button" class="btn btn-solid btn-sm" id="valGo">Compare</button></div></div><div id="valOut" aria-live="polite"></div>';
    $("valFile").addEventListener("change", function () { var fl = this.files && this.files[0]; if (!fl) return; var rd = new FileReader(); rd.onload = function () { $("valHw").value = String(rd.result); }; rd.readAsText(fl); });
    $("valGo").addEventListener("click", compare);
  }
  function compare() {
    var out = $("valOut"), txt = $("valHw").value.trim(), id = $("valSim").value;
    if (!txt) { out.innerHTML = '<p class="v-warn">Supply a hardware recording first. Nothing is compared without one.</p>'; return; }
    var hw; try { hw = JSON.parse(txt); } catch (e) { out.innerHTML = '<p class="v-bad">The recording is not valid JSON: ' + esc(e.message) + "</p>"; return; }
    var l = id ? AERIS_RUNS.load(id) : { ok: false, error: "No simulation run selected." };
    if (!l.ok) { out.innerHTML = '<p class="v-bad">' + esc(l.error) + "</p>"; return; }
    var r = AERIS_VALIDATION.compare(l.record, hw);
    V.out = { r: r, sim: l.record, hw: hw };
    if (!r.ok) { out.innerHTML = '<div class="vb err"><b>Not compared:</b><ul>' + r.errors.map(function (e) { return "<li>" + esc(e) + "</li>"; }).join("") + "</ul></div>" + (r.warnings.length ? '<div class="vb warn"><ul>' + r.warnings.map(function (w) { return "<li>" + esc(w) + "</li>"; }).join("") + "</ul></div>" : ""); return; }
    out.innerHTML = '<p class="small">' + B.source("hardware") + B.source("simulation") + " Comparison of <b>" + esc(hw.device && hw.device.id || "hardware") + "</b> (" + esc(hw.recording && hw.recording.started || "") + ") with <b>" + esc(l.record.experiment_id || l.record.id) + "</b>, overlap " + fx(r.overlap[0], 2) + "–" + fx(r.overlap[1], 2) + " s. These numbers describe these two files only.</p>" +
      '<div class="tblx"><table class="ct"><thead><tr><th scope="col">Signal</th><th scope="col">Samples</th><th scope="col">RMSE</th><th scope="col">Mean |error|</th><th scope="col">Peak |error|</th><th scope="col">Peak difference</th><th scope="col">Best time offset</th><th scope="col">RMSE after offset</th></tr></thead><tbody>' +
      r.signals.map(function (s) { return "<tr><th scope=\"row\">" + esc(s.label) + " <span class=\"dim small\">(" + esc(s.hwColumn) + ')</span></th><td class="mono">' + s.n + '</td><td class="mono">' + sig(s.rmse, 3) + " " + esc(s.unit) + '</td><td class="mono">' + sig(s.mae, 3) + '</td><td class="mono">' + sig(s.peakErr, 3) + '</td><td class="mono">' + sig(s.peakDiff, 3) + '</td><td class="mono">' + fx(s.lag_s * 1000, 0) + ' ms</td><td class="mono">' + sig(s.rmseAfterLag, 3) + "</td></tr>"; }).join("") + "</tbody></table></div>" +
      (r.warnings.length ? '<div class="vb warn"><ul>' + r.warnings.map(function (w) { return "<li>" + esc(w) + "</li>"; }).join("") + "</ul></div>" : "") +
      r.signals.map(function (s, i) { return '<figure class="plot"><figcaption><span class="pt">' + esc(s.label) + ' <span class="u">[' + esc(s.unit) + ']</span></span></figcaption><div class="plg"><span><svg width="22" height="8"><line x1="1" y1="4" x2="21" y2="4" stroke="' + TK.color.system.hardware + '" stroke-width="2"/></svg>hardware</span><span><svg width="22" height="8"><line x1="1" y1="4" x2="21" y2="4" stroke="' + TK.color.system.twin + '" stroke-width="2" stroke-dasharray="5 3"/></svg>simulation</span></div><canvas id="valPlot' + i + '" width="900" height="300" role="img" aria-label="' + esc(s.label + ": hardware and simulation against time") + '"></canvas></figure>'; }).join("");
    r.signals.forEach(function (s, i) { plot(i, s); });
  }
  function plot(i, s) {
    var cv = $("valPlot" + i); if (!cv || !V.out) return;
    var sim = V.out.sim.samples.cols, hw = V.out.hw.samples.cols, sg = AERIS_VALIDATION.SIGNALS.filter(function (x) { return x.key === s.key; })[0];
    var conv = AERIS_VALIDATION.toSI(hw[s.hwColumn], V.out.hw.samples.units[s.hwColumn] || (s.hwColumn.indexOf("wheel_rpm") === 0 ? "rpm" : ""), sg.si);
    if (!conv.ok) return;
    cv._fixedH = 200;
    Chart.line(cv, { xlim: V.out.r.overlap, xlabel: "t [s]", ylabel: s.unit, yzero: true, series: [
      { x: hw.t, y: conv.y.map(function (v) { return v * sg.scale; }), color: TK.color.system.hardware, width: 2 },
      { x: sim.t, y: sim[sg.sim].map(function (v) { return v * sg.scale; }), color: TK.color.system.twin, width: 1.6, dash: [5, 3] }] });
  }

  function init() { story(); evolution($("evoCompact"), true); cube(); research(); results(); validation(); }
  function show(v) {
    if (v === "results") sweeps();
    if (v === "validation") { var n = AERIS_RUNS.list().length; if (n !== V.runs.length) tool(); }
  }
  return { init: init, show: show, story: story, evolution: evolution };
})();

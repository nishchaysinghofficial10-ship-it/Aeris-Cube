/* =====================================================================
   AERIS · SYSTEM STATUS — the strip under the navigation on every page
   except home:

     AERIS SYSTEM  DEMO │ SOURCE  REPLAY │ MODEL  AERIS Twin 0.3.0 · NOMINAL │
     CONTROLLER  LQR │ EXPERIMENT  AERIS-EXP-000123 │ VALIDATION  SIM ↔ HW PENDING

   It reports what is on screen, never what is hoped for: HARDWARE is only
   shown for real telemetry, VALIDATED only when AERIS_CONTENT.twin says the
   model has been validated. Pages set their own fields with update(view, …).
   model() is pure so it can be tested without a DOM.
   ===================================================================== */
var AERIS_STATUS = (function () {
  "use strict";
  var TWIN = typeof AERIS_TWIN !== "undefined" ? AERIS_TWIN : require("../core.js");
  var SCHEMA = typeof AERIS_SCHEMA !== "undefined" ? AERIS_SCHEMA : require("../platform/schema.js");
  /* telemetry (v5): a synthetic source is never HARDWARE; a declared physical source is shown as declared */
  var SOURCE_TEXT = { simulation: "SIMULATION", hardware: "HARDWARE", replay: "REPLAY", setup: "SETUP PREVIEW", "hardware-pending": "HARDWARE DATA PENDING", none: "—",
    "telemetry-synthetic": "SYNTHETIC TELEMETRY", "telemetry-declared": "TELEMETRY · DECLARED PHYSICAL", "telemetry-replay": "TELEMETRY REPLAY", "telemetry-none": "NO TELEMETRY SOURCE" };
  var SOURCE_TONE = { simulation: "sim", hardware: "hw", replay: "replay", setup: "none", "hardware-pending": "pending", none: "none",
    "telemetry-synthetic": "pending", "telemetry-declared": "hw", "telemetry-replay": "replay", "telemetry-none": "none" };
  var DEFAULTS = {
    home: { source: "none", controller: "—", experiment: "—" },
    cube: { source: "hardware-pending", controller: "—", experiment: "—" },
    twin: { source: "simulation", controller: "PID · LQR · COM-adaptive LQR", experiment: "AERIS-EXP-000001 – 000007 (reference)" },
    lab: { source: "setup", controller: "—", experiment: "draft (not run)" },
    research: { source: "none", controller: "PID · LQR · COM-adaptive LQR", experiment: "research plan" },
    results: { source: "none", controller: "—", experiment: "final dataset not yet generated" },
    validation: { source: "hardware-pending", controller: "—", experiment: "—" },
    build: { source: "none", controller: "—", experiment: "—" },
    connect: { source: "telemetry-none", controller: "—", experiment: "—" }       // ConnectPage sets the source from what the device declares
  };
  var state = { view: "home", fields: {} }, host = null;
  function engineShort() { var m = String(TWIN.VERSION.model || ""), v = /(\d+\.\d+\.\d+)/.exec(m); return "AERIS Twin " + (v ? v[1] : m); }
  function validation() {
    var st = typeof AERIS_CONTENT !== "undefined" && AERIS_CONTENT.twin && SCHEMA.VALIDATION[AERIS_CONTENT.twin.validation] ? AERIS_CONTENT.twin.validation : "nominal";
    return { status: st, short: SCHEMA.VALIDATION[st].short };
  }
  function modeLabel(m) { return m === "simulation" ? "SIMULATION" : m === "hardware" ? "HARDWARE" : "DEMO"; }
  /* the six fields for a view, from explicit fields over the view's defaults */
  function model(view, fields, mode, engine) {
    var d = DEFAULTS[view] || DEFAULTS.home, f = Object.assign({}, d, fields || {}), val = validation();
    var src = SOURCE_TEXT[f.source] ? f.source : "none";
    return [
      { key: "system", label: "AERIS SYSTEM", value: modeLabel(mode), tone: "brand", cls: "" },
      { key: "source", label: "SOURCE", value: SOURCE_TEXT[src], tone: SOURCE_TONE[src], cls: "" },
      { key: "model", label: "MODEL", value: (engine || engineShort()) + " · " + val.short, tone: "none", cls: "opt" },
      { key: "controller", label: "CONTROLLER", value: f.controller || "—", tone: "none", cls: "opt2" },
      { key: "experiment", label: "EXPERIMENT", value: f.experiment || "—", tone: "none", cls: "" },
      { key: "validation", label: "VALIDATION", value: val.status === "validated" ? "VALIDATED" : "SIM ↔ HW PENDING", tone: val.status === "validated" ? "ok" : "pending", cls: "opt" }
    ];
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function currentMode() { return typeof AERIS_SERVICE !== "undefined" ? AERIS_SERVICE.getMode() : "demo"; }
  /* v4: in SIMULATION mode the model is the research backend's engine, as it reported itself */
  function currentEngine() {
    if (typeof AERIS_SERVICE === "undefined" || AERIS_SERVICE.getMode() !== "simulation") return null;
    var c = AERIS_SERVICE.capabilities(); return c && c.reported ? (c.mock ? "MOCK backend" : "Research engine " + (/(\d+\.\d+\.\d+)/.exec(String(c.engine_version || "")) || [0, "?"])[1]) : null;
  }
  function render() {
    if (!host) return;
    var items = model(state.view, state.fields[state.view], currentMode(), currentEngine());
    host.innerHTML = items.map(function (it, i) {
      return '<div class="sb-i ' + it.cls + (i === 0 ? " first" : "") + '" data-k="' + it.key + '" title="' + esc(it.label + ": " + it.value) + '"><span class="sb-k">' + esc(it.label) + '</span><span class="sb-v t-' + it.tone + '">' + (it.tone !== "none" && it.tone !== "brand" ? '<i aria-hidden="true"></i>' : "") + esc(it.value) + "</span></div>";
    }).join("");
  }
  function init(el) {
    host = el || null; render();
    if (typeof AERIS_SERVICE !== "undefined") AERIS_SERVICE.onChange(function (ev) { if (ev.type === "mode" || ev.type === "backend") render(); });
  }
  function setView(v) { state.view = v || "home"; render(); }
  /* update(view, fields) or update(fields) for the current view; null clears a field back to the default */
  function update(view, fields) {
    if (typeof view === "object") { fields = view; view = state.view; }
    var cur = state.fields[view] || (state.fields[view] = {});
    Object.keys(fields || {}).forEach(function (k) { if (fields[k] == null) delete cur[k]; else cur[k] = fields[k]; });
    if (view === state.view) render();
  }
  function snapshot() { return model(state.view, state.fields[state.view], currentMode(), currentEngine()); }
  return { init: init, setView: setView, update: update, model: model, snapshot: snapshot, SOURCE_TEXT: SOURCE_TEXT, DEFAULTS: DEFAULTS };
})();
if (typeof module !== "undefined") module.exports = AERIS_STATUS;

/* =====================================================================
   AERIS LAB · workspace — the research environment's main screen.

   Single experiment: create a setup, run it (or the same setup with PID,
   LQR and COM-adaptive LQR), replay and compare recordings.
   Research sweep: lazy-loaded (js/ui/sweep-ui.js).

   The workspace never simulates anything itself. Runs go through the
   experiment service (AERIS_SERVICE), which picks the data source for the
   current system mode (DEMO → browser engine, SIMULATION → research
   backend, HARDWARE → telemetry, not implemented). Saved runs come back
   through the replay adapter.

   Everything on screen describes one run at one sample index (W.run, W.idx):
   3-D view, playback, event timeline, telemetry, plots and maths cannot
   disagree.
   ===================================================================== */
var Workspace = (function () {
  "use strict";
  var DEG = AERIS_TWIN.DEG, RPM = AERIS_TWIN.RPM, $ = U.$, esc = U.esc, fx = U.fx, sig = U.sig;
  var TK = AERIS_TOKENS, B = AERIS_BADGES, SVC = AERIS_SERVICE;
  var CTRL = { pid: "PID", lqr: "LQR", adp: "COM-adaptive LQR", none: "No control" };
  var EST = { ideal: "Ideal state", cf: "Complementary filter", kf: "Kalman filter (angle + bias)", accel: "Accelerometer only", gyro: "Gyro integration" };
  var EST_BACKEND = { cf3d: "Complementary attitude filter (3-D, research backend)", mekf: "Quaternion MEKF (research backend)" };
  var CFG = AERIS_CFG;
  /* research-backend options are shown in SIMULATION mode, or whenever the setup already uses them */
  function researchUI() { return SVC.engineFor() === "backend" || CFG.extensions(W.draft).length > 0; }
  /* compare styles when the runs are not one-per-controller: neutral inks told apart by dash pattern */
  var NEUTRAL = [{ color: TK.color.ink.primary, dash: [] }, { color: TK.color.ink.secondary, dash: [7, 4] }, { color: TK.color.ink.tertiary, dash: [2, 3] }, { color: TK.color.system.replay, dash: [9, 3, 2, 3] }];
  var W = { draft: null, run: null, idx: 0, playing: false, speed: 1, clock: 0, lastTs: 0, placing: null, selected: null, viewer: null, viewMode: "setup", compare: [], inited: false, attempt: null, plots: [], mathsDirty: true, lastMaths: 0, fresh: false, kind: "single", sensorTier: "basic", busy: false, viewGen: 0 };
  var host = null;

  /* =================== examples (fixed setups in js/platform/examples.js) =================== */
  var EXAMPLES = AERIS_EXAMPLES.LIST;
  function exampleRecord(ex) { return SVC.replay().exampleRecord(ex.id); }

  /* =================== layout =================== */
  function build() {
    host = $("ws"); if (!host) return false;
    host.innerHTML =
      '<header class="ws-head"><div class="ws-head-in">' +
      '<div class="ws-title"><nav class="crumb" aria-label="Breadcrumb"><a href="#top">AERIS</a><span>/</span><span class="here">Lab</span></nav>' +
      '<h1 id="wsTitle">AERIS Lab</h1><p class="ws-lede">The research environment. Run experiments on AERIS Twin, the physics-based digital model of the cube, replay and compare recordings, and plan research sweeps. Every result states where it came from.</p></div>' +
      '<div class="ws-ctrl"><div class="ws-modes" id="wsModes" role="group" aria-label="System mode"></div>' +
      '<div class="ws-kind" role="tablist" aria-label="Experiment type"><button role="tab" id="wk-single" aria-controls="wsSingle" aria-selected="true">Single experiment</button><button role="tab" id="wk-sweep" aria-controls="wsSweep" aria-selected="false">Research sweep</button><button role="tab" id="wk-tel" aria-controls="wsTel" aria-selected="false">Telemetry</button></div>' +
      '<div class="ws-entry" role="group" aria-label="Start here"><button type="button" class="ws-entry-btn" data-entry="replay"><span class="k">01</span><b>Replay a recording</b><span>Open a saved run or an example and scrub through it.</span></button>' +
      '<button type="button" class="ws-entry-btn" data-entry="create"><span class="k">02</span><b>Create an experiment</b><span>Set the cube, masses, loads, sensors and controller, then run it.</span></button></div></div></div>' +
      '<div class="ws-claims">' + B.claim("simulated") + B.claim("nominal") + B.claim("valPending") + '<span class="ws-claim-t"><span id="wsEngine">' + engineClaim() + '</span> It has not yet been validated against measurements from the physical cube. <span id="wsStore"></span></span></div></header>' +
      '<div id="wsSingle" role="tabpanel" aria-labelledby="wk-single">' +
      '<div class="ws-mtabs" role="tablist" aria-label="Workspace panels"><button role="tab" id="mt-left" aria-controls="wsLeft">Setup</button><button role="tab" id="mt-center" aria-controls="wsCenter">Cube &amp; plots</button><button role="tab" id="mt-right" aria-controls="wsRight">Results</button></div>' +
      '<div class="ws-grid">' +
      '<section class="ws-col ws-left" id="wsLeft" aria-label="Setup and recordings"><div class="pane-tabs" role="tablist" aria-label="Setup or recordings"><button role="tab" id="lt-create" aria-controls="lp-create" aria-selected="true">Create experiment</button><button role="tab" id="lt-rec" aria-controls="lp-rec">Recordings <span class="cnt" id="recCount">0</span></button></div>' +
      '<div id="lp-create" role="tabpanel" aria-labelledby="lt-create" class="pane"></div><div id="lp-rec" role="tabpanel" aria-labelledby="lt-rec" class="pane" hidden></div></section>' +
      '<section class="ws-col ws-center" id="wsCenter" aria-label="3-D view, playback, events and plots">' +
      '<div class="vw-head"><div class="vw-src" role="group" aria-label="What the 3-D view shows"><button type="button" class="vw-mode" id="vmSetup" aria-pressed="true">Setup preview</button><button type="button" class="vw-mode" id="vmReplay" aria-pressed="false" disabled>Replay</button></div>' +
      '<div class="vw-views" role="group" aria-label="Camera"><button type="button" data-view="iso">Iso</button><button type="button" data-view="side" title="Look along the world x axis (along the support edge in edge mode)">Side</button><button type="button" data-view="front">Front</button><button type="button" data-view="top">Top</button><button type="button" data-cam="in" aria-label="Zoom in">+</button><button type="button" data-cam="out" aria-label="Zoom out">−</button><button type="button" data-cam="reset">Reset</button></div></div>' +
      '<div class="vw-stage" id="vwStage" tabindex="0" aria-label="3-D view of the cube. Drag, or use the arrow keys, to orbit; plus and minus zoom; Space plays or pauses a replay.">' +
      '<canvas id="vwCanvas"></canvas><div class="ovl tl" id="vwTag"></div><div class="ovl tr mono" id="vwT"></div>' +
      '<div class="vw-legend" aria-hidden="true"><span><i style="background:' + TK.color.physics.com + '"></i>COM</span><span><i class="ghost"></i>nominal COM</span><span><i style="background:' + TK.color.physics.load + '"></i>load F, <span class="nt">τ</span><sub>F</sub></span><span><i style="background:#c9a15a"></i>mass</span><span><i style="background:' + TK.color.status.warning + '"></i>wheel saturating</span><span class="ax"><b style="color:' + TK.color.axis.x + '">x</b><b style="color:' + TK.color.axis.y + '">y</b><b style="color:' + TK.color.axis.z + '">z</b> body _B · world _N</span></div>' +
      '<div class="vw-hint" id="vwHint" hidden><span id="vwHintText"></span><button type="button" class="act" id="vwHintCancel">Cancel</button></div>' +
      '<div class="vw-fallback">3-D view unavailable (WebGL is off). A simplified 2-D view is shown; plots and numbers are unaffected.</div></div>' +
      '<div class="pb" role="group" aria-label="Playback"><button type="button" class="pb-btn" id="pbPlay" aria-label="Play" disabled><svg viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5 L10.5 6 L3 10.5 Z"/></svg></button>' +
      '<button type="button" class="pb-btn" id="pbRestart" aria-label="Restart" disabled><svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2 2h1.6v8H2zM10.5 1.8v8.4L4.3 6z"/></svg></button>' +
      '<input type="range" id="pbScrub" min="0" max="0" step="1" value="0" aria-label="Playback position" disabled><output id="pbTime" class="mono" for="pbScrub">— / —</output>' +
      '<label class="sr" for="pbSpeed">Playback speed</label><select id="pbSpeed" disabled><option value="0.1">0.1×</option><option value="0.25">0.25×</option><option value="0.5">0.5×</option><option value="1" selected>1×</option><option value="2">2×</option><option value="4">4×</option></select></div>' +
      '<div class="tl" id="tl" aria-label="Event timeline" hidden></div>' +
      '<div class="tele" id="tele" aria-label="Telemetry at the playback time"></div>' +
      '<div class="plots" id="plots"></div></section>' +
      '<section class="ws-col ws-right" id="wsRight" aria-label="Results and analysis"><div class="pane-tabs" role="tablist" aria-label="Analysis"><button role="tab" id="rt-res" aria-controls="rp-res" aria-selected="true">Results</button><button role="tab" id="rt-math" aria-controls="rp-math">Maths</button><button role="tab" id="rt-cmp" aria-controls="rp-cmp">Compare</button><button role="tab" id="rt-ask" aria-controls="rp-ask">Assistant</button></div>' +
      '<div id="rp-res" role="tabpanel" aria-labelledby="rt-res" class="pane"></div><div id="rp-math" role="tabpanel" aria-labelledby="rt-math" class="pane" hidden></div><div id="rp-cmp" role="tabpanel" aria-labelledby="rt-cmp" class="pane" hidden></div><div id="rp-ask" role="tabpanel" aria-labelledby="rt-ask" class="pane" hidden></div></section>' +
      '</div></div>' +
      '<div id="wsSweep" class="ws-sweep" role="tabpanel" aria-labelledby="wk-sweep" hidden></div>' +
      '<div id="wsTel" class="ws-sweep ws-tel" role="tabpanel" aria-labelledby="wk-tel" hidden></div>' +
      '<div class="sr" aria-live="polite" id="wsLive"></div>';
    return true;
  }

  /* =================== init & routing =================== */
  function init() {
    if (W.inited) return; if (!build()) return; W.inited = true;
    var prefs = AERIS_RUNS.loadPrefs();
    if (prefs.sensorTier) W.sensorTier = prefs.sensorTier;
    W.leftTabs = U.tabs(host.querySelector('.ws-left .pane-tabs'), function (id) { savePrefs({ left: id }); if (id === "lt-rec") renderRecordings(); });
    W.rightTabs = U.tabs(host.querySelector('.ws-right .pane-tabs'), function (id) { savePrefs({ right: id }); if (id === "rt-math") renderMaths(true); if (id === "rt-cmp") renderCompare(); if (id === "rt-ask") renderAssistant(); });
    W.mTabs = U.tabs(host.querySelector(".ws-mtabs"), function (id) { host.setAttribute("data-mtab", id.slice(3)); if (id === "mt-center") { resizeAll(); } }, { noHide: true });
    W.kindTabs = U.tabs(host.querySelector(".ws-kind"), function (id) { setKind(id === "wk-sweep" ? "sweep" : id === "wk-tel" ? "telemetry" : "single", true); });
    [].forEach.call(host.querySelectorAll(".ws-entry-btn"), function (b) { b.addEventListener("click", function () { if (W.kind !== "single") W.kindTabs.select("wk-single"); entry(b.getAttribute("data-entry")); }); });
    renderModes();
    $("wsModes").addEventListener("click", onModeClick);
    SVC.onChange(function (ev) { if (ev.type === "mode") { renderModes(); buildForm(); var ec = $("wsEngine"); if (ec) ec.textContent = engineClaim(); } else if (ev.type === "backend") { renderModes(); validateDraft(false); } });
    // draft from storage (or default)
    var d = AERIS_RUNS.loadDraft(); W.draft = d ? CFG.normalize(d) : AERIS_TWIN.defaultConfig("edge");
    buildForm(); renderRecordings();
    // viewer
    W.viewer = new AerisViewer($("vwStage"), { preserve: true });
    W.viewer.onPick = onPick;
    [].forEach.call(host.querySelectorAll(".vw-views [data-view]"), function (b) { b.addEventListener("click", function () { W.viewer.setView(b.getAttribute("data-view")); markView(b.getAttribute("data-view")); }); });
    [].forEach.call(host.querySelectorAll(".vw-views [data-cam]"), function (b) { b.addEventListener("click", function () { var k = b.getAttribute("data-cam"); if (k === "in") W.viewer.zoomBy(0.85); else if (k === "out") W.viewer.zoomBy(1 / 0.85); else { W.viewer.resetCamera(); markView("iso"); } }); });
    markView("iso");
    $("vmSetup").addEventListener("click", function () { setViewMode("setup"); });
    $("vmReplay").addEventListener("click", function () { if (W.run) setViewMode("replay"); });
    $("vwHintCancel").addEventListener("click", function () { stopPlacing(); });
    // playback
    $("pbPlay").addEventListener("click", togglePlay);
    $("pbRestart").addEventListener("click", function () { pause(); setIndex(0, "restart"); });
    $("pbScrub").addEventListener("input", function () { pause(); setIndex(+this.value, "scrub"); });
    $("pbSpeed").addEventListener("change", function () { W.speed = +this.value; savePrefs({ speed: W.speed }); });
    host.addEventListener("keydown", onKey);
    window.addEventListener("resize", U.debounce(resizeAll, 150));
    // restore
    if (prefs.speed) { W.speed = prefs.speed; $("pbSpeed").value = String(prefs.speed); }
    W.compare = (prefs.compare || []).filter(function (id) { return AERIS_RUNS.list().some(function (e) { return e.id === id; }); });
    if (prefs.right) W.rightTabs.select(prefs.right);
    storageNote();
    var opened = false;
    if (prefs.open) { var l = SVC.replay().load(prefs.open); if (l.ok) { openRun(l.record, { keepIndex: prefs.idx || 0, silent: true }); opened = true; } }
    if (!opened) { clearView("none"); setViewMode("setup"); }
    renderResults(); renderAssistant(); statusUpdate();
  }
  function show(sub) {
    init();
    if (sub === "sweep") { if (W.kind !== "sweep") W.kindTabs.select("wk-sweep"); }
    else if (sub === "telemetry") { if (W.kind !== "telemetry") W.kindTabs.select("wk-tel"); }
    else {
      if (W.kind !== "single") W.kindTabs.select("wk-single");
      if (sub === "replay") entry("replay", true); else if (sub === "create") entry("create", true);
    }
    resizeAll(); statusUpdate();
  }
  function entry(kind, fromRoute) {
    if (kind === "replay") { W.leftTabs.select("lt-rec"); W.mTabs.select("mt-left"); renderRecordings(); var f = host.querySelector("#lp-rec button, #lp-rec input"); if (f && !fromRoute) f.focus(); }
    else { W.leftTabs.select("lt-create"); W.mTabs.select("mt-left"); if (!fromRoute) { var i = host.querySelector("#lp-create input, #lp-create select"); if (i) i.focus(); } }
  }
  /* Single experiment ↔ Research sweep */
  function setKind(k, fromTabs) {
    var was = W.kind;
    W.kind = k;
    $("wsSingle").hidden = k !== "single"; $("wsSweep").hidden = k !== "sweep"; $("wsTel").hidden = k !== "telemetry";
    host.setAttribute("data-kind", k);
    if (fromTabs && typeof history !== "undefined" && history.replaceState && /^#lab/.test(location.hash || "")) { var want = k === "sweep" ? "#lab/sweep" : k === "telemetry" ? "#lab/telemetry" : "#lab"; if (location.hash !== want && !(k === "single" && /^#lab\/(replay|create)$/.test(location.hash))) history.replaceState(null, "", want); }
    if (was === "telemetry" && k !== "telemetry" && typeof AERIS_TELEMETRY_UI !== "undefined") AERIS_TELEMETRY_UI.hide();
    if (k === "sweep") { pause(); mountSweep(); } else if (k === "telemetry") { pause(); mountTelemetry(); } else resizeAll();
    statusUpdate();
  }
  /* Telemetry (docs/TELEMETRY.md): lazy-loaded like the sweep module; it only talks to the research backend */
  function mountTelemetry() {
    var box = $("wsTel");
    if (box._mounted) { if (typeof AERIS_TELEMETRY_UI !== "undefined") AERIS_TELEMETRY_UI.show(); return; }
    box.innerHTML = '<p class="ws-empty">Loading the telemetry module…</p>';
    loadModule("AERIS_TELEMETRY_UI", (window.AERIS_ENV && window.AERIS_ENV.telemetryModuleUrl) || "js/ui/telemetry-ui.js", function (ok) {
      if (!ok) { box.innerHTML = '<p class="ws-empty v-bad">The telemetry module (js/ui/telemetry-ui.js) could not be loaded. Experiments are unaffected.</p>'; return; }
      box._mounted = true;
      AERIS_TELEMETRY_UI.mount(box, { service: SVC, toast: toast, status: function (f) { W.telStatus = f; statusUpdate(); } });
      if (W.kind !== "telemetry") AERIS_TELEMETRY_UI.hide();
    });
  }
  function loadModule(globalName, url, cb) {
    if (typeof window[globalName] !== "undefined") { cb(true); return; }
    W.modWait = W.modWait || {};
    if (W.modWait[url]) { W.modWait[url].push(cb); return; }
    W.modWait[url] = [cb];
    var s = document.createElement("script"), done = function () { var l = W.modWait[url] || []; W.modWait[url] = null; l.forEach(function (f) { f(typeof window[globalName] !== "undefined"); }); };
    s.src = url; s.async = true; s.onload = done; s.onerror = done;
    document.head.appendChild(s);
  }
  function mountSweep() {
    var box = $("wsSweep");
    if (box._mounted) { if (typeof AERIS_SWEEP_UI !== "undefined") AERIS_SWEEP_UI.show(); return; }
    box.innerHTML = '<p class="ws-empty">Loading the research sweep module…</p>';
    loadSweepUI(function (ok) {
      if (!ok) { box.innerHTML = '<p class="ws-empty v-bad">The research sweep module (js/ui/sweep-ui.js) could not be loaded. Single experiments are unaffected.</p>'; return; }
      box._mounted = true;
      AERIS_SWEEP_UI.mount(box, { service: SVC, toast: toast, exportText: exportText, draft: function () { return AERIS_TWIN.clone(W.draft); }, openRecord: function (rec) { W.kindTabs.select("wk-single"); openRun(rec, { fresh: true, autoplay: true }); renderRecordings(); }, openConfig: function (cfg) { W.kindTabs.select("wk-single"); openConfig(cfg, {}); }, status: function (f) { W.sweepStatus = f; statusUpdate(); } });
    });
  }
  function loadSweepUI(cb) {
    if (typeof AERIS_SWEEP_UI !== "undefined") { cb(true); return; }
    if (W.sweepWait) { W.sweepWait.push(cb); return; }
    W.sweepWait = [cb];
    var s = document.createElement("script"), done = function () { var l = W.sweepWait || []; W.sweepWait = null; l.forEach(function (f) { f(typeof AERIS_SWEEP_UI !== "undefined"); }); };
    s.src = (window.AERIS_ENV && window.AERIS_ENV.sweepModuleUrl) || "js/ui/sweep-ui.js"; s.async = true; s.onload = done; s.onerror = done;
    document.head.appendChild(s);
  }
  function savePrefs(o) { var p = AERIS_RUNS.loadPrefs(); Object.keys(o).forEach(function (k) { p[k] = o[k]; }); AERIS_RUNS.savePrefs(p); }
  /* which engine computes runs in the active mode (v4: SIMULATION runs on the research backend) */
  function engineClaim() { return SVC.engineFor() === "backend" ? "Runs are computed by the AERIS research backend (Python: the AERIS Twin model and its research extensions) with nominal design parameters." : "Runs are computed by AERIS Twin, a physics-based digital model with nominal design parameters."; }
  function storageNote() { var el = $("wsStore"); if (!el) return; el.textContent = AERIS_RUNS.persistent ? "Recordings are saved in this browser (" + Math.round(AERIS_RUNS.usage() / 1024) + " kB used)." : "Browser storage is unavailable here, so recordings last only until this tab closes. Export them to keep them."; }
  function live(msg) { var el = $("wsLive"); if (el) { el.textContent = ""; setTimeout(function () { el.textContent = msg; }, 30); } }
  function markView(v) { [].forEach.call(host.querySelectorAll(".vw-views [data-view]"), function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-view") === v ? "true" : "false"); }); }

  /* =================== system mode (DEMO / SIMULATION / HARDWARE) =================== */
  function renderModes() {
    var el = $("wsModes"); if (!el) return;
    var cur = SVC.getMode(), ms = SVC.modes(), info = ms.filter(function (m) { return m.id === cur; })[0], off = ms.filter(function (m) { return !m.available; });
    el.innerHTML = '<span class="wm-l">System mode</span><div class="wm-seg">' + ms.map(function (m) {
      return '<button type="button" class="wm-b' + (m.id === cur ? " on" : "") + '" data-mode="' + m.id + '" aria-pressed="' + (m.id === cur ? "true" : "false") + '"' + (m.available ? "" : ' aria-disabled="true" aria-describedby="wmOff"') + ">" + B.MODE[m.id].text + (m.mock ? " · MOCK" : "") + "</button>";
    }).join("") + "</div>" +
      '<p class="wm-note"><b>' + B.MODE[cur].text + "</b> · " + esc(info.text) + (info.mock ? " " + B.mark("mockData") : "") + "</p>" +
      (off.length ? '<details class="wm-why"><summary>Why ' + off.map(function (m) { return B.MODE[m.id].text; }).join(" and ") + (off.length > 1 ? " are" : " is") + ' unavailable</summary><p class="wm-off" id="wmOff">' + off.map(function (m) { return "<span><b>" + B.MODE[m.id].text + "</b> " + esc(m.reason) + "</span>"; }).join(" ") + "</p></details>" : "") + backendLine();
  }
  /* v4: configured is not reachable — the research backend's real connection state, re-checked on request */
  function backendLine() {
    var st = SVC.backendStatus && SVC.backendStatus(); if (!st || !st.configured) return "";
    var a = SVC.adapter("research-api"), when = st.lastProbe ? new Date(st.lastProbe).toLocaleTimeString() : null;
    var state = st.reachable === true && st.capabilitiesReported ? '<span class="v-ok">reachable</span>' + (st.health && st.health.version ? " · backend " + esc(st.health.version) : "") : st.reachable === false ? '<span class="v-bad">not reachable</span>' + (st.error ? " (" + esc(st.error.message) + ")" : "") : '<span class="dim">not checked yet</span>';
    return '<p class="wm-be small" id="wmBackend">Research backend <span class="mono">' + esc(a && a.baseUrl || "") + "</span>: " + state + (when ? ' <span class="dim">· checked ' + esc(when) + "</span>" : "") + ' <button type="button" class="act" data-probe="1">Check backend</button></p>';
  }
  function onModeClick(e) {
    var pb = e.target.closest("[data-probe]");
    if (pb) { pb.disabled = true; pb.textContent = "Checking…"; SVC.probe().then(function (st) { renderModes(); live(st && st.reachable ? "Research backend reachable." : "Research backend not reachable."); }); return; }
    var b = e.target.closest("[data-mode]"); if (!b) return;
    var m = b.getAttribute("data-mode");
    if (b.getAttribute("aria-disabled") === "true") { toast(SVC.modeInfo(m).reason); return; }
    var r = SVC.setMode(m); if (!r.ok) toast(r.reason); else { live(B.MODE[m].text + " mode selected."); if (m === "hardware" && W.kind !== "telemetry") W.kindTabs.select("wk-tel"); statusUpdate(); }
  }

  /* =================== setup form =================== */
  var P = function (k, label, unit, scale, step) { return { k: "params." + k, label: label, unit: unit, scale: scale || 1, step: step || "any" }; };
  var ADV = [P("kJ", "Body inertia factor k_J", "–"), P("Jw", "Wheel spin inertia J_w", "kg·m²"), P("g", "Gravity g", "m/s²"), P("KV", "Motor K_V", "rpm/V"), P("R", "Phase resistance", "Ω"), P("Vs", "Supply voltage", "V"), P("Imax", "Driver current limit", "A"), P("wmaxRpm", "Wheel speed limit", "rpm"), P("cv", "Viscous wheel friction", "N·m·s"), P("cc", "Coulomb wheel friction", "N·m"), P("fs", "Control loop rate", "Hz"), P("rImu", "IMU distance from pivot", "mm", 1000)];
  function numField(path, label, unit, scale, opts) {
    opts = opts || {};
    var id = "f_" + path.replace(/[^a-z0-9]/gi, "_"), v = getPath(W.draft, path), shown = isFinite(v) && v !== null ? +(v * (scale || 1)).toPrecision(8) : "";
    return '<div class="fld' + (opts.cls ? " " + opts.cls : "") + '"><label for="' + id + '">' + esc(label) + (unit ? ' <span class="u">' + esc(unit) + "</span>" : "") + '</label><input id="' + id + '" type="number" step="any" inputmode="decimal" data-path="' + path + '" data-scale="' + (scale || 1) + '"' + (opts.nullable ? ' data-kind="numnull"' : "") + (opts.placeholder != null || opts.nullable ? ' placeholder="' + esc(opts.placeholder != null ? opts.placeholder : "loop rate") + '"' : "") + ' value="' + shown + '"' + (opts.min != null ? ' min="' + opts.min + '"' : "") + (opts.aria ? ' aria-describedby="' + opts.aria + '"' : "") + "></div>";
  }
  function selField(path, label, options, opts) {
    opts = opts || {};
    var id = "f_" + path.replace(/[^a-z0-9]/gi, "_"), v = String(getPath(W.draft, path));
    return '<div class="fld' + (opts.cls ? " " + opts.cls : "") + '"><label for="' + id + '">' + esc(label) + '</label><select id="' + id + '" data-path="' + path + '" data-kind="str">' + options.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (String(o[0]) === v ? " selected" : "") + ">" + esc(o[1]) + "</option>"; }).join("") + "</select></div>";
  }
  function chkField(path, label, help) {
    var id = "f_" + path.replace(/[^a-z0-9]/gi, "_");
    return '<div class="fld chk"><input type="checkbox" id="' + id + '" data-path="' + path + '" data-kind="bool"' + (getPath(W.draft, path) ? " checked" : "") + '><label for="' + id + '">' + esc(label) + (help ? '<em>' + esc(help) + "</em>" : "") + "</label></div>";
  }
  function getPath(o, path) { return path.split(".").reduce(function (a, k) { return a == null ? a : a[k]; }, o); }
  function setPath(o, path, v) { var ks = path.split("."), last = ks.pop(), t = ks.reduce(function (a, k) { if (a[k] == null) a[k] = {}; return a[k]; }, o); t[last] = v; }
  /* initial condition: the browser's tilt/rate inputs, or (revision 1.2, research backend) an explicit attitude
     quaternion, body-rate vector and wheel speeds (docs/EXPERIMENT_CONTRACT.md) */
  function initialGroup(d, edge, rui) {
    var ini = d.initial, explicit = ini.attitude_q != null || ini.body_rate_dps != null;
    var h = '<details class="grp" id="grpInit" open><summary>Initial condition</summary>';
    if (rui || explicit) h += '<div class="seg2" role="radiogroup" aria-label="Initial state given as"><label><input type="radio" name="initForm" value="legacy"' + (explicit ? "" : " checked") + '><span>Tilt and rate</span></label><label><input type="radio" name="initForm" value="explicit"' + (explicit ? " checked" : "") + '><span>Quaternion + body rate</span></label></div>';
    if (!explicit) {
      h += '<div class="row2">' + numField("initial.tilt_deg", "Initial tilt", "°") + numField("initial.rate_dps", "Initial rate", "°/s") + (edge ? "" : numField("initial.azimuth_deg", "Tilt direction", "°")) + "</div>" +
        selField("initial.reference", "Tilt measured from", [["geometric", "Geometric attitude (diagonal vertical)"], ["balance", "Balance attitude (COM above the pivot)"]]);
    } else {
      var nw = (d.wheels && d.wheels.length) || 3;
      h += '<p class="help">Research backend (revision 1.2). Attitude q = [w, x, y, z]: scalar first, Hamilton product, rotating body into world coordinates (world z up; body axes along the cube edges from the pivot corner)' +
        (edge ? ". Edge mode allows only a rotation about body x from the edge reference: q = [cos(φ/2), sin(φ/2), 0, 0] with φ = 45° + θ." : ".") + " Body rate ω in body axes. The tilt/rate inputs are not used (null).</p>" +
        '<div class="row4">' + [0, 1, 2, 3].map(function (j) { return numField("initial.attitude_q." + j, "q" + "wxyz"[j], ""); }).join("") + "</div>" +
        '<div class="btnrow"><button type="button" class="act" id="btnNormQ">Normalise q</button><span class="small dim" id="qNorm"></span></div>' +
        '<div class="row3">' + [0, 1, 2].map(function (j) { return numField("initial.body_rate_dps." + j, "ω" + "xyz"[j], "°/s"); }).join("") + "</div>" +
        '<div class="row3">' + Array.apply(null, Array(nw)).map(function (_, j) { return numField("initial.wheel_speeds_rpm." + j, "Wheel " + ((d.wheels && d.wheels[j] && d.wheels[j].id) || "xyz"[j] || j).toString().toUpperCase(), "rpm", 1, { nullable: true, placeholder: "0" }); }).join("") + "</div>";
    }
    return h + "</details>";
  }
  function setInitialForm(form) {
    var d = W.draft, v = W.draftVal || SVC.validateConfig(d), mp = v.mp;
    if (!mp) { try { mp = AERIS_TWIN.massProps(d); } catch (e) { mp = null; } }
    if (form === "explicit") {
      var ex = mp ? CFG.explicitFromLegacy(d, mp) : { attitude_q: d.mode === "edge" ? [Math.cos(Math.PI / 8), Math.sin(Math.PI / 8), 0, 0] : AERIS_TWIN.QEQ.slice(), body_rate_dps: [0, 0, 0] };
      d.initial.attitude_q = ex.attitude_q.map(function (x) { return +x.toPrecision(12); }); d.initial.body_rate_dps = ex.body_rate_dps.map(function (x) { return +x.toPrecision(12); });
      d.initial.tilt_deg = null; d.initial.azimuth_deg = null; d.initial.reference = null; d.initial.rate_dps = null;
    } else {
      delete d.initial.attitude_q; delete d.initial.body_rate_dps;
      d.initial.tilt_deg = 2; d.initial.rate_dps = 0; d.initial.azimuth_deg = 0; d.initial.reference = "geometric";
    }
    W.draft = CFG.normalize(d); draftChanged(true);
  }
  /* research-backend options (revision 1.1 of aeris-config/1); executed by the research backend only */
  function researchGroup(d) {
    var R = CFG.RECOVERY_DEFAULTS, rec = d.recovery || {};
    function ph(v) { return v == null ? "" : String(v); }
    var h = '<details class="grp" id="grpResearch"' + (CFG.extensions(d).length ? " open" : "") + '><summary>Research backend options</summary>' +
      '<p class="help">Executed by the research backend (SIMULATION mode) and saved with the run. In DEMO mode a setup that uses them is refused, never silently simplified. Empty fields use the backend defaults shown in grey.</p>' +
      '<p class="sub-h">Research recovery criteria</p><div class="row2">' +
      numField("recovery.attitude_error_deg", "Attitude error ≤", "°", 1, { placeholder: ph(R.attitude_error_deg) }) + numField("recovery.rate_dps", "Body rate ≤", "°/s", 1, { placeholder: ph(R.rate_dps) }) +
      numField("recovery.hold_s", "Held for", "s", 1, { placeholder: ph(R.hold_s) }) + numField("recovery.max_time_s", "Reached by", "s", 1, { placeholder: "window", nullable: true }) + "</div>" +
      (d.mode === "corner" ? selField("recovery.yaw_objective", "Yaw objective", [["hold", "Hold the commanded heading"], ["free", "Tilt only (yaw free)"]]) : "") +
      '<p class="help">Separate from the legacy “Recovered” outcome (COM lean within ±0.25° to the end of the window, yaw may rotate). After a wheel failure that gives up yaw control, the backend applies the criteria to tilt only and says so.</p>' +
      (d.mode === "corner" ? '<p class="sub-h">Control objective</p><div class="row2">' + selField("reference.heading", "Heading", [["hold", "Hold: initial heading + offset + yaw commands"], ["free", "Free: yaw rate damped, no heading"]]) +
        numField("reference.yaw_deg", "Heading offset", "°", 1, { placeholder: "0" }) + "</div>" +
        '<p class="help">The balance attitude (centre of mass above the pivot) is the only attitude a fixed support can hold with bounded wheel speed; other attitude targets are rejected, never projected onto it. Each run records the controller’s target next to the plant’s equilibrium.</p>' : "") +
      '<p class="sub-h">Estimator timing</p><div class="row2">' + numField("estimator.stale_after_s", "Estimate age limit", "ms", 1000, { placeholder: "latency + 4 IMU periods", nullable: true }) + "</div>" +
      '<p class="help">The controller always receives the estimate predicted to the control time; when its newest sample is older than this limit the estimate is flagged stale (invalid) in the record and on the timeline.</p>' +
      '<p class="sub-h">Rates and termination</p><div class="row2">' +
      numField("solver.integration_hz", "Integration rate", "Hz", 1, { placeholder: "loop rate", nullable: true }) + numField("sensor.rate_hz", "IMU sample rate", "Hz", 1, { placeholder: "loop rate", nullable: true }) +
      numField("termination.overspeed_rpm", "Stop above wheel speed", "rpm", 1, { placeholder: "off", nullable: true }) + "</div>" +
      chkField("termination.stop_on_recovery", "Stop the run when the research recovery criteria are met") + "</details>";
    return h;
  }
  function researchHTML(r) {
    var R = r.research, rc = R.recovery || {}, c = rc.criteria || {}, ex = r.executed || {}, t = r.termination || {}, est = R.estimator;
    var h = '<h3 class="rh">Research metrics <span class="dim small">(' + esc(r.origin && r.origin.engine || "") + ", every integration step)</span></h3>";
    h += '<p class="small">Executed: <b>' + esc((ex.controller && ex.controller.name) || r.config.controller.type) + "</b>" + (ex.controller && ex.controller.structure === "mimo-lqr" ? " (coupled MIMO)" : "") + " · sensing: <b>" + esc((ex.estimator && ex.estimator.name) || r.config.estimator.type) + "</b>" + (ex.rates ? " · integration " + fx(ex.rates.integration_hz, 0) + " Hz, control " + fx(ex.rates.control_hz, 0) + " Hz, IMU " + fx(ex.rates.sensor_hz, 0) + " Hz" : "") + "</p>";
    h += '<div class="oc ' + (rc.recovered ? "ok" : "warn") + '"><div class="oc-l" data-icon="' + U.icon(rc.recovered ? "recovered" : "not_settled") + '">' + (rc.recovered ? "Research recovery at t = " + fx(rc.t_s, 3) + " s" : "Research recovery criteria not met") + '</div><p class="oc-r">Criteria: attitude error ≤ ' + fx(c.attitude_error_deg, 2) + "°, body rate ≤ " + fx(c.rate_dps, 2) + "°/s, held " + fx(c.hold_s, 2) + " s, by " + (c.max_time_s == null ? "the end of the window" : fx(c.max_time_s, 2) + " s") + ". Objective: " + esc(rc.objective_effective || rc.objective) + (rc.target ? " · target: " + esc(rc.target) : "") + ".</p>" + (rc.objective_note ? '<p class="oc-r v-warn">' + esc(rc.objective_note) + "</p>" : "") +
      (rc.recovered && rc.sustained !== undefined ? '<p class="oc-r">First recovery ' + fx(rc.first_recovery_s != null ? rc.first_recovery_s : rc.t_s, 3) + " s · " + (rc.sustained ? "sustained to the end (from " + fx(rc.sustained_from_s, 3) + " s)" : '<span class="v-warn">not sustained</span>') + " · later exits " + (rc.exits_after_recovery || 0) + (rc.fell_after_recovery ? ' · <span class="v-bad">fell after recovering</span>' : "") + "</p>" : "") + "</div>";
    var mv = AERIS_RUNS.metricsVersion(r);
    if (mv === "1") h += '<div class="vb warn" id="mvOld"><b>Research metrics version 1 (saved before AERIS v5).</b> Those definitions had two defects: angular ISE was reported in rad²·s labelled as deg²·s, and n intervals received n+1 weights. The values below are shown as saved and are not corrected. <button type="button" class="act" data-a="reanalyze">Reanalyse on the research backend</button> simulates the saved setup again as a new record with lineage (the saved samples do not resolve every integration step).</div>';
    h += '<table class="mt"><tbody>';
    h += mrow("Metric definitions", mv === "1" ? '<span class="v-warn">version 1 (pre-v5)</span>' : "version " + esc(mv) + " · time-weighted (trapezoidal) integrals", (r.definitions.research || {}).metrics_version);
    h += mrow("Termination", esc(t.reason || "—") + (t.t != null ? " at " + fx(t.t, 3) + " s" : "") + (t.detail ? '<br><span class="dim small">' + esc(t.detail) + "</span>" : ""), (r.definitions.research || {}).termination);
    if (R.attitude_error) h += mrow("Attitude error (RMS · peak · final)", fx(R.attitude_error.rms, 3) + "° · " + fx(R.attitude_error.peak, 3) + "° · " + fx(R.attitude_error.final, 3) + "°", (r.definitions.research || {}).attitude_error);
    if (R.attitude_error) h += mrow("Attitude error IAE · ISE", sig(R.attitude_error.iae, 4) + " °·s · " + sig(R.attitude_error.ise, 4) + " °²·s", (r.definitions.research || {}).attitude_error);
    if (R.body_rate) h += mrow("Body rate (RMS · peak)", fx(R.body_rate.rms, 2) + " · " + fx(R.body_rate.peak, 2) + " °/s", (r.definitions.research || {}).body_rate);
    if (R.torque) h += mrow("Peak torque requested · applied", Object.keys(R.torque.peak_requested_Nm).map(function (w) { return w.toUpperCase() + " " + sig(R.torque.peak_requested_Nm[w], 3) + " · " + sig(R.torque.peak_applied_Nm[w], 3); }).join("; ") + " N·m", (r.definitions.research || {}).torque);
    if (R.authority) h += mrow("Authority shortfall (RMS · peak · time)", sig(R.authority.residual_rms_Nm, 3) + " · " + sig(R.authority.residual_peak_Nm, 3) + " N·m · " + fx(R.authority.deficit_s, 3) + " s", (r.definitions.research || {}).authority);
    if (R.energy_model_J != null) h += mrow("Energy (model)", fx(R.energy_model_J, 3) + " J", (r.definitions.research || {}).energy);
    if (est) h += mrow("Estimator accuracy", "attitude RMSE " + fx(est.attitude_rmse_deg, 3) + "°" + (est.tilt_rmse_deg != null ? " · tilt RMSE " + fx(est.tilt_rmse_deg, 3) + "°" : "") + (est.bias_error_final_dps != null ? " · gyro-bias error at end " + fx(est.bias_error_final_dps, 3) + " °/s" : ""), (r.definitions.research || {}).estimator);
    if (est && est.age_mean_s != null) h += mrow("Estimate age", "mean " + fx(est.age_mean_s * 1000, 2) + " ms · max " + fx(est.age_max_s * 1000, 2) + " ms · stale " + fx(est.stale_s || 0, 3) + " s" + (est.uninitialised_s ? " · before the first sample " + fx(est.uninitialised_s, 3) + " s" : ""), (r.definitions.research || {}).estimator);
    var xr = ex.reference;
    if (xr && xr.requested) h += mrow("Control objective", esc(xr.requested.attitude || "balance") + (xr.requested.heading ? " · heading " + esc(xr.requested.heading) + (xr.requested.yaw_deg ? " (offset " + fx(xr.requested.yaw_deg, 1) + "°)" : "") : "") + " · controller target " + fx(xr.target_offset_deg, 3) + "° from the plant's equilibrium", xr.note);
    var xi = ex.initial_state;
    if (xi && xi.attitude_from) h += mrow("Initial state", esc(xi.attitude_from) + " · " + esc(xi.rate_from) + " · lean " + fx(xi.lean_deg, 3) + "°", xi.frames || "");
    var ri = AERIS_RUNS.recordingInfo(r);
    if (ri.realized != null) h += mrow("Recording", (ri.mismatch ? '<span class="v-warn">' + esc(ri.note) + "</span>" : fx(ri.realized, 4) + " Hz" + (ri.schedule ? " · every " + ri.schedule.stride_steps + " integration steps + the final state" : "")), ri.schedule ? ri.schedule.endpoint : "");
    if (R.event_counts) h += mrow("Events", Object.keys(R.event_counts).map(function (k) { return k.replace(/_/g, " ") + " " + R.event_counts[k]; }).join(" · "), (r.definitions.research || {}).event_counts);
    h += "</tbody></table>";
    if (est && est.note) h += '<p class="small dim">' + esc(est.note) + "</p>";
    return h;
  }
  function buildForm() {
    var d = W.draft, edge = d.mode === "edge", f = $("lp-create");
    var openState = {}; [].forEach.call(f.querySelectorAll("details[id]"), function (x) { openState[x.id] = x.open; });
    var ctx = { draft: d, num: numField, sel: selField, tier: W.sensorTier, open: !!openState.grpSensors };
    var h = '<form class="setup" id="setupForm" novalidate onsubmit="return false">';
    h += '<fieldset class="grp"><legend>Balance mode</legend><div class="seg2" role="radiogroup" aria-label="Balance mode">' +
      '<label><input type="radio" name="wsmode" value="edge"' + (edge ? " checked" : "") + '><span>Edge</span></label><label><input type="radio" name="wsmode" value="corner"' + (!edge ? " checked" : "") + '><span>Corner</span></label></div>' +
      '<p class="help">' + (edge ? "Planar model. The cube pivots about the support edge (body x axis through the pivot corner); only wheel X acts, and the edge carries every other reaction." : "Full 3-D model about the pivot corner with all three wheels and quaternion attitude. Sensing is ideal in this mode.") + "</p></fieldset>";
    h += '<details class="grp" id="grpCube" open><summary>Cube</summary><div class="row2">' + numField("params.a", "Edge length a", "mm", 1000) + numField("params.m", "Base mass m₀", "kg") + "</div>" +
      numField("comOffset_m", "Base centre-of-mass offset δ", "mm", 1000, { aria: "hCom" }) + '<p class="help" id="hCom">' + (edge ? "Moves the bare cube's centre of mass across the support edge, along n̂ = (0, −1, 1)/√2." : "Moves the bare cube's centre of mass perpendicular to the main diagonal, along ê₁ = (2, −1, −1)/√6.") + "</p>" +
      AERIS_SETUP_UI.comShiftFields(ctx) +
      '<details class="sub"><summary>Advanced parameters</summary><div class="row2">' + ADV.map(function (a) { return numField(a.k, a.label, a.unit, a.scale); }).join("") + '</div><button type="button" class="act" id="btnNominal">Reset to nominal values</button></details>' +
      '<p class="help">Nominal design values, not measurements of the physical cube.</p></details>';
    h += '<details class="grp" id="grpMass" open><summary>Attached masses <span class="cnt">' + d.attachments.length + '</span></summary><div id="lstMass" class="lst"></div><div class="btnrow"><button type="button" class="act" id="btnAddMass">+ Add mass</button><button type="button" class="act" id="btnPlaceMass" aria-pressed="' + (W.placing && W.placing.kind === "mass" ? "true" : "false") + '">Place by clicking the cube</button></div>' +
      '<p class="help">Point masses. Positions are in the body frame: origin at the pivot corner, axes along the cube edges, each coordinate from 0 to a.</p></details>';
    h += '<details class="grp" id="grpAsym"><summary>Mass asymmetry <span class="cnt" id="asymCnt"></span></summary><div id="maPanel"></div></details>';
    var rui = researchUI();
    h += initialGroup(d, edge, rui);
    var ctlOpts = [["pid", "PID"], ["lqr", "LQR"], ["adp", "COM-adaptive LQR"], ["none", "None (no control)"]];
    if (rui || d.controller.type === "nlpd") ctlOpts.splice(3, 0, ["nlpd", "Nonlinear PD (research backend)"]);
    var estOpts = Object.keys(EST).map(function (k) { return [k, EST[k]]; });
    if (rui || EST_BACKEND[d.estimator.type]) Object.keys(EST_BACKEND).forEach(function (k) { estOpts.push([k, EST_BACKEND[k]]); });
    var estCorner = [["ideal", EST.ideal]].concat(Object.keys(EST_BACKEND).map(function (k) { return [k, EST_BACKEND[k]]; }));
    h += '<details class="grp" id="grpCtl" open><summary>Controller</summary>' + selField("controller.type", "Controller", ctlOpts) +
      (!edge && (rui || d.controller.structure === "mimo-lqr") ? selField("controller.structure", "Structure", [["decoupled", "Decoupled (per axis, browser engine)"], ["mimo-lqr", "Coupled MIMO LQR (research backend)"]]) : "") +
      '<div id="ctlCard">' + AERIS_SETUP_UI.controllerCard(d.controller.type) + "</div>" +
      chkField("controller.knowsAttachments", "Controller knows the attached masses", "Design for the true mass properties and balance attitude. Off: designed for the bare cube.") +
      (edge ? "" : chkField("controller.reconfigureOnFailure", "Reallocate torque when a wheel fails", "Least-squares reallocation to the healthy wheels; yaw control is given up.")) +
      (edge ? '<div class="row2">' + selField("estimator.type", "Sensing", estOpts) + numField("seed", "Noise seed", "") + "</div>" : (rui || d.estimator.type !== "ideal" ? '<div class="row2">' + selField("estimator.type", "Sensing", estCorner) + numField("seed", "Noise seed", "") + "</div>" : "")) +
      '<div class="row2">' + numField("torqueScale", "Torque limit", "× nominal") + numField("uncertainty.inertiaScale", "True inertia", "× model") + "</div>" +
      '<p class="help">True inertia ≠ 1 tests a model error: the plant\'s inertia is scaled, the controller\'s design is not.</p></details>';
    h += AERIS_SETUP_UI.sensorGroup(ctx);
    if (rui) h += researchGroup(d);
    h += '<details class="grp" id="grpLoads" open><summary>Forces and torques <span class="cnt">' + d.disturbances.length + '</span></summary><div id="lstLoad" class="lst"></div><div class="btnrow"><button type="button" class="act" id="btnAddForce">+ Add force</button><button type="button" class="act" id="btnAddTorque">+ Add torque</button></div>' +
      '<p class="help"><b>Body frame</b>: fixed to the cube, turns with it. <b>World frame</b>: fixed to the room, z up. Forces act at their application point; their torque about the pivot is r × F.' + (edge ? " In edge mode only the component about the support edge moves the cube." : "") + "</p></details>";
    h += '<details class="grp" id="grpEvents"' + (d.events.length || d.commands.length ? " open" : "") + '><summary>Events</summary><div id="lstEvent" class="lst"></div><div class="btnrow"><button type="button" class="act" id="btnAddFail">+ Wheel failure</button>' + (edge ? "" : '<button type="button" class="act" id="btnAddYaw">+ Yaw command</button>') + "</div>" +
      '<p class="help">' + (edge ? "Edge mode drives wheel X only; a failed wheel X gives no torque." : "A failed wheel gives no torque and only friction slows it. Yaw commands turn the cube about its balance axis.") + "</p></details>";
    h += '<details class="grp" id="grpRun" open><summary>Run</summary><div class="row2">' + numField("duration_s", "Observation window", "s") + numField("record_hz", "Recording rate", "Hz") + "</div>" +
      '<div id="valBox" class="valbox" aria-live="polite"></div><div id="draftMP" class="draftmp"></div>' +
      '<div class="btnrow main"><button type="button" class="btn btn-solid btn-sm" id="btnRun">Run experiment</button><button type="button" class="act" id="btnResetSetup">Reset setup</button></div>' +
      '<div class="btnrow"><button type="button" class="act" id="btnRunSet" title="Runs this exact setup three times, once per controller; nothing else changes">Run PID · LQR · Adaptive</button></div>' +
      '<p class="help" id="runWhere"></p>' +
      '<div class="btnrow"><button type="button" class="act" id="btnImportCfg">Import…</button><button type="button" class="act" id="btnExportCfg">Export setup</button></div></details>';
    h += "</form>";
    f.innerHTML = h;
    Object.keys(openState).forEach(function (id) { var x = $(id); if (x && id !== "grpSensors") x.open = openState[id]; });
    renderLists(); bindForm(); validateDraft(true);
  }
  function listRow(kind, i, inner, id, selected) { return '<div class="lrow' + (selected ? " sel" : "") + '" data-kind="' + kind + '" data-i="' + i + '" data-id="' + esc(id) + '">' + inner + "</div>"; }
  function inNum(path, label, unit, scale, cls) { var v = getPath(W.draft, path), id = "f_" + path.replace(/[^a-z0-9]/gi, "_"); return '<label class="mini' + (cls ? " " + cls : "") + '" for="' + id + '"><span>' + esc(label) + (unit ? " " + esc(unit) : "") + '</span><input id="' + id + '" type="number" step="any" inputmode="decimal" data-path="' + path + '" data-scale="' + (scale || 1) + '" value="' + (isFinite(v) ? +(v * (scale || 1)).toPrecision(8) : "") + '"></label>'; }
  function inSel(path, label, options) { var v = String(getPath(W.draft, path)), id = "f_" + path.replace(/[^a-z0-9]/gi, "_"); return '<label class="mini" for="' + id + '"><span>' + esc(label) + '</span><select id="' + id + '" data-path="' + path + '" data-kind="str">' + options.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (String(o[0]) === v ? " selected" : "") + ">" + esc(o[1]) + "</option>"; }).join("") + "</select></label>"; }
  function renderLists() {
    var d = W.draft, edge = d.mode === "edge";
    $("lstMass").innerHTML = d.attachments.length ? d.attachments.map(function (a, i) {
      var p = "attachments." + i;
      return listRow("mass", i, '<div class="lhead"><b>m' + (i + 1) + '</b><label class="sr" for="f_' + p.replace(/\./g, "_") + '_label">Label</label><input class="lname" id="f_' + p.replace(/\./g, "_") + '_label" data-path="' + p + '.label" data-kind="str" value="' + esc(a.label) + '"><button type="button" class="icon" data-act="select" aria-label="Select m' + (i + 1) + ' in the 3-D view">◎</button><button type="button" class="icon" data-act="remove" aria-label="Remove m' + (i + 1) + '">×</button></div>' +
        '<div class="lgrid">' + inNum(p + ".mass_kg", "mass", "kg") + inNum(p + ".pos_m.0", "x", "mm", 1000) + inNum(p + ".pos_m.1", "y", "mm", 1000) + inNum(p + ".pos_m.2", "z", "mm", 1000) + "</div>", a.id, W.selected === a.id);
    }).join("") : '<p class="empty">No added masses.</p>';
    $("lstLoad").innerHTML = d.disturbances.length ? d.disturbances.map(function (L, i) {
      var p = "disturbances." + i, force = L.type === "force";
      return listRow("load", i, '<div class="lhead"><b>' + esc(L.id) + "</b><span class=\"tag\">" + (force ? "force" : "torque") + "</span>" + (force ? '<button type="button" class="icon" data-act="place" aria-label="Place the application point of ' + esc(L.id) + ' by clicking the cube">⌖</button>' : "") + '<button type="button" class="icon" data-act="select" aria-label="Select ' + esc(L.id) + '">◎</button><button type="button" class="icon" data-act="remove" aria-label="Remove ' + esc(L.id) + '">×</button></div>' +
        '<div class="lgrid">' + (force ? inNum(p + ".magnitude_N", "|F|", "N") : inNum(p + ".magnitude_Nm", "|τ|", "N·m")) + inSel(p + ".frame", "frame", [["world", "World"], ["body", "Body"]]) + inNum(p + ".t_start_s", "start", "s") + inNum(p + ".duration_s", "for", "s") + "</div>" +
        '<div class="lgrid"><span class="lg-l">direction</span>' + inNum(p + ".direction.0", "x", "") + inNum(p + ".direction.1", "y", "") + inNum(p + ".direction.2", "z", "") + "</div>" +
        (force ? '<div class="lgrid"><span class="lg-l">point</span>' + inNum(p + ".point_m.0", "x", "mm", 1000) + inNum(p + ".point_m.1", "y", "mm", 1000) + inNum(p + ".point_m.2", "z", "mm", 1000) + "</div>" : ""), L.id, W.selected === L.id);
    }).join("") : '<p class="empty">No forces or torques.</p>';
    var ev = d.events.map(function (e, i) { var p = "events." + i; return listRow("event", i, '<div class="lhead"><b>' + esc(e.id) + '</b><span class="tag">wheel failure</span><button type="button" class="icon" data-act="remove" aria-label="Remove ' + esc(e.id) + '">×</button></div><div class="lgrid">' + inSel(p + ".wheel", "wheel", [["x", "X"], ["y", "Y"], ["z", "Z"]]) + inNum(p + ".t_s", "at", "s") + "</div>", e.id); }).join("");
    ev += edge ? "" : d.commands.map(function (c, i) { var p = "commands." + i; return listRow("command", i, '<div class="lhead"><b>' + esc(c.id) + '</b><span class="tag">yaw step</span><button type="button" class="icon" data-act="remove" aria-label="Remove ' + esc(c.id) + '">×</button></div><div class="lgrid">' + inNum(p + ".t_s", "at", "s") + inNum(p + ".angle_deg", "to", "°") + "</div>", c.id); }).join("");
    $("lstEvent").innerHTML = ev || '<p class="empty">No events.</p>';
  }
  function bindForm() {
    var form = $("setupForm");
    form.addEventListener("input", onFormInput);
    form.addEventListener("change", onFormInput);
    form.addEventListener("click", function (e) {
      var b = e.target.closest("button"); if (!b) return;
      var id = b.id, row = b.closest(".lrow");
      if (row) {
        var kind = row.getAttribute("data-kind"), i = +row.getAttribute("data-i"), act = b.getAttribute("data-act"), rid = row.getAttribute("data-id");
        var list = kind === "mass" ? W.draft.attachments : kind === "load" ? W.draft.disturbances : kind === "event" ? W.draft.events : W.draft.commands;
        if (act === "remove") { list.splice(i, 1); if (W.selected === rid) W.selected = null; draftChanged(true); }
        else if (act === "select") { W.selected = W.selected === rid ? null : rid; setViewMode("setup"); renderLists(); previewSetup(); }
        else if (act === "place") { startPlacing({ kind: "load", id: rid }); }
        return;
      }
      if (id === "btnAddMass") { addMass(); }
      else if (id === "btnPlaceMass") { if (W.placing && W.placing.kind === "mass") stopPlacing(); else startPlacing({ kind: "mass" }); }
      else if (id === "btnAddForce" || id === "btnAddTorque") addLoad(id === "btnAddForce" ? "force" : "torque");
      else if (id === "btnAddFail") { W.draft.events.push({ id: nextId("E", W.draft.events), type: "wheel_failure", wheel: "x", t_s: 1 }); draftChanged(true); }
      else if (id === "btnAddYaw") { W.draft.commands.push({ id: nextId("C", W.draft.commands), type: "yaw_step", t_s: 1, angle_deg: 45 }); draftChanged(true); }
      else if (id === "btnNominal") { W.draft.params = AERIS_TWIN.clone(AERIS_TWIN.NOMINAL); draftChanged(true); }
      else if (id === "btnNormQ") { var q = W.draft.initial.attitude_q, n = q && Math.hypot(q[0], q[1], q[2], q[3]); if (n > 0 && isFinite(n)) { W.draft.initial.attitude_q = q.map(function (x) { return +(x / n).toPrecision(15); }); draftChanged(true); } }
      else if (id === "btnRun") runDraft();
      else if (id === "btnRunSet") runControllerSet();
      else if (id === "btnResetSetup") { W.draft = AERIS_TWIN.defaultConfig(W.draft.mode); W.selected = null; draftChanged(true); }
      else if (id === "btnExportCfg") exportText("aeris-setup.json", AERIS_RUNS.exportConfig(W.draft), "application/json", "Setup (configuration only)");
      else if (id === "btnImportCfg") importDialog();
    });
    [].forEach.call(form.querySelectorAll('input[name="wsmode"]'), function (r) { r.addEventListener("change", function () { if (!r.checked) return; var old = W.draft; W.draft = CFG.normalize(Object.assign(AERIS_TWIN.clone(old), { mode: r.value, estimator: r.value === "corner" && ["cf3d", "mekf"].indexOf(old.estimator.type) < 0 ? { type: "ideal" } : old.estimator, commands: r.value === "edge" ? [] : old.commands })); stopPlacing(); draftChanged(true); var rr = host.querySelector('input[name="wsmode"][value="' + r.value + '"]'); if (rr) rr.focus(); }); });
    [].forEach.call(form.querySelectorAll('input[name="initForm"]'), function (r) { r.addEventListener("change", function () { if (!r.checked) return; setInitialForm(r.value); var rr = host.querySelector('input[name="initForm"][value="' + r.value + '"]'); if (rr) rr.focus(); }); });
    [].forEach.call(form.querySelectorAll('input[name="sensorTier"]'), function (r) { r.addEventListener("change", function () { if (!r.checked) return; W.sensorTier = r.value; savePrefs({ sensorTier: r.value }); var g = $("grpSensors"); if (g) g.open = true; buildForm(); var g2 = $("grpSensors"); if (g2) g2.open = true; var rr = host.querySelector('input[name="sensorTier"][value="' + r.value + '"]'); if (rr) rr.focus(); }); });
  }
  function nextId(prefix, list) { var n = 1, ids = list.map(function (x) { return x.id; }); while (ids.indexOf(prefix + n) >= 0) n++; return prefix + n; }
  function addMass(pos) {
    var a = W.draft.params.a, id = nextId("m", W.draft.attachments);
    W.draft.attachments.push({ id: id, label: "Mass " + (W.draft.attachments.length + 1), mass_kg: 0.05, pos_m: pos || [a / 2, a / 2, a] });
    W.selected = id; draftChanged(true);
  }
  function addLoad(type) {
    var a = W.draft.params.a, id = nextId(type === "force" ? "F" : "T", W.draft.disturbances);
    W.draft.disturbances.push(type === "force" ? { id: id, type: "force", magnitude_N: 0.3, point_m: [a / 2, a, a], direction: [0, 1, 0], frame: "world", t_start_s: 1, duration_s: 1 } : { id: id, type: "torque", magnitude_Nm: 0.02, direction: [1, 0, 0], frame: "body", t_start_s: 1, duration_s: 1 });
    W.selected = id; draftChanged(true);
  }
  function onFormInput(e) {
    var t = e.target, path = t.getAttribute("data-path"); if (!path) return;
    var kind = t.getAttribute("data-kind"), v;
    if (kind === "bool") v = !!t.checked; else if (kind === "str") v = t.value;
    else { var raw = String(t.value).trim().replace("−", "-"); v = raw === "" ? (kind === "numnull" ? null : NaN) : parseFloat(raw) / (+t.getAttribute("data-scale") || 1); }
    var mw = /^initial\.wheel_speeds_rpm\.(\d+)$/.exec(path);
    if (mw) {   // a list with one speed per wheel; an empty field means 0 rpm; all zero → the field is removed (the default)
      var nw = (W.draft.wheels && W.draft.wheels.length) || 3, ws = Array.isArray(W.draft.initial.wheel_speeds_rpm) ? W.draft.initial.wheel_speeds_rpm.slice(0, nw) : [];
      while (ws.length < nw) ws.push(0);
      ws[+mw[1]] = v == null ? 0 : v;
      if (ws.every(function (x) { return x === 0; })) delete W.draft.initial.wheel_speeds_rpm; else W.draft.initial.wheel_speeds_rpm = ws;
      draftChanged(false); return;
    }
    setPath(W.draft, path, v);
    if (path === "controller.type") { var cc = $("ctlCard"); if (cc) cc.innerHTML = AERIS_SETUP_UI.controllerCard(v); draftChanged(false); statusUpdate(); }
    else if (path === "estimator.type") draftChanged(true);
    else if (path.indexOf("disturbances.") === 0 && /\.type$/.test(path)) draftChanged(true); else draftChanged(false);
  }
  var saveDraftSoon = U.debounce(function () { AERIS_RUNS.saveDraft(W.draft); }, 300);
  var validateSoon = U.debounce(function () { validateDraft(false); }, 120);
  function draftChanged(rebuild) {
    if (rebuild) { buildForm(); } else validateSoon();
    saveDraftSoon();
    if (W.viewMode === "setup") previewSetupSoon();
  }
  function validateDraft(initial) {
    if (!$("valBox")) return;
    var v = SVC.validateConfig(W.draft); W.draftVal = v;
    [].forEach.call(host.querySelectorAll("#setupForm [aria-invalid]"), function (x) { x.removeAttribute("aria-invalid"); });
    v.errors.forEach(function (er) { [].forEach.call(host.querySelectorAll('#setupForm [data-path^="' + er.path + '"]'), function (x) { x.setAttribute("aria-invalid", "true"); }); });
    var box = $("valBox"), h = "";
    if (v.errors.length) h += '<div class="vb err"><b>Invalid configuration.</b> This setup cannot be run:<ul>' + v.errors.map(function (e) { return "<li>" + esc(e.message) + "</li>"; }).join("") + "</ul></div>";
    if (v.warnings.length) h += '<div class="vb warn"><b>Check before running:</b><ul>' + v.warnings.map(function (e) { return "<li>" + esc(e.message) + "</li>"; }).join("") + "</ul></div>";
    if (!h) h = '<div class="vb ok">Configuration is physically consistent and ready to run.</div>';
    box.innerHTML = h;
    var route = SVC.route("single"), canRun = v.ok && !!route && !W.busy;
    ["btnRun", "btnRunSet"].forEach(function (id) { var b = $(id); if (b) { b.setAttribute("aria-disabled", canRun ? "false" : "true"); b.classList.toggle("is-off", !canRun); } });
    var rw = $("runWhere"); if (rw) rw.innerHTML = route ? "Runs on: <b>" + esc(route.label) + "</b> (" + B.MODE[SVC.getMode()].text + " mode)." + (route.mock ? " " + B.mark("mockData") : "") : '<span class="v-warn">' + esc(B.MODE[SVC.getMode()].text) + " mode cannot run experiments. Switch to DEMO.</span>";
    // draft mass properties (setup quantities computed from the draft)
    var mpBox = $("draftMP");
    if (v.ok && v.mp) {
      var mp = v.mp, edge = W.draft.mode === "edge", l = edge ? mp.edge.l : mp.corner.l, beta = edge ? mp.edge.beta : mp.corner.beta, hold = mp.M * W.draft.params.g * l * Math.abs(Math.sin(beta)), tmax = v.design ? v.design.actuator.taumax : AERIS_TWIN.derive(W.draft.params).taumax * W.draft.torqueScale;
      mpBox.innerHTML = '<div class="dmp-h">Setup quantities <span>from this draft · fixed during a run</span></div><dl>' +
        "<dt>Total mass M</dt><dd>" + fx(mp.M, 3) + " kg</dd><dt>Centre of mass</dt><dd>(" + mp.rc.map(function (x) { return fx(x * 1000, 1); }).join(", ") + ") mm</dd>" +
        "<dt>Lever arm l</dt><dd>" + fx(l * 1000, 2) + " mm</dd><dt>Balance lean β</dt><dd>" + fx(beta / DEG, 3) + "°</dd>" +
        "<dt>" + (edge ? "Θ about the edge" : "Θ eigenvalues") + "</dt><dd>" + (edge ? sig(mp.edge.Th0, 4) + " kg·m²" : mp.corner.eig.map(function (x) { return sig(x, 3); }).join(", ")) + "</dd>" +
        "<dt>Holding torque at geometric attitude</dt><dd>" + sig(hold, 3) + " N·m <span class=\"" + (hold > tmax ? "v-bad" : "dim") + "\">(" + fx(hold / tmax * 100, 0) + " % of τ<sub>max</sub>)</span></dd></dl>";
    } else mpBox.innerHTML = "";
    var ma = $("maPanel"), ac = $("asymCnt");
    if (ma) {
      var mpx = v.mp || null;
      if (!mpx) { try { var t = AERIS_TWIN.massProps(v.config); if (t.rc.every(isFinite)) mpx = t; } catch (x) { mpx = null; } }
      ma.innerHTML = AERIS_MASSUI.render(v.config, mpx);
      if (ac) { if (mpx) { var A = AERIS_MASSUI.asymmetry(v.config, mpx); ac.textContent = "|Δr| " + fx(A.drNorm * 1000, 2) + " mm"; } else ac.textContent = ""; }
    }
    if (!initial && W.viewMode === "setup") previewSetupSoon();
    if (!W.run) statusUpdate();
  }

  /* =================== viewer: setup preview and replay =================== */
  function sceneOf(cfg, mp, failed, selected) {
    var loads = (cfg.disturbances || []).map(function (L) { return { id: L.id, type: L.type, point_m: L.point_m, frame: L.frame, label: L.id + " " + (L.type === "force" ? fx(L.magnitude_N, 2) + " N" : fx(L.magnitude_Nm, 3) + " N·m") }; });
    var a = cfg.params.a;
    return { mode: cfg.mode, a: a, attachments: cfg.attachments, com_m: mp.rc, nominal_com_m: [a / 2, a / 2, a / 2], loads: loads, failed: failed || [false, false, false], selected: selected };
  }
  function loadVectors(cfg, R, t) {
    var tq = [0, 0, 0], out = [];
    (cfg.disturbances || []).forEach(function (L) {
      var active = t != null && AERIS_TWIN.loadActive(L, t);
      if (L.type === "force") {
        var Fw = AERIS_TWIN.loadForceWorld(L, R); out.push({ id: L.id, point_m: L.point_m, F_world: Fw, active: active, label: L.id });
        if (active) { var tb = AERIS_TWIN.loadTorqueBody(L, R), tw = AERIS_TWIN.vec.mv(R, tb); tq = AERIS_TWIN.vec.add3(tq, tw); }
      } else if (active) { var tb2 = AERIS_TWIN.loadTorqueBody(L, R); tq = AERIS_TWIN.vec.add3(tq, AERIS_TWIN.vec.mv(R, tb2)); }
    });
    return { loads: out, torque: tq };
  }
  /* The setup preview is scheduled (debounced) while editing. Every view-mode change increments W.viewGen and
     cancels the pending preview; the callback also checks the generation and the mode when it fires, so a
     preview scheduled in setup mode can never overwrite a replay that was opened in the meantime (v4 defect E). */
  var previewTimer = U.debounce(function (gen) { if (gen === W.viewGen && W.viewMode === "setup") previewSetup(); }, 90);
  function previewSetupSoon() { previewTimer(W.viewGen); }
  function previewSetup() {
    if (!W.viewer || W.viewMode !== "setup") return;
    var v = W.draftVal || AERIS_TWIN.validateConfig(W.draft), cfg = v.config, mp = v.mp;
    if (!mp) { try { mp = AERIS_TWIN.massProps(cfg); if (!mp.rc.every(isFinite)) mp = null; } catch (e) { mp = null; } }
    if (!mp || !isFinite(cfg.params.a) || cfg.params.a <= 0) { $("vwTag").innerHTML = '<span class="vtag bad">Setup preview · fix the highlighted values to update the view</span>'; return; }
    var pose = null; try { pose = CFG.initialPose(cfg, mp); } catch (e) { pose = null; }
    var R = pose ? pose.R : cfg.mode === "edge" ? AERIS_TWIN.edgeR(0) : AERIS_TWIN.Q3.rot(AERIS_TWIN.QEQ);
    W.viewer.setScene(sceneOf(cfg, mp, null, W.selected));
    var lv = loadVectors(cfg, R, null);
    W.viewer.setPose({ R: R, wheelAngles: [0, 0, 0], loads: lv.loads, torque_world: null, gravity_N: mp.M * cfg.params.g, t: null, idx: null, runId: null });
    W.viewer.pickMode = !!W.placing;
    $("vwTag").innerHTML = v.ok ? '<span class="vtag">Setup preview · initial attitude · not a run</span>' : '<span class="vtag bad">Setup preview · this setup has errors (see the list under Run)</span>';
    $("vwT").textContent = "";
  }
  function setViewMode(m) {
    if (m === "replay" && !W.run) m = "setup";
    W.viewGen++; previewTimer.cancel();
    W.viewMode = m;
    $("vmSetup").setAttribute("aria-pressed", m === "setup" ? "true" : "false"); $("vmReplay").setAttribute("aria-pressed", m === "replay" ? "true" : "false");
    host.classList.toggle("vm-setup", m === "setup");
    if (m === "setup") { pause(); previewSetup(); }
    else { stopPlacing(true); showRunInViewer(); updateAtIndex("mode"); }
  }
  function showRunInViewer() {
    var r = W.run; if (!r || !W.viewer) return;
    var mp = { rc: r.derived.rc, M: r.derived.M };
    W.viewer.setScene(sceneOf(r.config, mp, null, null));
    W.viewer.pickMode = false;
  }
  function wheelAngles(run) {   // cumulative wheel angle from the saved speeds (for drawing only)
    if (run._ang) return run._ang;
    // a custom wheel set (research backend) is not drawn by the three-wheel model: its wheels stay still in the view
    var S = run.samples.cols, cols = AERIS_RUNS.customWheels(run) ? [] : run.config.mode === "edge" ? ["omega_x"] : ["omega_x", "omega_y", "omega_z"], n = S.t.length, out = [new Float64Array(n), new Float64Array(n), new Float64Array(n)];
    cols.forEach(function (c, j) { for (var i = 1; i < n; i++) out[j][i] = out[j][i - 1] + 0.5 * (S[c][i] + S[c][i - 1]) * (S.t[i] - S.t[i - 1]); });
    run._ang = out; return out;
  }
  function halfStep(run) { var T = run.samples.cols.t; return T.length > 1 ? (T[1] - T[0]) / 2 : 0.005; }
  /* per-wheel state at sample i: failed (red) / sat (amber: torque-limited or ≥ 98 % of the speed limit) / risk (amber: ≥ 90 %) / ok */
  function wheelStates(run, i) {
    var S = run.samples.cols, cfg = run.config, edge = cfg.mode === "edge", t = S.t[i], wmax = run.derived.motor.wmax, R = AERIS_TWIN.EVENT_RULES;
    if (AERIS_RUNS.customWheels(run)) return ["ok", "ok", "ok"];
    var act = AERIS_EVENTS.activeAt(AERIS_EVENTS.timelineOf(run), t, halfStep(run));
    return [0, 1, 2].map(function (j) {
      var w = AERIS_TWIN.WHEELS[j];
      var failed = (cfg.events || []).some(function (e) { return e.type === "wheel_failure" && e.wheel === w && t >= e.t_s && (!edge || j === 0); });
      if (failed) return "failed";
      if (edge && j > 0) return "ok";
      var om = S["omega_" + w], f = om ? Math.abs(om[i]) / wmax : 0;
      var satNow = edge ? !!S.sat[i] : act.some(function (e) { return e.type === "saturation" && e.wheel === w; });
      return satNow || f >= R.speedLimitFrac ? "sat" : f >= R.speedRiskFrac ? "risk" : "ok";
    });
  }
  function poseAt(run, i) {
    var S = run.samples.cols, cfg = run.config, t = S.t[i];
    var R = cfg.mode === "edge" ? AERIS_TWIN.edgeR(S.theta[i]) : AERIS_TWIN.Q3.rot([S.q0[i], S.q1[i], S.q2[i], S.q3[i]]);
    var ang = wheelAngles(run), ws = wheelStates(run, i);
    var lv = loadVectors(cfg, R, t);
    return { R: R, wheelAngles: [ang[0][i], ang[1][i], ang[2][i]], failed: ws.map(function (s) { return s === "failed"; }), wheelState: ws, loads: lv.loads, torque_world: lv.torque, gravity_N: run.derived.M * cfg.params.g, t: t, idx: i, runId: run.id };
  }

  /* =================== placing masses and force points =================== */
  function startPlacing(pl) {
    W.placing = pl; setViewMode("setup"); W.viewer.pickMode = true;
    $("vwHint").hidden = false;
    $("vwHintText").textContent = pl.kind === "mass" ? "Click a point on the cube to add a 50 g mass there. Edit the numbers afterwards if needed." : "Click the cube where force " + pl.id + " should act.";
    var b = $("btnPlaceMass"); if (b) b.setAttribute("aria-pressed", pl.kind === "mass" ? "true" : "false");
    W.mTabs.select("mt-center");
    $("vwStage").focus();
  }
  function stopPlacing(silent) {
    W.placing = null; if (W.viewer) W.viewer.pickMode = false; var h = $("vwHint"); if (h) h.hidden = true;
    var b = $("btnPlaceMass"); if (b) b.setAttribute("aria-pressed", "false");
  }
  function onPick(hit) {
    if (hit.kind === "unsupported") { toast(hit.message); stopPlacing(); return; }
    if (W.viewMode !== "setup") return;
    if (hit.kind === "mass" || hit.kind === "load") { W.selected = hit.id; renderLists(); previewSetup(); var row = host.querySelector('.lrow[data-id="' + hit.id + '"]'); if (row) { W.mTabs.select("mt-left"); W.leftTabs.select("lt-create"); row.scrollIntoView({ block: "nearest" }); } return; }
    if (!W.placing || hit.kind !== "surface") return;
    var pt = hit.point_m.map(function (v) { return Math.round(v * 10000) / 10000; });
    if (W.placing.kind === "mass") { stopPlacing(); addMass(pt); toast("Mass added at (" + pt.map(function (v) { return fx(v * 1000, 1); }).join(", ") + ") mm."); }
    else if (W.placing.kind === "load") {
      var L = W.draft.disturbances.filter(function (x) { return x.id === W.placing.id; })[0];
      if (L) { L.point_m = pt; W.selected = L.id; toast("Force " + L.id + " now acts at (" + pt.map(function (v) { return fx(v * 1000, 1); }).join(", ") + ") mm."); }
      stopPlacing(); draftChanged(true);
    }
  }
  function toast(msg) { live(msg); var el = U.el("div", { cls: "ws-toast", role: "status", text: msg }); document.body.appendChild(el); setTimeout(function () { el.classList.add("out"); }, 2600); setTimeout(function () { el.remove(); }, 3200); }

  /* =================== running (through the experiment service) =================== */
  function setBusy(on, label) {
    W.busy = on;
    var b = $("btnRun"), s = $("btnRunSet");
    if (b) { b.textContent = on && label === "single" ? "Running…" : "Run experiment"; b.disabled = on; }
    if (s) { s.textContent = on && label === "set" ? "Running 3 controllers…" : "Run PID · LQR · Adaptive"; s.disabled = on; }
    if (!on) validateDraft(false);
  }
  function rejectAttempt(v) {
    W.attempt = { outcome: { code: "invalid", label: AERIS_TWIN.OUTCOMES.invalid.label, reason: "Rejected before the controller design and simulation." }, errors: v.errors, when: new Date() };
    clearView("invalid"); renderResults(); W.rightTabs.select("rt-res"); W.mTabs.select("mt-right");
    live("Invalid configuration. " + v.errors.map(function (e) { return e.message; }).join(" "));
    statusUpdate();
  }
  function failedAttempt(outcome, errors) {
    W.attempt = { outcome: outcome, errors: errors || [], when: new Date() };
    clearView("invalid"); renderResults(); W.rightTabs.select("rt-res");
    live(outcome.label + ". " + outcome.reason); statusUpdate();
  }
  function runDraft() {
    if (W.busy) return;
    var v = SVC.validateConfig(W.draft);
    if (!v.ok) { rejectAttempt(v); return; }
    if (!SVC.route("single")) { toast(B.MODE[SVC.getMode()].text + " mode cannot run experiments."); return; }
    setBusy(true, "single");
    SVC.runSingle(AERIS_TWIN.clone(W.draft)).then(function (out) {
      setBusy(false);
      if (!out.ok) { var res = out.result || {}; failedAttempt(res.outcome || { code: "invalid", label: AERIS_TWIN.OUTCOMES.invalid.label, reason: "The run was rejected." }, res.errors); return; }
      W.attempt = null;
      var rec = out.record, s = AERIS_RUNS.save(rec);
      rec._unsaved = !s.ok; if (!s.ok) toast(s.error);
      openRun(rec, { autoplay: true, fresh: true });
      renderRecordings(); storageNote();
      live("Run " + (rec.experiment_id || "") + " finished: " + rec.outcome.label + ". " + rec.outcome.reason);
    }, function (e) {
      setBusy(false);
      failedAttempt({ code: "invalid", label: "Run not completed", reason: (e && e.message ? e.message : "The data source did not complete the run.") + " Nothing was saved." }, []);
    });
  }
  /* the same setup with PID, LQR and COM-adaptive LQR; only controller.type changes between the three runs */
  function runControllerSet() {
    if (W.busy) return;
    var v = SVC.validateConfig(W.draft);
    if (!v.ok) { rejectAttempt(v); return; }
    if (!SVC.route("single")) { toast(B.MODE[SVC.getMode()].text + " mode cannot run experiments."); return; }
    setBusy(true, "set");
    SVC.runControllerSet(AERIS_TWIN.clone(W.draft), ["pid", "lqr", "adp"]).then(function (o) {
      setBusy(false);
      var recs = o.records, failed = o.outcomes.filter(function (x) { return !x.ok; }).length;
      if (!recs.length) { failedAttempt({ code: "invalid", label: "Controller set not completed", reason: "None of the three runs completed." }, []); return; }
      recs.forEach(function (r) { var s = AERIS_RUNS.save(r); r._unsaved = !s.ok; });
      var saved = recs.filter(function (r) { return !r._unsaved; });
      W.compare = saved.map(function (r) { return r.id; }).slice(0, 4); savePrefs({ compare: W.compare });
      var pick = recs.filter(function (r) { return r.config.controller.type === W.draft.controller.type; })[0] || recs[0];
      W.attempt = null;
      openRun(pick, { fresh: true, silent: true }); renderRecordings(); storageNote();
      W.rightTabs.select("rt-cmp"); renderCompare(); W.mTabs.select("mt-right");
      toast("Controller set " + recs.map(function (r) { return r.experiment_id; }).join(" / ") + " finished" + (failed ? "; " + failed + " run(s) did not complete" : "") + ". See Compare.");
    }, function (e) { setBusy(false); toast("Controller set not completed: " + (e && e.message ? e.message : "unknown error")); });
  }
  function openRun(rec, opts) {
    opts = opts || {};
    pause(); W.attempt = null; W.run = rec; W.idx = 0; W._ang = null; W.fresh = !!opts.fresh;
    savePrefs({ open: rec._unsaved ? null : rec.id, idx: 0 });
    $("vmReplay").disabled = false;
    var n = rec.samples.cols.t.length;
    ["pbPlay", "pbRestart", "pbScrub", "pbSpeed"].forEach(function (id) { $(id).disabled = false; });
    $("pbScrub").max = String(n - 1);
    AERIS_TIMELINE.render($("tl"), rec, { onSeek: seekTime });
    drawPlots();
    setViewMode("replay");
    setIndex(Math.min(opts.keepIndex || 0, n - 1), "open");
    renderResults(); renderMaths(true); if (W.rightTabs.current() === "rt-cmp") renderCompare(); renderAssistant(); renderRecordings();
    if (!opts.silent) W.mTabs.select("mt-center");
    statusUpdate();
    var RM = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (opts.autoplay && !RM) play();
  }
  /* reset every view that shows a run: 3-D replay, playback, timeline, telemetry, plots, results, maths */
  function clearView(reason) {
    pause(); W.run = null; W.idx = 0; W.fresh = false;
    savePrefs({ open: null, idx: 0 });
    $("vmReplay").disabled = true;
    ["pbPlay", "pbRestart", "pbScrub", "pbSpeed"].forEach(function (id) { $(id).disabled = true; });
    $("pbScrub").max = "0"; $("pbScrub").value = "0"; $("pbTime").textContent = "— / —"; $("pbScrub").setAttribute("aria-valuetext", "no run selected");
    AERIS_TIMELINE.render($("tl"), null);
    $("tele").innerHTML = '<p class="ws-empty">' + (reason === "invalid" ? "No run to show: the last attempt was rejected or not completed (see Results)." : reason === "cleared" ? "All recordings were deleted. Create an experiment or open an example." : "No run selected. Create an experiment or open a recording.") + "</p>";
    $("plots").innerHTML = ""; $("plots").removeAttribute("data-run"); W.plots = []; W.plotCursor = null;
    $("vwT").textContent = "";
    setViewMode("setup");
    renderMaths(true); renderAssistant();
    if (reason !== "invalid") renderResults();
    statusUpdate();
  }
  function seekTime(t) {
    if (!W.run) return;
    var T = W.run.samples.cols.t, lo = 0, hi = T.length - 1; t = Math.max(0, t);
    while (hi - lo > 1) { var mid = (lo + hi) >> 1; if (T[mid] <= t) lo = mid; else hi = mid; }
    pause(); setIndex(Math.abs(T[hi] - t) < Math.abs(T[lo] - t) ? hi : lo, "timeline");
    if (W.viewMode !== "replay") setViewMode("replay");
  }
  /* the system status strip reports what this screen shows */
  function statusUpdate() {
    if (typeof AERIS_STATUS === "undefined" || !W.draft) return;
    if (W.kind === "sweep") { var s = W.sweepStatus || {}; AERIS_STATUS.update("lab", { source: s.source || "setup", controller: s.controller || "PID · LQR · COM-adaptive LQR", experiment: s.experiment || "research sweep (not run)" }); return; }
    if (W.kind === "telemetry") { var ts = W.telStatus || {}; AERIS_STATUS.update("lab", { source: ts.source || "telemetry-none", controller: ts.controller || "— (read-only telemetry)", experiment: ts.experiment || "telemetry" }); return; }
    var r = W.run;
    if (r) AERIS_STATUS.update("lab", { source: W.fresh ? (r.origin && r.origin.kind === "hardware" ? "hardware" : "simulation") : "replay", controller: CTRL[r.config.controller.type] || r.config.controller.type, experiment: r.experiment_id || r.id });
    else AERIS_STATUS.update("lab", { source: "setup", controller: (CTRL[W.draft.controller.type] || W.draft.controller.type) + " (draft)", experiment: W.attempt ? "last attempt not run" : "draft (not run)" });
  }

  /* =================== playback =================== */
  function togglePlay() { if (W.playing) pause(); else play(); }
  function play() {
    if (!W.run) return;
    var n = W.run.samples.cols.t.length;
    if (W.idx >= n - 1) setIndex(0, "restart");
    if (W.viewMode !== "replay") setViewMode("replay");
    W.playing = true; W.clock = W.run.samples.cols.t[W.idx]; W.lastTs = 0;
    $("pbPlay").setAttribute("aria-label", "Pause"); $("pbPlay").innerHTML = '<svg viewBox="0 0 12 12" aria-hidden="true"><rect x="2" y="1.5" width="2.6" height="9"/><rect x="7.4" y="1.5" width="2.6" height="9"/></svg>';
    requestAnimationFrame(tick);
  }
  function pause() {
    if (!W.playing) return; W.playing = false;
    var b = $("pbPlay"); if (b) { b.setAttribute("aria-label", "Play"); b.innerHTML = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M3 1.5 L10.5 6 L3 10.5 Z"/></svg>'; }
    if (W.run) { savePrefs({ idx: W.idx }); renderMaths(false); }
  }
  function tick(ts) {
    if (!W.playing || !W.run) return;
    var dt = W.lastTs ? Math.min(0.25, (ts - W.lastTs) / 1000) : 0; W.lastTs = ts;   // real time, unless a frame took longer than 0.25 s
    if (advanceBy(dt)) requestAnimationFrame(tick);
  }
  /* move the playback clock by dt seconds of wall time at the chosen speed; false when the end is reached */
  function advanceBy(dt) {
    W.clock += dt * W.speed;
    var T = W.run.samples.cols.t, n = T.length, i = W.idx;
    while (i < n - 1 && T[i + 1] <= W.clock + 1e-9) i++;
    if (i !== W.idx) setIndex(i, "play");
    if (i >= n - 1) { pause(); return false; }
    return true;
  }
  function saveIdx() { if (W.run && !W.run._unsaved) savePrefs({ idx: W.idx }); }
  var saveIdxSoon = U.debounce(saveIdx, 250);
  window.addEventListener("pagehide", saveIdx);
  function setIndex(i, src) {
    if (!W.run) return;
    var n = W.run.samples.cols.t.length; i = Math.max(0, Math.min(n - 1, i | 0)); W.idx = i;
    if (src !== "play") { W.clock = W.run.samples.cols.t[i]; saveIdxSoon(); }
    updateAtIndex(src);
  }
  function updateAtIndex(src) {
    var r = W.run; if (!r) return;
    var i = W.idx, S = r.samples.cols, t = S.t[i], tEnd = S.t[S.t.length - 1];
    var sc = $("pbScrub"); if (String(sc.value) !== String(i)) sc.value = String(i);
    var txt = "t = " + fx(t, 2) + " s of " + fx(r.config.duration_s, 2) + " s";
    sc.setAttribute("aria-valuetext", txt); $("pbTime").textContent = fx(t, 2) + " / " + fx(tEnd, 2) + " s";
    if (W.viewMode === "replay" && W.viewer) {
      W.viewer.setPose(poseAt(r, i));
      $("vwT").textContent = "t = " + fx(t, 2) + " s";
      $("vwTag").innerHTML = '<span class="vtag">' + (W.fresh ? "Simulation" : "Replay") + " · " + esc(r.experiment_id || r.id) + " · " + esc(r.name) + "</span> " + U.badge(r.outcome) + (AERIS_RUNS.customWheels(r) ? ' <span class="vtag">custom set of ' + r.config.wheels.length + " wheels: the view shows the body motion; wheels are not drawn to their axes</span>" : "");
    }
    AERIS_TIMELINE.update($("tl"), t, halfStep(r));
    renderTelemetry(); drawCursors();
    var now = performance.now();
    if (!W.playing || now - W.lastMaths > 250) { renderMaths(false); W.lastMaths = now; }
  }
  function onKey(e) {
    if (e.key === "Escape" && W.placing) { stopPlacing(); live("Placement cancelled."); return; }
    if (e.target.closest("input, select, textarea, [contenteditable]")) return;
    if (!W.run) return;
    var k = e.key;
    if (e.target.closest(".ws-center") || e.target === document.body) {
      if (k === " " || k === "k" || k === "K") { if (e.target.closest("button") && k === " ") return; e.preventDefault(); togglePlay(); }
      else if (k === "," || k === ".") { e.preventDefault(); pause(); setIndex(W.idx + (k === "." ? 1 : -1), "step"); }
      else if (k === "Home" && !e.target.closest('[role="tab"]')) { e.preventDefault(); pause(); setIndex(0, "restart"); }
      else if (k === "End" && !e.target.closest('[role="tab"]')) { e.preventDefault(); pause(); setIndex(W.run.samples.cols.t.length - 1, "end"); }
    }
  }

  /* =================== telemetry =================== */
  function cell(k, u, v, extra) { return '<div class="tc"><div class="tk"><span>' + U.nt(k) + '</span><span class="u">' + (u || "") + '</span></div><div class="tv mono">' + v + "</div>" + (extra || "") + "</div>"; }
  function thousands(x) { return String(Math.round(x)).replace(/\B(?=(\d{3})+(?!\d))/g, ","); }
  /* WHEEL X 7,950 RPM / 8,000 RPM · SATURATION RISK → SATURATED (amber); FAILED (red) */
  function gauge(w, om, wmax, state) {
    var f = Math.min(1, Math.abs(om) / wmax), R = AERIS_TWIN.EVENT_RULES;
    var lab = state === "failed" ? "FAILED" : state === "sat" ? "SATURATED" : state === "risk" ? "SATURATION RISK" : "";
    var ic = state === "failed" ? "✕" : state === "sat" || state === "risk" ? "▲" : "";
    return '<div class="gauge g-' + state + '"><div class="g-h"><span class="g-w">WHEEL ' + w.toUpperCase() + '</span><span class="g-v mono">' + thousands(Math.abs(om) / RPM) + " RPM / " + thousands(wmax / RPM) + " RPM</span>" + (lab ? '<span class="g-s"><i aria-hidden="true">' + ic + "</i> " + lab + "</span>" : "") + "</div>" +
      '<div class="g-bar" aria-hidden="true"><i style="width:' + (f * 100).toFixed(2) + '%"></i><b style="left:' + (R.speedRiskFrac * 100) + '%"></b><b style="left:' + (R.speedLimitFrac * 100) + '%"></b></div></div>';
  }
  function renderTelemetry() {
    var r = W.run, el = $("tele"); if (!r) return;
    var S = r.samples.cols, i = W.idx, c = r.config, d = r.derived, wmax = d.motor.wmax, h = "";
    var act = AERIS_EVENTS.activeAt(AERIS_EVENTS.timelineOf(r), S.t[i], halfStep(r)).filter(function (e) { return e.type !== "termination" && e.type !== "recovered"; });
    var failedNow = (c.events || []).filter(function (e) { return e.type === "wheel_failure" && S.t[i] >= e.t_s && (c.mode === "corner" || e.wheel === "x"); });
    var status = act.map(function (e) { return '<span class="' + (e.severity === "failure" ? "v-bad" : e.severity === "warning" ? "v-warn" : "dim") + '">' + esc(e.label) + "</span>"; });
    failedNow.forEach(function (e) { if (!act.some(function (x) { return x.type === "wheel_failure" && x.wheel === e.wheel; })) status.push('<span class="v-bad">wheel ' + e.wheel.toUpperCase() + " failed</span>"); });
    if (r.metrics.fellAt_s != null && S.t[i] >= r.metrics.fellAt_s - 1e-9 && !act.some(function (e) { return e.type === "fall"; })) status.push('<span class="v-bad">fallen</span>');
    if (!status.length) status.push('<span class="dim">no active events</span>');
    h += cell("Time", "s", fx(S.t[i], 3));
    h += cell("COM lean e", "deg", fx(S.e[i] / DEG, 3));
    if (c.mode === "edge") {
      h += cell("Tilt θ", "deg", fx(S.theta[i] / DEG, 3)) + cell("Rate θ̇", "deg/s", fx(S.thetadot[i] / DEG, 2));
      h += cell("Motor T", "N·m", fx(S.T_x[i], 4) + (Math.abs(S.Tc_x[i] - S.T_x[i]) > 1e-6 ? '<small class="v-warn"> cmd ' + fx(S.Tc_x[i], 3) + "</small>" : ""));
      h += cell("Gravity τ<sub>g</sub>", "N·m", fx(S.tauG[i], 4)) + cell("Load τ<sub>F</sub>", "N·m", fx(S.tauF[i], 4));
    } else {
      h += cell("Tilt from diagonal", "deg", fx(S.geo[i] / DEG, 3)) + cell("Yaw ψ", "deg", fx(S.psi[i] / DEG, 1));
      h += cell("|T|", "N·m", fx(Math.hypot.apply(null, AERIS_RUNS.wheelIds(r).map(function (w) { return S["T_" + w][i]; })), 4)) + cell("|τ<sub>F</sub>|", "N·m", fx(Math.hypot(S.tauF_x[i], S.tauF_y[i], S.tauF_z[i]), 4));
    }
    h += cell("Energy E", "J", fx(S.E[i], 2)) + cell("Events now", "", status.join(" · ")).replace('<div class="tc">', '<div class="tc st">');
    var ws = wheelStates(r, i), wheels = AERIS_RUNS.wheelIds(r), custom = AERIS_RUNS.customWheels(r);
    h += '<div class="gauges">' + wheels.map(function (w, j) { var wm = custom && d.wheels && d.wheels[j] && d.wheels[j].wmax ? d.wheels[j].wmax : wmax; return gauge(w, S["omega_" + w][i], wm, custom ? "ok" : ws[AERIS_TWIN.WHEELS.indexOf(w)]); }).join("") + "</div>";
    el.innerHTML = h;
  }

  /* =================== plots =================== */
  function legendHTML(df) {
    return '<div class="plg" aria-hidden="true">' + df.series.map(function (s) { return '<span><svg width="22" height="8" viewBox="0 0 22 8"><line x1="1" y1="4" x2="21" y2="4" stroke="' + s.color + '" stroke-width="2"' + (s.dash && s.dash.length ? ' stroke-dasharray="' + s.dash.join(" ") + '"' : "") + "/></svg>" + U.nt(esc(s.name)) + "</span>"; }).join("") + "</div>";
  }
  function drawPlots() {
    var r = W.run, box = $("plots"); if (!r) return;
    var defs = AERIS_RUNPLOTS.defs(r); W.plotDefs = defs;
    box.setAttribute("data-run", r.id);
    box.innerHTML = defs.map(function (df) {
      return '<figure class="plot" data-id="' + df.id + '"><figcaption><span class="pt">' + U.nt(esc(df.title)) + ' <span class="u">[' + esc(df.unit) + ']</span></span><span class="pv mono" id="pv-' + df.id + '"></span><button type="button" class="pexp" data-plot="' + df.id + '" aria-label="Export the data of ' + esc(df.title) + ' as CSV">CSV</button></figcaption>' + legendHTML(df) +
        '<div class="pcv"><canvas width="900" height="300" id="pc-' + df.id + '" role="img" aria-label="' + esc(df.title + " against time t in seconds, 0 to " + fx(r.config.duration_s, 1) + " s") + '"></canvas><canvas class="cur" id="pk-' + df.id + '" aria-hidden="true"></canvas><div class="ptip" id="pt-' + df.id + '" hidden></div></div>' + (df.note ? '<p class="pnote">' + U.nt(esc(df.note)) + "</p>" : "") + "</figure>";
    }).join("") +
      '<p class="pnote">Click or drag on a plot to move the playback time; hover for values. Magenta bands: external loads acting. Amber ticks along the top of a plot: torque saturation (upper row) and wheel speed at ≥ 90 % (faint) or ≥ 98 % of its limit (lower row). Markers: settling time t_s, failures, fall. Shared time axis 0–' + fx(r.config.duration_s, 1) + " s (the whole observation window).</p>";
    W.plots = defs.map(function (df) {
      var cv = $("pc-" + df.id), ov = $("pk-" + df.id);
      cv._fixedH = window.innerWidth < 640 ? 170 : 190;
      var map = Chart.line(cv, { xlim: [0, r.config.duration_s], xlabel: "t [s]", ylabel: df.ylabel || "", series: df.series.map(function (s) { return { x: r.samples.cols.t, y: s.y, color: s.color, width: s.width, dash: s.dash }; }), hlines: df.hlines, ybands: df.ybands, vlines: df.vlines, xbands: df.xbands, xstrips: df.xstrips, yzero: df.yzero });
      bindSeek(ov, df);
      return { def: df, cv: cv, ov: ov, map: map };
    });
    box.querySelectorAll(".pexp").forEach(function (b) { b.addEventListener("click", function () { var df = W.plotDefs.filter(function (x) { return x.id === b.getAttribute("data-plot"); })[0]; if (!df || !W.run) return; exportText(String(W.run.experiment_id || W.run.id).replace(/[^a-z0-9-]/gi, "") + "-" + df.id + ".csv", AERIS_RUNPLOTS.toCSV(W.run, df), "text/csv", df.title + " (CSV)"); }); });
    drawCursors();
  }
  function nearestIndex(P, clientX) {
    var rect = P.ov.getBoundingClientRect(), x = clientX - rect.left, m = P.map, t = m.xl[0] + (x - m.pad.l) / m.pw * (m.xl[1] - m.xl[0]);
    var T = W.run.samples.cols.t, lo = 0, hi = T.length - 1; t = Math.max(0, t);
    while (hi - lo > 1) { var mid = (lo + hi) >> 1; if (T[mid] <= t) lo = mid; else hi = mid; }
    return Math.abs(T[hi] - t) < Math.abs(T[lo] - t) ? hi : lo;
  }
  function bindSeek(ov, df) {
    var down = false;
    function plot() { return W.plots.filter(function (p) { return p.ov === ov; })[0]; }
    function seek(e) { var P = plot(); if (!P || !W.run) return; pause(); setIndex(nearestIndex(P, e.clientX), "plot"); }
    function tip(e) {
      var P = plot(), el = $("pt-" + df.id); if (!P || !W.run || !el) return;
      var i = nearestIndex(P, e.clientX), S = W.run.samples.cols, rect = ov.getBoundingClientRect();
      el.innerHTML = '<b class="mono">t = ' + fx(S.t[i], 3) + " s</b>" + P.def.series.map(function (s) { var y = s.y[i]; return '<span><i style="background:' + s.color + '"></i>' + U.nt(esc(s.name)) + ' <span class="mono">' + (isFinite(y) ? fx(y, Math.abs(y) >= 100 ? 0 : Math.abs(y) >= 1 ? 3 : 4) : "—") + "</span> " + esc(df.unit) + "</span>"; }).join("");
      el.hidden = false;
      var x = e.clientX - rect.left, w = el.offsetWidth || 160;
      el.style.left = Math.max(4, Math.min(rect.width - w - 4, x + 12)) + "px"; el.style.top = "6px";
    }
    ov.addEventListener("pointerdown", function (e) { down = true; try { ov.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } seek(e); });
    ov.addEventListener("pointermove", function (e) { if (down) seek(e); if (e.pointerType !== "touch") tip(e); });
    ov.addEventListener("pointerup", function () { down = false; }); ov.addEventListener("pointercancel", function () { down = false; });
    ov.addEventListener("pointerleave", function () { var el = $("pt-" + df.id); if (el) el.hidden = true; });
  }
  function drawCursors() {
    var r = W.run; if (!r) return;
    var i = W.idx, S = r.samples.cols, t = S.t[i], dpr = Math.min(window.devicePixelRatio || 1, 2);
    W.plotCursor = W.plots.length ? { run: r.id, idx: i } : null;
    W.plots.forEach(function (P) {
      var m = P.map, ov = P.ov, w = m.W, h = m.H;
      if (ov.width !== Math.round(w * dpr)) { ov.width = Math.round(w * dpr); ov.height = Math.round(h * dpr); ov.style.height = h + "px"; }
      var g = ov.getContext("2d"); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
      var x = m.X(t); g.strokeStyle = "rgba(255,255,255,.85)"; g.lineWidth = 1; g.beginPath(); g.moveTo(x + 0.5, m.pad.t); g.lineTo(x + 0.5, m.pad.t + m.ph); g.stroke();
      var vals = [];
      P.def.series.forEach(function (s) { var y = s.y[i]; if (!isFinite(y)) return; var py = m.Y(Math.max(m.yl[0], Math.min(m.yl[1], y))); g.fillStyle = s.color; g.beginPath(); g.arc(x, py, 3.2, 0, 7); g.fill(); vals.push('<span><i class="sw" style="background:' + s.color + '"></i>' + esc(s.name) + " " + fx(y, Math.abs(y) >= 100 ? 0 : Math.abs(y) >= 1 ? 2 : 4) + "</span>"); });
      var pv = $("pv-" + P.def.id); if (pv) pv.innerHTML = vals.join(" ");
    });
  }
  function resizeAll() {
    if (!W.inited) return;
    if (W.kind !== "single") return;
    if (W.viewer) W.viewer.resize();
    if (W.run && $("plots").offsetParent) { drawPlots(); }
    if (W.cmpPlots && $("rp-cmp") && !$("rp-cmp").hidden) renderCompare();
  }

  /* =================== results =================== */
  function mrow(k, v, def) { return "<tr><th scope=\"row\">" + k + (def ? ' <button type="button" class="qm" aria-label="Definition of ' + esc(String(k).replace(/<[^>]+>/g, "")) + '" data-def="' + esc(def) + '">?</button>' : "") + "</th><td class=\"mono\">" + v + "</td></tr>"; }
  function srcText(r) { var o = r.origin || {}, eng = AERIS_SCHEMA.ENGINES[o.engine] || o.engine || "unknown engine"; return (W.fresh ? "Simulation, just computed" : "Replay of a saved " + (o.kind === "hardware" ? "hardware recording" : "simulation")) + " · " + eng + (o.engine_version ? " " + o.engine_version : "") + (o.mode ? " · " + String(o.mode).toUpperCase() + " mode" : ""); }
  function groupMembers(r) { if (!r.group || !r.group.id) return []; return AERIS_RUNS.list().filter(function (e) { return e.group && e.group.id === r.group.id; }).map(function (e) { return e.id; }); }
  function renderResults() {
    var el = $("rp-res"); if (!el) return;
    if (W.attempt) {
      el.innerHTML = '<div class="oc bad"><div class="oc-l" data-icon="' + U.icon("invalid") + '">' + esc(W.attempt.outcome.label) + '</div><p class="oc-r">' + esc(W.attempt.outcome.reason) + " Nothing was simulated and no recording was created.</p></div>" +
        (W.attempt.errors.length ? '<h3 class="rh">What to change</h3><ul class="errs">' + W.attempt.errors.map(function (e) { return "<li>" + esc(e.message) + "</li>"; }).join("") + "</ul>" : "") +
        '<p class="dim small">The same checks run on every setup before the controller is designed: parameter ranges, physically consistent combinations (for example wheel inertia against body inertia), geometry, loop rate, and numerical failures during integration.</p>';
      return;
    }
    var r = W.run;
    if (!r) { el.innerHTML = '<p class="ws-empty">No run selected. Results appear here after you run an experiment or open a recording.</p>' + examplesHTML(); bindExamples(el); return; }
    var m = r.metrics, A = r.definitions.assessment, D = r.definitions.metrics, tone = U.tone(r.outcome.code), edge = r.config.mode === "edge", type = r.config.controller.type;
    var a = r.config.params.a, rc = r.derived.rc, dr = Math.hypot(rc[0] - a / 2, rc[1] - a / 2, rc[2] - a / 2);
    var h = '<div class="rid"><span class="xid mono">' + esc(r.experiment_id || r.id) + "</span>" + B.forRecord(r, W.fresh ? "fresh" : "saved") + "</div>";
    h += '<div class="rctl">' + B.controller(type === "lqr" && r.config.controller.structure === "mimo-lqr" ? "lqr-mimo" : type, { long: true }) + '<span class="dim small">' + esc(r.config.mode === "edge" ? "edge balance" : "corner balance") + " · " + fx(r.config.duration_s, 1) + " s window" + (r.group ? " · controller set" : "") + "</span></div>";
    h += '<div class="oc ' + tone + '" id="ocCard"><div class="oc-l" data-icon="' + U.icon(r.outcome.code) + '">' + esc(r.outcome.label) + '</div><p class="oc-r">' + esc(r.outcome.reason) + "</p>" + ((r.outcome.notes || []).length ? '<ul class="oc-n">' + r.outcome.notes.map(function (n) { return "<li>" + esc(n) + "</li>"; }).join("") + "</ul>" : "") + "</div>";
    h += '<details class="how"><summary>How this outcome is decided</summary><ul><li>' + esc(D.lean) + "</li><li>" + esc(D.settle) + "</li><li>" + esc(D.drift) + "</li><li>" + esc(D.fall) + "</li><li>" + esc(D.outcome) + "</li></ul><p class=\"small dim\">These rules were saved with the run.</p></details>";
    h += '<table class="mt"><tbody>';
    h += mrow("Observation window", fx(m.window_s, 2) + " s" + (Math.abs(m.recorded_s - m.window_s) > 1e-6 ? " (recorded to " + fx(m.recorded_s, 2) + " s)" : ""), D.window);
    h += mrow("Settling time t<sub>s</sub>", m.settle_s == null ? '<span class="v-warn">not settled</span>' : fx(m.settle_s, 3) + " s", D.settle);
    h += mrow("Momentum settling t<sub>Ω</sub>", m.tOmega_s == null ? '<span class="dim">not within ±' + A.momentumTolRpm + " rpm</span>" : fx(m.tOmega_s, 3) + " s", D.tOmega);
    h += mrow("Initial COM lean", fx(m.e0_deg, 3) + "°", D.lean);
    h += mrow("Peak COM lean", fx(m.peakLean_deg, 3) + "° at " + fx(m.peakLean_t, 2) + " s", D.peakLean);
    if (m.leanMargin_deg !== undefined) h += mrow("Recovery margin", m.leanMargin_deg == null ? '<span class="v-bad">none (fell)</span>' : fx(m.leanMargin_deg, 2) + "° below the fall threshold", D.leanMargin);
    if (m.rmsLean_deg !== undefined) h += mrow("RMS COM lean", fx(m.rmsLean_deg, 4) + "°", D.rms);
    if (edge) h += mrow("Overshoot", m.overshoot_deg == null ? "—" : fx(m.overshoot_deg, 3) + "°", D.overshoot);
    h += mrow("Final-window lean", fx(m.finalLean_deg, 4) + "° (last " + fx(m.finalWindow_s, 2) + " s)", D.finalLean);
    h += mrow("Peak wheel speed", fx(m.peakOmega_rpm, 0) + " rpm · wheel " + String(m.peakOmega_wheel || "—").toUpperCase() + " · " + fx(m.peakOmega_frac * 100, 0) + " % of limit", D.peakOmega);
    h += mrow("Wheel speed at end", fx(m.endOmega_rpm, 0) + " rpm (" + fx(m.endOmega_frac * 100, 0) + " %)", D.momentum);
    h += mrow("Torque-limited time", fx(m.torqueLimited_s, 3) + " s", D.saturation);
    if (m.speedLimited_s !== undefined) h += mrow("Time at the speed limit", fx(m.speedLimited_s, 3) + " s", D.speedLimited);
    if (m.effort_Nms !== undefined) h += mrow("Control effort ∫Σ|T|dt", sig(m.effort_Nms, 4) + " N·m·s", D.effort);
    h += mrow("Energy", fx(m.energy_J, 3) + " J", D.energy);
    h += mrow("COM shift |Δr<sub>COM</sub>|", fx(dr * 1000, 2) + " mm from the nominal centre", "Distance between this setup's centre of mass and the bare cube's geometric centre (the nominal design COM).");
    if (m.fellAt_s != null) h += mrow("Fell at", fx(m.fellAt_s, 3) + " s" + (r.events && r.events.fallCause ? " (" + (r.events.fallCause === "contact" ? "floor contact" : "lean threshold") + ")" : ""), D.fall);
    if (m.drift) h += mrow("Drift", m.drift.kind === "wheel" ? "wheel " + m.drift.wheel.toUpperCase() + " +" + fx(m.drift.slope_rpm_s, 0) + " rpm/s, R² " + fx(m.drift.r2, 3) + ", limit at ≈" + fx(m.drift.projected_s, 1) + " s" : "lean +" + fx(m.drift.slope_dps, 3) + " °/s", D.drift);
    if (!edge) h += mrow("Yaw at end", fx(m.yawFinal_deg, 1) + "° (" + fx(m.yawRate_dps, 2) + " °/s)", D.yaw);
    h += "</tbody></table>";
    if (r.research) h += researchHTML(r);
    if (r.warnings && r.warnings.length) h += '<div class="vb warn"><b>Setup warnings recorded with this run:</b><ul>' + r.warnings.map(function (w) { return "<li>" + esc(w.message) + "</li>"; }).join("") + "</ul></div>";
    var mem = groupMembers(r);
    if (mem.length > 1) h += '<p class="small">Part of a controller set (' + mem.length + ' runs, same setup). <button type="button" class="act" data-a="cmpset">Compare the set</button></p>';
    h += '<h3 class="rh">This run</h3><div class="ri"><label for="runName" class="sr">Run name</label><input id="runName" value="' + esc(r.name) + '"' + (r._unsaved ? " disabled" : "") + '><dl>' +
      "<dt>Experiment</dt><dd class=\"mono\">" + esc(r.experiment_id || "—") + "</dd><dt>Storage key</dt><dd class=\"mono\">" + esc(r.id) + "</dd><dt>Created</dt><dd>" + esc(new Date(r.created).toLocaleString()) + "</dd>" +
      "<dt>Source</dt><dd>" + esc(srcText(r)) + (r._unsaved ? ' · <span class="v-bad">not saved (storage full)</span>' : "") + "</dd>" +
      "<dt>Model state</dt><dd>" + esc(r.validation ? (AERIS_SCHEMA.VALIDATION[r.validation.status] || {}).label + " · " + (r.validation.parameter_set || "") : "—") + "</dd>" +
      "<dt>Model</dt><dd>" + esc(r.software && r.software.model) + "</dd><dt>Solver</dt><dd>" + esc(r.software && r.software.solver) + "</dd>" +
      "<dt>Time step</dt><dd>" + (r.executed && r.executed.rates ? fx(1000 / r.executed.rates.integration_hz, 3) + " ms integration (" + r.executed.rates.integration_hz + " Hz); control " + r.executed.rates.control_hz + " Hz, IMU " + r.executed.rates.sensor_hz + " Hz" : fx(1000 / r.config.params.fs, 2) + " ms (" + r.config.params.fs + " Hz loop)") + ", recorded at " + r.samples.rate_hz + " Hz</dd><dt>Seed</dt><dd>" + r.config.seed + (r.config.estimator.type === "ideal" ? " (not used: ideal sensing)" : "") + "</dd>" +
      "<dt>Provenance</dt><dd>" + esc(r.provenance) + "</dd>" + (r.note ? "<dt>Note</dt><dd>" + esc(r.note) + "</dd>" : "") + "</dl></div>";
    h += '<div class="acts2"><button type="button" class="act" data-a="json">Export JSON</button><button type="button" class="act" data-a="csv">Export CSV</button><button type="button" class="act" data-a="cfg">Export setup</button><button type="button" class="act" data-a="edit">Edit &amp; re-run</button><button type="button" class="act" data-a="set">Run PID · LQR · Adaptive on this setup</button><button type="button" class="act" data-a="repro">Check reproducibility</button>' + (r._unsaved ? "" : '<button type="button" class="act fail" data-a="del">Delete</button>') + '</div><div id="reproOut" class="small" aria-live="polite"></div>';
    el.innerHTML = h;
    var nm = $("runName"); if (nm) nm.addEventListener("change", function () { var v = nm.value.trim(); if (!v) return; r.name = v; AERIS_RUNS.rename(r.id, v); renderRecordings(); updateAtIndex("rename"); });
    el.querySelectorAll(".qm").forEach(function (b) { b.addEventListener("click", function () { var open = b.nextElementSibling && b.nextElementSibling.classList && b.nextElementSibling.classList.contains("defpop"); el.querySelectorAll(".defpop").forEach(function (x) { x.remove(); }); if (!open) { var p = U.el("span", { cls: "defpop", role: "note", text: b.getAttribute("data-def") }); b.after(p); } }); });
    el.addEventListener("click", function (e) { var b = e.target.closest('[data-a="cmpset"]'); if (!b) return; W.compare = groupMembers(r).slice(0, 4); savePrefs({ compare: W.compare }); W.rightTabs.select("rt-cmp"); renderCompare(); renderRecordings(); });
    el.querySelector(".acts2").addEventListener("click", function (e) {
      var b = e.target.closest("button"); if (!b) return; var a = b.getAttribute("data-a"), base = r.id.replace(/[^a-z0-9-]/gi, "");
      if (a === "json") exportText(base + ".json", AERIS_RUNS.exportJSON(r), "application/json", "Run (JSON)");
      else if (a === "csv") exportText(base + ".csv", AERIS_RUNS.toCSV(r), "text/csv", "Samples (CSV)");
      else if (a === "cfg") exportText(base + "-setup.json", AERIS_RUNS.exportConfig(r.config), "application/json", "Setup (configuration only)");
      else if (a === "edit") { W.draft = CFG.normalize(AERIS_TWIN.clone(r.config)); W.selected = null; buildForm(); AERIS_RUNS.saveDraft(W.draft); W.leftTabs.select("lt-create"); W.mTabs.select("mt-left"); toast("Setup loaded from '" + r.name + "'. Edit it and press Run; the recording itself does not change."); }
      else if (a === "set") { W.draft = CFG.normalize(AERIS_TWIN.clone(r.config)); W.selected = null; buildForm(); AERIS_RUNS.saveDraft(W.draft); runControllerSet(); }
      else if (a === "reanalyze") {
        var mvb = $("mvOld"), outR = $("reproOut");
        if (!AERIS_RUNS.isBackendRecord(r)) { outR.innerHTML = '<span class="v-warn">Only research-backend records have research metrics to reanalyse.</span>'; return; }
        outR.innerHTML = '<span class="dim">Asking the research backend to simulate the saved setup again with metric version 2…</span>';
        SVC.reanalyzeAsync(r).then(function (o) {
          if (!o.ok) { outR.innerHTML = '<span class="v-bad">' + esc(o.message) + "</span>"; return; }
          var s2 = AERIS_RUNS.save(o.record); o.record._unsaved = !s2.ok;
          outR.innerHTML = '<span class="v-ok">New record ' + esc(o.record.experiment_id) + " (lineage: reanalysis of " + esc(r.experiment_id || r.id) + "). The original record is unchanged.</span>";
          renderRecordings();
        });
      }
      else if (a === "repro") {
        var out = $("reproOut"); out.innerHTML = '<span class="dim">' + (AERIS_RUNS.isBackendRecord(r) ? "Asking the research backend to re-run this setup…" : "Re-running…") + "</span>";
        SVC.reproduceAsync(r).then(function (o) {
          if (!o.ok) { out.innerHTML = '<span class="v-bad">' + esc(o.message) + "</span>"; return; }
          if (o.engine === "aeris-research-backend") {
            var chg = (o.configChanges || []).map(function (c) { return c.path + ": " + c.from + " → " + c.to; }).join("; ");
            out.innerHTML = o.identical ? '<span class="v-ok">The research backend re-ran the saved setup (' + esc(o.model) + ") and reproduced every saved sample exactly (new run " + esc(o.record.experiment_id) + ").</span>"
              : o.withinTolerance ? '<span class="v-ok">The research backend re-ran the saved setup (' + esc(o.model) + ") and reproduced every saved sample within the stated tolerance (relative " + sig((o.report.tolerance || {}).relative, 2) + "; largest difference " + sig(o.maxAbsDiff, 3) + ", SI units; new run " + esc(o.record.experiment_id) + ").</span>"
              : '<span class="v-warn">The backend re-run gives ' + (o.sameOutcome ? "the same outcome but" : "outcome '" + esc(o.outcome.label) + "' and") + " samples that differ by up to " + sig(o.maxAbsDiff, 3) + " (absolute, SI units)" + ((o.explanations || []).length ? ". Expected differences: " + esc(o.explanations.join("; ")) : "") + ".</span>";
            if (chg) out.innerHTML += '<br><span class="small">Configuration changed for the reproduction (explicit, recorded with the new run): ' + esc(chg) + "</span>";
            return;
          }
          out.innerHTML = o.identical ? '<span class="v-ok">Re-running the saved setup with ' + esc(o.model) + " reproduces every saved sample exactly.</span>" : '<span class="v-warn">Re-running gives ' + (o.sameOutcome ? "the same outcome but" : "outcome '" + esc(o.outcome.label) + "' and") + " samples that differ by up to " + sig(o.maxRelDiff * 100, 2) + " % (saved with " + esc(r.software && r.software.model) + ", now " + esc(o.model) + ").</span>";
        });
      }
      else if (a === "del") confirmBox("Delete '" + r.name + "' (" + (r.experiment_id || r.id) + ")? The recording is removed from this browser.", "Delete", function () { AERIS_RUNS.remove(r.id); W.compare = W.compare.filter(function (x) { return x !== r.id; }); savePrefs({ compare: W.compare }); clearView("deleted"); renderRecordings(); storageNote(); toast("Recording deleted."); });
    });
  }
  function confirmBox(text, label, fn) { U.modal({ title: "Please confirm", text: text, actions: [{ label: label, primary: true, run: function () { fn(); } }], closeLabel: "Cancel" }); }
  /* exports: a download button plus the text itself, because some viewers block downloads.
     A host can set window.AERIS_ENV: { downloads: false } offers copying only; { save: fn(name, text) -> Promise }
     routes the download through the host (the hosted build uses the viewer's save prompt). */
  function exportText(name, text, mime, what) {
    W.lastExport = { name: name, text: text };
    var env = window.AERIS_ENV || {}, hostSave = typeof env.save === "function" ? env.save : null;
    var dl = !!hostSave || env.downloads !== false, kb = Math.max(1, Math.round(text.length / 1024));
    var copy = { label: "Copy text", primary: !dl, run: function (v, b) { U.copyText(text, function (ok) { b.textContent = ok ? "Copied" : "Copy failed: select the text"; }); return false; } };
    var down = { label: "Download " + name, primary: true, run: function (v, b) {
      if (!hostSave) { var ok = U.download(name, text, mime); b.textContent = ok ? "Download started" : "Download blocked: copy instead"; return false; }
      b.disabled = true; b.textContent = "Confirm the save in the prompt";
      Promise.resolve().then(function () { return hostSave(name, text); }).then(function () { b.textContent = "Download started"; }, function (err) {
        var c = err && err.code;
        if (c === "declined") { b.textContent = "Not saved"; b.disabled = false; }
        else if (c === "rate_limited") { b.textContent = "A save prompt is already open"; b.disabled = false; }
        else { b.textContent = c === "too_large" ? "Too large to save here: copy instead" : "Saving isn't available here: copy instead"; if (env.save === hostSave && c !== "too_large") { env.save = null; env.downloads = false; } }
      });
      return false; } };
    U.modal({ title: "Export · " + what,
      text: name + " · " + kb + " kB. " + (dl ? "Download the file, or copy the text and save it under that name." : "This hosted page can't start downloads. Copy the text and save it as " + name + "."),
      textarea: text.length > 3e6 ? text.slice(0, 3e6) + "\n… (truncated in this preview; " + (dl ? "the download and Copy text include" : "Copy text includes") + " everything)" : text, readonly: true, taLabel: "Exported text", actions: dl ? [down, copy] : [copy] });
  }

  /* =================== recordings =================== */
  function examplesHTML() { return '<div class="exlist"><h3 class="rh">Examples</h3>' + EXAMPLES.map(function (ex) { return '<button type="button" class="exbtn" data-ex="' + ex.id + '"><b><span class="mono xid">' + esc(AERIS_IDS.forExample(ex.id) || "") + "</span> " + esc(ex.name) + "</b><span>" + esc(ex.note) + "</span></button>"; }).join("") + '<p class="small dim">Examples are simulated on this device from fixed setups (AERIS Twin, nominal parameters) and saved to your recordings when opened. ' + B.mark("example") + "</p></div>"; }
  function bindExamples(root) { root.querySelectorAll("[data-ex]").forEach(function (b) { b.addEventListener("click", function () { openExample(b.getAttribute("data-ex")); }); }); }
  function openExample(id) {
    var o = SVC.replay().example(id); if (!o.ok) { toast(o.error); return; }
    var rec = o.record; if (!o.stored && o.saveError) toast(o.saveError);
    if (W.kind !== "single") W.kindTabs.select("wk-single");
    openRun(rec, { autoplay: true }); renderRecordings(); storageNote();
  }
  function renderRecordings() {
    var el = $("lp-rec"); if (!el) return;
    var list = SVC.replay().list(), cnt = $("recCount"); if (cnt) cnt.textContent = String(list.length);
    var h = '<div class="recbar"><button type="button" class="act" id="btnImport">Import…</button><button type="button" class="act" id="btnExportAll"' + (list.length ? "" : " disabled") + '>Export all</button><button type="button" class="act fail" id="btnClearAll"' + (list.length ? "" : " disabled") + ">Delete all</button></div>";
    h += list.length ? '<ul class="reclist">' + list.map(function (e) {
      var on = W.run && W.run.id === e.id, cmp = W.compare.indexOf(e.id) >= 0;
      var marks = (e.collection === "example" ? B.mark("example") : "") + (e.collection === "imported" ? '<span class="bdg mk-imported"><i aria-hidden="true"></i>IMPORTED</span>' : "") + (e.origin && e.origin.engine === "mock-research-backend" ? B.mark("mockData") : "") + (e.group ? '<span class="bdg mk-set"><i aria-hidden="true"></i>SET</span>' : "");
      return '<li class="rec' + (on ? " on" : "") + '"><button type="button" class="rec-open" data-id="' + esc(e.id) + '"' + (on ? ' aria-current="true"' : "") + '><span class="rn">' + esc(e.name) + '</span><span class="rm"><span class="mono xid">' + esc(e.experiment_id || "—") + "</span> · " + esc(e.mode) + " · " + B.controller(e.controller) + " · " + fx(e.duration_s, 1) + " s · " + esc(new Date(e.created).toLocaleDateString()) + "</span>" + (marks ? '<span class="rmk">' + marks + "</span>" : "") + U.badge({ code: e.outcome, label: e.label || e.outcome }) + "</button>" +
        '<label class="rc"><input type="checkbox" data-cmp="' + esc(e.id) + '"' + (cmp ? " checked" : "") + '><span>Compare</span></label></li>';
    }).join("") + "</ul>" : '<p class="ws-empty">No recordings yet. Runs you create are saved here automatically.</p>';
    h += examplesHTML();
    el.innerHTML = h;
    bindExamples(el);
    el.querySelectorAll(".rec-open").forEach(function (b) { b.addEventListener("click", function () { var l = SVC.replay().load(b.getAttribute("data-id")); if (!l.ok) { toast(l.error); return; } openRun(l.record, {}); }); });
    el.querySelectorAll("[data-cmp]").forEach(function (c) { c.addEventListener("change", function () { var id = c.getAttribute("data-cmp"); if (c.checked) { if (W.compare.length >= 4) { c.checked = false; toast("Compare up to four runs at a time."); return; } W.compare.push(id); } else W.compare = W.compare.filter(function (x) { return x !== id; }); savePrefs({ compare: W.compare }); if (W.rightTabs.current() === "rt-cmp") renderCompare(); }); });
    $("btnImport").addEventListener("click", importDialog);
    $("btnExportAll").addEventListener("click", function () { var recs = AERIS_RUNS.list().map(function (e) { return AERIS_RUNS.load(e.id); }).filter(function (x) { return x.ok; }).map(function (x) { return x.record; }); exportText("aeris-recordings.json", AERIS_RUNS.exportJSON(recs), "application/json", "All recordings (JSON)"); });
    $("btnClearAll").addEventListener("click", function () { confirmBox("Delete all " + list.length + " recordings from this browser? Export them first if you want to keep them.", "Delete all", clearAll); });
  }
  function clearAll() {
    AERIS_RUNS.clearAll(); W.compare = []; savePrefs({ compare: [] });
    clearView("cleared"); renderRecordings(); renderCompare(); storageNote(); toast("All recordings deleted.");
  }
  function importDialog() {
    var body = U.el("div", { cls: "imp" }), fi = U.el("input", { type: "file", accept: ".json,application/json", id: "impFile", "aria-label": "Choose a JSON file" });
    body.appendChild(U.el("label", { "for": "impFile", cls: "small", text: "Choose a run, bundle or setup exported from this site (.json), or paste its text below. Hardware recordings (aeris-hardware-run/1) are imported on the Validation page." })); body.appendChild(fi);
    var out = U.el("div", { cls: "imp-out", "aria-live": "polite" });
    var m = U.modal({ title: "Import recordings or a setup", textarea: "", taLabel: "Paste JSON here", body: body, actions: [{ label: "Import pasted text", primary: true, run: function (v) { doImport(v, out); return false; } }] });
    m.box.appendChild(out);
    fi.addEventListener("change", function () { var f = fi.files && fi.files[0]; if (!f) return; var rd = new FileReader(); rd.onload = function () { doImport(String(rd.result), out); }; rd.onerror = function () { out.innerHTML = '<p class="v-bad">The file could not be read.</p>'; }; rd.readAsText(f); });
  }
  function doImport(text, out) {
    var res = AERIS_RUNS.parseImport(text), h = "";
    if (res.configs.length) { W.draft = res.configs[0]; W.selected = null; buildForm(); AERIS_RUNS.saveDraft(W.draft); h += '<p class="v-ok">Setup loaded into “Create experiment”. Press Run to simulate it.</p>'; }
    if (res.runs.length) { var r = AERIS_RUNS.importRuns(res.runs); h += '<p class="v-ok">Imported ' + r.added.length + " run" + (r.added.length === 1 ? "" : "s") + (r.skipped.length ? "; " + r.skipped.length + " already present" : "") + (r.failed.length ? '; <span class="v-bad">' + r.failed.length + " could not be saved: " + esc(r.failed[0].error) + "</span>" : "") + ".</p>"; if (r.added.length) openRun(r.added[0], {}); renderRecordings(); storageNote(); }
    if (res.warnings.length) h += '<div class="vb warn"><ul>' + res.warnings.map(function (w) { return "<li>" + esc(w) + "</li>"; }).join("") + "</ul></div>";
    if (res.errors.length) h += '<div class="vb err"><b>Not imported:</b><ul>' + res.errors.slice(0, 12).map(function (e) { return "<li>" + esc(e) + "</li>"; }).join("") + (res.errors.length > 12 ? "<li>… " + (res.errors.length - 12) + " more</li>" : "") + "</ul></div>";
    out.innerHTML = h || '<p class="dim">Nothing to import.</p>';
    W.lastImport = res;
  }

  /* =================== maths =================== */
  function renderMaths(full) {
    var el = $("rp-math"); if (!el) return;
    if (el.hidden && !full) { W.mathsDirty = true; return; }
    if (full || W.mathsDirty || el._run !== (W.run && W.run.id)) { WSMaths.render(el, W.run, W.idx); W.mathsDirty = false; }
    else WSMaths.update(el, W.run, W.idx);
    el._idx = W.idx;
  }

  /* =================== compare =================== */
  /* one controller per run → controller colours and marker shapes; otherwise neutral inks by letter */
  function compareStyles(recs) {
    var types = recs.map(function (r) { return r.config.controller.type; }), byCtl = types.every(function (t, i) { return types.indexOf(t) === i; });
    return recs.map(function (r, i) {
      if (byCtl) { var c = TK.controller(r.config.controller.type); return { color: c.color, dash: [], marker: c.marker, glyph: c.glyph, byController: true }; }
      return { color: NEUTRAL[i].color, dash: NEUTRAL[i].dash, marker: null, glyph: null, byController: false };
    });
  }
  function swatch(st) { return '<svg class="cmp-sw" width="26" height="10" viewBox="0 0 26 10" aria-hidden="true"><line x1="1" y1="5" x2="25" y2="5" stroke="' + st.color + '" stroke-width="2"' + (st.dash.length ? ' stroke-dasharray="' + st.dash.join(" ") + '"' : "") + "/>" + (st.marker ? markerSVG(st.marker, 13, 5, st.color) : "") + "</svg>"; }
  function markerSVG(shape, x, y, c) { if (shape === "square") return '<rect x="' + (x - 3.4) + '" y="' + (y - 3.4) + '" width="6.8" height="6.8" fill="' + c + '" stroke="#0b0c0e" stroke-width="1.5"/>'; if (shape === "triangle") return '<path d="M' + x + " " + (y - 4.2) + " L" + (x + 4) + " " + (y + 3.2) + " L" + (x - 4) + " " + (y + 3.2) + ' Z" fill="' + c + '" stroke="#0b0c0e" stroke-width="1.5"/>'; if (shape === "diamond") return '<path d="M' + x + " " + (y - 4.4) + " L" + (x + 4.4) + " " + y + " L" + x + " " + (y + 4.4) + " L" + (x - 4.4) + " " + y + ' Z" fill="' + c + '" stroke="#0b0c0e" stroke-width="1.5"/>'; return '<circle cx="' + x + '" cy="' + y + '" r="3.8" fill="' + c + '" stroke="#0b0c0e" stroke-width="1.5"/>'; }
  function renderCompare() {
    var el = $("rp-cmp"); if (!el) return;
    var recs = W.compare.map(function (id) { var l = SVC.replay().load(id); return l.ok ? l.record : null; }).filter(Boolean);
    var h = '<p class="small dim">Tick <b>Compare</b> next to up to four recordings (Recordings tab), or use <b>Run PID · LQR · Adaptive</b> to run one setup with each controller. Plots share units and a time axis from 0 to the longest observation window.</p>';
    if (recs.length < 2) { el.innerHTML = h + '<p class="ws-empty">' + (recs.length ? "One run selected. Select at least one more." : "No runs selected.") + "</p>"; W.cmpPlots = null; return; }
    var st = compareStyles(recs), L = "ABCD", ctlSet = AERIS_COMPARE.isControllerSet(recs);
    var diffs = {}, keys = [];
    recs.forEach(function (a, i) { recs.forEach(function (b, j) { if (j <= i) return; AERIS_ASSISTANT.configDiff(a.config, b.config).forEach(function (d) { if (!diffs[d.key]) { diffs[d.key] = d.label; keys.push(d.key); } }); }); });
    function val(r, k) { var v = k.split(".").reduce(function (o, p) { return o == null ? o : o[p]; }, r.config); return v === undefined ? "—" : typeof v === "object" && v !== null ? (Array.isArray(v) ? (v.length ? v.length + " item" + (v.length > 1 ? "s" : "") : "none") : JSON.stringify(v)) : String(v); }
    function head(r, i) { return '<th scope="col">' + swatch(st[i]) + L[i] + "</th>"; }
    h += '<ul class="cmp-legend">' + recs.map(function (r, i) { return "<li>" + swatch(st[i]) + "<b>" + L[i] + '</b> <span class="mono xid">' + esc(r.experiment_id || r.id) + "</span> " + B.controller(r.config.controller.type) + " " + esc(r.name) + "</li>"; }).join("") + "</ul>";
    if (ctlSet) h += '<p class="small cmp-set">' + B.role("independent") + " Controller set: the same setup run with " + recs.map(function (r) { return AERIS_CONTROLLERS.name(r.config.controller.type); }).join(", ") + ". Only the controller differs, so differences below come from the controller, for this setup and these nominal parameters.</p>";
    h += '<h3 class="rh">Conditions that differ</h3><div class="tblx"><table class="ct"><thead><tr><th scope="col">Condition</th>' + recs.map(head).join("") + "</tr></thead><tbody>";
    h += keys.length ? keys.map(function (k) { return "<tr><th scope=\"row\">" + esc(diffs[k]) + "</th>" + recs.map(function (r) { return "<td>" + esc(val(r, k)) + "</td>"; }).join("") + "</tr>"; }).join("") : '<tr><td colspan="' + (recs.length + 1) + '">No setup differences.</td></tr>';
    h += "</tbody></table></div>";
    var M = [["Outcome", function (r) { return U.badge(r.outcome); }], ["Settling t<sub>s</sub> [s]", function (r) { return r.metrics.settle_s == null ? "not settled" : fx(r.metrics.settle_s, 3); }], ["Peak COM lean [°]", function (r) { return fx(r.metrics.peakLean_deg, 3); }], ["Recovery margin [°]", function (r) { return r.metrics.leanMargin_deg == null ? (r.metrics.leanMargin_deg === null ? "none (fell)" : "—") : fx(r.metrics.leanMargin_deg, 2); }], ["RMS COM lean [°]", function (r) { return fx(r.metrics.rmsLean_deg, 4); }], ["Final-window lean [°]", function (r) { return fx(r.metrics.finalLean_deg, 4); }], ["Peak wheel speed [rpm]", function (r) { return fx(r.metrics.peakOmega_rpm, 0) + " (" + fx(r.metrics.peakOmega_frac * 100, 0) + " %)"; }], ["Torque-limited [s]", function (r) { return fx(r.metrics.torqueLimited_s, 3); }], ["Control effort [N·m·s]", function (r) { return r.metrics.effort_Nms == null ? "—" : sig(r.metrics.effort_Nms, 4); }], ["Energy [J]", function (r) { return fx(r.metrics.energy_J, 3); }], ["Fell at [s]", function (r) { return r.metrics.fellAt_s == null ? "—" : fx(r.metrics.fellAt_s, 3); }], ["Window [s]", function (r) { return fx(r.metrics.window_s, 2); }]];
    h += '<h3 class="rh">Outcomes and metrics</h3><div class="tblx"><table class="ct"><thead><tr><th scope="col">Metric</th>' + recs.map(head).join("") + "</tr></thead><tbody>" + M.map(function (row) { return "<tr><th scope=\"row\">" + row[0] + "</th>" + recs.map(function (r) { return "<td>" + row[1](r) + "</td>"; }).join("") + "</tr>"; }).join("") + "</tbody></table></div>";
    // research metrics (research-backend records), with their definition version: values of different versions are
    // not comparable, and version-1 ISE (rad²·s labelled deg²·s) is withheld rather than shown next to version 2
    if (recs.some(function (r) { return r.research; })) {
      var mvs = recs.map(function (r) { return AERIS_RUNS.metricsVersion(r); }), vset = mvs.filter(function (v, i) { return v && mvs.indexOf(v) === i; });
      var ae = function (r) { return (r.research && r.research.attitude_error) || null; };
      var RM = [["Metric definitions", function (r, mv) { return mv ? (mv === "1" ? '<span class="v-warn">version 1 (pre-v5)</span>' : "version " + esc(mv)) : '<span class="dim">browser run: legacy metrics only</span>'; }],
        ["Research recovery", function (r) { var rc = r.research && r.research.recovery; return !rc ? "—" : rc.recovered ? "at " + fx(rc.first_recovery_s != null ? rc.first_recovery_s : rc.t_s, 3) + " s" + (rc.sustained === false ? ' <span class="v-warn">not sustained</span>' : "") : "not met"; }],
        ["Attitude error RMS [°]", function (r) { var a = ae(r); return a && isFinite(a.rms) ? fx(a.rms, 3) : "—"; }],
        ["Attitude error IAE [°·s]", function (r) { var a = ae(r); return a && isFinite(a.iae) ? sig(a.iae, 4) : "—"; }],
        ["Attitude error ISE [°²·s]", function (r, mv) { var a = ae(r); if (!a || !isFinite(a.ise)) return "—"; return mv === "1" ? '<span class="v-warn">withheld (version 1: rad²·s labelled °²·s)</span>' : sig(a.ise, 4); }]];
      h += '<h3 class="rh">Research metrics (research backend)</h3>' + (vset.length > 1 ? '<p class="small v-warn" id="cmpMv">These runs carry research metrics of different definition versions (' + vset.map(esc).join(", ") + "); values of different versions are not comparable. Reanalyse the older runs (Results → Reanalyse).</p>" : "") +
        '<div class="tblx"><table class="ct" id="cmpResearch"><thead><tr><th scope="col">Metric</th>' + recs.map(head).join("") + "</tr></thead><tbody>" + RM.map(function (row) { return "<tr><th scope=\"row\">" + row[0] + "</th>" + recs.map(function (r, i) { return "<td>" + row[1](r, mvs[i]) + "</td>"; }).join("") + "</tr>"; }).join("") + "</tbody></table></div>";
    }
    var labels = AERIS_COMPARE.labels(recs);
    h += '<h3 class="rh">Computed labels</h3><ul class="cmp-labels">' + labels.map(function (lb) {
      if (!lb.winners.length) return '<li><b>' + esc(lb.label) + '</b> <span class="dim">— not comparable: ' + esc(lb.reason) + "</span></li>";
      return "<li><b>" + esc(lb.label) + "</b>" + (lb.tie ? ' <span class="dim">(tie)</span>' : "") + ": " + lb.winners.map(function (i) { return swatch(st[i]) + L[i] + ' <span class="mono xid">' + esc(recs[i].experiment_id || recs[i].id) + "</span> " + B.controller(recs[i].config.controller.type); }).join(", ") + ' · <span class="mono">' + esc(String(lb.value)) + " " + esc(lb.unit) + "</span>" + (lb.excluded.length ? ' <span class="dim small">(' + lb.excluded.map(function (i) { return L[i]; }).join(", ") + " not eligible)</span>" : "") + '<br><span class="small dim">' + esc(lb.why) + "</span></li>";
    }).join("") + '</ul><p class="small dim">Each label names the best run on one metric only. There is no overall winner: these metrics trade off against each other, and a different setup can reverse them.</p>';
    var modes = recs.map(function (r) { return r.config.mode; }).filter(function (v, i, a) { return a.indexOf(v) === i; });
    h += '<figure class="plot"><figcaption><span class="pt">COM lean e <span class="u">[°]</span></span></figcaption><canvas id="cmpA" width="900" height="300" role="img" aria-label="COM lean of the compared runs against time"></canvas></figure><figure class="plot"><figcaption><span class="pt">Fastest wheel |<span class="nt">Ω</span>| <span class="u">[rpm]</span></span></figcaption><canvas id="cmpB" width="900" height="300" role="img" aria-label="Fastest wheel speed of the compared runs against time"></canvas></figure><figure class="plot"><figcaption><span class="pt">Motor torque magnitude |T| <span class="u">[N·m]</span></span></figcaption><canvas id="cmpC" width="900" height="300" role="img" aria-label="Motor torque magnitude of the compared runs against time"></canvas></figure>';
    h += '<div class="caveat"><p>' + (keys.length === 0 ? "The setups are identical." : keys.length === 1 ? "Exactly one condition differs, so the difference in results can be attributed to it (for these nominal parameters)." : keys.length + " conditions differ, so no single one of them can be credited with the difference in results.") + (modes.length > 1 ? " Edge runs report a signed lean, corner runs an unsigned one." : "") + "</p><p>These are simulations with nominal parameters. They show how these particular runs behave; they do not show that one controller is better in general.</p></div>";
    el.innerHTML = h;
    var tmax = Math.max.apply(null, recs.map(function (r) { return r.config.duration_s; }));
    function ser(f) { return recs.map(function (r, i) { var S = r.samples.cols; return { x: S.t, y: S.t.map(function (_, k) { return f(r, S, k); }), color: st[i].color, width: 2, dash: st[i].dash, marker: st[i].marker, markerOffset: 16 + i * 26 }; }); }
    var H = window.innerWidth < 640 ? 170 : 190;
    [["cmpA", "e [°]", function (r, S, k) { return S.e[k] / DEG; }], ["cmpB", "|Ω| [rpm]", function (r, S, k) { return Math.max.apply(null, AERIS_RUNS.wheelIds(r).map(function (w) { return Math.abs(S["omega_" + w][k]); })) / RPM; }], ["cmpC", "|T| [N·m]", function (r, S, k) { return Math.hypot.apply(null, AERIS_RUNS.wheelIds(r).map(function (w) { return S["T_" + w][k]; })); }]].forEach(function (p) { var cv = $(p[0]); cv._fixedH = H; Chart.line(cv, { xlim: [0, tmax], xlabel: "t [s]", ylabel: p[1], series: ser(p[2]), yzero: true }); });
    W.cmpPlots = true;
  }

  /* =================== assistant =================== */
  function renderAssistant() {
    var el = $("rp-ask"); if (!el) return;
    var connected = AERIS_ASSISTANT.connected;
    var h = '<div class="as-head"><span class="as-badge' + (connected ? " on" : "") + '">' + (connected ? "Connected: " + esc(AERIS_ASSISTANT.serviceName || "AI service") : "Local explanations · no AI service connected") + "</span>" +
      '<p class="small dim">' + (connected ? "Questions and this run's data are sent to the configured service. Numbers it quotes that are not in this run's data are highlighted." : "Answers are assembled on this device by fixed rules from the selected run's saved data. They are not written by an AI model and they never compute new values.") + "</p></div>";
    h += '<div class="as-q" role="group" aria-label="Suggested questions">' + AERIS_ASSISTANT.QUESTIONS.map(function (q) { return '<button type="button" class="chipbtn" data-q="' + q.id + '">' + esc(q.text) + "</button>"; }).join("") + "</div>";
    h += '<div class="as-eq"><label for="asEq" class="small">Equation for “What does this equation mean?”</label><select id="asEq">' + Object.keys(AERIS_ASSISTANT.EQUATIONS).map(function (k) { return '<option value="' + k + '">' + esc(AERIS_ASSISTANT.EQUATIONS[k].name) + "</option>"; }).join("") + "</select></div>";
    h += '<form class="as-form" id="asForm"><label for="asIn" class="sr">Ask a question</label><input id="asIn" placeholder="Ask about this run…" autocomplete="off"><button type="submit" class="btn btn-sm">Ask</button></form><div id="asOut" class="as-out" aria-live="polite">' + (W.run ? "" : '<p class="dim">Open or create a run first; the explanations use its saved data only.</p>') + "</div>";
    el.innerHTML = h;
    el.querySelectorAll("[data-q]").forEach(function (b) { b.addEventListener("click", function () { ask(b.textContent, b.getAttribute("data-q")); }); });
    $("asForm").addEventListener("submit", function (e) { e.preventDefault(); var v = $("asIn").value.trim(); if (v) ask(v, null); });
  }
  function ask(q, intent) {
    var out = $("asOut"); if (!out) return;
    var recs = W.compare.map(function (id) { var l = AERIS_RUNS.load(id); return l.ok ? l.record : null; }).filter(Boolean);
    out.innerHTML = '<p class="dim">Working…</p>';
    var askedRun = W.run;
    AERIS_ASSISTANT.answer(q, W.run, W.idx, { intent: intent, compare: recs, equation: $("asEq") ? $("asEq").value : "dyn" }).then(function (a) {
      if (!out.isConnected || W.run !== askedRun) return;     // another run was opened meanwhile: this answer is not about it
      out.innerHTML = '<div class="as-a"><p class="as-qq">' + esc(q) + "</p>" + a.html + '<p class="as-src">' + (a.source === "service" ? "Source: " + esc(a.service) + " (external AI service)" : "Source: local rules applied to " + (W.run ? "'" + esc(W.run.name) + "' (" + esc(W.run.experiment_id || W.run.id) + ") at t = " + fx(W.run.samples.cols.t[W.idx], 2) + " s" : "no run")) + (a.note ? " · " + esc(a.note) : "") + "</p></div>";
    });
  }

  /* =================== public: open a setup from elsewhere (Twin page, home, sweeps) =================== */
  function openConfig(cfg, opts) {
    init(); opts = opts || {};
    if (W.kind !== "single") W.kindTabs.select("wk-single");
    W.draft = CFG.normalize(cfg); W.selected = null; buildForm(); AERIS_RUNS.saveDraft(W.draft);
    if (opts.run) runDraft(); else { W.leftTabs.select("lt-create"); setViewMode("setup"); }
  }
  function debug() {
    var r = W.run, i = W.idx, tele = $("tele") && $("tele").querySelector(".tv");
    return { runId: r ? r.id : null, experimentId: r ? r.experiment_id || null : null, idx: i, t: r ? r.samples.cols.t[i] : null, viewMode: W.viewMode, playing: W.playing, viewer: W.viewer ? W.viewer.snapshot() : null, teleT: tele ? tele.textContent : null, scrub: +$("pbScrub").value, mathsT: $("rp-math") && !$("rp-math").hidden ? (($("mxT") || {}).textContent || null) : "hidden", mathsRun: ($("rp-math") || {})._run || null, outcome: r ? r.outcome.code : W.attempt ? "invalid" : null, plots: W.plots.length, plotsRun: ($("plots") && $("plots").getAttribute("data-run")) || null, plotCursor: W.plotCursor || null, viewGen: W.viewGen, previewPending: previewTimer.pending(), tag: ($("vwTag") || {}).textContent || "", vwT: ($("vwT") || {}).textContent || "", tlT: ($("tl") && $("tl").getAttribute("data-t")) || null, tlRun: ($("tl") && $("tl").getAttribute("data-run")) || null, compare: W.compare.slice(), lastExport: W.lastExport ? W.lastExport.name : null, kind: W.kind, mode: SVC.getMode(), fresh: W.fresh, events: r ? AERIS_EVENTS.timelineOf(r).events.length : 0, busy: W.busy };
  }
  window.AERIS_DEBUG = { snapshot: debug, setIndex: function (i) { pause(); setIndex(i, "debug"); }, seekTime: seekTime, advanceBy: function (dt) { if (!W.run) return false; return advanceBy(dt); }, W: W, lastExportText: function () { return W.lastExport ? W.lastExport.text : null; }, doImport: function (t) { var o = U.el("div"); doImport(t, o); return o.textContent; }, openExample: openExample, runControllerSet: runControllerSet };
  return { init: init, show: show, openConfig: openConfig, openExample: openExample, EXAMPLES: EXAMPLES, exampleRecord: exampleRecord, resize: resizeAll, openRun: function (rec, o) { init(); openRun(rec, o || {}); renderRecordings(); } };
})();

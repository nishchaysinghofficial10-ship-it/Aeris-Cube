/* =====================================================================
   AERIS TWIN · BROWSER ENGINE  —  physics, validation, controller design, simulation
   and the single outcome assessment used everywhere on the site.

   Everything here runs on NOMINAL parameters until the model is validated
   against measurements from the physical cube. Nothing in this file is a
   hardware measurement.
   ===================================================================== */
var AERIS_TWIN = (function () {
  "use strict";
  var DEG = Math.PI / 180, RPM = Math.PI / 30;

  var VERSION = {
    model: "aeris-twin 0.3.0",
    modelNotes: "Rigid bodies pivoting on an ideal edge (hinge) or corner (point); point-mass attachments and a 3-D base COM shift; BLDC current/back-EMF torque limits scaled by wheel health; optional first-order motor torque lag; viscous + smoothed Coulomb wheel friction; edge-mode IMU model with noise, bias, bias walk, quantisation, latency and packet dropout (corner mode: ideal state feedback).",
    solver: "Fixed-step RK4 at dt = 1/f_s; controller output held constant over each step (zero-order hold)",
    config: "aeris-config/1",
    run: "aeris-run/1"
  };

  /* ---------------- nominal parameters (design values, not measured) ---------------- */
  var NOMINAL = {
    a: 0.18, m: 1.80, kJ: 0.20, Jw: 5.0e-4, g: 9.81, KV: 500, R: 0.40, Vs: 11.1, Imax: 8.0,
    wmaxRpm: 5000, cv: 1.0e-5, cc: 2.0e-3, fs: 500, rImu: 0.09
  };
  /* single source of truth for labels, units and individual ranges */
  var PARAM_SPEC = {
    a: { label: "Edge length", unit: "m", min: 0.05, max: 0.5 },
    m: { label: "Base mass (frame, wheels, electronics)", unit: "kg", min: 0.2, max: 10 },
    kJ: { label: "Body inertia factor k_J (J_c = k_J·m·a²)", unit: "–", min: 0.05, max: 0.5 },
    Jw: { label: "Wheel spin inertia J_w", unit: "kg·m²", min: 1e-6, max: 0.05 },
    g: { label: "Gravity", unit: "m/s²", min: 0.5, max: 25 },
    KV: { label: "Motor velocity constant K_V", unit: "rpm/V", min: 20, max: 5000 },
    R: { label: "Phase resistance", unit: "Ω", min: 0.01, max: 20 },
    Vs: { label: "Supply voltage", unit: "V", min: 1, max: 60 },
    Imax: { label: "Driver current limit", unit: "A", min: 0.1, max: 60 },
    wmaxRpm: { label: "Wheel speed limit", unit: "rpm", min: 100, max: 30000 },
    cv: { label: "Viscous wheel friction", unit: "N·m·s/rad", min: 0, max: 0.01 },
    cc: { label: "Coulomb wheel friction", unit: "N·m", min: 0, max: 0.1 },
    fs: { label: "Control loop rate", unit: "Hz", min: 50, max: 5000 },
    rImu: { label: "IMU distance from pivot", unit: "m", min: 0, max: 0.5 }
  };
  var WEIGHTS = { th: 1 * DEG, thd: 20 * DEG, ww: 40, psi: 5 * DEG, psid: 30 * DEG, pint: -3, pinty: -1, gam: 2e-4 };
  var SENSOR = { sg: 0.16 * DEG, b0: 0.5 * DEG, sbw: 0.002 * DEG, sa: 0.047 / 9.81, Rkf: 2.0 * DEG, tauCf: 0.5 };
  /* configurable sensor and actuator models; the defaults reproduce the fixed v0.2 model exactly.
     The estimators stay tuned for the nominal sensor (SENSOR): changing the simulated sensor tests
     the estimator under a modelling mismatch, as on real hardware. */
  var SENSOR_DEFAULTS = { gyro_noise_dps: 0.16, gyro_bias_dps: 0.5, gyro_bias_walk_dps: 0.002, accel_noise_mps2: 0.047, gyro_quant_dps: 0, accel_quant_deg: 0, latency_ms: 0, dropout: 0, rate_hz: null };
  var SENSOR_SPEC = {
    gyro_noise_dps: { label: "Gyro noise (1σ per sample)", unit: "°/s", min: 0, max: 5, tier: "basic" },
    gyro_bias_dps: { label: "Gyro bias at start", unit: "°/s", min: -10, max: 10, tier: "advanced" },
    gyro_bias_walk_dps: { label: "Gyro bias random walk", unit: "°/s/√s", min: 0, max: 1, tier: "expert" },
    accel_noise_mps2: { label: "Accelerometer noise (1σ)", unit: "m/s²", min: 0, max: 2, tier: "basic" },
    gyro_quant_dps: { label: "Gyro quantisation step", unit: "°/s", min: 0, max: 1, tier: "expert" },
    accel_quant_deg: { label: "Accelerometer angle quantisation", unit: "°", min: 0, max: 2, tier: "expert" },
    latency_ms: { label: "Measurement latency", unit: "ms", min: 0, max: 200, tier: "advanced" },
    dropout: { label: "Packet dropout probability", unit: "–", min: 0, max: 0.9, tier: "advanced" }
  };
  var ACTUATOR_DEFAULTS = { motor_lag_ms: 0, wheel_health: { x: 1, y: 1, z: 1 } };

  /* one set of assessment rules for every run on the site */
  var ASSESS = {
    settleTolDeg: 0.25,        // |e| band for settling / recovery (reference e = 0: COM above the pivot)
    holdMinS: 0.5,             // the band must hold at least this long before the window ends
    momentumTolRpm: 50,        // wheel-momentum settling band
    fallEdgeDeg: 30, fallCornerDeg: 20,             // COM lean beyond which the run is 'Fallen'
    contactEdgeDeg: 45,        // edge mode: a face touches the floor at |θ| = 45°
    contactCornerDeg: 35.2644, // corner mode: smallest tilt (toward an edge) at which an edge touches; the simulator uses the exact test min(u_B) ≤ 0
    cornerEdgeClearWarnDeg: 10,
    finalWindowMaxS: 1.0, finalWindowFrac: 0.25,    // final window for the mean-lean metric
    driftWindowMinS: 0.5, driftWindowMaxS: 2.0, driftWindowFrac: 0.25,
    driftWheelSlopeFrac: 0.005, // of Ω_max per second (0.5 %/s = 25 rpm/s at 5000 rpm)
    driftLeanSlopeDps: 0.05,
    driftR2: 0.9, driftPersist: 0.8,
    satSpeedFrac: 0.98
  };
  var OUTCOMES = {
    recovered: { label: "Recovered", tone: "ok" },
    not_settled: { label: "Not settled within the observation window", tone: "warn" },
    drifting: { label: "Drifting", tone: "warn" },
    fallen: { label: "Fallen", tone: "bad" },
    invalid: { label: "Invalid configuration", tone: "bad" }
  };
  var METRIC_DEFS = {
    lean: "COM lean e: angle between the pivot-to-centre-of-mass vector and the upward vertical. e = 0 means the centre of mass is directly above the pivot. Edge mode: signed, about the support edge. Corner mode: unsigned 3-D angle.",
    window: "Observation window: from t = 0 to the end of the recorded run.",
    settle: "Settling time t_s: the earliest time after which |e| stays within ±" + ASSESS.settleTolDeg + "° for the rest of the observation window, provided that final interval lasts at least " + ASSESS.holdMinS + " s. Reported as 'not settled' otherwise; never the end of the run.",
    tOmega: "Momentum settling time t_Ω: the earliest time after which every active wheel stays within ±" + ASSESS.momentumTolRpm + " rpm for the rest of the window (same " + ASSESS.holdMinS + " s hold).",
    finalLean: "Final-window lean: mean |e| over the last min(" + ASSESS.finalWindowMaxS + " s, " + (ASSESS.finalWindowFrac * 100) + " % of the window).",
    overshoot: "Overshoot (edge mode, initial |e| above the band): largest excursion of e past zero on the opposite side from the initial lean.",
    peakLean: "Peak lean: largest |e| in the window.",
    peakOmega: "Peak wheel speed: largest |Ω| of any wheel, also as a percentage of the speed limit.",
    saturation: "Torque-limited time: total time the commanded motor torque exceeded what the driver could deliver at that wheel speed.",
    energy: "Energy: electrical energy drawn by the motors, ∫ max(0, i²R + TΩ) dt over all wheels (no regeneration credit).",
    fall: "Fallen: COM lean exceeded " + ASSESS.fallEdgeDeg + "° (edge) or " + ASSESS.fallCornerDeg + "° (corner), or part of the cube touched the floor (edge mode: |θ| ≥ " + ASSESS.contactEdgeDeg + "°; corner mode: one of the three edges meeting at the pivot reaches the floor). Motors stop after a fall and the recording continues for up to 1.5 s or until floor contact.",
    momentum: "Momentum margin: how close the fastest wheel ends to its speed limit. A wheel near its limit cannot absorb another disturbance in the same direction.",
    yaw: "Yaw (corner mode): rotation about the balance axis, measured from the attitude at t = 0. The yaw error is measured against the commanded yaw.",
    drift: "Drifting: over the final " + ASSESS.driftWindowMinS + "–" + ASSESS.driftWindowMaxS + " s (" + (ASSESS.driftWindowFrac * 100) + " % of the window) a wheel speed or the lean keeps rising steadily (linear fit R² ≥ " + ASSESS.driftR2 + ", slope not decaying, wheel slope ≥ " + (ASSESS.driftWheelSlopeFrac * 100) + " % of Ω_max per second or lean slope ≥ " + ASSESS.driftLeanSlopeDps + " °/s).",
    outcome: "Outcome priority: Invalid configuration → Fallen → Drifting → Recovered (settled and not drifting) → Not settled within the observation window.",
    rms: "RMS attitude error: root-mean-square of the COM lean e over every integration step of the recorded window.",
    effort: "Control effort: ∫ Σ|T_i| dt over the recorded window [N·m·s], the total magnitude of motor torque applied by all wheels. It is not the energy drawn (see Energy).",
    speedLimited: "Speed-limited time: time during which any active wheel was at or above " + (ASSESS.satSpeedFrac * 100) + " % of its speed limit.",
    leanMargin: "Lean margin: the fall threshold (" + ASSESS.fallEdgeDeg + "° edge, " + ASSESS.fallCornerDeg + "° corner) minus the peak COM lean. Larger means further from falling. Not defined for runs that fell.",
    omegaMargin: "Wheel-speed margin: 1 − (peak wheel speed / speed limit)."
  };
  /* rules for the event timeline (every run on the site uses these) */
  var EVENT_RULES = { mergeGapS: 0.05, maxPerKind: 40, speedRiskFrac: 0.9, speedLimitFrac: ASSESS.satSpeedFrac, estErrDeg: 0.5, estErrHoldS: 0.2 };
  var EVENT_DEFS = {
    disturbance: "Disturbance applied: a scheduled force or torque from the configuration, from its start time to its end.",
    wheel_failure: "Wheel failure: a scheduled fault; the wheel gives no motor torque from this time on and only friction acts on it.",
    controller_mode: "Controller mode change: after a wheel failure in corner mode the torque is reallocated to the healthy wheels and yaw control is given up.",
    yaw_command: "Yaw command: a scheduled step in the commanded heading about the balance axis (corner mode).",
    saturation: "Torque saturation: the commanded motor torque exceeded what the driver could deliver at that wheel speed. Intervals closer than " + (EVENT_RULES.mergeGapS * 1000) + " ms are merged.",
    speed_risk: "Saturation risk: a wheel at or above " + (EVENT_RULES.speedRiskFrac * 100) + " % of its speed limit.",
    speed_limit: "Wheel at its speed limit: at or above " + (EVENT_RULES.speedLimitFrac * 100) + " % of the limit; the motor can add almost no torque in that direction.",
    estimator_warning: "Estimator warning: the estimated tilt differed from the true tilt by more than " + EVENT_RULES.estErrDeg + "° for at least " + EVENT_RULES.estErrHoldS + " s (edge mode with a non-ideal estimator).",
    recovered: "Stability recovered: the settling time t_s; |e| stays within ±" + ASSESS.settleTolDeg + "° from here to the end of the window.",
    fall: "Fall: the COM lean passed the fall threshold or part of the cube touched the floor. Motors stop.",
    floor_contact: "Floor contact: part of the cube reached the floor.",
    termination: "Termination: the end of the observation window, or the end of the recording after a fall.",
    numerical_failure: "Simulation failure: the numerical state became non-finite; the run is invalid."
  };

  /* ---------------- helpers ---------------- */
  function clone(o) { return o == null ? o : JSON.parse(JSON.stringify(o)); }
  function isNum(x) { return typeof x === "number" && isFinite(x); }
  function v3(x, y, z) { return [x, y, z]; }
  function add3(a, b) { return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]; }
  function sub3(a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
  function mul3(a, s) { return [a[0] * s, a[1] * s, a[2] * s]; }
  function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
  function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
  function norm3(a) { return Math.sqrt(dot(a, a)); }
  function unit3(a) { var n = norm3(a); return n > 0 ? mul3(a, 1 / n) : [0, 0, 0]; }
  function mv(M, v) { return [M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2], M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2], M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2]]; }
  function mtv(M, v) { return [M[0][0] * v[0] + M[1][0] * v[1] + M[2][0] * v[2], M[0][1] * v[0] + M[1][1] * v[1] + M[2][1] * v[2], M[0][2] * v[0] + M[1][2] * v[1] + M[2][2] * v[2]]; }
  function outer(a, b) { return [[a[0] * b[0], a[0] * b[1], a[0] * b[2]], [a[1] * b[0], a[1] * b[1], a[1] * b[2]], [a[2] * b[0], a[2] * b[1], a[2] * b[2]]]; }
  function steiner(m, r) { var r2 = dot(r, r); return [[m * (r2 - r[0] * r[0]), -m * r[0] * r[1], -m * r[0] * r[2]], [-m * r[1] * r[0], m * (r2 - r[1] * r[1]), -m * r[1] * r[2]], [-m * r[2] * r[0], -m * r[2] * r[1], m * (r2 - r[2] * r[2])]]; }
  function madd(A, B, s) { s = s == null ? 1 : s; return A.map(function (r, i) { return r.map(function (v, j) { return v + s * B[i][j]; }); }); }
  function mscale(A, s) { return A.map(function (r) { return r.map(function (v) { return v * s; }); }); }
  function eye3(s) { s = s == null ? 1 : s; return [[s, 0, 0], [0, s, 0], [0, 0, s]]; }
  function sym3eig(A) { // eigenvalues of a symmetric 3x3 (closed form)
    var p1 = A[0][1] * A[0][1] + A[0][2] * A[0][2] + A[1][2] * A[1][2];
    if (p1 < 1e-30) return [A[0][0], A[1][1], A[2][2]].sort(function (a, b) { return a - b; });
    var q = (A[0][0] + A[1][1] + A[2][2]) / 3;
    var p2 = Math.pow(A[0][0] - q, 2) + Math.pow(A[1][1] - q, 2) + Math.pow(A[2][2] - q, 2) + 2 * p1, pp = Math.sqrt(p2 / 6);
    var Bm = madd(A, eye3(q), -1).map(function (r) { return r.map(function (v) { return v / pp; }); });
    var r = det(Bm) / 2, phi = r <= -1 ? Math.PI / 3 : r >= 1 ? 0 : Math.acos(r) / 3;
    var e1 = q + 2 * pp * Math.cos(phi), e3 = q + 2 * pp * Math.cos(phi + 2 * Math.PI / 3), e2 = 3 * q - e1 - e3;
    return [e1, e2, e3].sort(function (a, b) { return a - b; });
  }

  /* ---------------- small dense linear algebra ---------------- */
  function zeros(n, m) { var A = []; for (var i = 0; i < n; i++) A.push(new Array(m).fill(0)); return A; }
  function eye(n) { var A = zeros(n, n); for (var i = 0; i < n; i++) A[i][i] = 1; return A; }
  function mul(A, B) {
    var n = A.length, m = B[0].length, k = B.length, C = zeros(n, m);
    for (var i = 0; i < n; i++) for (var j = 0; j < m; j++) { var s = 0; for (var q = 0; q < k; q++) s += A[i][q] * B[q][j]; C[i][j] = s; }
    return C;
  }
  function add(A, B, sb) { var s = sb === undefined ? 1 : sb; return A.map(function (r, i) { return r.map(function (v, j) { return v + s * B[i][j]; }); }); }
  function scal(A, s) { return A.map(function (r) { return r.map(function (v) { return v * s; }); }); }
  function tr(A) { return A[0].map(function (_, j) { return A.map(function (r) { return r[j]; }); }); }
  function inv(A) {
    var n = A.length, M = A.map(function (r, i) { return r.concat(eye(n)[i]); });
    for (var c = 0; c < n; c++) {
      var p = c, best = Math.abs(M[c][c]);
      for (var r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > best) { best = Math.abs(M[r][c]); p = r; }
      if (!(best > 1e-300)) throw new Error("singular matrix");
      var tmp = M[c]; M[c] = M[p]; M[p] = tmp;
      var piv = M[c][c];
      for (var j = 0; j < 2 * n; j++) M[c][j] /= piv;
      for (r = 0; r < n; r++) if (r !== c) { var f = M[r][c]; if (f) for (j = 0; j < 2 * n; j++) M[r][j] -= f * M[c][j]; }
    }
    return M.map(function (r) { return r.slice(n); });
  }
  function det(A) {
    var n = A.length, M = A.map(function (r) { return r.slice(); }), d = 1;
    for (var c = 0; c < n; c++) {
      var p = c, best = Math.abs(M[c][c]);
      for (var r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > best) { best = Math.abs(M[r][c]); p = r; }
      if (best === 0) return 0;
      if (p !== c) { var t = M[c]; M[c] = M[p]; M[p] = t; d = -d; }
      d *= M[c][c];
      for (r = c + 1; r < n; r++) { var f = M[r][c] / M[c][c]; for (var j = c; j < n; j++) M[r][j] -= f * M[c][j]; }
    }
    return d;
  }
  function norm1(A) { var m = 0; for (var j = 0; j < A[0].length; j++) { var s = 0; for (var i = 0; i < A.length; i++) s += Math.abs(A[i][j]); if (s > m) m = s; } return m; }
  function allFinite(A) { for (var i = 0; i < A.length; i++) for (var j = 0; j < A[i].length; j++) if (!isFinite(A[i][j])) return false; return true; }

  /* Continuous-time algebraic Riccati equation by the matrix sign function
     (Roberts 1971; Byers 1987 determinant scaling). Throws on failure. */
  function care(A, B, Q, R) {
    var n = A.length, Ri = inv(R), G = mul(mul(B, Ri), tr(B)), H = zeros(2 * n, 2 * n), i, j;
    for (i = 0; i < n; i++) for (j = 0; j < n; j++) { H[i][j] = A[i][j]; H[i][j + n] = -G[i][j]; H[i + n][j] = -Q[i][j]; H[i + n][j + n] = -A[j][i]; }
    var Z = H, it = 0, conv = false;
    for (it = 0; it < 100; it++) {
      var Zi = inv(Z), c = Math.pow(Math.abs(det(Z)), -1 / (2 * n));
      if (!isFinite(c) || c === 0) throw new Error("Riccati sign iteration broke down (singular Hamiltonian)");
      var Zn = add(scal(Z, 0.5 * c), scal(Zi, 0.5 / c)), diff = norm1(add(Zn, Z, -1)) / norm1(Z);
      Z = Zn; if (diff < 1e-13) { conv = true; break; }
    }
    if (!conv || !allFinite(Z)) throw new Error("Riccati sign iteration did not converge");
    var M = zeros(2 * n, n), N = zeros(2 * n, n);
    for (i = 0; i < n; i++) for (j = 0; j < n; j++) {
      M[i][j] = Z[i][j + n]; M[i + n][j] = Z[i + n][j + n] + (i === j ? 1 : 0);
      N[i][j] = -(Z[i][j] + (i === j ? 1 : 0)); N[i + n][j] = -Z[i + n][j];
    }
    var Mt = tr(M), P = mul(inv(mul(Mt, M)), mul(Mt, N)); P = scal(add(P, tr(P)), 0.5);
    if (!allFinite(P)) throw new Error("Riccati solution is not finite");
    return { P: P, iters: it + 1 };
  }
  function lqr(A, B, Q, R) { var s = care(A, B, Q, R); return { K: mul(mul(inv(R), tr(B)), s.P), P: s.P, iters: s.iters }; }

  /* ---------------- complex polynomials ---------------- */
  function cmul(a, b) { return [a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0]]; }
  function cdiv(a, b) { var d = b[0] * b[0] + b[1] * b[1]; return [(a[0] * b[0] + a[1] * b[1]) / d, (a[1] * b[0] - a[0] * b[1]) / d]; }
  function charPoly(A) {
    var n = A.length, M = zeros(n, n), c = [1], I = eye(n);
    for (var k = 1; k <= n; k++) { M = add(mul(A, M), scal(I, c[k - 1])); var AM = mul(A, M), t = 0; for (var i = 0; i < n; i++) t += AM[i][i]; c.push(-t / k); }
    return c;
  }
  function roots(c) {
    var n = c.length - 1, z = [], i, k, rad = 1 + Math.pow(Math.abs(c[n]), 1 / n);
    for (i = 0; i < n; i++) z.push([Math.cos(2 * Math.PI * i / n + 0.4) * rad, Math.sin(2 * Math.PI * i / n + 0.4) * rad]);
    function ev(x) { var r = [1, 0]; for (var j = 1; j <= n; j++) { r = cmul(r, x); r[0] += c[j]; } return r; }
    for (k = 0; k < 500; k++) {
      var mx = 0;
      for (i = 0; i < n; i++) {
        var den = [1, 0];
        for (var j = 0; j < n; j++) if (j !== i) den = cmul(den, [z[i][0] - z[j][0], z[i][1] - z[j][1]]);
        var dz = cdiv(ev(z[i]), den); z[i] = [z[i][0] - dz[0], z[i][1] - dz[1]]; mx = Math.max(mx, Math.abs(dz[0]) + Math.abs(dz[1]));
      }
      if (mx < 1e-14) break;
    }
    z.forEach(function (r) { if (Math.abs(r[1]) < 1e-9 * Math.max(1, Math.abs(r[0]))) r[1] = 0; });
    z.sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; });
    return z;
  }
  function eig(A) { return roots(charPoly(A)); }
  function polyFromRoots(rs) {
    var c = [[1, 0]];
    rs.forEach(function (r) { var nc = []; for (var i = 0; i <= c.length; i++) { var a = i < c.length ? c[i] : [0, 0], b = i > 0 ? cmul(c[i - 1], [-r[0], -r[1]]) : [0, 0]; nc.push([a[0] + b[0], a[1] + b[1]]); } c = nc; });
    return c.map(function (x) { return x[0]; });
  }

  /* ---------------- base-cube derived quantities (nominal design model) ---------------- */
  function derive(p) {
    var d = clone(p);
    d.Jc = p.kJ * p.m * p.a * p.a; d.lc = Math.sqrt(3) / 2 * p.a; d.le = Math.SQRT2 / 2 * p.a;
    d.kt = 60 / (2 * Math.PI * p.KV); d.ke = d.kt; d.taumax = d.kt * p.Imax; d.wnl = p.Vs / d.ke;
    d.wmax = p.wmaxRpm * RPM; d.hmax = p.Jw * d.wmax; d.dt = 1 / p.fs;
    ["e", "c"].forEach(function (t) {
      var l = t === "e" ? d.le : d.lc;
      d["Th0" + t] = d.Jc + p.m * l * l; d["Thh" + t] = d["Th0" + t] - p.Jw; d["mgl" + t] = p.m * p.g * l;
      d["lam" + t] = d["Thh" + t] > 0 ? Math.sqrt(d["mgl" + t] / d["Thh" + t]) : NaN;
      d["thmax" + t] = d.taumax < d["mgl" + t] ? Math.asin(d.taumax / d["mgl" + t]) : Math.PI / 2;
    });
    d.Thy = d.Jc - p.Jw;
    return d;
  }

  /* ---------------- controller design ---------------- */
  function designTilt(Thh, Th0, mgl, Jw, taumax) {
    if (!(Thh > 0) || !(Th0 > 0) || !(Jw > 0) || !(mgl > 0) || !(taumax > 0)) throw new Error("tilt model is not physical (non-positive inertia, gravity stiffness or torque limit)");
    var A = [[0, 1, 0], [mgl / Thh, 0, 0], [-mgl / Thh, 0, 0]], B = [[0], [-1 / Thh], [Th0 / (Jw * Thh)]];
    var Q = [[1 / (WEIGHTS.th * WEIGHTS.th), 0, 0], [0, 1 / (WEIGHTS.thd * WEIGHTS.thd), 0], [0, 0, 1 / (WEIGHTS.ww * WEIGHTS.ww)]], R = [[1 / (taumax * taumax)]];
    var L = lqr(A, B, Q, R), K = L.K[0];
    if (!K.every(isFinite)) throw new Error("LQR gain is not finite");
    var Acl = add(A, mul(B, [K]), -1), cl = eig(Acl);
    var fast = cl.filter(function (r) { return Math.abs(r[1]) > 1e-9; }); if (fast.length < 2) fast = cl.slice(0, 2);
    var poly = polyFromRoots(fast.concat([[WEIGHTS.pint, 0]]));
    var pid = { Kd: Thh * poly[1], Kp: mgl + Thh * poly[2], Ki: Thh * poly[3] };
    var Aa = zeros(4, 4);
    for (var i = 0; i < 3; i++) { for (var j = 0; j < 3; j++) Aa[i][j] = Acl[i][j]; Aa[i][3] = -B[i][0] * K[0]; }
    Aa[3][2] = WEIGHTS.gam;
    var PIDA = [[0, 1, 0], [(mgl - pid.Kp) / Thh, -pid.Kd / Thh, -pid.Ki / Thh], [1, 0, 0]];
    return { M: { A: A, B: B, Thh: Thh, Th0: Th0, mgl: mgl }, Q: Q, R: R, K: K, P: L.P, iters: L.iters, cl: cl, ol: eig(A), pid: pid, pidPoles: eig(PIDA), gam: WEIGHTS.gam, adpPoles: eig(Aa) };
  }
  function designYaw(Thy, taumax) {
    if (!(Thy > 0)) throw new Error("yaw inertia is not positive");
    var Ay = [[0, 1], [0, 0]], By = [[0], [-1 / Thy]];
    var Qy = [[1 / (WEIGHTS.psi * WEIGHTS.psi), 0], [0, 1 / (WEIGHTS.psid * WEIGHTS.psid)]], Ry = [[1 / (3 * taumax * taumax)]];
    var Ly = lqr(Ay, By, Qy, Ry), Ky = Ly.K[0], cly = eig(add(Ay, mul(By, [Ky]), -1));
    var polyy = polyFromRoots(cly.concat([[WEIGHTS.pinty, 0]]));
    return { A: Ay, B: By, Q: Qy, R: Ry, K: Ky, cl: cly, pid: { Kd: Thy * polyy[1], Kp: Thy * polyy[2], Ki: Thy * polyy[3] } };
  }
  /* nominal design used by the AERIS Twin reference pages */
  function design(p) {
    var d = derive(p), out = { d: d, W: WEIGHTS };
    out.e = designTilt(d.Thhe, d.Th0e, d.mgle, p.Jw, d.taumax);
    out.c = designTilt(d.Thhc, d.Th0c, d.mglc, p.Jw, d.taumax);
    out.yaw = designYaw(d.Thy, d.taumax);
    return out;
  }

  /* ---------------- actuator, friction, noise ---------------- */
  /* torque the driver can deliver: current limit, back-EMF limit and speed cut-off, all scaled by
     the wheel's health h (1 = nominal, 0 = no torque); h = 1 reproduces the unscaled limits exactly */
  function tauAvail(d, T, ww, h) {
    var tm = h == null || h === 1 ? d.taumax : d.taumax * h;
    if (T > tm) T = tm; else if (T < -tm) T = -tm;
    if (T * ww > 0) {
      var lim = Math.abs(ww) >= d.wmax ? 0 : Math.max(0, d.kt * (d.Vs - d.ke * Math.abs(ww)) / d.R);
      if (h != null && h !== 1) lim *= h;
      if (Math.abs(T) > lim) T = T > 0 ? lim : -lim;
    }
    return T;
  }
  function fric(d, ww) { return d.cv * ww + d.cc * Math.tanh(ww); }
  function rng(seed) {
    var a = seed >>> 0, spare = null;
    function u() { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
    function n() { if (spare !== null) { var s = spare; spare = null; return s; } var u1 = 0; while (u1 === 0) u1 = u(); var u2 = u(), r = Math.sqrt(-2 * Math.log(u1)); spare = r * Math.sin(2 * Math.PI * u2); return r * Math.cos(2 * Math.PI * u2); }
    return { u: u, n: n };
  }

  /* ---------------- geometry ---------------- */
  var Q3 = {
    mul: function (a, b) { return [a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3], a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2], a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1], a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0]]; },
    conj: function (q) { return [q[0], -q[1], -q[2], -q[3]]; },
    rot: function (q) { var q0 = q[0], q1 = q[1], q2 = q[2], q3 = q[3]; return [[1 - 2 * (q2 * q2 + q3 * q3), 2 * (q1 * q2 - q0 * q3), 2 * (q1 * q3 + q0 * q2)], [2 * (q1 * q2 + q0 * q3), 1 - 2 * (q1 * q1 + q3 * q3), 2 * (q2 * q3 - q0 * q1)], [2 * (q1 * q3 - q0 * q2), 2 * (q2 * q3 + q0 * q1), 1 - 2 * (q1 * q1 + q2 * q2)]]; },
    axis: function (ax, ang) { var n = Math.hypot(ax[0], ax[1], ax[2]); if (!(n > 0)) return [1, 0, 0, 0]; var s = Math.sin(ang / 2) / n; return [Math.cos(ang / 2), ax[0] * s, ax[1] * s, ax[2] * s]; },
    norm: function (q) { var n = Math.hypot(q[0], q[1], q[2], q[3]); return [q[0] / n, q[1] / n, q[2] / n, q[3] / n]; },
    fromTo: function (u, v) { // shortest rotation taking unit u to unit v
      var c = dot(u, v), ax = cross(u, v), s = norm3(ax);
      if (s < 1e-12) { if (c > 0) return [1, 0, 0, 0]; var perp = Math.abs(u[0]) < 0.9 ? cross(u, [1, 0, 0]) : cross(u, [0, 1, 0]); return Q3.axis(perp, Math.PI); }
      return Q3.axis(ax, Math.atan2(s, c));
    }
  };
  var CH = [1 / Math.sqrt(3), 1 / Math.sqrt(3), 1 / Math.sqrt(3)];
  function projOn(v, u) { var s = dot(v, u); return [v[0] - s * u[0], v[1] - s * u[1], v[2] - s * u[2]]; }
  function proj(v) { return projOn(v, CH); }
  var QEQ = Q3.fromTo(CH, [0, 0, 1]);
  var E1 = unit3(proj([1, 0, 0])), E2 = cross(CH, E1);
  var D_EDGE = [0, Math.SQRT1_2, Math.SQRT1_2], N_EDGE = [0, -Math.SQRT1_2, Math.SQRT1_2];   // edge balance line and its in-plane normal
  function rotX(phi) { var c = Math.cos(phi), s = Math.sin(phi); return [[1, 0, 0], [0, c, -s], [0, s, c]]; }
  var WHEELS = ["x", "y", "z"];

  /* ---------------- configuration ---------------- */
  function defaultConfig(mode) {
    return {
      schema: VERSION.config, mode: mode === "corner" ? "corner" : "edge",
      params: clone(NOMINAL), comOffset_m: 0, comShift_m: [0, 0, 0], attachments: [],
      controller: { type: "lqr", knowsAttachments: false, reconfigureOnFailure: true, structure: "decoupled" },
      estimator: { type: "ideal" }, seed: 7,
      sensor: clone(SENSOR_DEFAULTS), actuator: clone(ACTUATOR_DEFAULTS),
      initial: { tilt_deg: 2, rate_dps: 0, azimuth_deg: 0, reference: "geometric" },
      disturbances: [], events: [], commands: [],
      uncertainty: { inertiaScale: 1 }, torqueScale: 1, duration_s: 10, record_hz: 50
    };
  }
  function num(x, dflt) { var v = typeof x === "string" ? parseFloat(x) : x; return typeof v === "number" ? v : dflt; }
  /* fill defaults without hiding bad values: non-numbers become NaN so validation reports them */
  function normalizeConfig(cfg) {
    var c = defaultConfig(cfg && cfg.mode), s = cfg || {};
    c.mode = s.mode === "corner" ? "corner" : s.mode === "edge" ? "edge" : c.mode;
    if (s.params) Object.keys(NOMINAL).forEach(function (k) { if (s.params[k] !== undefined) c.params[k] = num(s.params[k], NaN); });
    if (s.comOffset_m !== undefined) c.comOffset_m = num(s.comOffset_m, NaN);
    if (s.comShift_m !== undefined) c.comShift_m = [0, 1, 2].map(function (j) { return Array.isArray(s.comShift_m) ? num(s.comShift_m[j], NaN) : NaN; });
    if (s.sensor) Object.keys(SENSOR_DEFAULTS).forEach(function (k) { if (s.sensor[k] !== undefined) c.sensor[k] = k === "rate_hz" && s.sensor[k] === null ? null : num(s.sensor[k], NaN); });
    if (s.actuator) {
      if (s.actuator.motor_lag_ms !== undefined) c.actuator.motor_lag_ms = num(s.actuator.motor_lag_ms, NaN);
      if (s.actuator.wheel_health) WHEELS.forEach(function (w) { if (s.actuator.wheel_health[w] !== undefined) c.actuator.wheel_health[w] = num(s.actuator.wheel_health[w], NaN); });
    }
    if (Array.isArray(s.attachments)) c.attachments = s.attachments.map(function (a, i) { return { id: String(a.id || ("m" + (i + 1))), label: String(a.label || ("Mass " + (i + 1))), mass_kg: num(a.mass_kg, NaN), pos_m: [0, 1, 2].map(function (j) { return num(a.pos_m && a.pos_m[j], NaN); }) }; });
    if (s.controller) { c.controller.type = ["pid", "lqr", "adp", "none"].indexOf(s.controller.type) >= 0 ? s.controller.type : "?" + s.controller.type; c.controller.knowsAttachments = !!s.controller.knowsAttachments; c.controller.reconfigureOnFailure = s.controller.reconfigureOnFailure !== false; if (s.controller.structure !== undefined) c.controller.structure = String(s.controller.structure); }
    if (s.estimator) { c.estimator.type = s.estimator.type || "ideal"; if (s.estimator.Rkf_deg !== undefined) c.estimator.Rkf_deg = num(s.estimator.Rkf_deg, NaN); }
    if (s.seed !== undefined) c.seed = Math.round(num(s.seed, 7));
    if (s.initial) { ["tilt_deg", "rate_dps", "azimuth_deg"].forEach(function (k) { if (s.initial[k] !== undefined) c.initial[k] = num(s.initial[k], NaN); }); if (s.initial.reference !== undefined) c.initial.reference = s.initial.reference === "balance" || s.initial.reference === "geometric" ? s.initial.reference : "?" + s.initial.reference; }
    if (Array.isArray(s.disturbances)) c.disturbances = s.disturbances.map(function (d, i) {
      var o = { id: String(d.id || ("L" + (i + 1))), type: d.type === "torque" ? "torque" : d.type === "force" ? "force" : "?" + d.type, frame: d.frame === "world" ? "world" : d.frame === "body" ? "body" : "?" + d.frame, t_start_s: num(d.t_start_s, NaN), duration_s: num(d.duration_s, NaN), direction: [0, 1, 2].map(function (j) { return num(d.direction && d.direction[j], NaN); }) };
      if (o.type === "force") { o.magnitude_N = num(d.magnitude_N, NaN); o.point_m = [0, 1, 2].map(function (j) { return num(d.point_m && d.point_m[j], NaN); }); }
      else o.magnitude_Nm = num(d.magnitude_Nm, NaN);
      return o;
    });
    if (Array.isArray(s.events)) c.events = s.events.map(function (e, i) { return { id: String(e.id || ("E" + (i + 1))), type: e.type === "wheel_failure" ? "wheel_failure" : "?" + e.type, wheel: WHEELS.indexOf(e.wheel) >= 0 ? e.wheel : "?" + e.wheel, t_s: num(e.t_s, NaN) }; });
    if (Array.isArray(s.commands)) c.commands = s.commands.map(function (e, i) { return { id: String(e.id || ("C" + (i + 1))), type: e.type === "yaw_step" ? "yaw_step" : "?" + e.type, t_s: num(e.t_s, NaN), angle_deg: num(e.angle_deg, NaN) }; });
    if (s.uncertainty && s.uncertainty.inertiaScale !== undefined) c.uncertainty.inertiaScale = num(s.uncertainty.inertiaScale, NaN);
    if (s.torqueScale !== undefined) c.torqueScale = num(s.torqueScale, NaN);
    if (s.duration_s !== undefined) c.duration_s = num(s.duration_s, NaN);
    if (s.record_hz !== undefined) c.record_hz = num(s.record_hz, NaN);
    return c;
  }

  /* ---------------- mass properties (base cube + point-mass attachments) ---------------- */
  function massProps(cfg) {
    var p = cfg.params, a = p.a, m0 = p.m, Jc0 = p.kJ * m0 * a * a;
    var offDir = cfg.mode === "edge" ? N_EDGE : E1;
    var shift = Array.isArray(cfg.comShift_m) ? cfg.comShift_m : [0, 0, 0];
    var r0 = add3(add3([a / 2, a / 2, a / 2], mul3(offDir, cfg.comOffset_m || 0)), [shift[0] || 0, shift[1] || 0, shift[2] || 0]);
    var M = m0, S = mul3(r0, m0), ThO = madd(eye3(Jc0), steiner(m0, r0)), parts = [];
    parts.push({ id: "base", label: "Base cube", mass: m0, pos: r0, ownInertia: Jc0 });
    (cfg.attachments || []).forEach(function (at) {
      M += at.mass_kg; S = add3(S, mul3(at.pos_m, at.mass_kg)); ThO = madd(ThO, steiner(at.mass_kg, at.pos_m));
      parts.push({ id: at.id, label: at.label, mass: at.mass_kg, pos: at.pos_m.slice(), ownInertia: 0 });
    });
    var rc = mul3(S, 1 / M), ThC = madd(ThO, steiner(M, rc), -1);
    var out = { M: M, rc: rc, r0: r0, m0: m0, Jc0: Jc0, ThO: ThO, ThC: ThC, parts: parts, baseCenter: [a / 2, a / 2, a / 2] };
    // edge: support edge along body x through the pivot vertex O
    var le = Math.hypot(rc[1], rc[2]), betaE = Math.atan2(dot(rc, N_EDGE), dot(rc, D_EDGE));
    out.edge = { l: le, beta: betaE, Th0: ThO[0][0], Thh: ThO[0][0] - p.Jw, xc: rc[0] };
    // corner: pivot at O
    var lc = norm3(rc), u = lc > 0 ? mul3(rc, 1 / lc) : CH.slice(), betaC = Math.acos(Math.max(-1, Math.min(1, dot(u, CH))));
    var Thh = madd(ThO, eye3(p.Jw), -1), ev = sym3eig(Thh);
    var trace = ThO[0][0] + ThO[1][1] + ThO[2][2], ThPar = dot(u, mv(ThO, u));
    // edgeClear: elevation angle of the lowest pivot edge when the COM is straight above the pivot (u_B = u)
    out.corner = { l: lc, u: u, beta: betaC, Thh: Thh, minEig: ev[0], eig: ev, ThPar: ThPar, ThPerp: (trace - ThPar) / 2, edgeClear: Math.asin(Math.max(-1, Math.min(1, Math.min(u[0], u[1], u[2])))) };
    return out;
  }

  /* ---------------- validation (individual ranges AND physical combinations) ---------------- */
  function fmtSI(x, u, sig) { if (!isFinite(x)) return String(x); var s = Math.abs(x) >= 1e-3 && Math.abs(x) < 1e5 ? (+x.toPrecision(sig || 3)).toString() : x.toExponential((sig || 3) - 1); return s + (u ? " " + u : ""); }
  function validateParams(p, E, W) {
    E = E || []; W = W || [];
    Object.keys(PARAM_SPEC).forEach(function (k) {
      var sp = PARAM_SPEC[k], v = p[k];
      if (!isNum(v)) E.push({ path: "params." + k, message: sp.label + " must be a finite number (got " + String(v) + ")." });
      else if (v < sp.min || v > sp.max) E.push({ path: "params." + k, message: sp.label + " = " + fmtSI(v, sp.unit) + " is outside the supported range " + fmtSI(sp.min, sp.unit) + " to " + fmtSI(sp.max, sp.unit) + "." });
    });
    if (E.length) return { errors: E, warnings: W };
    var Jc = p.kJ * p.m * p.a * p.a, JwMax = p.m * p.a * p.a / 12;
    if (p.Jw >= JwMax) E.push({ path: "params.Jw", message: "Wheel spin inertia J_w = " + fmtSI(p.Jw, "kg·m²") + " is too large for a " + fmtSI(p.m, "kg") + ", " + fmtSI(p.a * 1000, "mm") + " cube. A wheel of radius at most a/2 carrying at most a third of the base mass has J_w < m·a²/12 = " + fmtSI(JwMax, "kg·m²") + ". Reduce J_w or increase the mass or edge length." });
    if (Jc < 2 * p.Jw) E.push({ path: "params.kJ", message: "Body inertia J_c = k_J·m·a² = " + fmtSI(Jc, "kg·m²") + " is smaller than the " + fmtSI(2 * p.Jw, "kg·m²") + " that the three wheels alone contribute about any axis (one wheel's spin inertia plus half of each other wheel's, by the perpendicular-axis theorem). This would make the effective inertias negative. Increase k_J, m or a, or reduce J_w." });
    var d = derive(p);
    if (d.Vs && d.wnl < d.wmax) W.push({ path: "params.wmaxRpm", message: "The wheel speed limit (" + fmtSI(p.wmaxRpm, "rpm") + ") is above the motor's no-load speed (" + fmtSI(d.wnl / RPM, "rpm", 4) + "); back-EMF will stop the wheel before the limit." });
    if (2 * Math.PI * p.fs / Math.max(d.lame || 0, d.lamc || 0) < 60) W.push({ path: "params.fs", message: "The loop rate is low compared with the open-loop instability rate; results may depend on the sampling." });
    return { errors: E, warnings: W };
  }
  function validateConfig(cfgIn) {
    var cfg = normalizeConfig(cfgIn), E = [], W = [];
    if (cfgIn && cfgIn.mode && cfgIn.mode !== "edge" && cfgIn.mode !== "corner") E.push({ path: "mode", message: "Balance mode must be 'edge' or 'corner'." });
    validateParams(cfg.params, E, W);
    var p = cfg.params, a = p.a, edge = cfg.mode === "edge";
    /* kind "engine-range": a range this browser engine supports (another engine may accept more); "capability": a feature
       this engine does not execute. Both are reported as errors here; the platform re-checks them against the active engine. */
    function chk(path, v, lo, hi, label, unit, kind) { var o; if (!isNum(v)) o = { path: path, message: label + " must be a finite number." }; else if (v < lo || v > hi) o = { path: path, message: label + " = " + fmtSI(v, unit) + " must lie between " + fmtSI(lo, unit) + " and " + fmtSI(hi, unit) + "." }; if (o) { if (kind && isNum(v)) o.kind = kind; E.push(o); } }
    chk("duration_s", cfg.duration_s, 1, 60, "Duration", "s", "engine-range");
    chk("record_hz", cfg.record_hz, 10, 200, "Recording rate", "Hz", "engine-range");
    /* v5 (docs/RECORDING.md): samples are control-step states every fs/record_hz steps, so the rate must divide the loop
       rate; v4 rounded the stride and kept the requested label (e.g. 60 Hz recorded at 62.5 Hz) */
    if (isNum(cfg.record_hz) && cfg.record_hz > 0 && isNum(p.fs) && p.fs > 0 && Math.abs(p.fs / cfg.record_hz - Math.round(p.fs / cfg.record_hz)) > 1e-9 * Math.max(1, p.fs / cfg.record_hz)) {
      var lo = p.fs / Math.ceil(p.fs / cfg.record_hz), hi = p.fs / Math.floor(p.fs / cfg.record_hz);
      E.push({ path: "record_hz", kind: "engine-range", message: "The recording rate " + fmtSI(cfg.record_hz, "Hz", 6) + " does not divide the " + fmtSI(p.fs, "Hz", 6) + " loop rate. Samples are states at control steps, so it could only be realised as " + fmtSI(p.fs / Math.max(1, Math.round(p.fs / cfg.record_hz)), "Hz", 6) + " and would be mislabelled. Choose a divisor of the loop rate (nearest: " + fmtSI(lo, "Hz", 6) + (isFinite(hi) && hi !== lo ? " or " + fmtSI(hi, "Hz", 6) : "") + ")." });
    }
    chk("torqueScale", cfg.torqueScale, 0.2, 2, "Torque limit scale", "");
    chk("uncertainty.inertiaScale", cfg.uncertainty.inertiaScale, 0.5, 2, "Plant inertia scale", "");
    chk("comOffset_m", cfg.comOffset_m, -0.02, 0.02, "Base COM offset", "m");
    cfg.comShift_m.forEach(function (v, j) { chk("comShift_m." + j, v, -0.05, 0.05, "Base COM shift " + "xyz"[j], "m"); });
    Object.keys(SENSOR_SPEC).forEach(function (k) { var sp = SENSOR_SPEC[k]; chk("sensor." + k, cfg.sensor[k], sp.min, sp.max, sp.label, sp.unit); });
    if (cfg.sensor.rate_hz !== null && cfg.sensor.rate_hz !== undefined) { if (!isNum(cfg.sensor.rate_hz) || cfg.sensor.rate_hz <= 0) E.push({ path: "sensor.rate_hz", message: "IMU sample rate must be a positive number of hertz, or empty (same as the control loop)." }); else if (Math.abs(cfg.sensor.rate_hz - p.fs) > 1e-9) W.push({ path: "sensor.rate_hz", kind: "capability", message: "The browser engine samples the IMU at the control-loop rate (" + p.fs + " Hz). The IMU rate of " + cfg.sensor.rate_hz + " Hz is recorded for the research backend and has no effect in this run." }); }
    chk("actuator.motor_lag_ms", cfg.actuator.motor_lag_ms, 0, 200, "Motor torque lag", "ms");
    WHEELS.forEach(function (w) { chk("actuator.wheel_health." + w, cfg.actuator.wheel_health[w], 0, 1, "Wheel " + w.toUpperCase() + " health", ""); });
    if (["decoupled", "mimo-lqr"].indexOf(cfg.controller.structure) < 0) E.push({ path: "controller.structure", message: "Unknown controller structure '" + cfg.controller.structure + "'." });
    else if (cfg.controller.structure === "mimo-lqr") E.push({ path: "controller.structure", kind: "capability", message: "A full three-axis MIMO LQR (coupled x/y/z states with the full inertia tensor) is not implemented in the browser engine. It runs on the research backend (SIMULATION mode); choose the decoupled structure to run here." });
    var sensorChanged = Object.keys(SENSOR_SPEC).some(function (k) { return isNum(cfg.sensor[k]) && cfg.sensor[k] !== SENSOR_DEFAULTS[k]; });
    if (sensorChanged && cfg.mode === "corner") W.push({ path: "sensor", kind: "capability", message: "Corner mode uses ideal state feedback in the browser engine (no 3-D attitude estimator yet), so the sensor settings are recorded with the run but have no effect." });
    else if (sensorChanged && cfg.estimator.type === "ideal") W.push({ path: "sensor", message: "The estimator is 'Ideal state': the controller sees the true state, so the sensor settings have no effect. Choose an estimator to use them." });
    if (cfg.mode === "edge" && (cfg.actuator.wheel_health.y !== 1 || cfg.actuator.wheel_health.z !== 1)) W.push({ path: "actuator.wheel_health", message: "Edge mode drives only wheel X; the health of wheels Y and Z has no effect." });
    chk("initial.tilt_deg", cfg.initial.tilt_deg, -30, 30, "Initial tilt", "°");
    chk("initial.rate_dps", cfg.initial.rate_dps, -200, 200, "Initial rate", "°/s");
    chk("initial.azimuth_deg", cfg.initial.azimuth_deg, -360, 360, "Initial tilt direction", "°");
    if (String(cfg.initial.reference).charAt(0) === "?") E.push({ path: "initial.reference", message: "Initial tilt reference must be 'geometric' (diagonal vertical) or 'balance' (centre of mass above the pivot)." });
    if (!isNum(cfg.seed)) E.push({ path: "seed", message: "Random seed must be an integer." });
    if (cfg.controller.type.charAt(0) === "?") E.push(cfg.controller.type === "?nlpd" ? { path: "controller.type", kind: "capability", message: "The nonlinear quaternion controller (nlpd) runs on the research backend only; the browser engine has PID, LQR, Adaptive and None." } : { path: "controller.type", message: "Unknown controller '" + cfg.controller.type.slice(1) + "'. Use PID, LQR, Adaptive or None." });
    var ests = ["ideal", "cf", "kf", "accel", "gyro"];
    if (ests.indexOf(cfg.estimator.type) < 0) E.push(cfg.estimator.type === "mekf" || cfg.estimator.type === "cf3d" ? { path: "estimator.type", kind: "capability", message: "The " + (cfg.estimator.type === "mekf" ? "quaternion MEKF" : "3-D complementary filter") + " runs on the research backend only; the browser engine has ideal, cf, kf, accel and gyro (edge mode)." } : { path: "estimator.type", message: "Unknown estimator '" + cfg.estimator.type + "'." });
    else if (!edge && cfg.estimator.type !== "ideal") E.push({ path: "estimator.type", kind: "capability", message: "Corner mode uses ideal state feedback in the browser engine; the 3-D attitude estimators (cf3d, MEKF) run on the research backend (SIMULATION mode). Choose 'Ideal state' to run here." });
    if (cfg.estimator.Rkf_deg !== undefined) chk("estimator.Rkf_deg", cfg.estimator.Rkf_deg, 0.01, 20, "Kalman accelerometer noise", "°");
    if (cfg.attachments.length > 8) E.push({ path: "attachments", kind: "engine-range", message: "At most 8 attached masses are supported." });
    cfg.attachments.forEach(function (at, i) {
      var nm = "Attached mass '" + at.label + "'";
      chk("attachments." + i + ".mass_kg", at.mass_kg, 1e-4, 5, nm + " mass", "kg");
      at.pos_m.forEach(function (v, j) { if (!isNum(v)) E.push({ path: "attachments." + i + ".pos_m", message: nm + ": position " + "xyz"[j] + " must be a finite number." }); else if (v < -1e-4 || v > a + 1e-4) E.push({ path: "attachments." + i + ".pos_m", message: nm + ": " + "xyz"[j] + " = " + fmtSI(v * 1000, "mm") + " is outside the cube (0 to " + fmtSI(a * 1000, "mm") + "). Attachments must sit on or inside the frame." }); });
    });
    cfg.disturbances.forEach(function (L, i) {
      var nm = (L.type === "torque" ? "Torque load '" : "Force '") + L.id + "'", path = "disturbances." + i;
      if (L.type.charAt(0) === "?") { E.push({ path: path + ".type", message: nm + ": type must be 'force' or 'torque'." }); return; }
      if (L.frame.charAt(0) === "?") E.push({ path: path + ".frame", message: nm + ": frame must be 'body' or 'world'." });
      if (L.type === "force") {
        chk(path + ".magnitude_N", L.magnitude_N, 0, 100, nm + " magnitude", "N");
        L.point_m.forEach(function (v, j) { if (!isNum(v)) E.push({ path: path + ".point_m", message: nm + ": application point " + "xyz"[j] + " must be a finite number." }); else if (v < -1e-4 || v > a + 1e-4) E.push({ path: path + ".point_m", message: nm + ": application point " + "xyz"[j] + " = " + fmtSI(v * 1000, "mm") + " is outside the cube." }); });
      } else chk(path + ".magnitude_Nm", L.magnitude_Nm, 0, 5, nm + " magnitude", "N·m");
      if (!L.direction.every(isNum) || norm3(L.direction) < 1e-9) E.push({ path: path + ".direction", message: nm + ": direction must be a non-zero vector." });
      chk(path + ".t_start_s", L.t_start_s, 0, 60, nm + " start time", "s");
      chk(path + ".duration_s", L.duration_s, 1e-3, 60, nm + " duration", "s");
      if (isNum(L.t_start_s) && isNum(cfg.duration_s) && L.t_start_s >= cfg.duration_s) W.push({ path: path + ".t_start_s", message: nm + " starts after the run ends and will have no effect." });
    });
    cfg.events.forEach(function (ev, i) {
      var path = "events." + i;
      if (ev.type.charAt(0) === "?") E.push({ path: path, message: "Unknown event type '" + ev.type.slice(1) + "'." });
      if (ev.wheel.charAt(0) === "?") E.push({ path: path + ".wheel", message: "Wheel must be x, y or z." });
      chk(path + ".t_s", ev.t_s, 0, 60, "Wheel-failure time", "s");
      if (isNum(ev.t_s) && isNum(cfg.duration_s) && ev.t_s >= cfg.duration_s) W.push({ path: path + ".t_s", message: "The " + String(ev.wheel).toUpperCase() + "-wheel failure at " + fmtSI(ev.t_s, "s") + " happens after the run ends and will have no effect." });
      if (edge && ev.wheel !== "x" && ev.wheel.charAt(0) !== "?") W.push({ path: path + ".wheel", message: "Edge mode drives only the X wheel (its axis is parallel to the support edge); a " + ev.wheel.toUpperCase() + "-wheel failure has no effect." });
    });
    cfg.commands.forEach(function (c, i) {
      var path = "commands." + i;
      if (edge) E.push({ path: path, message: "Yaw commands apply to corner mode only." });
      if (c.type !== "yaw_step") E.push({ path: path, message: "Unknown command type." });
      chk(path + ".t_s", c.t_s, 0, 60, "Yaw command time", "s"); chk(path + ".angle_deg", c.angle_deg, -180, 180, "Yaw command angle", "°");
      if (isNum(c.t_s) && isNum(cfg.duration_s) && c.t_s >= cfg.duration_s) W.push({ path: path + ".t_s", message: "The yaw command at " + fmtSI(c.t_s, "s") + " happens after the run ends and will have no effect." });
    });
    var mp = null, dz = null;
    if (!E.length) {
      mp = massProps(cfg);
      var tol = 0.5e-3;
      if (edge) {
        if (!(mp.edge.Thh > 0)) E.push({ path: "attachments", message: "Effective inertia about the support edge is not positive." });
        if (mp.edge.l < 1e-3) E.push({ path: "attachments", message: "The centre of mass lies on the support edge (" + fmtSI(mp.edge.l * 1000, "mm") + " from it); there is nothing to balance." });
        if (mp.edge.xc <= tol || mp.edge.xc >= a - tol) E.push({ path: "attachments", message: "The centre of mass (x = " + fmtSI(mp.edge.xc * 1000, "mm") + ") is at or beyond the end of the support edge (0 to " + fmtSI(a * 1000, "mm") + "). The cube would tip over the end of the edge, which the planar edge model cannot represent." });
        else if (mp.edge.xc < 0.1 * a || mp.edge.xc > 0.9 * a) W.push({ path: "attachments", message: "The centre of mass sits " + fmtSI(Math.min(mp.edge.xc, a - mp.edge.xc) * 1000, "mm") + " from one end of the support edge. A real cube could tip over that end; the planar edge model only allows rotation about the edge." });
        var bE = Math.abs(mp.edge.beta) / DEG;
        if (bE >= ASSESS.contactEdgeDeg) E.push({ path: "attachments", message: "The centre of mass is " + bE.toFixed(1) + "° off the edge's balance line. Balancing would need a lean of " + bE.toFixed(1) + "°, but a face touches the floor at " + ASSESS.contactEdgeDeg + "°." });
        else if (bE > ASSESS.fallEdgeDeg - 5) W.push({ path: "attachments", message: "The balance attitude is " + bE.toFixed(1) + "° from the geometric one, close to where a face touches the floor." });
      } else {
        if (!(mp.corner.minEig > 0)) E.push({ path: "attachments", message: "Effective inertia about the pivot is not positive definite." });
        if (mp.corner.l < 1e-3) E.push({ path: "attachments", message: "The centre of mass coincides with the pivot corner." });
        var bC = mp.corner.beta / DEG, clrDeg = mp.corner.edgeClear / DEG;
        if (!(mp.corner.edgeClear > 0)) E.push({ path: "attachments", message: "With the centre of mass " + bC.toFixed(1) + "° off the main diagonal, the balance attitude would put one of the pivot's edges on the floor, so the cube would be resting on an edge rather than balancing on the corner." });
        else if (clrDeg < ASSESS.cornerEdgeClearWarnDeg) W.push({ path: "attachments", message: "The centre of mass is " + bC.toFixed(1) + "° off the main diagonal. At the balance attitude the lowest edge is only " + clrDeg.toFixed(1) + "° above the floor." });
      }
      if (!E.length) {
        var ini = initialState(cfg, mp), fallLim = edge ? ASSESS.fallEdgeDeg : ASSESS.fallCornerDeg;
        if (!(ini.clear > 0)) E.push({ path: "initial", message: "The initial attitude puts part of the cube on the floor (" + (edge ? "|θ₀| = " + (Math.abs(ini.theta) / DEG).toFixed(1) + "° ≥ " + ASSESS.contactEdgeDeg + "°" : "one of the pivot's edges is below the floor") + "). Reduce the initial tilt." });
        else if (Math.abs(ini.e) / DEG > fallLim) W.push({ path: "initial", message: "At t = 0 the centre of mass is already " + (Math.abs(ini.e) / DEG).toFixed(1) + "° from vertical, beyond the " + fallLim + "° fall threshold, so the run will be reported as Fallen straight away." + (cfg.initial.reference === "geometric" && (cfg.attachments.length || cfg.comOffset_m) ? " Measuring the initial tilt from the balance attitude starts the cube with its centre of mass above the pivot." : "") });
      }
      cfg.disturbances.forEach(function (L, i) { if (L.type === "force" && L.magnitude_N > 0.5 * mp.M * p.g) W.push({ path: "disturbances." + i, message: "Force '" + L.id + "' (" + fmtSI(L.magnitude_N, "N") + ") exceeds half the cube's weight (" + fmtSI(0.5 * mp.M * p.g, "N") + "). The model assumes the pivot never slips or lifts; a real cube might." }); });
      if (!E.length) {
        try { dz = designForConfig(cfg, mp); }
        catch (ex) { E.push({ path: "controller", message: "Controller design failed: " + ex.message + ". Check the inertia and torque parameters." }); }
      }
      if (dz) {
        var dt = 1 / p.fs, fastest = 0;
        [dz.tilt.cl, dz.tilt.pidPoles, dz.tilt.adpPoles, dz.yaw ? dz.yaw.cl : []].forEach(function (ps) { ps.forEach(function (r) { fastest = Math.max(fastest, Math.hypot(r[0], r[1])); }); });
        var lamPlant = dz.plant.lambda;
        if (!isFinite(fastest) || !isFinite(lamPlant)) E.push({ path: "controller", message: "Controller design produced non-finite poles." });
        else if (Math.max(fastest, lamPlant) * dt > 0.5) E.push({ path: "params.fs", message: "The loop rate f_s = " + fmtSI(p.fs, "Hz") + " is too slow for these dynamics (fastest mode " + fmtSI(Math.max(fastest, lamPlant), "s⁻¹") + "). The fixed-step integrator and the sampled controller need f_s ≥ " + fmtSI(Math.ceil(Math.max(fastest, lamPlant) / 0.5), "Hz") + "." });
        var hold = mp.M * p.g * (edge ? mp.edge.l * Math.abs(Math.sin(mp.edge.beta)) : mp.corner.l * Math.sin(mp.corner.beta)), tmax = dz.actuator.taumax;
        if (hold > tmax && !cfg.controller.knowsAttachments && cfg.controller.type !== "none") W.push({ path: "controller.knowsAttachments", message: "Held at the geometric attitude, gravity pulls with " + fmtSI(hold, "N·m") + ", more than the motors' " + fmtSI(tmax, "N·m") + ". This controller is designed for the bare cube, so it steers toward that attitude and is likely to fall. Enabling 'controller knows the attached masses' designs for the true balance attitude instead." });
      }
    }
    return { ok: E.length === 0, errors: E, warnings: W, config: cfg, mp: E.length ? null : mp, design: E.length ? null : dz };
  }

  /* ---------------- controller design for a configuration ---------------- */
  function designForConfig(cfg, mp) {
    var p = cfg.params, d = derive(p), knows = !!cfg.controller.knowsAttachments, s = cfg.uncertainty.inertiaScale;
    var act = { taumax: d.taumax * cfg.torqueScale, taumaxNominal: d.taumax, kt: d.kt, ke: d.ke, R: p.R, Vs: p.Vs, wmax: d.wmax, wnl: d.wnl, cv: p.cv, cc: p.cc, hmax: d.hmax };
    if (cfg.mode === "edge") {
      var Th0 = knows ? mp.edge.Th0 : d.Th0e, mgl = knows ? mp.M * p.g * mp.edge.l : d.mgle;
      var tilt = designTilt(Th0 - p.Jw, Th0, mgl, p.Jw, d.taumax);
      var plantThh = mp.edge.Th0 * s - p.Jw;
      if (!(plantThh > 0)) throw new Error("plant inertia about the edge is not positive after the inertia scale");
      return { mode: "edge", model: knows ? "actual" : "nominal", tilt: tilt, betaRef: knows ? mp.edge.beta : 0, actuator: act, plant: { Th0: mp.edge.Th0 * s, Thh: plantThh, mgl: mp.M * p.g * mp.edge.l, beta: mp.edge.beta, lambda: Math.sqrt(mp.M * p.g * mp.edge.l / plantThh) } };
    }
    var u = knows ? mp.corner.u : CH, Thp = knows ? mp.corner.ThPerp : d.Th0c, mglc = knows ? mp.M * p.g * mp.corner.l : d.mglc, Thpar = knows ? mp.corner.ThPar : d.Jc;
    var tiltC = designTilt(Thp - p.Jw, Thp, mglc, p.Jw, d.taumax), yaw = designYaw(Thpar - p.Jw, d.taumax);
    var plantTh = mscale(mp.ThO, s), plantThh = madd(plantTh, eye3(p.Jw), -1), ev = sym3eig(plantThh);
    if (!(ev[0] > 0)) throw new Error("plant inertia about the pivot is not positive definite after the inertia scale");
    var lamC = Math.sqrt(mp.M * p.g * mp.corner.l / Math.max(1e-12, ev[0]));
    return { mode: "corner", model: knows ? "actual" : "nominal", tilt: tiltC, yaw: yaw, uRef: u.slice(), actuator: act, plant: { Th0: plantTh, Thh: plantThh, Thhi: inv(plantThh), M: mp.M, rc: mp.rc, lambda: lamC } };
  }

  /* ---------------- external loads ---------------- */
  function loadActive(L, t) { return t >= L.t_start_s && t < L.t_start_s + L.duration_s; }
  /* torque about the pivot, expressed in body coordinates; R maps body → world */
  function loadTorqueBody(L, R) {
    var dir = unit3(L.direction);
    if (L.type === "force") {
      var Fb = L.frame === "world" ? mtv(R, mul3(dir, L.magnitude_N)) : mul3(dir, L.magnitude_N);
      return cross(L.point_m, Fb);
    }
    return L.frame === "world" ? mtv(R, mul3(dir, L.magnitude_Nm)) : mul3(dir, L.magnitude_Nm);
  }
  function loadForceWorld(L, R) { if (L.type !== "force") return [0, 0, 0]; var dir = unit3(L.direction); return L.frame === "world" ? mul3(dir, L.magnitude_N) : mv(R, mul3(dir, L.magnitude_N)); }
  function edgeR(theta) { return rotX(Math.PI / 4 + theta); }
  /* initial state. 'geometric': tilt measured from the attitude with the cube's diagonal vertical;
     'balance': tilt measured from the attitude with the centre of mass straight above the pivot */
  function initialState(cfg, mp) {
    var ini = cfg.initial, tilt = ini.tilt_deg * DEG, rate = ini.rate_dps * DEG;
    if (cfg.mode === "edge") {
      var th0 = ini.reference === "balance" ? tilt - mp.edge.beta : tilt;
      return { theta: th0, thetadot: rate, e: th0 + mp.edge.beta, clear: Math.PI / 4 - Math.abs(th0) };
    }
    var az = ini.azimuth_deg * DEG, rcu = mp.corner.u, bal = ini.reference === "balance";
    var tax = [Math.cos(az) * E1[0] + Math.sin(az) * E2[0], Math.cos(az) * E1[1] + Math.sin(az) * E2[1], Math.cos(az) * E1[2] + Math.sin(az) * E2[2]];
    var base = QEQ;
    if (bal) { base = Q3.fromTo(rcu, [0, 0, 1]); tax = unit3(projOn(tax, rcu)); if (norm3(tax) < 1e-9) tax = unit3(cross(rcu, [1, 0, 0])); }
    var q = tilt ? Q3.norm(Q3.mul(base, Q3.axis(tax, tilt))) : base.slice(), uB = mtv(Q3.rot(q), [0, 0, 1]);
    return { q: q, w: mul3(tax, rate), tiltAxis: tax, e: Math.acos(Math.max(-1, Math.min(1, dot(uB, rcu)))), clear: Math.asin(Math.max(-1, Math.min(1, Math.min(uB[0], uB[1], uB[2])))) };
  }

  /* ---------------- helpers for recording ---------------- */
  function r6(x) { return isFinite(x) ? +x.toPrecision(6) : x; }
  /* the recording schedule actually used (saved with the samples; the same fields as the research backend) */
  function recSchedule(cfg, fs, every, T) {
    var last = T.length ? T[T.length - 1] : null, prev = T.length > 1 ? T[T.length - 2] : null, real = fs / every;
    return { policy: "stride", text: (every > 1 ? "the state at every " + every + " control steps (every " + r6(every / fs) + " s)" : "the state at every control step") + " plus the final state of the run",
      requested_hz: cfg.record_hz, realized_hz: real, stride_steps: every, integration_hz: fs, matches_request: Math.abs(real - cfg.record_hz) <= 1e-9 * Math.max(1, cfg.record_hz),
      endpoint: "The state at the end of the executed run is always the last sample; if the run does not end on the stride grid (early termination, or a window that is not a multiple of the stride), the last interval is shorter.",
      t_end_s: last, final_interval_s: last != null && prev != null ? last - prev : null, rows: T.length, interpolation: "none (samples are integration-step states, no interpolation)" };
  }
  function wheelIndex(w) { return WHEELS.indexOf(w); }

  /* =====================================================================
     SIMULATION  (edge: planar hinge; corner: full 3-D rigid body about a point)
     ===================================================================== */
  function simulate(cfgIn, opts) {
    opts = opts || {};
    var v = validateConfig(cfgIn), cfg = v.config;
    if (!v.ok) return { ok: false, config: cfg, errors: v.errors, warnings: v.warnings, outcome: { code: "invalid", label: OUTCOMES.invalid.label, reason: v.errors.map(function (e) { return e.message; }).join(" ") } };
    var res = cfg.mode === "edge" ? simEdge(cfg, v.mp, v.design, opts) : simCorner(cfg, v.mp, v.design, opts);
    res.config = cfg; res.mp = v.mp; res.design = v.design; res.warnings = v.warnings; res.errors = [];
    if (res.numericalFailure) {
      res.ok = false; res.errors = [{ path: "solver", message: res.numericalFailure }];
      res.outcome = { code: "invalid", label: OUTCOMES.invalid.label, reason: "Numerical failure: " + res.numericalFailure };
      return res;
    }
    res.ok = true;
    var A = assess(res.full, { mode: cfg.mode, wmax: v.design.actuator.wmax, dt: 1 / cfg.params.fs, fellAt: res.fellAt, fallCause: res.fallCause, contactAt: res.contactAt, window_s: cfg.duration_s, failedWheels: res.failedWheels || [], hasYawCmd: cfg.commands.length > 0 });
    res.metrics = A.metrics; res.outcome = A.outcome;
    var dtS = 1 / cfg.params.fs;
    res.timeline = buildTimeline({ mode: cfg.mode, n: res.full.nSteps, tAt: function (k) { return k * dtS; }, satW: res.full.satW, om: res.full.om, wmax: v.design.actuator.wmax, estErr: res.full.estErr, cfg: cfg, metrics: A.metrics, fellAt: res.fellAt, fallCause: res.fallCause, contactAt: res.contactAt, failedWheels: res.failedWheels || [], windowEnd: cfg.duration_s, recordedEnd: res.full.nSteps * dtS, resolution_s: dtS });
    if (!opts.keepFull) delete res.full;
    return res;
  }

  /* Recording convention (zero-order hold): the sample at time t holds the state at t and the
     command the controller computed from that same state, which is then held until t + Δt.
     E(t) is the energy drawn up to t. After a fall the motors are off (T = 0). */
  function simEdge(cfg, mp, dz, opts) {
    var p = cfg.params, act = dz.actuator, dt = 1 / p.fs, Jw = p.Jw;
    var Thh = dz.plant.Thh, Mgl = dz.plant.mgl, beta = dz.plant.beta;
    var K = dz.tilt.K, pid = dz.tilt.pid, gam = dz.tilt.gam, ctrl = cfg.controller.type, betaRef = dz.betaRef;
    var loads = cfg.disturbances.filter(function (L) { return L.type === "force" || L.type === "torque"; });
    var failT = null; cfg.events.forEach(function (ev) { if (ev.type === "wheel_failure" && ev.wheel === "x") failT = failT === null ? ev.t_s : Math.min(failT, ev.t_s); });
    var est = cfg.estimator.type, N = rng(cfg.seed), Rkf = cfg.estimator.Rkf_deg !== undefined ? cfg.estimator.Rkf_deg * DEG : SENSOR.Rkf;
    var ini = initialState(cfg, mp), th = ini.theta, thd = ini.thetadot, ww = 0, I = 0, bh = 0;
    var SN = cfg.sensor, sg = SN.gyro_noise_dps * DEG, sbw = SN.gyro_bias_walk_dps * DEG, sa = SN.accel_noise_mps2 / 9.81;
    var qG = SN.gyro_quant_dps * DEG, qA = SN.accel_quant_deg * DEG, lagK = Math.round(SN.latency_ms / 1000 * p.fs), pDrop = SN.dropout, mbuf = [], lastM = null;
    var hX = cfg.actuator.wheel_health.x, lagA = cfg.actuator.motor_lag_ms > 0 ? 1 - Math.exp(-dt / (cfg.actuator.motor_lag_ms / 1000)) : 1, Tact = 0;
    var b = SN.gyro_bias_dps * DEG, thHat = 0, kx0 = 0, kx1 = 0, P00 = Math.pow(5 * DEG, 2), P01 = 0, P11 = Math.pow(1 * DEG, 2);
    var qa = SENSOR.sg * SENSOR.sg * dt * dt, qb = SENSOR.sbw * SENSOR.sbw * dt, Rk = Rkf * Rkf, alpha = SENSOR.tauCf / (SENSOR.tauCf + dt), thdd = 0;
    var n = Math.round(cfg.duration_s * p.fs), recEvery = Math.max(1, Math.round(p.fs / cfg.record_hz));
    var fallRad = ASSESS.fallEdgeDeg * DEG, contactRad = ASSESS.contactEdgeDeg * DEG;
    var S = { t: [], theta: [], thetadot: [], omega_x: [], T_x: [], Tc_x: [], e: [], betahat: [], thetahat: [], tauF: [], tauG: [], E: [], sat: [] };
    var full = { e: new Float64Array(n + 1), om: [new Float64Array(n + 1)], sat: new Uint8Array(n + 1), E: 0, effort: 0, nSteps: 0, estErr: est !== "ideal" ? new Float64Array(n + 1) : null };
    full.satW = [full.sat];
    var E = 0, fellAt = null, fallCause = null, contactAt = null, stopAt = n, failed = false;
    var OFF = { T: 0, Tc: 0, sat: 0 };
    function tauExt(t, th) { var s = 0; for (var i = 0; i < loads.length; i++) if (loadActive(loads[i], t)) s += loadTorqueBody(loads[i], edgeR(th))[0]; return s; }
    function f(th, thd, ww, T, t) {
      var Tn = failed ? -fric(act, ww) : T - fric(act, ww);
      var a = (Mgl * Math.sin(th + beta) + tauExt(t, th) - Tn) / Thh;
      return [thd, a, Tn / Jw - a];
    }
    function control(t) {
      if (failT !== null && t >= failT) failed = true;
      var thm = th, thdm = thd;                                   // sensing and estimation
      if (est !== "ideal") {
        b += sbw * Math.sqrt(dt) * N.n();
        var wm = thd + b + sg * N.n(), am = th - p.rImu * thdd / p.g + sa * N.n();
        if (qG > 0) wm = Math.round(wm / qG) * qG;                    // quantisation
        if (qA > 0) am = Math.round(am / qA) * qA;
        if (lagK > 0) { mbuf.push([wm, am]); if (mbuf.length > lagK + 1) mbuf.shift(); wm = mbuf[0][0]; am = mbuf[0][1]; }   // latency
        if (pDrop > 0) { if (lastM && N.u() < pDrop) { wm = lastM[0]; am = lastM[1]; } lastM = [wm, am]; }                  // dropout: hold the last packet
        if (est === "accel") { thm = am; thdm = wm; }
        else if (est === "gyro") { thHat += wm * dt; thm = thHat; thdm = wm; }
        else if (est === "cf") { thHat = alpha * (thHat + wm * dt) + (1 - alpha) * am; thm = thHat; thdm = wm; }
        else if (est === "kf") {
          kx0 = kx0 + (wm - kx1) * dt;
          var nP00 = P00 - dt * (P01 + P01) + dt * dt * P11 + qa, nP01 = P01 - dt * P11, nP11 = P11 + qb; P00 = nP00; P01 = nP01; P11 = nP11;
          var Sk = P00 + Rk, K0 = P00 / Sk, K1 = P01 / Sk, inn = am - kx0; kx0 += K0 * inn; kx1 += K1 * inn;
          var q00 = (1 - K0) * P00, q01 = (1 - K0) * P01, q11 = P11 - K1 * P01; P00 = q00; P01 = q01; P11 = q11;
          thm = kx0; thdm = wm - kx1;
        }
      }
      var bhUsed = bh, err = thm + betaRef, Tc = 0;                // control law: regulate the tilt about its reference
      if (fellAt === null) {
        if (ctrl === "pid") { I += err * dt; var Il = act.taumax / pid.Ki; if (I > Il) I = Il; else if (I < -Il) I = -Il; Tc = pid.Kp * err + pid.Ki * I + pid.Kd * thdm; }
        else if (ctrl === "lqr") Tc = -(K[0] * err + K[1] * thdm + K[2] * ww);
        else if (ctrl === "adp") Tc = -(K[0] * (err + bh) + K[1] * thdm + K[2] * ww);
      }
      var T = tauAvail(act, Tc, ww, hX), sat = Math.abs(T - Tc) > 1e-9 ? 1 : 0;
      if (failed) { T = 0; sat = Tc !== 0 ? 1 : 0; }
      if (lagA < 1) { Tact += (T - Tact) * lagA; T = Tact; }              // first-order motor torque lag
      if (ctrl === "adp" && fellAt === null && !sat && !failed) { bh += gam * ww * dt; if (bh > 6 * DEG) bh = 6 * DEG; else if (bh < -6 * DEG) bh = -6 * DEG; }
      if (fellAt !== null) return { T: 0, Tc: 0, sat: 0, thm: thm, bh: bhUsed };
      return { T: T, Tc: Tc, sat: sat, thm: thm, bh: bhUsed };
    }
    function rec(t, c) {
      S.t.push(r6(t)); S.theta.push(r6(th)); S.thetadot.push(r6(thd)); S.omega_x.push(r6(ww)); S.T_x.push(r6(c.T)); S.Tc_x.push(r6(c.Tc)); S.e.push(r6(th + beta));
      S.betahat.push(r6(c.bh != null ? c.bh : bh)); S.thetahat.push(r6(c.thm != null ? c.thm : th)); S.tauF.push(r6(tauExt(t, th))); S.tauG.push(r6(Mgl * Math.sin(th + beta))); S.E.push(r6(E)); S.sat.push(c.sat);
    }
    full.e[0] = th + beta; full.om[0][0] = ww;
    var k, ended = false;
    for (k = 0; k < n; k++) {
      var t = k * dt, c = control(t), T = c.T;
      full.sat[k] = c.sat; if (full.estErr) full.estErr[k] = c.thm - th;
      if (k % recEvery === 0) rec(t, c);
      var k1 = f(th, thd, ww, T, t), k2 = f(th + dt / 2 * k1[0], thd + dt / 2 * k1[1], ww + dt / 2 * k1[2], T, t + dt / 2),
        k3 = f(th + dt / 2 * k2[0], thd + dt / 2 * k2[1], ww + dt / 2 * k2[2], T, t + dt / 2), k4 = f(th + dt * k3[0], thd + dt * k3[1], ww + dt * k3[2], T, t + dt);
      th += dt / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]); thd += dt / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]); ww += dt / 6 * (k1[2] + 2 * k2[2] + 2 * k3[2] + k4[2]);
      if (!isFinite(th) || !isFinite(thd) || !isFinite(ww)) return { numericalFailure: "the state became non-finite at t = " + (t + dt).toFixed(3) + " s", samples: null };
      thdd = f(th, thd, ww, T, t + dt)[1];
      var ii = T / act.kt, Pel = ii * ii * act.R + T * ww; if (Pel > 0) E += Pel * dt;
      full.effort += Math.abs(T) * dt;
      full.e[k + 1] = th + beta; full.om[0][k + 1] = ww; full.nSteps = k + 1;
      var tn = t + dt;
      if (fellAt === null && (Math.abs(th + beta) > fallRad || Math.abs(th) >= contactRad)) { fellAt = tn; fallCause = Math.abs(th) >= contactRad ? "contact" : "lean"; stopAt = Math.min(n, k + 1 + Math.round(1.5 * p.fs)); }
      var touching = Math.abs(th) >= contactRad;
      if (touching) { th = Math.sign(th) * contactRad; thd = 0; if (contactAt === null) contactAt = tn; }
      if (touching || k + 1 >= stopAt) { rec(tn, fellAt !== null ? OFF : control(tn)); ended = true; break; }
    }
    if (!ended) rec(n * dt, control(n * dt));
    full.E = E;
    return {
      mode: "edge", samples: { rate_hz: p.fs / recEvery, schedule: recSchedule(cfg, p.fs, recEvery, S.t), fs: p.fs, convention: "zero-order hold: state at t and the command computed from it", cols: S, units: { t: "s", theta: "rad", thetadot: "rad/s", omega_x: "rad/s", T_x: "N·m", Tc_x: "N·m", e: "rad", betahat: "rad", thetahat: "rad", tauF: "N·m", tauG: "N·m", E: "J", sat: "0/1" } },
      full: full, fellAt: fellAt, fallCause: fallCause, contactAt: contactAt, energy: E, activeWheels: failed ? [] : ["x"], failedWheels: failed ? ["x"] : []
    };
  }

  function simCorner(cfg, mp, dz, opts) {
    var p = cfg.params, act = dz.actuator, dt = 1 / p.fs, Jw = p.Jw, g = p.g;
    var Th0 = dz.plant.Th0, Thhi = dz.plant.Thhi, M = dz.plant.M, rc = dz.plant.rc, rcu = unit3(rc);
    var D = dz.tilt, Y = dz.yaw, ctrl = cfg.controller.type, uRef = dz.uRef, reconf = cfg.controller.reconfigureOnFailure;
    var qRef = Q3.fromTo(uRef, [0, 0, 1]), qRefC = Q3.conj(qRef);
    var loads = cfg.disturbances.slice(), failEv = cfg.events.filter(function (e) { return e.type === "wheel_failure"; });
    var cmds = cfg.commands.filter(function (c) { return c.type === "yaw_step"; }).sort(function (a, b) { return a.t_s - b.t_s; });
    var ini = initialState(cfg, mp), q = ini.q.slice();
    var w = ini.w.slice(), ww = [0, 0, 0], I = [0, 0, 0], Iy = 0, bh = [0, 0, 0];
    var failed = [false, false, false], psiPrev = 0, psiTurns = 0, psi0 = null;
    var HW = [cfg.actuator.wheel_health.x, cfg.actuator.wheel_health.y, cfg.actuator.wheel_health.z], lagA = cfg.actuator.motor_lag_ms > 0 ? 1 - Math.exp(-dt / (cfg.actuator.motor_lag_ms / 1000)) : 1, Tact = [0, 0, 0];
    var n = Math.round(cfg.duration_s * p.fs), recEvery = Math.max(1, Math.round(p.fs / cfg.record_hz));
    var fallRad = ASSESS.fallCornerDeg * DEG, fallCause = null;
    var S = { t: [], q0: [], q1: [], q2: [], q3: [], wx: [], wy: [], wz: [], omega_x: [], omega_y: [], omega_z: [], T_x: [], T_y: [], T_z: [], Tc_x: [], Tc_y: [], Tc_z: [], e: [], geo: [], psi: [], psiRef: [], tauF_x: [], tauF_y: [], tauF_z: [], tauG_x: [], tauG_y: [], tauG_z: [], betahat_x: [], betahat_y: [], betahat_z: [], E: [], sat: [] };
    var full = { e: new Float64Array(n + 1), om: [new Float64Array(n + 1), new Float64Array(n + 1), new Float64Array(n + 1)], psi: new Float64Array(n + 1), psiRef: new Float64Array(n + 1), sat: new Uint8Array(n + 1), satW: [new Uint8Array(n + 1), new Uint8Array(n + 1), new Uint8Array(n + 1)], E: 0, effort: 0, nSteps: 0, estErr: null };
    var E = 0, fellAt = null, contactAt = null, stopAt = n;
    function extTorque(t, qq) { var s = [0, 0, 0], R = null; for (var i = 0; i < loads.length; i++) if (loadActive(loads[i], t)) { if (!R) R = Q3.rot(qq); s = add3(s, loadTorqueBody(loads[i], R)); } return s; }
    function deriv(qq, ww_b, wwh, TT, t) {
      var R = Q3.rot(qq), gB = mtv(R, [0, 0, -g]);
      var Tn = [0, 1, 2].map(function (i) { return failed[i] ? -fric(act, wwh[i]) : TT[i] - fric(act, wwh[i]); });
      var L = add3(mv(Th0, ww_b), mul3(wwh, Jw));
      var rhs = add3(add3(mul3(cross(ww_b, L), -1), mul3(cross(rc, gB), M)), sub3(extTorque(t, qq), Tn));
      var wd = mv(Thhi, rhs), qd = Q3.mul(qq, [0, ww_b[0], ww_b[1], ww_b[2]]);
      return { qd: [qd[0] / 2, qd[1] / 2, qd[2] / 2, qd[3] / 2], wd: wd, wwd: [Tn[0] / Jw - wd[0], Tn[1] / Jw - wd[1], Tn[2] / Jw - wd[2]] };
    }
    function sense() {
      var R = Q3.rot(q), uB = mtv(R, [0, 0, 1]);
      var qe = Q3.mul(qRefC, q), psi = 2 * Math.atan2(dot([qe[1], qe[2], qe[3]], uRef), qe[0]);
      var dpsi = psi - psiPrev; if (dpsi > Math.PI) psiTurns -= 2 * Math.PI; else if (dpsi < -Math.PI) psiTurns += 2 * Math.PI; psiPrev = psi;
      return { R: R, uB: uB, tht: cross(uB, uRef), psi: psi + psiTurns, psid: dot(w, uRef), e: Math.acos(Math.max(-1, Math.min(1, dot(uB, rcu)))), geo: Math.acos(Math.max(-1, Math.min(1, dot(uB, CH)))), clr: Math.min(uB[0], uB[1], uB[2]) };
    }
    function psiRef(t) { var r = psi0; for (var i = 0; i < cmds.length; i++) if (t >= cmds[i].t_s) r = psi0 + cmds[i].angle_deg * DEG; return r; }
    var OFF = { T: [0, 0, 0], Tc: [0, 0, 0], sat: 0, bh: null };
    function control(t, s) {
      var i;
      failEv.forEach(function (ev) { if (t >= ev.t_s) failed[wheelIndex(ev.wheel)] = true; });
      var Pw = projOn(w, uRef), Pww = projOn(ww, uRef), Tp = [0, 0, 0], Tc = 0, bhUsed = bh.slice();
      if (fellAt === null && ctrl !== "none") {
        if (ctrl === "pid") {
          for (i = 0; i < 3; i++) I[i] += s.tht[i] * dt;
          var In = norm3(I), Il = act.taumax / D.pid.Ki; if (In > Il) I = mul3(I, Il / In);
          Tp = [0, 1, 2].map(function (jj) { return D.pid.Kp * s.tht[jj] + D.pid.Ki * I[jj] + D.pid.Kd * Pw[jj]; });
        } else {
          var bb = ctrl === "adp" ? bh : [0, 0, 0];
          Tp = [0, 1, 2].map(function (jj) { return -(D.K[0] * (s.tht[jj] + bb[jj]) + D.K[1] * Pw[jj] + D.K[2] * Pww[jj]); });
        }
        var ey = s.psi - psiRef(t);
        if (ctrl === "pid") { Iy += ey * dt; Tc = Y.pid.Kp * ey + Y.pid.Ki * Iy + Y.pid.Kd * s.psid; } else Tc = -(Y.K[0] * ey + Y.K[1] * s.psid);
      }
      var TpP = projOn(Tp, uRef), Tdes, anyFail = failed[0] || failed[1] || failed[2];
      if (anyFail && reconf && fellAt === null) {
        var idx = [0, 1, 2].filter(function (kk) { return !failed[kk]; });
        Tdes = [0, 0, 0];
        if (idx.length === 2) {
          var cols = idx.map(function (kk) { var ek = [0, 0, 0]; ek[kk] = 1; return projOn(ek, uRef); });
          var a11 = dot(cols[0], cols[0]), a12 = dot(cols[0], cols[1]), a22 = dot(cols[1], cols[1]), b1 = dot(cols[0], TpP), b2 = dot(cols[1], TpP), dd = a11 * a22 - a12 * a12;
          Tdes[idx[0]] = (a22 * b1 - a12 * b2) / dd; Tdes[idx[1]] = (a11 * b2 - a12 * b1) / dd;
        } else if (idx.length === 1) { var e1 = [0, 0, 0]; e1[idx[0]] = 1; var c1 = projOn(e1, uRef); Tdes[idx[0]] = dot(c1, TpP) / Math.max(1e-12, dot(c1, c1)); }
      } else Tdes = add3(TpP, mul3(uRef, Tc));
      var T = [0, 1, 2].map(function (kk) { return tauAvail(act, Tdes[kk], ww[kk], HW[kk]); });
      var satd = 0, satW = [0, 0, 0]; for (i = 0; i < 3; i++) { if (failed[i]) { if (Tdes[i] !== 0) { satd = 1; satW[i] = 1; } T[i] = 0; } else if (Math.abs(T[i] - Tdes[i]) > 1e-9) { satd = 1; satW[i] = 1; } }
      if (lagA < 1) { for (i = 0; i < 3; i++) { Tact[i] += (T[i] - Tact[i]) * lagA; T[i] = Tact[i]; } }   // first-order motor torque lag
      if (ctrl === "adp" && fellAt === null && (!satd || anyFail)) { for (i = 0; i < 3; i++) bh[i] += D.gam * Pww[i] * dt; bh = projOn(bh, uRef); var nb = norm3(bh); if (nb > 6 * DEG) bh = mul3(bh, 6 * DEG / nb); }
      if (fellAt !== null) return { T: [0, 0, 0], Tc: [0, 0, 0], sat: 0, satW: [0, 0, 0], bh: bhUsed };
      return { T: T, Tc: Tdes, sat: satd, satW: satW, bh: bhUsed };
    }
    function rec(t, s, c) {
      var tf = extTorque(t, q), tg = mul3(cross(rc, mtv(s.R, [0, 0, -g])), M), bb = c.bh || bh;
      S.t.push(r6(t)); S.q0.push(r6(q[0])); S.q1.push(r6(q[1])); S.q2.push(r6(q[2])); S.q3.push(r6(q[3]));
      S.wx.push(r6(w[0])); S.wy.push(r6(w[1])); S.wz.push(r6(w[2])); S.omega_x.push(r6(ww[0])); S.omega_y.push(r6(ww[1])); S.omega_z.push(r6(ww[2]));
      S.T_x.push(r6(c.T[0])); S.T_y.push(r6(c.T[1])); S.T_z.push(r6(c.T[2])); S.Tc_x.push(r6(c.Tc[0])); S.Tc_y.push(r6(c.Tc[1])); S.Tc_z.push(r6(c.Tc[2]));
      S.e.push(r6(s.e)); S.geo.push(r6(s.geo)); S.psi.push(r6(s.psi - psi0)); S.psiRef.push(r6(psiRef(t) - psi0));
      S.tauF_x.push(r6(tf[0])); S.tauF_y.push(r6(tf[1])); S.tauF_z.push(r6(tf[2])); S.tauG_x.push(r6(tg[0])); S.tauG_y.push(r6(tg[1])); S.tauG_z.push(r6(tg[2]));
      S.betahat_x.push(r6(bb[0])); S.betahat_y.push(r6(bb[1])); S.betahat_z.push(r6(bb[2])); S.E.push(r6(E)); S.sat.push(c.sat);
    }
    var s0 = sense(); psi0 = s0.psi; full.e[0] = s0.e; full.psi[0] = 0; full.psiRef[0] = 0;
    var k, ended = false;
    for (k = 0; k < n; k++) {
      var t = k * dt, i, j, s = sense(), c = control(t, s), T = c.T;
      full.sat[k] = c.sat; for (j = 0; j < 3; j++) full.satW[j][k] = c.satW ? c.satW[j] : 0;
      if (k % recEvery === 0) rec(t, s, c);
      var st = function (kd, h) { return { q: [q[0] + h * kd.qd[0], q[1] + h * kd.qd[1], q[2] + h * kd.qd[2], q[3] + h * kd.qd[3]], w: add3(w, mul3(kd.wd, h)), ww: add3(ww, mul3(kd.wwd, h)) }; };
      var k1 = deriv(q, w, ww, T, t), s2 = st(k1, dt / 2), k2 = deriv(s2.q, s2.w, s2.ww, T, t + dt / 2), s3 = st(k2, dt / 2), k3 = deriv(s3.q, s3.w, s3.ww, T, t + dt / 2), s4 = st(k3, dt), k4 = deriv(s4.q, s4.w, s4.ww, T, t + dt);
      for (i = 0; i < 4; i++) q[i] += dt / 6 * (k1.qd[i] + 2 * k2.qd[i] + 2 * k3.qd[i] + k4.qd[i]);
      for (i = 0; i < 3; i++) { w[i] += dt / 6 * (k1.wd[i] + 2 * k2.wd[i] + 2 * k3.wd[i] + k4.wd[i]); ww[i] += dt / 6 * (k1.wwd[i] + 2 * k2.wwd[i] + 2 * k3.wwd[i] + k4.wwd[i]); }
      q = Q3.norm(q);
      if (!(q.every(isFinite) && w.every(isFinite) && ww.every(isFinite))) return { numericalFailure: "the state became non-finite at t = " + (t + dt).toFixed(3) + " s", samples: null };
      for (i = 0; i < 3; i++) { var ii = T[i] / act.kt, Pe = ii * ii * act.R + T[i] * ww[i]; if (Pe > 0) E += Pe * dt; full.effort += Math.abs(T[i]) * dt; }
      var tn = t + dt, s1 = sense();
      full.e[k + 1] = s1.e; for (j = 0; j < 3; j++) full.om[j][k + 1] = ww[j]; full.psi[k + 1] = s1.psi - psi0; full.psiRef[k + 1] = psiRef(tn) - psi0; full.nSteps = k + 1;
      if (fellAt === null && (s1.e > fallRad || s1.clr <= 0)) { fellAt = tn; fallCause = s1.clr <= 0 ? "contact" : "lean"; stopAt = Math.min(n, k + 1 + Math.round(1.5 * p.fs)); }
      var touching = s1.clr <= 0;
      if (touching && contactAt === null) contactAt = tn;
      if (touching || k + 1 >= stopAt) { rec(tn, s1, fellAt !== null ? OFF : control(tn, s1)); ended = true; break; }
    }
    if (!ended) { var sN = sense(); rec(n * dt, sN, control(n * dt, sN)); }
    full.E = E;
    var activeWheels = WHEELS.filter(function (_, i) { return !failed[i]; });
    full.activeIdx = [0, 1, 2].filter(function (i) { return !failed[i]; });
    var units = { t: "s", q0: "–", q1: "–", q2: "–", q3: "–", wx: "rad/s", wy: "rad/s", wz: "rad/s", omega_x: "rad/s", omega_y: "rad/s", omega_z: "rad/s", T_x: "N·m", T_y: "N·m", T_z: "N·m", Tc_x: "N·m", Tc_y: "N·m", Tc_z: "N·m", e: "rad", geo: "rad", psi: "rad", psiRef: "rad", tauF_x: "N·m", tauF_y: "N·m", tauF_z: "N·m", tauG_x: "N·m", tauG_y: "N·m", tauG_z: "N·m", betahat_x: "rad", betahat_y: "rad", betahat_z: "rad", E: "J", sat: "0/1" };
    return { mode: "corner", samples: { rate_hz: p.fs / recEvery, schedule: recSchedule(cfg, p.fs, recEvery, S.t), fs: p.fs, convention: "zero-order hold: state at t and the command computed from it", cols: S, units: units }, full: full, fellAt: fellAt, fallCause: fallCause, contactAt: contactAt, energy: E, activeWheels: activeWheels, psi0: psi0, failedWheels: WHEELS.filter(function (_, i) { return failed[i]; }) };
  }

  /* =====================================================================
     ASSESSMENT — the only place outcomes and metrics are decided
     ===================================================================== */
  function linfit(ts, ys) {
    var n = ts.length; if (n < 3) return { slope: 0, r2: 0 };
    var mt = 0, my = 0, i; for (i = 0; i < n; i++) { mt += ts[i]; my += ys[i]; } mt /= n; my /= n;
    var sxy = 0, sxx = 0, syy = 0; for (i = 0; i < n; i++) { var a = ts[i] - mt, b = ys[i] - my; sxy += a * b; sxx += a * a; syy += b * b; }
    var slope = sxx > 0 ? sxy / sxx : 0, r2 = sxx > 0 && syy > 0 ? (sxy * sxy) / (sxx * syy) : 0;
    return { slope: slope, r2: r2 };
  }
  function settleTime(vals, dt, n, tol, hold) {
    // earliest index after which |v| <= tol for the rest of the window, with the hold satisfied
    var last = -1; for (var i = 0; i <= n; i++) if (Math.abs(vals(i)) > tol) last = i;
    var tStart = last < 0 ? 0 : (last + 1) * dt, tEnd = n * dt;
    if (last >= n) return null;
    if (tEnd - tStart + 1e-12 < hold) return null;
    return tStart;
  }
  function assess(full, ctx) {
    var n = full.nSteps, dt = ctx.dt, tEnd = n * dt, e = full.e, i, j;
    var active = ctx.mode === "edge" ? [0] : (full.activeIdx || [0, 1, 2]);
    var tol = ASSESS.settleTolDeg * DEG, hold = ASSESS.holdMinS, wtol = ASSESS.momentumTolRpm * RPM;
    var m = { window_s: ctx.window_s != null ? ctx.window_s : tEnd, recorded_s: tEnd, e0_deg: e[0] / DEG };
    // peak lean, overshoot
    var peak = 0, peakT = 0, os = 0, sgn = e[0] >= 0 ? 1 : -1;
    for (i = 0; i <= n; i++) { var ae = Math.abs(e[i]); if (ae > peak) { peak = ae; peakT = i * dt; } if (ctx.mode === "edge") { var ov = -sgn * e[i]; if (ov > os) os = ov; } }
    m.peakLean_deg = peak / DEG; m.peakLean_t = peakT;
    m.overshoot_deg = ctx.mode === "edge" && Math.abs(e[0]) > tol ? os / DEG : null;
    // settling (only if the run did not fall)
    m.settle_s = ctx.fellAt === null ? settleTime(function (k) { return e[k]; }, dt, n, tol, hold) : null;
    m.tOmega_s = ctx.fellAt === null ? settleTime(function (k) { var mx = 0; active.forEach(function (a) { mx = Math.max(mx, Math.abs(full.om[a][k])); }); return mx; }, dt, n, wtol, hold) : null;
    // final window lean
    var fw = Math.min(ASSESS.finalWindowMaxS, ASSESS.finalWindowFrac * tEnd), k0 = Math.max(0, Math.round((tEnd - fw) / dt)), s = 0, c = 0;
    for (i = k0; i <= n; i++) { s += Math.abs(e[i]); c++; }
    m.finalLean_deg = c ? s / c / DEG : null; m.finalWindow_s = fw;
    // wheels
    var pk = 0, pkWheel = null, pkT = 0;
    for (j = 0; j < full.om.length; j++) for (i = 0; i <= n; i++) { var aw = Math.abs(full.om[j][i]); if (aw > pk) { pk = aw; pkWheel = WHEELS[j]; pkT = i * dt; } }
    m.peakOmega_rpm = pk / RPM; m.peakOmega_wheel = pkWheel; m.peakOmega_t = pkT; m.peakOmega_frac = pk / ctx.wmax;
    m.finalOmega_rpm = {}; for (j = 0; j < full.om.length; j++) m.finalOmega_rpm[WHEELS[j]] = full.om[j][n] / RPM;
    var satN = 0; for (i = 0; i < n; i++) satN += full.sat[i]; m.torqueLimited_s = satN * dt;
    var reachedLimit = pk >= ASSESS.satSpeedFrac * ctx.wmax; m.wheelAtLimit = reachedLimit;
    m.energy_J = full.E; m.fellAt_s = ctx.fellAt; m.contactAt_s = ctx.contactAt;
    // research metrics (definitions in METRIC_DEFS: rms, effort, speedLimited, leanMargin, omegaMargin)
    var ss = 0; for (i = 0; i <= n; i++) ss += e[i] * e[i];
    m.rmsLean_deg = Math.sqrt(ss / (n + 1)) / DEG;
    m.effort_Nms = typeof full.effort === "number" ? full.effort : null;
    var spN = 0, spLim = ASSESS.satSpeedFrac * ctx.wmax;
    for (i = 0; i < n; i++) { for (j = 0; j < active.length; j++) if (Math.abs(full.om[active[j]][i]) >= spLim) { spN++; break; } }
    m.speedLimited_s = spN * dt;
    m.leanMargin_deg = ctx.fellAt === null ? (ctx.mode === "edge" ? ASSESS.fallEdgeDeg : ASSESS.fallCornerDeg) - m.peakLean_deg : null;
    m.omegaMargin_frac = 1 - m.peakOmega_frac;
    // drift detection over the final window
    var dw = Math.max(ASSESS.driftWindowMinS, Math.min(ASSESS.driftWindowMaxS, ASSESS.driftWindowFrac * tEnd)), d0 = Math.max(0, Math.round((tEnd - dw) / dt));
    function trend(getter) {
      var ts = [], ys = []; for (var k = d0; k <= n; k++) { ts.push(k * dt); ys.push(getter(k)); }
      var h = Math.floor(ts.length / 2), all = linfit(ts, ys), a = linfit(ts.slice(0, h), ys.slice(0, h)), b = linfit(ts.slice(h), ys.slice(h));
      return { slope: all.slope, r2: all.r2, s1: a.slope, s2: b.slope, end: ys[ys.length - 1] };
    }
    var drift = null;
    if (ctx.fellAt === null && tEnd >= 2 * ASSESS.driftWindowMinS) {
      active.forEach(function (a) {
        var tr_ = trend(function (k) { return Math.abs(full.om[a][k]); });
        var steady = tr_.s1 > 0 && tr_.s2 >= ASSESS.driftPersist * tr_.s1;
        if (tr_.slope >= ASSESS.driftWheelSlopeFrac * ctx.wmax && tr_.r2 >= ASSESS.driftR2 && steady && tr_.end > wtol) {
          var proj_ = tEnd + (ctx.wmax - tr_.end) / tr_.slope;
          if (!drift || proj_ < drift.projected_s) drift = { kind: "wheel", wheel: WHEELS[a], slope_rpm_s: tr_.slope / RPM, r2: tr_.r2, end_rpm: tr_.end / RPM, projected_s: proj_ };
        }
      });
      if (!drift) {
        var tl = trend(function (k) { return Math.abs(e[k]); }), steadyL = tl.s1 > 0 && tl.s2 >= ASSESS.driftPersist * tl.s1;
        if (tl.slope >= ASSESS.driftLeanSlopeDps * DEG && tl.r2 >= ASSESS.driftR2 && steadyL && tl.end > tol) drift = { kind: "lean", slope_dps: tl.slope / DEG, r2: tl.r2, end_deg: tl.end / DEG };
      }
    }
    m.drift = drift; m.driftWindow_s = dw;
    // yaw (corner mode)
    if (ctx.mode === "corner" && full.psi) {
      var ty = [], yy = []; for (i = d0; i <= n; i++) { ty.push(i * dt); yy.push(full.psi[i]); }
      m.yawFinal_deg = full.psi[n] / DEG; m.yawErrFinal_deg = (full.psi[n] - full.psiRef[n]) / DEG; m.yawRate_dps = linfit(ty, yy).slope / DEG;
    } else { m.yawFinal_deg = null; m.yawErrFinal_deg = null; m.yawRate_dps = null; }
    // momentum margin at the end of the window
    var endW = null, endV = 0; active.forEach(function (a) { var v = Math.abs(full.om[a][n]); if (v >= endV) { endV = v; endW = WHEELS[a]; } });
    m.endOmega_rpm = endV / RPM; m.endOmega_wheel = endW; m.endOmega_frac = endV / ctx.wmax;
    // outcome
    var code, reason, notes = [];
    if (ctx.failedWheels && ctx.failedWheels.length) notes.push("Wheel " + ctx.failedWheels.map(function (w) { return w.toUpperCase(); }).join(", ") + " failed during the run.");
    if (ctx.fellAt !== null) {
      code = "fallen";
      reason = (ctx.fallCause === "contact" ? "The cube touched the floor at t = " + ctx.fellAt.toFixed(2) + " s" : "COM lean passed the " + (ctx.mode === "edge" ? ASSESS.fallEdgeDeg : ASSESS.fallCornerDeg) + "° fall threshold at t = " + ctx.fellAt.toFixed(2) + " s") + (reachedLimit ? " after a wheel reached " + Math.round(m.peakOmega_frac * 100) + " % of its speed limit" : "") + ".";
    } else if (drift) {
      code = "drifting";
      reason = drift.kind === "wheel" ? "Wheel " + drift.wheel.toUpperCase() + " speed is still rising steadily at " + Math.round(drift.slope_rpm_s) + " rpm/s at the end of the window (" + Math.round(drift.end_rpm) + " rpm); at that rate it reaches its " + Math.round(ctx.wmax / RPM) + " rpm limit at about t = " + drift.projected_s.toFixed(1) + " s." + (m.settle_s === null ? " The COM lean is also outside ±" + ASSESS.settleTolDeg + "°." : "")
        : "The COM lean is still growing at " + drift.slope_dps.toFixed(2) + " °/s at the end of the window (|e| = " + drift.end_deg.toFixed(2) + "°).";
    } else if (m.settle_s !== null) {
      code = "recovered"; reason = "|e| stayed within ±" + ASSESS.settleTolDeg + "° from t = " + m.settle_s.toFixed(2) + " s to the end of the window (" + (tEnd - m.settle_s).toFixed(2) + " s ≥ " + ASSESS.holdMinS + " s), and no wheel is trending toward its limit.";
      if (m.tOmega_s === null && endW) notes.push("Wheel momentum has not returned to within ±" + ASSESS.momentumTolRpm + " rpm: wheel " + endW.toUpperCase() + " ends at " + Math.round(m.endOmega_rpm) + " rpm (" + Math.round(m.endOmega_frac * 100) + " % of its limit)" + (m.endOmega_frac > 0.8 ? ", leaving little margin for another disturbance in the same direction." : "."));
    } else {
      code = "not_settled"; reason = "The run did not fall and nothing is drifting, but |e| was not within ±" + ASSESS.settleTolDeg + "° for the final " + ASSESS.holdMinS + " s (final-window mean " + (m.finalLean_deg || 0).toFixed(2) + "°). A longer window may show whether it settles.";
    }
    if (code !== "fallen" && ctx.mode === "corner" && m.yawFinal_deg !== null) {
      var failedAny = ctx.failedWheels && ctx.failedWheels.length, turning = Math.abs(m.yawRate_dps) > 1;
      if (failedAny && (turning || Math.abs(m.yawFinal_deg) > 5)) notes.push("Yaw is not controlled after a wheel failure (balance has priority): it ended at " + m.yawFinal_deg.toFixed(0) + "°" + (turning ? ", still turning at " + m.yawRate_dps.toFixed(1) + " °/s." : "."));
      else if (turning) notes.push("Yaw is still turning at " + m.yawRate_dps.toFixed(1) + " °/s at the end of the window.");
      else if (ctx.hasYawCmd && Math.abs(m.yawErrFinal_deg) > 2) notes.push("Yaw ends " + m.yawErrFinal_deg.toFixed(1) + "° from the commanded heading.");
    }
    return { metrics: m, outcome: { code: code, label: OUTCOMES[code].label, tone: OUTCOMES[code].tone, reason: reason, notes: notes } };
  }

  /* =====================================================================
     EVENT TIMELINE — inputs from the configuration plus events detected in
     the state history. Used for new runs (every integration step) and for
     older records (recorded samples; see js/platform/events.js).
     x = { mode, n, tAt(i), satW:[per-wheel 0/1 arrays], om:[per-wheel arrays, rad/s],
           wmax, estErr (array|null, rad), cfg (normalised), metrics, fellAt, fallCause,
           contactAt, failedWheels, windowEnd, recordedEnd, resolution_s, satAggregate }
     ===================================================================== */
  function intervalsOf(flagAt, n, tAt, gap) {
    var raw = [], on = false, t0 = 0, i;
    for (i = 0; i <= n; i++) { var f = !!flagAt(i); if (f && !on) { on = true; t0 = tAt(i); } else if (!f && on) { on = false; raw.push({ t0: t0, t1: tAt(i), open: false }); } }
    if (on) raw.push({ t0: t0, t1: tAt(n), open: true });
    var out = [];
    raw.forEach(function (iv) { var last = out[out.length - 1]; if (last && iv.t0 - last.t1 < gap) { last.t1 = iv.t1; last.open = iv.open; } else out.push(iv); });
    return out;
  }
  function r4(x) { return Math.round(x * 1e4) / 1e4; }
  function buildTimeline(x) {
    var ev = [], cfg = x.cfg || {}, edge = x.mode === "edge", R = EVENT_RULES, n = x.n, tAt = x.tAt;
    var failT = [null, null, null];
    (cfg.events || []).forEach(function (e) { var w = wheelIndex(e.wheel); if (e.type === "wheel_failure" && w >= 0 && (!edge || w === 0) && (failT[w] === null || e.t_s < failT[w])) failT[w] = e.t_s; });
    function push(o) { o.t = r4(o.t); if (o.t_end != null) o.t_end = r4(o.t_end); ev.push(o); }
    function capped(list, kind, mk) {
      if (list.length <= R.maxPerKind) { list.forEach(mk); return; }
      list.slice(0, R.maxPerKind - 1).forEach(mk);
      var rest = list.slice(R.maxPerKind - 1), tot = rest.reduce(function (s, iv) { return s + (iv.t1 - iv.t0); }, 0);
      push({ t: rest[0].t0, t_end: rest[rest.length - 1].t1, type: kind, severity: "warning", source: "detected", label: "… " + rest.length + " more " + (kind === "saturation" ? "saturation" : "speed-limit") + " intervals", detail: "Combined " + tot.toFixed(2) + " s; listed individually up to " + (R.maxPerKind - 1) + "." });
    }
    // ---- scheduled inputs
    (cfg.disturbances || []).forEach(function (L) {
      if (!(L.t_start_s < x.windowEnd)) return;
      push({ t: L.t_start_s, t_end: Math.min(x.windowEnd, L.t_start_s + L.duration_s), type: "disturbance", severity: "info", source: "input", ref: L.id, label: (L.type === "force" ? "Force " : "Torque ") + L.id + " applied", detail: (L.type === "force" ? L.magnitude_N + " N at (" + (L.point_m || []).map(function (v) { return Math.round(v * 1000); }).join(", ") + ") mm" : L.magnitude_Nm + " N·m") + ", " + L.frame + " frame, for " + L.duration_s + " s." });
    });
    (cfg.events || []).forEach(function (e) {
      if (e.type !== "wheel_failure" || !(e.t_s < x.windowEnd)) return;
      var used = !edge || e.wheel === "x";
      push({ t: e.t_s, type: "wheel_failure", severity: used ? "failure" : "info", source: "input", wheel: e.wheel, ref: e.id, label: "Wheel " + String(e.wheel).toUpperCase() + " failed", detail: used ? "No motor torque from this wheel from now on." : "Edge mode does not drive this wheel, so the failure has no effect." });
      if (used && !edge && cfg.controller && cfg.controller.reconfigureOnFailure) push({ t: e.t_s, type: "controller_mode", severity: "warning", source: "detected", label: "Controller reconfigured", detail: "Torque reallocated to the healthy wheels (least squares); yaw control given up." });
    });
    (cfg.commands || []).forEach(function (c) { if (c.type === "yaw_step" && c.t_s < x.windowEnd) push({ t: c.t_s, type: "yaw_command", severity: "info", source: "input", ref: c.id, label: "Yaw command " + c.angle_deg + "°", detail: "Commanded heading about the balance axis." }); });
    // ---- detected: torque saturation per wheel (a failed wheel is reported as failed, not as saturated)
    var nW = x.satW ? x.satW.length : 0;
    for (var w = 0; w < nW; w++) {
      var arr = x.satW[w]; if (!arr) continue;
      var fw = failT[w];
      var ivs = intervalsOf(function (i) { return arr[i] && (fw === null || tAt(i) < fw); }, n, tAt, R.mergeGapS);
      var wl = x.satAggregate ? "" : "Wheel " + WHEELS[w].toUpperCase() + " ";
      capped(ivs, "saturation", function (iv) { push({ t: iv.t0, t_end: iv.t1, type: "saturation", severity: "warning", source: "detected", wheel: x.satAggregate ? null : WHEELS[w], label: wl + "torque saturated" + (x.satAggregate ? " (a wheel)" : ""), detail: "Commanded torque above what the driver can deliver" + (iv.open ? "; still saturated at the end of the recording." : ".") + " Duration " + (iv.t1 - iv.t0).toFixed(3) + " s." }); });
    }
    // ---- detected: wheel speed near / at the limit
    (x.om || []).forEach(function (om, wi) {
      if (!om || (edge && wi > 0)) return;
      var risk = intervalsOf(function (i) { return Math.abs(om[i]) >= R.speedRiskFrac * x.wmax; }, n, tAt, R.mergeGapS);
      capped(risk, "speed_risk", function (iv) { push({ t: iv.t0, t_end: iv.t1, type: "speed_risk", severity: "warning", source: "detected", wheel: WHEELS[wi], label: "Wheel " + WHEELS[wi].toUpperCase() + " saturation risk", detail: "Speed at or above " + Math.round(R.speedRiskFrac * 100) + " % of the " + Math.round(x.wmax / RPM) + " rpm limit for " + (iv.t1 - iv.t0).toFixed(2) + " s." }); });
      var lim = intervalsOf(function (i) { return Math.abs(om[i]) >= R.speedLimitFrac * x.wmax; }, n, tAt, R.mergeGapS);
      capped(lim, "speed_limit", function (iv) { push({ t: iv.t0, t_end: iv.t1, type: "speed_limit", severity: "warning", source: "detected", wheel: WHEELS[wi], label: "Wheel " + WHEELS[wi].toUpperCase() + " at its speed limit", detail: "Speed at or above " + Math.round(R.speedLimitFrac * 100) + " % of the limit for " + (iv.t1 - iv.t0).toFixed(2) + " s." }); });
    });
    // ---- detected: estimator error
    if (x.estErr) {
      var tol = R.estErrDeg * DEG, first = null, since = null;
      for (var i = 0; i <= n; i++) {
        if (Math.abs(x.estErr[i]) > tol) { if (since === null) since = tAt(i); if (tAt(i) - since >= R.estErrHoldS) { first = since; break; } } else since = null;
      }
      if (first !== null) push({ t: first, type: "estimator_warning", severity: "warning", source: "detected", label: "Estimator warning", detail: "Estimated tilt more than " + R.estErrDeg + "° from the true tilt for at least " + R.estErrHoldS + " s (first occurrence)." });
    }
    // ---- detected: outcome milestones
    var M = x.metrics || {};
    if (M.settle_s != null) push({ t: M.settle_s, type: "recovered", severity: "stable", source: "detected", label: "Stability recovered", detail: "|e| within ±" + ASSESS.settleTolDeg + "° from here to the end of the window." });
    if (x.fellAt != null) push({ t: x.fellAt, type: "fall", severity: "failure", source: "detected", label: x.fallCause === "contact" ? "Fall: floor contact" : "Fall: lean threshold passed", detail: x.fallCause === "contact" ? "Part of the cube reached the floor; motors stop." : "COM lean passed " + (edge ? ASSESS.fallEdgeDeg : ASSESS.fallCornerDeg) + "°; motors stop." });
    if (x.contactAt != null && x.contactAt !== x.fellAt) push({ t: x.contactAt, type: "floor_contact", severity: "failure", source: "detected", label: "Floor contact", detail: "Part of the cube reached the floor." });
    push({ t: x.recordedEnd, type: "termination", severity: "info", source: "detected", label: x.fellAt != null ? "Recording stopped after the fall" : "End of observation window", detail: x.fellAt != null ? "Recorded until floor contact or 1.5 s after the fall." : "Window " + x.windowEnd + " s." });
    var order = { input: 0, detected: 1 };
    ev.sort(function (a, b) { return a.t - b.t || (order[a.source] - order[b.source]); });
    return { rules: EVENT_RULES, resolution_s: x.resolution_s, events: ev };
  }

  /* =====================================================================
     Lab helpers (nominal design): capture-region grid and controllability
     ===================================================================== */
  function doaEdge(p, dsg, ctrl, opts, done, progress) {
    var nth = opts.nth || 33, nthd = opts.nthd || 33, thR = opts.thR || 8 * DEG, thdR = opts.thdR || 80 * DEG, Tend = opts.T || 4;
    var res = new Int8Array(nth * nthd), idx = 0, total = nth * nthd;
    var d = dsg.d, Dd = dsg.e, M = Dd.M, dt = d.dt, K = Dd.K, pid = Dd.pid, gam = Dd.gam, Thh = M.Thh, mgl = M.mgl;
    var n = Math.round(Tend * p.fs), tail = Math.round(ASSESS.holdMinS * p.fs);   // same band, hold and fall rules as every run
    function one(th, thd) {
      var ww = 0, I = 0, bh = 0, sat = false, tailMax = 0;
      function f(th, thd, ww, T) { var Tn = T - fric(d, ww), a = (mgl * Math.sin(th) - Tn) / Thh; return [thd, a, Tn / d.Jw - a]; }
      for (var k = 0; k < n; k++) {
        var Tc;
        if (ctrl === "pid") { I += th * dt; var Il = d.taumax / pid.Ki; if (I > Il) I = Il; else if (I < -Il) I = -Il; Tc = pid.Kp * th + pid.Ki * I + pid.Kd * thd; }
        else if (ctrl === "lqr") Tc = -(K[0] * th + K[1] * thd + K[2] * ww); else Tc = -(K[0] * (th + bh) + K[1] * thd + K[2] * ww);
        var T = tauAvail(d, Tc, ww);
        if (Math.abs(T - Tc) > 1e-9) sat = true; else if (ctrl === "adp") bh += gam * ww * dt;
        if (ctrl === "adp") { if (bh > 6 * DEG) bh = 6 * DEG; else if (bh < -6 * DEG) bh = -6 * DEG; }
        var k1 = f(th, thd, ww, T), k2 = f(th + dt / 2 * k1[0], thd + dt / 2 * k1[1], ww + dt / 2 * k1[2], T), k3 = f(th + dt / 2 * k2[0], thd + dt / 2 * k2[1], ww + dt / 2 * k2[2], T), k4 = f(th + dt * k3[0], thd + dt * k3[1], ww + dt * k3[2], T);
        th += dt / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]); thd += dt / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]); ww += dt / 6 * (k1[2] + 2 * k2[2] + 2 * k3[2] + k4[2]);
        if (!isFinite(th) || Math.abs(th) > ASSESS.fallEdgeDeg * DEG) return 0;
        if (k >= n - tail && Math.abs(th) > tailMax) tailMax = Math.abs(th);
      }
      if (tailMax > ASSESS.settleTolDeg * DEG) return 0;
      return sat ? 1 : 2;
    }
    function chunk() {
      var t0 = Date.now();
      while (idx < total && Date.now() - t0 < 24) { var i = idx % nth, j = Math.floor(idx / nth); res[idx] = one(-thR + 2 * thR * i / (nth - 1), -thdR + 2 * thdR * j / (nthd - 1)); idx++; }
      if (progress) progress(idx / total);
      if (idx < total) setTimeout(chunk, 0);
      else {
        var rec = 0, clean = 0; for (var q = 0; q < total; q++) { if (res[q] > 0) rec++; if (res[q] === 2) clean++; }
        var mid = Math.floor(nthd / 2), lo = 0, hi = 0;
        for (i = 0; i < nth; i++) { var th = -thR + 2 * thR * i / (nth - 1); if (res[mid * nth + i] > 0) { if (th < lo) lo = th; if (th > hi) hi = th; } }
        done({ res: res, nth: nth, nthd: nthd, thR: thR, thdR: thdR, frac: rec / total, clean: clean / total, capLo: lo, capHi: hi });
      }
    }
    if (opts.sync) { while (idx < total) { var i2 = idx % nth, j2 = Math.floor(idx / nth); res[idx] = one(-thR + 2 * thR * i2 / (nth - 1), -thdR + 2 * thdR * j2 / (nthd - 1)); idx++; } chunk(); } else chunk();
  }
  function rank(Mx, tol) {
    var A = Mx.map(function (r) { return r.slice(); }), n = A.length, m = A[0].length, rnk = 0, i, j;
    for (j = 0; j < m; j++) { var s = 0; for (i = 0; i < n; i++) s += A[i][j] * A[i][j]; s = Math.sqrt(s); if (s > 0) for (i = 0; i < n; i++) A[i][j] /= s; }
    var used = new Array(m).fill(false);
    for (var r = 0; r < n; r++) {
      var bi = -1, bj = -1, bv = 0;
      for (i = r; i < n; i++) for (j = 0; j < m; j++) if (!used[j] && Math.abs(A[i][j]) > bv) { bv = Math.abs(A[i][j]); bi = i; bj = j; }
      if (bv < (tol || 1e-8)) break;
      var t = A[r]; A[r] = A[bi]; A[bi] = t; used[bj] = true; rnk++;
      for (i = r + 1; i < n; i++) { var f = A[i][bj] / A[r][bj]; if (f) for (j = 0; j < m; j++) A[i][j] -= f * A[r][j]; }
    }
    return rnk;
  }
  function cornerRank(dsg, wheels) {
    var d = dsg.d, a = d.a, m = d.m, rc = [a / 2, a / 2, a / 2], i, j;
    var Th0 = madd(eye3(d.Jc), steiner(m, rc)), Thh = madd(Th0, eye3(d.Jw), -1), Ti = inv(Thh);
    var P = zeros(3, 3); for (i = 0; i < 3; i++) for (j = 0; j < 3; j++) P[i][j] = (i === j ? 1 : 0) - CH[i] * CH[j];
    var G = mul(Ti, P).map(function (r) { return r.map(function (v) { return v * d.mglc; }); });
    var A = zeros(9, 9), B = zeros(9, wheels.length);
    for (i = 0; i < 3; i++) { A[i][3 + i] = 1; for (j = 0; j < 3; j++) { A[3 + i][j] = G[i][j]; A[6 + i][j] = -G[i][j]; } }
    wheels.forEach(function (w, c) { for (i = 0; i < 3; i++) { B[3 + i][c] = -Ti[i][w]; B[6 + i][c] = (i === w ? 1 / d.Jw : 0) + Ti[i][w]; } });
    var As = A.map(function (r) { return r.map(function (v) { return v / d.lamc; }); }), cols = [], X = B;
    for (var k = 0; k < 9; k++) { cols.push(X); X = mul(As, X); }
    var Kc = zeros(9, 9 * wheels.length);
    cols.forEach(function (Xk, k) { for (i = 0; i < 9; i++) for (j = 0; j < wheels.length; j++) Kc[i][k * wheels.length + j] = Xk[i][j]; });
    return rank(Kc, 1e-7);
  }

  return {
    DEG: DEG, RPM: RPM, VERSION: VERSION, NOMINAL: NOMINAL, PARAM_SPEC: PARAM_SPEC, WEIGHTS: WEIGHTS, SENSOR: SENSOR,
    ASSESS: ASSESS, OUTCOMES: OUTCOMES, METRIC_DEFS: METRIC_DEFS, WHEELS: WHEELS, EVENT_RULES: EVENT_RULES, EVENT_DEFS: EVENT_DEFS, buildTimeline: buildTimeline,
    SENSOR_DEFAULTS: SENSOR_DEFAULTS, SENSOR_SPEC: SENSOR_SPEC, ACTUATOR_DEFAULTS: ACTUATOR_DEFAULTS,
    clone: clone, derive: derive, design: design, designTilt: designTilt, designYaw: designYaw,
    la: { zeros: zeros, eye: eye, mul: mul, add: add, inv: inv, det: det, tr: tr, care: care, lqr: lqr, eig: eig, charPoly: charPoly, roots: roots, polyFromRoots: polyFromRoots, sym3eig: sym3eig },
    vec: { add3: add3, sub3: sub3, mul3: mul3, dot: dot, cross: cross, norm3: norm3, unit3: unit3, mv: mv, mtv: mtv, steiner: steiner },
    tauAvail: tauAvail, fric: fric, rng: rng,
    defaultConfig: defaultConfig, normalizeConfig: normalizeConfig, massProps: massProps,
    validateParams: validateParams, validateConfig: validateConfig, designForConfig: designForConfig,
    simulate: simulate, assess: assess, initialState: initialState, loadActive: loadActive, loadTorqueBody: loadTorqueBody, loadForceWorld: loadForceWorld, edgeR: edgeR,
    doaEdge: doaEdge, rank: rank, cornerRank: cornerRank,
    Q3: Q3, CH: CH, QEQ: QEQ, E1: E1, E2: E2, D_EDGE: D_EDGE, N_EDGE: N_EDGE, proj: proj, projOn: projOn, rotX: rotX
  };
})();
if (typeof module !== "undefined") module.exports = AERIS_TWIN;

# AERIS v5.1 · Software completion report

> **Historical (v5.1, as delivered).** Superseded by `SOFTWARE_COMPLETION_REPORT.md` (v5.2). The `test-logs/` run this
> report cites is preserved unchanged in `evidence/v5.1-release/test-logs/`; the repository's `test-logs/` now holds
> the v5.2 run. The independent review of v5.1 found four issues (G1–G4) in what this report marks as passed; see
> `evidence/v5.1-independent-review/` and the v5.2 report.

Scope: a focused completion pass on the independent review of the delivered v5 (findings F1–F5). Baseline: v5 git
head `1023e09005dd5271a7cae7602222e5c9088902a1`, archive `aeris-site-v5.zip` SHA-256
`11312c94ada527b6d14bdbd50bf6a9e66730e2a0c99fc050a849e328399deb33` (both verified unchanged; v5.1 was built in a
separate checkout on branch `v5.1`). Review pack `AERIS-v5-review-pack.zip` SHA-256
`b91411ef44ce4bf3a41ecdeb550266f11f2d76e072e0851ea5141a7ffd6f07b1`, kept as supplied in
`evidence/v5-independent-review/`. Preserved unchanged: the frontend design, `LocalSimulatorAdapter`, the
experiment/service architecture, the engine (aeris-research-engine 1.1.0), records, schemas' meaning, the database,
research data and historical evidence. Contract changes are additive ([MIGRATION_V5_1.md](site/docs/MIGRATION_V5_1.md)).

Every statement below points to code and to evidence **executed by us** in the environment of §2, unless it is
marked as the supplied review's. Nothing here was measured on, connected to or validated against the physical cube.

## 1. Status at a glance

| Gate | Status | Evidence |
|---|---|---|
| F1 synthetic provenance across mixed-source export/replay (P1) | **fixed**; reproduced on v5 (2 of 3 scenarios and the reviewer's probe fail), passes on v5.1 | §4.1; `evidence/v5.1-verification/results/{v5,v51}/`; `test_provenance.py` (11) |
| F2 telemetry after a backend restart (P2) | **fixed**; real-process probe: v5 0/50 replay frames for both consumers, v5.1 50/50 | §4.2; `test_stream_identity.py` (6), `v51.test.js` (9), live L14, `browser_v51.py` (12) |
| F3 CI browser interpreter path (P2) | **fixed in the runner and the workflow**; the reviewer's CI probe: v5 `FileNotFoundError`, v5.1 completes with a summary | §4.3; `test_run_tests.py` (15); release step `test-runner` |
| F3 the workflow on a CI service | **NOT EXECUTED** — no CI service is reachable for this project from this session (§7) | — |
| F3 the workflow's steps, locally, from clean clones | **all steps of all 4 jobs succeeded** (backend 391, JavaScript 181 + drift checks, integration 14, browser 171 — the 18 suites between them); not a CI service run | `evidence/v5.1-verification/ci-local/` (§7) |
| F4 cross-platform reproduction assertion (P2) | **fixed**; the Mac-sized difference fails v5's test and passes v5.1's; meaningful deviations still fail | §4.4; `test_reproduction.py` (21 incl. 8 negative controls) |
| F5 COM-preview browser check (P2) | **fixed** (test only; product unchanged); v5.1 check passes at CPU slow-downs 1×–24×, v5's fails or passes on a stale vector at 16×–24× | §4.5; `browser_v3.py` (3 COM checks) |
| All suites on this machine | **757 passed, 0 failed, 0 skipped, 0 not run** — 18 of 18 suites (backend 391, JavaScript 181, live 14, browser 171) | `test-logs/` (§3) |
| Schema and `index.html` drift checks | **passed** (`node build/build_schemas.js`, `python3 build/build_index.py`, no diff) | §3 |
| Campaign sample re-run (32 rows, 4 per study) | **32 identical**, 0 outcome changes (same machine and versions) | `evidence/v5.1-verification/results/v51/campaign-verification.json` |
| Fresh-directory validation of the release archive (Linux) | candidate archive: **14 of 14 steps passed** (incl. F1, F2, F3 steps); the delivered archive's own result is delivered next to it | §8; `evidence/v5.1-release/` |
| Archive ↔ git bundle correspondence | candidate archive: **identical** to its commit (552 files, same bytes; bundle verifies, complete history); the delivered archive's own check is delivered next to it | §8 |
| macOS | **not executed by us** (our environment is Linux; nothing was run on your Mac); instructions in §9; the portable orphan-worker test is ready for it | — |
| Windows, non-Chromium browsers, remote/multi-user deployment, long soak tests | **not executed** | — |
| Physical hardware: device compatibility, measured parameters, validation | **not done — out of reach of software** | `site/docs/HARDWARE_HANDOFF.md` |

Software completion is therefore **conditional**: the five findings are fixed and every suite passes on one local
Linux research workstation with synthetic telemetry; the CI service run, macOS, Windows and every hardware gate
remain open.

## 2. Environment of every executed check

| Item | Value |
|---|---|
| Machine | Linux x86-64 (kernel 6.18.44, glibc 2.39), 2 logical CPUs (Intel Xeon 2.1 GHz, AVX-512), 7 GB RAM; a cloud sandbox, loopback services only |
| Backend | Python 3.12.3 venv with the lock file: NumPy 2.5.3, SciPy 1.18.1, FastAPI 0.141.1, Starlette 1.7.0, uvicorn 0.54.0, pydantic 2.13.5, pytest 9.1.1, jsonschema 4.26.0 |
| Frontend tests | Node.js v22.22.2 |
| Browser tests | Playwright 1.56.0 in the same Python 3.12.3 venv; Chromium 141.0.7390.37 headless (SwiftShader WebGL), reduced motion |
| Orchestration | `scripts/run_tests.py` under Python 3.11.15 with explicit absolute `--backend-python` / `--browser-python` |
| Network | no public deployment, no hardware, no CI service; package installation from PyPI through the sandbox proxy |

## 3. Test results (exact counts, this machine)

Command: `python3 scripts/run_tests.py --out test-logs --backend-python <venv python> --browser-python <venv python>`
→ `test-logs/` (one log per suite, `summary.json`, `SUMMARY.md`, `pytest-junit.xml`). Verdict line of the run:
**"PASSED — all 18 suites ran and passed"** (exit code 0), 2026-10-01T01:49Z, on commit `8ce530f`. Later commits
change no product or test code: only documentation, evidence, the CI workflow's log folder (`ci-test-logs/`) and
release tooling (`scripts/ci_local.py`, `scripts/compare_archive_bundle.py`).

| Suite | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---:|---:|---:|---:|---:|---|
| Backend (pytest) | 391 | 0 | 0 | 0 | 183.7 | `test-logs/backend.log` |
| JavaScript · assistant | 9 | 0 | 0 | 0 | 0.3 | `test-logs/js-assistant.log` |
| JavaScript · engine | 9 | 0 | 0 | 0 | 0.8 | `test-logs/js-engine.log` |
| JavaScript · numerics | 38 | 0 | 0 | 0 | 0.6 | `test-logs/js-numerics.log` |
| JavaScript · platform | 16 | 0 | 0 | 0 | 0.3 | `test-logs/js-platform.log` |
| JavaScript · runs | 14 | 0 | 0 | 0 | 0.3 | `test-logs/js-runs.log` |
| JavaScript · schema | 7 | 0 | 0 | 0 | 0.3 | `test-logs/js-schema.log` |
| JavaScript · service | 19 | 0 | 0 | 0 | 0.4 | `test-logs/js-service.log` |
| JavaScript · ui | 16 | 0 | 0 | 0 | 0.3 | `test-logs/js-ui.log` |
| JavaScript · v4 | 27 | 0 | 0 | 0 | 0.6 | `test-logs/js-v4.log` |
| JavaScript · v5 | 17 | 0 | 0 | 0 | 0.6 | `test-logs/js-v5.log` |
| JavaScript · v51 (new) | 9 | 0 | 0 | 0 | 0.3 | `test-logs/js-v51.log` |
| Live adapter integration (incl. L14, a real backend restart) | 14 | 0 | 0 | 0 | 13.7 | `test-logs/live.log` |
| Browser · browser_check | 50 | 0 | 0 | 0 | 71.1 | `test-logs/browser-browser_check.log` |
| Browser · browser_v3 | 49 | 0 | 0 | 0 | 52.5 | `test-logs/browser-browser_v3.log` |
| Browser · browser_v4 | 24 | 0 | 0 | 0 | 66.8 | `test-logs/browser-browser_v4.log` |
| Browser · browser_v5 | 36 | 0 | 0 | 0 | 50.2 | `test-logs/browser-browser_v5.log` |
| Browser · browser_v51 (new) | 12 | 0 | 0 | 0 | 55.9 | `test-logs/browser-browser_v51.log` |
| **Total** | **757** | **0** | **0** | **0** | | `test-logs/summary.json` |

Against v5 (685 passed on this kind of machine; the reviewer's Mac run of v5: 682 passed, 2 failed, 1 skipped):
backend 343 → 391 (+11 provenance, +6 stream identity, +15 runner, +14 reproduction rules and controls, +1 schema
for recorder output and datasets, +1 portable orphan test); JavaScript 172 → 181 (+9 `v51`); live 13 → 14 (L14);
browser 157 → 171 (`browser_v3` 47 → 49: the COM check became three; `browser_v51` 12 new). Every v5 test is still
present; test expectations changed only where listed in [MIGRATION_V5_1.md](site/docs/MIGRATION_V5_1.md) §5, each
with its reason. No assertion was weakened, no sleep was lengthened to obtain a pass, and no numerical or integration
check was replaced by a mock. On this Linux machine nothing is skipped; on macOS the `/proc` orphan test is reported
as skipped (its portable `ps` counterpart runs) — that skip is not a pass.

Drift checks (the CI's): `node build/build_schemas.js && git diff --exit-code site/schemas` and
`python3 build/build_index.py && git diff --exit-code site/index.html` — no diff.

## 4. Findings → code → tests → evidence

Each finding was reproduced on the **unmodified v5** first (clean worktree at `1023e09`), with the review's own probe
where one exists (paths adapted only); the same probes then ran on v5.1. Outputs: `evidence/v5.1-verification/results/`
(`v5/`, `v51/`, each with `index.json`); how to rerun: `evidence/v5.1-verification/README.md`.

### 4.1 F1 (P1) — synthetic provenance lost across mixed-source export and replay

*Reproduced on v5:* a recording that switches from a declared-physical source (an artificial fixture) to the
emulator is stored as synthetic, but its NDJSON export carries only the first hello (`physical`, `synthetic: false`);
the replay is labelled "REPLAY of a recording declared from a physical device" and the re-recording is stored with
`synthetic: false` (`results/v5/review_probes.out`). The extended probe fails 2 of 3 scenarios (physical then
synthetic; physical, reconnect, then synthetic), through two generations (`results/v5/f1_mixed_source.out`).

*Fix:* `backend/aeris_backend/telemetry/lineage.py` (new: `classify`, `export_segments`), `telemetry/stream.py`
(source segments per recording, mode change closes the recording, segment-aware `recording_document` and
`recording_to_ndjson`), `telemetry/protocol.py` (optional `hello.lineage`, ≤ 8 KiB, validated), `api/app.py` (trust
recomputed from the immutable document for listing, import, datasets and comparisons; `effective_provenance`),
`hardware/compare.py` (unknown trust and derived copies are never evidence), `hardware/bridge.py` (recording replays
export with lineage), `site/js/ui/telemetry-ui.js` (origin wording: unknown, copy). Rules: trust only travels down —
one synthetic, test or undeclared segment or ancestor makes everything derived synthetic; unknown/missing
declarations are `unknown`, never physical; a physical hello is never given `synthetic: true` (the protocol forbids
it) — non-physical segments are exported with the protocol-valid synthetic replay identity `file-replay`,
`synthetic: true`; replay copies are `derived`. Old records are classified when read and never rewritten.

*Tests:* `backend/tests/test_provenance.py` — both source orders, a reconnect of one declared source, emulator
reconnect and identity change, mode change, export → replay → re-recording twice, recording replays, JSON round
trips, forged relabelling (422), datasets, comparisons, v5 documents unchanged byte-for-byte, unknown declarations,
the list endpoint, uploads without `seq`, and the positive control (a declared-physical original stays admissible;
its replay copy does not). `test_schemas.py` (recorder output and datasets against the published schemas),
`v51.test.js` P1, `browser_v51.py` (the Telemetry tab: declared original, mixed recording SYNTHETIC in the list, in
every exported hello and throughout its replay, the copy named as a copy). *After:* all scenarios pass
(`results/v51/f1_mixed_source.out`, `review_probes.out`).

### 4.2 F2 (P2) — telemetry freezes after a backend restart

*Reproduced on v5:* the reviewer's transport fixture delivers `[1000]` only (cursor stuck at 1000); with REAL backend
processes (stopped and started on the same port and database, a WebSocket consumer and a forced-polling consumer
staying loaded) 0 of 50 replay frames and no live frames reach either consumer after the restart
(`results/v5/restart_real_processes.out`). The real-process run also showed a second v5 defect: in Node (used by the
integration tests), a WebSocket attempt to a stopped backend reports only `error`, never `close` — browsers send both —
and the adapter waited for `close` forever.

*Fix:* `telemetry/stream.py` (`stream_id`, `stream_started`, `segment` in the status; `frames_after(n, limit,
stream)` answers another stream's cursor from this stream's start with `stream_changed: true`), `api/app.py`
(`/telemetry/frames?stream=`; live batches carry `"stream"`), `site/js/adapters/hardware-telemetry.js` (cursor and
de-duplication per stream; a `stream` event before the new stream's frames; stale streams ignored; `observe()` for
statuses the page fetches itself; `opts.stream`/`opts.after` for a panel shown again; counter-regression fallback for
v5 backends; a socket that ends with `error` only or never opens falls back to polling), `site/js/ui/telemetry-ui.js`
(on a stream change the frame, session, wheel angles and this page's counters are dropped, the banner says the
backend restarted until the new status arrives; an unreachable backend is re-probed every 3 s while the tab is open).
Ordering and de-duplication within one stream are unchanged.

*Tests:* `test_stream_identity.py` (two API processes one after the other), `v51.test.js` W1–W8 (WebSocket and
forced polling across a restart, stale answers, reconnect without restart, v5 backends, hidden/shown panel, Node's
error-only socket, a never-opening socket), live L14 (a real backend restart: both consumers get a 12-frame 5 Hz
replay from n = 1 and then live frames; a socket closed without a restart keeps one cursor), `browser_v51.py` (two
Chromium tabs, one on the WebSocket, one with WebSocket switched off; reconnect without restart; real restart; the
old frame is dropped from values, readout and 3-D view; the low-rate replay arrives in both tabs; live frames
continue; the first tab returns to the WebSocket; a tab whose site probed the backend while it was down shows
"Telemetry unavailable" and recovers by itself). *After:* 50/50 replay frames and live frames for both consumers
(`results/v51/restart_real_processes.out`). Display timings in the definitive browser run: the first frame of the 5 Hz
replay was shown 177 ms (WebSocket tab) and 334 ms (polling tab) after Connect; the probed-while-down tab was back
2.0 s after the backend answered (`test-logs/browser-browser_v51.log`). Single-tab diagnostic:
`results/v51/f2_display_latency.out`. Timings depend on the machine (an earlier run on the same machine measured
1.3–1.7 s for the first replay frame while both tabs rendered WebGL on 2 CPUs).

*Compatibility:* additive fields and query parameter. v5.1 page + v5 backend: restarts are detected when the new
process's counter is below the cursor (otherwise indistinguishable from a gap without stream ids); v5 page (cached)
+ v5.1 backend: v5 behaviour until reloaded ([TELEMETRY.md](site/docs/TELEMETRY.md) §11).

### 4.3 F3 (P2) — the CI browser command crashed before running a test

*Reproduced on v5:* the reviewer's layout with `--browser-python backend/.venv/bin/python` raises
`FileNotFoundError: 'backend/.venv/bin/python'` and writes no summary (`results/v5/review_probes.out`). Also found:
an explicit interpreter without Playwright was silently replaced by another Python, and `--skip` runs were reported
as `all_passed`.

*Fix:* `scripts/run_tests.py` — interpreters (`--backend-python`/`$AERIS_PYTHON`, `--browser-python`/
`$PLAYWRIGHT_PYTHON`, `--node`) resolved once from the start directory (absolute, symlinks kept so a venv stays a
venv; bare names via PATH); explicit choices never replaced; launch failures caught; statuses passed / failed /
not run / skipped; `--only`; `verdict`, `complete`, `full_validation` in `summary.json` and first in `SUMMARY.md`;
exit 0 only when every selected suite ran and passed, 2 when incomplete, 64 for unknown suite names.
`.github/workflows/ci.yml` — `--only` per job and absolute paths under `$GITHUB_WORKSPACE`. `scripts/ci_local.py` —
executes the workflow's run steps locally from clean clones (not a CI service run).

*Tests:* `backend/tests/test_run_tests.py` — the real runner against a fake repository: the exact CI shape (relative
path from the root), relative from another directory, absolute, PATH name, spaces in paths, missing / non-executable
/ unknown interpreters (not run, exit 2, no traceback), an explicit interpreter without Playwright (not replaced),
defaults recorded, environment variables resolved like arguments, missing Node, `--skip` and `--only` never a full
validation, unknown suite names (64), launch failures. Release validation step `test-runner`. *After:* the reviewer's
CI probe completes with a summary (`results/v51/review_probes.out`).

### 4.4 F4 (P2) — the reproduction test demanded bit-equality across platforms

*Reproduced:* this machine reproduces the Linux-generated fixtures bit for bit, so the review's macOS difference
(2.053914e-15 on one sample of `corner_custom`) was applied to a copy of the fixture: v5's test function fails
although the application's verdict is `within_tolerance` (`results/v5/f4_cross_platform.out`).

*Fix:* `backend/tests/test_reproduction.py` — same-environment reruns (also through the JSON a stored record is kept
as) must be bit-identical in samples, outcome and metrics; the stored v4 fixtures, generated on another machine,
must meet the **predeclared** cross-environment rule of `site/docs/REPRODUCIBILITY.md` §2: relative 2e-5 per sample
(asserted equal to the documented value, unchanged since v5), the same outcome, rows, sample rate, columns and units,
and the application's verdict `identical` or `within_tolerance`; runs with a 3-D estimator keep v5's assertions.
Fixtures were not regenerated; the tolerance was not widened. *Negative controls* (8): relative 1e-3 on one sample,
1.5 × the tolerance, a changed outcome, a missing column, a changed unit and one row fewer fail; 0.5 × the tolerance
and the Mac-sized 2.05e-15 pass the cross-environment rule and fail the same-environment rule. *After:*
`results/v51/f4_cross_platform.out`: the Mac-sized case passes, the meaningful and outcome cases still fail.

### 4.5 F5 (P2) — the COM-preview browser check observed an unfinished update

*Reproduced:* under Chrome DevTools CPU throttling the v5 check (a fixed 500 ms pause, then "4.00 mm" in the label and
SOME arrow) fails for 4 mm at 16× and 24× and, for 5 mm, passes while the 3-D view still shows the previous 4 mm vector
(`results/v51/f5_check_under_throttle.out`; the v5 check's result at 16× varied between runs:
`results/{v5,v51}/com_preview_throttle.out`).

*Fix (test only; the product and the v5 replay-race fix are unchanged):* `site/tests/browser_v3.py` waits (bounded,
15 s) until the input, the draft, the validated draft, the label `|Δr| x.00 mm` and the view's COM vector (0, x, 0) mm
all agree, for 4 mm and then 5 mm; then replay (the run's own centre of mass) → setup (the draft's 5 mm again, draft
unchanged) → 0 mm (no arrow). *After:* the v5.1 check passes at every rate from 1× to 24×, agreement within 0.5–2.1 s.

## 5. Found while completing v5.1 (not in the review) and fixed

| Issue | Before | After | Test / evidence |
|---|---|---|---|
| NDJSON export or replay of an uploaded recording without a `seq` column | HTTP 500 (`KeyError: 'seq'`) | row index stands in | `test_provenance.py::test_api_an_uploaded_recording_without_a_seq_column_exports_and_replays` |
| `aeris-dataset/1` lacked `provenance.source: "synthetic-telemetry"` (written since v5) | a backend dataset of synthetic recordings failed the published schema | conforms | `results/dataset-schema-drift.txt`; `test_schemas.py` |
| orphan-worker check only via Linux `/proc` | skipped on macOS | portable `ps` test; negative control for both tests (both fail without the parent watch, pass with it) | `test_process_restart.py`; `evidence/v5.1-verification/orphan_workers_negative_control.py` → `.out` (Linux) |
| live stream stalled on a WebSocket that reports only `error` (Node) | the WebSocket consumer never recovered after a restart | polling fallback; 8 s open timeout | `v51.test.js` W7 |
| Telemetry tab stayed "unavailable" for up to a minute when the site's periodic probe hit a restart | waited for the next 60 s probe | re-probes every 3 s while the tab is open (back 2.0 s after the backend answered) | `browser_v51.py` ("came back by itself") |
| `studies/verify_campaign.py` could only overwrite the campaign's own `verification.json` | — | `--out` (default unchanged) | used for the v5.1 sample check |

## 6. Contract changes (all additive) and versions

Backend 1.1.0 → **1.1.1**; engine unchanged (aeris-research-engine 1.1.0); config, run, sweep, metrics and database
versions unchanged. Additive: `hello.lineage`; recording provenance `segments`, `lineage`, `trust`, `trust_reasons`,
`mixed_sources`, `derived`, `derived_from`, `recording_closed`, `stream_id`; dataset provenance
`contains_unknown_origin`, `unknown_origin_members`, `derived_members`, member `trust`/`derived`, and the enum value
`synthetic-telemetry` the backend already wrote; status `stream_id`, `stream_started`, `segment`; poll answers
`stream_id`, `stream_changed`, query `stream`; live batches `stream`; recordings list `trust`, `derived`. Behaviour
changes a client may notice: exported hellos of non-physical segments use device kind `file-replay` and an id
prefixed `replay:`; a mode change closes a running recording; the runner's exit codes (2 for incomplete runs, 64 for
unknown names). Details: [MIGRATION_V5_1.md](site/docs/MIGRATION_V5_1.md), [TELEMETRY.md](site/docs/TELEMETRY.md) §6, §11.

## 7. CI

**Not executed on a CI service.** Blocker: this session has no CI service for the project — its origin is a local Git
bundle, no GitHub repository is configured for the session (the session's GitHub access is limited to configured
repositories and listing repositories was refused), and creating a repository or changing visibility was not
authorised. There is therefore no run URL. Executed instead, and **not** to be confused with a CI service run:
`scripts/ci_local.py` ran every `run:` step of `.github/workflows/ci.yml` verbatim, each job in its own fresh `git
clone` of commit `c8b1967` (the final code and workflow), with `actions/setup-python` provided by Python 3.12.3 and
`actions/setup-node` by Node 22.22.2. Every step of the four jobs succeeded: **backend** (`scripts/install.sh`, then
`run_tests.py --only backend` with an absolute `--backend-python`: 391 passed), **javascript** (schema and
`index.html` drift checks, then 181 passed), **integration** (install, then the live suite: 14 passed), **browser**
(install, `pip install playwright==1.56.0`, `playwright install --with-deps chromium` — the system dependencies were
installed with apt — then the five browser suites with absolute interpreter paths: 171 passed). Each job's runner
verdict says "selected suites only … Not a full validation", as designed; the four selections together are the 18
suites. Differences from GitHub Actions: no GitHub runner image or service, this machine's interpreters stand in for
the setup actions, artifacts were copied locally, and Chromium came from this machine's Playwright browser directory.
Records: `evidence/v5.1-verification/ci-local/CI-LOCAL.md`, `ci-local.json`, per-step logs and each job's artifact
(`<job>/artifacts/ci-test-logs/`, only that job's logs).

## 8. Release archive: fresh-directory validation and correspondence

`scripts/validate_release.py` (standard library; 14 steps: archive, extract, install, start, experiment,
reproduce, restart, sweep-cancel, telemetry, **telemetry-provenance** (F1, with an artificial declared-physical
fixture), **telemetry-restart** (F2), **test-runner** (F3), backup, stop) unpacks the archive into a new temporary
directory, installs it into a new virtual environment from the lock file and exercises it end to end.

**Candidate archive** (commit `2ed4e66`; 552 files; SHA-256 `481b146f…c704777`): **14 of 14 steps passed**
(`evidence/v5.1-release/candidate-archive-validation.json`). Highlights: install with Python 3.12.3, no lock-file
mismatches, backend 1.1.1 with aeris-research-engine 1.1.0; the advanced run recovered and reproduced identically
(max |Δ| 0.0); a sweep survived stop/start (72 of 72 rows, no duplicates, 1 restart); a cancelled sweep's partial
rows (5 of 72) went into a finalised dataset with intact integrity; the synthetic emulator was recorded (120
samples), exported and replayed as SYNTHETIC; **telemetry-provenance**: the fixture alone → `declared-physical`;
fixture → emulator → `synthetic`, segments `[physical, emulator]`, exported hellos `file-replay` and `emulator`, all
`synthetic: true`; the re-recorded export `synthetic` and `derived`; its comparison not admissible; the dataset
`synthetic-telemetry`; **telemetry-restart**: after `stop.sh` + `start.sh` the stream id changed and the old cursor
(671) with the old stream id was answered from n = 1 (`stream_changed: true`); **test-runner**: the CI's relative
`--browser-python backend/.venv/bin/python` in the fresh install (no Playwright there) gave NOT RUN for all five
browser suites with the reason, exit 2, a written summary and no traceback, and `--only js:schema` gave "PASSED —
selected suites only … Not a full validation"; backup and restore verified; clean stop.

**Correspondence** (`evidence/v5.1-release/candidate-archive-bundle-check.json`): `git bundle verify` succeeds in an
empty repository (complete history: 35 commits from the v4 baseline through v5 to v5.1); the archive's 552 files and
the 552 files tracked at the commit are the same set with the same bytes. (The reviewer found that the v5 archive
held 20 files the v5 bundle did not track — `test-logs/` and the candidate validation; in v5.1 they are committed.)

**Delivered archive**: built from the commit tagged `aeris-v5.1`. The commits after the candidate only add
`evidence/v5.1-release/`, complete this report and make the bundle check verify inside an empty repository (no
product, test, runner or other tooling change). Its fresh-directory validation and its archive ↔ bundle
check were run after packaging and are delivered next to it (`aeris-site-v5.1.release-validation.json`,
`aeris-site-v5.1.archive-bundle-check.json`); a report inside an archive cannot contain the check of that archive.

## 9. Run on macOS (concise; not executed by us for v5.1)

```bash
unzip aeris-site-v5.1.zip && cd aeris-v5.1
scripts/install.sh --python python3.12          # Python 3.12+ (python.org or brew install python@3.12)
scripts/start.sh --emulator                     # http://127.0.0.1:8750/#lab ; SYNTHETIC emulator on 127.0.0.1:47100
scripts/stop.sh
backend/.venv/bin/python -m pip install playwright==1.56.0 && backend/.venv/bin/python -m playwright install chromium
python3 scripts/run_tests.py --backend-python "$PWD/backend/.venv/bin/python" --browser-python "$PWD/backend/.venv/bin/python"
python3 scripts/validate_release.py --zip ../aeris-site-v5.1.zip --expect-top aeris-v5.1
```

Node.js 18+ (`brew install node`) is needed only for the JavaScript and live suites. Expect the `/proc` orphan test to
be reported as skipped on macOS; `test-logs/SUMMARY.md` starts with the verdict.

## 10. Supplied review vs our checks

The independent review (`evidence/v5-independent-review/supplied/`) is the reviewer's execution on macOS arm64 of v5;
we did not execute it and it says nothing about v5.1. Our checks are §3–§8 (Linux x86-64 only). Two of the
reviewer's probes were rerun by us with paths adapted (`probes/review_probes_adapted.py`,
`probes/telemetry_restart_probe_adapted.js`); their failure conditions are unchanged.

## 11. Limitations (stated, not hidden)

* All telemetry is synthetic or an artificial fixture; "physical" is a source's declaration, never verified.
* Restart detection against a **v5** backend (no stream ids) cannot distinguish a restart from a gap once the new
  process has counted past the page's cursor; v5.1 backends always send stream ids.
* A v5 recording produced by the v5 defect (a mixed export replayed and recorded) cannot be recognised as synthetic
  any more (the export lost that information); it is classified `derived` and is never evidence.
* The COM preview still settles through debounced steps (about 0.5–2 s under heavy load); the test now waits for
  agreement instead of a fixed time. No product change was made for F5.
* Cross-platform numerical agreement is checked by rule and by emulating the review's measured difference; we ran no
  second platform.
* Display timings depend on the machine (first replay frame 0.2–1.7 s across our runs with two WebGL tabs on 2 CPUs).
* The 3 s re-probe interval and the 8 s WebSocket open timeout are fixed choices (documented, not configurable).

## 12. Not executed (and therefore not claimed)

* The CI workflow on a CI service (§7).
* Any check on macOS or Windows; any browser other than headless Chromium.
* Remote or multi-user deployment; long soak tests; the complete 1 668-row campaign (a 32-row sample was re-run).
* Anything involving the physical cube.

## 13. Deliverables

| File | What |
|---|---|
| `aeris-site-v5.1.zip` | the release (top folder `aeris-v5.1`): source, docs, schemas, tests, `test-logs/`, evidence, studies |
| `aeris-site-v5.1.zip.sha256` | its SHA-256 |
| `aeris-site-v5.1-git.bundle` | git history: branches `v5.1` (this release) and `master` (v5, `1023e09`), annotated tags `aeris-v5` and `aeris-v5.1`; `git clone aeris-site-v5.1-git.bundle aeris && cd aeris && git checkout v5.1` |
| `aeris-site-v5.1.release-validation.json` | the fresh-directory validation of the delivered archive (14 steps) |
| `aeris-site-v5.1.archive-bundle-check.json` | the delivered archive ↔ bundle comparison |
| `AERIS-v5.1-SOFTWARE_COMPLETION_REPORT.md`, `AERIS-v5.1-MIGRATION.md` | this report and `site/docs/MIGRATION_V5_1.md` (also inside the archive) |
| `aeris-site-v5.1-test-logs.zip` | `test-logs/` of the definitive run (also inside the archive) |

Earlier releases (v3, v4, v5 archives, the v5 bundle and report) are left untouched next to these.

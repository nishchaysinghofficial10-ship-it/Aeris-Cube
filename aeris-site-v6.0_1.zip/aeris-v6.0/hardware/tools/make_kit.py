#!/usr/bin/env python3
"""Writes the kit document of the AERIS reference cube A1 (aeris-kit/1) to the site and to the backend package.

    python hardware/tools/make_kit.py           # write site/data/kits/aeris-kit-a1.json, the backend copy, the site's BOM copy
                                                # and hardware/BUILD_GUIDE.md (the same content as one readable page)
    python hardware/tools/make_kit.py --check   # exit 1 when a written copy differs from what this script produces

The BOM's single source is hardware/bom/aeris-kit-a1.bom.json; the site serves an identical copy (data/bom/), whose
SHA-256 the kit document records.

The kit document is the Build page's content: readiness, the BOM reference (hash-bound), downloads (available files
with their SHA-256, unavailable ones with the reason), the sizing summary (hardware/tools/sizing.py on the reference
profile) and the guided steps — each with the parts it uses, the expected result, a checkpoint, troubleshooting and,
where the website or the device performs the check, the action that does it. Steps that need something that does
not exist yet (CAD, a selected motor, a designed power system) are marked blocked with the reason; nothing here is a
photograph, a tested assembly or a qualification.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(REPO, "backend"))
SITE = os.path.join(REPO, "site")
OUTS = [os.path.join(SITE, "data", "kits", "aeris-kit-a1.json"),
        os.path.join(REPO, "backend", "aeris_backend", "devices", "data", "kits", "aeris-kit-a1.json")]
BOM_SRC = os.path.join(REPO, "hardware", "bom", "aeris-kit-a1.bom.json")
BOM_SITE = os.path.join(SITE, "data", "bom", "aeris-kit-a1.bom.json")
FW_VERSION = "0.1.0"


def sha(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def download(id_, title, rel, kind, unavailable_reason=None):
    p = os.path.join(SITE, rel) if rel else None
    if p and os.path.isfile(p):
        return {"id": id_, "title": title, "kind": kind, "status": "available", "path": rel, "sha256": sha(p), "bytes": os.path.getsize(p)}
    return {"id": id_, "title": title, "kind": kind, "status": "unavailable",
            "reason": unavailable_reason or f"{rel} has not been produced for this revision"}


def sizing_summary():
    import sizing                                     # hardware/tools/sizing.py
    from aeris_backend.devices import reference
    r = sizing.analyse(reference.reference_profile())
    d = r["drivers"]["odrive-micro"]
    edge = r["modes"]["edge"]
    return {"source": "hardware/tools/sizing.py on the reference profile aeris-ref-a1 (nominal model values; nothing measured)",
            "wheel_model": {k: round(v, 4) if isinstance(v, float) else v for k, v in r["wheel"].items()},
            "edge": {"mgl_Nm": round(edge["mgl_Nm"], 4), "torque_at_start_limit_with_margin_Nm": round(edge["torque_needed_with_margin_Nm"], 4),
                     "current_needed_A": round(edge["current_needed_at_profile_kt_A"], 2), "rows": [{k: round(v, 4) for k, v in x.items()} for x in edge["rows"]]},
            "candidate_driver": {"name": d["limits"]["name"], "I_cont_A": d["limits"]["I_cont_A"], "I_peak_A": d["limits"]["I_peak_A"],
                                 "V_min": d["limits"]["V_min"], "V_max": d["limits"]["V_max"],
                                 "static_limit_deg_continuous": round(d["checks"][0]["static_limit_deg_continuous"], 2),
                                 "static_limit_deg_peak": round(d["checks"][0]["static_limit_deg_peak"], 2),
                                 "KV_max_for_continuous_rpm_per_V": round(d["checks"][0]["KV_max_for_continuous_rpm_per_V"]),
                                 "supply_min_below_driver": d["supply_checks"]["below_driver_minimum"],
                                 "profile_current_above_driver_peak": d["supply_checks"]["above_driver_peak"],
                                 "low_kv_Jw_needed_kgm2": round(d["low_kv_consequence"]["Jw_needed_for_profile_H_kgm2"], 5)},
            "conclusion": ("With the nominal motor model, the candidate driver's continuous current holds the nominal cube statically only up to "
                           f"≈{d['checks'][0]['static_limit_deg_continuous']:.1f}° from balance; the motor, rotor and driver must be selected together "
                           "(a lower-KV motor with a larger rotor inertia, or a driver with a higher current rating) before any part is ordered.")}


def step(id_, section, title, *, summary, parts=(), expected, checkpoint, troubleshooting=(), action=None, requires=(), blocked=None,
         advanced=None, illustration=None):
    s = {"id": id_, "section": section, "title": title, "summary": summary, "parts": list(parts), "expected_result": expected, "checkpoint": checkpoint,
         "troubleshooting": list(troubleshooting), "requires": list(requires),
         "illustration": illustration or {"status": "none", "note": "No photograph or drawing of an AERIS A1 build exists: none is shown."}}
    if action:
        s["action"] = action
    if blocked:
        s["availability"] = {"status": "blocked", "reason": blocked}
    else:
        s["availability"] = {"status": "available"}
    if advanced:
        s["advanced"] = advanced
    return s


def kit() -> dict:
    bom_rel = os.path.relpath(BOM_SITE, SITE).replace(os.sep, "/")
    fw_rel = f"firmware/releases/{FW_VERSION}/manifest.json"
    steps = [
        step("plan-readiness", "plan", "Know what this revision is",
             summary="A1-candidate names development electronics and states what is not designed yet. It is browsable, not an order-and-balance kit.",
             expected="You know which parts are named candidates and which are unresolved (motors, rotors, frame, harness, power system, fixture).",
             checkpoint="The BOM shows 'unresolved' items and this page shows blocked steps; nothing claims a tested build.",
             troubleshooting=["Looking for a shopping list? There is none yet: the motor, rotor and driver must be selected together first."]),
        step("plan-sizing", "plan", "Select motor, rotor and driver together",
             summary="Use the sizing calculation to choose a motor/rotor/driver combination that can hold the cube at the recipe's start tilt with margin.",
             parts=["motor", "rotor", "wheel-driver", "power-system"],
             expected="A combination whose required current at the start limit (with ×2 margin) lies within the driver's continuous rating, and whose rotor stores enough momentum.",
             checkpoint="hardware/tools/sizing.py --profile your-profile.json reports 'within continuous: yes' for edge and corner.",
             troubleshooting=["Not enough torque: a lower KV (higher torque constant) or a driver with a higher current rating.",
                              "Too little momentum with a low-KV motor: a larger rotor inertia (heavier or larger rotor)."],
             blocked="Engineering work: no motor, rotor or power system has been selected for A1-candidate."),
        step("firmware-install", "firmware", "Install the AERIS firmware (motors disabled)",
             summary="Connect the controller board's ESP32-S3 USB port and install the release image from this website.",
             parts=["controller", "usb-cable"],
             expected="The installer detects an ESP32-S3, checks the image against the signed release manifest, writes it and reads back the firmware's identity.",
             checkpoint="The Connect page shows the device's hello with firmware 0.1.0 and 'this build never drives motors'.",
             troubleshooting=["No port offered: use a data cable and the ESP32-S3's own USB port; on a browser without Web Serial use the companion (Connect page).",
                              "Installation interrupted: hold BOOT, press RESET, release BOOT and install again (the ROM bootloader cannot be overwritten).",
                              "Wrong chip reported: the release image is for ESP32-S3 only; nothing is written to another chip."],
             action={"route": "#connect/install", "label": "Open the installer"}),
        step("connect-pair", "connect", "Pair the controller with you",
             summary="The website asks the device to pair; you confirm by pressing ARM on the cube. Without that press nothing is registered.",
             parts=["controller", "local-controls"],
             expected="The device is listed as paired with its own key: with this browser (the Connect page without a backend) or with your account on your AERIS backend.",
             checkpoint="The Connect page says 'Paired'; on a backend, pairing the same device to another account is refused until you revoke it.",
             troubleshooting=["No ARM button wired yet: pairing waits 60 s for the press and then fails safely; wire the ARM input (GPIO10 to ground) first."],
             action={"route": "#connect/pair", "label": "Pair"}),
        step("bench-imu", "electronics", "Wire the IMU (logic power only)",
             summary="Connect the LSM6DSOX breakout over I²C: SDA→GPIO8, SCL→GPIO9, 3V3, GND. No motor power is connected.",
             parts=["imu", "controller"],
             expected="Diagnostics name the IMU at 0x6A (or 0x6B) and show plausible gravity (≈9.8 m/s²) when the board lies still.",
             checkpoint="Run diagnostics: 'IMU LSM6DSOX at 0x6a (WHO_AM_I 0x6c)' and a valid estimator.",
             troubleshooting=["'no LSM6DSOX detected on I2C': check SDA/SCL are not swapped, the 3V3/GND leads and the address jumper.",
                              "Another sensor at the address: the firmware reports it as missing; it never reads an unknown chip."],
             action={"route": "#connect/diagnostics", "label": "Run diagnostics"}),
        step("bench-can", "electronics", "Connect the CAN bus and the three drivers (no motors yet)",
             summary="Transceiver TX/RX to GPIO4/GPIO5; daisy-chain CANH/CANL to the three drivers; terminate both ends with 120 Ω; configure each driver.",
             parts=["can-transceiver", "can-termination", "wheel-driver", "power-system"],
             expected="Each driver configured with node id 1, 2 or 3, CAN at 1 Mbit/s set explicitly, encoder estimates every 10 ms, heartbeat 100 ms, watchdog enabled.",
             checkpoint="Diagnostics show a heartbeat from nodes 1, 2 and 3 with no axis error.",
             troubleshooting=["No heartbeat: check termination (≈60 Ω between CANH and CANL with power off), the bitrate on every node and that node ids are distinct.",
                              "A driver is not seen at all: set its node id (1, 2 or 3, as in your profile) explicitly with the manufacturer's tool."],
             action={"route": "#connect/diagnostics", "label": "Run diagnostics"},
             advanced="hardware/INTEGRATION.md §CAN lists every driver setting the firmware relies on.",
             blocked="Needs the power system (unresolved) to power the drivers."),
        step("bench-controls", "electronics", "Wire ARM, emergency stop, dead-man, LED and DRIVE_EN",
             summary="ARM (GPIO10) and dead-man (GPIO12) to ground; the stop's sense contact on GPIO11 (open = stop); LED on GPIO13; DRIVE_EN (GPIO14) to the drive-power switch.",
             parts=["local-controls", "controller"],
             expected="Diagnostics report the ARM button, the stop and the dead-man control as they are read; an open stop line reads as 'asserted'.",
             checkpoint="Run diagnostics with the stop pressed and released: 'Local stop: ASSERTED' then 'released'; with the stop asserted the self-test is refused ('the local stop is asserted').",
             troubleshooting=["Stop always asserted: GPIO11 must be pulled to ground through the stop's closed contact; an open line means stop (fail-safe)."],
             action={"route": "#connect/diagnostics", "label": "Run diagnostics"},
             blocked="The emergency-stop and drive-power switching parts depend on the power system (unresolved)."),
        step("mech-frame", "mechanics", "Assemble the frame, guards and pivot pieces",
             summary="Frame, motor mounts, rotor guards and the edge/corner contact pieces.",
             parts=["frame", "harness"],
             expected="A rigid frame matching the profile's edge length, with guards around every rotor.",
             checkpoint="Measured edge length and mass entered in your profile.",
             blocked="No CAD, drawing or manufacturing file exists for A1-candidate."),
        step("mech-wheels", "mechanics", "Build and mount the three wheel assemblies",
             summary="Motor, rotor, encoder magnet and guard per axis, mounted along the body axes in the order of the profile (x, y, z).",
             parts=["motor", "rotor", "encoder-magnet", "wheel-driver"],
             expected="Three wheels spin freely by hand, each centred over its driver's encoder.",
             checkpoint="The encoder check (calibration) sees each wheel turn.",
             blocked="Motor and rotor not selected; no wheel-assembly drawing exists."),
        step("mech-mount-electronics", "mechanics", "Mount the controller and the IMU rigidly",
             summary="Fix the IMU with its axes parallel to the cube's body axes; note its position from the pivot corner.",
             parts=["imu", "controller", "frame"],
             expected="The IMU cannot move relative to the frame; its position is measured.",
             checkpoint="Your profile's imu.position_m holds the measured position.",
             blocked="Needs the frame (no CAD)."),
        step("profile", "setup", "Create your cube's profile",
             summary="Start from the reference profile and replace what you measured (mass, edge length, IMU position, motor and wheel values). Unknown values stay nominal and are labelled.",
             expected="A profile revision of your own, validated, with value sources stating what was measured.",
             checkpoint="The profile validates; its qualification is 'experimental' (the website never grants qualification).",
             troubleshooting=["Validation errors name the field and the allowed range."],
             action={"route": "#connect/profile", "label": "Edit profile"}),
        step("calibrate-imu", "calibrate", "Calibrate the IMU (cube still, then on two faces)",
             summary="Measure the gyroscope bias with the cube completely still, then the gravity direction with two different faces up.",
             parts=["imu"],
             expected="A calibration revision with the measured mounting (to_body) and the gyroscope bias.",
             checkpoint="The fit residual is below 10° for every face; a mounting that differs from your profile is reported.",
             troubleshooting=["'the cube moved during the measurement': rest it on a table and do not touch it.",
                              "'two different body axes': use, e.g., +z up and then +x up — not +z and −z."],
             action={"route": "#connect/calibrate", "label": "Calibrate"}),
        step("calibrate-wheels", "calibrate", "Check the wheel directions by hand",
             summary="With the drivers powered but idle (no torque), turn each wheel by hand in its marked positive direction.",
             parts=["wheel-driver", "motor"],
             expected="All three wheels read positive for their marked direction.",
             checkpoint="The calibration shows three confirmed directions; experiments stay blocked until it does.",
             troubleshooting=["A wheel reads negative: its driver.sign in your profile is wrong — make a profile revision with the opposite sign and calibrate again."],
             action={"route": "#connect/calibrate", "label": "Check wheels"},
             blocked="Needs the wheel assemblies and the power system (unresolved)."),
        step("commission-motors", "commission", "Motor checks in the fixture (commissioning build)",
             summary="Low-torque per-motor tests with the dead-man button held, the cube in the fixture. Needs a firmware build with commissioning enabled, built from source by the person responsible for the hardware.",
             parts=["fixture", "local-controls", "motor", "wheel-driver"],
             expected="Each wheel accelerates in the commanded direction at the capped torque and stops when the dead-man button is released.",
             checkpoint="The per-motor test result reports the applied torque and speed; releasing the button ends the test at once.",
             troubleshooting=["The installer never offers this build: it is built locally (firmware/README.md) after the hardware checks."],
             advanced="Commissioning is USB-only, needs the commissioning build flag and the dead-man input; the website has no motor console.",
             blocked="Needs motors, rotors, the fixture and the power system (unresolved), and a locally built commissioning firmware."),
        step("first-simulation", "experiment", "Run the matching simulation",
             summary="Simulate your profile with the edge recipe in the research engine: predicted recovery and wheel saturation for the first trial.",
             expected="A simulation run labelled as a prediction of your profile's MODEL.",
             checkpoint="The run names your profile revision, recipe and calibration.",
             action={"route": "#connect/simulate", "label": "Simulate My Cube"}),
        step("edge-trial", "experiment", "Edge trial in the fixture",
             summary="Apply the approved configuration, pass the self-test, place the cube near the edge balance, request the trial and press ARM on the cube.",
             parts=["fixture", "local-controls"],
             expected="The cube balances on its edge for the recipe's duration, then stops normally; or a limit stops it and the fixture catches it.",
             checkpoint="The experiment result states how it ended; the recording is stored with its provenance.",
             troubleshooting=["'waiting for the local enable': press ARM on the cube before the request expires.",
                              "'wheel directions not confirmed': complete the wheel check first."],
             requires=["calibrate-wheels", "first-simulation"],
             action={"route": "#connect/experiment", "label": "Start the edge trial"},
             blocked="Needs a complete, commissioned cube (motors, rotors, frame, power system) and a firmware build that may drive motors."),
        step("record-compare", "experiment", "Record and compare with the simulation",
             summary="Compare the recording with the simulation of the same profile and recipe; export both with their hashes.",
             expected="A comparison whose evidence status says what it can and cannot be used for.",
             checkpoint="Synthetic, replayed or undeclared data is never admissible as validation evidence; a declared physical recording needs a predeclared protocol.",
             action={"route": "#connect/compare", "label": "Compare"}),
        step("corner-trial", "experiment", "Corner trial (after a completed edge trial)",
             summary="Unlocked only after an edge trial of the same device and profile revision completed its duration.",
             parts=["fixture", "local-controls"],
             expected="The cube balances on its corner for the recipe's duration, then stops normally.",
             checkpoint="The Connect page and the backend refuse the corner recipe until an edge trial of this device is on record (the synthetic device needs none).",
             requires=["edge-trial"],
             action={"route": "#connect/experiment", "label": "Start the corner trial"},
             blocked="Needs a completed edge trial on a commissioned cube."),
    ]
    return {
        "schema": "aeris-kit/1",
        "id": "aeris-kit-a1",
        "revision": "A1-candidate",
        "name": "AERIS reference cube A1",
        "readiness": "candidate",
        "readiness_note": ("Candidate: development electronics are named with their published data; motors, rotors, frame, harness, power system and fixture are "
                           "not selected or designed. No A1 cube has been assembled, measured or balanced. Use the virtual cube, or follow the electronics bench "
                           "steps; do not order a complete kit from this page."),
        "profile": {"id": "aeris-ref-a1", "revision": 1},
        "firmware": {"version": FW_VERSION, "manifest": fw_rel, "installer_offers": ["release (motors never driven)"],
                     "not_offered": ["experimental/commissioning builds — built from source by the person responsible for the hardware (firmware/README.md)"]},
        "bom": {"path": bom_rel, "sha256": sha(os.path.join(SITE, bom_rel))},
        "supported_connections": [
            {"id": "web-serial", "status": "implemented", "tested": "against a mocked serial port in Chromium (no physical board)",
             "browsers": "desktop browsers that expose Web Serial (Chrome, Edge); others: use the companion"},
            {"id": "companion", "status": "implemented", "tested": "with the synthetic device process", "note": "python -m aeris_backend.companion (backend/README.md)"},
            {"id": "wifi-gateway", "status": "implemented", "tested": "with the synthetic device through a test bridge; the board's own Wi-Fi client is built but untested on hardware"}],
        "downloads": [
            download("firmware-release", f"AERIS firmware {FW_VERSION} release manifest (ESP32-S3-DevKitC-1, motors never driven)", fw_rel, "firmware"),
            download("bom", "Provisional bill of materials (machine-readable)", bom_rel, "bom"),
            download("cad-frame", "Frame, guards, mounts and pivot pieces (STEP/STL, drawings)", None, "cad", "No CAD exists for A1-candidate: the frame follows the motor and rotor selection, which is open."),
            download("pcb-controller", "Controller board (schematic, PCB, assembly files)", None, "pcb", "Not designed: the development board plus breakouts is the candidate for bench work."),
            download("harness", "Harness drawing and pinout", None, "harness", "Not designed: lengths and connectors follow the CAD."),
            download("assembly-drawing", "Assembly drawing", None, "drawing", "Not available: no released CAD."),
            download("photos", "Assembly photographs and videos", None, "photo", "None exist: no A1 cube has been built. The site's renders and video show the AERIS Cube concept (AI-generated illustrations), not this kit.")],
        "sizing": sizing_summary(),
        "steps": steps,
        "revision_history": [{"revision": "A1-candidate", "date": "2026-10-10", "changes": "First published candidate (electronics named; mechanics and power open).",
                              "invalidates": {"steps": [], "calibration": False}}],
        "progress_note": "Ticked steps are your own notes. They are not a hardware qualification and do not permit anything: the device, the profile, the self-test and the press of ARM decide.",
    }


GUIDE = os.path.join(REPO, "hardware", "BUILD_GUIDE.md")
SECTIONS = [("plan", "Plan"), ("firmware", "Firmware"), ("connect", "Connect"), ("electronics", "Electronics (bench)"), ("mechanics", "Mechanics"),
            ("setup", "Setup"), ("calibrate", "Calibrate"), ("commission", "Commission"), ("experiment", "Experiments")]


def _cell(s) -> str:
    return str(s if s is not None else "—").replace("|", "\\|").replace("\n", " ")


def guide_markdown(doc: dict, bom: dict) -> str:
    """hardware/BUILD_GUIDE.md: the kit document and the BOM as one readable page (generated; the Build page shows the same)."""
    L = [f"# Build guide — {doc['name']}, revision {doc['revision']}", "",
         "<!-- Generated by hardware/tools/make_kit.py from the kit document and hardware/bom/aeris-kit-a1.bom.json. Do not edit: "
         "change the script or the BOM and run it again (--check detects drift). -->", "",
         f"**Readiness: {doc['readiness'].upper()}.** {doc['readiness_note']}", "",
         f"{doc['progress_note']}", "",
         "Readiness levels: " + " → ".join(f"**{x}**" if x == doc["readiness"] else x for x in bom["readiness_levels"])
         + " ([README.md](README.md) says what each level needs).", "",
         "## Bill of materials", "",
         f"Provisional; sources checked on {bom['checked']}. {bom['price_note']} Machine-readable: `hardware/bom/aeris-kit-a1.bom.json` "
         f"(the site serves an identical copy, `site/{doc['bom']['path']}`, SHA-256 `{doc['bom']['sha256']}`); the facts, sources and "
         "compatibility notes of every item are in that file.", "",
         "| Item | Qty | Status | Part | Function |", "|---|---:|---|---|---|"]
    for it in bom["items"]:
        p = it.get("part") or {}
        part = " ".join(x for x in (p.get("manufacturer"), p.get("part_number")) if x) or p.get("description") or "—"
        L.append(f"| {_cell(it['name'])} | {it['qty']} | {it['status']} | {_cell(part)} | {_cell(it['function'])} |")
    L += ["", "Tested substitutions: none (no item has a tested substitute).", "", "### Tools", ""]
    L += [f"- **{t['name']}** — {t['purpose']}" for t in bom["tools"]]
    L += ["", "### Open engineering", ""] + [f"- {x}" for x in bom["open_engineering"]]
    L += ["", "## Downloads", "", "| File | Status | Path / reason | SHA-256 |", "|---|---|---|---|"]
    for d in doc["downloads"]:
        if d["status"] == "available":
            L.append(f"| {_cell(d['title'])} | available | `{d['path']}` ({d['bytes']} bytes) | `{d['sha256']}` |")
        else:
            L.append(f"| {_cell(d['title'])} | **unavailable** | {_cell(d['reason'])} | — |")
    sz = doc["sizing"]
    L += ["", "## Sizing", "", f"{sz['conclusion']} Source: {sz['source']}; details in [SIZING.md](SIZING.md).", "",
          "## Steps", "", "No step has an illustration: no photograph or drawing of an AERIS A1 build exists. A blocked step needs work that has "
          "not been done; the reason is given.", ""]
    names = {it["id"]: it["name"] for it in bom["items"]}
    n = 0
    for key, title in SECTIONS:
        steps = [s for s in doc["steps"] if s["section"] == key]
        if not steps:
            continue
        L += [f"### {title}", ""]
        for s in steps:
            n += 1
            blocked = s["availability"]["status"] == "blocked"
            L.append(f"**{n}. {s['title']}**" + (f" — *blocked: {s['availability']['reason']}*" if blocked else ""))
            L.append("")
            L.append(s["summary"])
            L.append("")
            if s["parts"]:
                L.append("- Parts: " + ", ".join(names.get(p, p) for p in s["parts"]))
            L.append(f"- Expected result: {s['expected_result']}")
            L.append(f"- Checkpoint: {s['checkpoint']}")
            for t in s["troubleshooting"]:
                L.append(f"- Troubleshooting: {t}")
            if s.get("requires"):
                L.append("- Requires: " + ", ".join(s["requires"]))
            if s.get("action"):
                L.append(f"- On the website: {s['action']['label']} (`{s['action']['route']}`)")
            if s.get("advanced"):
                L.append(f"- Advanced: {s['advanced']}")
            L.append("")
    L += ["## Revision history", ""]
    for r in doc["revision_history"]:
        L.append(f"- {r['revision']} ({r['date']}): {r['changes']}")
    return "\n".join(L).rstrip() + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args(argv)
    sys.path.insert(0, HERE)
    from aeris_backend.devices import schemas
    bom_text = open(BOM_SRC, encoding="utf-8").read()
    json.loads(bom_text)                                   # the BOM must be JSON
    bad = 0
    if a.check:
        if not os.path.isfile(BOM_SITE) or open(BOM_SITE, encoding="utf-8").read() != bom_text:
            print("DIFFERS:", os.path.relpath(BOM_SITE, REPO), "(copy of", os.path.relpath(BOM_SRC, REPO) + ")")
            bad += 1
    else:
        os.makedirs(os.path.dirname(BOM_SITE), exist_ok=True)
        with open(BOM_SITE, "w", encoding="utf-8") as f:
            f.write(bom_text)
        print("wrote", os.path.relpath(BOM_SITE, REPO))
    doc = kit()
    res = schemas.validate_kit(doc)
    if not res["ok"]:
        print("kit document invalid:", res["errors"])
        return 1
    text = json.dumps(doc, indent=1, ensure_ascii=False) + "\n"
    guide = guide_markdown(doc, json.loads(bom_text))
    for p, t in [(p, text) for p in OUTS] + [(GUIDE, guide)]:
        if a.check:
            cur = open(p, encoding="utf-8").read() if os.path.isfile(p) else None
            if cur != t:
                print("DIFFERS:", os.path.relpath(p, REPO))
                bad += 1
        else:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(t)
            print("wrote", os.path.relpath(p, REPO))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())

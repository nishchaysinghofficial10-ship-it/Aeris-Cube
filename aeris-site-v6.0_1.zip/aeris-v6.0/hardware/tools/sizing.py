#!/usr/bin/env python3
"""AERIS reaction-wheel sizing — the calculations needed to select the motors, rotors, drivers and power system that the
reference kit has NOT yet selected (hardware/SIZING.md).

    python hardware/tools/sizing.py                          # the reference profile (nominal model values)
    python hardware/tools/sizing.py --profile my-cube.json   # an aeris-device-profile/1 document
    python hardware/tools/sizing.py --json                   # machine-readable
    python hardware/tools/sizing.py --update-doc hardware/SIZING.md   # refresh the generated block (--check-doc: drift check)

Uses the research engine's own plant (backend/aeris_backend: the same mgl / inertia / COM the controllers are designed
on) and the profile's motor values. Every number is a MODEL estimate from declared values; none is a measurement.
Driver limits are the manufacturer's published figures (hardware/bom/aeris-kit-a1.bom.json, checked dates there).
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "backend"))

# published limits of candidate drivers (sources and check dates: hardware/bom/aeris-kit-a1.bom.json)
# "modulation" is NOT a published figure: an assumed fraction of the supply voltage the driver can apply to the motor,
# used only to estimate the top speed of a lower-KV motor on the same supply (stated as an assumption in the output)
DRIVERS = {
    "odrive-micro": {"name": "ODrive Micro (docs 0.6.12)", "I_cont_A": 3.5, "I_peak_A": 7.0, "V_min": 10.0, "V_max": 31.0, "P_cont_W": 100.0,
                     "modulation": 0.78, "brake_resistor": False},
}
TILTS_DEG = (0.5, 1.0, 2.0, 3.0, 5.0)
MARGIN = 2.0          # torque margin over the static gravity torque at the start tilt (to accelerate back, not only hold)


def kt_engine(kv):
    return 60.0 / (2 * math.pi * kv)


def analyse(profile: dict, recipe_ids=("edge-hold-10s", "corner-hold-10s")) -> dict:
    from aeris_backend.devices import configgen, reference
    out = {"profile": {"id": profile.get("id"), "name": profile.get("name"), "value_sources": profile.get("value_sources")}, "modes": {}, "drivers": {}}
    w0 = profile["wheels"][0]
    mo = w0["motor"]
    kt = kt_engine(mo["KV_rpm_per_V"])
    Jw = w0["Jw_kgm2"]
    wmax = mo["speed_max_rpm"] * math.pi / 30
    out["wheel"] = {"KV_rpm_per_V": mo["KV_rpm_per_V"], "kt_NmA_engine": kt, "Imax_A": mo["Imax_A"], "tau_max_Nm": kt * mo["Imax_A"], "Jw_kgm2": Jw,
                    "speed_max_rpm": mo["speed_max_rpm"], "H_max_Nms": Jw * wmax, "supply_V": mo["supply_V"],
                    "no_load_speed_rpm_at_supply": mo["KV_rpm_per_V"] * mo["supply_V"]}
    for rid in recipe_ids:
        rec = reference.recipe(rid)
        D = configgen.design(profile, rec)
        pl = D["design"]["plant"]
        mode = rec["mode"]
        if mode == "edge":
            mgl = float(pl["mgl"])
            share = 1.0                       # one drive wheel acts about the edge
        else:
            rc = [float(x) for x in pl["rc"]]
            mgl = float(pl["M"]) * float(profile.get("g_mps2", 9.81)) * math.sqrt(sum(x * x for x in rc))
            share = math.sqrt(2.0 / 3.0)      # worst-case share of a horizontal torque on one body axis (cube diagonal vertical)
        rows = []
        for th in TILTS_DEG:
            tg = mgl * math.sin(math.radians(th))
            tw = tg * share
            rows.append({"tilt_deg": th, "gravity_torque_Nm": tg, "per_wheel_torque_Nm": tw, "current_at_profile_kt_A": tw / kt,
                         "saturation_time_s_at_this_torque": (Jw * wmax / tw) if tw > 0 else None})
        start = rec["limits"]["tilt_start_deg"]
        need = MARGIN * mgl * math.sin(math.radians(start)) * share
        out["modes"][mode] = {"recipe": rid, "mgl_Nm": mgl, "per_wheel_share": share, "rows": rows, "start_tilt_deg": start,
                              "torque_needed_with_margin_Nm": need, "current_needed_at_profile_kt_A": need / kt,
                              "static_limit_deg_at_profile_Imax": math.degrees(math.asin(min(1.0, kt * mo["Imax_A"] / (mgl * share))))}
    for key, d in DRIVERS.items():
        res = {"limits": d, "checks": []}
        for mode, m in out["modes"].items():
            need_I = m["current_needed_at_profile_kt_A"]
            res["checks"].append({"mode": mode, "current_needed_A": need_I, "within_continuous": need_I <= d["I_cont_A"], "within_peak": need_I <= d["I_peak_A"],
                                  "static_limit_deg_continuous": math.degrees(math.asin(min(1.0, kt * d["I_cont_A"] / (m["mgl_Nm"] * m["per_wheel_share"])))),
                                  "static_limit_deg_peak": math.degrees(math.asin(min(1.0, kt * d["I_peak_A"] / (m["mgl_Nm"] * m["per_wheel_share"])))),
                                  "kt_needed_for_continuous_NmA": m["torque_needed_with_margin_Nm"] / d["I_cont_A"],
                                  "KV_max_for_continuous_rpm_per_V": 60.0 / (2 * math.pi * (m["torque_needed_with_margin_Nm"] / d["I_cont_A"]))})
        el = profile["electrical"]
        res["supply_checks"] = {"profile_vbus_min_V": el["vbus_min_V"], "profile_vbus_max_V": el["vbus_max_V"],
                                "below_driver_minimum": el["vbus_min_V"] < d["V_min"], "above_driver_maximum": el["vbus_max_V"] > d["V_max"],
                                "profile_current_limit_A": mo["Imax_A"], "above_driver_peak": mo["Imax_A"] > d["I_peak_A"],
                                "regenerative_energy_path_needed": not d["brake_resistor"]}
        # what a lower-KV motor implies for speed and momentum on the same supply
        best = max(c["kt_needed_for_continuous_NmA"] for c in res["checks"])
        kv = 60.0 / (2 * math.pi * best)
        w_avail = kv * mo["supply_V"] * d["modulation"] * math.pi / 30
        res["low_kv_consequence"] = {"KV_rpm_per_V": kv, "speed_available_rpm": w_avail * 30 / math.pi, "H_with_profile_Jw_Nms": Jw * w_avail,
                                     "Jw_needed_for_profile_H_kgm2": (Jw * wmax) / w_avail}
        out["drivers"][key] = res
    return out


def to_markdown(r: dict) -> str:
    L = []
    w = r["wheel"]
    L.append(f"Profile **{r['profile']['id']}** — wheel model: KV {w['KV_rpm_per_V']:g} rpm/V → k_t = 60/(2π·KV) = {w['kt_NmA_engine']:.4f} N·m/A (engine convention), "
             f"I_max {w['Imax_A']:g} A → τ_max {w['tau_max_Nm']:.3f} N·m, J_w {w['Jw_kgm2']:g} kg·m², speed limit {w['speed_max_rpm']:g} rpm → "
             f"momentum capacity H_max = J_w·ω_max = {w['H_max_Nms']:.3f} N·m·s.\n")
    for mode, m in r["modes"].items():
        L.append(f"### {mode} ({m['recipe']}): m·g·l = {m['mgl_Nm']:.3f} N·m, per-wheel share {m['per_wheel_share']:.3f}\n")
        L.append("| tilt from balance | gravity torque | per-wheel torque | current at profile k_t | time to saturate at that torque |")
        L.append("|---:|---:|---:|---:|---:|")
        for x in m["rows"]:
            L.append(f"| {x['tilt_deg']:g}° | {x['gravity_torque_Nm']:.4f} N·m | {x['per_wheel_torque_Nm']:.4f} N·m | {x['current_at_profile_kt_A']:.2f} A | "
                     f"{x['saturation_time_s_at_this_torque']:.2f} s |")
        L.append(f"\nWith a ×{MARGIN:g} margin at the recipe's start limit ({m['start_tilt_deg']:g}°): {m['torque_needed_with_margin_Nm']:.4f} N·m per wheel = "
                 f"{m['current_needed_at_profile_kt_A']:.2f} A at the profile's k_t. Static limit at the profile's I_max: {m['static_limit_deg_at_profile_Imax']:.2f}°.\n")
    for key, d in r["drivers"].items():
        lim = d["limits"]
        L.append(f"### Candidate driver: {lim['name']} — {lim['I_cont_A']:g} A continuous, {lim['I_peak_A']:g} A peak, {lim['V_min']:g}–{lim['V_max']:g} V\n")
        L.append("| mode | current needed (×2 margin) | within continuous | within peak | static limit (continuous) | static limit (peak) | k_t needed at continuous | KV at most |")
        L.append("|---|---:|:---:|:---:|---:|---:|---:|---:|")
        for c in d["checks"]:
            L.append(f"| {c['mode']} | {c['current_needed_A']:.2f} A | {'yes' if c['within_continuous'] else '**no**'} | {'yes' if c['within_peak'] else '**no**'} | "
                     f"{c['static_limit_deg_continuous']:.2f}° | {c['static_limit_deg_peak']:.2f}° | {c['kt_needed_for_continuous_NmA']:.4f} N·m/A | "
                     f"{c['KV_max_for_continuous_rpm_per_V']:.0f} rpm/V |")
        s = d["supply_checks"]
        L.append("")
        L.append(f"- Supply: the profile allows {s['profile_vbus_min_V']:g}–{s['profile_vbus_max_V']:g} V; "
                 + ("**its minimum is below the driver's minimum**" if s["below_driver_minimum"] else "within the driver's minimum")
                 + ("; **its maximum is above the driver's maximum**" if s["above_driver_maximum"] else "; within the driver's maximum") + ".")
        L.append(f"- Current: the profile's per-motor limit {s['profile_current_limit_A']:g} A is "
                 + ("**above the driver's peak rating**" if s["above_driver_peak"] else "within the driver's peak rating") + ".")
        if s["regenerative_energy_path_needed"]:
            L.append("- Braking wheels return energy to the DC bus and this driver has no brake-resistor control: the power system needs an "
                     "energy path (a battery that may be charged at that current, or an external regeneration clamp) and the driver's "
                     "negative-current and over-voltage limits set accordingly.")
        lk = d["low_kv_consequence"]
        L.append(f"- A motor with KV ≈ {lk['KV_rpm_per_V']:.0f} rpm/V would meet the margin within the continuous rating, but on the same supply "
                 f"(assuming the driver applies at most {lim['modulation']:g} of the supply voltage — an assumption, not a published figure) "
                 f"it reaches ≈ {lk['speed_available_rpm']:.0f} rpm: the profile's J_w would then store only "
                 f"{lk['H_with_profile_Jw_Nms']:.3f} N·m·s; keeping the momentum capacity needs J_w ≈ {lk['Jw_needed_for_profile_H_kgm2']:.4f} kg·m².\n")
    return "\n".join(L)


BEGIN, END = "<!-- sizing.py output: begin (generated; python hardware/tools/sizing.py --update-doc hardware/SIZING.md) -->", "<!-- sizing.py output: end -->"


def update_doc(path: str, text: str, check: bool) -> int:
    """Replace the generated block of a document with this run's output (or, with check, report a stale block)."""
    with open(path, encoding="utf-8") as f:
        doc = f.read()
    if BEGIN not in doc or END not in doc:
        print(f"{path}: the generated block markers are missing")
        return 1
    head, rest = doc.split(BEGIN, 1)
    _old, tail = rest.split(END, 1)
    new = head + BEGIN + "\n\n" + text.strip() + "\n\n" + END + tail
    if check:
        if new != doc:
            print(f"DIFFERS: {path} (run python hardware/tools/sizing.py --update-doc {path})")
            return 1
        return 0
    if new != doc:
        with open(path, "w", encoding="utf-8") as f:
            f.write(new)
        print("wrote", path)
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--profile", help="an aeris-device-profile/1 JSON file (default: the reference profile)")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--update-doc", metavar="MD", help="write the reference profile's result into the generated block of MD")
    ap.add_argument("--check-doc", metavar="MD", help="exit 1 when MD's generated block differs from this run (drift check)")
    a = ap.parse_args(argv)
    if a.profile:
        with open(a.profile, encoding="utf-8") as f:
            prof = json.load(f)
    else:
        from aeris_backend.devices import reference
        prof = reference.reference_profile()
    r = analyse(prof)
    if a.update_doc or a.check_doc:
        return update_doc(a.update_doc or a.check_doc, to_markdown(r), check=bool(a.check_doc))
    print(json.dumps(r, indent=1) if a.json else to_markdown(r))
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Hardware integration — what the firmware assumes (v6.0)

The electrical and bus interfaces that the AERIS firmware (`aeris-fw 0.1.0`, board layer `firmware/esp32s3`) relies
on, for the candidate parts of the reference cube A1 (`hardware/bom/aeris-kit-a1.bom.json`). **Nothing here has been
wired, powered or measured**: these are the firmware's assumptions and the requirements that follow from them, not a
tested design. Where a decision is still open it is named as one.

## 1. Controller board and pins

Candidate: Espressif ESP32-S3-DevKitC-1-N8R8. The device link (`aeris-device-link/1`) runs on the ESP32-S3's **own
USB port** (USB-Serial-JTAG): connect that port, not the USB-to-UART port, for the website and the companion. The
firmware's log console is on UART0 (GPIO43/44, the board's USB-to-UART bridge); the `qemutest` image moves the link to
UART0 and is never for a cube.

Pins are Kconfig options (`firmware/esp32s3/main/Kconfig.projbuild`); the defaults below are what the released image
uses. Another assignment needs a build with other values and a matching note in your profile.

| Function | GPIO | Behaviour in the firmware |
|---|---|---|
| IMU I²C SDA | 8 | I²C master, 400 kHz (`CONFIG_AERIS_I2C_HZ`) |
| IMU I²C SCL | 9 | |
| CAN TX → transceiver D | 4 | ESP32-S3 TWAI controller, 1 Mbit/s (`CONFIG_AERIS_CAN_BITRATE`); the chip has no CAN PHY: an external transceiver is required |
| CAN RX ← transceiver R | 5 | |
| ARM button | 10 | input, internal pull-up, **active low** (pressed = connected to ground); debounced over 5 control steps |
| Stop-chain sense | 11 | input, internal pull-up; **low = stop chain closed (running allowed); high or an open wire = stop asserted** (fail-safe); debounced; reads "asserted" at boot until the line is seen closed |
| Dead-man (commissioning) | 12 | input, internal pull-up, active low; used only by commissioning builds |
| Status LED | 13 | output: identify 5 Hz; ARMED fast blink; BALANCING/STOPPING steady; FAULT slow blink; READY short flash every 4 s; otherwise a brief "alive" flash. (The DevKitC's own RGB LED, GPIO38 on board v1.1, is not used.) |
| DRIVE_EN | 14 | output, **low after reset**; high = enable the drivers' power stage (relay/contactor); asserted only in the states that need powered drivers and never with the stop asserted; **forced low in release builds** by the board layer |

None of these is a strapping pin or one of GPIO35–37 (used internally by the N8R8's octal PSRAM). The board's three
power inputs — USB, the 5V/G pins, the 3V3/G pins — are mutually exclusive according to Espressif's user guide: a
controller board that feeds the 5V pin from the cube's regulator while the USB port is connected for the link must
respect that (**open design item**).

## 2. IMU

LSM6DSOX (candidate breakout: Adafruit 4438, 3–5 V power and logic) at I²C address 0x6A (default) or 0x6B. At
configuration time the driver checks WHO_AM_I = 0x6C — any other answer is reported as "not an LSM6DSOX" and the
sensor is not used —, resets the chip, sets block data update and register auto-increment, writes the output data
rate and full scales from the configuration and reads them back. Every control step reads the status register, the
twelve output bytes and the temperature; the data-ready flags decide whether a sample is fresh, five consecutive bad
or stale reads raise `IMU_STALE`, a full-scale reading raises `IMU_SATURATED`.

* **Mounting**: rigid, with the sensor axes parallel to the cube's body axes (a signed permutation; arbitrary angles
  are not supported). The calibration measures which sensor axis is which body axis; the profile declares its
  position from the pivot corner (`imu.position_m`, within 0.5 m).
* **Wiring**: short leads (STEMMA QT cable to GPIO8/GPIO9, 3V3, GND), away from the motor phases.

## CAN

Every driver-side setting and bus behaviour the firmware relies on. The firmware speaks **ODrive CANSimple**
(`firmware/core/src/drivers.c`, `drivers.h`): 11-bit identifiers `node_id << 5 | cmd_id`, little-endian payloads.

**Bus.** ESP32-S3 TWAI + an external ISO 11898-2 3.3 V transceiver (candidate: TI SN65HVD230) at **1 Mbit/s**, set
explicitly on every node (not automatic detection). Exactly two 120 Ω terminations, at the two physical ends of the
daisy chain (≈60 Ω between CANH and CANL with power off). The drivers' **node ids** come from the approved
configuration (`wheels[].node`, from the profile's `driver.node`: 1…62, distinct); the reference profile uses 1, 2, 3
for the x, y and z wheels.

**What the firmware sends**

| CANSimple message | When | Content |
|---|---|---|
| `Set_Axis_State` (0x07) | entering and leaving closed loop | IDLE (1) or CLOSED_LOOP_CONTROL (8) |
| `Set_Controller_Mode` (0x0B) | before closed loop | control mode TORQUE (1), input mode PASSTHROUGH (1) |
| `Set_Limits` (0x0F) | before closed loop | velocity limit [rev/s] and current limit [A] from the configuration (the wheel's speed and current limits) |
| `Set_Input_Torque` (0x0E) | every control step while the drivers are in closed loop (2 ms at 500 Hz); 0 N·m when going idle | torque [N·m] in the **driver's** direction: the configuration's `sign` × the model's wheel torque (a non-finite value is never sent: it becomes 0) |
| `Clear_Errors` (0x18) | when latched faults are cleared with the local long press | — |
| RTR requests: `Get_Bus_Voltage_Current` (0x17), `Get_Temperature` (0x15), `Get_Iq` (0x14), `Get_Torques` (0x1C) | one request every 5 control steps, round robin over the three drivers and the four messages (each message from each driver about every 60 steps, 120 ms at 500 Hz) | — |

The firmware never sends `Estop` (0x02): it stops with zero torque and IDLE, removes driver power (DRIVE_EN) and relies
on the hardware stop chain.

**What the firmware expects from each driver**

| Message | How | Freshness the firmware requires |
|---|---|---|
| `Heartbeat` (0x01): axis error, axis state | **cyclic** (configure on the driver; ≤ 100 ms suggested) | ≤ 300 ms for the self-test and while driving (`DRV_ABSENT` / `DRV_STALE` otherwise); a non-zero axis error in a fresh heartbeat raises `DRV_ERROR` in every state |
| `Get_Encoder_Estimates` (0x09): position [rev], velocity [rev/s] | **cyclic** (configure on the driver; 10 ms suggested) | ≤ 25 ms old to start an experiment and while driving (`ENC_STALE`); ≤ 50 ms for the self-test; wheel speeds appear in telemetry only while ≤ 100 ms old |
| `Get_Bus_Voltage_Current` (0x17) | answer to the RTR request (or cyclic) | the lowest bus voltage reported within 2 s is the device's bus voltage (self-test, `UNDERVOLT` / `OVERVOLT`); without any report the self-test fails and no experiment starts |
| `Get_Iq` (0x14) | answer to the RTR request (or cyclic) | measured current within 1 s is checked against `limits.current_abort_A` (`OVERCURRENT`) |
| `Get_Temperature` (0x15) | answer to the RTR request (or cyclic) | FET and motor temperature within 2 s are checked against `limits.temperature_abort_C` (`OVERTEMP`) |
| `Get_Torques` (0x1C) | answer to the RTR request (or cyclic) | torque estimates within 500 ms appear in telemetry as `torque_meas` |
| `Get_Error` (0x03) | decoded if it arrives; never requested | — |

While balancing, an axis that has not reported CLOSED_LOOP_CONTROL within 300 ms of the request raises `DRV_ERROR`.

**Driver configuration the firmware relies on** (done with the manufacturer's tool; AERIS does not configure the
drivers). The ODrive documentation could not be consulted for these notes, so the settings are named by what they do;
take the exact parameter names from the ODrive documentation **for the firmware version installed on your drivers**:

1. the CAN node id of each driver = its wheel's `driver.node` in the profile;
2. the CAN bit rate fixed at 1 Mbit/s;
3. the cyclic heartbeat message enabled;
4. the cyclic encoder-estimate message enabled at 10 ms (it must stay below 25 ms under bus load);
5. answers to RTR requests for the four `Get_*` messages above (or the same messages configured as cyclic);
6. motor, encoder and their calibration configured and saved on the driver (the firmware never runs driver calibrations);
7. the driver's torque constant consistent with the motor model in the profile (the firmware commands **torque** in
   N·m; the driver converts it to current with its own setting — a mismatch scales every torque);
8. the driver's own current and velocity limits no higher than the qualified values (the firmware also sends its
   configured limits with `Set_Limits` before closing the loop);
9. the driver's **CAN watchdog** enabled with a timeout of a few control periods: the firmware sends
   `Set_Input_Torque` every control step while driving, and the BOM's source states that every `Set_Input_Torque`
   resets the ODrive's watchdog — a stalled controller then lets the axis drop to idle on the driver's own authority;
10. the DC-bus over-voltage trip and the negative (regenerative) current limit set for the power system (§4);
11. the direction convention: the motor's positive direction relative to the wheel's axis is the profile's
    `driver.sign`; confirm it with `check_encoders` (each wheel turned by hand in its marked positive direction must
    read positive; a negative reading means the sign in the profile is wrong).

## 3. Local controls and drive power

* **Emergency stop** — a latching switch with two contacts: a **power contact that interrupts the motor bus**
  (the safety function, independent of the firmware) and a sense contact that keeps GPIO11 at ground while the chain is
  closed. The firmware's stop input is a **sense line, not the safety function**: when it reads the stop while the
  drivers may be powered it latches `ESTOP` (drivers idle, DRIVE_EN off); in DISARMED it blocks the self-test and
  arming. A browser stop button is supplementary and never replaces the hardware stop.
* **DRIVE_EN** (GPIO14) — intended for the relay or contactor (with pre-charge) that switches the drivers' power stage,
  in series with the hardware stop chain. The switching circuit must be **off by default and off when the controller is
  unpowered or resetting** (the pin is low after reset). The firmware asserts it only in SELF_TEST, READY, ARMED,
  BALANCING, STOPPING, COMMISSIONING and during `check_encoders`; a release build never asserts it.
* **Open decision: the drivers' logic supply.** If the drivers' logic and CAN interface are powered only through the
  DRIVE_EN-switched bus, the drivers are invisible on CAN whenever DRIVE_EN is off — in a release build always — so
  diagnostics show them as "not seen", and the self-test's driver checks and `check_encoders` cannot pass. Whether the
  drivers get a separate logic supply (and how the candidate driver supports that) must be decided in the power design.
* **ARM** (GPIO10) and **dead-man** (GPIO12) — momentary switches to ground. ARM is the local enable and the local
  confirmation (pairing, unpairing, starting an experiment, holding 2 s to clear latched faults).

## 4. Power (requirements, not a design)

* The bus voltage must stay inside **every driver's range over the whole discharge curve** (candidate ODrive Micro:
  10–31 V). The reference profile's nominal range (9.9–12.6 V) starts below that minimum: a build with this driver
  needs a profile revision (SIZING.md).
* The configuration's `vbus_min_V` / `vbus_max_V` (from the profile's `electrical`) are checked by the firmware: the
  self-test fails outside them, and while driving they raise `UNDERVOLT` / `OVERVOLT`.
* **Regenerative energy**: braking wheels return energy to the bus and the candidate driver has no brake-resistor
  control — the system needs a battery allowed to absorb that current or an external regeneration clamp, with the
  drivers' over-voltage and negative-current limits set to match.
* A fuse sized for the drivers' combined current, a main switch, a 5 V regulator for the controller (see the
  mutually-exclusive power inputs in §1), a complete protected battery pack with its charger, motor-power wiring kept
  apart from sensor and bus wiring, and DC polarity that cannot be reversed (the candidate driver does not tolerate
  reversed polarity).

## 5. What the firmware never does

It never reads an unknown sensor with assumed registers, never fills in a value a sensor or driver did not report
(absent, stale and wrong-identity are reported as such), never sends a non-finite setpoint, never closes the loop or
asserts DRIVE_EN in a release build, never configures or calibrates the drivers, and never treats its own stop input
as the emergency stop. What has to be built and measured before motors may be energised:
[COMMISSIONING.md](COMMISSIONING.md). The protocol between the website and the firmware:
[`site/docs/DEVICE_LINK.md`](../site/docs/DEVICE_LINK.md).

# Sizing the reaction wheels (v6.0)

The calculation behind the open choice of **motor, rotor and driver** for the AERIS reference cube A1
(`hardware/tools/sizing.py`). It answers one question before anything is ordered: can a given motor/driver pair hold
the cube at the recipe's start tilt, with margin, within the driver's continuous current — and how much angular
momentum does the rotor then store?

**What it is.** A static calculation on the research engine's own plant for a device profile (the same m·g·l, inertia
and centre-of-mass model the controllers are designed on, `devices/configgen.design`) and the profile's motor values.
For the reference profile `aeris-ref-a1` every input is a **nominal-model** value (its `value_sources`); the driver
limits are the manufacturer's published figures with their check dates in `hardware/bom/aeris-kit-a1.bom.json`.

**What it is not.** No dynamics (the controller needs torque to accelerate the cube back, not only to hold it — the ×2
margin stands in for that), no thermal model, no friction or back-EMF limit beyond what is stated, no measured value.
It is not a qualification of anything and it does not select a part. A real build re-runs it with its own profile and
then measures (COMMISSIONING.md).

## Method

* **Gravity torque** at a tilt θ from the balance attitude: τ_g = m·g·l · sin θ, with m·g·l from the engine's plant of
  the mode (edge: about the support edge; corner: m·g·|r_c| about the pivot corner).
* **Per-wheel share**: edge — one drive wheel acts about the edge (share 1); corner — the worst-case share of a
  horizontal torque on one body axis with the cube diagonal vertical, √(2/3).
* **Current** at the profile's torque constant k_t = 60 / (2π·KV) (the engine's convention): I = τ_wheel / k_t.
* **Time to saturate** at that torque: H_max / τ_wheel, with the momentum capacity H_max = J_w · ω_max.
* **Requirement**: with a ×2 margin at the recipe's start limit (`limits.tilt_start_deg`, 3° in the reference recipes),
  the current must lie within the driver's **continuous** rating; the static limit is the tilt the continuous (or
  peak) current can hold at all.
* **Consequence of a lower KV**: the KV that meets the requirement, the speed it reaches on the same supply (assuming
  the driver applies at most 0.78 of the supply voltage — an assumption of the tool, not a published figure), the
  momentum the profile's rotor would then store, and the rotor inertia needed to keep the profile's momentum capacity.

## Result for the reference profile

<!-- sizing.py output: begin (generated; python hardware/tools/sizing.py --update-doc hardware/SIZING.md) -->

Profile **aeris-ref-a1** — wheel model: KV 500 rpm/V → k_t = 60/(2π·KV) = 0.0191 N·m/A (engine convention), I_max 8 A → τ_max 0.153 N·m, J_w 0.0005 kg·m², speed limit 5000 rpm → momentum capacity H_max = J_w·ω_max = 0.262 N·m·s.

### edge (edge-hold-10s): m·g·l = 2.247 N·m, per-wheel share 1.000

| tilt from balance | gravity torque | per-wheel torque | current at profile k_t | time to saturate at that torque |
|---:|---:|---:|---:|---:|
| 0.5° | 0.0196 N·m | 0.0196 N·m | 1.03 A | 13.35 s |
| 1° | 0.0392 N·m | 0.0392 N·m | 2.05 A | 6.67 s |
| 2° | 0.0784 N·m | 0.0784 N·m | 4.11 A | 3.34 s |
| 3° | 0.1176 N·m | 0.1176 N·m | 6.16 A | 2.23 s |
| 5° | 0.1959 N·m | 0.1959 N·m | 10.26 A | 1.34 s |

With a ×2 margin at the recipe's start limit (3°): 0.2352 N·m per wheel = 12.32 A at the profile's k_t. Static limit at the profile's I_max: 3.90°.

### corner (corner-hold-10s): m·g·l = 2.753 N·m, per-wheel share 0.816

| tilt from balance | gravity torque | per-wheel torque | current at profile k_t | time to saturate at that torque |
|---:|---:|---:|---:|---:|
| 0.5° | 0.0240 N·m | 0.0196 N·m | 1.03 A | 13.35 s |
| 1° | 0.0480 N·m | 0.0392 N·m | 2.05 A | 6.67 s |
| 2° | 0.0961 N·m | 0.0784 N·m | 4.11 A | 3.34 s |
| 3° | 0.1441 N·m | 0.1176 N·m | 6.16 A | 2.23 s |
| 5° | 0.2399 N·m | 0.1959 N·m | 10.26 A | 1.34 s |

With a ×2 margin at the recipe's start limit (3°): 0.2352 N·m per wheel = 12.32 A at the profile's k_t. Static limit at the profile's I_max: 3.90°.

### Candidate driver: ODrive Micro (docs 0.6.12) — 3.5 A continuous, 7 A peak, 10–31 V

| mode | current needed (×2 margin) | within continuous | within peak | static limit (continuous) | static limit (peak) | k_t needed at continuous | KV at most |
|---|---:|:---:|:---:|---:|---:|---:|---:|
| edge | 12.32 A | **no** | **no** | 1.70° | 3.41° | 0.0672 N·m/A | 142 rpm/V |
| corner | 12.32 A | **no** | **no** | 1.70° | 3.41° | 0.0672 N·m/A | 142 rpm/V |

- Supply: the profile allows 9.9–12.6 V; **its minimum is below the driver's minimum**; within the driver's maximum.
- Current: the profile's per-motor limit 8 A is **above the driver's peak rating**.
- Braking wheels return energy to the DC bus and this driver has no brake-resistor control: the power system needs an energy path (a battery that may be charged at that current, or an external regeneration clamp) and the driver's negative-current and over-voltage limits set accordingly.
- A motor with KV ≈ 142 rpm/V would meet the margin within the continuous rating, but on the same supply (assuming the driver applies at most 0.78 of the supply voltage — an assumption, not a published figure) it reaches ≈ 1230 rpm: the profile's J_w would then store only 0.064 N·m·s; keeping the momentum capacity needs J_w ≈ 0.0020 kg·m².

<!-- sizing.py output: end -->

## Reading the result

* With the nominal motor model (KV 500 rpm/V, k_t ≈ 0.019 N·m/A) the ×2-margin current at the 3° start limit is about
  12 A per wheel — above the candidate driver's 3.5 A continuous and 7 A peak ratings. Its continuous current holds the
  nominal cube **statically only up to ≈1.7°** from balance.
* Meeting the margin within 3.5 A needs k_t ≥ ≈0.067 N·m/A (KV ≲ 142 rpm/V). On the same supply such a motor turns far
  slower, so the rotor needs about four times the nominal inertia to store the same momentum — a heavier or larger
  rotor, which changes the mass model.
* The reference profile's supply range (9.9–12.6 V) starts below the candidate driver's 10 V minimum, and its 8 A motor
  limit is above the driver's 7 A peak: a build with this driver needs a **profile revision** within the driver's
  limits.
* Braking wheels return energy to the DC bus and the candidate driver has no brake-resistor control: the power system
  needs an energy path (a battery allowed to absorb the regenerative current, or an external regeneration clamp) and
  the driver's negative-current and over-voltage limits set to match (INTEGRATION.md, COMMISSIONING.md).

**Therefore the motor, rotor and driver are selected together** — a lower-KV motor with a larger rotor, or a driver
with a higher current rating — and only then the frame, the power system and the harness. Until that selection exists
the kit stays at readiness `candidate` (README.md).

## Running it

```bash
python hardware/tools/sizing.py                            # the reference profile (Markdown)
python hardware/tools/sizing.py --profile my-cube.json     # your aeris-device-profile/1 document
python hardware/tools/sizing.py --json                     # machine-readable
python hardware/tools/sizing.py --check-doc hardware/SIZING.md   # the block above matches the code (run by the test runner)
```

It needs the backend package (it imports the engine's plant): run it with the backend's Python
(`backend/.venv/bin/python`).

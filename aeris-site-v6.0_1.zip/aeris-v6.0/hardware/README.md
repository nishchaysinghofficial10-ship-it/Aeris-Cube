# AERIS hardware (v6.0)

The reference cube **A1**, revision **A1-candidate**: the build content behind the website's optional Build page. The
virtual cube needs none of it.

**Readiness: candidate.** The development electronics are named with their published data and check dates; the
motors, rotors, frame, harness, power system, local controls and fixture are **not selected or designed**. No A1 cube
has been assembled, measured or balanced, and nothing here is a tested design.

## Contents

| Path | What it is |
|---|---|
| `bom/aeris-kit-a1.bom.json` | the provisional bill of materials (`aeris-bom/1`): every item with quantity, status (`candidate` or `unresolved`), part, function, manufacturer facts with their **source and check date**, compatibility notes, supplier links and tested substitutions (none); tools; open engineering. The single source: the site serves an identical copy |
| `tools/make_kit.py` | writes the kit document (`aeris-kit/1`: readiness, BOM reference by SHA-256, downloads, sizing summary, guided steps) to the site and the backend, the site's BOM copy and `BUILD_GUIDE.md`; `--check` detects drift |
| `tools/sizing.py` | the calculation for selecting the motor, rotor and driver together (`--profile`, `--json`, `--check-doc`) |
| [BUILD_GUIDE.md](BUILD_GUIDE.md) | the build guide as one page (generated: the same content as the Build page) |
| [SIZING.md](SIZING.md) | the sizing method and its result for the reference profile |
| [INTEGRATION.md](INTEGRATION.md) | pins, IMU, **CAN** (every driver setting the firmware relies on), local controls, drive power, power requirements |
| [COMMISSIONING.md](COMMISSIONING.md) | the engineering work and measurements that remain before motors may be energised; the commissioning mode; product hardening |

What does **not** exist: CAD, drawings or manufacturing files for the frame, guards, mounts and pivot pieces; a
controller-board schematic or PCB; a harness drawing; photographs or videos of an A1 build (the site's renders and
video show the AERIS Cube concept and are labelled illustrations); measured mass properties; a selected motor, rotor or
power system; tested substitutions. The Build page lists each missing asset as unavailable with the reason.

## Readiness levels

| Level | What it requires | A1 |
|---|---|---|
| concept | an idea and a model | done (the AERIS model and the virtual cube) |
| **candidate** | development electronics named with checked published data; the open items listed | **current** |
| engineered | motor, rotor and driver selected by the sizing with margin; frame, guards, mounts, pivot pieces in CAD; power system, controller board and harness designed; an exact BOM | no |
| manufactured | one cube built to that design; its measured profile (mass properties, rotor inertias, motor constants) | no |
| bench-tested | commissioning completed (COMMISSIONING.md), qualified limits, recorded edge and corner trials in the fixture | no |
| beginner-validated | built and operated by someone outside the project from the published material alone, with tested assembly drawing, manufacturing files, exact BOM and a keyed, precrimped harness | no |

A level is a statement about evidence, never a setting: the software cannot raise it, and a profile's qualification can
be declared by users only as `experimental` or `unqualified` (DEVICES.md).

## Status of the hardware items

| Item | Implemented | Software-tested | Hardware-tested | Blocked / open |
|---|---|---|---|---|
| BOM with sources and check dates; kit document; Build page | yes | content checks (`make_kit.py --check`, schema validation, browser suite) | — | — |
| Sizing calculation | yes | `sizing.py --check-doc`; used by the kit document | — | inputs are nominal-model values |
| Firmware pin map, IMU and CAN drivers, local controls, DRIVE_EN policy | yes (firmware) | host tests against register and bus models; QEMU boot | **no** | a board |
| Motors, rotors, frame, harness, power system, local-control parts, fixture | — | — | **no** | not selected / not designed |
| Measured profile, calibration of a real cube | software exists | with synthetic devices | **no** | a built cube |

Hardware-tested: **none**. See COMMISSIONING.md for what that requires and in which order.

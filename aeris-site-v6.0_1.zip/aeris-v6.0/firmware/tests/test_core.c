#define _POSIX_C_SOURCE 200809L
/* AERIS firmware core — host tests: units (formatting, parsing, CRC, base64url, strict JSON, configuration
 * validation), parity with the backend's estimator and controllers (fixtures generated from the backend), and the
 * whole device against the synthetic device (protocol, sessions, commands, state machine, protection, pairing,
 * telemetry backfill, calibration, commissioning, balancing of the MODEL plant).
 *
 * Every device-level result here is SYNTHETIC: it shows what the firmware core does with the models of the IMU, the
 * drivers and the plant — not what a physical cube does. */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "harness.h"
#include "aeris/util.h"
#include "aeris/mathq.h"

static const char *FXDIR = "tests/fixtures";
static int g_pass, g_fail, g_n;
static const char *g_test;
static int g_test_failed;

#define CHECK(cond, ...) do { if (!(cond)) { if (!g_test_failed) { printf("not ok %d - %s\n", g_n, g_test); } g_test_failed = 1; \
    printf("#   %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

typedef void (*test_fn)(void);
static int g_only;
static void run(const char *name, test_fn f) {
    g_n++;
    if (g_only && g_n != g_only) return;
    g_test = name;
    g_test_failed = 0;
    f();
    if (g_test_failed) g_fail++;
    else { g_pass++; printf("ok %d - %s\n", g_n, name); }
    fflush(stdout);
}

/* ------------------------------------------------------------------------------------------------ helpers */
static void press(H *h, double s) { simdev_set_arm(h->s, true); h_run(h, s); simdev_set_arm(h->s, false); h_run(h, 0.01); }

static void params_for(sim_params_t *p, const char *mode) {
    if (!fx_plant(FXDIR, mode, p)) { fprintf(stderr, "cannot read the plant fixture (run firmware/tools/make_fixtures.py)\n"); exit(2); }
}

static void connect_usb(H *h) {
    h_hello(h, AERIS_LINK_USB);
    h_session(h, AERIS_LINK_USB, "usb-session-0001", 1);
    h_run(h, 0.01);
}

static char *config_cmd_params(const char *cfg) {
    size_t n = strlen(cfg) + 32;
    char *b = malloc(n);
    snprintf(b, n, "{\"config\":%s}", cfg);
    return b;
}

static bool apply_cfg(H *h, const char *cfg, const char *hash) {
    char *pp = config_cmd_params(cfg);
    const char *id = h_cmd(h, AERIS_LINK_USB, "apply_config", pp, hash, 5000);
    char idc[48];
    bool ok;
    snprintf(idc, sizeof idc, "%s", id);
    free(pp);
    ok = h_wait_status(h, idc, "completed", 1.0) >= 0;
    return ok;
}

static bool to_ready(H *h, const char *mode) {
    char id[48];
    const char *cfg = mode[0] == 'e' ? FX_CONFIG_EDGE : FX_CONFIG_CORNER, *hash = mode[0] == 'e' ? FX_HASH_EDGE : FX_HASH_CORNER;
    connect_usb(h);
    if (!apply_cfg(h, cfg, hash)) return false;
    snprintf(id, sizeof id, "%s", h_cmd(h, AERIS_LINK_USB, "self_test", NULL, NULL, 2000));
    if (h_wait_status(h, id, "completed", 5.0) < 0) return false;
    return h->s->dev.state == ST_READY;
}

/* keeps the session alive while running (a supervising host sends heartbeats) */
static void run_hb(H *h, double seconds, int link) {
    double t = 0;
    char b[200];
    while (t < seconds) {
        snprintf(b, sizeof b, "{\"kind\":\"heartbeat\",\"link_session\":\"%s\"}", h->session[link]);
        h_send(h, link, b);
        h_run(h, 0.1);
        t += 0.1;
    }
}

static double g_settled;     /* mean true tilt over the last second of max_tilt_during [rad] */
static double max_tilt_during(H *h, double seconds, int link) {
    double t = 0, m = 0, sum = 0;
    int k = 0, n = 0;
    (void)link;
    while (t < seconds) {
        double x;
        h_run(h, 0.001);
        t += 0.001;
        k++;
        x = simdev_tilt_from_balance(h->s);
        if (x > m) m = x;
        if (t > seconds - 1.0) { sum += x; n++; }
    }
    g_settled = n ? sum / n : 0;
    return m;
}

static const char *start_exp(H *h, const char *hash, double duration) {
    char p[80];
    snprintf(p, sizeof p, "{\"duration_s\":%g}", duration);
    return h_cmd(h, AERIS_LINK_USB, "start_experiment", p, hash, 5000);
}

/* ------------------------------------------------------------------------------------------------ units */
static void t_util_format_parse(void) {
    char b[64];
    double v;
    struct { double x; int sig; const char *s; } F[] = {{0.0, 9, "0"}, {-0.0, 9, "0"}, {1.0, 9, "1"}, {-2.5, 9, "-2.5"}, {123.456, 9, "123.456"},
                                                        {1e-5, 9, "0.00001"}, {1e-7, 9, "1e-7"}, {1e21, 9, "1e21"}, {0.1, 17, "0.1"},
                                                        {123.456, 17, "123.456"}, {6.02214076e23, 9, "6.02214076e23"}, {0.30000000000000004, 17, "0.30000000000000004"}};
    unsigned i;
    for (i = 0; i < sizeof F / sizeof F[0]; i++) {
        au_fmt_double(b, sizeof b, F[i].x, F[i].sig);
        CHECK(strcmp(b, F[i].s) == 0, "%.17g with %d digits gave '%s' (expected '%s')", F[i].x, F[i].sig, b, F[i].s);
    }
    CHECK(au_fmt_double(b, sizeof b, NAN, 17) == 0, "NaN must be refused");
    CHECK(au_fmt_double(b, sizeof b, INFINITY, 17) == 0, "infinity must be refused");
    {
        const char *bad[] = {"01", "1.", ".5", "+1", "1e", "NaN", "--1", "1e+", "0x10", "", "-", "1 "};
        const char *good[] = {"-0", "1e-05", "1E+2", "0.5", "-12.25e3", "0", "123.456", "0.1", "9007199254740993", "1e-300"};
        for (i = 0; i < sizeof bad / sizeof bad[0]; i++) CHECK(!au_parse_double(bad[i], strlen(bad[i]), &v), "'%s' must be refused", bad[i]);
        for (i = 0; i < sizeof good / sizeof good[0]; i++) {
            double r = strtod(good[i], NULL);
            CHECK(au_parse_double(good[i], strlen(good[i]), &v) && fabs(v - r) <= 4 * fabs(nextafter(r, INFINITY) - r), "'%s' parsed to %.17g, strtod %.17g", good[i], v, r);
        }
    }
    {   /* single-precision values (what the device computes): 9 digits read back as the same float, in every binade */
        uint64_t s = 99;
        int k, bad = 0, bad15 = 0, far17 = 0;
        for (k = 0; k < 200000; k++) {
            uint32_t u;
            float f, g;
            s = s * 6364136223846793005ull + 1442695040888963407ull;
            u = (uint32_t)(s >> 33) & 0x7F7FFFFFu;
            if ((u >> 23) == 0) u |= 0x00800000u;          /* normal numbers */
            memcpy(&f, &u, 4);
            if (k & 1) f = -f;
            au_fmt_double(b, sizeof b, (double)f, 9);
            if (!au_parse_double(b, strlen(b), &v)) { bad++; continue; }
            g = (float)v;
            if (g != f) bad++;
        }
        CHECK(bad == 0, "%d of 200000 random floats did not read back exactly at 9 digits", bad);
        for (k = 0; k < 100000; k++) {   /* decimals of up to 15 digits: parsed exactly as strtod */
            char t[40];
            double x, r;
            s = s * 6364136223846793005ull + 1442695040888963407ull;
            x = (double)(s >> 11) * 0x1p-53 * 1000.0;
            snprintf(t, sizeof t, "%.15g", x);
            r = strtod(t, NULL);
            if (!au_parse_double(t, strlen(t), &v) || v != r) bad15++;
            au_fmt_double(b, sizeof b, x, 17);
            if (!au_parse_double(b, strlen(b), &v) || fabs(v - x) > 4 * fabs(nextafter(x, INFINITY) - x)) far17++;
        }
        CHECK(bad15 == 0, "%d of 100000 15-digit decimals were not parsed exactly", bad15);
        CHECK(far17 == 0, "%d of 100000 doubles were not reproduced within 4 ulp at 17 digits", far17);
    }
    {
        int64_t iv;
        CHECK(au_parse_int("12345", 5, &iv) && iv == 12345, "int");
        CHECK(!au_parse_int("1.5", 3, &iv), "a fraction is not an integer");
        CHECK(!au_parse_int("1e3", 3, &iv), "an exponent is not an integer");
    }
}

static void t_crc_b64(void) {
    uint8_t out[16];
    char b[32];
    CHECK(au_crc32((const uint8_t *)"123456789", 9) == 0xCBF43926u, "CRC-32 check value");
    CHECK(au_crc32((const uint8_t *)"", 0) == 0u, "CRC-32 of nothing");
    au_b64url_encode(b, sizeof b, (const uint8_t *)"foob", 4); CHECK(strcmp(b, "Zm9vYg") == 0, "base64url 'foob' -> %s", b);
    au_b64url_encode(b, sizeof b, (const uint8_t *)"fooba", 5); CHECK(strcmp(b, "Zm9vYmE") == 0, "base64url 'fooba' -> %s", b);
    au_b64url_encode(b, sizeof b, (const uint8_t *)"\xfb\xff", 2); CHECK(strcmp(b, "-_8") == 0, "base64url alphabet -> %s", b);
    CHECK(au_b64url_decode(out, sizeof out, "Zm9vYmE", 7) == 5 && memcmp(out, "fooba", 5) == 0, "decode");
    CHECK(au_b64url_decode(out, sizeof out, "Zm9vYmF", 7) < 0, "non-canonical trailing bits refused");
    CHECK(au_b64url_decode(out, sizeof out, "Zm9v+mE", 7) < 0, "standard alphabet refused");
}

static void t_json_strict(void) {
    jsmntok_t t[64];
    aj_doc_t d;
    char s[64];
    const char *raw;
    size_t n;
#define P(js) aj_parse(&d, js, strlen(js), t, 64)
    CHECK(P("{\"a\":1,\"a\":2}") == -3, "duplicate keys refused");
    CHECK(P("{\"o\":{\"x\":1,\"x\":1}}") == -3, "duplicate keys in a nested object refused");
    CHECK(P("[1,2]") == -2, "top level must be an object");
    CHECK(P("{\"a\":1") < 0, "truncated");
    CHECK(P("{\"a\":1} x") < 0, "trailing text refused");
    CHECK(P("{\"s\":\"a\\u00e9\\n\\\"b\",\"r\":{\"k\":[1, 2]}}") > 0, "valid");
    CHECK(aj_str(&d, aj_get(&d, 0, "s"), s, sizeof s) && strcmp(s, "a\xc3\xa9\n\"b") == 0, "escapes decoded: %s", s);
    CHECK(aj_raw(&d, aj_get(&d, 0, "r"), &raw, &n) && n == 12 && memcmp(raw, "{\"k\":[1, 2]}", 12) == 0, "raw bytes kept exactly");
    CHECK(P("{\"s\":\"\\u0000\"}") > 0 && !aj_str(&d, aj_get(&d, 0, "s"), s, sizeof s), "NUL in a string refused");
#undef P
}

static void t_config_validation(void) {
    jsmntok_t *t = malloc(sizeof(jsmntok_t) * 512);
    aj_doc_t d;
    aeris_cfg_t c;
    char err[200], *m;
    simdev_t *s = calloc(1, sizeof *s);
    sim_params_t p;
    struct { const char *find, *repl, *path; } M[] = {
        {"\"type\":\"edge-lqr\"", "\"type\":\"pid\"", "config.controller.type"},
        {"\"to_body\":[1,0,0,0,1,0,0,0,1]", "\"to_body\":[1,0,0,0,1,0,0,0,-1]", "config.imu.to_body"},
        {"\"speed_max_rpm\":5000.0", "\"speed_max_rpm\":9000.0", "config.wheels[].speed_max_rpm"},
        {"\"telemetry_hz\":50", "\"telemetry_hz\":30", "config.rates.telemetry_hz"},
        {"\"driver\":\"lsm6dsox\"", "\"driver\":\"mpu6050\"", "config.imu.driver"},
        {"\"tilt_start_deg\":3.0", "\"tilt_start_deg\":13.0", "config.limits.tilt_start_deg"},
        {"\"schema\":\"aeris-device-config/1\"", "\"schema\":\"aeris-device-config/2\"", "config.schema"},
        {"\"node\":2", "\"node\":1", "config.wheels[].node"},
        {"\"driver\":\"odrive-cansimple\"", "\"driver\":\"vesc-can\"", "config.wheels[].driver"},
    };
    unsigned i;
    params_for(&p, "edge");
    simdev_init(s, &p, NULL, "x", "host");
    CHECK(aj_parse(&d, FX_CONFIG_EDGE, strlen(FX_CONFIG_EDGE), t, 512) > 0 && cfg_parse(&c, &d, 0, &s->board, err, sizeof err), "edge fixture: %s", err);
    CHECK(c.controller == CTRL_EDGE_LQR && c.control_hz == 500 && c.telemetry_hz == 50, "edge fields");
    CHECK(aj_parse(&d, FX_CONFIG_CORNER, strlen(FX_CONFIG_CORNER), t, 512) > 0 && cfg_parse(&c, &d, 0, &s->board, err, sizeof err), "corner fixture: %s", err);
    CHECK(c.controller == CTRL_CORNER_MIMO, "corner controller");
    for (i = 0; i < sizeof M / sizeof M[0]; i++) {
        const char *at = strstr(FX_CONFIG_EDGE, M[i].find);
        size_t a, nf = strlen(M[i].find), nr = strlen(M[i].repl);
        if (!at) { CHECK(0, "fixture text '%s' not found", M[i].find); continue; }
        a = (size_t)(at - FX_CONFIG_EDGE);
        m = malloc(strlen(FX_CONFIG_EDGE) + nr + 1);
        memcpy(m, FX_CONFIG_EDGE, a); memcpy(m + a, M[i].repl, nr); strcpy(m + a + nr, at + nf);
        err[0] = 0;
        CHECK(aj_parse(&d, m, strlen(m), t, 512) > 0 && !cfg_parse(&c, &d, 0, &s->board, err, sizeof err) && strncmp(err, M[i].path, strlen(M[i].path)) == 0,
              "mutation %u must be refused at %s (got '%s')", i, M[i].path, err);
        free(m);
    }
    free(s);
    free(t);
}

/* ------------------------------------------------------------------------------------------------ parity with the backend */
/* angle between two attitudes, computed from the relative quaternion's vector part (well conditioned near 0) */
static double qangle(const float a[4], const double b[4]) {
    double w = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
    double x = a[0] * b[1] - a[1] * b[0] - a[2] * b[3] + a[3] * b[2];
    double y = a[0] * b[2] + a[1] * b[3] - a[2] * b[0] - a[3] * b[1];
    double z = a[0] * b[3] - a[1] * b[2] + a[2] * b[1] - a[3] * b[0];
    return 2 * atan2(sqrt(x * x + y * y + z * z), fabs(w));
}

static void t_estimator_parity(void) {
    char path[600];
    size_t n;
    char *js;
    jsmntok_t *t = malloc(sizeof(jsmntok_t) * 200000);
    aj_doc_t d;
    int sm, out, k, ns, et;
    aeris_cfg_t c;
    est_t e;
    double max_q = 0, max_p = 0, max_b = 0;
    int acc_mismatch = 0, gated_mismatch = 0;
    snprintf(path, sizeof path, "%s/parity_estimator.json", FXDIR);
    js = h_read_file(path, &n);
    CHECK(js && aj_parse(&d, js, n, t, 200000) > 0, "fixture");
    if (!js) { free(t); return; }
    memset(&c, 0, sizeof c);
    et = aj_get(&d, 0, "estimator");
    { double v; aj_num(&d, aj_get(&d, et, "tau_s"), &v); c.tau_s = (float)v; aj_num(&d, aj_get(&d, et, "accel_gate_mps2"), &v); c.accel_gate = (float)v;
      aj_num(&d, aj_get(&d, et, "bias_gain"), &v); c.bias_gain = (float)v; aj_num(&d, aj_get(&d, et, "tau_alpha_s"), &v); c.tau_alpha_s = (float)v;
      aj_num(&d, aj_get(&d, et, "stale_after_s"), &v); c.stale_after_s = (float)v; aj_num(&d, aj_get(&d, et, "g_mps2"), &v); c.g = (float)v;
      aj_vecf(&d, aj_get(&d, et, "imu_position_m"), c.imu_pos, 3); aj_vecf(&d, aj_get(&d, et, "q_nominal"), c.q_nominal, 4);
      aj_bool(&d, aj_get(&d, et, "compensate_dynamic"), &c.compensate_dynamic); }
    est_init(&e, &c);
    sm = aj_get(&d, 0, "samples");
    out = aj_get(&d, 0, "outputs");
    ns = aj_arr_len(&d, sm);
    CHECK(ns > 500, "samples");
    for (k = 0; k < ns; k++) {
        int st = aj_arr_at(&d, sm, k), ot = aj_arr_at(&d, out, k);
        double ts, q[4], qp[4], b[3];
        float g[3], a[3], qe[4], we[3], age;
        bool acc, want_acc;
        double gated;
        int i;
        aj_num(&d, aj_arr_at(&d, st, 0), &ts);
        aj_vecf(&d, aj_arr_at(&d, st, 1), g, 3);
        aj_vecf(&d, aj_arr_at(&d, st, 2), a, 3);
        acc = est_accept(&e, ts, g, a, ts);
        aj_bool(&d, aj_get(&d, ot, "accepted"), &want_acc);
        if (acc != want_acc) acc_mismatch++;
        for (i = 0; i < 4; i++) { aj_num(&d, aj_arr_at(&d, aj_get(&d, ot, "q"), i), &q[i]); aj_num(&d, aj_arr_at(&d, aj_get(&d, ot, "q_pred"), i), &qp[i]); }
        for (i = 0; i < 3; i++) aj_num(&d, aj_arr_at(&d, aj_get(&d, ot, "b"), i), &b[i]);
        aj_num(&d, aj_get(&d, ot, "gated"), &gated);
        if ((double)e.gated != gated) gated_mismatch++;
        if (qangle(e.q, q) > max_q) max_q = qangle(e.q, q);
        {   /* the controller-facing prediction 0.7 ms after the sample (as the backend's predict) */
            double tq;
            aj_num(&d, aj_arr_at(&d, aj_arr_at(&d, sm, k), 0), &tq);
            (void)tq;
        }
        est_predict(&e, (double)k / 833.0 + 0.0007, qe, we, &age);
        if (qangle(qe, qp) > max_p) max_p = qangle(qe, qp);
        for (i = 0; i < 3; i++) if (fabs(e.b[i] - b[i]) > max_b) max_b = fabs(e.b[i] - b[i]);
    }
    CHECK(acc_mismatch == 0, "%d samples accepted/rejected differently from the backend", acc_mismatch);
    CHECK(gated_mismatch == 0, "%d samples gated differently from the backend", gated_mismatch);
    CHECK(max_q < 2e-4, "filter attitude differs from the backend by up to %.3g rad (single vs double precision)", max_q);
    CHECK(max_p < 2e-4, "prediction differs by up to %.3g rad", max_p);
    CHECK(max_b < 1e-6, "bias differs by %.3g", max_b);
    printf("#   estimator parity: max |Δq| %.2e rad, prediction %.2e rad over %d samples (float32 vs float64)\n", max_q, max_p, ns);
    free(js);
    free(t);
}

static void controller_parity(const char *mode) {
    char path[600], err[200];
    size_t n;
    char *js;
    jsmntok_t *t = malloc(sizeof(jsmntok_t) * 20000), *tc = malloc(sizeof(jsmntok_t) * 512);
    aj_doc_t d, dc;
    aeris_cfg_t c;
    ctrl_t k;
    int cs, i, nc;
    double max_err = 0, max_T = 0;
    simdev_t *s = calloc(1, sizeof *s);
    sim_params_t p;
    params_for(&p, mode);
    simdev_init(s, &p, NULL, "x", "host");
    snprintf(path, sizeof path, "%s/parity_controller_%s.json", FXDIR, mode);
    js = h_read_file(path, &n);
    CHECK(js && aj_parse(&d, js, n, t, 20000) > 0, "fixture");
    {
        const char *cfg = mode[0] == 'e' ? FX_CONFIG_EDGE : FX_CONFIG_CORNER;
        CHECK(aj_parse(&dc, cfg, strlen(cfg), tc, 512) > 0 && cfg_parse(&c, &dc, 0, &s->board, err, sizeof err), "config: %s", err);
    }
    ctrl_init(&k, &c);
    cs = aj_get(&d, 0, "cases");
    nc = aj_arr_len(&d, cs);
    for (i = 0; i < nc; i++) {
        int ct = aj_arr_at(&d, cs, i), j;
        float q[4], w[3], om[3], T[3];
        double want[3];
        aj_vecf(&d, aj_get(&d, ct, "q"), q, 4);
        aj_vecf(&d, aj_get(&d, ct, "w"), w, 3);
        aj_vecf(&d, aj_get(&d, ct, "omega"), om, 3);
        for (j = 0; j < 3; j++) aj_num(&d, aj_arr_at(&d, aj_get(&d, ct, "T"), j), &want[j]);
        if (i == 0) ctrl_start(&k, q);
        ctrl_request(&k, q, w, om, T);
        for (j = 0; j < 3; j++) {
            double e = fabs((double)T[j] - want[j]);
            if (e > max_err) max_err = e;
            if (fabs(want[j]) > max_T) max_T = fabs(want[j]);
        }
    }
    CHECK(nc >= 50, "cases");
    CHECK(max_err < 1e-4 * (max_T > 1 ? max_T : 1), "%s controller differs from the backend by up to %.3g N·m (largest torque %.3g)", mode, max_err, max_T);
    printf("#   %s controller parity: max |ΔT| %.2e N·m over %d cases (largest |T| %.3g N·m)\n", mode, max_err, nc, max_T);
    free(js); free(t); free(tc); free(s);
}
static void t_controller_parity_edge(void) { controller_parity("edge"); }
static void t_controller_parity_corner(void) { controller_parity("corner"); }

/* ------------------------------------------------------------------------------------------------ the device: link */
static void t_boot_and_hello(void) {
    H h;
    sim_params_t p;
    char s[64];
    bool b;
    int i;
    params_for(&p, "edge");
    h_init(&h, &p, 11);
    h_run(&h, 0.2);
    CHECK(h.n == 0, "the device must stay silent until a host_hello (%d messages)", h.n);
    h_hello(&h, AERIS_LINK_USB);
    h_run(&h, 0.01);
    i = h_find(&h, 0, "dev_hello", 0);
    CHECK(i >= 0, "dev_hello");
    CHECK(h_str(&h, i, "link", s, sizeof s) && strcmp(s, "aeris-device-link/1") == 0, "link protocol");
    CHECK(h_bool(&h, i, "board.synthetic", &b) && b, "board.synthetic true");
    CHECK(h_str(&h, i, "board.kind", s, sizeof s) && strcmp(s, "emulator") == 0, "board.kind emulator");
    CHECK(h_str(&h, i, "fw.version", s, sizeof s) && strcmp(s, AERIS_FW_VERSION) == 0, "fw.version");
    CHECK(h_str(&h, i, "state", s, sizeof s) && strcmp(s, "DISARMED") == 0, "boots DISARMED");
    CHECK(h_is_null(&h, i, "config_hash"), "no configuration after boot");
    CHECK(h_find(&h, 0, "state", 0) >= 0, "state message");
    CHECK(h_find(&h, 0, "hello", 0) < 0, "no telemetry session before an approved configuration");
    CHECK(!h.s->motor_power, "driver power off after boot");
    CHECK(h.unframed[0] == 0 && h.bad_crc[0] == 0, "every line framed with a valid CRC");
    h_free(&h);
}

static void t_framing_errors(void) {
    H h;
    sim_params_t p;
    char s[120];
    int i0, i;
    char *big;
    params_for(&p, "edge");
    h_init(&h, &p, 12);
    h_send(&h, 0, "{\"kind\":\"session\",\"link_session\":\"abcdefgh\",\"lease_epoch\":1}");
    h_run(&h, 0.01);
    i = h_find(&h, 0, "link_error", 0);
    CHECK(i >= 0 && h_str(&h, i, "reason", s, sizeof s) && strstr(s, "host_hello"), "messages before host_hello refused");
    h_hello(&h, 0);
    h_run(&h, 0.01);
    i0 = h.n;
    { const char *r = "{\"kind\":\"heartbeat\"}\t00000000\n"; h_send_raw(&h, 0, r, strlen(r)); }
    h_run(&h, 0.01);
    i = h_find(&h, 0, "link_error", i0);
    CHECK(i >= 0 && h_str(&h, i, "reason", s, sizeof s) && strstr(s, "CRC"), "bad CRC refused");
    i0 = h.n;
    { const char *r = "{\"kind\":\"heartbeat\"}\n"; h_send_raw(&h, 0, r, strlen(r)); }
    h_run(&h, 0.01);
    i = h_find(&h, 0, "link_error", i0);
    CHECK(i >= 0 && h_str(&h, i, "reason", s, sizeof s) && strstr(s, "unframed"), "unframed refused");
    i0 = h.n;
    h_send(&h, 0, "{\"kind\":\"tlm_ack\",\"seq\":1,\"seq\":2}");
    h_run(&h, 0.01);
    i = h_find(&h, 0, "link_error", i0);
    CHECK(i >= 0 && h_str(&h, i, "reason", s, sizeof s) && strstr(s, "twice"), "duplicate key refused");
    i0 = h.n;
    big = malloc(5000);
    memset(big, 'x', 4999);
    big[4999] = '\n';
    h_send_raw(&h, 0, big, 5000);
    free(big);
    h_run(&h, 0.01);
    i = h_find(&h, 0, "link_error", i0);
    CHECK(i >= 0 && h_str(&h, i, "reason", s, sizeof s) && strstr(s, "too long"), "over-long line refused");
    i0 = h.n;
    h_send(&h, 0, "{\"kind\":\"warp_drive\"}");
    h_run(&h, 0.01);
    i = h_find(&h, 0, "link_error", i0);
    CHECK(i >= 0 && h_str(&h, i, "reason", s, sizeof s) && strstr(s, "unknown"), "unknown type refused");
    h_hello(&h, 0);
    h_run(&h, 0.01);
    CHECK(h_find(&h, 0, "dev_hello", i0) >= 0, "the link still works after errors");
    h_free(&h);
}

static void t_command_checks(void) {
    H h;
    sim_params_t p;
    char st[24], reason[200];
    int i;
    const char *id;
    char idc[48];
    params_for(&p, "edge");
    h_init(&h, &p, 13);
    h_hello(&h, 0);
    h_run(&h, 0.01);
    snprintf(h.session[0], sizeof h.session[0], "usb-session-0001");
    id = h_cmd(&h, 0, "identify", NULL, NULL, 1000);
    snprintf(idc, sizeof idc, "%s", id);
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0 && h_str(&h, i, "reason", reason, sizeof reason) && strstr(reason, "no session"), "a command needs a session");
    h_session(&h, 0, "usb-session-0001", 1);
    h_run(&h, 0.01);
    i = h_find(&h, 0, "session_ok", 0);
    CHECK(i >= 0 && h_str(&h, i, "role", st, sizeof st) && strcmp(st, "supervisor") == 0, "USB session is a supervisor");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "identify", "{\"seconds\":1}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "accepted", 0.1) >= 0 && h_wait_status(&h, idc, "completed", 0.1) >= 0, "identify accepted and completed");
    CHECK(h.s->led == 100, "identify pattern on the LED");
    /* duplicate id: the cached status, never a second execution */
    h_cmd_raw(&h, 0, idc, "identify", NULL, NULL, 1000, ++h.seq[0], 1, h.session[0]);
    h_run(&h, 0.01);
    {
        bool dup = false;
        i = h_last(&h, 0, "cmd_ack");
        CHECK(i >= 0 && h_bool(&h, i, "duplicate", &dup) && dup && h_str(&h, i, "status", st, sizeof st) && strcmp(st, "completed") == 0, "duplicate id answered with its cached status");
    }
    /* sequence replay */
    snprintf(idc, sizeof idc, "%s", h_cmd_raw(&h, 0, "replay-1", "identify", NULL, NULL, 1000, 1, 1, h.session[0]));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0 && h_str(&h, i, "reason", reason, sizeof reason) && strstr(reason, "seq"), "replayed sequence refused");
    /* stale lease */
    snprintf(idc, sizeof idc, "%s", h_cmd_raw(&h, 0, "lease-0", "identify", NULL, NULL, 1000, ++h.seq[0], 7, h.session[0]));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0 && h_str(&h, i, "reason", reason, sizeof reason) && strstr(reason, "lease"), "stale lease refused");
    /* ttl bound */
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "identify", NULL, NULL, 60000));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0, "ttl above 10 s refused");
    /* unknown action, wrong state */
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "set_pwm", NULL, NULL, 1000));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0 && h_str(&h, i, "reason", reason, sizeof reason) && strstr(reason, "unknown action"), "no raw motor console");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "clear_faults", NULL, NULL, 1000));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0 && h_str(&h, i, "reason", reason, sizeof reason) && strstr(reason, "DISARMED"), "state guard");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "start_experiment", "{\"duration_s\":1}", FX_HASH_EDGE, 1000));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0, "no experiment without an applied configuration");
    /* diagnostics works and reports the loop */
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "diagnostics", NULL, NULL, 1000));
    i = h_wait_status(&h, idc, "completed", 0.1);
    {
        double ov = -1;
        bool present = false;
        CHECK(i >= 0 && h_num(&h, i, "result.loop.overruns", &ov) && ov == 0, "diagnostics: no loop overruns in virtual time");
        CHECK(i >= 0 && h_bool(&h, i, "result.imu.present", &present) && present, "diagnostics: IMU present");
    }
    /* diagnostics report the local controls as read now (bench wiring checks) and never a driven DRIVE_EN while DISARMED */
    {
        bool stop = true, drive = true, arm = true;
        CHECK(i >= 0 && h_bool(&h, i, "result.inputs.stop_asserted", &stop) && !stop && h_bool(&h, i, "result.inputs.drive_enable", &drive) && !drive &&
              h_bool(&h, i, "result.inputs.arm_pressed", &arm) && !arm, "diagnostics: inputs released, drive enable off in DISARMED");
        simdev_set_estop(h.s, true);
        simdev_set_arm(h.s, true);
        h_run(&h, 0.05);
        snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "diagnostics", NULL, NULL, 1000));
        i = h_wait_status(&h, idc, "completed", 0.1);
        CHECK(i >= 0 && h_bool(&h, i, "result.inputs.stop_asserted", &stop) && stop && h_bool(&h, i, "result.inputs.arm_pressed", &arm) && arm &&
              h_bool(&h, i, "result.inputs.drive_enable", &drive) && !drive, "diagnostics: the stop and ARM inputs are reported as read");
        simdev_set_arm(h.s, false);
        simdev_set_estop(h.s, false);
        h_run(&h, 0.05);
    }
    h_free(&h);
}

/* ------------------------------------------------------------------------------------------------ the device: configuration and states */
static void t_apply_config(void) {
    H h;
    sim_params_t p;
    char st[24], reason[300], s[80], *pp;
    int i, i0;
    char idc[48];
    params_for(&p, "edge");
    h_init(&h, &p, 14);
    connect_usb(&h);
    pp = config_cmd_params(FX_CONFIG_EDGE);
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "apply_config", pp, NULL, 2000));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0, "config_hash required");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "apply_config", pp, FX_HASH_CORNER, 2000));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0 && h_str(&h, i, "reason", reason, sizeof reason) && strstr(reason, "SHA-256"), "hash of other bytes refused");
    free(pp);
    {   /* bytes altered in transit: the hash no longer matches */
        char *m = strdup(FX_CONFIG_EDGE), *at = strstr(m, "\"tilt_abort_deg\":12.0");
        if (at) at[18] = '9';
        pp = config_cmd_params(m);
        snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "apply_config", pp, FX_HASH_EDGE, 2000));
        i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
        CHECK(i >= 0 && strcmp(st, "rejected") == 0, "altered configuration refused");
        free(pp); free(m);
    }
    i0 = h.n;
    CHECK(apply_cfg(&h, FX_CONFIG_EDGE, FX_HASH_EDGE), "valid configuration applied");
    CHECK(strcmp(h.s->dev.cfg.hash_hex, FX_HASH_EDGE) == 0, "the device reports the backend's hash");
    i = h_wait(&h, 0, "hello", i0, 0.1);
    CHECK(i >= 0 && h_str(&h, i, "mode", s, sizeof s) && strcmp(s, "edge") == 0, "telemetry hello with the mode");
    CHECK(i >= 0 && h_str(&h, i, "device.kind", s, sizeof s) && strcmp(s, "emulator") == 0, "telemetry declares an emulator");
    {
        bool syn = false;
        CHECK(i >= 0 && h_bool(&h, i, "synthetic", &syn) && syn, "telemetry declares synthetic: true");
    }
    h_run(&h, 1.0);
    {
        int a = h_find(&h, 0, "frame", i0), cnt = h_count(&h, 0, "frame", i0), k, prev = 0, gaps = 0;
        double v;
        CHECK(a >= 0 && h_str(&h, a, "status", s, sizeof s) && strcmp(s, "idle") == 0, "idle frames while DISARMED");
        CHECK(cnt >= 45 && cnt <= 55, "about 50 frames per second (%d)", cnt);
        for (k = i0; k < h.n; k++) if (h.msgs[k].link == 0 && strstr(h.msgs[k].json, "\"type\":\"frame\"")) {
            h_num(&h, k, "seq", &v);
            if (prev && (int)v != prev + 1) gaps++;
            prev = (int)v;
        }
        CHECK(gaps == 0, "contiguous seq");
        CHECK(a >= 0 && h_num(&h, a, "theta", &v), "edge frames carry theta");
        CHECK(a >= 0 && h_arr_len(&h, a, "wheel_rpm") < 0, "no wheel speeds while the drivers are unpowered (nothing fabricated)");
    }
    h_free(&h);
}

static void t_self_test_ready(void) {
    H h;
    sim_params_t p;
    int i, k, nch;
    bool ready = false;
    char idc[48], name[40];
    params_for(&p, "edge");
    h_init(&h, &p, 15);
    connect_usb(&h);
    CHECK(apply_cfg(&h, FX_CONFIG_EDGE, FX_HASH_EDGE), "config");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "self_test", NULL, NULL, 2000));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0, "self-test executing");
    CHECK(h.s->dev.state == ST_SELF_TEST && h.s->motor_power, "SELF_TEST powers the drivers (no torque)");
    i = h_wait_status(&h, idc, "completed", 5.0);
    CHECK(i >= 0, "self-test completed");
    CHECK(i >= 0 && h_bool(&h, i, "result.ready", &ready) && ready, "READY");
    nch = h_arr_len(&h, i, "result.checks");
    CHECK(nch >= 12, "checks listed (%d)", nch);
    for (k = 0; k < nch; k++) {
        bool ok = false, req = false;
        char path[64];
        snprintf(path, sizeof path, "result.checks.%d.ok", k); h_bool(&h, i, path, &ok);
        snprintf(path, sizeof path, "result.checks.%d.required", k); h_bool(&h, i, path, &req);
        snprintf(path, sizeof path, "result.checks.%d.name", k); h_str(&h, i, path, name, sizeof name);
        CHECK(!req || ok, "required check %s failed", name);
    }
    CHECK(h.s->dev.state == ST_READY, "state READY");
    h_free(&h);
}

static void t_start_needs_local_enable(void) {
    H h;
    sim_params_t p;
    char idc[48], reason[200];
    int i;
    params_for(&p, "edge");
    h_init(&h, &p, 16);
    CHECK(to_ready(&h, "edge"), "READY");
    snprintf(idc, sizeof idc, "%s", start_exp(&h, FX_HASH_EDGE, 5));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0, "waiting for the local enable");
    run_hb(&h, 6.0, 0);
    i = h_wait_status(&h, idc, "expired", 0.01);
    CHECK(i >= 0 && h_str(&h, i, "reason", reason, sizeof reason) && strstr(reason, "local enable"), "expired without ARM");
    CHECK(h.s->dev.state == ST_READY && !h.s->dev.exp_active, "nothing started");
    /* a stale queued request must never start later */
    press(&h, 0.05);
    CHECK(h.s->dev.state == ST_ARMED, "ARM press arms");
    run_hb(&h, 1.0, 0);
    CHECK(h.s->dev.state == ST_ARMED, "the expired command did not start after a later ARM press");
    /* config hash must match the applied configuration */
    snprintf(idc, sizeof idc, "%s", start_exp(&h, FX_HASH_CORNER, 5));
    CHECK(h_wait_status(&h, idc, "rejected", 0.1) >= 0, "start for another configuration refused");
    h_free(&h);
}

static void balance_test(const char *mode, double seconds, double tilt_limit_deg) {
    H h;
    sim_params_t p;
    char idc[48], s[64];
    int i, i0;
    double mt;
    params_for(&p, mode);
    h_init(&h, &p, 17);
    CHECK(to_ready(&h, mode), "READY");
    press(&h, 0.05);
    CHECK(h.s->dev.state == ST_ARMED, "ARMED by the local enable");
    i0 = h.n;
    snprintf(idc, sizeof idc, "%s", start_exp(&h, mode[0] == 'e' ? FX_HASH_EDGE : FX_HASH_CORNER, 10));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0, "executing");
    CHECK(h.s->dev.state == ST_BALANCING, "BALANCING");
    mt = max_tilt_during(&h, seconds, 0);
    CHECK(h.s->dev.state == ST_BALANCING, "still balancing after %.1f s (state %s, faults 0x%x)", seconds, h_state(&h), h.s->dev.faults);
    CHECK(mt * 57.29578 < tilt_limit_deg, "true tilt of the MODEL stayed below %.1f° (max %.3f°)", tilt_limit_deg, mt * 57.29578);
    CHECK(g_settled * 57.29578 < 0.3, "the model settles near its balance attitude (last-second mean %.3f°)", g_settled * 57.29578);
    printf("#   %s: synthetic plant held for %.1f s, max true tilt from balance %.3f° (start 1.0°), last-second mean %.4f°\n", mode, seconds, mt * 57.29578, g_settled * 57.29578);
    i = h_find(&h, 0, "frame", i0);
    while (i >= 0 && h_str(&h, i, "status", s, sizeof s) && strcmp(s, "ok") != 0) i = h_find(&h, 0, "frame", i + 1);
    CHECK(i >= 0, "frames with status ok while balancing");
    CHECK(i >= 0 && h_arr_len(&h, i, "wheel_rpm") == 3 && h_arr_len(&h, i, "torque_cmd") == 3, "wheel speeds and commanded torques in frames");
    {   /* normal stop */
        char sid[48];
        snprintf(sid, sizeof sid, "%s", h_cmd(&h, 0, "stop", NULL, NULL, 1000));
        CHECK(h_wait_status(&h, sid, "completed", 0.1) >= 0, "stop completed");
        CHECK(h.s->dev.state == ST_STOPPING || h.s->dev.state == ST_DISARMED, "STOPPING");
        run_hb(&h, 3.0, 0);
        CHECK(h.s->dev.state == ST_DISARMED, "DISARMED after the normal stop (%s)", h_state(&h));
        i = h_wait_status(&h, idc, "completed", 0.1);
        CHECK(i >= 0 && h_str(&h, i, "result.ended", s, sizeof s) && strcmp(s, "stop requested") == 0, "experiment result: ended by the stop request");
        CHECK(!h.s->motor_power, "driver power off when DISARMED");
    }
    h_free(&h);
}
static void t_balance_edge(void) { balance_test("edge", 6.0, 1.5); }
static void t_balance_corner(void) { balance_test("corner", 6.0, 2.0); }

static void t_duration_end(void) {
    H h;
    sim_params_t p;
    char idc[48], s[64];
    int i;
    params_for(&p, "edge");
    h_init(&h, &p, 18);
    CHECK(to_ready(&h, "edge"), "READY");
    snprintf(idc, sizeof idc, "%s", start_exp(&h, FX_HASH_EDGE, 2.0));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0, "waiting");
    press(&h, 0.05);
    CHECK(h.s->dev.state == ST_BALANCING, "ARM press starts the waiting experiment (%s)", h_state(&h));
    run_hb(&h, 5.0, 0);
    i = h_wait_status(&h, idc, "completed", 0.1);
    CHECK(i >= 0 && h_str(&h, i, "result.ended", s, sizeof s) && strcmp(s, "duration reached") == 0, "ended at its duration");
    CHECK(h.s->dev.state == ST_DISARMED, "DISARMED");
    h_free(&h);
}

static void t_link_loss_policy(void) {
    H h;
    sim_params_t p;
    char idc[48], s[64];
    int i;
    uint64_t t_lost;
    params_for(&p, "edge");
    h_init(&h, &p, 19);
    CHECK(to_ready(&h, "edge"), "READY");
    press(&h, 0.05);
    snprintf(idc, sizeof idc, "%s", start_exp(&h, FX_HASH_EDGE, 10));
    run_hb(&h, 1.0, 0);
    CHECK(h.s->dev.state == ST_BALANCING, "balancing");
    /* the host stops sending heartbeats: the session expires after 1.5 s; the cube keeps balancing for
       limits.link_loss_max_s (0.5 s) and then performs a normal stop — no immediate power cut, no indefinite run */
    h.auto_hb[0] = false;
    h_run(&h, 1.0);
    CHECK(h.s->dev.state == ST_BALANCING && !h.s->dev.link_lost, "still supervised just before the timeout");
    i = h_wait(&h, 0, "session_expired", 0, 0.6);
    CHECK(i >= 0, "session expired");
    t_lost = h.s->t_us;
    CHECK(h.s->dev.state == ST_BALANCING, "balancing continues right after the loss");
    h_run(&h, 0.45);
    CHECK(h.s->dev.state == ST_BALANCING, "within link_loss_max_s");
    h_run(&h, 0.1);
    CHECK(h.s->dev.state == ST_STOPPING || h.s->dev.state == ST_DISARMED, "normal stop after link_loss_max_s (%s at %.3f s)", h_state(&h), (double)(h.s->t_us - t_lost) * 1e-6);
    h_run(&h, 3.0);
    CHECK(h.s->dev.state == ST_DISARMED, "DISARMED");
    i = h_wait_status(&h, idc, "completed", 0.01);
    CHECK(i >= 0 && h_str(&h, i, "result.ended", s, sizeof s) && strstr(s, "link lost"), "experiment ended by the link loss");
    /* reconnecting does not resume or re-arm anything */
    connect_usb(&h);
    h_run(&h, 0.5);
    CHECK(h.s->dev.state == ST_DISARMED, "a new connection does not arm (%s)", h_state(&h));
    h_free(&h);
}

static void t_estop_and_clear(void) {
    H h;
    sim_params_t p;
    char idc[48], reason[200];
    int i;
    params_for(&p, "edge");
    h_init(&h, &p, 20);
    CHECK(to_ready(&h, "edge"), "READY");
    press(&h, 0.05);
    snprintf(idc, sizeof idc, "%s", start_exp(&h, FX_HASH_EDGE, 10));
    run_hb(&h, 0.5, 0);
    CHECK(h.s->dev.state == ST_BALANCING, "balancing");
    simdev_set_estop(h.s, true);
    h_run(&h, 0.01);
    CHECK(h.s->dev.state == ST_FAULT && (h.s->dev.latched & F_ESTOP), "local stop: FAULT latched");
    CHECK(!h.s->motor_power, "driver power removed");
    i = h_wait_status(&h, idc, "failed", 0.01);
    CHECK(i >= 0, "experiment reported failed");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "clear_faults", NULL, NULL, 5000));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, reason, sizeof reason);
    CHECK(i >= 0 && strcmp(reason, "rejected") == 0, "faults cannot be cleared while the stop is asserted");
    press(&h, 2.5);
    CHECK(h.s->dev.state == ST_FAULT, "a long press does not clear while the cause is present");
    simdev_set_estop(h.s, false);
    h_run(&h, 0.05);
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "clear_faults", NULL, NULL, 8000));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0, "clear waits for the long press");
    press(&h, 0.5);
    CHECK(h.s->dev.state == ST_FAULT, "a short press is not enough");
    press(&h, 2.2);
    CHECK(h.s->dev.state == ST_DISARMED, "cleared by the long press (%s)", h_state(&h));
    CHECK(h_wait_status(&h, idc, "completed", 0.1) >= 0, "clear_faults completed");
    CHECK(h.s->dev.latched == 0, "nothing latched");
    h_free(&h);
}

static void t_estop_while_disarmed(void) {
    H h;
    sim_params_t p;
    char idc[48];
    params_for(&p, "edge");
    h_init(&h, &p, 35);
    connect_usb(&h);
    CHECK(apply_cfg(&h, FX_CONFIG_EDGE, FX_HASH_EDGE), "config");
    simdev_set_estop(h.s, true);
    h_run(&h, 0.1);
    CHECK(h.s->dev.state == ST_DISARMED && !(h.s->dev.latched & F_ESTOP) && (h.s->dev.faults & F_ESTOP), "DISARMED with the stop reported, nothing latched");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "self_test", NULL, NULL, 1000));
    CHECK(h_wait_status(&h, idc, "rejected", 0.1) >= 0, "self-test refused while the stop is asserted");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "calibrate_imu", "{\"seconds\":2}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "completed", 3.0) >= 0, "sensing calibration still possible (drivers stay unpowered)");
    simdev_set_estop(h.s, false);
    h_run(&h, 0.1);
    CHECK(!(h.s->dev.faults & F_ESTOP), "stop released");
    h_free(&h);
}

static void t_tilt_abort(void) {
    H h;
    sim_params_t p;
    double push[3] = {1.5, 0, 0};
    params_for(&p, "edge");
    h_init(&h, &p, 21);
    CHECK(to_ready(&h, "edge"), "READY");
    press(&h, 0.05);
    start_exp(&h, FX_HASH_EDGE, 10);
    run_hb(&h, 0.5, 0);
    CHECK(h.s->dev.state == ST_BALANCING, "balancing");
    simdev_push(h.s, push, 0.3);           /* a disturbance beyond what the wheel can recover: the cube falls */
    run_hb(&h, 2.0, 0);
    CHECK(h.s->dev.state == ST_FAULT, "fault after the fall (%s)", h_state(&h));
    CHECK((h.s->dev.latched & (F_TILT_LIMIT | F_OVERSPEED)) != 0, "tilt or wheel-speed limit latched (0x%x)", h.s->dev.latched);
    CHECK(!h.s->motor_power, "driver power removed");
    h_free(&h);
}

static void t_overspeed(void) {
    H h;
    sim_params_t p;
    params_for(&p, "edge");
    h_init(&h, &p, 22);
    CHECK(to_ready(&h, "edge"), "READY");
    press(&h, 0.05);
    start_exp(&h, FX_HASH_EDGE, 10);
    run_hb(&h, 0.3, 0);
    simdev_spin_wheel(h.s, 1, 600.0);      /* a wheel suddenly above wheel_speed_abort_rpm (5250 rpm ≈ 550 rad/s) */
    run_hb(&h, 0.1, 0);
    CHECK(h.s->dev.state == ST_FAULT && (h.s->dev.latched & F_OVERSPEED), "overspeed fault (%s, 0x%x)", h_state(&h), h.s->dev.latched);
    h_free(&h);
}

/* ------------------------------------------------------------------------------------------------ allocation and saturation */
static void t_allocation_limits(void) {
    jsmntok_t *t = malloc(sizeof(jsmntok_t) * 512);
    aj_doc_t d;
    aeris_cfg_t c;
    alloc_out_t a;
    char err[200] = "";
    float req[3], om[3];
    simdev_t *s = calloc(1, sizeof *s);
    sim_params_t p;
    params_for(&p, "edge");
    simdev_init(s, &p, NULL, "x", "host");
    CHECK(aj_parse(&d, FX_CONFIG_EDGE, strlen(FX_CONFIG_EDGE), t, 512) > 0 && cfg_parse(&c, &d, 0, &s->board, err, sizeof err), "edge fixture: %s", err);
    /* within the limits: unchanged, nothing saturated */
    req[0] = 0.05f; req[1] = -0.05f; req[2] = 0.0f; om[0] = 100.0f; om[1] = -100.0f; om[2] = 0.0f;
    alloc_clip(&c, req, om, &a);
    CHECK(a.T[0] == req[0] && a.T[1] == req[1] && a.T[2] == 0.0f && !a.any, "requests within the limits pass unchanged");
    /* the torque limit (= kt · current limit) clips each wheel separately, with the sign kept */
    req[0] = 10.0f; req[1] = -10.0f; req[2] = 0.1f;
    alloc_clip(&c, req, om, &a);
    CHECK(a.T[0] == c.w[0].torque_max && a.T[1] == -c.w[1].torque_max && a.T[2] == 0.1f, "torque clipped to ±torque_max (%.4f, %.4f)", a.T[0], a.T[1]);
    CHECK(a.saturated[0] && a.saturated[1] && !a.saturated[2] && a.any, "the clipped wheels are reported saturated, the other not");
    /* at the speed limit no torque may accelerate the wheel further; braking is always allowed */
    om[0] = c.w[0].speed_max_rads * 1.01f; om[1] = -c.w[1].speed_max_rads * 1.01f; om[2] = c.w[2].speed_max_rads * 1.01f;
    req[0] = 0.05f; req[1] = -0.05f; req[2] = -0.05f;
    alloc_clip(&c, req, om, &a);
    CHECK(a.T[0] == 0.0f && a.T[1] == 0.0f && a.saturated[0] && a.saturated[1], "no accelerating torque beyond the speed limit, reported saturated");
    CHECK(a.T[2] == -0.05f && !a.saturated[2], "a braking torque at the speed limit passes");
    /* a non-finite request is never sent: zero torque, saturated */
    req[0] = NAN; req[1] = INFINITY; req[2] = 0.01f; om[0] = om[1] = om[2] = 0.0f;
    alloc_clip(&c, req, om, &a);
    CHECK(a.T[0] == 0.0f && a.T[1] == 0.0f && a.saturated[0] && a.saturated[1] && a.T[2] == 0.01f, "non-finite requests become zero torque, reported saturated");
    free(t);
    free(s);
}

/* the experiment's result reports, per wheel, how many balancing control steps were limited by the allocation */
static bool sat_run(double push_Nm, double *steps, double sat[3]) {
    H h;
    sim_params_t p;
    char idc[48];
    int i;
    bool ok;
    double push[3] = {0, 0, 0};
    push[0] = push_Nm;
    params_for(&p, "edge");
    h_init(&h, &p, 51);
    ok = to_ready(&h, "edge");
    press(&h, 0.05);
    snprintf(idc, sizeof idc, "%s", start_exp(&h, FX_HASH_EDGE, 3));
    run_hb(&h, 1.0, 0);
    if (push_Nm > 0) simdev_push(h.s, push, 0.1);
    run_hb(&h, 4.0, 0);
    i = h_wait_status(&h, idc, "completed", 3.0);
    ok = ok && i >= 0 && h_num(&h, i, "result.balancing_steps", steps) && h_arr_len(&h, i, "result.saturated_steps") == 3 &&
         h_num(&h, i, "result.saturated_steps.0", &sat[0]) && h_num(&h, i, "result.saturated_steps.1", &sat[1]) && h_num(&h, i, "result.saturated_steps.2", &sat[2]);
    if (!ok) printf("#   experiment with push %.2f N·m: %s\n", push_Nm, h_state(&h));
    h_free(&h);
    return ok;
}

static void t_saturation_reported(void) {
    double n0 = 0, n1 = 0, a[3] = {0, 0, 0}, b[3] = {0, 0, 0};
    CHECK(sat_run(0.0, &n0, a), "an undisturbed 3 s experiment completes with a saturation report");
    CHECK(sat_run(0.16, &n1, b), "the same experiment with a 0.16 N·m push for 0.1 s completes (recovered) with a saturation report");
    printf("#   saturation reports: undisturbed %g steps, saturated %g / %g / %g; pushed %g steps, saturated %g / %g / %g\n", n0, a[0], a[1], a[2], n1, b[0], b[1], b[2]);
    CHECK(n0 > 1400 && n0 < 1600 && n1 > 1400 && n1 < 1600, "balancing steps reported (3 s at 500 Hz): %g, %g", n0, n1);
    CHECK(b[0] > a[0] && b[0] < n1, "the push adds steps in which the drive wheel was at its torque limit (%g → %g of %g)", a[0], b[0], n1);
    CHECK(a[1] == 0 && a[2] == 0 && b[1] == 0 && b[2] == 0, "the edge's other wheels are never limited");
}

/* ------------------------------------------------------------------------------------------------ protection: injected faults
 * The remaining protection paths, each injected into the MODELS while the edge experiment balances: the core must stop
 * the motors at once (driver power off, every driver out of closed loop), latch FAULT with that fault's bit, fail the
 * experiment command and name the fault. Not reachable through the models and therefore not exercised: a non-finite
 * IMU value (the register model produces integers; read_imu refuses non-finite values before they are used). */
typedef void (*inject_fn)(H *h);
static void inj_overtemp(H *h) { h->s->od[0].temp_inject_C = 70.0; }   /* motor 25 + 2·|iq| + 70 °C > temperature_abort_C 80 */
static void inj_overcurrent(H *h) { h->s->od[1].iq_inject_A = 12.0; }  /* measured current beyond current_abort_A 9 A */
static void inj_undervolt(H *h) { h->s->p.vbus_V = 9.0; }             /* below vbus_min_V 9.9 V */
static void inj_overvolt(H *h) { h->s->p.vbus_V = 13.5; }             /* above vbus_max_V 12.6 V */
static void inj_drv_lost(H *h) { h->s->p.w[2].present = false; }      /* a driver stops answering (heartbeat and encoder) */
static void inj_drv_error(H *h) { h->s->od[0].axis_error = 0x1u; }     /* a driver reports an error in its heartbeat */
static void inj_enc_stale(H *h) { h->s->p.enc_period_us = 0; }         /* encoder estimates stop; heartbeats continue */
static void inj_imu_lost(H *h) { h->s->p.imu_present = false; }       /* the IMU stops answering on I2C */

static void fault_case(const char *name, inject_fn inj, uint32_t want, double within_s, uint64_t seed) {
    H h;
    sim_params_t p;
    char idc[48];
    int i, k, idle = 0;
    params_for(&p, "edge");
    h_init(&h, &p, seed);
    CHECK(to_ready(&h, "edge"), "%s: READY", name);
    press(&h, 0.05);
    snprintf(idc, sizeof idc, "%s", start_exp(&h, FX_HASH_EDGE, 10));
    run_hb(&h, 0.4, 0);
    CHECK(h.s->dev.state == ST_BALANCING && h.s->dev.latched == 0, "%s: balancing before the injection (%s, latched 0x%x)", name, h_state(&h), h.s->dev.latched);
    inj(&h);
    for (k = 0; k < (int)(within_s / 0.002) && h.s->dev.state == ST_BALANCING; k++) h_run(&h, 0.002);
    CHECK(h.s->dev.state == ST_FAULT && (h.s->dev.latched & want), "%s: FAULT latched with the expected bit within %.2f s (state %s, latched 0x%x, want 0x%x, after %.3f s)",
          name, within_s, h_state(&h), h.s->dev.latched, want, k * 0.002);
    CHECK(strstr(h.s->dev.state_reason, "protection stopped the motors") != NULL, "%s: the reason names the protection (%s)", name, h.s->dev.state_reason);
    CHECK(!h.s->motor_power, "%s: driver power removed", name);
    for (i = 0; i < 3; i++) if (h.s->od[i].axis_state != ODRV_AXIS_CLOSED_LOOP) idle++;
    CHECK(idle == 3, "%s: no driver left in closed loop (%d of 3 idle)", name, idle);
    CHECK(h_wait_status(&h, idc, "failed", 0.1) >= 0 && h_wait_status(&h, idc, "completed", 0.0) < 0, "%s: the experiment command reports failed, never completed", name);
    h_free(&h);
}

static void t_injected_faults(void) {
    fault_case("over-temperature", inj_overtemp, F_OVERTEMP, 0.5, 41);
    fault_case("over-current", inj_overcurrent, F_OVERCURRENT, 0.5, 42);
    fault_case("under-voltage", inj_undervolt, F_UNDERVOLT, 0.5, 43);
    fault_case("over-voltage", inj_overvolt, F_OVERVOLT, 0.5, 44);
    fault_case("driver lost", inj_drv_lost, F_ENC_STALE | F_DRV_STALE, 0.5, 45);
    fault_case("driver error", inj_drv_error, F_DRV_ERROR, 0.5, 46);
    fault_case("encoder estimates stale", inj_enc_stale, F_ENC_STALE, 0.2, 47);
    fault_case("IMU lost", inj_imu_lost, F_IMU_STALE | F_EST_INVALID, 0.1, 48);
}

/* control steps that start late (the step's period exceeded by more than half a period, OVERRUN_LIMIT times in a row)
 * stop a balancing experiment: LOOP_OVERRUN latched */
static void t_loop_overrun_fault(void) {
    H h;
    sim_params_t p;
    int k;
    uint32_t period;
    params_for(&p, "edge");
    h_init(&h, &p, 49);
    CHECK(to_ready(&h, "edge"), "READY");
    press(&h, 0.05);
    start_exp(&h, FX_HASH_EDGE, 10);
    run_hb(&h, 0.4, 0);
    CHECK(h.s->dev.state == ST_BALANCING && h.s->dev.overruns == 0, "balancing on time (%s, %u overruns)", h_state(&h), (unsigned)h.s->dev.overruns);
    period = aeris_control_period_us(&h.s->dev);
    for (k = 0; k < 30 && h.s->dev.state == ST_BALANCING; k++) {
        h.s->next_ctrl_us = h.s->t_us + 3u * period;          /* the next step starts three periods after this one */
        h_run(&h, 3.25 * period * 1e-6);
    }
    CHECK(h.s->dev.state == ST_FAULT && (h.s->dev.latched & F_LOOP_OVERRUN), "LOOP_OVERRUN latched after %d late steps (%s, 0x%x)", k, h_state(&h), h.s->dev.latched);
    CHECK(k >= 10, "not before %d consecutive late steps (stopped after %d)", 10, k);
    CHECK(!h.s->motor_power, "driver power removed");
    h_free(&h);
}

/* a check that fails while READY returns the device to DISARMED; a self-test fails while the cause persists; nothing a
 * host sends re-arms it, and the self-test succeeds again only once the cause is gone */
static void t_ready_check_and_retest(void) {
    H h;
    sim_params_t p;
    char idc[48];
    int k;
    params_for(&p, "edge");
    h_init(&h, &p, 50);
    CHECK(to_ready(&h, "edge"), "READY");
    h.s->p.vbus_V = 9.0;
    for (k = 0; k < 1500 && h.s->dev.state == ST_READY; k++) h_run(&h, 0.002);
    CHECK(h.s->dev.state == ST_DISARMED && strstr(h.s->dev.state_reason, "no longer ready") != NULL, "READY → DISARMED when the bus voltage drops (%s: %s)", h_state(&h), h.s->dev.state_reason);
    CHECK(h.s->dev.latched == 0, "nothing latched outside a driving state");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, AERIS_LINK_USB, "start_experiment", "{\"duration_s\":3}", FX_HASH_EDGE, 2000));
    CHECK(h_wait_status(&h, idc, "rejected", 0.1) >= 0, "an experiment request is refused while DISARMED");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, AERIS_LINK_USB, "self_test", NULL, NULL, 2000));
    CHECK(h_wait_status(&h, idc, "failed", 5.0) >= 0 && h.s->dev.state != ST_READY, "the self-test fails while the bus voltage is low (%s)", h_state(&h));
    h.s->p.vbus_V = 11.25;
    h_run(&h, 0.1);
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, AERIS_LINK_USB, "self_test", NULL, NULL, 2000));
    CHECK(h_wait_status(&h, idc, "completed", 5.0) >= 0 && h.s->dev.state == ST_READY, "the self-test passes once the voltage is back (%s)", h_state(&h));
    h_free(&h);
}

/* ------------------------------------------------------------------------------------------------ pairing and the network link */
static void t_pairing(void) {
    H h;
    sim_params_t p;
    char pk[120], sig[120], nonce[] = "nonce-0123456789abcdef", session[] = "pair-session-001", msg[600], board[64], fw[32], devid[64];
    uint8_t pub[65], sg[64];
    int i, i0;
    bool b;
    params_for(&p, "edge");
    h_init(&h, &p, 23);
    h_hello(&h, 0);
    h_run(&h, 0.01);
    i = h_find(&h, 0, "dev_hello", 0);
    CHECK(i >= 0 && h_is_null(&h, i, "pubkey"), "no key before pairing");
    h_hello(&h, 1);
    h_send(&h, 1, "{\"kind\":\"pair_begin\",\"session\":\"pair-session-001\",\"nonce\":\"nonce-0123456789abcdef\"}");
    h_run(&h, 0.01);
    CHECK(h_find(&h, 1, "pair_rejected", 0) >= 0, "pairing refused over the network link");
    h_send(&h, 0, "{\"kind\":\"pair_begin\",\"session\":\"pair-session-001\",\"nonce\":\"nonce-0123456789abcdef\"}");
    h_run(&h, 0.01);
    CHECK(h_find(&h, 0, "pair_ready", 0) >= 0, "pair_ready over USB");
    i0 = h.n;
    h_run(&h, 1.0);
    CHECK(h_find(&h, 0, "pair_proof", i0) < 0, "no proof without the local confirmation");
    press(&h, 0.05);
    i = h_wait(&h, 0, "pair_proof", i0, 0.1);
    CHECK(i >= 0, "pair_proof after the press");
    CHECK(i >= 0 && h_bool(&h, i, "local_confirmed", &b) && b, "local_confirmed");
    if (i >= 0) {
        h_str(&h, i, "pubkey", pk, sizeof pk);
        h_str(&h, i, "sig", sig, sizeof sig);
        h_str(&h, i, "board_id", board, sizeof board);
        h_str(&h, i, "firmware", fw, sizeof fw);
        h_str(&h, i, "device_id", devid, sizeof devid);
        CHECK(au_b64url_decode(pub, 65, pk, strlen(pk)) == 65 && au_b64url_decode(sg, 64, sig, strlen(sig)) == 64, "key and signature encodings");
        snprintf(msg, sizeof msg, "AERIS-PAIR-V1\n%s\n%s\n%s\n%s\n%s\n%s\nlocal-confirmed", session, nonce, devid, pk, board, fw);
        CHECK(host_verify(pub, (const uint8_t *)msg, strlen(msg), sg) == 1, "the pairing proof verifies with OpenSSL");
        msg[20] ^= 1;
        CHECK(host_verify(pub, (const uint8_t *)msg, strlen(msg), sg) == 0, "a changed message does not verify");
    }
    /* the network link: authentication with the same key, then a session; USB supervision makes it an observer */
    h_send(&h, 1, "{\"kind\":\"session\",\"link_session\":\"net-session-01\",\"lease_epoch\":1}");
    h_run(&h, 0.01);
    i = h_last(&h, 1, "link_error");
    CHECK(i >= 0, "no network session before authentication");
    i0 = h.n;
    h_send(&h, 1, "{\"kind\":\"auth_challenge\",\"gateway_id\":\"gw.example\",\"gw_session\":\"gws-000001\",\"nonce\":\"auth-nonce-0123456789\"}");
    h_run(&h, 0.01);
    i = h_find(&h, 1, "auth", i0);
    CHECK(i >= 0 && h_str(&h, i, "sig", sig, sizeof sig), "auth answer");
    if (i >= 0) {
        char boot[40];
        h_str(&h, i, "boot_id", boot, sizeof boot);
        snprintf(msg, sizeof msg, "AERIS-AUTH-V1\ngw.example\ngws-000001\nauth-nonce-0123456789\n%s\n%s", devid, boot);
        au_b64url_decode(sg, 64, sig, strlen(sig));
        CHECK(host_verify(pub, (const uint8_t *)msg, strlen(msg), sg) == 1, "the authentication signature verifies");
    }
    h_session(&h, 0, "usb-session-0001", 1);
    h_session(&h, 1, "net-session-01", 3);
    h_run(&h, 0.01);
    i = h_last(&h, 1, "session_ok");
    {
        char role[24];
        CHECK(i >= 0 && h_str(&h, i, "role", role, sizeof role) && strcmp(role, "observer") == 0, "network session is an observer while USB supervises");
    }
    {
        char idc[48], st[24];
        snprintf(idc, sizeof idc, "%s", h_cmd(&h, 1, "identify", NULL, NULL, 1000));
        i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
        CHECK(i >= 0 && strcmp(st, "rejected") == 0, "observer cannot command");
        snprintf(idc, sizeof idc, "%s", h_cmd(&h, 1, "stop", NULL, NULL, 1000));
        CHECK(h_wait_status(&h, idc, "completed", 0.1) >= 0, "observer may stop");
        simdev_link_down(h.s, 0);
        h_run(&h, 0.01);
        snprintf(idc, sizeof idc, "%s", h_cmd(&h, 1, "identify", NULL, NULL, 1000));
        CHECK(h_wait_status(&h, idc, "completed", 0.1) >= 0, "network session supervises once the USB link is gone");
        snprintf(idc, sizeof idc, "%s", h_cmd(&h, 1, "enter_update", NULL, NULL, 1000));
        i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
        CHECK(i >= 0 && strcmp(st, "rejected") == 0, "firmware update only over USB");
    }
    h_free(&h);
}

static void t_pairing_timeout_and_unpair(void) {
    H h;
    sim_params_t p;
    char idc[48];
    int i;
    params_for(&p, "edge");
    h_init(&h, &p, 24);
    connect_usb(&h);
    h_send(&h, 0, "{\"kind\":\"pair_begin\",\"session\":\"pair-session-002\",\"nonce\":\"nonce-0123456789abcdef\"}");
    h_run(&h, 61.0);
    i = h_find(&h, 0, "pair_rejected", 0);
    CHECK(i >= 0, "pairing expires without the local confirmation");
    h_send(&h, 0, "{\"kind\":\"pair_begin\",\"session\":\"pair-session-003\",\"nonce\":\"nonce-0123456789abcdef\"}");
    h_run(&h, 0.01);
    press(&h, 0.05);
    CHECK(h_find(&h, 0, "pair_proof", 0) >= 0 && h.s->dev.paired, "paired");
    h.seq[0] = h.s->dev.link[0].last_seq;
    run_hb(&h, 0.2, 0);
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "unpair", NULL, NULL, 5000));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0, "unpair waits for the press");
    press(&h, 0.05);
    CHECK(h_wait_status(&h, idc, "completed", 0.1) >= 0 && !h.s->dev.have_key && !h.s->dev.paired, "key forgotten");
    h_free(&h);
}

/* ------------------------------------------------------------------------------------------------ telemetry backfill */
static void t_telemetry_resume(void) {
    H h;
    sim_params_t p;
    char sess[64], b[200];
    int i, k, i0;
    double v, last = 0, first_missing;
    int have[3000] = {0};
    params_for(&p, "edge");
    h_init(&h, &p, 25);
    connect_usb(&h);
    CHECK(apply_cfg(&h, FX_CONFIG_EDGE, FX_HASH_EDGE), "config");
    h_run(&h, 1.0);
    i = h_last(&h, 0, "frame");
    h_num(&h, i, "seq", &last);
    i = h_last(&h, 0, "hello");
    h_str(&h, i, "session", sess, sizeof sess);
    /* the host misses 2 s of output (a stalled transport) */
    h.drop_output[0] = true;
    h_run(&h, 2.0);
    h.drop_output[0] = false;
    h_run(&h, 0.2);
    first_missing = last + 1;
    i0 = h.n;
    snprintf(b, sizeof b, "{\"kind\":\"tlm_resume\",\"session\":\"%s\",\"after\":%d}", sess, (int)last);
    h_send(&h, 0, b);
    h_run(&h, 1.0);
    CHECK(h_find(&h, 0, "tlm_resumed", i0) >= 0, "backfill complete");
    for (k = 0; k < h.n; k++) if (h.msgs[k].link == 0 && strstr(h.msgs[k].json, "\"type\":\"frame\"") && h_num(&h, k, "seq", &v) && v < 3000) have[(int)v] = 1;
    {
        int missing = 0, top = 0;
        for (k = 1; k < 3000; k++) if (have[k]) top = k;
        for (k = 1; k <= top; k++) if (!have[k]) missing++;
        CHECK(missing == 0, "%d frames still missing after the backfill (from %d)", missing, (int)first_missing);
    }
    /* longer than the ring: the device reports what it no longer has */
    h.drop_output[0] = true;
    h_run(&h, 15.0);
    h.drop_output[0] = false;
    h_run(&h, 0.1);
    i0 = h.n;
    snprintf(b, sizeof b, "{\"kind\":\"tlm_resume\",\"session\":\"%s\",\"after\":%d}", sess, 1);
    h_send(&h, 0, b);
    h_run(&h, 3.0);
    i = h_find(&h, 0, "tlm_gap", i0);
    CHECK(i >= 0, "a gap is reported for frames no longer kept (never filled in)");
    snprintf(b, sizeof b, "{\"kind\":\"tlm_resume\",\"session\":\"old-session\",\"after\":1}");
    i0 = h.n;
    h_send(&h, 0, b);
    h_run(&h, 0.01);
    i = h_find(&h, 0, "tlm_gap", i0);
    {
        char r[64];
        CHECK(i >= 0 && h_str(&h, i, "reason", r, sizeof r) && strcmp(r, "session-ended") == 0, "resume of an ended session");
    }
    h_free(&h);
}

/* ------------------------------------------------------------------------------------------------ calibration */
static void t_calibration(void) {
    H h;
    sim_params_t p;
    char idc[48];
    int i, k;
    double v, g[3];
    params_for(&p, "corner");
    h_init(&h, &p, 26);
    connect_usb(&h);
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "calibrate_imu", "{\"seconds\":5}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0 && h.s->dev.state == ST_CALIBRATING && !h.s->motor_power, "CALIBRATING, drivers unpowered");
    i = h_wait_status(&h, idc, "completed", 6.0);
    CHECK(i >= 0, "gyro bias measured");
    for (k = 0; k < 3; k++) {
        char path[48];
        snprintf(path, sizeof path, "result.gyro_mean_radps.%d", k);
        h_num(&h, i, path, &g[k]);
        CHECK(fabs(g[k] - p.gyro_bias[k]) < 3e-4, "axis %d: measured bias %.6f rad/s, synthetic bias %.6f", k, g[k], p.gyro_bias[k]);
    }
    CHECK(h.s->dev.state == ST_DISARMED, "back to DISARMED");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "calibrate_axes", "{\"seconds\":2,\"face\":\"resting\"}", NULL, 1000));
    i = h_wait_status(&h, idc, "completed", 3.0);
    CHECK(i >= 0 && h_num(&h, i, "result.accel_norm_mps2", &v) && fabs(v - 9.81) < 0.05, "gravity magnitude %.4f", v);
    {   /* the measured direction is gravity in the sensor frame for the held attitude */
        double up[3], q[4], a[3];
        memcpy(q, h.s->q, sizeof q);
        up[0] = 2 * (q[1] * q[3] - q[0] * q[2]); up[1] = 2 * (q[2] * q[3] + q[0] * q[1]); up[2] = 1 - 2 * (q[1] * q[1] + q[2] * q[2]);
        for (k = 0; k < 3; k++) { char path[48]; snprintf(path, sizeof path, "result.accel_mean_mps2.%d", k); h_num(&h, i, path, &a[k]); }
        for (k = 0; k < 3; k++) CHECK(fabs(a[k] - 9.81 * up[k]) < 0.02, "axis %d: %.4f vs %.4f", k, a[k], 9.81 * up[k]);
    }
    /* moving during a bias measurement: refused, never accepted as a calibration */
    simdev_release(h.s);
    {
        double push[3] = {0.2, -0.1, 0.0};
        snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "calibrate_imu", "{\"seconds\":2}", NULL, 1000));
        h_run(&h, 0.5);
        simdev_push(h.s, push, 0.2);
        i = h_wait_status(&h, idc, "failed", 3.0);
        CHECK(i >= 0, "a moving cube fails the bias measurement");
    }
    h_free(&h);
}

static void t_calibration_poses(void) {
    /* the operator rests the cube on three faces (either plant mode); each measurement is gravity along the named body
       axis expressed in the SENSOR frame: a host recovers to_body from two or more of them */
    static const char *faces[3] = {"+z", "+x", "-y"};
    static const double e[3][3] = {{0, 0, 1}, {1, 0, 0}, {0, -1, 0}};
    H h;
    sim_params_t p;
    char idc[48], prm[64];
    int i, k, f;
    double a[3], want[3];
    params_for(&p, "edge");
    /* a sensor mounted rotated about the body z axis (x_s = y_b, y_s = -x_b): the profile's declared mounting would be wrong */
    {
        static const double ts[9] = {0, 1, 0, -1, 0, 0, 0, 0, 1};
        memcpy(p.to_sensor, ts, sizeof ts);
    }
    h_init(&h, &p, 28);
    connect_usb(&h);
    CHECK(!simdev_face_pose(h.s, "+w") && !simdev_face_pose(h.s, "x"), "unknown faces refused");
    for (f = 0; f < 3; f++) {
        CHECK(simdev_face_pose(h.s, faces[f]), "pose %s", faces[f]);
        h_run(&h, 0.2);                 /* the cube settles on the face before the measurement starts */
        snprintf(prm, sizeof prm, "{\"seconds\":1,\"face\":\"%s\"}", faces[f]);
        snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "calibrate_axes", prm, NULL, 1000));
        i = h_wait_status(&h, idc, "completed", 2.5);
        CHECK(i >= 0, "%s: measured", faces[f]);
        for (k = 0; k < 3; k++) { char path[48]; snprintf(path, sizeof path, "result.accel_mean_mps2.%d", k); h_num(&h, i, path, &a[k]); }
        for (k = 0; k < 3; k++) want[k] = 9.81 * (p.to_sensor[3 * k] * e[f][0] + p.to_sensor[3 * k + 1] * e[f][1] + p.to_sensor[3 * k + 2] * e[f][2]);
        for (k = 0; k < 3; k++) CHECK(fabs(a[k] - want[k]) < 0.03, "%s axis %d: %.4f vs %.4f", faces[f], k, a[k], want[k]);
        {
            char lab[17] = "";
            CHECK(h_str(&h, i, "result.face", lab, sizeof lab) && !strcmp(lab, faces[f]), "%s: the face label travels with the result", faces[f]);
        }
    }
    simdev_hold(h.s, NULL);
    CHECK(!h.s->pose_active, "hold ends the pose");
    h_free(&h);
}

static void t_encoder_check(void) {
    H h;
    sim_params_t p;
    char idc[48];
    int i;
    double vmax, vmin, upd;
    params_for(&p, "edge");
    p.w[2].mount_sign = -1;             /* wheel 2's motor is mounted the other way round than its profile says */
    h_init(&h, &p, 27);
    connect_usb(&h);
    CHECK(apply_cfg(&h, FX_CONFIG_EDGE, FX_HASH_EDGE), "config");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "check_encoders", "{\"seconds\":3}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0 && h.s->motor_power, "drivers powered, idle");
    h_run(&h, 1.0);
    simdev_spin_wheel(h.s, 0, 20.0);    /* the person turns wheel 0 and wheel 2 in their marked positive direction */
    simdev_spin_wheel(h.s, 2, 20.0);
    i = h_wait_status(&h, idc, "completed", 3.0);
    CHECK(i >= 0, "encoder check completed");
    h_num(&h, i, "result.wheels.0.vel_rads_max", &vmax);
    CHECK(vmax > 15.0, "wheel 0: positive turn seen as positive (%.2f rad/s)", vmax);
    h_num(&h, i, "result.wheels.2.vel_rads_min", &vmin);
    CHECK(vmin < -15.0, "wheel 2: the sign mismatch is visible (%.2f rad/s)", vmin);
    h_num(&h, i, "result.wheels.1.encoder_updates", &upd);
    CHECK(upd > 100, "encoder estimates from every driver");
    CHECK(h.s->od[0].axis_state == ODRV_AXIS_IDLE, "drivers stay idle");
    h_free(&h);
}

/* ------------------------------------------------------------------------------------------------ builds and missing hardware */
static void t_release_build(void) {
    H h;
    sim_params_t p;
    char idc[48], reason[200];
    int i;
    bool ready = true;
    params_for(&p, "edge");
    h_init(&h, &p, 28);
    h.s->board.actuation_build = false;
    h.s->board.commissioning_build = false;
    connect_usb(&h);
    CHECK(apply_cfg(&h, FX_CONFIG_EDGE, FX_HASH_EDGE), "config");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "self_test", NULL, NULL, 1000));
    i = h_wait_status(&h, idc, "completed", 5.0);
    CHECK(i >= 0 && h_bool(&h, i, "result.ready", &ready) && !ready, "the self-test passes but the device never becomes READY");
    CHECK(h.s->dev.state == ST_DISARMED, "DISARMED");
    press(&h, 0.05);
    CHECK(h.s->dev.state == ST_DISARMED, "the ARM press does nothing");
    snprintf(idc, sizeof idc, "%s", start_exp(&h, FX_HASH_EDGE, 5));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, reason, sizeof reason);
    CHECK(i >= 0 && strcmp(reason, "rejected") == 0 && h_str(&h, i, "reason", reason, sizeof reason) && strstr(reason, "cannot drive motors"), "start refused by the build");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "commission", "{\"enter\":true}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "rejected", 0.1) >= 0, "no commissioning mode in a release build");
    h_free(&h);
}

static void t_missing_hardware(void) {
    H h;
    sim_params_t p;
    char idc[48], reason[300];
    int i;
    params_for(&p, "edge");
    p.imu_present = false;
    p.w[1].present = false;
    h_init(&h, &p, 29);
    connect_usb(&h);
    CHECK(apply_cfg(&h, FX_CONFIG_EDGE, FX_HASH_EDGE), "config");
    h_run(&h, 1.0);
    CHECK(h_find(&h, 0, "frame", 0) < 0, "no frames without an IMU (nothing fabricated)");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "self_test", NULL, NULL, 1000));
    i = h_wait_status(&h, idc, "failed", 5.0);
    CHECK(i >= 0 && h_str(&h, i, "reason", reason, sizeof reason) && strstr(reason, "imu_present") && strstr(reason, "driver_wheel_1"), "self-test names the missing parts: %s", reason);
    CHECK(h.s->dev.state == ST_DISARMED, "DISARMED");
    h_free(&h);
    params_for(&p, "edge");
    p.imu_who_am_i = 0x6B;
    h_init(&h, &p, 30);
    CHECK(!h.s->dev.imu_ok && (h.s->dev.faults & F_IMU_ABSENT), "a chip with another WHO_AM_I is never used as the IMU");
    h_free(&h);
}

/* ------------------------------------------------------------------------------------------------ commissioning, update, stop, leases */
static void t_commissioning(void) {
    H h;
    sim_params_t p;
    char idc[48], s[64];
    int i;
    double om;
    params_for(&p, "edge");
    h_init(&h, &p, 31);
    connect_usb(&h);
    CHECK(apply_cfg(&h, FX_CONFIG_EDGE, FX_HASH_EDGE), "config");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "commission", "{\"enter\":true}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "rejected", 0.1) >= 0, "needs the dead-man control held");
    simdev_set_commission(h.s, true);
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "commission", "{\"enter\":true}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "completed", 0.1) >= 0 && h.s->dev.state == ST_COMMISSIONING, "COMMISSIONING");
    h_run(&h, 0.6);       /* the drivers boot */
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "motor_test", "{\"wheel\":0,\"torque_Nm\":0.2,\"duration_ms\":300}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "rejected", 0.1) >= 0, "torque above the commissioning cap refused");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "motor_test", "{\"wheel\":0,\"torque_Nm\":0.01,\"duration_ms\":300}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0, "motor test running");
    i = h_wait_status(&h, idc, "completed", 1.0);
    CHECK(i >= 0 && h_num(&h, i, "result.omega_max_rads", &om) && om > 1.0, "the wheel turned (%.2f rad/s)", om);
    CHECK(i >= 0 && h_str(&h, i, "result.ended", s, sizeof s) && (strcmp(s, "duration reached") == 0 || strcmp(s, "speed cap reached") == 0), "ended: %s", s);
    CHECK(h.s->od[0].axis_state == ODRV_AXIS_IDLE || h.s->od[0].input_torque == 0.0f, "no torque after the test");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "motor_test", "{\"wheel\":1,\"torque_Nm\":0.01,\"duration_ms\":1500}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "executing", 0.1) >= 0, "second test");
    h_run(&h, 0.2);
    simdev_set_commission(h.s, false);
    i = h_wait_status(&h, idc, "completed", 0.2);
    CHECK(h.s->dev.state == ST_DISARMED, "releasing the dead-man control ends commissioning");
    CHECK(i >= 0 && h_str(&h, i, "result.ended", s, sizeof s) && strstr(s, "dead-man"), "test ended by the dead-man release");
    h_free(&h);
}

static void t_update_and_reboot(void) {
    H h;
    sim_params_t p;
    char idc[48], b1[40], b2[40];
    int i;
    params_for(&p, "edge");
    h_init(&h, &p, 32);
    connect_usb(&h);
    i = h_find(&h, 0, "dev_hello", 0);
    h_str(&h, i, "boot_id", b1, sizeof b1);
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "enter_update", NULL, NULL, 1000));
    CHECK(h_wait_status(&h, idc, "completed", 0.1) >= 0 && h.s->dev.state == ST_UPDATE, "UPDATE");
    h_run(&h, 0.5);
    CHECK(h.s->in_bootloader, "the (simulated) bootloader");
    h_run(&h, 2.0);
    CHECK(!h.s->in_bootloader && h.s->boots == 2, "booted again");
    i = h.n;
    h_hello(&h, 0);
    h_run(&h, 0.01);
    i = h_find(&h, 0, "dev_hello", i);
    CHECK(i >= 0 && h_str(&h, i, "boot_id", b2, sizeof b2) && strcmp(b1, b2) != 0, "a new boot id");
    CHECK(h.s->dev.state == ST_DISARMED && !h.s->dev.cfg.valid, "DISARMED, no configuration carried over a reboot");
    h_free(&h);
}

static void t_stop_idempotent_and_lease(void) {
    H h;
    sim_params_t p;
    char idc[48], st[24];
    int i;
    params_for(&p, "edge");
    h_init(&h, &p, 33);
    connect_usb(&h);
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "stop", NULL, NULL, 1000));
    CHECK(h_wait_status(&h, idc, "completed", 0.1) >= 0, "stop with nothing running");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "stop", NULL, NULL, 1000));
    CHECK(h_wait_status(&h, idc, "completed", 0.1) >= 0, "stop again");
    /* lease handover inside the session */
    h_send(&h, 0, "{\"kind\":\"heartbeat\",\"link_session\":\"usb-session-0001\",\"lease_epoch\":2}");
    h_run(&h, 0.01);
    snprintf(idc, sizeof idc, "%s", h_cmd_raw(&h, 0, "old-lease-1", "identify", NULL, NULL, 1000, ++h.seq[0], 1, h.session[0]));
    i = h_wait_cmd(&h, idc, "cmd_ack", 0.1, st, sizeof st);
    CHECK(i >= 0 && strcmp(st, "rejected") == 0, "the previous lease is refused after the handover");
    snprintf(idc, sizeof idc, "%s", h_cmd_raw(&h, 0, "new-lease-1", "identify", NULL, NULL, 1000, ++h.seq[0], 2, h.session[0]));
    CHECK(h_wait_status(&h, idc, "completed", 0.1) >= 0, "the new lease is accepted");
    i = h.n;
    h_send(&h, 0, "{\"kind\":\"heartbeat\",\"link_session\":\"usb-session-0001\",\"lease_epoch\":1}");
    h_run(&h, 0.01);
    CHECK(h_find(&h, 0, "link_error", i) >= 0, "a lease epoch cannot go back");
    h_free(&h);
}

static void t_set_network(void) {
    H h;
    sim_params_t p;
    char idc[48];
    int i;
    uint8_t buf[100];
    size_t n = 0;
    params_for(&p, "edge");
    h_init(&h, &p, 34);
    connect_usb(&h);
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "set_network", "{\"ssid\":\"lab\",\"password\":\"correct horse battery\",\"gateway_url\":\"ws://insecure\"}", NULL, 1000));
    CHECK(h_wait_status(&h, idc, "rejected", 0.1) >= 0, "a non-TLS gateway URL is refused");
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, 0, "set_network", "{\"ssid\":\"lab\",\"password\":\"correct horse battery\",\"gateway_url\":\"wss://aeris.example/api/v6/device-link\"}", NULL, 1000));
    i = h_wait_status(&h, idc, "completed", 0.1);
    CHECK(i >= 0, "stored");
    CHECK(i >= 0 && strstr(h.msgs[i].json, "correct horse") == NULL, "the password is never echoed");
    CHECK(h.s->hal.nvs_get(h.s, "net_url", buf, sizeof buf, &n) == 0 && n > 10, "kept in non-volatile storage");
    h_free(&h);
}

int main(int argc, char **argv) {
    const char *only = getenv("AERIS_TEST_ONLY");
    if (argc > 1) FXDIR = argv[1];
    g_only = only ? atoi(only) : 0;
    if (!fx_load(FXDIR)) { fprintf(stderr, "fixtures missing in %s (run firmware/tools/make_fixtures.py)\n", FXDIR); return 2; }
    printf("TAP version 13\n");
    run("util: number formatting and strict parsing", t_util_format_parse);
    run("util: CRC-32 and base64url", t_crc_b64);
    run("json: strict reader (duplicate keys, escapes, exact bytes)", t_json_strict);
    run("config: fixtures valid; mutations refused with their path", t_config_validation);
    run("parity: cf3d estimator vs backend", t_estimator_parity);
    run("parity: edge-lqr vs backend EdgeLegacy", t_controller_parity_edge);
    run("parity: corner-mimo-lqr vs backend CornerMimo", t_controller_parity_corner);
    run("link: silent until host_hello; dev_hello identity", t_boot_and_hello);
    run("link: framing errors never reach the command handler", t_framing_errors);
    run("commands: session, duplicate id, replay, lease, ttl, state guard", t_command_checks);
    run("config: hash-bound application; telemetry session", t_apply_config);
    run("states: self-test to READY", t_self_test_ready);
    run("safety: start needs the local enable; stale request never starts", t_start_needs_local_enable);
    run("synthetic: edge balance of the model plant, then normal stop", t_balance_edge);
    run("synthetic: corner balance of the model plant, then normal stop", t_balance_corner);
    run("experiment: ends at its duration", t_duration_end);
    run("safety: link-loss policy (continue up to the limit, then normal stop)", t_link_loss_policy);
    run("safety: local stop latches FAULT; clearing needs cause gone + long press", t_estop_and_clear);
    run("safety: local stop while disarmed blocks power-up, latches nothing", t_estop_while_disarmed);
    run("safety: fall → tilt/speed limit fault", t_tilt_abort);
    run("safety: wheel overspeed fault", t_overspeed);
    run("allocation: torque and speed limits, non-finite requests, saturation flags", t_allocation_limits);
    run("allocation: saturation reported with the experiment result", t_saturation_reported);
    run("safety: injected faults (temperature, current, voltage, driver, encoder, IMU) stop the motors and latch", t_injected_faults);
    run("safety: late control steps latch LOOP_OVERRUN", t_loop_overrun_fault);
    run("safety: a failed check leaves READY; re-test needs the cause gone", t_ready_check_and_retest);
    run("pairing: local proof over USB; network auth; observer role", t_pairing);
    run("pairing: timeout; unpair with local confirmation", t_pairing_timeout_and_unpair);
    run("telemetry: backfill after a stall; gaps reported, never filled", t_telemetry_resume);
    run("calibration: gyro bias and gravity direction measured; moving refused", t_calibration);
    run("calibration: rested on three faces, gravity measured per face (sensor frame)", t_calibration_poses);
    run("calibration: encoder check reveals a wheel sign mismatch", t_encoder_check);
    run("build: release image never actuates", t_release_build);
    run("hardware: missing IMU/driver reported, nothing fabricated", t_missing_hardware);
    run("commissioning: dead-man, caps, per-motor test", t_commissioning);
    run("update: bootloader entry and fresh boot", t_update_and_reboot);
    run("commands: stop idempotent; lease handover", t_stop_idempotent_and_lease);
    run("network: settings stored, TLS required, password not echoed", t_set_network);
    printf("1..%d\n# firmware core tests: %d passed, %d failed\n", g_n, g_pass, g_fail);
    return g_fail ? 1 : 0;
}

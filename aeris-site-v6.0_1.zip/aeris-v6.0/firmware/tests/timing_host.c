/* Host timing of the firmware core's control step (acceptance FW-11). NOT board timing.
 *
 * The synthetic device (firmware/sim) runs the real firmware core against the device models; this program is built with
 * -DAERIS_SIM_STEP_HOOK so the simulator calls aeris_sim_step_hook() around every aeris_control_step(), and measures
 * the wall-clock duration of each step with CLOCK_MONOTONIC on THIS computer, per device state: idle (DISARMED) and
 * balancing (BALANCING: estimator, controller, allocation, protection and telemetry). A step includes the core's HAL
 * calls, which here run the synthetic device's register-level IMU model and CAN driver models instead of the board's
 * I2C and TWAI drivers; the plant integration runs outside the step. The simulated time the device sees is unaffected.
 *
 * What it says: the work of one control step on a desktop CPU and its spread. What it does NOT say: anything about the
 * ESP32-S3 (a 240 MHz Xtensa core with a single-precision FPU, flash caches, interrupts, the I2C and TWAI drivers and
 * FreeRTOS scheduling). Real-board timing must be measured on the board (firmware diagnostics: loop.step_us_max,
 * overruns; hardware/COMMISSIONING.md).
 *
 *   make -C firmware timing      (writes a JSON summary to stdout; the Makefile also prints it) */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "harness.h"

#define MAXS 200000
static double g_buf[2][MAXS];          /* [0] DISARMED, [1] BALANCING: step durations in µs */
static int g_n[2];

static double now_us(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (double)t.tv_sec * 1e6 + (double)t.tv_nsec / 1e3; }

void aeris_sim_step_hook(int phase, int state) {
    static double t0;
    if (phase == 0) { t0 = now_us(); return; }
    {
        double d = now_us() - t0;
        int k = state == ST_BALANCING ? 1 : state == ST_DISARMED ? 0 : -1;
        if (k >= 0 && g_n[k] < MAXS) g_buf[k][g_n[k]++] = d;
    }
}

static int cmp(const void *a, const void *b) { double x = *(const double *)a, y = *(const double *)b; return x < y ? -1 : x > y; }

static void summary(const char *name, double *v, int n, int last) {
    double sum = 0;
    int i;
    qsort(v, (size_t)n, sizeof v[0], cmp);
    for (i = 0; i < n; i++) sum += v[i];
    printf("    \"%s\": {\"steps\": %d, \"mean_us\": %.3f, \"p50_us\": %.3f, \"p99_us\": %.3f, \"max_us\": %.3f}%s\n", name, n, n ? sum / n : 0.0,
           n ? v[n / 2] : 0.0, n ? v[(int)((double)(n - 1) * 0.99)] : 0.0, n ? v[n - 1] : 0.0, last ? "" : ",");
}

static void press(H *h, double s) { simdev_set_arm(h->s, true); h_run(h, s); simdev_set_arm(h->s, false); h_run(h, 0.01); }

static int run_mode(const char *dir, const char *mode, double seconds, int last) {
    H h;
    sim_params_t p;
    char idc[48], pp[96], *cfg;
    const char *hash;
    size_t n;
    int i;
    if (!fx_plant(dir, mode, &p)) { fprintf(stderr, "cannot read the plant fixture in %s\n", dir); return 2; }
    h_init(&h, &p, 17);
    g_n[0] = g_n[1] = 0;
    h_hello(&h, AERIS_LINK_USB);
    h_session(&h, AERIS_LINK_USB, "timing-session-1", 1);
    h_run(&h, 0.01);
    cfg = mode[0] == 'e' ? FX_CONFIG_EDGE : FX_CONFIG_CORNER;
    hash = mode[0] == 'e' ? FX_HASH_EDGE : FX_HASH_CORNER;
    n = strlen(cfg) + 32;
    {
        char *b = malloc(n);
        snprintf(b, n, "{\"config\":%s}", cfg);
        snprintf(idc, sizeof idc, "%s", h_cmd(&h, AERIS_LINK_USB, "apply_config", b, hash, 5000));
        free(b);
    }
    if (h_wait_status(&h, idc, "completed", 1.0) < 0) { fprintf(stderr, "%s: configuration not applied\n", mode); return 1; }
    h_run(&h, 2.0);                                        /* idle steps (DISARMED, estimator running) */
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, AERIS_LINK_USB, "self_test", NULL, NULL, 2000));
    if (h_wait_status(&h, idc, "completed", 5.0) < 0 || h.s->dev.state != ST_READY) { fprintf(stderr, "%s: not READY\n", mode); return 1; }
    press(&h, 0.05);
    snprintf(pp, sizeof pp, "{\"duration_s\":%g}", seconds + 1.0);      /* within limits.duration_max_s (10 s) */
    snprintf(idc, sizeof idc, "%s", h_cmd(&h, AERIS_LINK_USB, "start_experiment", pp, hash, 5000));
    h_wait_status(&h, idc, "executing", 0.1);
    if (h.s->dev.state != ST_BALANCING) {
        char st[24], why[200];
        int k = h_last(&h, 0, "cmd_ack") > h_last(&h, 0, "cmd_result") ? h_last(&h, 0, "cmd_ack") : h_last(&h, 0, "cmd_result");
        if (k < 0 || !h_str(&h, k, "status", st, sizeof st)) st[0] = 0;
        if (k < 0 || !h_str(&h, k, "reason", why, sizeof why)) why[0] = 0;
        fprintf(stderr, "%s: not BALANCING (%s): %s %s\n", mode, h_state(&h), st, why);
        return 1;
    }
    for (i = 0; i < (int)(seconds * 10); i++) {            /* a supervising host: heartbeats every 100 ms */
        char b[120];
        snprintf(b, sizeof b, "{\"kind\":\"heartbeat\",\"link_session\":\"%s\"}", h.session[0]);
        h_send(&h, 0, b);
        h_run(&h, 0.1);
    }
    if (h.s->dev.state != ST_BALANCING) { fprintf(stderr, "%s: balancing ended early (%s)\n", mode, h_state(&h)); return 1; }
    printf("  \"%s\": {\n    \"control_period_us\": %u,\n", mode, aeris_control_period_us(&h.s->dev));
    summary("idle_disarmed", g_buf[0], g_n[0], 0);
    summary("balancing", g_buf[1], g_n[1], 1);
    printf("  }%s\n", last ? "" : ",");
    h_free(&h);
    return 0;
}

int main(int argc, char **argv) {
    const char *dir = argc > 1 ? argv[1] : "tests/fixtures";
    int r;
    if (!fx_load(dir)) { fprintf(stderr, "cannot read the fixtures in %s\n", dir); return 2; }
    printf("{\n  \"what\": \"wall-clock duration of one aeris_control_step() of the firmware core on THIS host CPU (CLOCK_MONOTONIC): the core's work plus its HAL calls into the synthetic device's register-level IMU and CAN driver models (the plant integration is outside the step); NOT ESP32-S3 timing\",\n");
    if ((r = run_mode(dir, "edge", 8.0, 0)) != 0) return r;
    if ((r = run_mode(dir, "corner", 8.0, 1)) != 0) return r;
    printf("}\n");
    return 0;
}

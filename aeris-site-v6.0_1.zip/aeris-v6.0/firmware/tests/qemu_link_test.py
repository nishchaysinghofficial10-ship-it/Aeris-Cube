#!/usr/bin/env python3
"""Integration test of the ESP32-S3 TEST image in Espressif's QEMU (emulated ESP32-S3; not a physical board).

The 'qemutest' image (firmware/esp32s3/sdkconfig.qemutest) is the real board firmware with two test-only options: the
device link on UART0 (QEMU does not model the ESP32-S3 USB-Serial-JTAG) and a boot-time PSA ECDSA self-test. QEMU
models the CPU, memory, flash, UART, SHA and RNG peripherals; it has no LSM6DSOX and no CAN bus, so the firmware must
report the IMU and the drivers as absent and never fabricate their readings.

Checks: the image was built from the current firmware sources (aeris-sources.sha256 of the build directory); the
boot crypto self-test signature verifies (OpenSSL via `cryptography`); dev_hello identity and build id;
session; diagnostics (the control loop runs — its timing in an emulator says nothing about the board); the approved
configuration is accepted with the backend's SHA-256 (PSA SHA-256 on the target build); the self-test fails naming the
missing IMU and drivers; an experiment is refused by the release-style build; pairing creates a key on the device (PSA
key generation + NVS) whose public key then appears in dev_hello; framing errors are refused.

Usage: firmware/tests/qemu_link_test.py --qemu <qemu-system-xtensa> --build <firmware/esp32s3/build/qemutest> [--log <file>]
Exit status 0 when every check passes; prints one line per check.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))


def frame(obj) -> bytes:
    js = json.dumps(obj, separators=(",", ":")).encode()
    return js + b"\t%08x\n" % zlib.crc32(js)


class Link:
    def __init__(self, sock, log):
        self.s = sock
        self.buf = b""
        self.msgs = []
        self.raw = []
        self.log = log
        self.session = None              # a supervising host sends a heartbeat every 0.4 s (like the site and the companion)
        self.hb_at = 0.0

    def send(self, obj):
        self.s.sendall(frame(obj))
        self.log.write("> " + json.dumps(obj)[:300] + "\n")

    def send_raw(self, b: bytes):
        self.s.sendall(b)

    def pump(self, seconds):
        end = time.time() + seconds
        while time.time() < end:
            if self.session and time.time() >= self.hb_at:
                self.hb_at = time.time() + 0.4
                self.s.sendall(frame({"kind": "heartbeat", "link_session": self.session}))
            self.s.settimeout(max(0.01, min(0.2, end - time.time())))
            try:
                d = self.s.recv(65536)
            except socket.timeout:
                continue
            if not d:
                break
            self.buf += d
            while b"\n" in self.buf:
                line, self.buf = self.buf.split(b"\n", 1)
                line = line.rstrip(b"\r")
                self.log.write("< " + line.decode("utf-8", "replace")[:400] + "\n")
                if len(line) > 9 and line[-9:-8] == b"\t":
                    js, crc = line[:-9], line[-8:]
                    try:
                        if int(crc, 16) == zlib.crc32(js):
                            self.msgs.append(json.loads(js))
                            continue
                    except ValueError:
                        pass
                self.raw.append(line.decode("utf-8", "replace"))

    def wait(self, pred, seconds=10.0):
        end = time.time() + seconds
        i = 0
        while True:
            while i < len(self.msgs):
                if pred(self.msgs[i]):
                    return self.msgs[i]
                i += 1
            if time.time() >= end:
                return None
            self.pump(0.2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--qemu", required=True)
    ap.add_argument("--build", required=True)
    ap.add_argument("--fixtures", default=os.path.join(HERE, "fixtures"))
    ap.add_argument("--log", default=None)
    ap.add_argument("--esptool-python", default=sys.executable)
    a = ap.parse_args()
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

    results = []

    def check(name, ok, detail=""):
        results.append((name, bool(ok), detail))
        print(("ok   " if ok else "FAIL ") + name + (f"  ({detail})" if detail else ""), flush=True)

    # the image under test was built from the sources in this tree (build_esp32s3.sh records them; a stale build fails)
    sys.path.insert(0, os.path.join(os.path.dirname(HERE), "tools"))
    import source_hash
    rec_path = os.path.join(a.build, "aeris-sources.sha256")
    recorded = open(rec_path, encoding="ascii").read().strip() if os.path.isfile(rec_path) else None
    current = source_hash.sources_sha256("esp32s3")
    check("test image built from the current firmware sources", recorded == current,
          f"recorded {recorded[:12] if recorded else 'nothing (build with firmware/tools/build_esp32s3.sh)'}, current {current[:12]}")

    tmp = tempfile.mkdtemp(prefix="aeris-qemu-")
    flash = os.path.join(tmp, "flash.bin")
    subprocess.run([a.esptool_python, "-m", "esptool", "--chip", "esp32s3", "merge-bin", "--fill-flash-size", "4MB", "-o", flash, "@flash_args"],
                   cwd=a.build, check=True, capture_output=True)
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    qemu = subprocess.Popen([a.qemu, "-nographic", "-machine", "esp32s3", "-drive", f"file={flash},if=mtd,format=raw",
                             "-serial", f"tcp:127.0.0.1:{port},server=on,wait=on", "-monitor", "none"],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = open(a.log, "w", encoding="utf-8") if a.log else open(os.devnull, "w")
    try:
        sock = None
        for _ in range(100):
            try:
                sock = socket.create_connection(("127.0.0.1", port), timeout=1)
                break
            except OSError:
                time.sleep(0.1)
        if sock is None:
            raise SystemExit("QEMU did not open its serial port")
        L = Link(sock, log)
        L.pump(6.0)                      # boot: ROM banner (unframed) and the crypto self-test line
        st = [r for r in L.raw if r.startswith("AERIS-SELFTEST")]
        if st and "pub=" in st[0]:
            kv = dict(p.split("=", 1) for p in st[0].split()[1:])
            msg = b"AERIS-TARGET-SELFTEST\nPSA ECDSA P-256 SHA-256"
            pub = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), bytes.fromhex(kv["pub"]))
            sig = bytes.fromhex(kv["sig"])
            der = encode_dss_signature(int.from_bytes(sig[:32], "big"), int.from_bytes(sig[32:], "big"))
            try:
                pub.verify(der, msg, ec.ECDSA(hashes.SHA256()))
                good = True
            except InvalidSignature:
                good = False
            check("target PSA ECDSA P-256 signature verifies with OpenSSL", good)
            check("target PSA SHA-256 equals hashlib", kv.get("sha256") == hashlib.sha256(msg).hexdigest())
        else:
            check("boot crypto self-test line present", False, repr(st[:1]))
        check("boot text is not mistaken for protocol messages", len(L.msgs) == 0, f"{len(L.raw)} unframed lines")
        L.send({"kind": "host_hello", "versions": [1], "host": "qemu-test"})
        h = L.wait(lambda m: m.get("kind") == "dev_hello")
        check("dev_hello", h is not None)
        if h:
            check("identity: physical board, not synthetic", h["board"]["kind"] == "physical" and h["board"]["synthetic"] is False)
            check("build id names the test image", "qemutest" in h["fw"]["build"], h["fw"]["build"])
            check("actuation not compiled in", h["fw"]["actuation_build"] is False)
            check("boots DISARMED without a configuration", h["state"] == "DISARMED" and h["config_hash"] is None)
        L.send({"kind": "session", "link_session": "qemu-session-1", "lease_epoch": 1})
        L.session = "qemu-session-1"
        check("session_ok", L.wait(lambda m: m.get("kind") == "session_ok") is not None)
        seq = [0]

        def cmd(action, params=None, config_hash=None, ttl=5000, cid=None):
            seq[0] += 1
            c = {"kind": "cmd", "id": cid or f"q{seq[0]:03d}-{action}"[:40], "v": 1, "link_session": "qemu-session-1", "lease_epoch": 1,
                 "seq": seq[0], "action": action, "ttl_ms": ttl}
            if params is not None:
                c["params"] = params
            if config_hash:
                c["config_hash"] = config_hash
            L.s.sendall(json.dumps(c, separators=(",", ":")).encode() + b"\t%08x\n" % zlib.crc32(json.dumps(c, separators=(",", ":")).encode()))
            return c["id"]

        def raw_cmd(action, cfg_text, cfg_hash):
            seq[0] += 1
            cid = f"q{seq[0]:03d}-{action}"
            body = ('{"kind":"cmd","id":"%s","v":1,"link_session":"qemu-session-1","lease_epoch":1,"seq":%d,"action":"%s","ttl_ms":5000,'
                    '"params":{"config":%s},"config_hash":"%s"}') % (cid, seq[0], action, cfg_text, cfg_hash)
            b = body.encode()
            L.send_raw(b + b"\t%08x\n" % zlib.crc32(b))
            return cid

        def result(cid, statuses=("completed", "failed", "rejected", "expired"), seconds=15):
            return L.wait(lambda m: m.get("id") == cid and m.get("status") in statuses, seconds)

        r = result(cmd("diagnostics"))
        check("diagnostics completed", r is not None and r["status"] == "completed")
        if r and r.get("result"):
            lp = r["result"]["loop"]
            check("the control loop runs on the target build", lp["steps"] > 100, f"steps {lp['steps']}, period {lp['period_us']} µs, "
                  f"max step {lp['step_us_max']} µs in the EMULATOR (not board timing)")
            check("IMU reported absent (no LSM6DSOX in the emulator)", r["result"]["imu"]["present"] is False)
            check("drivers reported unseen (no CAN bus in the emulator)", all(not d["seen"] for d in r["result"]["drivers"]))
        cfg_text = open(os.path.join(a.fixtures, "config_edge.json"), encoding="utf-8").read().strip()
        cfg_hash = open(os.path.join(a.fixtures, "config_edge.sha256"), encoding="utf-8").read().strip()
        r = result(raw_cmd("apply_config", cfg_text, cfg_hash))
        check("approved configuration accepted with the backend's SHA-256", r is not None and r["status"] == "completed",
              (r or {}).get("reason", ""))
        r = result(raw_cmd("apply_config", cfg_text.replace('"tilt_abort_deg":12.0', '"tilt_abort_deg":19.0'), cfg_hash))
        check("altered configuration refused", r is not None and r["status"] == "rejected")
        r = result(cmd("self_test"), seconds=10)
        check("self-test fails and names the missing parts", r is not None and r["status"] == "failed" and "imu_present" in r.get("reason", ""),
              (r or {}).get("reason", ""))
        r = result(cmd("start_experiment", {"duration_s": 5}, cfg_hash))
        check("experiment refused by the build", r is not None and r["status"] == "rejected" and "cannot drive motors" in r.get("reason", ""))
        L.send({"kind": "pair_begin", "session": "pair-session-qemu1", "nonce": "nonce-qemu-0123456789"})
        pr = L.wait(lambda m: m.get("kind") in ("pair_ready", "pair_rejected"))
        check("pairing starts (key generated on the device)", pr is not None and pr["kind"] == "pair_ready", json.dumps(pr)[:120])
        n0 = len(L.msgs)
        L.send({"kind": "host_hello", "versions": [1], "host": "qemu-test"})
        h2 = L.wait(lambda m: m.get("kind") == "dev_hello" and L.msgs.index(m) >= n0)
        if h2 and h2.get("pubkey"):
            raw = base64.urlsafe_b64decode(h2["pubkey"] + "=" * (-len(h2["pubkey"]) % 4))
            try:
                ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), raw)
                ok = len(raw) == 65
            except ValueError:
                ok = False
            check("device public key is a valid P-256 point", ok)
        else:
            check("device public key published after key generation", False)
        n0 = len(L.msgs)
        L.send_raw(b'{"kind":"heartbeat"}\t00000000\n')
        e = L.wait(lambda m: m.get("kind") == "link_error" and L.msgs.index(m) >= n0, 5)
        check("bad CRC refused", e is not None and "CRC" in e.get("reason", ""))
        L.send({"kind": "session", "link_session": "qemu-session-1", "lease_epoch": 1})
        L.pump(0.5)
        r = result(cmd("stop"))
        check("stop accepted and completed", r is not None and r["status"] == "completed")
    finally:
        try:
            qemu.terminate()
            qemu.wait(timeout=5)
        except Exception:
            qemu.kill()
        log.close()
    passed = sum(1 for _, ok, _ in results if ok)
    print(f"# qemu target tests: {passed} passed, {len(results) - passed} failed (emulated ESP32-S3, not a physical board)")
    sys.exit(0 if passed == len(results) else 1)


if __name__ == "__main__":
    main()

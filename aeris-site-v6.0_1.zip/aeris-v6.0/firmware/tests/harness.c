#include "harness.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "aeris/util.h"

char *FX_CONFIG_EDGE, *FX_CONFIG_CORNER, *FX_HASH_EDGE, *FX_HASH_CORNER;

char *h_read_file(const char *path, size_t *n) {
    FILE *f = fopen(path, "rb");
    char *b;
    long len;
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    len = ftell(f);
    fseek(f, 0, SEEK_SET);
    b = malloc((size_t)len + 1);
    if (fread(b, 1, (size_t)len, f) != (size_t)len) { fclose(f); free(b); return NULL; }
    fclose(f);
    b[len] = 0;
    if (n) *n = (size_t)len;
    return b;
}

static void chomp(char *s) { size_t n = strlen(s); while (n && (s[n - 1] == '\n' || s[n - 1] == '\r')) s[--n] = 0; }

bool fx_load(const char *dir) {
    char p[600];
    snprintf(p, sizeof p, "%s/config_edge.json", dir); FX_CONFIG_EDGE = h_read_file(p, NULL);
    snprintf(p, sizeof p, "%s/config_corner.json", dir); FX_CONFIG_CORNER = h_read_file(p, NULL);
    snprintf(p, sizeof p, "%s/config_edge.sha256", dir); FX_HASH_EDGE = h_read_file(p, NULL);
    snprintf(p, sizeof p, "%s/config_corner.sha256", dir); FX_HASH_CORNER = h_read_file(p, NULL);
    if (!FX_CONFIG_EDGE || !FX_CONFIG_CORNER || !FX_HASH_EDGE || !FX_HASH_CORNER) return false;
    chomp(FX_CONFIG_EDGE); chomp(FX_CONFIG_CORNER); chomp(FX_HASH_EDGE); chomp(FX_HASH_CORNER);
    return true;
}

bool fx_plant(const char *dir, const char *mode, sim_params_t *p) {
    char path[600], err[200];
    size_t n;
    char *t;
    bool ok;
    snprintf(path, sizeof path, "%s/plant_%s.json", dir, mode);
    t = h_read_file(path, &n);
    if (!t) return false;
    sim_default_params(p, mode[0] == 'e' ? MODE_EDGE : MODE_CORNER);
    ok = simdev_plant_params_json(t, n, p, err, sizeof err);
    if (!ok) fprintf(stderr, "plant fixture: %s\n", err);
    free(t);
    return ok;
}

/* ------------------------------------------------------------------------------------------------ output collection */
static void store(H *h, int link, const char *line, size_t n) {
    hmsg_t *m;
    if (h->drop_output[link]) return;
    if (n < 10 || line[n - 9] != '\t') { h->unframed[link]++; return; }
    {
        char hx[9];
        uint32_t want;
        memcpy(hx, line + n - 8, 8);
        hx[8] = 0;                                   /* exactly the 8 hex digits of the frame */
        want = (uint32_t)strtoul(hx, NULL, 16);
        if (au_crc32((const uint8_t *)line, n - 9) != want) { h->bad_crc[link]++; return; }
    }
    if (h->n == h->cap) { h->cap = h->cap ? h->cap * 2 : 1024; h->msgs = realloc(h->msgs, (size_t)h->cap * sizeof *h->msgs); }
    m = &h->msgs[h->n++];
    m->link = link;
    m->n = n - 9;
    m->json = malloc(m->n + 1);
    memcpy(m->json, line, m->n);
    m->json[m->n] = 0;
    m->t_us = h->s->t_us;
    if (getenv("AERIS_TEST_DUMP") && !strstr(m->json, "\"type\":\"frame\"")) fprintf(stderr, "[%d %.3f] %s\n", link, (double)m->t_us * 1e-6, m->json);
}

static void on_out(void *ctx, int link, const uint8_t *data, size_t n) {
    H *h = (H *)ctx;
    size_t i;
    for (i = 0; i < n; i++) {
        char c = (char)data[i];
        if (c == '\n') { store(h, link, h->part[link], h->plen[link]); h->plen[link] = 0; }
        else if (h->plen[link] < sizeof h->part[link] - 1) h->part[link][h->plen[link]++] = c;
    }
}

static void on_log(void *ctx, int level, const char *msg) { (void)ctx; if (getenv("AERIS_TEST_LOG")) fprintf(stderr, "[device log %d] %s\n", level, msg); }

void h_init(H *h, const sim_params_t *p, uint64_t seed) {
    memset(h, 0, sizeof *h);
    host_crypto_init(&h->hc, NULL, seed);
    host_crypto_bind(&h->hc, &h->sc);
    h->s = calloc(1, sizeof *h->s);
    simdev_init(h->s, p, &h->sc, "synthetic-test-0001", "host");
    simdev_set_output(h->s, on_out, h);
    simdev_set_log(h->s, on_log, h);
    simdev_link_up(h->s, AERIS_LINK_USB);      /* the USB cable is plugged in; the network transport is connected too */
    simdev_link_up(h->s, AERIS_LINK_NET);
    h->tokcap = 4096;
    h->tok = malloc(sizeof(jsmntok_t) * (size_t)h->tokcap);
    h->seq[0] = h->seq[1] = 0;
}

void h_free(H *h) {
    int i;
    for (i = 0; i < h->n; i++) free(h->msgs[i].json);
    free(h->msgs);
    free(h->tok);
    host_crypto_free(&h->hc);
    free(h->s);
}

void h_send_raw(H *h, int link, const char *bytes, size_t n) { simdev_input(h->s, link, (const uint8_t *)bytes, n); }

void h_send(H *h, int link, const char *json) {
    size_t n = strlen(json);
    char *b = malloc(n + 16);
    memcpy(b, json, n);
    snprintf(b + n, 16, "\t%08x\n", au_crc32((const uint8_t *)json, n));
    simdev_input(h->s, link, (const uint8_t *)b, n + 10);
    free(b);
}

void h_run(H *h, double seconds) {
    uint64_t us = (uint64_t)(seconds * 1e6 + 0.5);
    int l;
    while (us) {
        uint64_t k = us > 1000 ? 1000 : us;
        for (l = 0; l < AERIS_LINKS; l++) if (h->auto_hb[l] && h->s->t_us >= h->hb_next_us[l]) {
            char b[160];
            snprintf(b, sizeof b, "{\"kind\":\"heartbeat\",\"link_session\":\"%s\"}", h->session[l]);
            h->hb_next_us[l] = h->s->t_us + 250000u;
            h_send(h, l, b);
        }
        simdev_advance(h->s, k);
        us -= k;
    }
}

/* ------------------------------------------------------------------------------------------------ queries */
static bool kind_is(H *h, int idx, const char *kind) {
    aj_doc_t d;
    int t;
    if (idx < 0 || idx >= h->n) return false;
    if (aj_parse(&d, h->msgs[idx].json, h->msgs[idx].n, h->tok, h->tokcap) < 0) return false;
    t = aj_get(&d, 0, "kind");                    /* link messages */
    if (t < 0) t = aj_get(&d, 0, "type");         /* telemetry messages (aeris-telemetry-ndjson/1) */
    return t >= 0 && aj_str_eq(&d, t, kind);
}

int h_find(H *h, int link, const char *kind, int from) {
    int i;
    for (i = from < 0 ? 0 : from; i < h->n; i++) if ((link < 0 || h->msgs[i].link == link) && kind_is(h, i, kind)) return i;
    return -1;
}
int h_last(H *h, int link, const char *kind) {
    int i;
    for (i = h->n - 1; i >= 0; i--) if ((link < 0 || h->msgs[i].link == link) && kind_is(h, i, kind)) return i;
    return -1;
}
int h_count(H *h, int link, const char *kind, int from) {
    int i, c = 0;
    for (i = from < 0 ? 0 : from; i < h->n; i++) if ((link < 0 || h->msgs[i].link == link) && kind_is(h, i, kind)) c++;
    return c;
}
int h_wait(H *h, int link, const char *kind, int from, double max_s) {
    double t = 0;
    int i;
    for (;;) {
        i = h_find(h, link, kind, from);
        if (i >= 0 || t >= max_s) return i;
        if (h->n > from) from = h->n;
        h_run(h, 0.001);
        t += 0.001;
    }
}

static int path_tok(H *h, int idx, const char *path, aj_doc_t *d) {
    char seg[64];
    const char *p = path;
    int t = 0;
    if (idx < 0 || idx >= h->n) return -1;
    if (aj_parse(d, h->msgs[idx].json, h->msgs[idx].n, h->tok, h->tokcap) < 0) return -1;
    while (*p) {
        size_t k = 0;
        while (*p && *p != '.' && k < sizeof seg - 1) seg[k++] = *p++;
        seg[k] = 0;
        if (*p == '.') p++;
        if (seg[0] >= '0' && seg[0] <= '9') t = aj_arr_at(d, t, atoi(seg));
        else t = aj_get(d, t, seg);
        if (t < 0) return -1;
    }
    return t;
}
bool h_str(H *h, int idx, const char *path, char *out, size_t cap) { aj_doc_t d; int t = path_tok(h, idx, path, &d); return t >= 0 && aj_str(&d, t, out, cap); }
bool h_num(H *h, int idx, const char *path, double *v) { aj_doc_t d; int t = path_tok(h, idx, path, &d); return t >= 0 && aj_num(&d, t, v); }
bool h_bool(H *h, int idx, const char *path, bool *v) { aj_doc_t d; int t = path_tok(h, idx, path, &d); return t >= 0 && aj_bool(&d, t, v); }
bool h_is_null(H *h, int idx, const char *path) { aj_doc_t d; int t = path_tok(h, idx, path, &d); return t >= 0 && aj_is_null(&d, t); }
int h_arr_len(H *h, int idx, const char *path) { aj_doc_t d; int t = path_tok(h, idx, path, &d); return t < 0 ? -1 : aj_arr_len(&d, t); }

/* ------------------------------------------------------------------------------------------------ host actions */
void h_hello(H *h, int link) { h_send(h, link, "{\"kind\":\"host_hello\",\"versions\":[1],\"host\":\"test\"}"); }

void h_session(H *h, int link, const char *sid, uint32_t epoch) {
    char b[200];
    snprintf(h->session[link], sizeof h->session[link], "%s", sid);
    h->epoch[link] = epoch;
    snprintf(b, sizeof b, "{\"kind\":\"session\",\"link_session\":\"%s\",\"lease_epoch\":%u}", sid, epoch);
    h_send(h, link, b);
    h->auto_hb[link] = true;
    h->hb_next_us[link] = h->s->t_us + 250000u;
}

const char *h_cmd_raw(H *h, int link, const char *id, const char *action, const char *params, const char *config_hash, int ttl_ms, int64_t seq, uint32_t epoch, const char *sid) {
    size_t cap = (params ? strlen(params) : 0) + 600;
    char *b = malloc(cap);
    int n = snprintf(b, cap, "{\"kind\":\"cmd\",\"id\":\"%s\",\"v\":1,\"link_session\":\"%s\",\"lease_epoch\":%u,\"seq\":%lld,\"action\":\"%s\",\"ttl_ms\":%d",
                     id, sid, epoch, (long long)seq, action, ttl_ms);
    if (params) n += snprintf(b + n, cap - (size_t)n, ",\"params\":%s", params);
    if (config_hash) n += snprintf(b + n, cap - (size_t)n, ",\"config_hash\":\"%s\"", config_hash);
    snprintf(b + n, cap - (size_t)n, "}");
    h_send(h, link, b);
    free(b);
    snprintf(h->last_id, sizeof h->last_id, "%s", id);
    return h->last_id;
}

const char *h_cmd(H *h, int link, const char *action, const char *params, const char *config_hash, int ttl_ms) {
    char id[48];
    snprintf(id, sizeof id, "c%04d-%s", ++h->cmd_n, action);
    if (strlen(id) > 40) id[40] = 0;
    return h_cmd_raw(h, link, id, action, params, config_hash, ttl_ms, ++h->seq[link], h->epoch[link], h->session[link]);
}

static bool id_is(H *h, int i, const char *id) {
    char mid[48];
    return h_str(h, i, "id", mid, sizeof mid) && strcmp(mid, id) == 0;
}

int h_wait_cmd(H *h, const char *id, const char *kind, double max_s, char *status, size_t cap) {
    double t = 0;
    int scanned = 0;
    for (;;) {
        int i;
        for (i = scanned; i < h->n; i++) {
            if (kind_is(h, i, kind) && id_is(h, i, id)) {
                if (status) h_str(h, i, "status", status, cap);
                return i;
            }
        }
        scanned = h->n;
        if (t >= max_s) return -1;
        h_run(h, 0.001);
        t += 0.001;
    }
}

int h_wait_status(H *h, const char *id, const char *status, double max_s) {
    double t = 0;
    int scanned = 0;
    for (;;) {
        int i;
        for (i = scanned; i < h->n; i++) {
            char st[24];
            if ((kind_is(h, i, "cmd_ack") || kind_is(h, i, "cmd_result")) && id_is(h, i, id) &&
                h_str(h, i, "status", st, sizeof st) && strcmp(st, status) == 0) return i;
        }
        scanned = h->n;
        if (t >= max_s) return -1;
        h_run(h, 0.001);
        t += 0.001;
    }
}

const char *h_state(H *h) { return aeris_state_name(h->s->dev.state); }

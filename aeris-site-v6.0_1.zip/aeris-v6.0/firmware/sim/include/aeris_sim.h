/* AERIS synthetic device — the firmware core running against MODELS of the cube, its sensor and its motor drivers.
 *
 * Everything this produces is SYNTHETIC. The plant is the backend engine's rigid-body model (corner: 3-D rotation about
 * the pivot with three reaction wheels; edge: rotation about the support edge), integrated with RK4; the IMU is a
 * register-level model of an LSM6DSOX on I2C (WHO_AM_I, CTRL registers, software reset, output data rate, data-ready
 * flags, full-scale quantisation and saturation, bias and noise); each wheel driver is a model of an ODrive speaking
 * CANSimple (heartbeat, encoder estimates, RTR replies, axis states, torque mode, limits, watchdog, power-up delay).
 * The firmware core is the SAME code as on the board: it only sees the HAL (I2C, CAN, inputs, links), so the
 * synthetic device exercises its protocol, state machine, protection, estimator and controllers — not the hardware.
 * Its telemetry declares device.kind "emulator" and synthetic: true.
 *
 * Time is virtual: simdev_advance() moves the models and calls the core at its control period, so tests run faster
 * than real time and are reproducible (seeded noise). The board layer of a real cube is firmware/esp32s3. */
#ifndef AERIS_SIM_H
#define AERIS_SIM_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "aeris/device.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SIM_NVS_SLOTS 16
#define SIM_CANQ 256

typedef struct {
    double axis[3];          /* spin axis, body frame (unit) */
    double Jw;               /* wheel inertia about its axis [kg·m²] */
    double kt, R, Vs, Imax;  /* motor: torque constant [N·m/A] (= back-EMF constant), resistance, supply, current limit */
    double wmax;             /* speed limit [rad/s] */
    double cv, cc;           /* friction: cv·Ω + cc·tanh(Ω) [N·m] (engine model) */
    int mount_sign;          /* the motor's positive direction relative to the axis (+1/−1): the config's wheel sign must match */
    uint8_t node;            /* CANSimple node id */
    bool present;
} sim_wheel_t;

typedef struct {
    int mode;                         /* MODE_EDGE or MODE_CORNER */
    double g;
    /* corner plant (aeris-plant-model/1, from the backend's design for the same profile) */
    double Th0[9], Thhi[9], M, rc[3];
    /* edge plant */
    double Thh, mgl, beta;
    sim_wheel_t w[3];
    /* IMU */
    bool imu_present;
    uint8_t imu_addr, imu_who_am_i;   /* who_am_i ≠ 0x6C models a different chip at the address */
    double imu_pos[3];                /* [m] from the pivot, body frame */
    double to_sensor[9];              /* sensor vector = to_sensor · body vector (a signed permutation) */
    double gyro_bias[3], accel_bias[3];
    double gyro_noise, accel_noise;   /* standard deviation per sample [rad/s], [m/s²] */
    double temp_c;
    /* power */
    double vbus_V, batt_R;
    /* the operator and the fixture: the body is held at the start attitude until some time after the device enters
       BALANCING (the operator lets go); beyond catch_rad from the balance attitude it rests on the catch (held) */
    double start_q[4], start_theta, catch_rad, release_delay_s;
    uint64_t seed;
    int plant_hz;                     /* RK4 rate (multiple of 1000 recommended: 4000) */
    uint32_t enc_period_us, hb_period_us, driver_boot_us, watchdog_us;
} sim_params_t;

typedef struct {
    int (*sha256)(void *ctx, const uint8_t *d, size_t n, uint8_t out[32]);
    int (*key_public)(void *ctx, uint8_t pub[65], bool create);
    int (*sign)(void *ctx, const uint8_t *m, size_t n, uint8_t sig[64]);
    int (*key_reset)(void *ctx);
    int (*random)(void *ctx, uint8_t *b, size_t n);
    void *ctx;
} sim_crypto_t;

typedef void (*sim_out_fn)(void *ctx, int link, const uint8_t *data, size_t n);
typedef void (*sim_log_fn)(void *ctx, int level, const char *msg);

typedef struct { char key[16]; uint8_t val[224]; size_t len; bool used; } sim_nvs_t;

typedef struct {
    uint8_t reg[128];
    int reset_reads;                  /* SW_RESET reads as 1 for this many reads */
    uint64_t next_sample_us;
    uint32_t samples;
} sim_imu_t;

typedef struct {
    uint8_t axis_state, procedure_result;
    uint32_t axis_error, active_errors, disarm_reason;
    uint32_t control_mode, input_mode;
    float input_torque, vel_limit, current_limit;
    bool closed_loop_pending;
    uint64_t closed_loop_at_us, last_torque_us, next_hb_us, next_enc_us, powered_at_us;
    bool powered;
    double pos_rev, T_motor, iq, temp_motor;
    double temp_inject_C, iq_inject_A;   /* TEST FAULT INJECTION (0 unless a test sets them): added to the motor temperature
                                            and to the measured current this driver reports */
    uint32_t rx_frames, tx_frames;
} sim_odrv_t;

typedef struct { uint32_t id; uint8_t data[8]; uint8_t len; bool rtr; } sim_can_t;

typedef struct simdev {
    sim_params_t p;
    /* plant state: attitude q (body → world), body rate w, edge angle/rate, wheel speeds relative to the body */
    double q[4], w[3], th, thd, ww[3];
    double wd[3], thdd;               /* the last accelerations (specific force at the IMU) */
    double ext_T[3];                  /* external torque on the body (body frame) and until when */
    uint64_t ext_until_us;
    bool held;
    bool caught;
    bool pose_active;                 /* the operator holds the cube still in a calibration pose (any attitude, either mode) */
    double pose_q[4];
    uint64_t release_at_us;
    uint64_t t_us;
    /* models */
    sim_imu_t imu;
    sim_odrv_t od[3];
    sim_can_t q_rx[SIM_CANQ];
    int q_head, q_n;
    uint32_t can_dropped;
    /* local inputs and outputs */
    bool arm, estop, commission, motor_power;
    int led;
    /* links */
    sim_out_fn out;
    void *out_ctx;
    sim_log_fn log;
    void *log_ctx;
    bool link_up[AERIS_LINKS];
    size_t link_budget[AERIS_LINKS];  /* bytes accepted per advance call (0 = unlimited): models a slow transport */
    size_t link_used[AERIS_LINKS];
    /* persistent storage, crypto, randomness */
    sim_nvs_t nvs[SIM_NVS_SLOTS];
    sim_crypto_t crypto;
    uint64_t rng;
    /* the device */
    aeris_hal_t hal;
    aeris_board_t board;
    char device_id[48];
    uint64_t next_ctrl_us, next_service_us;
    uint32_t boots;
    bool in_bootloader;
    uint64_t bootloader_until_us;
    aeris_dev_t dev;
} simdev_t;

/* parameters of the reference synthetic cube (nominal engine values; the caller replaces the plant block with the
   backend's design for its profile) */
void sim_default_params(sim_params_t *p, int mode);
void simdev_init(simdev_t *s, const sim_params_t *p, const sim_crypto_t *crypto, const char *device_id, const char *chip);
void simdev_set_output(simdev_t *s, sim_out_fn out, void *ctx);
void simdev_set_log(simdev_t *s, sim_log_fn log, void *ctx);
void simdev_advance(simdev_t *s, uint64_t us);
void simdev_link_up(simdev_t *s, int link);
void simdev_link_down(simdev_t *s, int link);
void simdev_input(simdev_t *s, int link, const uint8_t *data, size_t n);
/* operator actions */
void simdev_set_arm(simdev_t *s, bool pressed);
void simdev_set_estop(simdev_t *s, bool asserted);
void simdev_set_commission(simdev_t *s, bool held);
void simdev_push(simdev_t *s, const double torque_body[3], double seconds);   /* a disturbance torque on the body */
void simdev_hold(simdev_t *s, const double q[4]);                              /* the operator holds the cube there */
void simdev_release(simdev_t *s);
/* the operator rests the cube still in the attitude q (body → world) to calibrate it, in either mode: the IMU then
   measures that attitude; hold() or release() ends the pose */
void simdev_pose(simdev_t *s, const double q[4]);
bool simdev_face_pose(simdev_t *s, const char *face);                            /* "+x" … "-z": that body axis up */
void simdev_spin_wheel(simdev_t *s, int wheel, double rads);                    /* a person turns a wheel by hand */
/* true state (for tests and for the comparison of the device's estimate with the model's state) */
double simdev_tilt_from_balance(const simdev_t *s);                             /* [rad] */
bool simdev_plant_params_json(const char *json, size_t n, sim_params_t *p, char *err, size_t errcap);

#ifdef __cplusplus
}
#endif
#endif

/* AERIS synthetic device: plant, LSM6DSOX register model, ODrive CANSimple models and the HAL that connects them to
 * the firmware core (see aeris_sim.h). Double precision; no libc beyond what util.h provides (builds for WebAssembly). */
#include "aeris_sim.h"
#include "aeris/json.h"
#include "aeris/util.h"

#define PI 3.141592653589793
#define TWO_PI 6.283185307179586
#define G0 9.80665
#define WATCHDOG_ERROR 0x00000800u          /* ODrive error flag WATCHDOG_TIMER_EXPIRED (model) */
#define ESTOP_ERROR 0x00000040u             /* ODrive error flag ESTOP_REQUESTED (model) */

/* ------------------------------------------------------------------------------------------------ small vector math */
static void qmul(const double a[4], const double b[4], double o[4]) {
    o[0] = a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3];
    o[1] = a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2];
    o[2] = a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1];
    o[3] = a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0];
}
static void qnorm(double q[4]) {
    double n = au_sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
    int i;
    if (!(n > 0)) { q[0] = 1; q[1] = q[2] = q[3] = 0; return; }
    for (i = 0; i < 4; i++) q[i] /= n;
}
static void up_in_body(const double q[4], double u[3]) {
    u[0] = 2 * (q[1] * q[3] - q[0] * q[2]);
    u[1] = 2 * (q[2] * q[3] + q[0] * q[1]);
    u[2] = 1 - 2 * (q[1] * q[1] + q[2] * q[2]);
}
static void cross(const double a[3], const double b[3], double o[3]) {
    double x = a[1] * b[2] - a[2] * b[1], y = a[2] * b[0] - a[0] * b[2], z = a[0] * b[1] - a[1] * b[0];
    o[0] = x; o[1] = y; o[2] = z;
}
static double dot(const double a[3], const double b[3]) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
static void mv(const double m[9], const double v[3], double o[3]) {
    double x = m[0] * v[0] + m[1] * v[1] + m[2] * v[2], y = m[3] * v[0] + m[4] * v[1] + m[5] * v[2], z = m[6] * v[0] + m[7] * v[1] + m[8] * v[2];
    o[0] = x; o[1] = y; o[2] = z;
}
static void axis_angle(const double ax[3], double ang, double q[4]) {
    double n = au_sqrt(dot(ax, ax)), s = au_sin(ang / 2);
    q[0] = au_cos(ang / 2); q[1] = s * ax[0] / n; q[2] = s * ax[1] / n; q[3] = s * ax[2] / n;
}
static void from_to(const double u[3], const double v[3], double q[4]) {
    /* shortest rotation taking unit u to unit v (physics/quaternion.py from_to) */
    double c[3], d = dot(u, v);
    cross(u, v, c);
    q[0] = 1 + d; q[1] = c[0]; q[2] = c[1]; q[3] = c[2];
    if (q[0] < 1e-12) { double a[3] = {1, 0, 0}; if (u[0] > 0.9 || u[0] < -0.9) { a[0] = 0; a[1] = 1; } cross(u, a, c); q[0] = 0; q[1] = c[0]; q[2] = c[1]; q[3] = c[2]; }
    qnorm(q);
}
static double clampd(double x, double lo, double hi) { return x < lo ? lo : x > hi ? hi : x; }
static double absd(double x) { return x < 0 ? -x : x; }

/* deterministic noise: splitmix64 → uniform; Irwin–Hall sum of 12 uniforms → approximately N(0, 1) */
static uint64_t rnd64(uint64_t *s) {
    uint64_t z = (*s += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}
static double unif(uint64_t *s) { return (double)(rnd64(s) >> 11) * (1.0 / 9007199254740992.0); }
static double gauss(uint64_t *s) { double a = 0; int i; for (i = 0; i < 12; i++) a += unif(s); return a - 6.0; }

static void slog(simdev_t *s, int level, const char *m) { if (s->log) s->log(s->log_ctx, level, m); }

/* ------------------------------------------------------------------------------------------------ parameters */
void sim_default_params(sim_params_t *p, int mode) {
    /* nominal engine cube: a = 0.18 m, m = 1.8 kg, k_J = 0.2, three wheels along the body axes, J_w = 5e-4 kg·m²,
       KV 500 rpm/V, R 0.4 Ω, V_s 11.1 V, I_max 8 A, 5000 rpm (constants.NOMINAL). The plant block below is the bare
       nominal cube; hosts normally load the backend's design for their profile (simdev_plant_params_json). */
    const double a = 0.18, m = 1.8, kJ = 0.2, Jw = 5e-4, g = 9.81;
    int i;
    au_memset(p, 0, sizeof *p);
    p->mode = mode;
    p->g = g;
    for (i = 0; i < 3; i++) {
        sim_wheel_t *w = &p->w[i];
        w->axis[i] = 1;
        w->Jw = Jw;
        w->kt = 60.0 / (TWO_PI * 500.0);
        w->R = 0.4; w->Vs = 11.1; w->Imax = 8; w->wmax = 5000 * TWO_PI / 60.0; w->cv = 1e-5; w->cc = 0.002;
        w->mount_sign = 1;
        w->node = (uint8_t)(i + 1);
        w->present = true;
    }
    {   /* corner: inertia about the pivot of the cube with point-mass-free wheels: k_J m a² I + m (|r|² I − r rᵀ), r = (a/2)(1,1,1) */
        double r = a / 2, rr = 3 * r * r, I0 = kJ * m * a * a;
        double Th0[9] = {I0 + m * (rr - r * r), -m * r * r, -m * r * r, -m * r * r, I0 + m * (rr - r * r), -m * r * r, -m * r * r, -m * r * r, I0 + m * (rr - r * r)};
        double Thh[9], det, inv[9];
        au_memcpy(p->Th0, Th0, sizeof Th0);
        au_memcpy(Thh, Th0, sizeof Thh);
        for (i = 0; i < 3; i++) Thh[4 * i] -= Jw;
        det = Thh[0] * (Thh[4] * Thh[8] - Thh[5] * Thh[7]) - Thh[1] * (Thh[3] * Thh[8] - Thh[5] * Thh[6]) + Thh[2] * (Thh[3] * Thh[7] - Thh[4] * Thh[6]);
        inv[0] = (Thh[4] * Thh[8] - Thh[5] * Thh[7]) / det; inv[1] = (Thh[2] * Thh[7] - Thh[1] * Thh[8]) / det; inv[2] = (Thh[1] * Thh[5] - Thh[2] * Thh[4]) / det;
        inv[3] = (Thh[5] * Thh[6] - Thh[3] * Thh[8]) / det; inv[4] = (Thh[0] * Thh[8] - Thh[2] * Thh[6]) / det; inv[5] = (Thh[2] * Thh[3] - Thh[0] * Thh[5]) / det;
        inv[6] = (Thh[3] * Thh[7] - Thh[4] * Thh[6]) / det; inv[7] = (Thh[1] * Thh[6] - Thh[0] * Thh[7]) / det; inv[8] = (Thh[0] * Thh[4] - Thh[1] * Thh[3]) / det;
        au_memcpy(p->Thhi, inv, sizeof inv);
        p->M = m;
        p->rc[0] = p->rc[1] = p->rc[2] = r;
    }
    {   /* edge: about the support edge (body x): k_J m a² + m (a/√2)²; COM at a/√2 from the edge */
        double l = a * 0.7071067811865476;
        p->Thh = kJ * m * a * a + m * l * l - Jw;
        p->mgl = m * g * l;
        p->beta = 0;
    }
    p->imu_present = true;
    p->imu_addr = 0x6A;
    p->imu_who_am_i = 0x6C;
    p->imu_pos[0] = p->imu_pos[1] = p->imu_pos[2] = 0.09 / 1.7320508075688772;     /* r_IMU along the body diagonal (engine default) */
    p->to_sensor[0] = p->to_sensor[4] = p->to_sensor[8] = 1;
    p->gyro_noise = 0.16 * PI / 180.0;
    p->accel_noise = 0.047;
    p->temp_c = 31.0;
    p->vbus_V = 24.0;
    p->batt_R = 0.05;
    p->catch_rad = 20.0 * PI / 180.0;
    p->release_delay_s = 0.05;
    p->start_theta = 1.0 * PI / 180.0;
    p->seed = 7;
    p->plant_hz = 4000;
    p->enc_period_us = 2000;
    p->hb_period_us = 100000;
    p->driver_boot_us = 400000;
    p->watchdog_us = 100000;
    {   /* corner start: the balance attitude tilted by 1° about a horizontal body direction */
        double z[3] = {0, 0, 1}, rcu[3], n = au_sqrt(dot(p->rc, p->rc)), qb[4], ax[3] = {1, -1, 0}, qt[4];
        rcu[0] = p->rc[0] / n; rcu[1] = p->rc[1] / n; rcu[2] = p->rc[2] / n;
        from_to(rcu, z, qb);
        axis_angle(ax, 1.0 * PI / 180.0, qt);
        qmul(qb, qt, p->start_q);
        qnorm(p->start_q);
    }
}

/* ------------------------------------------------------------------------------------------------ plant */
static void balance_q(const simdev_t *s, double qb[4]) {
    double z[3] = {0, 0, 1}, n = au_sqrt(dot(s->p.rc, s->p.rc)), rcu[3];
    rcu[0] = s->p.rc[0] / n; rcu[1] = s->p.rc[1] / n; rcu[2] = s->p.rc[2] / n;
    from_to(rcu, z, qb);
}

double simdev_tilt_from_balance(const simdev_t *s) {
    if (s->p.mode == MODE_EDGE) return absd(s->th + s->p.beta);
    {
        double up[3], n = au_sqrt(dot(s->p.rc, s->p.rc)), c;
        up_in_body(s->q, up);
        c = dot(up, s->p.rc) / n;
        c = clampd(c, -1, 1);
        return au_atan2(au_sqrt(1 - c * c), c);
    }
}

static double friction(const sim_wheel_t *w, double om) { return w->cv * om + w->cc * au_tanh(om); }

/* the engine's deliverable torque at wheel speed ww (actuators.py Wheel.avail, health 1) */
static double avail(const sim_wheel_t *w, double T, double ww) {
    double tm = w->kt * w->Imax;
    T = clampd(T, -tm, tm);
    if (T * ww > 0) {
        double lim = absd(ww) >= w->wmax ? 0.0 : w->kt * (w->Vs - w->kt * absd(ww)) / w->R;
        if (lim < 0) lim = 0;
        if (absd(T) > lim) T = T > 0 ? lim : -lim;
    }
    return T;
}

typedef struct { double q[4], w[3], th, thd, ww[3]; } pstate_t;
typedef struct { double q[4], w[3], th, thd, ww[3]; } pderiv_t;

static void deriv(const simdev_t *s, const pstate_t *x, const double T[3], const double te[3], bool held, pderiv_t *dx) {
    const sim_params_t *p = &s->p;
    double Tn[3];
    int i;
    for (i = 0; i < 3; i++) Tn[i] = p->w[i].present ? T[i] - friction(&p->w[i], x->ww[i]) : 0.0;
    au_memset(dx, 0, sizeof *dx);
    if (p->mode == MODE_EDGE) {
        double a = 0;
        if (!held) {
            double sum = 0;
            for (i = 0; i < 3; i++) sum += p->w[i].axis[0] * Tn[i];
            a = (p->mgl * au_sin(x->th + p->beta) + te[0] - sum) / p->Thh;
        }
        dx->th = held ? 0 : x->thd;
        dx->thd = a;
        for (i = 0; i < 3; i++) dx->ww[i] = p->w[i].present ? Tn[i] / p->w[i].Jw - p->w[i].axis[0] * a : 0.0;
        return;
    }
    {
        double up[3], gB[3], L[3], c1[3], c2[3], Mrc[3], rhs[3], wd[3] = {0, 0, 0}, qd[4], wq[4];
        if (!held) {
            up_in_body(x->q, up);
            gB[0] = -p->g * up[0]; gB[1] = -p->g * up[1]; gB[2] = -p->g * up[2];
            mv(p->Th0, x->w, L);
            for (i = 0; i < 3; i++) { double h = x->ww[i] * p->w[i].Jw; L[0] += h * p->w[i].axis[0]; L[1] += h * p->w[i].axis[1]; L[2] += h * p->w[i].axis[2]; }
            cross(x->w, L, c1);
            Mrc[0] = p->M * p->rc[0]; Mrc[1] = p->M * p->rc[1]; Mrc[2] = p->M * p->rc[2];
            cross(Mrc, gB, c2);
            for (i = 0; i < 3; i++) rhs[i] = -c1[i] + c2[i] + te[i];
            for (i = 0; i < 3; i++) { rhs[0] -= Tn[i] * p->w[i].axis[0]; rhs[1] -= Tn[i] * p->w[i].axis[1]; rhs[2] -= Tn[i] * p->w[i].axis[2]; }
            mv(p->Thhi, rhs, wd);
            wq[0] = 0; wq[1] = x->w[0]; wq[2] = x->w[1]; wq[3] = x->w[2];
            qmul(x->q, wq, qd);
            for (i = 0; i < 4; i++) dx->q[i] = qd[i] / 2;
        }
        au_memcpy(dx->w, wd, sizeof wd);
        for (i = 0; i < 3; i++) dx->ww[i] = p->w[i].present ? Tn[i] / p->w[i].Jw - dot(p->w[i].axis, wd) : 0.0;
    }
}

static void axpy(pstate_t *o, const pstate_t *x, const pderiv_t *d, double h) {
    int i;
    for (i = 0; i < 4; i++) o->q[i] = x->q[i] + h * d->q[i];
    for (i = 0; i < 3; i++) { o->w[i] = x->w[i] + h * d->w[i]; o->ww[i] = x->ww[i] + h * d->ww[i]; }
    o->th = x->th + h * d->th;
    o->thd = x->thd + h * d->thd;
}

static void plant_step(simdev_t *s, const double T[3], double h) {
    pstate_t x, t;
    pderiv_t k1, k2, k3, k4;
    double te[3] = {0, 0, 0};
    int i;
    if (s->ext_until_us > s->t_us) au_memcpy(te, s->ext_T, sizeof te);
    au_memcpy(x.q, s->q, sizeof x.q); au_memcpy(x.w, s->w, sizeof x.w); au_memcpy(x.ww, s->ww, sizeof x.ww);
    x.th = s->th; x.thd = s->thd;
    deriv(s, &x, T, te, s->held, &k1);
    axpy(&t, &x, &k1, h / 2); deriv(s, &t, T, te, s->held, &k2);
    axpy(&t, &x, &k2, h / 2); deriv(s, &t, T, te, s->held, &k3);
    axpy(&t, &x, &k3, h); deriv(s, &t, T, te, s->held, &k4);
    for (i = 0; i < 4; i++) s->q[i] = x.q[i] + h / 6 * (k1.q[i] + 2 * k2.q[i] + 2 * k3.q[i] + k4.q[i]);
    for (i = 0; i < 3; i++) {
        s->w[i] = x.w[i] + h / 6 * (k1.w[i] + 2 * k2.w[i] + 2 * k3.w[i] + k4.w[i]);
        s->ww[i] = x.ww[i] + h / 6 * (k1.ww[i] + 2 * k2.ww[i] + 2 * k3.ww[i] + k4.ww[i]);
    }
    s->th = x.th + h / 6 * (k1.th + 2 * k2.th + 2 * k3.th + k4.th);
    s->thd = x.thd + h / 6 * (k1.thd + 2 * k2.thd + 2 * k3.thd + k4.thd);
    qnorm(s->q);
    /* the accelerations at the end of the step (for the accelerometer) */
    au_memcpy(x.q, s->q, sizeof x.q); au_memcpy(x.w, s->w, sizeof x.w); au_memcpy(x.ww, s->ww, sizeof x.ww);
    x.th = s->th; x.thd = s->thd;
    deriv(s, &x, T, te, s->held, &k1);
    au_memcpy(s->wd, k1.w, sizeof s->wd);
    s->thdd = k1.thd;
    if (s->p.mode == MODE_EDGE) {
        double ax[3] = {1, 0, 0};
        axis_angle(ax, PI / 4 + s->th, s->q);
        s->w[0] = s->thd; s->w[1] = s->w[2] = 0;
        s->wd[0] = s->thdd; s->wd[1] = s->wd[2] = 0;
    }
    if (s->held) { s->w[0] = s->w[1] = s->w[2] = 0; s->wd[0] = s->wd[1] = s->wd[2] = 0; s->thd = 0; s->thdd = 0; }
    if (!s->held && simdev_tilt_from_balance(s) > s->p.catch_rad) {
        s->held = true;
        s->caught = true;
        slog(s, 2, "synthetic plant: the body reached the catch (fell); it now rests there");
    }
}

/* ------------------------------------------------------------------------------------------------ LSM6DSOX model */
static void imu_reset(sim_imu_t *m) {
    au_memset(m->reg, 0, sizeof m->reg);
    m->reg[0x12] = 0x04;                       /* CTRL3_C default: IF_INC */
}

static double imu_odr(const sim_imu_t *m) {
    static const double HZ[16] = {0, 12.5, 26, 52, 104, 208, 416, 833, 1666, 3332, 6664, 0, 0, 0, 0, 0};
    double a = HZ[(m->reg[0x10] >> 4) & 15], g = HZ[(m->reg[0x11] >> 4) & 15];
    return a > g ? a : g;
}

static void put16(uint8_t *b, double v) {
    long x = (long)(v < 0 ? v - 0.5 : v + 0.5);
    if (x > 32767) x = 32767;
    if (x < -32768) x = -32768;
    b[0] = (uint8_t)((unsigned long)x & 0xFFu);
    b[1] = (uint8_t)(((unsigned long)x >> 8) & 0xFFu);
}

static void imu_sample(simdev_t *s) {
    sim_imu_t *m = &s->imu;
    const sim_params_t *p = &s->p;
    static const double XL_MG[4] = {0.061, 0.488, 0.122, 0.244};          /* FS_XL 00: 2 g, 01: 16 g, 10: 4 g, 11: 8 g */
    double g_lsb, w_lsb, up[3], t1[3], t2[3], f[3], gs[3], as[3];
    int fsg = (m->reg[0x11] >> 1) & 7, i;
    double mdps = fsg == 1 ? 4.375 : fsg == 0 ? 8.75 : fsg == 2 ? 17.5 : fsg == 4 ? 35.0 : 70.0;
    g_lsb = XL_MG[(m->reg[0x10] >> 2) & 3] * 1e-3 * G0;
    w_lsb = mdps * 1e-3 * PI / 180.0;
    /* specific force at the IMU: α×r + ω×(ω×r) + g·up (pivot fixed); in a calibration pose the cube rests still */
    up_in_body(s->pose_active ? s->pose_q : s->q, up);
    cross(s->wd, p->imu_pos, t1);
    cross(s->w, p->imu_pos, t2);
    cross(s->w, t2, t2);
    for (i = 0; i < 3; i++) f[i] = t1[i] + t2[i] + p->g * up[i];
    mv(p->to_sensor, s->w, gs);
    mv(p->to_sensor, f, as);
    for (i = 0; i < 3; i++) {
        gs[i] += p->gyro_bias[i] + p->gyro_noise * gauss(&s->rng);
        as[i] += p->accel_bias[i] + p->accel_noise * gauss(&s->rng);
    }
    if ((m->reg[0x11] >> 4) & 15) for (i = 0; i < 3; i++) put16(&m->reg[0x22 + 2 * i], gs[i] / w_lsb);
    if ((m->reg[0x10] >> 4) & 15) for (i = 0; i < 3; i++) put16(&m->reg[0x28 + 2 * i], as[i] / g_lsb);
    put16(&m->reg[0x20], (p->temp_c - 25.0) * 256.0);
    m->reg[0x1E] = (uint8_t)(((m->reg[0x10] >> 4) & 15 ? 0x01 : 0) | ((m->reg[0x11] >> 4) & 15 ? 0x02 : 0) | 0x04);
    m->samples++;
}

static void imu_tick(simdev_t *s) {
    double odr = imu_odr(&s->imu);
    if (!s->p.imu_present || !(odr > 0)) return;
    if (s->t_us >= s->imu.next_sample_us) {
        imu_sample(s);
        s->imu.next_sample_us += (uint64_t)(1e6 / odr + 0.5);
        if (s->imu.next_sample_us <= s->t_us) s->imu.next_sample_us = s->t_us + (uint64_t)(1e6 / odr + 0.5);
    }
}

static int hal_i2c_read(void *ctx, uint8_t addr, uint8_t reg, uint8_t *buf, size_t n) {
    simdev_t *s = (simdev_t *)ctx;
    sim_imu_t *m = &s->imu;
    size_t k;
    if (!s->p.imu_present || addr != s->p.imu_addr) return -1;          /* no acknowledge */
    for (k = 0; k < n; k++) {
        uint8_t r = (uint8_t)((m->reg[0x12] & 0x04) ? reg + k : reg);
        uint8_t v;
        if (r == 0x0F) v = s->p.imu_who_am_i;
        else if (r == 0x12 && m->reset_reads > 0) { v = (uint8_t)(m->reg[0x12] | 0x01); m->reset_reads--; }
        else v = r < 128 ? m->reg[r] : 0;
        buf[k] = v;
        if (r >= 0x22 && r <= 0x27) m->reg[0x1E] &= (uint8_t)~0x02u;
        if (r >= 0x28 && r <= 0x2D) m->reg[0x1E] &= (uint8_t)~0x01u;
        if (r == 0x20 || r == 0x21) m->reg[0x1E] &= (uint8_t)~0x04u;
    }
    return 0;
}

static int hal_i2c_write(void *ctx, uint8_t addr, uint8_t reg, const uint8_t *buf, size_t n) {
    simdev_t *s = (simdev_t *)ctx;
    sim_imu_t *m = &s->imu;
    size_t k;
    if (!s->p.imu_present || addr != s->p.imu_addr) return -1;
    for (k = 0; k < n; k++) {
        uint8_t r = (uint8_t)((m->reg[0x12] & 0x04) ? reg + k : reg);
        if (r == 0x12 && (buf[k] & 0x01)) { imu_reset(m); m->reset_reads = 1; continue; }
        if (r == 0x10 || r == 0x11 || r == 0x12) m->reg[r] = buf[k];
    }
    m->next_sample_us = s->t_us + 1000;                                  /* the first sample after a configuration */
    return 0;
}

/* ------------------------------------------------------------------------------------------------ ODrive models */
static void canq_push(simdev_t *s, uint32_t id, const uint8_t *d, uint8_t len) {
    sim_can_t *f;
    if (s->q_n >= SIM_CANQ) { s->can_dropped++; return; }
    f = &s->q_rx[(s->q_head + s->q_n) % SIM_CANQ];
    f->id = id; f->len = len; f->rtr = false;
    au_memset(f->data, 0, 8);
    if (d) au_memcpy(f->data, d, len);
    s->q_n++;
}

static void putf(uint8_t *b, double v) { odrv_put_f32(b, (float)v); }

static void od_reply(simdev_t *s, int i, uint8_t cmd) {
    sim_odrv_t *o = &s->od[i];
    const sim_wheel_t *w = &s->p.w[i];
    uint8_t d[8] = {0};
    double vel = (double)w->mount_sign * s->ww[i] / TWO_PI;
    switch (cmd) {
    case ODRV_CMD_HEARTBEAT: odrv_put_u32(d, o->axis_error); d[4] = o->axis_state; d[5] = o->procedure_result; d[6] = 1; break;
    case ODRV_CMD_GET_ERROR: odrv_put_u32(d, o->axis_error); odrv_put_u32(d + 4, o->disarm_reason); break;
    case ODRV_CMD_GET_ENCODER: putf(d, o->pos_rev); putf(d + 4, vel); break;
    case ODRV_CMD_GET_IQ: putf(d, w->kt > 0 ? (double)o->input_torque / w->kt : 0); putf(d + 4, o->iq + o->iq_inject_A); break;
    case ODRV_CMD_GET_TEMPERATURE: putf(d, 30.0 + 0.2 * absd(o->iq)); putf(d + 4, o->temp_motor); break;
    case ODRV_CMD_GET_BUS: {
        double pw = 0, ib;
        int k;
        for (k = 0; k < 3; k++) pw += s->od[k].T_motor * (double)s->p.w[k].mount_sign * s->ww[k] + s->od[k].iq * s->od[k].iq * s->p.w[k].R;
        ib = pw / s->p.vbus_V;
        putf(d, s->p.vbus_V - ib * s->p.batt_R); putf(d + 4, ib);
        break;
    }
    case ODRV_CMD_GET_TORQUES: putf(d, o->input_torque); putf(d + 4, o->T_motor); break;
    default: return;
    }
    canq_push(s, odrv_id(w->node, cmd), d, 8);
    o->tx_frames++;
}

static int hal_can_send(void *ctx, uint32_t id, const uint8_t *data, uint8_t len, bool rtr) {
    simdev_t *s = (simdev_t *)ctx;
    uint8_t node = (uint8_t)((id >> 5) & 0x3Fu), cmd = (uint8_t)(id & 0x1Fu);
    int i;
    for (i = 0; i < 3; i++) {
        sim_odrv_t *o = &s->od[i];
        if (!s->p.w[i].present || s->p.w[i].node != node || !o->powered || s->t_us < o->powered_at_us + s->p.driver_boot_us) continue;
        o->rx_frames++;
        if (rtr) { od_reply(s, i, cmd); return 0; }
        switch (cmd) {
        case ODRV_CMD_SET_AXIS_STATE: {
            uint32_t st = len >= 4 ? odrv_get_u32(data) : 0;
            if (st == ODRV_AXIS_IDLE) { o->axis_state = ODRV_AXIS_IDLE; o->closed_loop_pending = false; o->input_torque = 0; }
            else if (st == ODRV_AXIS_CLOSED_LOOP && !o->axis_error) { o->closed_loop_pending = true; o->closed_loop_at_us = s->t_us + 3000; }
            break;
        }
        case ODRV_CMD_SET_CTRL_MODE: if (len >= 8) { o->control_mode = odrv_get_u32(data); o->input_mode = odrv_get_u32(data + 4); } break;
        case ODRV_CMD_SET_INPUT_TORQUE: if (len >= 4) { float v = odrv_get_f32(data); o->input_torque = au_isfinitef(v) ? v : 0.0f; o->last_torque_us = s->t_us; } break;
        case ODRV_CMD_SET_LIMITS: if (len >= 8) { o->vel_limit = odrv_get_f32(data); o->current_limit = odrv_get_f32(data + 4); } break;
        case ODRV_CMD_CLEAR_ERRORS: o->axis_error = 0; o->disarm_reason = 0; break;
        case ODRV_CMD_ESTOP: o->axis_state = ODRV_AXIS_IDLE; o->axis_error |= ESTOP_ERROR; o->disarm_reason = ESTOP_ERROR; break;
        default: break;
        }
        return 0;
    }
    return 0;                      /* nobody on the bus answers: the frame is simply not acknowledged */
}

static int hal_can_recv(void *ctx, uint32_t *id, uint8_t *data, uint8_t *len, bool *rtr) {
    simdev_t *s = (simdev_t *)ctx;
    sim_can_t *f;
    if (!s->q_n) return 0;
    f = &s->q_rx[s->q_head];
    *id = f->id; au_memcpy(data, f->data, 8); *len = f->len; *rtr = f->rtr;
    s->q_head = (s->q_head + 1) % SIM_CANQ;
    s->q_n--;
    return 1;
}

static void od_power(simdev_t *s, bool on) {
    int i;
    for (i = 0; i < 3; i++) {
        sim_odrv_t *o = &s->od[i];
        if (on && !o->powered) {
            o->powered = true;
            o->powered_at_us = s->t_us;
            o->axis_state = ODRV_AXIS_IDLE; o->axis_error = 0; o->disarm_reason = 0; o->closed_loop_pending = false;
            o->input_torque = 0; o->control_mode = 0; o->vel_limit = 0; o->current_limit = 0;
            o->next_hb_us = s->t_us + s->p.driver_boot_us;
            o->next_enc_us = s->t_us + s->p.driver_boot_us;
        } else if (!on && o->powered) {
            o->powered = false;
            o->axis_state = ODRV_AXIS_IDLE;
            o->T_motor = 0; o->iq = 0;
        }
    }
}

/* the torque each driver applies now (motor direction), its cyclic messages and its watchdog */
static void od_tick(simdev_t *s, double T_model[3]) {
    int i;
    for (i = 0; i < 3; i++) {
        sim_odrv_t *o = &s->od[i];
        const sim_wheel_t *w = &s->p.w[i];
        double T = 0;
        T_model[i] = 0;
        if (!w->present || !o->powered) { o->T_motor = 0; o->iq = 0; continue; }
        if (s->t_us < o->powered_at_us + s->p.driver_boot_us) continue;
        if (o->closed_loop_pending && s->t_us >= o->closed_loop_at_us) {
            o->closed_loop_pending = false;
            if (!o->axis_error) { o->axis_state = ODRV_AXIS_CLOSED_LOOP; o->last_torque_us = s->t_us; }
        }
        if (o->axis_state == ODRV_AXIS_CLOSED_LOOP && s->p.watchdog_us && s->t_us - o->last_torque_us > s->p.watchdog_us) {
            o->axis_error |= WATCHDOG_ERROR; o->disarm_reason = WATCHDOG_ERROR; o->axis_state = ODRV_AXIS_IDLE;
        }
        if (o->axis_state == ODRV_AXIS_CLOSED_LOOP && o->control_mode == ODRV_CONTROL_TORQUE) {
            double ilim = o->current_limit > 0 && o->current_limit < w->Imax ? (double)o->current_limit : w->Imax;
            double vel = (double)w->mount_sign * s->ww[i] / TWO_PI;
            T = clampd((double)o->input_torque, -w->kt * ilim, w->kt * ilim);
            if (o->vel_limit > 0 && absd(vel) >= (double)o->vel_limit && T * vel > 0) T = 0;
            T_model[i] = avail(w, (double)w->mount_sign * T, s->ww[i]);
            T = (double)w->mount_sign * T_model[i];
        }
        o->T_motor = T;
        o->iq = w->kt > 0 ? T / w->kt : 0;
        o->temp_motor = 25.0 + 2.0 * absd(o->iq) + o->temp_inject_C;
        o->pos_rev += (double)w->mount_sign * s->ww[i] / TWO_PI * (1.0 / (double)s->p.plant_hz);
        if (s->t_us >= o->next_hb_us) { od_reply(s, i, ODRV_CMD_HEARTBEAT); o->next_hb_us += s->p.hb_period_us; }
        if (s->p.enc_period_us && s->t_us >= o->next_enc_us) { od_reply(s, i, ODRV_CMD_GET_ENCODER); o->next_enc_us += s->p.enc_period_us; }
    }
}

/* ------------------------------------------------------------------------------------------------ HAL */
static uint64_t hal_time(void *ctx) { return ((simdev_t *)ctx)->t_us; }
static bool hal_arm(void *ctx) { return ((simdev_t *)ctx)->arm; }
static bool hal_stop(void *ctx) { return ((simdev_t *)ctx)->estop; }
static bool hal_commission(void *ctx) { return ((simdev_t *)ctx)->commission; }
static void hal_motor_power(void *ctx, bool on) { simdev_t *s = (simdev_t *)ctx; s->motor_power = on; od_power(s, on && !s->estop); }
static void hal_led(void *ctx, int pattern) { ((simdev_t *)ctx)->led = pattern; }

static int hal_link_write(void *ctx, int link, const uint8_t *data, size_t n) {
    simdev_t *s = (simdev_t *)ctx;
    size_t k = n;
    if (link < 0 || link >= AERIS_LINKS || !s->link_up[link]) return (int)n;
    if (s->link_budget[link]) {
        size_t room = s->link_budget[link] > s->link_used[link] ? s->link_budget[link] - s->link_used[link] : 0;
        if (k > room) k = room;
        s->link_used[link] += k;
    }
    if (k && s->out) s->out(s->out_ctx, link, data, k);
    return (int)k;
}

static int hal_nvs_get(void *ctx, const char *key, uint8_t *buf, size_t cap, size_t *len) {
    simdev_t *s = (simdev_t *)ctx;
    int i;
    for (i = 0; i < SIM_NVS_SLOTS; i++) if (s->nvs[i].used && au_streq(s->nvs[i].key, key)) {
        if (s->nvs[i].len > cap) return -1;
        au_memcpy(buf, s->nvs[i].val, s->nvs[i].len);
        *len = s->nvs[i].len;
        return 0;
    }
    return 1;
}
static int hal_nvs_set(void *ctx, const char *key, const uint8_t *buf, size_t len) {
    simdev_t *s = (simdev_t *)ctx;
    int i, free_i = -1;
    if (len > sizeof s->nvs[0].val || au_strlen(key) >= sizeof s->nvs[0].key) return -1;
    for (i = 0; i < SIM_NVS_SLOTS; i++) {
        if (s->nvs[i].used && au_streq(s->nvs[i].key, key)) { free_i = i; break; }
        if (!s->nvs[i].used && free_i < 0) free_i = i;
    }
    if (free_i < 0) return -1;
    s->nvs[free_i].used = true;
    au_strlcpy(s->nvs[free_i].key, key, sizeof s->nvs[free_i].key);
    au_memcpy(s->nvs[free_i].val, buf, len);
    s->nvs[free_i].len = len;
    return 0;
}

static int hal_random(void *ctx, uint8_t *b, size_t n) {
    simdev_t *s = (simdev_t *)ctx;
    size_t i;
    if (s->crypto.random) return s->crypto.random(s->crypto.ctx, b, n);
    for (i = 0; i < n; i++) b[i] = (uint8_t)rnd64(&s->rng);
    return 0;
}
static int hal_sha256(void *ctx, const uint8_t *d, size_t n, uint8_t out[32]) { simdev_t *s = (simdev_t *)ctx; return s->crypto.sha256 ? s->crypto.sha256(s->crypto.ctx, d, n, out) : -1; }
static int hal_key_public(void *ctx, uint8_t pub[65], bool create) { simdev_t *s = (simdev_t *)ctx; return s->crypto.key_public ? s->crypto.key_public(s->crypto.ctx, pub, create) : -1; }
static int hal_sign(void *ctx, const uint8_t *m, size_t n, uint8_t sig[64]) { simdev_t *s = (simdev_t *)ctx; return s->crypto.sign ? s->crypto.sign(s->crypto.ctx, m, n, sig) : -1; }
static int hal_key_reset(void *ctx) { simdev_t *s = (simdev_t *)ctx; return s->crypto.key_reset ? s->crypto.key_reset(s->crypto.ctx) : -1; }

static int g_reboot_request;     /* set inside the core's call stack, handled after it returns */
static void hal_reboot(void *ctx, bool to_bootloader) { (void)ctx; g_reboot_request = to_bootloader ? 2 : 1; }
static void hal_log(void *ctx, int level, const char *msg) { slog((simdev_t *)ctx, level, msg); }

/* ------------------------------------------------------------------------------------------------ the synthetic device */
static void boot(simdev_t *s) {
    int i;
    s->boots++;
    s->q_head = s->q_n = 0;
    imu_reset(&s->imu);
    s->imu.next_sample_us = s->t_us;
    od_power(s, false);
    aeris_init(&s->dev, &s->hal, &s->board, s->device_id);
    for (i = 0; i < AERIS_LINKS; i++) if (s->link_up[i]) aeris_link_up(&s->dev, i);
    s->next_ctrl_us = s->t_us;
    s->next_service_us = s->t_us;
}

void simdev_init(simdev_t *s, const sim_params_t *p, const sim_crypto_t *crypto, const char *device_id, const char *chip) {
    int i;
    au_memset(s, 0, sizeof *s);
    s->p = *p;
    if (crypto) s->crypto = *crypto;
    s->rng = p->seed ? p->seed : 1;
    au_strlcpy(s->device_id, device_id, sizeof s->device_id);
    /* the plant starts held at the start attitude, wheels at rest */
    if (p->mode == MODE_EDGE) {
        double ax[3] = {1, 0, 0};
        s->th = p->start_theta;
        axis_angle(ax, PI / 4 + s->th, s->q);
    } else {
        au_memcpy(s->q, p->start_q, sizeof s->q);
        if (!(s->q[0] * s->q[0] + s->q[1] * s->q[1] + s->q[2] * s->q[2] + s->q[3] * s->q[3] > 0.5)) balance_q(s, s->q);
        qnorm(s->q);
    }
    s->held = true;
    for (i = 0; i < 3; i++) s->ww[i] = 0;
    s->hal.ctx = s;
    s->hal.time_us = hal_time;
    s->hal.i2c_read = hal_i2c_read;
    s->hal.i2c_write = hal_i2c_write;
    s->hal.can_send = hal_can_send;
    s->hal.can_recv = hal_can_recv;
    s->hal.arm_input = hal_arm;
    s->hal.stop_input = hal_stop;
    s->hal.commission_input = hal_commission;
    s->hal.motor_power = hal_motor_power;
    s->hal.led = hal_led;
    s->hal.link_write = hal_link_write;
    s->hal.nvs_get = hal_nvs_get;
    s->hal.nvs_set = hal_nvs_set;
    s->hal.random = hal_random;
    s->hal.sha256 = hal_sha256;
    s->hal.key_public = hal_key_public;
    s->hal.sign = hal_sign;
    s->hal.key_reset = hal_key_reset;
    s->hal.reboot = hal_reboot;
    s->hal.log = hal_log;
    s->board.board_id = "aeris-synthetic";
    s->board.chip = chip ? chip : "host";
    s->board.device_kind = "emulator";
    s->board.synthetic = true;
    s->board.actuation_build = true;          /* the motors are models: the whole control path can be exercised */
    s->board.commissioning_build = true;
    s->board.hard_max_current_A = 10.0f;
    s->board.hard_max_torque_Nm = 1.0f;
    s->board.hard_max_speed_rpm = 8000.0f;
    s->board.commissioning_max_torque_Nm = 0.05f;
    s->board.commissioning_max_speed_rpm = 600.0f;
    s->board.commissioning_max_ms = 2000;
    s->board.max_control_hz = 1000;
    s->board.imu_drivers = "lsm6dsox";
    s->board.motor_drivers = "odrive-cansimple";
    boot(s);
}

void simdev_set_output(simdev_t *s, sim_out_fn out, void *ctx) { s->out = out; s->out_ctx = ctx; }
void simdev_set_log(simdev_t *s, sim_log_fn log, void *ctx) { s->log = log; s->log_ctx = ctx; }

static void handle_reboot(simdev_t *s) {
    int r = g_reboot_request;
    g_reboot_request = 0;
    if (!r) return;
    if (r == 2) {
        /* the synthetic device has no flash to write: it stays "in the bootloader" briefly, then starts the same core */
        s->in_bootloader = true;
        s->bootloader_until_us = s->t_us + 2000000u;
        slog(s, 1, "synthetic device: bootloader requested (simulated; nothing is flashed)");
        od_power(s, false);
        return;
    }
    boot(s);
}

/* firmware/tests/timing_host.c measures the wall-clock time of each control step on the host; the hook exists only in
 * that build (-DAERIS_SIM_STEP_HOOK): every other build of the simulator compiles exactly as before */
#ifdef AERIS_SIM_STEP_HOOK
void aeris_sim_step_hook(int phase, int state);
#define STEP_HOOK(phase, s) aeris_sim_step_hook((phase), (int)(s)->dev.state)
#else
#define STEP_HOOK(phase, s) ((void)0)
#endif

void simdev_advance(simdev_t *s, uint64_t us) {
    uint64_t end = s->t_us + us, h_us = (uint64_t)(1000000 / (s->p.plant_hz > 0 ? s->p.plant_hz : 4000));
    double h = (double)h_us * 1e-6, T[3];
    int i;
    for (i = 0; i < AERIS_LINKS; i++) s->link_used[i] = 0;
    while (s->t_us < end) {
        if (s->in_bootloader) {
            if (s->t_us >= s->bootloader_until_us) { s->in_bootloader = false; boot(s); }
        } else {
            if (s->t_us >= s->next_ctrl_us) {
                STEP_HOOK(0, s);
                aeris_control_step(&s->dev);
                STEP_HOOK(1, s);
                s->next_ctrl_us += aeris_control_period_us(&s->dev);
                if (s->next_ctrl_us <= s->t_us) s->next_ctrl_us = s->t_us + aeris_control_period_us(&s->dev);
                if (s->dev.state == ST_BALANCING && s->held && !s->caught && !s->release_at_us) s->release_at_us = s->t_us + (uint64_t)(s->p.release_delay_s * 1e6);
            }
            if (s->t_us >= s->next_service_us) {
                aeris_service(&s->dev);
                s->next_service_us = s->t_us + 1000;
                handle_reboot(s);
            }
        }
        if (s->release_at_us && s->t_us >= s->release_at_us) { s->release_at_us = 0; if (!s->caught) s->held = false; }
        od_tick(s, T);
        plant_step(s, T, h);
        s->t_us += h_us;
        imu_tick(s);
    }
}

void simdev_link_up(simdev_t *s, int link) { if (link >= 0 && link < AERIS_LINKS) { s->link_up[link] = true; aeris_link_up(&s->dev, link); } }
void simdev_link_down(simdev_t *s, int link) { if (link >= 0 && link < AERIS_LINKS) { aeris_link_down(&s->dev, link); s->link_up[link] = false; } }
void simdev_input(simdev_t *s, int link, const uint8_t *data, size_t n) {
    if (s->in_bootloader) return;
    aeris_link_input(&s->dev, link, data, n);
    handle_reboot(s);
}
void simdev_set_arm(simdev_t *s, bool pressed) { s->arm = pressed; }
void simdev_set_estop(simdev_t *s, bool asserted) { s->estop = asserted; if (asserted) od_power(s, false); }
void simdev_set_commission(simdev_t *s, bool held) { s->commission = held; }
void simdev_push(simdev_t *s, const double torque_body[3], double seconds) {
    au_memcpy(s->ext_T, torque_body, sizeof s->ext_T);
    s->ext_until_us = s->t_us + (uint64_t)(seconds * 1e6);
}
void simdev_hold(simdev_t *s, const double q[4]) {
    int i;
    s->pose_active = false;
    s->held = true;
    s->caught = false;
    s->release_at_us = 0;
    for (i = 0; i < 3; i++) s->w[i] = 0;
    s->thd = 0;
    if (s->p.mode == MODE_EDGE) {
        double ax[3] = {1, 0, 0};
        s->th = s->p.start_theta;
        axis_angle(ax, PI / 4 + s->th, s->q);
    } else if (q) { au_memcpy(s->q, q, sizeof s->q); qnorm(s->q); }
    else au_memcpy(s->q, s->p.start_q, sizeof s->q);
}
void simdev_release(simdev_t *s) { s->pose_active = false; s->held = false; s->release_at_us = 0; }
void simdev_pose(simdev_t *s, const double q[4]) {
    int i;
    simdev_hold(s, NULL);
    for (i = 0; i < 4; i++) s->pose_q[i] = q[i];
    qnorm(s->pose_q);
    s->pose_active = true;
}
bool simdev_face_pose(simdev_t *s, const char *face) {
    /* the attitude (body → world) that turns the named body axis up */
    static const char *F[6] = {"+z", "-z", "+x", "-x", "+y", "-y"};
    const double r = 0.7071067811865476;
    const double Q[6][4] = {{1, 0, 0, 0}, {0, 1, 0, 0}, {r, 0, -r, 0}, {r, 0, r, 0}, {r, r, 0, 0}, {r, -r, 0, 0}};
    int i;
    for (i = 0; i < 6; i++)
        if (face && face[0] == F[i][0] && face[1] == F[i][1] && face[2] == 0) { simdev_pose(s, Q[i]); return true; }
    return false;
}
void simdev_spin_wheel(simdev_t *s, int i, double rads) { if (i >= 0 && i < 3) s->ww[i] = rads; }

/* ------------------------------------------------------------------------------------------------ plant model JSON
 * aeris-plant-model/1 (produced by the backend from a device profile; site/docs/DEVICE_LINK.md §8) */
static bool getd(const aj_doc_t *d, int obj, const char *k, double *v) { int t = aj_get(d, obj, k); return t >= 0 && aj_num(d, t, v) && au_isfinite(*v); }
static bool getvec(const aj_doc_t *d, int t, double *out, int n) {
    int i;
    if (aj_arr_len(d, t) != n) return false;
    for (i = 0; i < n; i++) if (!aj_num(d, aj_arr_at(d, t, i), &out[i]) || !au_isfinite(out[i])) return false;
    return true;
}
static bool getmat(const aj_doc_t *d, int t, double out[9]) {
    int r;
    if (aj_arr_len(d, t) != 3) return false;
    for (r = 0; r < 3; r++) if (!getvec(d, aj_arr_at(d, t, r), out + 3 * r, 3)) return false;
    return true;
}

bool simdev_plant_params_json(const char *json, size_t n, sim_params_t *p, char *err, size_t errcap) {
    static jsmntok_t tok[600];
    aj_doc_t d;
    int t, k, i;
    double v;
#define FAIL(m) do { au_strlcpy(err, m, errcap); return false; } while (0)
    if (aj_parse(&d, json, n, tok, 600) < 0) FAIL("plant model: not one JSON object");
    if (!aj_str_eq(&d, aj_get(&d, 0, "schema"), "aeris-plant-model/1")) FAIL("plant model: schema aeris-plant-model/1 required");
    t = aj_get(&d, 0, "mode");
    if (aj_str_eq(&d, t, "edge")) p->mode = MODE_EDGE; else if (aj_str_eq(&d, t, "corner")) p->mode = MODE_CORNER; else FAIL("plant model: mode edge or corner");
    if (!getd(&d, 0, "g", &p->g)) FAIL("plant model: g");
    if (p->mode == MODE_CORNER) {
        t = aj_get(&d, 0, "corner");
        if (t < 0 || !getmat(&d, aj_get(&d, t, "Th0"), p->Th0) || !getmat(&d, aj_get(&d, t, "Thhi"), p->Thhi) || !getd(&d, t, "M", &p->M) ||
            !getvec(&d, aj_get(&d, t, "rc"), p->rc, 3)) FAIL("plant model: corner {Th0, Thhi, M, rc}");
    } else {
        t = aj_get(&d, 0, "edge");
        if (t < 0 || !getd(&d, t, "Thh", &p->Thh) || !getd(&d, t, "mgl", &p->mgl) || !getd(&d, t, "beta", &p->beta)) FAIL("plant model: edge {Thh, mgl, beta}");
    }
    t = aj_get(&d, 0, "wheels");
    if (aj_arr_len(&d, t) != 3) FAIL("plant model: three wheels");
    for (k = 0; k < 3; k++) {
        int wt = aj_arr_at(&d, t, k);
        sim_wheel_t *w = &p->w[k];
        int64_t iv;
        if (!getvec(&d, aj_get(&d, wt, "axis"), w->axis, 3) || !getd(&d, wt, "Jw", &w->Jw) || !getd(&d, wt, "kt", &w->kt) || !getd(&d, wt, "R", &w->R) ||
            !getd(&d, wt, "Vs", &w->Vs) || !getd(&d, wt, "Imax", &w->Imax) || !getd(&d, wt, "wmax_rads", &w->wmax) || !getd(&d, wt, "cv", &w->cv) ||
            !getd(&d, wt, "cc", &w->cc)) FAIL("plant model: wheels[] {axis, Jw, kt, R, Vs, Imax, wmax_rads, cv, cc}");
        if (!aj_int(&d, aj_get(&d, wt, "mount_sign"), &iv) || (iv != 1 && iv != -1)) FAIL("plant model: wheels[].mount_sign ±1");
        w->mount_sign = (int)iv;
        if (!aj_int(&d, aj_get(&d, wt, "node"), &iv) || iv < 1 || iv > 62) FAIL("plant model: wheels[].node");
        w->node = (uint8_t)iv;
        w->present = true;
        { int pt = aj_get(&d, wt, "present"); bool b; if (pt >= 0 && aj_bool(&d, pt, &b)) w->present = b; }
    }
    t = aj_get(&d, 0, "imu");
    if (t >= 0) {
        int64_t iv;
        bool b;
        int pt = aj_get(&d, t, "present");
        if (pt >= 0 && aj_bool(&d, pt, &b)) p->imu_present = b;
        if (aj_int(&d, aj_get(&d, t, "address"), &iv)) p->imu_addr = (uint8_t)iv;
        if (aj_int(&d, aj_get(&d, t, "who_am_i"), &iv)) p->imu_who_am_i = (uint8_t)iv;
        if (aj_get(&d, t, "position_m") >= 0 && !getvec(&d, aj_get(&d, t, "position_m"), p->imu_pos, 3)) FAIL("plant model: imu.position_m");
        if (aj_get(&d, t, "to_sensor") >= 0 && !getvec(&d, aj_get(&d, t, "to_sensor"), p->to_sensor, 9)) FAIL("plant model: imu.to_sensor (9 numbers)");
        if (aj_get(&d, t, "gyro_bias_radps") >= 0 && !getvec(&d, aj_get(&d, t, "gyro_bias_radps"), p->gyro_bias, 3)) FAIL("plant model: imu.gyro_bias_radps");
        if (aj_get(&d, t, "accel_bias_mps2") >= 0 && !getvec(&d, aj_get(&d, t, "accel_bias_mps2"), p->accel_bias, 3)) FAIL("plant model: imu.accel_bias_mps2");
        if (getd(&d, t, "gyro_noise_radps", &v)) p->gyro_noise = v;
        if (getd(&d, t, "accel_noise_mps2", &v)) p->accel_noise = v;
    }
    t = aj_get(&d, 0, "power");
    if (t >= 0) { if (getd(&d, t, "vbus_V", &v)) p->vbus_V = v; if (getd(&d, t, "batt_R", &v)) p->batt_R = v; }
    t = aj_get(&d, 0, "start");
    if (t >= 0) {
        int qt = aj_get(&d, t, "q");
        if (qt >= 0 && !aj_is_null(&d, qt) && !getvec(&d, qt, p->start_q, 4)) FAIL("plant model: start.q");
        if (getd(&d, t, "theta", &v)) p->start_theta = v;
        if (getd(&d, t, "catch_deg", &v)) p->catch_rad = v * PI / 180.0;
        if (getd(&d, t, "release_delay_s", &v)) p->release_delay_s = v;
    }
    {
        int64_t sd;
        if (aj_int(&d, aj_get(&d, 0, "seed"), &sd) && sd > 0) p->seed = (uint64_t)sd;
    }
    for (i = 0; i < 3; i++) if (!(p->w[i].Jw > 0) || !(p->w[i].kt > 0)) FAIL("plant model: wheel Jw and kt must be positive");
#undef FAIL
    return true;
}

#!/usr/bin/env python3
"""Generate the firmware test fixtures FROM THE BACKEND (run from the repository root):

  firmware/tests/fixtures/config_<mode>.json   the approved device configuration of the reference profile + recipe
                                               (backend devices.configgen.device_config, canonical text) and its hash
  firmware/tests/fixtures/plant_<mode>.json    the synthetic device's plant for the same profile (configgen.plant_model)
  firmware/tests/fixtures/parity_estimator.json  inputs to and outputs of the backend's cf3d estimator
                                               (estimation.ComplementaryAttitude) on a seeded synthetic sample sequence
  firmware/tests/fixtures/parity_controller_<mode>.json  states and the torques of the backend's controllers
                                               (control.controllers EdgeLegacy 'lqr' / CornerMimo) for them

The C tests (firmware/tests/test_core.c) check the firmware's ports against these numbers. Everything is synthetic.
Usage: backend/.venv/bin/python firmware/tools/make_fixtures.py [--check]   (--check: regenerate in memory and compare)
Run it with the backend's environment (backend/requirements-lock.txt): the files hold floating-point results, and
another NumPy version can change their last digits (seen: NumPy 2.4.4 vs the pinned 2.5.3 differ by < 1e-12 N·m in the
corner controller's torques), which the byte comparison of --check reports as drift.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "backend"))

import numpy as np  # noqa: E402

from aeris_backend.config.validate import validate_config  # noqa: E402
from aeris_backend.devices import configgen, reference  # noqa: E402
from aeris_backend.estimation import ComplementaryAttitude, Estimate  # noqa: E402
from aeris_backend.physics.quaternion import edge_quat, qconj, qmul, qnorm, exp_vec  # noqa: E402
from aeris_backend.sensors import ImuSample  # noqa: E402
from aeris_backend.simulation.engine import Engine  # noqa: E402

OUT = os.path.join(ROOT, "firmware", "tests", "fixtures")


def dump(obj, compact=False) -> str:
    if compact:
        return json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n"
    return json.dumps(obj, indent=1, sort_keys=True) + "\n"


def estimator_fixture():
    prof = reference.reference_profile()
    rec = reference.recipe("corner-hold-10s")
    D = configgen.design(prof, rec)
    cfg = D["config"]
    dc = configgen.device_config(prof, rec)["config"]
    q_nom = tuple(dc["estimator"]["q_nominal"])
    est = ComplementaryAttitude(cfg, q_nom)
    rng = np.random.default_rng(20261009)
    r = np.array(dc["estimator"]["imu_position_m"])
    g = dc["estimator"]["g_mps2"]
    dt = 1.0 / 833.0
    q = np.array(qnorm(qmul(q_nom, exp_vec((0.02, -0.015, 0.01)))))
    w_prev = np.zeros(3)
    samples, outputs = [], []
    t = 0.0
    for k in range(800):
        t = k * dt
        w = np.array([0.4 * math.sin(2.1 * t), 0.3 * math.cos(1.3 * t), 0.2 * math.sin(0.7 * t + 0.5)])
        wd = (w - w_prev) / dt if k else np.zeros(3)
        w_prev = w
        qq = tuple(q)
        up = np.array([2 * (qq[1] * qq[3] - qq[0] * qq[2]), 2 * (qq[2] * qq[3] + qq[0] * qq[1]), 1 - 2 * (qq[1] ** 2 + qq[2] ** 2)])
        f = np.cross(wd, r) + np.cross(w, np.cross(w, r)) + g * up
        gyro = w + np.array([0.004, -0.003, 0.002]) + rng.normal(0, 0.003, 3)
        accel = f + rng.normal(0, 0.05, 3)
        if k % 97 == 50:
            accel = accel * 1.3          # a sample outside the gate (dynamic acceleration): it must be gated
        ts = t
        if k == 700:
            ts = t - 0.5 * dt            # an out-of-order sample: rejected
        s = ImuSample(ts, tuple(float(x) for x in gyro), tuple(float(x) for x in accel))
        acc = est.accept(s, ts)
        samples.append([ts, [float(x) for x in gyro], [float(x) for x in accel]])
        qp, wp = est.predict(t + 0.0007)
        outputs.append({"accepted": bool(acc), "q": [float(x) for x in est.q], "b": [float(x) for x in est.b],
                        "q_pred": [float(x) for x in qp], "w_pred": [float(x) for x in wp], "gated": int(est.gated), "updates": int(est.updates)})
        q = np.array(qnorm(qmul(tuple(q), exp_vec(tuple(w * dt)))))
    return {"description": "backend estimation.ComplementaryAttitude (cf3d) on a seeded synthetic sequence; predict at t + 0.7 ms",
            "estimator": dc["estimator"], "samples": samples, "outputs": outputs}


def controller_fixture(mode):
    prof = reference.reference_profile()
    rid = "edge-hold-10s" if mode == "edge" else "corner-hold-10s"
    rec = reference.recipe(rid)
    built = configgen.device_config(prof, rec)
    raw = built["engine_config"]
    v = validate_config(raw)
    eng = Engine(v.config, v.mp)
    ctrl = eng.controller
    rng = np.random.default_rng(7 if mode == "edge" else 8)
    cases = []
    q0e = qconj(edge_quat(0.0))
    for k in range(60):
        est = Estimate()
        if mode == "edge":
            th = float(rng.normal(0, 0.04))
            q = edge_quat(th)
            r = qmul(q0e, q)
            est.theta = 2 * math.atan2(r[1], r[0])
            w = (float(rng.normal(0, 0.3)), 0.0, 0.0)
            est.thetadot = w[0]
        else:
            qeq = tuple(built["config"]["controller"]["q_eq"])
            q = qnorm(qmul(qeq, exp_vec(tuple(float(x) for x in rng.normal(0, 0.03, 3)))))
            if k > 30:   # some cases with a heading offset (the reference heading is captured at the first call)
                q = qnorm(qmul(exp_vec((0.0, 0.0, 0.3)), q))
            w = tuple(float(x) for x in rng.normal(0, 0.2, 3))
        est.q = tuple(float(x) for x in q)
        est.w = w
        ww = [float(x) for x in rng.normal(0, 40, 3)]
        req = ctrl.request(k * 0.002, est, ww, [False, False, False])
        cases.append({"q": list(est.q), "w": list(w), "omega": ww, "T": [float(x) for x in req.per_wheel]})
    return {"description": f"backend control.controllers ({type(ctrl).__name__}) on states near the balance attitude; the heading reference is captured at the first case",
            "config_hash": built["hash"], "cases": cases}


def build():
    files = {}
    prof = reference.reference_profile()
    for mode, rid in (("edge", "edge-hold-10s"), ("corner", "corner-hold-10s")):
        rec = reference.recipe(rid)
        dc = configgen.device_config(prof, rec)
        files[f"config_{mode}.json"] = dc["text"] + "\n"
        files[f"config_{mode}.sha256"] = dc["hash"] + "\n"
        files[f"plant_{mode}.json"] = dump(configgen.plant_model(prof, rec))
        files[f"parity_controller_{mode}.json"] = dump(controller_fixture(mode), compact=True)
    files["parity_estimator.json"] = dump(estimator_fixture(), compact=True)
    return files


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    files = build()
    os.makedirs(OUT, exist_ok=True)
    bad = 0
    for name, text in sorted(files.items()):
        path = os.path.join(OUT, name)
        if a.check:
            cur = open(path, encoding="utf-8").read() if os.path.exists(path) else None
            if cur != text:
                print("DIFFERS", name)
                bad += 1
            else:
                print("same   ", name)
        else:
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
            print("wrote", os.path.relpath(path, ROOT), len(text), "bytes")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()

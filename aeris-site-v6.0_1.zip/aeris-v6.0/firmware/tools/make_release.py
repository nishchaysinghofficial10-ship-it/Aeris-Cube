#!/usr/bin/env python3
"""Package a built ESP32-S3 image as a firmware release the website's installer can verify (site/docs/FIRMWARE_INSTALL.md).

    python firmware/tools/make_release.py --build firmware/esp32s3/build/release --out site/firmware/releases/0.1.0 \
        --key /path/outside/the/repo/dev-key.pem --key-id aeris-dev-test-20261010

Writes the flash parts (bootloader, partition table, application) and manifest.json (aeris-firmware-manifest/1): chip,
board, flash settings, offsets, sizes and SHA-256 of every part, the firmware version and build id the device must
report after installation, the SHA-256 of the firmware sources the image was built from (firmware/tools/source_hash.py,
recorded by build_esp32s3.sh), and an ECDSA P-256 signature (raw r||s, base64url) over the manifest's canonical JSON
(sorted keys, no whitespace, the "signature" member removed).

Trust model: the installer accepts a manifest only when its signature verifies with a key listed in
site/firmware/trust.json. "production" keys sign releases; "development" keys sign builds made by developers and are
accepted only after the visitor explicitly allows development builds. v6.0 has NO production key: its manifests are
signed with a development test key whose private half is kept outside the repository and is never distributed.
Signing proves which key approved these bytes — not that the firmware is safe or that any hardware was tested.

    python firmware/tools/make_release.py --new-key /path/outside/the/repo/dev-key.pem      # create a development key
    python firmware/tools/make_release.py --verify site/firmware/releases/0.1.0                # check hashes + signature
"""
from __future__ import annotations

import argparse
import base64
import datetime as _dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import source_hash  # noqa: E402  (firmware/tools/source_hash.py)

FW = os.path.dirname(HERE)
REPO = os.path.dirname(FW)
TRUST = os.path.join(REPO, "site", "firmware", "trust.json")
SCHEMA = "aeris-firmware-manifest/1"


def b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")


def sha256(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def load_key(path: str):
    from cryptography.hazmat.primitives import serialization
    with open(path, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def pub_b64u(key) -> str:
    from cryptography.hazmat.primitives import serialization
    return b64u(key.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint))


def sign(key, msg: bytes) -> str:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
    r, s = decode_dss_signature(key.sign(msg, ec.ECDSA(hashes.SHA256())))
    return b64u(r.to_bytes(32, "big") + s.to_bytes(32, "big"))


def verify_sig(pub: str, msg: bytes, sig: str) -> bool:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
    raw = b64u_dec(sig)
    if len(raw) != 64:
        return False
    try:
        k = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), b64u_dec(pub))
        k.verify(encode_dss_signature(int.from_bytes(raw[:32], "big"), int.from_bytes(raw[32:], "big")), msg, ec.ECDSA(hashes.SHA256()))
        return True
    except (InvalidSignature, ValueError):
        return False


def fw_version() -> str:
    h = open(os.path.join(FW, "core", "include", "aeris", "device.h"), encoding="utf-8").read()
    return re.search(r'#define AERIS_FW_VERSION\s+"([^"]+)"', h).group(1)


def build_info(build: str) -> dict:
    cache = open(os.path.join(build, "CMakeCache.txt"), encoding="utf-8").read()
    m = re.search(r"^AERIS_BUILD_ID:[A-Z]+=(.+)$", cache, re.M)
    sdk = open(os.path.join(build, "config", "sdkconfig.h"), encoding="utf-8").read()
    act = "#define CONFIG_AERIS_ACTUATION_ENABLED 1" in sdk
    com = "#define CONFIG_AERIS_COMMISSIONING 1" in sdk
    idf, cc = None, None
    desc = os.path.join(build, "project_description.json")
    if os.path.isfile(desc):
        d = json.load(open(desc, encoding="utf-8"))
        idf = d.get("idf_ver") or d.get("git_revision")          # ESP-IDF v6 records its revision as git_revision
        cc = d.get("c_compiler")
    if not idf:
        v = re.search(r'#define CONFIG_IDF_INIT_VERSION "([^"]+)"', sdk)
        idf = ("v" + v.group(1)) if v else None
    compiler = None
    if cc and os.path.isfile(cc):
        try:
            compiler = subprocess.run([cc, "--version"], capture_output=True, text=True, check=True).stdout.splitlines()[0].strip()
        except (OSError, subprocess.CalledProcessError, IndexError):
            compiler = os.path.basename(cc)
    return {"build_id": m.group(1).strip() if m else None, "actuation": act, "commissioning": com, "idf_version": idf, "compiler": compiler}


def git_head() -> str | None:
    try:
        return subprocess.run(["git", "-C", REPO, "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def build_sources(build: str) -> str:
    """The sources hash build_esp32s3.sh recorded when it built this directory; refuses a build whose sources have
    changed since (the manifest would name sources the image was not built from)."""
    p = os.path.join(build, "aeris-sources.sha256")
    if not os.path.isfile(p):
        raise SystemExit(f"refusing: {p} is missing (build with firmware/tools/build_esp32s3.sh, which records the sources it built)")
    recorded = open(p, encoding="ascii").read().strip()
    current = source_hash.sources_sha256("esp32s3")
    if recorded != current:
        raise SystemExit(f"refusing: the firmware sources changed after this build (built {recorded[:12]}, now {current[:12]}); build again")
    return recorded


def make(build: str, out: str, key_path: str, key_id: str, channel: str) -> dict:
    fa = json.load(open(os.path.join(build, "flasher_args.json"), encoding="utf-8"))
    info = build_info(build)
    sources = build_sources(build)
    if info["actuation"] or info["commissioning"]:
        raise SystemExit("refusing: this build can drive motors (actuation/commissioning compiled in); the website installer only offers builds that never drive motors")
    if fa["extra_esptool_args"]["chip"] != "esp32s3":
        raise SystemExit("not an ESP32-S3 build")
    os.makedirs(out, exist_ok=True)
    names = {"bootloader": "bootloader.bin", "partition-table": "partition-table.bin", "app": "aeris_fw.bin"}
    parts = []
    for key in ("bootloader", "partition-table", "app"):
        src = os.path.join(build, fa[key]["file"])
        dst = os.path.join(out, names[key])
        shutil.copyfile(src, dst)
        parts.append({"name": key, "offset": int(fa[key]["offset"], 16), "file": names[key], "bytes": os.path.getsize(dst), "sha256": sha256(dst)})
    version = fw_version()
    manifest = {
        "schema": SCHEMA,
        "product": "aeris-fw",
        "version": version,
        "build": info["build_id"],
        "channel": channel,
        "created": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "source": {"repository": "AERIS", "commit": git_head(), "firmware_sources_sha256": sources,
                   "toolchain": f"ESP-IDF {info['idf_version'] or 'unknown'}" + (f"; {info['compiler']}" if info.get("compiler") else "")},
        "target": {"chip": "ESP32-S3", "board": "esp32-s3-devkitc-1", "flash_min_bytes": 4 * 1024 * 1024},
        "flash": {"mode": fa["flash_settings"]["flash_mode"], "frequency": fa["flash_settings"]["flash_freq"], "size": fa["flash_settings"]["flash_size"]},
        "parts": parts,
        "capabilities": {"actuation": False, "commissioning": False, "link": "aeris-device-link/1", "config_schema": "aeris-device-config/1"},
        "expected_hello": {"fw.version": version, "fw.build": info["build_id"], "fw.actuation_build": False, "board.id": "esp32-s3-devkitc-1"},
        "readiness": ("Software-tested: host tests of the firmware core, a release-image boot and a protocol test in the Espressif QEMU emulator. "
                      "Never run on a physical board. This build never drives motors."),
        "not_offered": [{"variant": "experimental", "reason": "motor actuation and commissioning compiled in: built from source by the person "
                                                              "responsible for the hardware (firmware/README.md); never installed by the website"}],
        "recovery": "If an installation is interrupted, hold BOOT, press RESET, release BOOT and install again: the ROM bootloader is not overwritten.",
    }
    key = load_key(key_path)
    manifest["signature"] = {"alg": "ES256", "key_id": key_id, "public_key": pub_b64u(key), "sig": sign(key, canonical(manifest))}
    with open(os.path.join(out, "manifest.json"), "w", encoding="ascii") as f:
        json.dump(manifest, f, indent=1, ensure_ascii=True)
        f.write("\n")
    return manifest


def verify(rel_dir: str, trust_path: str = TRUST) -> dict:
    m = json.load(open(os.path.join(rel_dir, "manifest.json"), encoding="ascii"))
    sig = m.pop("signature")
    trust = json.load(open(trust_path, encoding="utf-8"))
    found = None
    for level in ("production", "development"):
        for k in trust.get(level) or []:
            if k["key_id"] == sig["key_id"] and k["public_key"] == sig["public_key"]:
                found = level
    out = {"signature_valid": verify_sig(sig["public_key"], canonical(m), sig["sig"]), "trust": found or "unknown-key", "parts": []}
    for p in m["parts"]:
        f = os.path.join(rel_dir, p["file"])
        ok = os.path.isfile(f) and os.path.getsize(f) == p["bytes"] and sha256(f) == p["sha256"]
        out["parts"].append({"file": p["file"], "ok": ok})
    out["ok"] = out["signature_valid"] and found is not None and all(x["ok"] for x in out["parts"])
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--build")
    ap.add_argument("--out")
    ap.add_argument("--key")
    ap.add_argument("--key-id")
    ap.add_argument("--channel", default="development", choices=("development", "production"))
    ap.add_argument("--new-key", metavar="PEM")
    ap.add_argument("--verify", metavar="RELEASE_DIR")
    a = ap.parse_args(argv)
    if a.new_key:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        if os.path.abspath(a.new_key).startswith(REPO + os.sep):
            raise SystemExit("refusing to write a private key inside the repository")
        k = ec.generate_private_key(ec.SECP256R1())
        with open(a.new_key, "wb") as f:
            f.write(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        os.chmod(a.new_key, 0o600)
        print(json.dumps({"public_key": pub_b64u(k)}))
        return 0
    if a.verify:
        r = verify(a.verify)
        print(json.dumps(r, indent=1))
        return 0 if r["ok"] else 1
    if not (a.build and a.out and a.key and a.key_id):
        ap.error("--build, --out, --key and --key-id are required")
    if os.path.abspath(a.key).startswith(REPO + os.sep):
        raise SystemExit("refusing: the signing key must live outside the repository")
    m = make(a.build, a.out, a.key, a.key_id, a.channel)
    print(json.dumps({"version": m["version"], "build": m["build"], "parts": [(p["file"], p["sha256"]) for p in m["parts"]]}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())

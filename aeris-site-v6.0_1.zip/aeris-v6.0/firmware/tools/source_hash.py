#!/usr/bin/env python3
"""SHA-256 over the source files a firmware artifact is built from, recorded when the artifact is built and checked
by the drift suite (scripts/check_drift.py), so a committed binary can be tied to the sources it came from without a
byte-reproducible toolchain.

    python3 firmware/tools/source_hash.py esp32s3|wasm          # print the hash
    python3 firmware/tools/source_hash.py esp32s3 --list        # the files, each with its SHA-256

The hash is SHA-256 over the lines "<path relative to the repository, '/' separators>\\t<SHA-256 of the file>\\n" in
sorted path order. It is computed from the files on disk (a git checkout or an extracted release ZIP give the same
answer); build output and generated configuration are excluded:
  esp32s3  firmware/core (sources, headers, third_party), firmware/esp32s3 (without build/, sdkconfig, sdkconfig.old,
           managed_components/), firmware/tools/build_esp32s3.sh
  wasm     firmware/core, firmware/sim, firmware/wasm, firmware/tools/build_wasm.sh
"""
from __future__ import annotations

import hashlib
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FW = os.path.dirname(HERE)
REPO = os.path.dirname(FW)
SKIP_DIRS = {"build", "managed_components", "__pycache__", ".git"}
SKIP_FILES = {"sdkconfig", "sdkconfig.old", ".DS_Store"}
TARGETS = {
    "esp32s3": (["firmware/core", "firmware/esp32s3"], ["firmware/tools/build_esp32s3.sh"]),
    "wasm": (["firmware/core", "firmware/sim", "firmware/wasm"], ["firmware/tools/build_wasm.sh"]),
}


def files(target: str, repo: str = REPO) -> list:
    dirs, singles = TARGETS[target]
    out = []
    for d in dirs:
        for base, subdirs, names in os.walk(os.path.join(repo, d)):
            subdirs[:] = sorted(s for s in subdirs if s not in SKIP_DIRS)
            out += [os.path.relpath(os.path.join(base, n), repo).replace(os.sep, "/") for n in names if n not in SKIP_FILES and not n.endswith(".pyc")]
    out += [s for s in singles if os.path.isfile(os.path.join(repo, s))]
    return sorted(set(out))


def listing(target: str, repo: str = REPO) -> list:
    rows = []
    for rel in files(target, repo):
        with open(os.path.join(repo, rel), "rb") as f:
            rows.append((rel, hashlib.sha256(f.read()).hexdigest()))
    return rows


def sources_sha256(target: str, repo: str = REPO) -> str:
    return hashlib.sha256("".join(f"{p}\t{h}\n" for p, h in listing(target, repo)).encode("utf-8")).hexdigest()


def main(argv=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if not argv or argv[0] not in TARGETS:
        print("usage: source_hash.py esp32s3|wasm [--list]", file=sys.stderr)
        return 2
    if "--list" in argv:
        for p, h in listing(argv[0]):
            print(f"{h}  {p}")
    print(sources_sha256(argv[0]))
    return 0


if __name__ == "__main__":
    sys.exit(main())

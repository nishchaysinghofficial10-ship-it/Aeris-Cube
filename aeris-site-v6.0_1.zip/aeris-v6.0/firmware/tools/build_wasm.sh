#!/usr/bin/env bash
# Build the browser's synthetic device: firmware core + device models → WebAssembly (clang 18, no libc).
#   firmware/tools/build_wasm.sh [output]   (default: site/firmware/synthetic/aeris-device.wasm)
# Writes <output without .wasm>.build.json next to it (aeris-wasm-build/1): the file's SHA-256, the SHA-256 of the
# sources it was built from (firmware/tools/source_hash.py wasm) and the compiler, so the drift suite can tell whether
# the committed module still matches the sources and rebuild it byte for byte with the same compiler.
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$HERE/../site/firmware/synthetic/aeris-device.wasm}"
CC="${CLANG:-clang-18}"
cd "$HERE"
CORE="core/src/util.c core/src/json.c core/src/mathq.c core/src/drivers.c core/src/config.c core/src/control.c core/src/device.c core/src/link.c core/src/command.c core/src/telemetry.c core/src/tasks.c"
"$CC" --target=wasm32 -O2 -std=c11 -nostdlib -ffreestanding -Wall -Wextra -Werror -Wno-unused-parameter -Icore/include -Isim/include \
      -Wl,--no-entry -Wl,--allow-undefined -Wl,--strip-all -Wl,-z,stack-size=262144 -o "$OUT" $CORE sim/src/sim.c wasm/aeris_wasm.c wasm/wasm_libc.c
python3 - "$OUT" "$("$CC" --version | head -n 1)" "$(python3 "$HERE/tools/source_hash.py" wasm)" <<'EOF'
import hashlib, json, os, sys
out, compiler, sources = sys.argv[1], sys.argv[2].strip(), sys.argv[3].strip()
info = {"schema": "aeris-wasm-build/1", "file": os.path.basename(out), "sha256": hashlib.sha256(open(out, "rb").read()).hexdigest(),
        "bytes": os.path.getsize(out), "sources_sha256": sources, "compiler": compiler, "command": "firmware/tools/build_wasm.sh"}
path = out[:-len(".wasm")] + ".build.json" if out.endswith(".wasm") else out + ".build.json"
with open(path, "w", encoding="utf-8") as f:
    json.dump(info, f, indent=1)
    f.write("\n")
print(info["sha256"], out)
EOF

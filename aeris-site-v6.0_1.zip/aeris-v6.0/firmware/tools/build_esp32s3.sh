#!/usr/bin/env bash
# Build the ESP32-S3 images with a pinned ESP-IDF (v6.0.3) and toolchain (xtensa-esp-elf esp-15.2.0_20251204).
#   firmware/tools/build_esp32s3.sh <release|experimental|all> [build-id]
# Environment: IDF_PATH (ESP-IDF v6.0.3 checkout with submodules), AERIS_XTENSA_BIN (toolchain bin directory),
#              AERIS_IDF_PYTHON (python of a venv with tools/requirements/requirements.core.txt installed).
# The component manager is disabled (IDF_COMPONENT_MANAGER=0): every component is in ESP-IDF or vendored here.
# Each build directory receives aeris-sources.sha256: firmware/tools/source_hash.py esp32s3 at the start of the build
# (make_release.py signs it into the manifest; the QEMU test and the drift suite compare it with the current sources).
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
VARIANT="${1:-release}"
BUILD_ID="${2:-$(git -C "$HERE" rev-parse --short=12 HEAD 2>/dev/null || echo dev)}"
: "${IDF_PATH:?set IDF_PATH to the ESP-IDF v6.0.3 checkout}"
: "${AERIS_XTENSA_BIN:?set AERIS_XTENSA_BIN to the xtensa-esp-elf bin directory}"
PY="${AERIS_IDF_PYTHON:-python3}"
export PATH="$AERIS_XTENSA_BIN:$(dirname "$PY"):$PATH"
export IDF_PYTHON_CHECK_CONSTRAINTS=no IDF_COMPONENT_MANAGER=0 IDF_PYTHON_ENV_PATH="$(dirname "$(dirname "$PY")")"
cd "$HERE/esp32s3"
build() {
  local v="$1" src
  src="$("$PY" "$HERE/tools/source_hash.py" esp32s3)"       # the sources this image is built from (drift suite, make_release)
  "$PY" "$IDF_PATH/tools/idf.py" -B "build/$v" -DSDKCONFIG="build/$v/sdkconfig" \
       -DSDKCONFIG_DEFAULTS="sdkconfig.defaults;sdkconfig.$v" -DAERIS_BUILD_ID="$BUILD_ID-$v" build
  echo "$src" > "build/$v/aeris-sources.sha256"
}
case "$VARIANT" in
  release|experimental|qemutest) build "$VARIANT" ;;
  all) build release; build experimental; build qemutest ;;
  *) echo "usage: $0 <release|experimental|qemutest|all> [build-id]" >&2; exit 2 ;;
esac

#!/usr/bin/env python3
"""Stand-in for the board's own network client when the device is the HOST synthetic device.

A cube built from firmware/esp32s3 opens its own outbound WebSocket over TLS to the backend (main/net.c; the gateway
URL is stored over USB with the set_network command) and speaks aeris-device-link/1 on it. The synthetic device process (aeris-hostsim) instead exposes its
network link as a listening TCP port (--net-tcp PORT). This bridge connects that port to the backend's gateway
endpoint so the gateway route can be exercised end to end without a board:

    python firmware/tools/synthetic_net_bridge.py --device 127.0.0.1:7101 --backend ws://127.0.0.1:8750
    python firmware/tools/synthetic_net_bridge.py --device 127.0.0.1:7101 --backend wss://127.0.0.1:8750 --cafile ca.pem

Over wss:// the backend's certificate is verified (hostname and chain) against --cafile, or the system's trust store
without it — like the board, which verifies the server against the ESP-IDF CA bundle.

It copies bytes unchanged in both directions (the device authenticates itself to the backend with its own key; the
bridge holds no credential). It is test tooling for SYNTHETIC devices only and is not shipped to boards.
"""
from __future__ import annotations

import argparse
import asyncio
import sys


async def bridge(device: str, backend: str, cafile: str | None = None) -> int:
    from websockets.asyncio.client import connect
    host, port = device.rsplit(":", 1)
    r, w = await asyncio.open_connection(host, int(port))
    url = backend.rstrip("/") + "/api/v6/device-link"
    kw = {}
    if url.startswith("wss://"):
        import ssl
        kw["ssl"] = ssl.create_default_context(cafile=cafile) if cafile else ssl.create_default_context()
    try:
        ws_cm = connect(url, max_size=2**20, open_timeout=10, **kw)
        ws = await ws_cm.__aenter__()
    except Exception as e:  # noqa: BLE001 — reported, e.g. a certificate that does not verify
        print("bridge ended: error", repr(e), flush=True)
        w.close()
        return 1
    try:
        async def up():
            while True:
                b = await r.read(4096)
                if not b:
                    return "device closed"
                await ws.send(b)

        async def down():
            from websockets.exceptions import ConnectionClosed
            try:
                async for m in ws:
                    w.write(m if isinstance(m, bytes) else m.encode("utf-8"))
                    await w.drain()
            except ConnectionClosed:
                pass                       # closed with an application code (e.g. 4401: authentication refused)
            return f"backend closed ({ws.close_code} {ws.close_reason})"

        tasks = [asyncio.create_task(up()), asyncio.create_task(down())]
        done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
        for t in done:
            print("bridge ended:", t.result() if t.exception() is None else f"error {t.exception()!r}", flush=True)
    finally:
        await ws_cm.__aexit__(None, None, None)
    w.close()
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--device", required=True, help="HOST:PORT of aeris-hostsim --net-tcp")
    ap.add_argument("--backend", required=True, help="ws://… or wss://… origin of the backend")
    ap.add_argument("--cafile", help="wss://: verify the backend's certificate against this CA file (default: the system's trust store)")
    a = ap.parse_args(argv)
    sys.exit(asyncio.run(bridge(a.device, a.backend, a.cafile)))


if __name__ == "__main__":
    main()

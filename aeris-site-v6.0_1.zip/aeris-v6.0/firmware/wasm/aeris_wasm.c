/* AERIS synthetic device for the browser: the firmware core + the device models (firmware/sim) compiled to WebAssembly.
 *
 * The page (site/js/connect/synthetic.js, used by the Connect page site/js/connect/connect-ui.js) owns time and the
 * transport: it calls sd_advance() from a timer loop, feeds link bytes with sd_input() and receives the device's bytes
 * through the imported aeris_out(). Cryptography is imported from the page (the maintained @noble/curves P-256 and
 * @noble/hashes SHA-256 libraries, vendored as site/vendor/noble-p256-sha256.min.js); the core implements none.
 * Everything this device produces is SYNTHETIC. */
#include "aeris_sim.h"
#include "aeris/util.h"

#define EXPORT(name) __attribute__((export_name(#name)))
#define IMPORT(name) __attribute__((import_module("env"), import_name(#name)))

IMPORT(aeris_out) void js_out(int link, const uint8_t *data, size_t n);
IMPORT(aeris_log) void js_log(int level, const char *msg);
IMPORT(aeris_sha256) int js_sha256(const uint8_t *d, size_t n, uint8_t *out);
IMPORT(aeris_key_public) int js_key_public(uint8_t *pub, int create);
IMPORT(aeris_sign) int js_sign(const uint8_t *m, size_t n, uint8_t *sig);
IMPORT(aeris_key_reset) int js_key_reset(void);
IMPORT(aeris_random) int js_random(uint8_t *b, size_t n);

static simdev_t g_sim;
static sim_params_t g_params;
static uint8_t g_buf[65536];
static char g_err[256];
static char g_id[48];

static int c_sha256(void *ctx, const uint8_t *d, size_t n, uint8_t out[32]) { (void)ctx; return js_sha256(d, n, out); }
static int c_key_public(void *ctx, uint8_t pub[65], bool create) { (void)ctx; return js_key_public(pub, create ? 1 : 0); }
static int c_sign(void *ctx, const uint8_t *m, size_t n, uint8_t sig[64]) { (void)ctx; return js_sign(m, n, sig); }
static int c_key_reset(void *ctx) { (void)ctx; return js_key_reset(); }
static int c_random(void *ctx, uint8_t *b, size_t n) { (void)ctx; return js_random(b, n); }
static void c_out(void *ctx, int link, const uint8_t *d, size_t n) { (void)ctx; js_out(link, d, n); }
static void c_log(void *ctx, int level, const char *msg) { (void)ctx; js_log(level, msg); }

EXPORT(sd_buffer) uint8_t *sd_buffer(void) { return g_buf; }
EXPORT(sd_buffer_size) size_t sd_buffer_size(void) { return sizeof g_buf; }
EXPORT(sd_error) const char *sd_error(void) { return g_err; }

/* plant model JSON (aeris-plant-model/1) in sd_buffer()[0..n); device id after it. Returns 0 or -1 (sd_error()). */
EXPORT(sd_init) int sd_init(size_t plant_len, size_t id_off, size_t id_len) {
    sim_crypto_t c = {c_sha256, c_key_public, c_sign, c_key_reset, c_random, 0};
    int edge = 0;
    size_t i;
    for (i = 0; i + 6 <= plant_len; i++) if (au_memcmp(g_buf + i, "\"edge\"", 6) == 0) { edge = 1; break; }
    sim_default_params(&g_params, edge ? MODE_EDGE : MODE_CORNER);
    if (!simdev_plant_params_json((const char *)g_buf, plant_len, &g_params, g_err, sizeof g_err)) return -1;
    if (id_len >= sizeof g_id) id_len = sizeof g_id - 1;
    au_memcpy(g_id, g_buf + id_off, id_len);
    g_id[id_len] = 0;
    simdev_init(&g_sim, &g_params, &c, g_id, "wasm32");
    simdev_set_output(&g_sim, c_out, 0);
    simdev_set_log(&g_sim, c_log, 0);
    return 0;
}
EXPORT(sd_release_build) void sd_release_build(int on) { g_sim.board.actuation_build = !on; g_sim.board.commissioning_build = !on; }
EXPORT(sd_advance) void sd_advance(uint32_t us) { simdev_advance(&g_sim, us); }
EXPORT(sd_input) void sd_input(int link, size_t n) { simdev_input(&g_sim, link, g_buf, n); }
EXPORT(sd_link_up) void sd_link_up(int link) { simdev_link_up(&g_sim, link); }
EXPORT(sd_link_down) void sd_link_down(int link) { simdev_link_down(&g_sim, link); }
EXPORT(sd_set_arm) void sd_set_arm(int on) { simdev_set_arm(&g_sim, on != 0); }
EXPORT(sd_set_estop) void sd_set_estop(int on) { simdev_set_estop(&g_sim, on != 0); }
EXPORT(sd_set_commission) void sd_set_commission(int on) { simdev_set_commission(&g_sim, on != 0); }
EXPORT(sd_push) void sd_push(double tx, double ty, double tz, double s) { double t[3] = {tx, ty, tz}; simdev_push(&g_sim, t, s); }
EXPORT(sd_hold) void sd_hold(void) { simdev_hold(&g_sim, 0); }
EXPORT(sd_release) void sd_release(void) { simdev_release(&g_sim); }
EXPORT(sd_pose) void sd_pose(double w, double x, double y, double z) { double q[4] = {w, x, y, z}; simdev_pose(&g_sim, q); }
EXPORT(sd_posed) int sd_posed(void) { return g_sim.pose_active ? 1 : 0; }
EXPORT(sd_spin) void sd_spin(int wheel, double rads) { simdev_spin_wheel(&g_sim, wheel, rads); }
/* the MODEL's true state (for the side-by-side view of truth vs the device's estimate; never sent as telemetry) */
EXPORT(sd_true_q) double sd_true_q(int i) { return i >= 0 && i < 4 ? g_sim.q[i] : 0; }
EXPORT(sd_true_ww) double sd_true_ww(int i) { return i >= 0 && i < 3 ? g_sim.ww[i] : 0; }
EXPORT(sd_tilt) double sd_tilt(void) { return simdev_tilt_from_balance(&g_sim); }
EXPORT(sd_held) int sd_held(void) { return g_sim.held; }
EXPORT(sd_caught) int sd_caught(void) { return g_sim.caught; }
EXPORT(sd_time_us) double sd_time_us(void) { return (double)g_sim.t_us; }
EXPORT(sd_state) int sd_state(void) { return (int)g_sim.dev.state; }
EXPORT(sd_in_bootloader) int sd_in_bootloader(void) { return g_sim.in_bootloader; }
EXPORT(sd_motor_power) int sd_motor_power(void) { return g_sim.motor_power; }
/* the synthetic device's storage, so a page can keep the pairing state between visits */
EXPORT(sd_nvs) uint8_t *sd_nvs(void) { return (uint8_t *)g_sim.nvs; }
EXPORT(sd_nvs_size) size_t sd_nvs_size(void) { return sizeof g_sim.nvs; }

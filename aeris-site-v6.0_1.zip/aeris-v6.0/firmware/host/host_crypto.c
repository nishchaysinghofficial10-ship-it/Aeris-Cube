/* AERIS host build — the synthetic device's cryptography from OpenSSL (libcrypto 3): SHA-256, an ECDSA P-256 key pair
 * (optionally kept in a PEM file so a simulated device keeps its identity across runs), raw r || s signatures and
 * random bytes. The core implements no cryptography itself. */
#include "host_crypto.h"

#include <stdio.h>
#include <string.h>
#include <openssl/bn.h>
#include <openssl/core_names.h>
#include <openssl/ec.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>

static int hc_sha256(void *ctx, const uint8_t *d, size_t n, uint8_t out[32]) {
    unsigned int len = 32;
    (void)ctx;
    return EVP_Digest(d, n, out, &len, EVP_sha256(), NULL) == 1 && len == 32 ? 0 : -1;
}

static int hc_random(void *ctx, uint8_t *b, size_t n) {
    host_crypto_t *h = (host_crypto_t *)ctx;
    size_t i;
    if (h->deterministic) {
        for (i = 0; i < n; i++) {
            uint64_t z = (h->det_state += 0x9E3779B97F4A7C15ull);
            z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
            z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
            b[i] = (uint8_t)(z ^ (z >> 31));
        }
        return 0;
    }
    return RAND_bytes(b, (int)n) == 1 ? 0 : -1;
}

static int save_key(host_crypto_t *h) {
    FILE *f;
    if (!h->key_path[0] || !h->key) return 0;
    f = fopen(h->key_path, "wb");
    if (!f) return -1;
    if (PEM_write_PrivateKey(f, (EVP_PKEY *)h->key, NULL, NULL, 0, NULL, NULL) != 1) { fclose(f); return -1; }
    fclose(f);
    return 0;
}

static int load_key(host_crypto_t *h) {
    FILE *f;
    if (!h->key_path[0]) return -1;
    f = fopen(h->key_path, "rb");
    if (!f) return -1;
    h->key = PEM_read_PrivateKey(f, NULL, NULL, NULL);
    fclose(f);
    return h->key ? 0 : -1;
}

static int hc_key_public(void *ctx, uint8_t pub[65], bool create) {
    host_crypto_t *h = (host_crypto_t *)ctx;
    size_t len = 0;
    if (!h->key && load_key(h) != 0) {
        if (!create) return -1;
        h->key = EVP_EC_gen("P-256");
        if (!h->key) return -1;
        if (save_key(h) != 0) return -1;
    }
    if (EVP_PKEY_get_octet_string_param((EVP_PKEY *)h->key, OSSL_PKEY_PARAM_ENCODED_PUBLIC_KEY, pub, 65, &len) != 1 || len != 65 || pub[0] != 0x04) return -1;
    return 0;
}

static int hc_sign(void *ctx, const uint8_t *m, size_t n, uint8_t sig[64]) {
    host_crypto_t *h = (host_crypto_t *)ctx;
    EVP_MD_CTX *md;
    unsigned char der[80];
    const unsigned char *p = der;
    size_t dlen = sizeof der;
    ECDSA_SIG *es;
    const BIGNUM *r, *s;
    int ok;
    if (!h->key && load_key(h) != 0) return -1;
    md = EVP_MD_CTX_new();
    if (!md) return -1;
    ok = EVP_DigestSignInit(md, NULL, EVP_sha256(), NULL, (EVP_PKEY *)h->key) == 1 && EVP_DigestSign(md, der, &dlen, m, n) == 1;
    EVP_MD_CTX_free(md);
    if (!ok) return -1;
    es = d2i_ECDSA_SIG(NULL, &p, (long)dlen);
    if (!es) return -1;
    ECDSA_SIG_get0(es, &r, &s);
    ok = BN_bn2binpad(r, sig, 32) == 32 && BN_bn2binpad(s, sig + 32, 32) == 32;
    ECDSA_SIG_free(es);
    return ok ? 0 : -1;
}

static int hc_key_reset(void *ctx) {
    host_crypto_t *h = (host_crypto_t *)ctx;
    if (h->key) { EVP_PKEY_free((EVP_PKEY *)h->key); h->key = NULL; }
    if (h->key_path[0]) remove(h->key_path);
    return 0;
}

void host_crypto_init(host_crypto_t *h, const char *key_path, uint64_t deterministic_seed) {
    memset(h, 0, sizeof *h);
    if (key_path) snprintf(h->key_path, sizeof h->key_path, "%s", key_path);
    h->deterministic = deterministic_seed != 0;
    h->det_state = deterministic_seed;
}

void host_crypto_bind(host_crypto_t *h, sim_crypto_t *c) {
    c->ctx = h;
    c->sha256 = hc_sha256;
    c->random = hc_random;
    c->key_public = hc_key_public;
    c->sign = hc_sign;
    c->key_reset = hc_key_reset;
}

void host_crypto_free(host_crypto_t *h) { if (h->key) EVP_PKEY_free((EVP_PKEY *)h->key); h->key = NULL; }

int host_verify(const uint8_t pub[65], const uint8_t *m, size_t n, const uint8_t sig[64]) {
    /* verification of a raw r || s signature against an uncompressed P-256 point (used by the tests) */
    EVP_PKEY *pk = NULL;
    EVP_PKEY_CTX *pc = EVP_PKEY_CTX_new_from_name(NULL, "EC", NULL);
    OSSL_PARAM params[3];
    EVP_MD_CTX *md;
    ECDSA_SIG *es;
    unsigned char *der = NULL;
    int dlen, ok = 0;
    char group[] = "P-256";
    if (!pc) return 0;
    params[0] = OSSL_PARAM_construct_utf8_string(OSSL_PKEY_PARAM_GROUP_NAME, group, 0);
    params[1] = OSSL_PARAM_construct_octet_string(OSSL_PKEY_PARAM_PUB_KEY, (void *)pub, 65);
    params[2] = OSSL_PARAM_construct_end();
    if (EVP_PKEY_fromdata_init(pc) != 1 || EVP_PKEY_fromdata(pc, &pk, EVP_PKEY_PUBLIC_KEY, params) != 1) { EVP_PKEY_CTX_free(pc); return 0; }
    EVP_PKEY_CTX_free(pc);
    es = ECDSA_SIG_new();
    ECDSA_SIG_set0(es, BN_bin2bn(sig, 32, NULL), BN_bin2bn(sig + 32, 32, NULL));
    dlen = i2d_ECDSA_SIG(es, &der);
    ECDSA_SIG_free(es);
    md = EVP_MD_CTX_new();
    if (md && dlen > 0 && EVP_DigestVerifyInit(md, NULL, EVP_sha256(), NULL, pk) == 1) ok = EVP_DigestVerify(md, der, (size_t)dlen, m, n) == 1;
    EVP_MD_CTX_free(md);
    OPENSSL_free(der);
    EVP_PKEY_free(pk);
    return ok;
}

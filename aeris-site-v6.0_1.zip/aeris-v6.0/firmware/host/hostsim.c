/* aeris-hostsim — the synthetic device as a process: the firmware core and the device models (firmware/sim), in real
 * time, with its local link on a pseudo-terminal (a serial port for the companion and for pyserial), on a TCP port or
 * on stdin/stdout, an optional second listening port for the network link (a bridge connects it to the gateway), and a
 * control port for the "operator" (ARM button, local stop, dead-man control, pushes, holding the cube).
 *
 * Everything it produces is SYNTHETIC (telemetry declares device.kind "emulator", synthetic: true).
 *
 *   aeris-hostsim --plant firmware/tests/fixtures/plant_edge.json --pty [--net-tcp 7101] [--ctl-tcp 7102]
 *                 [--device-id synthetic-0001] [--key-file key.pem] [--nvs-file nvs.bin] [--speed 1.0] [--release]
 * Control port commands (one per line): arm-press | arm-down | arm-up | estop-on | estop-off | deadman-on | deadman-off |
 *   push tx ty tz seconds | hold | release | spin wheel rads | pose w x y z | face +x|-x|+y|-y|+z|-z | state | quit
 *   (pose/face: the cube rests still in that attitude for a calibration measurement; hold or release ends it) */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <poll.h>
#include <pty.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#include "aeris_sim.h"
#include "host_crypto.h"

static simdev_t *S;
static int fd_usb = -1, fd_usb_listen = -1, fd_net = -1, fd_net_listen = -1, fd_ctl = -1, fd_ctl_listen = -1;
static const char *nvs_file;
static volatile int g_stop;

static uint64_t mono_us(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (uint64_t)t.tv_sec * 1000000u + (uint64_t)t.tv_nsec / 1000u; }

static int listen_tcp(int port) {
    int s = socket(AF_INET, SOCK_STREAM, 0), one = 1;
    struct sockaddr_in a;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);          /* local only */
    a.sin_port = htons((uint16_t)port);
    if (bind(s, (struct sockaddr *)&a, sizeof a) != 0 || listen(s, 1) != 0) { perror("listen"); exit(2); }
    return s;
}

static void write_all(int fd, const uint8_t *d, size_t n) {
    while (n && fd >= 0) {
        ssize_t k = write(fd, d, n);
        if (k < 0) { if (errno == EINTR) continue; return; }      /* a full or closed transport drops (never blocks) */
        d += k; n -= (size_t)k;
    }
}

static void on_out(void *ctx, int link, const uint8_t *data, size_t n) {
    (void)ctx;
    if (link == AERIS_LINK_USB) write_all(fd_usb, data, n);
    else if (link == AERIS_LINK_NET) write_all(fd_net, data, n);
}

static void on_log(void *ctx, int level, const char *msg) { (void)ctx; fprintf(stderr, "[synthetic device %d] %s\n", level, msg); }

static void save_nvs(void) {
    FILE *f;
    if (!nvs_file) return;
    f = fopen(nvs_file, "wb");
    if (!f) return;
    fwrite(S->nvs, sizeof S->nvs, 1, f);
    fclose(f);
}

static void ctl_line(char *l) {
    double a, b, c, d;
    int i;
    char out[256];
    if (!strncmp(l, "arm-press", 9)) { simdev_set_arm(S, true); simdev_advance(S, 60000); simdev_set_arm(S, false); }
    else if (!strncmp(l, "arm-down", 8)) simdev_set_arm(S, true);
    else if (!strncmp(l, "arm-up", 6)) simdev_set_arm(S, false);
    else if (!strncmp(l, "estop-on", 8)) simdev_set_estop(S, true);
    else if (!strncmp(l, "estop-off", 9)) simdev_set_estop(S, false);
    else if (!strncmp(l, "deadman-on", 10)) simdev_set_commission(S, true);
    else if (!strncmp(l, "deadman-off", 11)) simdev_set_commission(S, false);
    else if (sscanf(l, "push %lf %lf %lf %lf", &a, &b, &c, &d) == 4) { double t[3] = {a, b, c}; simdev_push(S, t, d); }
    else if (sscanf(l, "pose %lf %lf %lf %lf", &a, &b, &c, &d) == 4) { double q[4] = {a, b, c, d}; simdev_pose(S, q); }
    else if (!strncmp(l, "face ", 5)) { if (!simdev_face_pose(S, l + 5)) { static const char e[] = "error face: +x -x +y -y +z -z\n"; if (fd_ctl >= 0) write_all(fd_ctl, (const uint8_t *)e, sizeof e - 1); return; } }
    else if (!strncmp(l, "hold", 4)) simdev_hold(S, NULL);
    else if (!strncmp(l, "release", 7)) simdev_release(S);
    else if (sscanf(l, "spin %d %lf", &i, &a) == 2) simdev_spin_wheel(S, i, a);
    else if (!strncmp(l, "quit", 4)) g_stop = 1;
    else if (!strncmp(l, "state", 5)) { }
    else { if (fd_ctl >= 0) write_all(fd_ctl, (const uint8_t *)"error unknown command\n", 22); return; }
    snprintf(out, sizeof out, "ok state=%s tilt_deg=%.4f held=%d caught=%d t=%.3f\n", aeris_state_name(S->dev.state), simdev_tilt_from_balance(S) * 57.29577951308232,
             S->held, S->caught, (double)S->t_us * 1e-6);
    if (fd_ctl >= 0) write_all(fd_ctl, (const uint8_t *)out, strlen(out));
    save_nvs();
}

static void on_signal(int s) { (void)s; g_stop = 1; }

int main(int argc, char **argv) {
    const char *plant = NULL, *device_id = "synthetic-0001", *key_file = NULL;
    int use_pty = 0, use_stdio = 0, usb_tcp = 0, net_tcp = 0, ctl_tcp = 0, release = 0, i;
    double speed = 1.0;
    sim_params_t p;
    host_crypto_t hc;
    sim_crypto_t sc;
    char *json = NULL, ctlbuf[512];
    size_t ctllen = 0;
    uint64_t t0, sim0;
    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--plant") && i + 1 < argc) plant = argv[++i];
        else if (!strcmp(argv[i], "--pty")) use_pty = 1;
        else if (!strcmp(argv[i], "--stdio")) use_stdio = 1;
        else if (!strcmp(argv[i], "--usb-tcp") && i + 1 < argc) usb_tcp = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--net-tcp") && i + 1 < argc) net_tcp = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--ctl-tcp") && i + 1 < argc) ctl_tcp = atoi(argv[++i]);
        else if (!strcmp(argv[i], "--device-id") && i + 1 < argc) device_id = argv[++i];
        else if (!strcmp(argv[i], "--key-file") && i + 1 < argc) key_file = argv[++i];
        else if (!strcmp(argv[i], "--nvs-file") && i + 1 < argc) nvs_file = argv[++i];
        else if (!strcmp(argv[i], "--speed") && i + 1 < argc) speed = atof(argv[++i]);
        else if (!strcmp(argv[i], "--release")) release = 1;
        else { fprintf(stderr, "unknown argument %s\n", argv[i]); return 2; }
    }
    sim_default_params(&p, MODE_CORNER);
    if (plant) {
        FILE *f = fopen(plant, "rb");
        long n;
        char err[200];
        if (!f) { perror(plant); return 2; }
        fseek(f, 0, SEEK_END); n = ftell(f); fseek(f, 0, SEEK_SET);
        json = malloc((size_t)n + 1);
        if (fread(json, 1, (size_t)n, f) != (size_t)n) { fclose(f); return 2; }
        fclose(f);
        json[n] = 0;
        sim_default_params(&p, strstr(json, "\"mode\": \"edge\"") || strstr(json, "\"mode\":\"edge\"") ? MODE_EDGE : MODE_CORNER);
        if (!simdev_plant_params_json(json, (size_t)n, &p, err, sizeof err)) { fprintf(stderr, "%s\n", err); return 2; }
    }
    host_crypto_init(&hc, key_file, 0);
    host_crypto_bind(&hc, &sc);
    S = calloc(1, sizeof *S);
    simdev_init(S, &p, &sc, device_id, "host");
    if (release) { S->board.actuation_build = false; S->board.commissioning_build = false; }
    if (nvs_file) { FILE *f = fopen(nvs_file, "rb"); if (f) { if (fread(S->nvs, sizeof S->nvs, 1, f) != 1) memset(S->nvs, 0, sizeof S->nvs); fclose(f); } }
    simdev_set_output(S, on_out, NULL);
    simdev_set_log(S, on_log, NULL);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGPIPE, SIG_IGN);
    if (use_pty) {
        int master, slave;
        struct termios t;
        char name[256];
        if (openpty(&master, &slave, name, NULL, NULL) != 0) { perror("openpty"); return 2; }
        tcgetattr(slave, &t);
        cfmakeraw(&t);
        tcsetattr(slave, TCSANOW, &t);
        fd_usb = master;
        fcntl(fd_usb, F_SETFL, O_NONBLOCK);
        printf("PTY %s\n", name);
        fflush(stdout);
        simdev_link_up(S, AERIS_LINK_USB);
        /* keep the slave open so the link stays up while hosts open and close the port */
    } else if (use_stdio) {
        fd_usb = 1;
        simdev_link_up(S, AERIS_LINK_USB);
    } else if (usb_tcp) fd_usb_listen = listen_tcp(usb_tcp);
    if (net_tcp) fd_net_listen = listen_tcp(net_tcp);
    if (ctl_tcp) fd_ctl_listen = listen_tcp(ctl_tcp);
    printf("READY device=%s mode=%s actuation=%s\n", device_id, p.mode == MODE_EDGE ? "edge" : "corner", S->board.actuation_build ? "synthetic-motors" : "disabled");
    fflush(stdout);
    t0 = mono_us();
    sim0 = S->t_us;
    while (!g_stop) {
        struct pollfd pf[8];
        int np = 0, k;
        uint8_t buf[4096];
        uint64_t target;
        int i_usb = -1, i_usbl = -1, i_net = -1, i_netl = -1, i_ctl = -1, i_ctll = -1, i_stdin = -1;
        if (fd_usb >= 0 && !use_stdio) { i_usb = np; pf[np].fd = fd_usb; pf[np++].events = POLLIN; }
        if (use_stdio) { i_stdin = np; pf[np].fd = 0; pf[np++].events = POLLIN; }
        if (fd_usb_listen >= 0 && fd_usb < 0) { i_usbl = np; pf[np].fd = fd_usb_listen; pf[np++].events = POLLIN; }
        if (fd_net >= 0) { i_net = np; pf[np].fd = fd_net; pf[np++].events = POLLIN; }
        if (fd_net_listen >= 0 && fd_net < 0) { i_netl = np; pf[np].fd = fd_net_listen; pf[np++].events = POLLIN; }
        if (fd_ctl >= 0) { i_ctl = np; pf[np].fd = fd_ctl; pf[np++].events = POLLIN; }
        if (fd_ctl_listen >= 0 && fd_ctl < 0) { i_ctll = np; pf[np].fd = fd_ctl_listen; pf[np++].events = POLLIN; }
        poll(pf, (nfds_t)np, 1);
        if (i_usb >= 0 && (pf[i_usb].revents & (POLLIN | POLLHUP))) {
            k = (int)read(fd_usb, buf, sizeof buf);
            if (k > 0) simdev_input(S, AERIS_LINK_USB, buf, (size_t)k);
            else if (!use_pty && k == 0) { close(fd_usb); fd_usb = -1; simdev_link_down(S, AERIS_LINK_USB); }
        }
        if (i_stdin >= 0 && (pf[i_stdin].revents & POLLIN)) { k = (int)read(0, buf, sizeof buf); if (k > 0) simdev_input(S, AERIS_LINK_USB, buf, (size_t)k); else g_stop = 1; }
        if (i_usbl >= 0 && (pf[i_usbl].revents & POLLIN)) { fd_usb = accept(fd_usb_listen, NULL, NULL); simdev_link_up(S, AERIS_LINK_USB); }
        if (i_net >= 0 && (pf[i_net].revents & (POLLIN | POLLHUP))) {
            k = (int)read(fd_net, buf, sizeof buf);
            if (k > 0) simdev_input(S, AERIS_LINK_NET, buf, (size_t)k);
            else { close(fd_net); fd_net = -1; simdev_link_down(S, AERIS_LINK_NET); }
        }
        if (i_netl >= 0 && (pf[i_netl].revents & POLLIN)) { fd_net = accept(fd_net_listen, NULL, NULL); simdev_link_up(S, AERIS_LINK_NET); }
        if (i_ctll >= 0 && (pf[i_ctll].revents & POLLIN)) fd_ctl = accept(fd_ctl_listen, NULL, NULL);
        if (i_ctl >= 0 && (pf[i_ctl].revents & (POLLIN | POLLHUP))) {
            k = (int)read(fd_ctl, buf, sizeof buf);
            if (k <= 0) { close(fd_ctl); fd_ctl = -1; }
            else for (i = 0; i < k; i++) {
                if (buf[i] == '\n') { ctlbuf[ctllen] = 0; ctl_line(ctlbuf); ctllen = 0; }
                else if (ctllen < sizeof ctlbuf - 1) ctlbuf[ctllen++] = (char)buf[i];
            }
        }
        target = sim0 + (uint64_t)((double)(mono_us() - t0) * speed);
        if (target > S->t_us) {
            uint64_t step = target - S->t_us;
            if (step > 200000) step = 200000;          /* never jump far (the process was stopped) */
            simdev_advance(S, step);
        }
    }
    save_nvs();
    host_crypto_free(&hc);
    return 0;
}

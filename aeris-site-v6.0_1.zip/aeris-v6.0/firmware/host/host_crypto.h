#ifndef AERIS_HOST_CRYPTO_H
#define AERIS_HOST_CRYPTO_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "aeris_sim.h"

typedef struct {
    void *key;               /* EVP_PKEY */
    char key_path[512];      /* empty: the key lives in memory only */
    bool deterministic;      /* tests: reproducible boot ids (keys always come from OpenSSL's generator) */
    uint64_t det_state;
} host_crypto_t;

void host_crypto_init(host_crypto_t *h, const char *key_path, uint64_t deterministic_seed);
void host_crypto_bind(host_crypto_t *h, sim_crypto_t *c);
void host_crypto_free(host_crypto_t *h);
int host_verify(const uint8_t pub[65], const uint8_t *m, size_t n, const uint8_t sig[64]);   /* 1 valid */

#endif

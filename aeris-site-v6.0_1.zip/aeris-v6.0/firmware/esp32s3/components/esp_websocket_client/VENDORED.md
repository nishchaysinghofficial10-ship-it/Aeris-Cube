# Vendored component: esp_websocket_client 1.8.0

Copied unmodified from https://github.com/espressif/esp-protocols at tag `websocket-v1.8.0`
(commit 70bf122fc8bc74622dcf7e15233b5b2af9088df5, 2026-07-22), directory `components/esp_websocket_client`.
License: Apache-2.0 (see LICENSE). It is vendored because the build environment used for AERIS v6.0 could not reach
the ESP Component Registry; with registry access the same version can be declared in `main/idf_component.yml` instead.

/* AERIS firmware for the ESP32-S3: one control task owns the firmware core.
 *
 * A general-purpose timer interrupts at the control period (aeris_control_period_us: 2 ms at 500 Hz) and wakes the
 * control task (core 1, high priority). Each wake-up: debounce the local inputs, one aeris_control_step (IMU →
 * estimator → controller → allocation → drivers, with every protection check), then drain the links (USB-Serial-JTAG,
 * network stream buffer) and run aeris_service. The stabilising loop never waits for a host or the network.
 * Wi-Fi, TLS and the WebSocket client run on core 0. */
#include <string.h>
#include "aeris/device.h"
#include "board.h"
#include "driver/gptimer.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "net.h"

static const char *TAG = "aeris";
static aeris_dev_t s_dev;
static TaskHandle_t s_ctrl;
static gptimer_handle_t s_timer;
static uint32_t s_period_us;

static bool IRAM_ATTR on_tick(gptimer_handle_t t, const gptimer_alarm_event_data_t *e, void *ctx) {
    BaseType_t woke = pdFALSE;
    vTaskNotifyGiveFromISR(s_ctrl, &woke);
    return woke == pdTRUE;
}

static void set_period(uint32_t us) {
    gptimer_alarm_config_t a = {.alarm_count = us, .reload_count = 0, .flags.auto_reload_on_alarm = true};
    s_period_us = us;
    gptimer_set_alarm_action(s_timer, &a);
}

static void control_task(void *arg) {
    static uint8_t buf[1024];
    bool usb_up = false;
    uint32_t net_gen = 0;
    bool net_up = false;
    gptimer_config_t tc = {.clk_src = GPTIMER_CLK_SRC_DEFAULT, .direction = GPTIMER_COUNT_UP, .resolution_hz = 1000000};
    gptimer_event_callbacks_t cbs = {.on_alarm = on_tick};
    s_ctrl = xTaskGetCurrentTaskHandle();               /* before the timer can fire */
    ESP_ERROR_CHECK(gptimer_new_timer(&tc, &s_timer));
    ESP_ERROR_CHECK(gptimer_register_event_callbacks(s_timer, &cbs, NULL));
    ESP_ERROR_CHECK(gptimer_enable(s_timer));
    set_period(aeris_control_period_us(&s_dev));
    ESP_ERROR_CHECK(gptimer_start(s_timer));
    for (;;) {
        size_t n = 0;
        uint32_t gen;
        bool conn;
        int k;
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        board_step((uint64_t)esp_timer_get_time());
        aeris_control_step(&s_dev);
        /* USB link */
        if (board_usb_connected() != usb_up) {
            usb_up = !usb_up;
            if (usb_up) aeris_link_up(&s_dev, AERIS_LINK_USB); else aeris_link_down(&s_dev, AERIS_LINK_USB);
        }
        while ((k = board_usb_read(buf, sizeof buf)) > 0) aeris_link_input(&s_dev, AERIS_LINK_USB, buf, (size_t)k);
        /* network link */
        if (net_poll(buf, sizeof buf, &n, &gen, &conn)) {
            if (gen != net_gen) {
                net_gen = gen;
                if (net_up) { aeris_link_down(&s_dev, AERIS_LINK_NET); net_up = false; }
                if (conn) { aeris_link_up(&s_dev, AERIS_LINK_NET); net_up = true; }
            }
            if (n) aeris_link_input(&s_dev, AERIS_LINK_NET, buf, n);
        }
        aeris_service(&s_dev);
        if (aeris_control_period_us(&s_dev) != s_period_us) set_period(aeris_control_period_us(&s_dev));
    }
}

#if CONFIG_AERIS_BOOT_CRYPTO_SELFTEST
#include "driver/uart.h"
static void emit_line(const char *l) { uart_write_bytes(UART_NUM_0, l, strlen(l)); uart_write_bytes(UART_NUM_0, "\n", 1); }
#endif

void app_main(void) {
    char id[48];
    board_init();
#if CONFIG_AERIS_BOOT_CRYPTO_SELFTEST
    board_crypto_selftest(emit_line);
#endif
    board_device_id(id, sizeof id);
    aeris_init(&s_dev, board_hal(), board_info(), id);
    ESP_LOGI(TAG, "%s %s (%s) on %s, device %s, actuation %s", AERIS_FW_NAME, AERIS_FW_VERSION, AERIS_BUILD_ID, board_info()->board_id, id,
             board_info()->actuation_build ? "COMPILED IN (experimental build)" : "disabled (release build)");
    net_start();
    xTaskCreatePinnedToCore(control_task, "aeris_ctrl", 12288, NULL, configMAX_PRIORITIES - 2, NULL, 1);
}

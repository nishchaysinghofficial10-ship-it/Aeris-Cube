/* AERIS ESP32-S3 board layer: the HAL (firmware/core/include/aeris/hal.h) on ESP-IDF v6.0.3 drivers. */
#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "aeris/hal.h"

void board_init(void);
const aeris_hal_t *board_hal(void);
const aeris_board_t *board_info(void);
void board_device_id(char *out, size_t cap);
/* called by the control task every step: debounced inputs and the LED pattern */
void board_step(uint64_t now_us);
/* the USB-Serial-JTAG link: bytes received since the last call (non-blocking), connection state */
int board_usb_read(uint8_t *buf, size_t cap);
bool board_usb_connected(void);
/* persistent settings (also used by net.c) */
bool board_nvs_get_str(const char *key, char *out, size_t cap);

#include "sdkconfig.h"
#if CONFIG_AERIS_BOOT_CRYPTO_SELFTEST
void board_crypto_selftest(void (*emit)(const char *line));
#endif

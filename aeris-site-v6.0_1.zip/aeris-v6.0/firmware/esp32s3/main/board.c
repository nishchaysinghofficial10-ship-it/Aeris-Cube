/* AERIS ESP32-S3 board layer (ESP-IDF v6.0.3).
 *
 *   IMU        LSM6DSOX on I2C (driver/i2c_master.h), SDA/SCL from Kconfig, 400 kHz by default
 *   drivers    CAN through the TWAI controller (esp_twai.h, esp_twai_onchip.h) and an EXTERNAL transceiver (the ESP32-S3
 *              has no CAN PHY); received frames are queued from the RX callback; transmitted frames live in a ring of
 *              buffers that outlives the driver's queue (the TWAI driver passes frames by pointer)
 *   inputs     ARM button and dead-man control (active low, pull-ups), stop-chain sense (low = chain closed; high or a
 *              broken wire = stop asserted: fail-safe), all debounced over 5 control steps
 *   outputs    driver power enable (low after reset and in every state except the powered ones), status LED
 *   link       USB-Serial-JTAG (driver/usb_serial_jtag.h); the network link is in net.c
 *   storage    NVS namespace "aeris"
 *   crypto     PSA Crypto (mbedTLS 4 in ESP-IDF v6): SHA-256, ECDSA P-256 (SECP256R1) with SHA-256, random numbers.
 *              The pairing key is generated on the device and kept in NVS (exported private scalar). Hardening for a
 *              product (flash encryption + NVS encryption) is listed in hardware/COMMISSIONING.md.
 * Nothing here has been run on a physical board by the AERIS project yet: it compiles against ESP-IDF v6.0.3. */
#include "board.h"

#include <string.h>
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "driver/uart.h"
#include "driver/usb_serial_jtag.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "esp_twai.h"
#include "esp_twai_onchip.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "psa/crypto.h"
#include "sdkconfig.h"
#include "soc/rtc_cntl_reg.h"
#include "soc/soc.h"

static const char *TAG = "aeris-board";

#ifndef CONFIG_AERIS_ACTUATION_ENABLED
#define CONFIG_AERIS_ACTUATION_ENABLED 0
#endif
#ifndef CONFIG_AERIS_COMMISSIONING
#define CONFIG_AERIS_COMMISSIONING 0
#endif

static const aeris_board_t BOARD = {
    .board_id = "esp32-s3-devkitc-1",
    .chip = "ESP32-S3",
    .device_kind = "physical",
    .synthetic = false,
    .actuation_build = CONFIG_AERIS_ACTUATION_ENABLED,
    .commissioning_build = CONFIG_AERIS_COMMISSIONING,
    .hard_max_current_A = CONFIG_AERIS_HARD_MAX_CURRENT_MA / 1000.0f,
    .hard_max_torque_Nm = CONFIG_AERIS_HARD_MAX_TORQUE_MNM / 1000.0f,
    .hard_max_speed_rpm = (float)CONFIG_AERIS_HARD_MAX_SPEED_RPM,
    .commissioning_max_torque_Nm = CONFIG_AERIS_COMMISSION_MAX_TORQUE_MNM / 1000.0f,
    .commissioning_max_speed_rpm = (float)CONFIG_AERIS_COMMISSION_MAX_SPEED_RPM,
    .commissioning_max_ms = CONFIG_AERIS_COMMISSION_MAX_MS,
    .max_control_hz = 1000,
    .imu_drivers = "lsm6dsox",
    .motor_drivers = "odrive-cansimple",
};

/* ------------------------------------------------------------------------------------------------ I2C */
static i2c_master_bus_handle_t s_bus;
static i2c_master_dev_handle_t s_i2c[2];        /* 0x6A, 0x6B */

static i2c_master_dev_handle_t i2c_dev(uint8_t addr) { return addr == 0x6A ? s_i2c[0] : addr == 0x6B ? s_i2c[1] : NULL; }

static int hal_i2c_read(void *ctx, uint8_t addr, uint8_t reg, uint8_t *buf, size_t n) {
    i2c_master_dev_handle_t d = i2c_dev(addr);
    if (!d) return -1;
    return i2c_master_transmit_receive(d, &reg, 1, buf, n, 5) == ESP_OK ? 0 : -1;
}

static int hal_i2c_write(void *ctx, uint8_t addr, uint8_t reg, const uint8_t *buf, size_t n) {
    uint8_t b[17];
    i2c_master_dev_handle_t d = i2c_dev(addr);
    if (!d || n > 16) return -1;
    b[0] = reg;
    memcpy(b + 1, buf, n);
    return i2c_master_transmit(d, b, n + 1, 5) == ESP_OK ? 0 : -1;
}

/* ------------------------------------------------------------------------------------------------ CAN (TWAI) */
typedef struct { uint32_t id; uint8_t len; uint8_t rtr; uint8_t data[8]; } can_rec_t;
#define TX_RING 48                                      /* > tx_queue_depth + 1: a slot is reused only after it was sent */
static twai_node_handle_t s_twai;
static QueueHandle_t s_can_rx;
static twai_frame_t s_tx[TX_RING];
static uint8_t s_tx_buf[TX_RING][8];
static unsigned s_tx_next;
static volatile uint32_t s_can_rx_dropped;

static bool IRAM_ATTR on_can_rx(twai_node_handle_t h, const twai_rx_done_event_data_t *e, void *ctx) {
    uint8_t buf[8];
    can_rec_t r;
    BaseType_t woke = pdFALSE;
    twai_frame_t f = {.buffer = buf, .buffer_len = sizeof buf};
    if (twai_node_receive_from_isr(h, &f) != ESP_OK) return false;
    r.id = f.header.id;
    r.len = (uint8_t)(f.header.dlc > 8 ? 8 : f.header.dlc);
    r.rtr = (uint8_t)f.header.rtr;
    memcpy(r.data, buf, 8);
    if (xQueueSendFromISR(s_can_rx, &r, &woke) != pdTRUE) s_can_rx_dropped++;
    return woke == pdTRUE;
}

static int hal_can_send(void *ctx, uint32_t id, const uint8_t *data, uint8_t len, bool rtr) {
    twai_frame_t *f;
    unsigned k;
    if (!s_twai) return -1;
    k = s_tx_next++ % TX_RING;
    f = &s_tx[k];
    memset(f, 0, sizeof *f);
    if (data && len) memcpy(s_tx_buf[k], data, len > 8 ? 8 : len);
    f->header.id = id;
    f->header.dlc = len;
    f->header.rtr = rtr;
    f->buffer = s_tx_buf[k];
    f->buffer_len = rtr ? 0 : len;
    return twai_node_transmit(s_twai, f, 0) == ESP_OK ? 0 : -1;    /* never blocks the control loop */
}

static int hal_can_recv(void *ctx, uint32_t *id, uint8_t *data, uint8_t *len, bool *rtr) {
    can_rec_t r;
    if (!s_can_rx || xQueueReceive(s_can_rx, &r, 0) != pdTRUE) return 0;
    *id = r.id; *len = r.len; *rtr = r.rtr != 0;
    memcpy(data, r.data, 8);
    return 1;
}

/* ------------------------------------------------------------------------------------------------ inputs and outputs */
typedef struct { int gpio; bool active_low; uint8_t count; bool state; } debounce_t;
static debounce_t s_arm = {CONFIG_AERIS_ARM_GPIO, true, 0, false};
static debounce_t s_dead = {CONFIG_AERIS_DEADMAN_GPIO, true, 0, false};
static debounce_t s_stop = {CONFIG_AERIS_STOP_SENSE_GPIO, false, 0, true};      /* high = chain open = stop asserted */
static int s_led_pattern;
static bool s_drive_en;

static void debounce(debounce_t *d) {
    bool raw = gpio_get_level(d->gpio) != 0;
    bool active = d->active_low ? !raw : raw;
    if (active == d->state) { d->count = 0; return; }
    if (++d->count >= 5) { d->state = active; d->count = 0; }
}

void board_step(uint64_t now_us) {
    bool on;
    debounce(&s_arm);
    debounce(&s_dead);
    debounce(&s_stop);
    switch (s_led_pattern) {
    case 100: on = (now_us / 100000u) & 1u; break;                       /* identify: 5 Hz */
    case 4: on = (now_us / 125000u) & 1u; break;                         /* ARMED: fast blink */
    case 5: case 6: on = true; break;                                    /* BALANCING, STOPPING */
    case 7: on = (now_us / 500000u) & 1u; break;                         /* FAULT: slow blink */
    case 3: on = (now_us / 1000000u) % 4u == 0; break;                   /* READY: short flash */
    default: on = (now_us / 2000000u) % 10u == 0; break;                 /* alive */
    }
    gpio_set_level(CONFIG_AERIS_LED_GPIO, on);
}

static bool hal_arm(void *ctx) { return s_arm.state; }
static bool hal_stop(void *ctx) { return s_stop.state; }
static bool hal_commission(void *ctx) { return s_dead.state; }
static void hal_motor_power(void *ctx, bool on) {
#if !CONFIG_AERIS_ACTUATION_ENABLED
    on = false;                                     /* a release image never powers the drivers' output stage */
#endif
    s_drive_en = on;
    gpio_set_level(CONFIG_AERIS_DRIVE_EN_GPIO, on ? 1 : 0);
}
static void hal_led(void *ctx, int pattern) { s_led_pattern = pattern; }

/* ------------------------------------------------------------------------------------------------ USB-Serial-JTAG */
static int hal_link_write(void *ctx, int link, const uint8_t *data, size_t n);
#if CONFIG_AERIS_LINK_ON_UART0
/* emulator test images: the local link on UART0 (QEMU models UART0, not the ESP32-S3 USB-Serial-JTAG) */
int board_usb_read(uint8_t *buf, size_t cap) { int k = uart_read_bytes(UART_NUM_0, buf, cap, 0); return k > 0 ? k : 0; }
bool board_usb_connected(void) { return true; }
static int usb_write(const uint8_t *data, size_t n) {
    size_t room = 0;
    uart_get_tx_buffer_free_size(UART_NUM_0, &room);
    if (n > room) n = room;
    return n ? uart_write_bytes(UART_NUM_0, data, n) : 0;
}
#else
int board_usb_read(uint8_t *buf, size_t cap) { int k = usb_serial_jtag_read_bytes(buf, cap, 0); return k > 0 ? k : 0; }
bool board_usb_connected(void) { return usb_serial_jtag_is_connected(); }
static int usb_write(const uint8_t *data, size_t n) { int k = usb_serial_jtag_write_bytes(data, n, 0); return k > 0 ? k : 0; }
#endif
int net_link_write(const uint8_t *data, size_t n);         /* net.c */

static int hal_link_write(void *ctx, int link, const uint8_t *data, size_t n) {
    if (link == AERIS_LINK_USB) return usb_write(data, n);
    if (link == AERIS_LINK_NET) return net_link_write(data, n);
    return (int)n;
}

/* ------------------------------------------------------------------------------------------------ storage */
static nvs_handle_t s_nvs;

static int hal_nvs_get(void *ctx, const char *key, uint8_t *buf, size_t cap, size_t *len) {
    size_t n = cap;
    esp_err_t e = nvs_get_blob(s_nvs, key, buf, &n);
    if (e == ESP_ERR_NVS_NOT_FOUND) return 1;
    if (e != ESP_OK) return -1;
    *len = n;
    return 0;
}
static int hal_nvs_set(void *ctx, const char *key, const uint8_t *buf, size_t len) {
    if (nvs_set_blob(s_nvs, key, buf, len) != ESP_OK) return -1;
    return nvs_commit(s_nvs) == ESP_OK ? 0 : -1;
}
bool board_nvs_get_str(const char *key, char *out, size_t cap) {
    size_t n = cap - 1;
    if (nvs_get_blob(s_nvs, key, out, &n) != ESP_OK) return false;
    out[n] = 0;
    return n > 0;
}

/* ------------------------------------------------------------------------------------------------ cryptography (PSA) */
static psa_key_id_t s_key;
static bool s_key_loaded;

static int hal_random(void *ctx, uint8_t *b, size_t n) { return psa_generate_random(b, n) == PSA_SUCCESS ? 0 : -1; }
static int hal_sha256(void *ctx, const uint8_t *d, size_t n, uint8_t out[32]) {
    size_t len = 0;
    return psa_hash_compute(PSA_ALG_SHA_256, d, n, out, 32, &len) == PSA_SUCCESS && len == 32 ? 0 : -1;
}

static void key_attributes(psa_key_attributes_t *a) {
    *a = psa_key_attributes_init();
    psa_set_key_type(a, PSA_KEY_TYPE_ECC_KEY_PAIR(PSA_ECC_FAMILY_SECP_R1));
    psa_set_key_bits(a, 256);
    psa_set_key_usage_flags(a, PSA_KEY_USAGE_SIGN_MESSAGE | PSA_KEY_USAGE_SIGN_HASH | PSA_KEY_USAGE_EXPORT);
    psa_set_key_algorithm(a, PSA_ALG_ECDSA(PSA_ALG_SHA_256));
}

static bool load_key(void) {
    uint8_t priv[32];
    size_t n = sizeof priv;
    psa_key_attributes_t a;
    if (s_key_loaded) return true;
    if (nvs_get_blob(s_nvs, "devkey", priv, &n) != ESP_OK || n != 32) return false;
    key_attributes(&a);
    s_key_loaded = psa_import_key(&a, priv, 32, &s_key) == PSA_SUCCESS;
    memset(priv, 0, sizeof priv);
    return s_key_loaded;
}

static int hal_key_public(void *ctx, uint8_t pub[65], bool create) {
    size_t n = 0;
    if (!load_key()) {
        psa_key_attributes_t a;
        uint8_t priv[32];
        if (!create) return -1;
        key_attributes(&a);
        if (psa_generate_key(&a, &s_key) != PSA_SUCCESS) return -1;
        if (psa_export_key(s_key, priv, sizeof priv, &n) != PSA_SUCCESS || n != 32) return -1;
        if (nvs_set_blob(s_nvs, "devkey", priv, 32) != ESP_OK || nvs_commit(s_nvs) != ESP_OK) { memset(priv, 0, sizeof priv); return -1; }
        memset(priv, 0, sizeof priv);
        s_key_loaded = true;
    }
    if (psa_export_public_key(s_key, pub, 65, &n) != PSA_SUCCESS || n != 65) return -1;
    return 0;
}

static int hal_sign(void *ctx, const uint8_t *m, size_t n, uint8_t sig[64]) {
    size_t len = 0;
    if (!load_key()) return -1;
    return psa_sign_message(s_key, PSA_ALG_ECDSA(PSA_ALG_SHA_256), m, n, sig, 64, &len) == PSA_SUCCESS && len == 64 ? 0 : -1;
}

static int hal_key_reset(void *ctx) {
    if (s_key_loaded) { psa_destroy_key(s_key); s_key_loaded = false; }
    nvs_erase_key(s_nvs, "devkey");
    return nvs_commit(s_nvs) == ESP_OK ? 0 : -1;
}

/* ------------------------------------------------------------------------------------------------ system */
static uint64_t hal_time(void *ctx) { return (uint64_t)esp_timer_get_time(); }

static void hal_reboot(void *ctx, bool to_bootloader) {
    gpio_set_level(CONFIG_AERIS_DRIVE_EN_GPIO, 0);
    if (to_bootloader) REG_WRITE(RTC_CNTL_OPTION1_REG, RTC_CNTL_FORCE_DOWNLOAD_BOOT);   /* ROM download mode on the next reset */
    esp_restart();
}

static void hal_log(void *ctx, int level, const char *msg) {
    if (level >= 2) ESP_LOGW(TAG, "%s", msg); else ESP_LOGI(TAG, "%s", msg);
}

static const aeris_hal_t HAL = {
    .ctx = NULL,
    .time_us = hal_time,
    .i2c_read = hal_i2c_read,
    .i2c_write = hal_i2c_write,
    .can_send = hal_can_send,
    .can_recv = hal_can_recv,
    .arm_input = hal_arm,
    .stop_input = hal_stop,
    .commission_input = hal_commission,
    .motor_power = hal_motor_power,
    .led = hal_led,
    .link_write = hal_link_write,
    .nvs_get = hal_nvs_get,
    .nvs_set = hal_nvs_set,
    .random = hal_random,
    .sha256 = hal_sha256,
    .key_public = hal_key_public,
    .sign = hal_sign,
    .key_reset = hal_key_reset,
    .reboot = hal_reboot,
    .log = hal_log,
};

const aeris_hal_t *board_hal(void) { return &HAL; }
const aeris_board_t *board_info(void) { return &BOARD; }

void board_device_id(char *out, size_t cap) {
    uint8_t mac[6] = {0};
    esp_efuse_mac_get_default(mac);
    snprintf(out, cap, "aeris-%02x%02x%02x%02x%02x%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

void board_init(void) {
    esp_err_t e;
    /* outputs first: driver power off, whatever happens next */
    gpio_config_t out = {.pin_bit_mask = (1ULL << CONFIG_AERIS_DRIVE_EN_GPIO) | (1ULL << CONFIG_AERIS_LED_GPIO), .mode = GPIO_MODE_OUTPUT};
    gpio_config_t in = {.pin_bit_mask = (1ULL << CONFIG_AERIS_ARM_GPIO) | (1ULL << CONFIG_AERIS_DEADMAN_GPIO) | (1ULL << CONFIG_AERIS_STOP_SENSE_GPIO),
                        .mode = GPIO_MODE_INPUT, .pull_up_en = GPIO_PULLUP_ENABLE};
    gpio_set_level(CONFIG_AERIS_DRIVE_EN_GPIO, 0);
    gpio_config(&out);
    gpio_set_level(CONFIG_AERIS_DRIVE_EN_GPIO, 0);
    gpio_config(&in);
    /* storage and crypto */
    e = nvs_flash_init();
    if (e == ESP_ERR_NVS_NO_FREE_PAGES || e == ESP_ERR_NVS_NEW_VERSION_FOUND) { nvs_flash_erase(); e = nvs_flash_init(); }
    ESP_ERROR_CHECK(e);
    ESP_ERROR_CHECK(nvs_open("aeris", NVS_READWRITE, &s_nvs));
    if (psa_crypto_init() != PSA_SUCCESS) ESP_LOGE(TAG, "PSA crypto init failed: pairing and authentication unavailable");
    /* I2C */
    {
        i2c_master_bus_config_t bc = {.i2c_port = -1, .sda_io_num = CONFIG_AERIS_I2C_SDA_GPIO, .scl_io_num = CONFIG_AERIS_I2C_SCL_GPIO,
                                      .clk_source = I2C_CLK_SRC_DEFAULT, .glitch_ignore_cnt = 7, .flags.enable_internal_pullup = true};
        i2c_device_config_t dc = {.dev_addr_length = I2C_ADDR_BIT_LEN_7, .scl_speed_hz = CONFIG_AERIS_I2C_HZ};
        if (i2c_new_master_bus(&bc, &s_bus) == ESP_OK) {
            dc.device_address = 0x6A; i2c_master_bus_add_device(s_bus, &dc, &s_i2c[0]);
            dc.device_address = 0x6B; i2c_master_bus_add_device(s_bus, &dc, &s_i2c[1]);
        } else ESP_LOGE(TAG, "I2C bus init failed");
    }
    /* CAN */
    {
        twai_onchip_node_config_t nc = {
            .io_cfg = {.tx = CONFIG_AERIS_CAN_TX_GPIO, .rx = CONFIG_AERIS_CAN_RX_GPIO, .quanta_clk_out = -1, .bus_off_indicator = -1},
            .bit_timing = {.bitrate = CONFIG_AERIS_CAN_BITRATE},
            .fail_retry_cnt = 3,
            .tx_queue_depth = 16,
            .intr_priority = 1,
        };
        twai_event_callbacks_t cbs = {.on_rx_done = on_can_rx};
        s_can_rx = xQueueCreate(128, sizeof(can_rec_t));
        if (twai_new_node_onchip(&nc, &s_twai) != ESP_OK || twai_node_register_event_callbacks(s_twai, &cbs, NULL) != ESP_OK ||
            twai_node_enable(s_twai) != ESP_OK) { ESP_LOGE(TAG, "TWAI init failed: no wheel drivers"); s_twai = NULL; }
    }
    /* the local link */
#if CONFIG_AERIS_LINK_ON_UART0
    ESP_ERROR_CHECK(uart_driver_install(UART_NUM_0, 4096, 8192, 0, NULL, 0));
#else
    {
        usb_serial_jtag_driver_config_t uc = {.tx_buffer_size = 8192, .rx_buffer_size = 4096};
        ESP_ERROR_CHECK(usb_serial_jtag_driver_install(&uc));
    }
#endif
}

#if CONFIG_AERIS_BOOT_CRYPTO_SELFTEST
/* test images only: an ephemeral key signs a fixed message; the host verifies the signature with OpenSSL */
void board_crypto_selftest(void (*emit)(const char *line)) {
    static const char MSG[] = "AERIS-TARGET-SELFTEST\nPSA ECDSA P-256 SHA-256";
    psa_key_attributes_t a;
    psa_key_id_t k;
    uint8_t pub[65], sig[64], h[32];
    size_t n = 0, i;
    char line[400], *p = line;
    a = psa_key_attributes_init();
    psa_set_key_type(&a, PSA_KEY_TYPE_ECC_KEY_PAIR(PSA_ECC_FAMILY_SECP_R1));
    psa_set_key_bits(&a, 256);
    psa_set_key_usage_flags(&a, PSA_KEY_USAGE_SIGN_MESSAGE);
    psa_set_key_algorithm(&a, PSA_ALG_ECDSA(PSA_ALG_SHA_256));
    if (psa_generate_key(&a, &k) != PSA_SUCCESS) { emit("AERIS-SELFTEST keygen-failed"); return; }
    if (psa_export_public_key(k, pub, sizeof pub, &n) != PSA_SUCCESS || n != 65 ||
        psa_sign_message(k, PSA_ALG_ECDSA(PSA_ALG_SHA_256), (const uint8_t *)MSG, sizeof MSG - 1, sig, sizeof sig, &n) != PSA_SUCCESS || n != 64 ||
        psa_hash_compute(PSA_ALG_SHA_256, (const uint8_t *)MSG, sizeof MSG - 1, h, sizeof h, &n) != PSA_SUCCESS) {
        psa_destroy_key(k);
        emit("AERIS-SELFTEST sign-failed");
        return;
    }
    psa_destroy_key(k);
    p += sprintf(p, "AERIS-SELFTEST pub=");
    for (i = 0; i < 65; i++) p += sprintf(p, "%02x", pub[i]);
    p += sprintf(p, " sig=");
    for (i = 0; i < 64; i++) p += sprintf(p, "%02x", sig[i]);
    p += sprintf(p, " sha256=");
    for (i = 0; i < 32; i++) p += sprintf(p, "%02x", h[i]);
    emit(line);
}
#endif

/* AERIS ESP32-S3 network link: Wi-Fi station + an OUTBOUND WebSocket over TLS to the backend's device gateway.
 *
 * The device never listens for connections. The gateway URL, the Wi-Fi name and password are stored over USB with the
 * set_network command (NVS keys net_url, net_ssid, net_pass); without them the network link stays off. The server is
 * verified against the ESP-IDF CA certificate bundle (esp_crt_bundle_attach): a server without a certificate from a
 * public CA is refused. The WebSocket carries exactly the byte stream of the USB link (aeris-device-link/1 lines) in
 * BINARY frames (a frame may hold part of a line or several lines; the newlines delimit messages), so a multi-byte
 * character split across frames is never a protocol error. After the connection the gateway authenticates the device
 * (auth_challenge, signed with the pairing key) and only then opens a session (firmware link.c).
 *
 * Threads: the WebSocket client calls back on its own task; received bytes go into a stream buffer that the control
 * task drains (the core is single-threaded); bytes the core sends go into another stream buffer that a sender task
 * writes to the socket. */
#include "net.h"

#include <string.h>
#include "board.h"
#include "esp_crt_bundle.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_websocket_client.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/stream_buffer.h"
#include "freertos/task.h"

static const char *TAG = "aeris-net";
static StreamBufferHandle_t s_rx, s_tx;
static esp_websocket_client_handle_t s_ws;
static volatile bool s_connected;
static volatile uint32_t s_conn_gen;
static bool s_started;
static char s_url[201];

static void on_wifi(void *arg, esp_event_base_t base, int32_t id, void *data) {
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) esp_wifi_connect();
    else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) esp_wifi_connect();
    else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) ESP_LOGI(TAG, "Wi-Fi connected");
}

static void on_ws(void *arg, esp_event_base_t base, int32_t id, void *data) {
    esp_websocket_event_data_t *d = (esp_websocket_event_data_t *)data;
    switch (id) {
    case WEBSOCKET_EVENT_CONNECTED:
        xStreamBufferReset(s_rx);
        xStreamBufferReset(s_tx);
        s_connected = true;
        s_conn_gen++;
        ESP_LOGI(TAG, "gateway connected");
        break;
    case WEBSOCKET_EVENT_DISCONNECTED:
    case WEBSOCKET_EVENT_CLOSED:
        s_connected = false;
        s_conn_gen++;
        ESP_LOGW(TAG, "gateway disconnected");
        break;
    case WEBSOCKET_EVENT_DATA:
        if ((d->op_code == 0x1 || d->op_code == 0x2 || d->op_code == 0x0) && d->data_len > 0) {
            if (xStreamBufferSend(s_rx, d->data_ptr, (size_t)d->data_len, 0) != (size_t)d->data_len)
                ESP_LOGW(TAG, "receive buffer full: bytes dropped (the CRC framing will reject the damaged line)");
        }
        break;
    default:
        break;
    }
}

static void sender(void *arg) {
    uint8_t buf[1024];
    for (;;) {
        size_t n = xStreamBufferReceive(s_tx, buf, sizeof buf, portMAX_DELAY);
        if (n && s_connected && s_ws) esp_websocket_client_send_bin(s_ws, (const char *)buf, (int)n, pdMS_TO_TICKS(2000));
    }
}

int net_link_write(const uint8_t *data, size_t n) {
    if (!s_started || !s_connected) return (int)n;           /* nothing listens: dropped like on a closed link */
    return (int)xStreamBufferSend(s_tx, data, n, 0);          /* never blocks the control task */
}

bool net_poll(uint8_t *buf, size_t cap, size_t *n, uint32_t *gen, bool *connected) {
    *gen = s_conn_gen;
    *connected = s_connected;
    *n = s_started ? xStreamBufferReceive(s_rx, buf, cap, 0) : 0;
    return s_started;
}

void net_start(void) {
    char ssid[33], pass[65];
    wifi_config_t wc = {0};
    wifi_init_config_t ic = WIFI_INIT_CONFIG_DEFAULT();
    esp_websocket_client_config_t cfg = {0};
    if (!board_nvs_get_str("net_url", s_url, sizeof s_url) || !board_nvs_get_str("net_ssid", ssid, sizeof ssid)) {
        ESP_LOGI(TAG, "no network settings stored (set_network over USB): the network link stays off");
        return;
    }
    if (!board_nvs_get_str("net_pass", pass, sizeof pass)) pass[0] = 0;
    s_rx = xStreamBufferCreate(8192, 1);
    s_tx = xStreamBufferCreate(16384, 1);
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    ESP_ERROR_CHECK(esp_wifi_init(&ic));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, on_wifi, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, on_wifi, NULL));
    /* wifi_config_t fields hold up to 32 / 64 bytes and need no terminator when full */
    memcpy(wc.sta.ssid, ssid, strnlen(ssid, sizeof wc.sta.ssid));
    memcpy(wc.sta.password, pass, strnlen(pass, sizeof wc.sta.password));
    wc.sta.threshold.authmode = pass[0] ? WIFI_AUTH_WPA2_PSK : WIFI_AUTH_OPEN;
    memset(pass, 0, sizeof pass);
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wc));
    ESP_ERROR_CHECK(esp_wifi_start());
    cfg.uri = s_url;
    cfg.crt_bundle_attach = esp_crt_bundle_attach;   /* TLS server verification against the CA bundle */
    cfg.reconnect_timeout_ms = 5000;
    cfg.network_timeout_ms = 10000;
    cfg.buffer_size = 4096;
    cfg.task_stack = 8192;
    cfg.task_prio = 5;
    s_ws = esp_websocket_client_init(&cfg);
    if (!s_ws) { ESP_LOGE(TAG, "websocket client init failed"); return; }
    esp_websocket_register_events(s_ws, WEBSOCKET_EVENT_ANY, on_ws, NULL);
    xTaskCreatePinnedToCore(sender, "aeris_net_tx", 4096, NULL, 5, NULL, 0);
    s_started = true;
    esp_websocket_client_start(s_ws);
}

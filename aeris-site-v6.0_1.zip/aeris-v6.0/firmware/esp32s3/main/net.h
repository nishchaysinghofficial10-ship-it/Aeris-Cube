#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

void net_start(void);
int net_link_write(const uint8_t *data, size_t n);
/* bytes received from the gateway since the last call; gen changes on every connect/disconnect */
bool net_poll(uint8_t *buf, size_t cap, size_t *n, uint32_t *gen, bool *connected);

/* AERIS firmware core — freestanding helpers (see util.h). */
#include "aeris/util.h"

#if defined(__wasm__)
/* WebAssembly: no libc. memcpy/memset/memcmp are provided by wasm/wasm_libc.c (the compiler emits calls to them);
 * transcendental functions are imported from the page (Math.*); sqrt is a wasm instruction. */
__attribute__((import_module("env"), import_name("aeris_sin"))) double aeris_import_sin(double);
__attribute__((import_module("env"), import_name("aeris_cos"))) double aeris_import_cos(double);
__attribute__((import_module("env"), import_name("aeris_atan2"))) double aeris_import_atan2(double, double);
__attribute__((import_module("env"), import_name("aeris_acos"))) double aeris_import_acos(double);
__attribute__((import_module("env"), import_name("aeris_tanh"))) double aeris_import_tanh(double);
void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int v, size_t n);
int memcmp(const void *a, const void *b, size_t n);
float au_sqrtf(float x) { return __builtin_sqrtf(x); }
double au_sqrt(double x) { return __builtin_sqrt(x); }
float au_sinf(float x) { return (float)aeris_import_sin((double)x); }
float au_cosf(float x) { return (float)aeris_import_cos((double)x); }
float au_atan2f(float y, float x) { return (float)aeris_import_atan2((double)y, (double)x); }
float au_acosf(float x) { return (float)aeris_import_acos((double)x); }
float au_tanhf(float x) { return (float)aeris_import_tanh((double)x); }
double au_sin(double x) { return aeris_import_sin(x); }
double au_cos(double x) { return aeris_import_cos(x); }
double au_atan2(double y, double x) { return aeris_import_atan2(y, x); }
double au_tanh(double x) { return aeris_import_tanh(x); }
#else
#include <math.h>
#include <string.h>
float au_sqrtf(float x) { return sqrtf(x); }
double au_sqrt(double x) { return sqrt(x); }
float au_sinf(float x) { return sinf(x); }
float au_cosf(float x) { return cosf(x); }
float au_atan2f(float y, float x) { return atan2f(y, x); }
float au_acosf(float x) { return acosf(x); }
float au_tanhf(float x) { return tanhf(x); }
double au_sin(double x) { return sin(x); }
double au_cos(double x) { return cos(x); }
double au_atan2(double y, double x) { return atan2(y, x); }
double au_tanh(double x) { return tanh(x); }
#endif

int au_isfinite(double x) { return x == x && x - x == 0.0; }          /* NaN fails the first, ±inf the second */
int au_isfinitef(float x) { return x == x && x - x == 0.0f; }

void au_memset(void *d, int v, size_t n) { memset(d, v, n); }
void au_memcpy(void *d, const void *s, size_t n) { if (n) memcpy(d, s, n); }
int au_memcmp(const void *a, const void *b, size_t n) { return n ? memcmp(a, b, n) : 0; }
size_t au_strlen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
size_t au_strnlen(const char *s, size_t max) { size_t n = 0; while (n < max && s[n]) n++; return n; }
int au_streq(const char *a, const char *b) {
    if (!a || !b) return 0;
    while (*a && *a == *b) { a++; b++; }
    return *a == *b;
}
int au_strneq(const char *a, size_t alen, const char *b) {
    size_t i = 0;
    if (!a || !b) return 0;
    for (; i < alen; i++) if (b[i] == 0 || a[i] != b[i]) return 0;
    return b[alen] == 0;
}
size_t au_strlcpy(char *d, const char *s, size_t cap) {
    size_t n = au_strlen(s);
    if (cap) { size_t k = n < cap - 1 ? n : cap - 1; au_memcpy(d, s, k); d[k] = 0; }
    return n;
}

/* ------------------------------------------------------------------------------------------------ formatting */
static const double P10[] = {1e0, 1e1, 1e2, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13, 1e14, 1e15, 1e16,
                             1e17, 1e18, 1e19, 1e20, 1e21, 1e22};

size_t au_fmt_uint(char *buf, size_t cap, uint64_t v) {
    char t[24]; size_t n = 0, i;
    do { t[n++] = (char)('0' + v % 10u); v /= 10u; } while (v && n < sizeof t);
    if (n + 1 > cap) return 0;
    for (i = 0; i < n; i++) buf[i] = t[n - 1 - i];
    buf[n] = 0;
    return n;
}

size_t au_fmt_int(char *buf, size_t cap, int64_t v) {
    if (v < 0) {
        uint64_t u = (uint64_t)(-(v + 1)) + 1u;
        size_t n;
        if (cap < 2) return 0;
        buf[0] = '-';
        n = au_fmt_uint(buf + 1, cap - 1, u);
        return n ? n + 1 : 0;
    }
    return au_fmt_uint(buf, cap, (uint64_t)v);
}

size_t au_fmt_hex(char *buf, size_t cap, const uint8_t *data, size_t n) {
    static const char H[] = "0123456789abcdef";
    size_t i;
    if (2 * n + 1 > cap) return 0;
    for (i = 0; i < n; i++) { buf[2 * i] = H[data[i] >> 4]; buf[2 * i + 1] = H[data[i] & 15]; }
    buf[2 * n] = 0;
    return 2 * n;
}

/* x · 10^k with as few roundings as possible: one multiplication or division by an exact power of ten (|k| ≤ 22) */
static double scale10(double x, int k) {
    while (k > 22) { x *= 1e22; k -= 22; }
    while (k < -22) { x /= 1e22; k += 22; }
    return k >= 0 ? x * P10[k] : x / P10[-k];
}

size_t au_fmt_double(char *buf, size_t cap, double x, int sig) {
    char d[20], out[48];
    size_t o = 0;
    int e = 0, nd, i;
    uint64_t m, lim, low;
    double v, w;
    if (!au_isfinite(x)) return 0;
    if (sig < 1) sig = 1;
    if (sig > 17) sig = 17;
    if (x == 0.0) { if (cap < 2) return 0; buf[0] = '0'; buf[1] = 0; return 1; }
    v = x < 0 ? -x : x;
    /* decimal exponent: 10^e ≤ v < 10^(e+1) (exact comparisons against the exact powers of ten where possible) */
    if (v >= 1.0 && v < 1e23) { e = 0; while (e < 22 && v >= P10[e + 1]) e++; }
    else if (v < 1.0 && v >= 1e-22) { e = -1; while (e > -22 && v * P10[-e] < 1.0) e--; }
    else {
        w = v;
        while (w >= 10.0) { w /= 10.0; e++; }
        while (w < 1.0) { w *= 10.0; e--; }
    }
    lim = 1;
    for (i = 0; i < sig; i++) lim *= 10u;
    low = lim / 10u;
    w = scale10(v, sig - 1 - e);                 /* ≈ v·10^(sig−1−e) ∈ [10^(sig−1), 10^sig) */
    m = (uint64_t)(w + 0.5);
    if (m >= lim) { e++; w = scale10(v, sig - 1 - e); m = (uint64_t)(w + 0.5); if (m >= lim) m = lim - 1; }
    else if (m < low) { e--; w = scale10(v, sig - 1 - e); m = (uint64_t)(w + 0.5); if (m < low) m = low; }
    for (i = sig - 1; i >= 0; i--) { d[i] = (char)('0' + (int)(m % 10u)); m /= 10u; }
    nd = sig;
    while (nd > 1 && d[nd - 1] == '0') nd--;
    if (x < 0) out[o++] = '-';
    if (e >= -5 && e < 17) {
        if (e >= 0) {
            for (i = 0; i <= e; i++) out[o++] = i < nd ? d[i] : '0';
            if (nd > e + 1) { out[o++] = '.'; for (i = e + 1; i < nd; i++) out[o++] = d[i]; }
        } else {
            out[o++] = '0'; out[o++] = '.';
            for (i = 0; i < -e - 1; i++) out[o++] = '0';
            for (i = 0; i < nd; i++) out[o++] = d[i];
        }
    } else {
        char eb[8];
        size_t en;
        out[o++] = d[0];
        if (nd > 1) { out[o++] = '.'; for (i = 1; i < nd; i++) out[o++] = d[i]; }
        out[o++] = 'e';
        en = au_fmt_int(eb, sizeof eb, e);
        for (i = 0; i < (int)en; i++) out[o++] = eb[i];
    }
    if (o + 1 > cap) return 0;
    au_memcpy(buf, out, o);
    buf[o] = 0;
    return o;
}

/* ------------------------------------------------------------------------------------------------ parsing */
static double pow10d(int k) {
    double r = 1.0;
    int neg = k < 0;
    if (neg) k = -k;
    while (k >= 22) { r *= P10[22]; k -= 22; }
    r *= P10[k];
    return neg ? 1.0 / r : r;
}

bool au_parse_double(const char *s, size_t len, double *out) {
    size_t i = 0;
    int neg = 0, digits = 0, exp10 = 0, eneg = 0;
    long ex = 0;
    uint64_t m = 0;
    if (!s || !len) return false;
    if (s[i] == '-') { neg = 1; i++; }
    if (i >= len) return false;
    if (s[i] == '0') { i++; if (i < len && s[i] >= '0' && s[i] <= '9') return false; }
    else if (s[i] >= '1' && s[i] <= '9') {
        while (i < len && s[i] >= '0' && s[i] <= '9') {
            if (digits < 19) { m = m * 10u + (uint64_t)(s[i] - '0'); digits++; } else exp10++;
            i++;
        }
    } else return false;
    if (i < len && s[i] == '.') {
        i++;
        if (i >= len || s[i] < '0' || s[i] > '9') return false;
        while (i < len && s[i] >= '0' && s[i] <= '9') {
            if (digits < 19) { m = m * 10u + (uint64_t)(s[i] - '0'); digits++; exp10--; }
            i++;
        }
    }
    if (i < len && (s[i] == 'e' || s[i] == 'E')) {
        i++;
        if (i < len && (s[i] == '+' || s[i] == '-')) { eneg = s[i] == '-'; i++; }
        if (i >= len || s[i] < '0' || s[i] > '9') return false;
        while (i < len && s[i] >= '0' && s[i] <= '9') { if (ex < 100000) ex = ex * 10 + (s[i] - '0'); i++; }
    }
    if (i != len) return false;
    exp10 += (int)(eneg ? -ex : ex);
    {
        double v = (double)m;
        if (m != 0) {
            if (exp10 > 308 + 19) return false;
            if (exp10 < -400) v = 0.0;
            else if (m <= 9007199254740992ull && exp10 >= -22 && exp10 <= 22) v = exp10 >= 0 ? v * P10[exp10] : v / P10[-exp10];   /* exact operands: correctly rounded */
            else if (exp10 >= 0) v *= pow10d(exp10);
            else if (exp10 >= -22) v /= P10[-exp10];
            else v = (v / P10[22]) * pow10d(exp10 + 22);
        }
        if (!au_isfinite(v)) return false;
        *out = neg ? -v : v;
    }
    return true;
}

bool au_parse_int(const char *s, size_t len, int64_t *out) {
    size_t i = 0;
    int neg = 0;
    uint64_t v = 0;
    if (!s || !len) return false;
    if (s[0] == '-') { neg = 1; i = 1; }
    if (i >= len) return false;
    if (s[i] == '0' && len > i + 1) return false;
    for (; i < len; i++) {
        if (s[i] < '0' || s[i] > '9') return false;
        if (v > (UINT64_MAX - 9u) / 10u) return false;
        v = v * 10u + (uint64_t)(s[i] - '0');
    }
    if (neg) { if (v > (uint64_t)INT64_MAX + 1u) return false; *out = v == (uint64_t)INT64_MAX + 1u ? INT64_MIN : -(int64_t)v; }
    else { if (v > (uint64_t)INT64_MAX) return false; *out = (int64_t)v; }
    return true;
}

/* ------------------------------------------------------------------------------------------------ CRC-32 */
static const uint32_t CRC_NIBBLE[16] = {
    0x00000000u, 0x1DB71064u, 0x3B6E20C8u, 0x26D930ACu, 0x76DC4190u, 0x6B6B51F4u, 0x4DB26158u, 0x5005713Cu,
    0xEDB88320u, 0xF00F9344u, 0xD6D6A3E8u, 0xCB61B38Cu, 0x9B64C2B0u, 0x86D3D2D4u, 0xA00AE278u, 0xBDBDF21Cu};

uint32_t au_crc32_update(uint32_t crc, const uint8_t *data, size_t n) {
    size_t i;
    crc = ~crc;
    for (i = 0; i < n; i++) {
        crc ^= data[i];
        crc = (crc >> 4) ^ CRC_NIBBLE[crc & 15u];
        crc = (crc >> 4) ^ CRC_NIBBLE[crc & 15u];
    }
    return ~crc;
}
uint32_t au_crc32(const uint8_t *data, size_t n) { return au_crc32_update(0u, data, n); }

/* ------------------------------------------------------------------------------------------------ base64url, hex */
static const char B64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

size_t au_b64url_encode(char *out, size_t cap, const uint8_t *data, size_t n) {
    size_t o = 0, i = 0;
    while (i + 2 < n) {
        uint32_t v = ((uint32_t)data[i] << 16) | ((uint32_t)data[i + 1] << 8) | data[i + 2];
        if (o + 4 >= cap) return 0;
        out[o++] = B64[(v >> 18) & 63]; out[o++] = B64[(v >> 12) & 63]; out[o++] = B64[(v >> 6) & 63]; out[o++] = B64[v & 63];
        i += 3;
    }
    if (i < n) {
        uint32_t v = (uint32_t)data[i] << 16;
        if (i + 1 < n) v |= (uint32_t)data[i + 1] << 8;
        if (o + 4 >= cap) return 0;
        out[o++] = B64[(v >> 18) & 63]; out[o++] = B64[(v >> 12) & 63];
        if (i + 1 < n) out[o++] = B64[(v >> 6) & 63];
    }
    if (o >= cap) return 0;
    out[o] = 0;
    return o;
}

static int b64v(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '-') return 62;
    if (c == '_') return 63;
    return -1;
}

int au_b64url_decode(uint8_t *out, size_t cap, const char *s, size_t len) {
    size_t o = 0, i = 0;
    uint32_t acc = 0;
    int bits = 0;
    if (len % 4 == 1) return -1;
    for (i = 0; i < len; i++) {
        int v = b64v(s[i]);
        if (v < 0) return -1;
        acc = (acc << 6) | (uint32_t)v; bits += 6;
        if (bits >= 8) { bits -= 8; if (o >= cap) return -1; out[o++] = (uint8_t)(acc >> bits); acc &= (1u << bits) - 1u; }
    }
    if (acc != 0) return -1;            /* non-canonical trailing bits */
    return (int)o;
}

int au_hex_decode(uint8_t *out, size_t cap, const char *s, size_t len) {
    size_t i;
    if (len % 2 || len / 2 > cap) return -1;
    for (i = 0; i < len; i += 2) {
        int hi, lo;
        char a = s[i], b = s[i + 1];
        hi = a >= '0' && a <= '9' ? a - '0' : a >= 'a' && a <= 'f' ? a - 'a' + 10 : -1;
        lo = b >= '0' && b <= '9' ? b - '0' : b >= 'a' && b <= 'f' ? b - 'a' + 10 : -1;
        if (hi < 0 || lo < 0) return -1;
        out[i / 2] = (uint8_t)(hi * 16 + lo);
    }
    return (int)(len / 2);
}

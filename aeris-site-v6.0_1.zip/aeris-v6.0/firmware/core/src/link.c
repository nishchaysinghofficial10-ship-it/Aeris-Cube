/* AERIS firmware core — aeris-device-link/1: framing, link messages, sessions, device authentication, pairing and the
 * service loop (site/docs/DEVICE_LINK.md).
 *
 * Framing: one message per line, `<json>\t<crc32>\n`, the CRC-32 (zlib) of the JSON bytes as 8 lower-case hex digits,
 * at most AERIS_MAX_LINE bytes. A line that is not framed, fails its CRC, is too long or is not one JSON object is
 * counted and answered with link_error; it never reaches the command handler. Text without a frame (boot messages of
 * the chip's ROM, for example) is ignored by hosts the same way.
 *
 * Single-threaded: the board layer calls aeris_control_step, aeris_service and aeris_link_input from one task (or with
 * its own lock); link_write must not call back into the core. */
#include "aeris/device.h"
#include "aeris/json.h"
#include "aeris/util.h"

#define TLM_HEADROOM 4096u      /* bytes kept free for control messages when telemetry is queued */

static const char HEX[] = "0123456789abcdef";
static const char *LINK_NAMES[AERIS_LINKS] = {"usb", "net"};

static uint64_t now_us(const aeris_dev_t *d) { return d->hal->time_us(d->hal->ctx); }

/* ------------------------------------------------------------------------------------------------ output */
static void flush(aeris_dev_t *d, int link) {
    aeris_link_t *L = &d->link[link];
    int k;
    if (!L->up || !L->tx_len || !d->hal->link_write) return;
    k = d->hal->link_write(d->hal->ctx, link, L->tx, L->tx_len);
    if (k <= 0) return;
    if ((size_t)k >= L->tx_len) { L->tx_len = 0; return; }
    {   /* keep the rest (memmove) */
        size_t i, rest = L->tx_len - (size_t)k;
        for (i = 0; i < rest; i++) L->tx[i] = L->tx[(size_t)k + i];
        L->tx_len = rest;
    }
}

bool dev_tx_room(const aeris_dev_t *d, int link, size_t n, bool bulk) {
    const aeris_link_t *L = &d->link[link];
    size_t need = n + 10 + (bulk ? TLM_HEADROOM : 0);
    return L->up && L->tx_len + need <= AERIS_TX_BUF;
}

bool dev_send(aeris_dev_t *d, int link, const char *json, size_t n) {
    aeris_link_t *L;
    uint32_t c;
    int i;
    if (link < 0 || link >= AERIS_LINKS) return false;
    L = &d->link[link];
    if (!L->up) return false;
    if (n == 0 || n + 10 > AERIS_MAX_LINE || L->tx_len + n + 10 > AERIS_TX_BUF) { L->tx_dropped_lines++; return false; }
    c = au_crc32((const uint8_t *)json, n);
    au_memcpy(L->tx + L->tx_len, json, n);
    L->tx_len += n;
    L->tx[L->tx_len++] = '\t';
    for (i = 7; i >= 0; i--) { L->tx[L->tx_len + (size_t)i] = (uint8_t)HEX[c & 15u]; c >>= 4; }
    L->tx_len += 8;
    L->tx[L->tx_len++] = '\n';
    flush(d, link);
    return true;
}

void dev_broadcast(aeris_dev_t *d, const char *json, size_t n) {
    int i;
    for (i = 0; i < AERIS_LINKS; i++) if (d->link[i].up && d->link[i].active) dev_send(d, i, json, n);
}

static void send_w(aeris_dev_t *d, int link, aw_t *w) { if (aw_done(w)) dev_send(d, link, w->buf, w->len); }

static void link_error(aeris_dev_t *d, int link, const char *reason, const char *ref) {
    char b[256];
    aw_t w;
    aw_init(&w, b, sizeof b);
    aw_obj(&w); aw_kstr(&w, "kind", "link_error"); aw_kstr(&w, "reason", reason);
    if (ref) aw_kstr(&w, "ref", ref);
    aw_end_obj(&w);
    send_w(d, link, &w);
}

static bool usb_supervising(const aeris_dev_t *d) {
    const aeris_link_t *u = &d->link[AERIS_LINK_USB];
    return u->up && u->active && u->has_session;
}

static const char *ACTIONS[] = {"identify", "diagnostics", "self_test", "calibrate_imu", "calibrate_axes", "check_encoders",
                                "apply_config", "start_experiment", "stop", "clear_faults", "set_telemetry", "enter_update",
                                "reboot", "set_network", "unpair", "commission", "motor_test"};

void dev_send_dev_hello(aeris_dev_t *d, int link) {
    char *b = d->line;
    char pk[96];
    aw_t w;
    unsigned i;
    aw_init(&w, b, sizeof d->line);
    aw_obj(&w);
    aw_kstr(&w, "kind", "dev_hello");
    aw_kstr(&w, "link", AERIS_LINK_PROTOCOL);
    aw_key(&w, "versions"); aw_arr(&w); aw_int(&w, 1); aw_end_arr(&w);
    aw_kstr(&w, "device_id", d->device_id);
    aw_kstr(&w, "boot_id", d->boot_id);
    aw_key(&w, "fw"); aw_obj(&w);
    aw_kstr(&w, "name", AERIS_FW_NAME); aw_kstr(&w, "version", AERIS_FW_VERSION); aw_kstr(&w, "build", AERIS_BUILD_ID);
    aw_kbool(&w, "actuation_build", d->board->actuation_build); aw_kbool(&w, "commissioning_build", d->board->commissioning_build);
    aw_end_obj(&w);
    aw_key(&w, "board"); aw_obj(&w);
    aw_kstr(&w, "id", d->board->board_id); aw_kstr(&w, "chip", d->board->chip); aw_kstr(&w, "kind", d->board->device_kind);
    aw_kbool(&w, "synthetic", d->board->synthetic);
    aw_end_obj(&w);
    if (d->have_key && au_b64url_encode(pk, sizeof pk, d->pub, 65)) aw_kstr(&w, "pubkey", pk); else aw_knull(&w, "pubkey");
    aw_kbool(&w, "paired", d->paired);
    aw_kstr(&w, "state", aeris_state_name(d->state));
    if (d->cfg.valid) aw_kstr(&w, "config_hash", d->cfg.hash_hex); else aw_knull(&w, "config_hash");
    aw_kstr(&w, "link_name", LINK_NAMES[link]);
    aw_key(&w, "caps"); aw_obj(&w);
    aw_key(&w, "actions"); aw_arr(&w);
    for (i = 0; i < sizeof ACTIONS / sizeof ACTIONS[0]; i++) aw_str(&w, ACTIONS[i]);
    aw_end_arr(&w);
    aw_key(&w, "controllers"); aw_arr(&w); aw_str(&w, "edge-lqr"); aw_str(&w, "corner-mimo-lqr"); aw_end_arr(&w);
    aw_key(&w, "estimators"); aw_arr(&w); aw_str(&w, "cf3d"); aw_end_arr(&w);
    aw_kstr(&w, "imu", d->board->imu_drivers); aw_kstr(&w, "motor", d->board->motor_drivers);
    aw_kstr(&w, "config_schema", "aeris-device-config/1");
    aw_kint(&w, "max_control_hz", d->board->max_control_hz);
    aw_kint(&w, "max_ttl_ms", AERIS_MAX_TTL_MS);
    aw_kint(&w, "max_line", AERIS_MAX_LINE);
    aw_end_obj(&w);
    aw_key(&w, "limits"); aw_obj(&w);
    aw_knum(&w, "hard_max_current_A", d->board->hard_max_current_A, 6);
    aw_knum(&w, "hard_max_torque_Nm", d->board->hard_max_torque_Nm, 6);
    aw_knum(&w, "hard_max_speed_rpm", d->board->hard_max_speed_rpm, 6);
    aw_end_obj(&w);
    aw_end_obj(&w);
    send_w(d, link, &w);
}

void dev_send_state(aeris_dev_t *d) {
    char b[900], fl[300];
    aw_t w;
    size_t n;
    uint64_t now = now_us(d);
    if (!(d->link[0].active && d->link[0].up) && !(d->link[1].active && d->link[1].up)) return;
    aw_init(&w, b, sizeof b);
    aw_obj(&w);
    aw_kstr(&w, "kind", "state");
    aw_kstr(&w, "state", aeris_state_name(d->state));
    aw_kstr(&w, "reason", d->state_reason);
    n = aeris_faults_json(d->faults, fl, sizeof fl);
    aw_key(&w, "faults"); if (n) aw_raw(&w, fl, n); else aw_null(&w);
    n = aeris_faults_json(d->latched, fl, sizeof fl);
    aw_key(&w, "latched"); if (n) aw_raw(&w, fl, n); else aw_null(&w);
    if (d->cfg.valid) {
        aw_kstr(&w, "config_hash", d->cfg.hash_hex);
        aw_kstr(&w, "mode", d->cfg.mode == MODE_EDGE ? "edge" : "corner");
    } else { aw_knull(&w, "config_hash"); aw_knull(&w, "mode"); }
    aw_kbool(&w, "actuation_permitted", aeris_actuation_permitted(d));
    if (d->exp_active || d->state == ST_STOPPING) {
        aw_key(&w, "experiment"); aw_obj(&w);
        aw_kstr(&w, "cmd", d->exp_cmd); aw_kstr(&w, "recipe", d->exp_recipe);
        aw_knum(&w, "elapsed_s", (double)(now - d->exp_start_us) * 1e-6, 6);
        if (d->state == ST_BALANCING) aw_knum(&w, "remaining_s", d->exp_end_us > now ? (double)(d->exp_end_us - now) * 1e-6 : 0.0, 6);
        if (d->exp_end_reason[0]) aw_kstr(&w, "ending", d->exp_end_reason);
        aw_end_obj(&w);
    } else aw_knull(&w, "experiment");
    if (d->wait_start || d->wait_clear || d->wait_unpair || d->pair_pending) {
        uint64_t dl = d->pair_pending ? d->pair_deadline_us : d->wait_deadline_us;
        aw_key(&w, "waiting"); aw_obj(&w);
        aw_kstr(&w, "kind", d->pair_pending ? "pair" : d->wait_start ? "start" : d->wait_clear ? "clear_faults" : "unpair");
        aw_kstr(&w, "local_action", d->wait_clear ? "hold ARM for 2 s" : "press ARM");
        if (!d->pair_pending) aw_kstr(&w, "cmd", d->wait_cmd);
        aw_kint(&w, "remaining_ms", dl > now ? (int64_t)((dl - now) / 1000u) : 0);
        aw_end_obj(&w);
    } else aw_knull(&w, "waiting");
    if (d->task == TASK_SELF_TEST) aw_kstr(&w, "task", "self_test");
    else if (d->task == TASK_IMU_AVERAGE) aw_kstr(&w, "task", d->task_sub ? "calibrate_axes" : "calibrate_imu");
    else if (d->task == TASK_ENCODERS) aw_kstr(&w, "task", "check_encoders");
    else aw_knull(&w, "task");
    aw_kbool(&w, "link_lost", d->link_lost);
    aw_kbool(&w, "local_session", usb_supervising(d));
    aw_knum(&w, "uptime_s", (double)(now - d->boot_us) * 1e-6, 7);
    aw_kstr(&w, "boot_id", d->boot_id);
    aw_key(&w, "tlm"); aw_obj(&w);
    aw_kstr(&w, "session", d->tlm_session); aw_kuint(&w, "seq", d->tlm_seq); aw_kint(&w, "hz", d->tlm_hz);
    aw_end_obj(&w);
    if (d->est_valid && d->cfg.valid) aw_knum(&w, "tilt_deg", (double)d->tilt * 57.29577951308232, 5); else aw_knull(&w, "tilt_deg");
    if (d->vbus > 0) aw_knum(&w, "vbus_V", d->vbus, 5); else aw_knull(&w, "vbus_V");
    aw_end_obj(&w);
    if (aw_done(&w)) dev_broadcast(d, w.buf, w.len);
    d->state_sent_us = now;
}

/* ------------------------------------------------------------------------------------------------ validation helpers */
static bool safe_token(const char *s, size_t min, size_t max) {
    size_t i, n = au_strlen(s);
    if (n < min || n > max) return false;
    for (i = 0; i < n; i++) {
        char c = s[i];
        if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == ':' || c == '-')) return false;
    }
    return true;
}

/* field `key` of object `obj`: a string of [A-Za-z0-9._:-] (no separators that could make two canonical strings equal) */
static bool get_token(const aj_doc_t *doc, int obj, const char *key, char *out, size_t cap, size_t min) {
    int t = aj_get(doc, obj, key);
    return t >= 0 && aj_str(doc, t, out, cap) && safe_token(out, min, cap - 1);
}

static void append(char *b, size_t cap, size_t *n, const char *s) {
    size_t k = au_strlen(s);
    if (*n + k + 1 > cap) { *n = cap; return; }
    au_memcpy(b + *n, s, k);
    *n += k;
    b[*n] = 0;
}

/* ------------------------------------------------------------------------------------------------ device authentication
 * The gateway (the backend's device endpoint, reached over TLS that the board layer verifies against its CA bundle)
 * challenges the device; the device signs "AERIS-AUTH-V1\n<gateway_id>\n<gw_session>\n<nonce>\n<device_id>\n<boot_id>"
 * with its pairing key. The gateway checks the signature against the credential registered at pairing. */
static void on_auth_challenge(aeris_dev_t *d, int link, const aj_doc_t *doc) {
    char gw[65], gs[65], nonce[97], msg[400], sig_b64[96], pk[96];
    uint8_t sig[64];
    size_t n = 0;
    aw_t w;
    if (link != AERIS_LINK_NET) { link_error(d, link, "auth_challenge is for the network link", 0); return; }
    if (!get_token(doc, 0, "gateway_id", gw, sizeof gw, 1) || !get_token(doc, 0, "gw_session", gs, sizeof gs, 8) ||
        !get_token(doc, 0, "nonce", nonce, sizeof nonce, 16)) { link_error(d, link, "auth_challenge: gateway_id, gw_session (≥ 8) and nonce (≥ 16) of [A-Za-z0-9._:-] required", 0); return; }
    aw_init(&w, d->line, sizeof d->line);
    aw_obj(&w); aw_kstr(&w, "kind", "auth"); aw_kstr(&w, "device_id", d->device_id); aw_kstr(&w, "boot_id", d->boot_id);
    if (!d->have_key || !d->hal->sign) {
        aw_kstr(&w, "error", "not paired: this device has no key (pair it over USB first)");
        aw_end_obj(&w); send_w(d, link, &w);
        return;
    }
    msg[0] = 0;
    append(msg, sizeof msg, &n, "AERIS-AUTH-V1\n"); append(msg, sizeof msg, &n, gw); append(msg, sizeof msg, &n, "\n");
    append(msg, sizeof msg, &n, gs); append(msg, sizeof msg, &n, "\n"); append(msg, sizeof msg, &n, nonce); append(msg, sizeof msg, &n, "\n");
    append(msg, sizeof msg, &n, d->device_id); append(msg, sizeof msg, &n, "\n"); append(msg, sizeof msg, &n, d->boot_id);
    if (n >= sizeof msg || d->hal->sign(d->hal->ctx, (const uint8_t *)msg, n, sig) != 0) {
        aw_kstr(&w, "error", "signing failed"); aw_end_obj(&w); send_w(d, link, &w); return;
    }
    au_b64url_encode(sig_b64, sizeof sig_b64, sig, 64);
    au_b64url_encode(pk, sizeof pk, d->pub, 65);
    aw_kstr(&w, "pubkey", pk); aw_kstr(&w, "sig", sig_b64); aw_kstr(&w, "alg", "ES256-raw");
    aw_end_obj(&w);
    send_w(d, link, &w);
    d->link[link].authed = true;
}

/* ------------------------------------------------------------------------------------------------ pairing (local proof)
 * USB only: the owner's browser (signed in to the site) obtains a pairing session and nonce from the backend and sends
 * pair_begin; the device creates its key pair if needed and waits for a press of the local ARM control; then it signs
 * "AERIS-PAIR-V1\n<session>\n<nonce>\n<device_id>\n<pubkey>\n<board_id>\n<fw_version>\nlocal-confirmed" and returns
 * pair_proof. The backend accepts the proof once (nonce bound to the owner's pairing session) and registers the public
 * key as the device's credential. Physical access to the USB port and the button is the local proof. */
static void pair_reply(aeris_dev_t *d, int link, bool ready, const char *session, const char *reason) {
    char b[400];
    aw_t w;
    aw_init(&w, b, sizeof b);
    aw_obj(&w); aw_kstr(&w, "kind", ready ? "pair_ready" : "pair_rejected"); aw_kstr(&w, "session", session);
    if (reason) aw_kstr(&w, "reason", reason);
    if (ready) { aw_kint(&w, "expires_in_ms", (int64_t)(AERIS_PAIR_WINDOW_US / 1000u)); aw_kstr(&w, "confirm", "press the ARM control on the cube"); }
    aw_end_obj(&w);
    send_w(d, link, &w);
}

static void on_pair_begin(aeris_dev_t *d, int link, const aj_doc_t *doc) {
    char session[48], nonce[97];
    if (!get_token(doc, 0, "session", session, sizeof session, 8) || !get_token(doc, 0, "nonce", nonce, sizeof nonce, 16)) {
        link_error(d, link, "pair_begin: session (8..47) and nonce (16..96) of [A-Za-z0-9._:-] required", 0);
        return;
    }
    if (link != AERIS_LINK_USB) { pair_reply(d, link, false, session, "pairing needs the local USB link"); return; }
    if (d->state != ST_DISARMED) { pair_reply(d, link, false, session, "pairing needs the DISARMED state"); return; }
    if (d->pair_pending || dev_local_wait(d)) { pair_reply(d, link, false, session, "another local confirmation is pending"); return; }
    if (!d->hal->key_public || d->hal->key_public(d->hal->ctx, d->pub, true) != 0) { pair_reply(d, link, false, session, "the device could not create its key"); return; }
    d->have_key = true;
    d->pair_pending = true;
    au_strlcpy(d->pair_session, session, sizeof d->pair_session);
    au_strlcpy(d->pair_nonce, nonce, sizeof d->pair_nonce);
    d->pair_link = link;
    d->pair_deadline_us = now_us(d) + AERIS_PAIR_WINDOW_US;
    pair_reply(d, link, true, session, 0);
    dev_send_state(d);
}

/* called by the task step on a local press while a pairing waits */
void link_pair_confirm(aeris_dev_t *d) {
    char msg[480], pk[96], sig_b64[96];
    uint8_t sig[64], one = 1;
    size_t n = 0;
    aw_t w;
    d->pair_pending = false;
    au_b64url_encode(pk, sizeof pk, d->pub, 65);
    msg[0] = 0;
    append(msg, sizeof msg, &n, "AERIS-PAIR-V1\n"); append(msg, sizeof msg, &n, d->pair_session); append(msg, sizeof msg, &n, "\n");
    append(msg, sizeof msg, &n, d->pair_nonce); append(msg, sizeof msg, &n, "\n"); append(msg, sizeof msg, &n, d->device_id); append(msg, sizeof msg, &n, "\n");
    append(msg, sizeof msg, &n, pk); append(msg, sizeof msg, &n, "\n"); append(msg, sizeof msg, &n, d->board->board_id); append(msg, sizeof msg, &n, "\n");
    append(msg, sizeof msg, &n, AERIS_FW_VERSION); append(msg, sizeof msg, &n, "\nlocal-confirmed");
    if (n >= sizeof msg || !d->hal->sign || d->hal->sign(d->hal->ctx, (const uint8_t *)msg, n, sig) != 0) {
        pair_reply(d, d->pair_link, false, d->pair_session, "signing failed");
        dev_send_state(d);
        return;
    }
    au_b64url_encode(sig_b64, sizeof sig_b64, sig, 64);
    aw_init(&w, d->line, sizeof d->line);
    aw_obj(&w);
    aw_kstr(&w, "kind", "pair_proof"); aw_kstr(&w, "session", d->pair_session); aw_kstr(&w, "nonce", d->pair_nonce);
    aw_kstr(&w, "device_id", d->device_id); aw_kstr(&w, "pubkey", pk); aw_kstr(&w, "board_id", d->board->board_id);
    aw_kstr(&w, "firmware", AERIS_FW_VERSION); aw_kstr(&w, "build", AERIS_BUILD_ID); aw_kbool(&w, "synthetic", d->board->synthetic);
    aw_kbool(&w, "local_confirmed", true); aw_kstr(&w, "alg", "ES256-raw"); aw_kstr(&w, "sig", sig_b64);
    aw_end_obj(&w);
    send_w(d, d->pair_link, &w);
    if (d->hal->nvs_set) d->hal->nvs_set(d->hal->ctx, "paired", &one, 1);
    d->paired = true;
    dev_send_state(d);
}

void link_pair_cancel(aeris_dev_t *d, const char *reason) {
    if (!d->pair_pending) return;
    d->pair_pending = false;
    pair_reply(d, d->pair_link, false, d->pair_session, reason);
    dev_send_state(d);
}

/* ------------------------------------------------------------------------------------------------ sessions */
static void drop_session(aeris_dev_t *d, int link, const char *why) {
    aeris_link_t *L = &d->link[link];
    uint64_t now = now_us(d);
    if (!L->has_session) return;
    L->has_session = false;
    if (d->exp_active && d->exp_link == link && !d->link_lost) { d->link_lost = true; d->link_lost_at = now; }
    if ((d->wait_start || d->wait_clear || d->wait_unpair) && d->wait_link == link) {
        cmd_report(d, link, d->wait_cmd, "cmd_result", "failed", why, 0);
        d->wait_start = d->wait_clear = d->wait_unpair = false;
    }
    if (d->pair_pending && d->pair_link == link) link_pair_cancel(d, why);
    dev_send_state(d);
}

static void on_session(aeris_dev_t *d, int link, const aj_doc_t *doc) {
    aeris_link_t *L = &d->link[link];
    char sid[48], b[256];
    int64_t epoch;
    int t = aj_get(doc, 0, "lease_epoch");
    aw_t w;
    if (!get_token(doc, 0, "link_session", sid, sizeof sid, 8)) { link_error(d, link, "session: link_session (8..47 of [A-Za-z0-9._:-]) required", 0); return; }
    if (t < 0 || !aj_int(doc, t, &epoch) || epoch < 0 || epoch > 0xFFFFFFFFll) { link_error(d, link, "session: lease_epoch (integer ≥ 0) required", 0); return; }
    if (link == AERIS_LINK_NET && !L->authed) { link_error(d, link, "session: the device has not been authenticated on this connection", 0); return; }
    if (L->has_session && au_streq(L->session, sid)) {
        if ((uint32_t)epoch < L->lease_epoch) { link_error(d, link, "session: lease_epoch cannot decrease", 0); return; }
        L->lease_epoch = (uint32_t)epoch;               /* lease handover within one session */
    } else {
        if (L->has_session) drop_session(d, link, "session replaced by a new one");
        au_strlcpy(L->session, sid, sizeof L->session);
        L->lease_epoch = (uint32_t)epoch;
        L->last_seq = -1;
        L->has_session = true;
    }
    L->last_heartbeat_us = now_us(d);
    if (d->exp_active && d->exp_link == link && au_streq(d->exp_session, sid)) d->link_lost = false;   /* supervision resumed */
    aw_init(&w, b, sizeof b);
    aw_obj(&w); aw_kstr(&w, "kind", "session_ok"); aw_kstr(&w, "link_session", L->session); aw_kuint(&w, "lease_epoch", L->lease_epoch);
    aw_kstr(&w, "role", (link == AERIS_LINK_NET && usb_supervising(d)) ? "observer" : "supervisor");
    aw_end_obj(&w);
    send_w(d, link, &w);
    dev_send_state(d);
}

static void on_heartbeat(aeris_dev_t *d, int link, const aj_doc_t *doc) {
    aeris_link_t *L = &d->link[link];
    char sid[48];
    int t = aj_get(doc, 0, "lease_epoch");
    int64_t epoch;
    if (!L->has_session) { link_error(d, link, "heartbeat: no session on this link", 0); return; }
    if (!get_token(doc, 0, "link_session", sid, sizeof sid, 8) || !au_streq(sid, L->session)) { link_error(d, link, "heartbeat: link_session does not match this link's session", 0); return; }
    if (t >= 0) {
        if (!aj_int(doc, t, &epoch) || epoch < (int64_t)L->lease_epoch || epoch > 0xFFFFFFFFll) { link_error(d, link, "heartbeat: lease_epoch cannot decrease", 0); return; }
        L->lease_epoch = (uint32_t)epoch;
    }
    L->last_heartbeat_us = now_us(d);
    if (d->exp_active && d->exp_link == link && au_streq(d->exp_session, sid) && d->link_lost) { d->link_lost = false; dev_send_state(d); }
}

/* ------------------------------------------------------------------------------------------------ dispatch */
void link_handle(aeris_dev_t *d, int link, const aj_doc_t *doc) {
    aeris_link_t *L = &d->link[link];
    int t = aj_get(doc, 0, "kind");
    if (t < 0 || !aj_is(doc, t, JSMN_STRING)) { L->rx.bad_message++; link_error(d, link, "message without a 'kind'", 0); return; }
    if (aj_str_eq(doc, t, "host_hello")) {
        int v = aj_get(doc, 0, "versions"), k, n = aj_arr_len(doc, v);
        bool ok = false;
        char host[16];
        for (k = 0; k < n; k++) { int64_t x; if (aj_int(doc, aj_arr_at(doc, v, k), &x) && x == 1) ok = true; }
        if (!ok) { link_error(d, link, "host_hello: no common link version (this firmware speaks aeris-device-link/1)", 0); return; }
        if (L->has_session) drop_session(d, link, "the host started a new link");
        if (!get_token(doc, 0, "host", host, sizeof host, 1)) au_strlcpy(host, "unknown", sizeof host);
        au_strlcpy(L->host, host, sizeof L->host);
        L->active = true;
        L->version = 1;
        L->tlm_on = true;
        L->tlm_hello_sent = false;
        L->resuming = false;
        dev_send_dev_hello(d, link);
        dev_send_state(d);
        if (d->tlm_hz > 0) dev_tlm_hello(d, link);
        return;
    }
    if (!L->active) { L->rx.bad_message++; link_error(d, link, "send host_hello first", 0); return; }
    if (aj_str_eq(doc, t, "cmd")) { cmd_handle(d, link, doc); return; }
    if (aj_str_eq(doc, t, "heartbeat")) { on_heartbeat(d, link, doc); return; }
    if (aj_str_eq(doc, t, "session")) { on_session(d, link, doc); return; }
    if (aj_str_eq(doc, t, "auth_challenge")) { on_auth_challenge(d, link, doc); return; }
    if (aj_str_eq(doc, t, "pair_begin")) { on_pair_begin(d, link, doc); return; }
    if (aj_str_eq(doc, t, "tlm_ack")) {
        int64_t s;
        if (aj_int(doc, aj_get(doc, 0, "seq"), &s) && s >= 0 && s <= 0xFFFFFFFFll) L->acked_seq = (uint32_t)s;
        return;
    }
    if (aj_str_eq(doc, t, "tlm_resume")) {
        char sess[40];
        int64_t after;
        if (!get_token(doc, 0, "session", sess, sizeof sess, 1) || !aj_int(doc, aj_get(doc, 0, "after"), &after) || after < 0 || after > 0xFFFFFFFFll) {
            link_error(d, link, "tlm_resume: session and after (integer ≥ 0) required", 0);
            return;
        }
        if (!au_streq(sess, d->tlm_session)) {
            char b[200];
            aw_t w;
            aw_init(&w, b, sizeof b);
            aw_obj(&w); aw_kstr(&w, "kind", "tlm_gap"); aw_kstr(&w, "session", sess); aw_kstr(&w, "reason", "session-ended");
            aw_kstr(&w, "current", d->tlm_session); aw_end_obj(&w);
            send_w(d, link, &w);
            return;
        }
        dev_tlm_resume(d, link, (uint32_t)after);
        return;
    }
    L->rx.bad_message++;
    link_error(d, link, "unknown message type", 0);
}

static void process_line(aeris_dev_t *d, int link, uint8_t *buf, size_t len) {
    aeris_link_t *L = &d->link[link];
    aj_doc_t doc;
    uint32_t want = 0;
    size_t i, n;
    int r;
    if (len && buf[len - 1] == '\r') len--;
    if (!len) return;
    L->rx.lines++;
    if (len < 10 || buf[len - 9] != '\t') { L->rx.bad_message++; link_error(d, link, "unframed line (expected <json>\\t<crc32 hex>)", 0); return; }
    for (i = len - 8; i < len; i++) {
        uint8_t c = buf[i];
        int v = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : -1;
        if (v < 0) { L->rx.bad_message++; link_error(d, link, "frame: the CRC must be 8 lower-case hex digits", 0); return; }
        want = (want << 4) | (uint32_t)v;
    }
    n = len - 9;
    if (au_crc32(buf, n) != want) { L->rx.bad_crc++; link_error(d, link, "frame: CRC mismatch (line dropped)", 0); return; }
    buf[n] = 0;
    r = aj_parse(&doc, (const char *)buf, n, d->tok, (int)(sizeof d->tok / sizeof d->tok[0]));
    if (r < 0) {
        L->rx.not_json++;
        link_error(d, link, r == -3 ? "message: a key occurs twice (refused)" : r == -2 ? "message: not a JSON object" : "message: not valid JSON (or too many tokens)", 0);
        return;
    }
    link_handle(d, link, &doc);
}

void aeris_link_input(aeris_dev_t *d, int link, const uint8_t *data, size_t n) {
    aeris_rx_t *R;
    size_t i;
    if (link < 0 || link >= AERIS_LINKS || !d->link[link].up) return;
    R = &d->link[link].rx;
    for (i = 0; i < n; i++) {
        uint8_t c = data[i];
        if (c == '\n') {
            if (R->discarding) { R->discarding = false; R->too_long++; link_error(d, link, "line too long (dropped)", 0); }
            else process_line(d, link, R->buf, R->len);
            R->len = 0;
        } else if (!R->discarding) {
            if (R->len >= AERIS_MAX_LINE) R->discarding = true;
            else R->buf[R->len++] = c;
        }
    }
}

void aeris_link_up(aeris_dev_t *d, int link) {
    aeris_link_t *L;
    if (link < 0 || link >= AERIS_LINKS) return;
    L = &d->link[link];
    au_memset(L, 0, sizeof *L);
    L->up = true;
    L->last_seq = -1;
}

void aeris_link_down(aeris_dev_t *d, int link) {
    aeris_link_t *L;
    if (link < 0 || link >= AERIS_LINKS) return;
    L = &d->link[link];
    if (!L->up) return;
    drop_session(d, link, "link closed");
    if (d->exp_active && d->exp_link == link && !d->link_lost) { d->link_lost = true; d->link_lost_at = now_us(d); }
    if (d->pair_pending && d->pair_link == link) d->pair_pending = false;
    L->up = false;
    L->active = false;
    L->authed = false;
    L->tx_len = 0;
    L->rx.len = 0;
    L->rx.discarding = false;
    dev_send_state(d);      /* to the other link, if any */
}

/* ------------------------------------------------------------------------------------------------ service */
void aeris_service(aeris_dev_t *d) {
    uint64_t now = now_us(d);
    int i;
    for (i = 0; i < AERIS_LINKS; i++) {
        aeris_link_t *L = &d->link[i];
        if (!L->up) continue;
        flush(d, i);
        if (L->has_session && now - L->last_heartbeat_us > AERIS_LINK_TIMEOUT_US) {
            /* drop first, then tell the host: a host that answers at once with a new session (synchronously, as the
             * browser's synthetic transport could) must find the old one already gone, not have its new one dropped */
            char b[200], sid[sizeof L->session];
            aw_t w;
            au_strlcpy(sid, L->session, sizeof sid);
            drop_session(d, i, "supervisor link lost (no heartbeat)");
            aw_init(&w, b, sizeof b);
            aw_obj(&w); aw_kstr(&w, "kind", "session_expired"); aw_kstr(&w, "link_session", sid);
            aw_kstr(&w, "reason", "no heartbeat within 1.5 s"); aw_end_obj(&w);
            send_w(d, i, &w);
        }
        if (L->active) dev_tlm_service(d, i);
    }
    cmd_service(d);
    if (d->pair_pending && now >= d->pair_deadline_us) link_pair_cancel(d, "no local confirmation within 60 s");
    if (d->identify_until_us && now >= d->identify_until_us) { d->identify_until_us = 0; if (d->hal->led) d->hal->led(d->hal->ctx, (int)d->state); }
    if (now - d->state_sent_us >= AERIS_STATE_PERIOD_US) dev_send_state(d);
    if (d->reboot_at_us && now >= d->reboot_at_us) {
        bool flushed = true;
        for (i = 0; i < AERIS_LINKS; i++) if (d->link[i].up && d->link[i].tx_len) flushed = false;
        if (flushed || now >= d->reboot_at_us + 500000u) {
            d->reboot_at_us = 0;
            dev_drivers_idle(d);
            if (d->hal->motor_power) d->hal->motor_power(d->hal->ctx, false);
            if (d->hal->reboot) d->hal->reboot(d->hal->ctx, d->reboot_bootloader);
        }
    }
}

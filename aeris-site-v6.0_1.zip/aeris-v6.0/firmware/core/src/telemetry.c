/* AERIS firmware core — telemetry in the reference contract aeris-telemetry-ndjson/1 (site/docs/TELEMETRY.md §2).
 *
 * The device sends contract messages ("type": hello / frame / bye) on every active link, so a host can forward them
 * to the backend's existing ingest unchanged. One telemetry session per device: a new one after every boot and after
 * every applied configuration (the mode is fixed per session); frames carry a contiguous seq. The last AERIS_TLM_RING
 * frames are kept so a host that missed some (a full transport buffer, a reconnection) can ask for them again
 * (tlm_resume); what the ring no longer holds is reported as a tlm_gap, never filled in.
 *
 * Nothing is fabricated: no telemetry session exists before an approved configuration is applied (until then the
 * body axes — the contract's frame — are not known: imu.to_body comes with the configuration); no frame is produced
 * without a valid attitude estimate; wheel speeds are included only while every driver reports fresh encoder
 * estimates, measured torques only while every driver reports fresh torque estimates. The attitude is the device's
 * ESTIMATE (cf3d), labelled as such in the hello. */
#include "aeris/device.h"
#include "aeris/json.h"
#include "aeris/util.h"

#define RPM_PER_RADS 9.549296585513721
#define FRESH_ENC_US 100000u
#define FRESH_TORQUE_US 500000u
#define RESUME_PER_SERVICE 8

enum { TS_OK = 0, TS_IDLE, TS_CAL, TS_FAULT, TS_ESTOP };
static const char *TS_NAMES[] = {"ok", "idle", "calibrating", "fault", "estop"};
enum { TM_EDGE = 0, TM_CORNER, TM_FREE };
static const char *TM_NAMES[] = {"edge", "corner", "free"};

static uint64_t now_us(const aeris_dev_t *d) { return d->hal->time_us(d->hal->ctx); }

static int tlm_mode(const aeris_dev_t *d) { return !d->cfg.valid ? TM_FREE : d->cfg.mode == MODE_EDGE ? TM_EDGE : TM_CORNER; }

void dev_tlm_hello(aeris_dev_t *d, int link) {
    aeris_link_t *L = &d->link[link];
    char fw[64];
    size_t n;
    aw_t w;
    if (!L->up || !L->active || !L->tlm_on || !d->cfg.valid || d->tlm_hz <= 0) return;
    n = au_strlcpy(fw, AERIS_FW_NAME " " AERIS_FW_VERSION " (", sizeof fw);
    au_strlcpy(fw + n, AERIS_BUILD_ID, sizeof fw - n);
    n = au_strlen(fw);
    au_strlcpy(fw + n, ")", sizeof fw - n);
    aw_init(&w, d->line, sizeof d->line);
    aw_obj(&w);
    aw_kstr(&w, "type", "hello");
    aw_kstr(&w, "protocol", AERIS_TLM_PROTOCOL);
    aw_key(&w, "device"); aw_obj(&w);
    aw_kstr(&w, "id", d->device_id); aw_kstr(&w, "kind", d->board->device_kind); aw_kstr(&w, "firmware", fw);
    aw_end_obj(&w);
    aw_kbool(&w, "synthetic", d->board->synthetic);
    aw_kstr(&w, "mode", TM_NAMES[tlm_mode(d)]);
    if (d->tlm_hz > 0) aw_kint(&w, "nominal_rate_hz", d->tlm_hz);
    aw_key(&w, "conventions"); aw_obj(&w);
    aw_kstr(&w, "quaternion", "w,x,y,z; body to world; Hamilton product");
    aw_kstr(&w, "body_axes", "x, y, z along the cube edges from the pivot corner");
    aw_kstr(&w, "world_axes", "z up");
    aw_kstr(&w, "time", "seconds since the session start (monotonic)");
    aw_end_obj(&w);
    aw_kstr(&w, "session", d->tlm_session);
    aw_kstr(&w, "boot_id", d->boot_id);
    if (d->cfg.valid) aw_kstr(&w, "config_hash", d->cfg.hash_hex); else aw_knull(&w, "config_hash");
    aw_kstr(&w, "attitude", "estimated on the device (cf3d complementary filter); not ground truth");
    aw_end_obj(&w);
    if (aw_done(&w) && dev_send(d, link, w.buf, w.len)) L->tlm_hello_sent = true;
}

static void send_bye(aeris_dev_t *d, int link, const char *reason) {
    char b[200];
    aw_t w;
    aw_init(&w, b, sizeof b);
    aw_obj(&w); aw_kstr(&w, "type", "bye"); aw_kstr(&w, "session", d->tlm_session); aw_kstr(&w, "reason", reason); aw_end_obj(&w);
    if (aw_done(&w)) dev_send(d, link, w.buf, w.len);
}

void dev_tlm_new_session(aeris_dev_t *d) {
    int i;
    char num[12];
    size_t n;
    for (i = 0; i < AERIS_LINKS; i++) {
        aeris_link_t *L = &d->link[i];
        if (L->up && L->active && L->tlm_hello_sent) send_bye(d, i, "new telemetry session");
        L->tlm_hello_sent = false;
        L->resuming = false;
    }
    d->tlm_session_n++;
    n = au_strlcpy(d->tlm_session, d->boot_id, sizeof d->tlm_session);
    if (n + 1 < sizeof d->tlm_session) { d->tlm_session[n] = '-'; d->tlm_session[n + 1] = 0; }
    au_fmt_uint(num, sizeof num, d->tlm_session_n);
    n = au_strlen(d->tlm_session);
    au_strlcpy(d->tlm_session + n, num, sizeof d->tlm_session - n);
    d->tlm_seq = 0;
    d->ring_head = d->ring_count = 0;
    d->tlm_div_count = 0;
    d->tlm_start_us = now_us(d);
    for (i = 0; i < AERIS_LINKS; i++) if (d->link[i].up && d->link[i].active) dev_tlm_hello(d, i);
}

static size_t frame_json(const aeris_tlm_frame_t *f, char *buf, size_t cap) {
    aw_t w;
    aw_init(&w, buf, cap);
    aw_obj(&w);
    aw_kstr(&w, "type", "frame");
    aw_knum(&w, "t", f->t, 9);
    aw_kuint(&w, "seq", f->seq);
    aw_kstr(&w, "mode", TM_NAMES[f->mode]);
    aw_key(&w, "q"); aw_vecf(&w, f->q, 4, 7);
    if (f->has_theta) aw_knum(&w, "theta", f->theta, 7);
    aw_key(&w, "w"); aw_vecf(&w, f->w, 3, 6);
    if (f->has_rpm) { aw_key(&w, "wheel_rpm"); aw_vecf(&w, f->wheel_rpm, 3, 6); }
    aw_key(&w, "torque_cmd"); aw_vecf(&w, f->torque_cmd, 3, 5);
    if (f->has_meas) { aw_key(&w, "torque_meas"); aw_vecf(&w, f->torque_meas, 3, 5); }
    aw_key(&w, "imu"); aw_obj(&w);
    aw_key(&w, "gyro"); aw_vecf(&w, f->gyro, 3, 6);
    aw_key(&w, "accel"); aw_vecf(&w, f->accel, 3, 6);
    aw_end_obj(&w);
    aw_kstr(&w, "status", TS_NAMES[f->status]);
    aw_end_obj(&w);
    return aw_done(&w) ? w.len : 0;
}

static uint8_t status_of(const aeris_dev_t *d) {
    switch (d->state) {
    case ST_BALANCING: case ST_STOPPING: return TS_OK;
    case ST_COMMISSIONING: return d->motor_test_until_us ? TS_OK : TS_IDLE;
    case ST_CALIBRATING: case ST_SELF_TEST: return TS_CAL;
    case ST_FAULT: return (d->latched & F_ESTOP) ? TS_ESTOP : TS_FAULT;
    default: return TS_IDLE;
    }
}

void dev_tlm_step(aeris_dev_t *d) {
    aeris_tlm_frame_t *f;
    uint64_t now;
    int div, i;
    bool rpm = true, meas = true;
    char buf[640];
    size_t n;
    if (d->tlm_hz <= 0 || !d->cfg.valid) return;
    div = (d->cfg.control_hz > 0 ? d->cfg.control_hz : 500) / d->tlm_hz;
    if (div < 1) div = 1;
    if (++d->tlm_div_count < (uint32_t)div) return;
    d->tlm_div_count = 0;
    if (!d->est_valid) return;                       /* no estimate: no frame (nothing is fabricated) */
    now = now_us(d);
    for (i = 0; i < AERIS_NW; i++) {
        const odrv_t *m = &d->drv[i];
        if (!m->seen || !m->t_encoder_us || now - m->t_encoder_us > FRESH_ENC_US) rpm = false;
        if (!m->seen || !m->t_torque_us || now - m->t_torque_us > FRESH_TORQUE_US) meas = false;
    }
    f = &d->ring[d->ring_head];
    f->t = (double)(now - d->tlm_start_us) * 1e-6;
    f->seq = ++d->tlm_seq;
    f->mode = (uint8_t)tlm_mode(d);
    au_memcpy(f->q, d->q, sizeof f->q);
    f->has_theta = f->mode == TM_EDGE;
    f->theta = d->theta;
    au_memcpy(f->w, d->w, sizeof f->w);
    f->has_rpm = rpm;
    f->has_meas = meas;
    for (i = 0; i < 3; i++) {
        f->wheel_rpm[i] = (float)((double)d->omega[i] * RPM_PER_RADS);
        f->torque_cmd[i] = d->torque_cmd[i];
        f->torque_meas[i] = d->torque_meas[i];
    }
    au_memcpy(f->gyro, d->gyro, sizeof f->gyro);
    au_memcpy(f->accel, d->accel, sizeof f->accel);
    f->status = status_of(d);
    d->ring_head = (d->ring_head + 1) % AERIS_TLM_RING;
    if (d->ring_count < AERIS_TLM_RING) d->ring_count++;
    n = frame_json(f, buf, sizeof buf);
    if (!n) return;
    for (i = 0; i < AERIS_LINKS; i++) {
        aeris_link_t *L = &d->link[i];
        if (!L->up || !L->active || !L->tlm_on) continue;
        if (!L->tlm_hello_sent) { dev_tlm_hello(d, i); if (!L->tlm_hello_sent) continue; }
        if (dev_tx_room(d, i, n, true)) dev_send(d, i, buf, n);
        else L->tx_dropped_tlm++;                    /* the host sees the seq gap and may ask for it again */
    }
}

static uint32_t oldest_seq(const aeris_dev_t *d) { return d->ring_count ? d->tlm_seq - d->ring_count + 1 : d->tlm_seq + 1; }

static void send_gap(aeris_dev_t *d, int link, uint32_t from, uint32_t to, const char *reason) {
    char b[240];
    aw_t w;
    aw_init(&w, b, sizeof b);
    aw_obj(&w); aw_kstr(&w, "kind", "tlm_gap"); aw_kstr(&w, "session", d->tlm_session);
    aw_kuint(&w, "from", from); aw_kuint(&w, "to", to); aw_kstr(&w, "reason", reason); aw_end_obj(&w);
    if (aw_done(&w)) dev_send(d, link, w.buf, w.len);
}

void dev_tlm_resume(aeris_dev_t *d, int link, uint32_t after) {
    aeris_link_t *L = &d->link[link];
    uint32_t start = after + 1, old = oldest_seq(d);
    if (after >= d->tlm_seq) {                          /* nothing missing */
        L->resuming = true; L->resume_next = d->tlm_seq + 1; L->resume_end = d->tlm_seq;
        dev_tlm_service(d, link);
        return;
    }
    if (start < old) { send_gap(d, link, start, old - 1, "no longer kept on the device (ring overwritten)"); start = old; }
    L->resuming = true;
    L->resume_next = start;
    L->resume_end = d->tlm_seq;
    dev_tlm_service(d, link);
}

void dev_tlm_service(aeris_dev_t *d, int link) {
    aeris_link_t *L = &d->link[link];
    char buf[640];
    int k = 0;
    if (!L->resuming) return;
    while (L->resume_next <= L->resume_end && k < RESUME_PER_SERVICE) {
        uint32_t s = L->resume_next, old = oldest_seq(d), back;
        size_t n;
        if (s < old) { send_gap(d, link, s, L->resume_end < old - 1 ? L->resume_end : old - 1, "overwritten while being resent"); L->resume_next = old; continue; }
        back = d->tlm_seq - s;                           /* 0 = newest */
        n = frame_json(&d->ring[(d->ring_head + AERIS_TLM_RING - 1 - back) % AERIS_TLM_RING], buf, sizeof buf);
        if (!n || !dev_tx_room(d, link, n, true)) return;   /* continue on the next service call */
        dev_send(d, link, buf, n);
        L->resume_next++;
        k++;
    }
    if (L->resume_next > L->resume_end) {
        char b[200];
        aw_t w;
        L->resuming = false;
        aw_init(&w, b, sizeof b);
        aw_obj(&w); aw_kstr(&w, "kind", "tlm_resumed"); aw_kstr(&w, "session", d->tlm_session); aw_kuint(&w, "through", L->resume_end); aw_end_obj(&w);
        if (aw_done(&w)) dev_send(d, link, w.buf, w.len);
    }
}

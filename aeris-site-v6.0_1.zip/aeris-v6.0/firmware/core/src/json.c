/* AERIS firmware core — JSON reading and writing (see json.h). jsmn is compiled here, in strict mode. */
#define JSMN_STRICT
#include "../third_party/jsmn/jsmn.h"
#include "aeris/json.h"
#include "aeris/util.h"

int aj_skip(const aj_doc_t *d, int i) {
    int pending = 1;
    while (pending > 0 && i < d->n) {
        const jsmntok_t *t = &d->t[i];
        pending--;
        if (t->type == JSMN_OBJECT) pending += 2 * t->size;
        else if (t->type == JSMN_ARRAY) pending += t->size;
        i++;
    }
    return i;
}

static bool key_eq_tok(const aj_doc_t *d, int a, int b) {
    const jsmntok_t *x = &d->t[a], *y = &d->t[b];
    int n = x->end - x->start;
    return n == y->end - y->start && au_memcmp(d->js + x->start, d->js + y->start, (size_t)n) == 0;
}

/* every object: no key twice (compared on the raw key text; escaped spellings of one key are refused anyway because
 * the device never accepts keys with escapes, see aj_get) */
static bool unique_keys(const aj_doc_t *d) {
    int i;
    for (i = 0; i < d->n; i++) {
        if (d->t[i].type == JSMN_OBJECT) {
            int k, j = i + 1, keys[64], nk = 0;
            for (k = 0; k < d->t[i].size; k++) {
                int a;
                if (j >= d->n || d->t[j].type != JSMN_STRING) return false;
                if (nk >= 64) return false;                       /* objects of the device protocol are small */
                for (a = 0; a < nk; a++) if (key_eq_tok(d, keys[a], j)) return false;
                keys[nk++] = j;
                j = aj_skip(d, j + 1);
            }
        }
    }
    return true;
}

int aj_parse(aj_doc_t *d, const char *js, size_t len, jsmntok_t *toks, int cap) {
    jsmn_parser p;
    int n;
    d->js = js; d->len = len; d->t = toks; d->n = 0;
    jsmn_init(&p);
    n = jsmn_parse(&p, js, len, toks, (unsigned int)cap);
    if (n < 1) return -1;
    d->n = n;
    if (toks[0].type != JSMN_OBJECT) return -2;
    if (aj_skip(d, 0) != n) return -1;                  /* exactly one value */
    if (!unique_keys(d)) return -3;
    return n;
}

int aj_get(const aj_doc_t *d, int obj, const char *key) {
    int k, j;
    if (obj < 0 || obj >= d->n || d->t[obj].type != JSMN_OBJECT) return -1;
    j = obj + 1;
    for (k = 0; k < d->t[obj].size; k++) {
        const jsmntok_t *t = &d->t[j];
        if (t->type == JSMN_STRING && au_strneq(d->js + t->start, (size_t)(t->end - t->start), key)) return j + 1;
        j = aj_skip(d, j + 1);
    }
    return -1;
}

bool aj_is(const aj_doc_t *d, int i, jsmntype_t type) { return i >= 0 && i < d->n && d->t[i].type == type; }

bool aj_is_null(const aj_doc_t *d, int i) {
    return aj_is(d, i, JSMN_PRIMITIVE) && d->t[i].end - d->t[i].start == 4 && d->js[d->t[i].start] == 'n';
}

static int hexv(char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1; }

bool aj_str(const aj_doc_t *d, int i, char *out, size_t cap) {
    const char *s;
    int a, b;
    size_t o = 0;
    if (!aj_is(d, i, JSMN_STRING) || cap == 0) return false;
    s = d->js; a = d->t[i].start; b = d->t[i].end;
    while (a < b) {
        unsigned c = (unsigned char)s[a++];
        if (c < 0x20) return false;
        if (c == '\\') {
            if (a >= b) return false;
            c = (unsigned char)s[a++];
            switch (c) {
            case '"': case '\\': case '/': break;
            case 'b': c = 8; break;
            case 'f': c = 12; break;
            case 'n': c = 10; break;
            case 'r': c = 13; break;
            case 't': c = 9; break;
            case 'u': {
                int h0, h1, h2, h3;
                unsigned cp;
                if (a + 4 > b) return false;
                h0 = hexv(s[a]); h1 = hexv(s[a + 1]); h2 = hexv(s[a + 2]); h3 = hexv(s[a + 3]);
                if (h0 < 0 || h1 < 0 || h2 < 0 || h3 < 0) return false;
                cp = (unsigned)((h0 << 12) | (h1 << 8) | (h2 << 4) | h3);
                a += 4;
                if (cp == 0 || (cp >= 0xD800 && cp <= 0xDFFF)) return false;   /* no NUL, no surrogates in device strings */
                if (cp < 0x80) { if (o + 1 >= cap) return false; out[o++] = (char)cp; }
                else if (cp < 0x800) { if (o + 2 >= cap) return false; out[o++] = (char)(0xC0 | (cp >> 6)); out[o++] = (char)(0x80 | (cp & 63)); }
                else { if (o + 3 >= cap) return false; out[o++] = (char)(0xE0 | (cp >> 12)); out[o++] = (char)(0x80 | ((cp >> 6) & 63)); out[o++] = (char)(0x80 | (cp & 63)); }
                continue;
            }
            default: return false;
            }
        }
        if (o + 1 >= cap) return false;
        out[o++] = (char)c;
    }
    out[o] = 0;
    return true;
}

bool aj_str_eq(const aj_doc_t *d, int i, const char *s) {
    return aj_is(d, i, JSMN_STRING) && au_strneq(d->js + d->t[i].start, (size_t)(d->t[i].end - d->t[i].start), s);
}

bool aj_num(const aj_doc_t *d, int i, double *v) {
    char c;
    if (!aj_is(d, i, JSMN_PRIMITIVE)) return false;
    c = d->js[d->t[i].start];
    if (c != '-' && (c < '0' || c > '9')) return false;
    return au_parse_double(d->js + d->t[i].start, (size_t)(d->t[i].end - d->t[i].start), v);
}

bool aj_int(const aj_doc_t *d, int i, int64_t *v) {
    if (!aj_is(d, i, JSMN_PRIMITIVE)) return false;
    return au_parse_int(d->js + d->t[i].start, (size_t)(d->t[i].end - d->t[i].start), v);
}

bool aj_bool(const aj_doc_t *d, int i, bool *v) {
    if (!aj_is(d, i, JSMN_PRIMITIVE)) return false;
    if (au_strneq(d->js + d->t[i].start, (size_t)(d->t[i].end - d->t[i].start), "true")) { *v = true; return true; }
    if (au_strneq(d->js + d->t[i].start, (size_t)(d->t[i].end - d->t[i].start), "false")) { *v = false; return true; }
    return false;
}

int aj_arr_len(const aj_doc_t *d, int i) { return aj_is(d, i, JSMN_ARRAY) ? d->t[i].size : -1; }

int aj_arr_at(const aj_doc_t *d, int i, int k) {
    int j, m;
    if (!aj_is(d, i, JSMN_ARRAY) || k < 0 || k >= d->t[i].size) return -1;
    j = i + 1;
    for (m = 0; m < k; m++) j = aj_skip(d, j);
    return j;
}

bool aj_vecf(const aj_doc_t *d, int i, float *out, int n) {
    int k, j;
    if (aj_arr_len(d, i) != n) return false;
    j = i + 1;
    for (k = 0; k < n; k++) {
        double v;
        if (!aj_num(d, j, &v)) return false;
        out[k] = (float)v;
        if (!au_isfinitef(out[k])) return false;
        j = aj_skip(d, j);
    }
    return true;
}

bool aj_raw(const aj_doc_t *d, int i, const char **p, size_t *len) {
    int a, b;
    if (i < 0 || i >= d->n) return false;
    a = d->t[i].start; b = d->t[i].end;
    if (d->t[i].type == JSMN_STRING) { a -= 1; b += 1; }          /* include the quotes */
    *p = d->js + a; *len = (size_t)(b - a);
    return true;
}

/* ------------------------------------------------------------------------------------------------ writer */
static void put(aw_t *w, const char *s, size_t n) {
    if (w->err) return;
    if (w->len + n + 1 > w->cap) { w->err = true; return; }
    au_memcpy(w->buf + w->len, s, n);
    w->len += n;
    w->buf[w->len] = 0;
}
static void put_c(aw_t *w, char c) { put(w, &c, 1); }

static void sep(aw_t *w) {
    if (w->after_key) { w->after_key = false; return; }
    if (w->depth > 0) { if (w->count[w->depth - 1] > 0) put_c(w, ','); w->count[w->depth - 1]++; }
}

void aw_init(aw_t *w, char *buf, size_t cap) {
    w->buf = buf; w->cap = cap; w->len = 0; w->err = cap == 0; w->depth = 0; w->after_key = false;
    if (cap) buf[0] = 0;
}
static void open_(aw_t *w, char c) {
    sep(w);
    put_c(w, c);
    if (w->depth >= AW_MAX_DEPTH) { w->err = true; return; }
    w->count[w->depth++] = 0;
}
static void close_(aw_t *w, char c) {
    if (w->depth <= 0) { w->err = true; return; }
    w->depth--;
    put_c(w, c);
}
void aw_obj(aw_t *w) { open_(w, '{'); }
void aw_end_obj(aw_t *w) { close_(w, '}'); }
void aw_arr(aw_t *w) { open_(w, '['); }
void aw_end_arr(aw_t *w) { close_(w, ']'); }

static void str_body(aw_t *w, const char *s, size_t n) {
    static const char H[] = "0123456789abcdef";
    size_t i;
    put_c(w, '"');
    for (i = 0; i < n; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c == '"' || c == '\\') { char e[2] = {'\\', (char)c}; put(w, e, 2); }
        else if (c == '\n') put(w, "\\n", 2);
        else if (c == '\r') put(w, "\\r", 2);
        else if (c == '\t') put(w, "\\t", 2);
        else if (c < 0x20) { char e[6] = {'\\', 'u', '0', '0', H[c >> 4], H[c & 15]}; put(w, e, 6); }
        else put_c(w, (char)c);
    }
    put_c(w, '"');
}
void aw_key(aw_t *w, const char *k) {
    if (w->depth <= 0) { w->err = true; return; }
    sep(w);
    str_body(w, k, au_strlen(k));
    put_c(w, ':');
    w->after_key = true;
}
void aw_str(aw_t *w, const char *s) { sep(w); str_body(w, s, au_strlen(s)); }
void aw_strn(aw_t *w, const char *s, size_t n) { sep(w); str_body(w, s, au_strnlen(s, n)); }
void aw_num(aw_t *w, double v, int sig) {
    char b[48];
    size_t n = au_fmt_double(b, sizeof b, v, sig);
    if (!n) { w->err = true; return; }
    sep(w);
    put(w, b, n);
}
void aw_int(aw_t *w, int64_t v) { char b[24]; size_t n = au_fmt_int(b, sizeof b, v); sep(w); put(w, b, n); }
void aw_uint(aw_t *w, uint64_t v) { char b[24]; size_t n = au_fmt_uint(b, sizeof b, v); sep(w); put(w, b, n); }
void aw_bool(aw_t *w, bool v) { sep(w); if (v) put(w, "true", 4); else put(w, "false", 5); }
void aw_null(aw_t *w) { sep(w); put(w, "null", 4); }
void aw_raw(aw_t *w, const char *s, size_t n) { sep(w); put(w, s, n); }
void aw_vecf(aw_t *w, const float *v, int n, int sig) { int i; aw_arr(w); for (i = 0; i < n; i++) aw_num(w, (double)v[i], sig); aw_end_arr(w); }
void aw_kstr(aw_t *w, const char *k, const char *s) { aw_key(w, k); if (s) aw_str(w, s); else aw_null(w); }
void aw_knum(aw_t *w, const char *k, double v, int sig) { aw_key(w, k); aw_num(w, v, sig); }
void aw_kint(aw_t *w, const char *k, int64_t v) { aw_key(w, k); aw_int(w, v); }
void aw_kuint(aw_t *w, const char *k, uint64_t v) { aw_key(w, k); aw_uint(w, v); }
void aw_kbool(aw_t *w, const char *k, bool v) { aw_key(w, k); aw_bool(w, v); }
void aw_knull(aw_t *w, const char *k) { aw_key(w, k); aw_null(w); }
bool aw_done(aw_t *w) { return !w->err && w->depth == 0; }

/* AERIS firmware core — measurement tasks and local confirmations (run inside the control step).
 *
 *   self_test        3 s, drivers powered and idle: IMU presence and data, gravity magnitude, stillness, estimate,
 *                    configuration, each wheel driver (heartbeat, no error, encoder estimates), bus voltage, loop timing,
 *                    local stop. READY only when every required check passes, a configuration is applied and the build
 *                    may drive motors.
 *   calibrate_imu    gyroscope bias: mean and spread of the raw (sensor-frame) readings while the cube is still.
 *   calibrate_axes   gravity direction in the sensor frame with the cube resting on a known face; a host combines two or
 *                    more of these into imu.to_body.
 *   check_encoders   drivers powered and idle: encoder estimates while a person turns each wheel by hand.
 * The device MEASURES; it never decides that a calibration is good enough to use. Hosts record the results as an
 * immutable calibration revision and the backend builds the next approved configuration from it.
 *
 * Local confirmations (the ARM control on the cube): a press confirms a pairing or an unpairing; ARMED + a waiting
 * start_experiment starts the experiment; a long press (2 s) in FAULT clears the latched faults when their causes are
 * gone (with or without a waiting clear_faults command). */
#include "aeris/device.h"
#include "aeris/json.h"
#include "aeris/util.h"

#define DRV_FRESH_US 300000u
#define ENC_FRESH_US 50000u
#define SELF_TEST_STILL_GYRO 0.05     /* rad/s, norm of the per-axis standard deviations */
#define SELF_TEST_STILL_ACCEL 0.3     /* m/s² */
#define CAL_STILL_GYRO 0.02
#define CAL_STILL_ACCEL 0.15
#define GRAVITY_TOL 0.6               /* m/s² */

static uint64_t now_us(const aeris_dev_t *d) { return d->hal->time_us(d->hal->ctx); }

void task_begin(aeris_dev_t *d, int task, int sub, int link, const char *cmd, uint32_t duration_ms, const char *label) {
    uint64_t now = now_us(d);
    int i;
    d->task = task;
    d->task_sub = sub;
    d->task_link = link;
    au_strlcpy(d->task_cmd, cmd, sizeof d->task_cmd);
    au_strlcpy(d->task_label, label ? label : "", sizeof d->task_label);
    d->task_n = 0;
    d->task_start_us = now;
    d->task_until_us = now + (uint64_t)duration_ms * 1000u;
    for (i = 0; i < 3; i++) {
        d->acc_g[i] = d->acc_g2[i] = d->acc_a[i] = d->acc_a2[i] = 0;
        d->enc_pos_min[i] = d->enc_vel_min[i] = 1e30f;
        d->enc_pos_max[i] = d->enc_vel_max[i] = -1e30f;
        d->enc_updates[i] = 0;
        d->enc_last_t[i] = d->drv[i].t_encoder_us;
    }
    d->acc_t = 0;
    d->st_imu_fresh = d->st_imu_reads = 0;
    d->task_return = ST_DISARMED;
    d->overrun_run = 0;
    {   /* remember the overrun count at the start (self-test loop-timing check) */
        d->task_n = d->overruns;
    }
    dev_set_state(d, task == TASK_SELF_TEST ? ST_SELF_TEST : ST_CALIBRATING,
                  task == TASK_SELF_TEST ? "self-test running (drivers powered, no torque)"
                  : task == TASK_ENCODERS ? "encoder check running (drivers powered, no torque)"
                                          : "measuring (motors unpowered)");
}

/* ------------------------------------------------------------------------------------------------ small text helpers */
typedef struct { char *b; size_t cap, n; } tb_t;
static void tb_s(tb_t *t, const char *s) { if (t->n < t->cap) t->n += au_strlcpy(t->b + t->n, s, t->cap - t->n); if (t->n >= t->cap) t->n = t->cap - 1; }
static void tb_f(tb_t *t, double x, int sig) { if (t->n < t->cap) { size_t k = au_fmt_double(t->b + t->n, t->cap - t->n, x, sig); t->n += k; t->b[t->n] = 0; } }
static void tb_i(tb_t *t, int64_t x) { if (t->n < t->cap) { size_t k = au_fmt_int(t->b + t->n, t->cap - t->n, x); t->n += k; t->b[t->n] = 0; } }

static void stats(const double s[3], const double s2[3], double n, double mean[3], double sd[3]) {
    int i;
    for (i = 0; i < 3; i++) {
        double m = n > 0 ? s[i] / n : 0, v = n > 1 ? (s2[i] - n * m * m) / (n - 1) : 0;
        mean[i] = m;
        sd[i] = v > 0 ? au_sqrt(v) : 0;
    }
}
static double norm3(const double v[3]) { return au_sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); }
static void vec3d(aw_t *w, const char *k, const double v[3], int sig) { int i; aw_key(w, k); aw_arr(w); for (i = 0; i < 3; i++) aw_num(w, v[i], sig); aw_end_arr(w); }

static void check(aw_t *w, const char *name, bool ok, bool required, const char *detail, bool *all) {
    aw_obj(w); aw_kstr(w, "name", name); aw_kbool(w, "ok", ok); aw_kbool(w, "required", required); aw_kstr(w, "detail", detail); aw_end_obj(w);
    if (required && !ok) *all = false;
}

/* ------------------------------------------------------------------------------------------------ self-test */
static void self_test_step(aeris_dev_t *d, uint64_t now) {
    int i;
    aw_t w;
    bool all = true, ready, any;
    char det[120];
    tb_t t;
    double mg[3], sg[3], ma[3], sa[3], n, expect, odr_ratio, gref = d->cfg.g > 0 ? (double)d->cfg.g : 9.80665;
    uint32_t overruns;
    const char *failed_names[16];
    int nf = 0;
    d->st_imu_reads++;
    if (d->imu_fresh) {
        for (i = 0; i < 3; i++) {
            d->acc_g[i] += (double)d->gyro[i]; d->acc_g2[i] += (double)d->gyro[i] * (double)d->gyro[i];
            d->acc_a[i] += (double)d->accel[i]; d->acc_a2[i] += (double)d->accel[i] * (double)d->accel[i];
        }
        d->st_imu_fresh++;
    }
    if (now < d->task_until_us) return;
    n = (double)d->st_imu_fresh;
    stats(d->acc_g, d->acc_g2, n, mg, sg);
    stats(d->acc_a, d->acc_a2, n, ma, sa);
    overruns = d->overruns - d->task_n;
    aw_init(&w, d->res, sizeof d->res);
    aw_obj(&w);
    aw_key(&w, "checks"); aw_arr(&w);
#define CHECK(name, ok, req) do { bool _ok = (ok); check(&w, name, _ok, req, det, &all); if ((req) && !_ok && nf < 16) failed_names[nf++] = name; } while (0)
    t.b = det; t.cap = sizeof det; t.n = 0; det[0] = 0;
    { bool st = d->hal->stop_input && d->hal->stop_input(d->hal->ctx); tb_s(&t, st ? "the local stop is asserted" : "the local stop is released"); CHECK("local_stop_released", !st, true); }
    t.n = 0; det[0] = 0;
    if (d->imu_ok) { tb_s(&t, "LSM6DSOX answers at 0x"); { char hx[3]; uint8_t a = d->imu.addr; au_fmt_hex(hx, sizeof hx, &a, 1); tb_s(&t, hx); } tb_s(&t, " (WHO_AM_I 0x6c)"); }
    else tb_s(&t, "no LSM6DSOX detected on I2C");
    CHECK("imu_present", d->imu_ok, true);
    odr_ratio = d->cfg.imu_odr_hz > 0 && d->cfg.control_hz > 0 ? (double)d->cfg.imu_odr_hz / (double)d->cfg.control_hz : 1.0;
    if (odr_ratio > 1.0) odr_ratio = 1.0;
    expect = (double)d->st_imu_reads * odr_ratio;
    t.n = 0; det[0] = 0; tb_i(&t, (int64_t)d->st_imu_fresh); tb_s(&t, " fresh samples in "); tb_i(&t, (int64_t)d->st_imu_reads); tb_s(&t, " control steps");
    CHECK("imu_data", d->imu_ok && n >= 0.5 * expect && n > 10, true);
    t.n = 0; det[0] = 0;
    if (n > 10) { tb_s(&t, "|a| = "); tb_f(&t, norm3(ma), 4); tb_s(&t, " m/s² (g = "); tb_f(&t, gref, 6); tb_s(&t, ")"); }
    else tb_s(&t, "no data");
    CHECK("gravity", n > 10 && norm3(ma) > gref - GRAVITY_TOL && norm3(ma) < gref + GRAVITY_TOL, true);
    t.n = 0; det[0] = 0;
    if (n > 10) { tb_s(&t, "gyro spread "); tb_f(&t, norm3(sg), 3); tb_s(&t, " rad/s, accel spread "); tb_f(&t, norm3(sa), 3); tb_s(&t, " m/s²"); }
    else tb_s(&t, "no data");
    CHECK("still", n > 10 && norm3(sg) < SELF_TEST_STILL_GYRO && norm3(sa) < SELF_TEST_STILL_ACCEL, true);
    t.n = 0; det[0] = 0; tb_s(&t, d->est_valid ? "cf3d estimate valid" : "no valid estimate");
    CHECK("estimate", d->est_valid, true);
    t.n = 0; det[0] = 0;
    if (d->cfg.valid) { char h[13]; au_strlcpy(h, d->cfg.hash_hex, sizeof h); tb_s(&t, "applied, sha256 "); tb_s(&t, h); tb_s(&t, "…"); }
    else tb_s(&t, "no approved configuration applied");
    CHECK("configuration", d->cfg.valid, true);
    for (i = 0; i < AERIS_NW; i++) {
        const odrv_t *m = &d->drv[i];
        bool hb = m->seen && now - m->t_heartbeat_us <= DRV_FRESH_US, enc = m->t_encoder_us && now - m->t_encoder_us <= ENC_FRESH_US;
        static const char *NAMES[3] = {"driver_wheel_0", "driver_wheel_1", "driver_wheel_2"};
        t.n = 0; det[0] = 0; tb_s(&t, "CAN node "); tb_i(&t, m->node);
        if (!m->seen) tb_s(&t, ": no heartbeat seen");
        else if (!hb) tb_s(&t, ": heartbeat stale");
        else if (m->axis_error) { tb_s(&t, ": axis error 0x"); { char hx[9]; uint8_t b[4] = {(uint8_t)(m->axis_error >> 24), (uint8_t)(m->axis_error >> 16), (uint8_t)(m->axis_error >> 8), (uint8_t)m->axis_error}; au_fmt_hex(hx, sizeof hx, b, 4); tb_s(&t, hx); } }
        else if (!enc) tb_s(&t, ": no recent encoder estimates");
        else tb_s(&t, ": heartbeat, encoder estimates, no error");
        CHECK(NAMES[i], hb && !m->axis_error && enc, true);
    }
    t.n = 0; det[0] = 0;
    any = d->vbus > 0;
    if (any) { tb_f(&t, d->vbus, 4); tb_s(&t, " V"); if (d->cfg.valid) { tb_s(&t, " (limits "); tb_f(&t, d->cfg.vbus_min_V, 4); tb_s(&t, "–"); tb_f(&t, d->cfg.vbus_max_V, 4); tb_s(&t, " V)"); } }
    else tb_s(&t, "not reported by any driver");
    CHECK("bus_voltage", any && (!d->cfg.valid || (d->vbus >= d->cfg.vbus_min_V && d->vbus <= d->cfg.vbus_max_V)), true);
    t.n = 0; det[0] = 0; tb_i(&t, (int64_t)overruns); tb_s(&t, " overruns; longest step "); tb_i(&t, (int64_t)d->step_us_max); tb_s(&t, " µs of "); tb_i(&t, (int64_t)aeris_control_period_us(d)); tb_s(&t, " µs");
    CHECK("loop_timing", overruns == 0, true);
    t.n = 0; det[0] = 0; tb_s(&t, d->board->actuation_build ? "this build may drive motors" : "release build: motors are never driven (sensing, calibration and telemetry only)");
    CHECK("actuation_build", d->board->actuation_build, false);
#undef CHECK
    aw_end_arr(&w);
    ready = all && d->cfg.valid && aeris_actuation_permitted(d);
    aw_kbool(&w, "passed", all);
    aw_kbool(&w, "ready", ready);
    aw_end_obj(&w);
    d->task = TASK_NONE;
    if (ready) dev_set_state(d, ST_READY, "self-test passed: READY (press ARM on the cube to enable)");
    else dev_set_state(d, ST_DISARMED, !all ? "self-test failed" : !d->cfg.valid ? "self-test passed; no approved configuration" : "self-test passed (sensing only: this build cannot drive motors)");
    if (all) cmd_report(d, d->task_link, d->task_cmd, "cmd_result", "completed", ready ? "READY" : d->state_reason, aw_done(&w) ? d->res : 0);
    else {
        char why[200];
        tb_t r = {why, sizeof why, 0};
        int k;
        why[0] = 0;
        tb_s(&r, "failed checks:");
        for (k = 0; k < nf; k++) { tb_s(&r, " "); tb_s(&r, failed_names[k]); }
        cmd_report(d, d->task_link, d->task_cmd, "cmd_result", "failed", why, aw_done(&w) ? d->res : 0);
    }
}

/* ------------------------------------------------------------------------------------------------ IMU averaging */
static void imu_average_step(aeris_dev_t *d, uint64_t now) {
    int i;
    double n, mg[3], sg[3], ma[3], sa[3], secs, expect, odr_ratio;
    bool still, enough, grav_ok;
    aw_t w;
    const char *why = 0;
    d->st_imu_reads++;
    if (d->imu_fresh) {
        for (i = 0; i < 3; i++) {
            d->acc_g[i] += (double)d->gyro_raw[i]; d->acc_g2[i] += (double)d->gyro_raw[i] * (double)d->gyro_raw[i];
            d->acc_a[i] += (double)d->accel_raw[i]; d->acc_a2[i] += (double)d->accel_raw[i] * (double)d->accel_raw[i];
        }
        d->acc_t += (double)d->temp_c;
        d->st_imu_fresh++;
    }
    if (now < d->task_until_us) return;
    n = (double)d->st_imu_fresh;
    stats(d->acc_g, d->acc_g2, n, mg, sg);
    stats(d->acc_a, d->acc_a2, n, ma, sa);
    secs = (double)(now - d->task_start_us) * 1e-6;
    odr_ratio = d->cfg.imu_odr_hz > 0 && d->cfg.control_hz > 0 ? (double)d->cfg.imu_odr_hz / (double)d->cfg.control_hz : 1.0;
    if (odr_ratio > 1.0) odr_ratio = 1.0;
    expect = (double)d->st_imu_reads * odr_ratio;
    enough = n > 20 && n >= 0.5 * expect;
    still = norm3(sg) < CAL_STILL_GYRO && norm3(sa) < CAL_STILL_ACCEL;
    grav_ok = norm3(ma) > 9.80665 - GRAVITY_TOL && norm3(ma) < 9.80665 + GRAVITY_TOL;
    aw_init(&w, d->res, sizeof d->res);
    aw_obj(&w);
    aw_kstr(&w, "measurement", d->task_sub ? "calibrate_axes" : "calibrate_imu");
    if (d->task_label[0]) aw_kstr(&w, "face", d->task_label);
    aw_kstr(&w, "frame", "sensor (LSM6DSOX axes, before imu.to_body and gyro bias)");
    aw_knum(&w, "seconds", secs, 5);
    aw_kuint(&w, "samples", d->st_imu_fresh);
    if (n > 0) {
        vec3d(&w, "gyro_mean_radps", mg, 7); vec3d(&w, "gyro_std_radps", sg, 4);
        vec3d(&w, "accel_mean_mps2", ma, 7); vec3d(&w, "accel_std_mps2", sa, 4);
        aw_knum(&w, "accel_norm_mps2", norm3(ma), 6);
        aw_knum(&w, "temp_c", d->acc_t / n, 4);
    }
    aw_kbool(&w, "still", still);
    aw_kstr(&w, "imu", "lsm6dsox");
    aw_kint(&w, "odr_hz", d->imu.odr_hz); aw_kint(&w, "accel_range_g", d->imu.fs_g); aw_kint(&w, "gyro_range_dps", d->imu.fs_dps);
    aw_end_obj(&w);
    if (!enough) why = "too few IMU samples (check the IMU connection)";
    else if (!still) why = "the cube moved during the measurement: repeat with the cube resting still";
    else if (!grav_ok) why = "the measured gravity magnitude is not plausible (check the IMU range and mounting)";
    d->task = TASK_NONE;
    dev_set_state(d, ST_DISARMED, why ? "measurement failed" : "measurement complete (a configuration that includes it must be applied to use it)");
    cmd_report(d, d->task_link, d->task_cmd, "cmd_result", why ? "failed" : "completed", why, aw_done(&w) ? d->res : 0);
}

/* ------------------------------------------------------------------------------------------------ encoder check */
static void encoders_step(aeris_dev_t *d, uint64_t now) {
    int i;
    aw_t w;
    const char *why = 0;
    for (i = 0; i < AERIS_NW; i++) {
        const odrv_t *m = &d->drv[i];
        if (m->t_encoder_us && m->t_encoder_us != d->enc_last_t[i]) {
            float s = d->cfg.w[i].sign != 0 ? d->cfg.w[i].sign : 1.0f, v = s * m->vel_rev_s * 6.283185307179586f;
            d->enc_last_t[i] = m->t_encoder_us;
            d->enc_updates[i]++;
            if (m->pos_rev < d->enc_pos_min[i]) d->enc_pos_min[i] = m->pos_rev;
            if (m->pos_rev > d->enc_pos_max[i]) d->enc_pos_max[i] = m->pos_rev;
            if (v < d->enc_vel_min[i]) d->enc_vel_min[i] = v;
            if (v > d->enc_vel_max[i]) d->enc_vel_max[i] = v;
        }
    }
    if (now < d->task_until_us) return;
    aw_init(&w, d->res, sizeof d->res);
    aw_obj(&w);
    aw_knum(&w, "seconds", (double)(now - d->task_start_us) * 1e-6, 5);
    aw_kstr(&w, "velocity_sign", "vel_rads uses the configured wheel sign (model axis direction)");
    aw_key(&w, "wheels"); aw_arr(&w);
    for (i = 0; i < AERIS_NW; i++) {
        const odrv_t *m = &d->drv[i];
        aw_obj(&w);
        aw_kint(&w, "index", i); aw_kint(&w, "node", m->node); aw_kbool(&w, "seen", m->seen);
        aw_kbool(&w, "heartbeat", m->seen && now - m->t_heartbeat_us <= DRV_FRESH_US);
        aw_kuint(&w, "axis_error", m->axis_error);
        aw_kuint(&w, "encoder_updates", d->enc_updates[i]);
        if (d->enc_updates[i]) {
            aw_knum(&w, "pos_rev_min", d->enc_pos_min[i], 7); aw_knum(&w, "pos_rev_max", d->enc_pos_max[i], 7);
            aw_knum(&w, "travel_rev", d->enc_pos_max[i] - d->enc_pos_min[i], 6);
            aw_knum(&w, "vel_rads_min", d->enc_vel_min[i], 6); aw_knum(&w, "vel_rads_max", d->enc_vel_max[i], 6);
        }
        aw_end_obj(&w);
        if (!why && !d->enc_updates[i]) why = !m->seen ? "a wheel driver was not seen on the CAN bus" : "a wheel driver sent no encoder estimates";
    }
    aw_end_arr(&w);
    aw_end_obj(&w);
    d->task = TASK_NONE;
    dev_set_state(d, ST_DISARMED, why ? "encoder check failed" : "encoder check complete");
    cmd_report(d, d->task_link, d->task_cmd, "cmd_result", why ? "failed" : "completed", why, aw_done(&w) ? d->res : 0);
}

/* ------------------------------------------------------------------------------------------------ local confirmations */
static void do_unpair(aeris_dev_t *d) {
    uint8_t zero = 0;
    char id[41];
    au_strlcpy(id, d->wait_cmd, sizeof id);
    d->wait_unpair = false;
    if (d->hal->key_reset && d->hal->key_reset(d->hal->ctx) != 0) { cmd_report(d, d->wait_link, id, "cmd_result", "failed", "the key could not be erased", 0); return; }
    if (d->hal->nvs_set) d->hal->nvs_set(d->hal->ctx, "paired", &zero, 1);
    d->have_key = false;
    d->paired = false;
    au_memset(d->pub, 0, sizeof d->pub);
    cmd_report(d, d->wait_link, id, "cmd_result", "completed", "the device forgot its key: pair it again to connect it to an account", "{\"forgotten\":true}");
    dev_send_state(d);
}

static void clear_faults_local(aeris_dev_t *d) {
    uint32_t present = d->faults & d->latched;
    int i;
    if (present) {
        char why[200], fl[150];
        size_t n = aeris_faults_json(present, fl, sizeof fl);
        au_strlcpy(why, "the cause is still present: ", sizeof why);
        if (n) au_strlcpy(why + au_strlen(why), fl, sizeof why - au_strlen(why));
        if (d->wait_clear) { d->wait_clear = false; cmd_report(d, d->wait_link, d->wait_cmd, "cmd_result", "failed", why, 0); }
        if (d->hal->log) d->hal->log(d->hal->ctx, 2, why);
        dev_send_state(d);
        return;
    }
    for (i = 0; i < AERIS_NW; i++) if (d->drv[i].seen) odrv_clear_errors(&d->drv[i], d->hal);
    d->latched = 0;
    d->overrun_run = 0;
    dev_set_state(d, ST_DISARMED, "latched faults cleared with the local control");
    if (d->wait_clear) { d->wait_clear = false; cmd_report(d, d->wait_link, d->wait_cmd, "cmd_result", "completed", "faults cleared", 0); }
}

void task_step(aeris_dev_t *d) {
    uint64_t now = now_us(d);
    bool press = d->arm_now && !d->arm_prev;
    if (press && d->pair_pending && d->state == ST_DISARMED) { d->arm_consumed = true; press = false; link_pair_confirm(d); }
    if (press && d->wait_unpair && d->state == ST_DISARMED) { d->arm_consumed = true; press = false; do_unpair(d); }
    if (d->pair_pending && d->state != ST_DISARMED) link_pair_cancel(d, "the device left DISARMED");
    if (d->wait_start) {
        if (d->state == ST_ARMED) {
            char why[128];
            if (exp_begin(d, now, why, sizeof why)) cmd_report(d, d->exp_link, d->exp_cmd, "cmd_result", "executing", "balancing (local enable given)", 0);
            else { d->wait_start = false; cmd_report(d, d->wait_link, d->wait_cmd, "cmd_result", "failed", why, 0); }
        } else if (d->state != ST_READY) {
            d->wait_start = false;
            cmd_report(d, d->wait_link, d->wait_cmd, "cmd_result", "failed", "the device left READY before the local enable", 0);
        }
    }
    if (d->state == ST_FAULT && d->arm_now && !d->arm_consumed && now - d->arm_pressed_at >= AERIS_FAULT_CLEAR_PRESS_US) {
        d->arm_consumed = true;
        clear_faults_local(d);
    }
    switch (d->task) {
    case TASK_SELF_TEST: if (d->state == ST_SELF_TEST) self_test_step(d, now); break;
    case TASK_IMU_AVERAGE: if (d->state == ST_CALIBRATING) imu_average_step(d, now); break;
    case TASK_ENCODERS: if (d->state == ST_CALIBRATING) encoders_step(d, now); break;
    default: break;
    }
    if (d->mt_cmd[0]) {
        int k = d->motor_test_wheel;
        float om = d->omega[k] < 0 ? -d->omega[k] : d->omega[k];
        if (om > d->mt_omega_max) d->mt_omega_max = om;
        if (!d->motor_test_until_us || d->state != ST_COMMISSIONING) {
            aw_t w;
            aw_init(&w, d->res, sizeof d->res);
            aw_obj(&w);
            aw_kint(&w, "wheel", k); aw_kint(&w, "node", d->drv[k].node); aw_knum(&w, "torque_Nm", d->motor_test_torque, 5);
            aw_knum(&w, "applied_s", (double)(now - d->mt_start_us) * 1e-6, 5);
            aw_knum(&w, "omega_max_rads", d->mt_omega_max, 5);
            aw_kstr(&w, "ended", d->mt_end[0] ? d->mt_end : "ended");
            aw_end_obj(&w);
            cmd_report(d, d->mt_link, d->mt_cmd, "cmd_result", "completed", d->mt_end, aw_done(&w) ? d->res : 0);
            d->mt_cmd[0] = 0;
        }
    }
}

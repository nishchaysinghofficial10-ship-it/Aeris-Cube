/* AERIS firmware core — bounded commands (site/docs/DEVICE_LINK.md §5).
 *
 * A command is a request; the device decides. Every command carries an id (idempotency: a repeated id never executes
 * twice; the device answers with the latest status it has for it), the link session and lease epoch it belongs to, a
 * per-session sequence number (replays and reordering are refused), a time-to-live measured from its RECEIPT on the
 * device (no clock synchronisation is assumed) and, for anything that acts on the approved configuration, its SHA-256.
 *
 * Checks, in order: shape → duplicate id → session → local-session priority → lease → sequence → action → link
 * (USB-only actions) → build (actuation / commissioning) → state → parameters. Status messages: cmd_ack (accepted |
 * rejected | the cached status of a duplicate), then cmd_result (executing → completed | failed | expired).
 *
 * Nothing a host sends arms the motors: start_experiment needs the local enable (ARM pressed on the cube, in READY),
 * either before the command (ARMED, within limits.arm_window_s) or after it (before the command's ttl). stop is always
 * accepted from any session, is idempotent and only ever reduces what the motors do. */
#include "aeris/device.h"
#include "aeris/json.h"
#include "aeris/util.h"

#define S(x) (1u << (x))
#define ALL_STATES 0xFFFFFFFFu
enum { A_USB_ONLY = 1, A_OBSERVER_OK = 2, A_ACTUATION = 4, A_COMMISSIONING = 8 };

typedef struct {
    aeris_dev_t *d;
    int link;
    const char *id;
    const aj_doc_t *doc;
    int params;               /* token of the params object, -1 when absent */
    uint64_t now, deadline;
    const char *config_hash;  /* NULL when absent */
} cctx_t;

typedef const char *(*run_fn)(cctx_t *c);

typedef struct {
    const char *name;
    uint32_t states;
    unsigned flags;
    run_fn run;
} action_t;

static uint64_t now_us(const aeris_dev_t *d) { return d->hal->time_us(d->hal->ctx); }

/* ------------------------------------------------------------------------------------------------ id cache */
static aeris_cmd_cache_t *cache_find(aeris_dev_t *d, const char *id) {
    int i;
    for (i = 0; i < AERIS_CMD_CACHE; i++) if (d->cache[i].used && au_streq(d->cache[i].id, id)) return &d->cache[i];
    return 0;
}

static void cache_put(aeris_dev_t *d, const char *id, int link, const char *status, const char *reason) {
    aeris_cmd_cache_t *e = cache_find(d, id);
    if (!e) {
        e = &d->cache[d->cache_next];
        d->cache_next = (d->cache_next + 1) % AERIS_CMD_CACHE;
        au_memset(e, 0, sizeof *e);
        au_strlcpy(e->id, id, sizeof e->id);
        e->used = true;
    }
    e->link = link;
    au_strlcpy(e->status, status, sizeof e->status);
    au_strlcpy(e->reason, reason ? reason : "", sizeof e->reason);
}

/* ------------------------------------------------------------------------------------------------ messages */
static void send_ack(aeris_dev_t *d, int link, const char *id, const char *status, const char *reason, bool duplicate) {
    char b[400];
    aw_t w;
    aw_init(&w, b, sizeof b);
    aw_obj(&w); aw_kstr(&w, "kind", "cmd_ack"); aw_kstr(&w, "id", id); aw_kstr(&w, "status", status);
    if (reason && reason[0]) aw_kstr(&w, "reason", reason);
    if (duplicate) aw_kbool(&w, "duplicate", true);
    aw_kstr(&w, "state", aeris_state_name(d->state));
    aw_end_obj(&w);
    if (aw_done(&w)) dev_send(d, link, w.buf, w.len);
}

void cmd_report(aeris_dev_t *d, int link, const char *id, const char *kind, const char *status, const char *reason, const char *result_json) {
    aw_t w;
    char rid[41];
    au_strlcpy(rid, id, sizeof rid);                 /* id may point into a field that the caller clears next */
    cache_put(d, rid, link, status, reason);
    aw_init(&w, d->line, sizeof d->line);
    aw_obj(&w); aw_kstr(&w, "kind", kind); aw_kstr(&w, "id", rid); aw_kstr(&w, "status", status);
    if (reason && reason[0]) aw_kstr(&w, "reason", reason);
    if (result_json) { aw_key(&w, "result"); aw_raw(&w, result_json, au_strlen(result_json)); }
    aw_kstr(&w, "state", aeris_state_name(d->state));
    aw_end_obj(&w);
    if (aw_done(&w)) dev_send(d, link, w.buf, w.len);
}

static void reject(aeris_dev_t *d, int link, const char *id, const char *reason) {
    cache_put(d, id, link, "rejected", reason);
    send_ack(d, link, id, "rejected", reason, false);
}

static void accept(cctx_t *c) {
    cache_put(c->d, c->id, c->link, "accepted", 0);
    send_ack(c->d, c->link, c->id, "accepted", 0, false);
}

static void done(cctx_t *c, const char *status, const char *reason, const char *result) { cmd_report(c->d, c->link, c->id, "cmd_result", status, reason, result); }

/* ------------------------------------------------------------------------------------------------ parameters */
static int param(const cctx_t *c, const char *key) { return c->params < 0 ? -1 : aj_get(c->doc, c->params, key); }

/* a number in [lo, hi]; absent → def, or an error when required. Returns NULL or the reason. */
static const char *p_num(const cctx_t *c, const char *key, double lo, double hi, double def, bool required, double *out) {
    int t = param(c, key);
    if (t < 0) {
        if (required) return "params: a required number is missing";
        *out = def;
        return 0;
    }
    if (!aj_num(c->doc, t, out) || !au_isfinite(*out)) return "params: a value must be a finite number";
    if (*out < lo || *out > hi) return "params: a value is out of its allowed range";
    return 0;
}

static bool printable(const char *s) {
    for (; *s; s++) if ((unsigned char)*s < 0x20 || *s == 0x7f) return false;
    return true;
}

static void res_init(aeris_dev_t *d, aw_t *w) { aw_init(w, d->res, sizeof d->res); }
static const char *res_done(aw_t *w) { return aw_done(w) ? w->buf : "{\"error\":\"result too large\"}"; }

/* ------------------------------------------------------------------------------------------------ actions */
static const char *run_identify(cctx_t *c) {
    double s;
    aw_t w;
    const char *e = p_num(c, "seconds", 0.5, 10.0, 3.0, false, &s);
    if (e) return e;
    accept(c);
    c->d->identify_until_us = c->now + (uint64_t)(s * 1e6);
    if (c->d->hal->led) c->d->hal->led(c->d->hal->ctx, 100);      /* board pattern 100: identify */
    res_init(c->d, &w); aw_obj(&w); aw_knum(&w, "seconds", s, 4); aw_end_obj(&w);
    done(c, "completed", 0, res_done(&w));
    return 0;
}

static const char *run_diagnostics(cctx_t *c) {
    aeris_dev_t *d = c->d;
    aw_t w;
    int i;
    accept(c);
    res_init(d, &w);
    aw_obj(&w);
    aw_key(&w, "imu"); aw_obj(&w);
    aw_kstr(&w, "driver", "lsm6dsox"); aw_kint(&w, "i2c_address", d->imu.addr ? d->imu.addr : d->cfg.imu_addr);
    aw_kbool(&w, "present", d->imu_ok); aw_kint(&w, "who_am_i", d->imu.who_am_i); aw_kint(&w, "odr_hz", d->imu.odr_hz);
    aw_kuint(&w, "reads", d->imu.reads); aw_kuint(&w, "bus_errors", d->imu.bus_errors); aw_kuint(&w, "stale_reads", d->imu.stale_reads);
    aw_kuint(&w, "saturated", d->imu.saturated);
    if (d->imu_ok) aw_knum(&w, "temp_c", d->temp_c, 4); else aw_knull(&w, "temp_c");
    aw_end_obj(&w);
    aw_key(&w, "drivers"); aw_arr(&w);
    for (i = 0; i < AERIS_NW; i++) {
        const odrv_t *m = &d->drv[i];
        aw_obj(&w);
        aw_kint(&w, "node", m->node); aw_kbool(&w, "seen", m->seen);
        if (m->seen) {
            aw_kint(&w, "axis_state", m->axis_state); aw_kuint(&w, "axis_error", m->axis_error);
            aw_kint(&w, "heartbeat_age_ms", (int64_t)((c->now - m->t_heartbeat_us) / 1000u));
            if (m->t_encoder_us) aw_kint(&w, "encoder_age_ms", (int64_t)((c->now - m->t_encoder_us) / 1000u)); else aw_knull(&w, "encoder_age_ms");
            if (m->t_bus_us) aw_knum(&w, "vbus_V", m->vbus_V, 4); else aw_knull(&w, "vbus_V");
            if (m->t_temp_us) { aw_knum(&w, "fet_temp_C", m->fet_temp_C, 4); aw_knum(&w, "motor_temp_C", m->motor_temp_C, 4); }
        }
        aw_kuint(&w, "rx", m->rx); aw_kuint(&w, "tx", m->tx); aw_kuint(&w, "tx_errors", m->tx_errors);
        aw_end_obj(&w);
    }
    aw_end_arr(&w);
    aw_key(&w, "loop"); aw_obj(&w);
    aw_kuint(&w, "period_us", aeris_control_period_us(d)); aw_kuint(&w, "steps", d->steps); aw_kuint(&w, "overruns", d->overruns);
    aw_kuint(&w, "step_us_last", d->step_us_last); aw_kuint(&w, "step_us_max", d->step_us_max);
    aw_knum(&w, "step_us_mean", d->steps ? (double)d->step_us_sum / (double)d->steps : 0.0, 5);
    aw_end_obj(&w);
    aw_key(&w, "estimator"); aw_obj(&w);
    aw_kstr(&w, "type", "cf3d"); aw_kbool(&w, "initialised", d->est.initialised); aw_kbool(&w, "valid", d->est_valid);
    aw_kuint(&w, "processed", d->est.processed); aw_kuint(&w, "gated", d->est.gated); aw_kuint(&w, "updates", d->est.updates);
    aw_kuint(&w, "rejected_duplicate", d->est.rejected_duplicate); aw_kuint(&w, "rejected_out_of_order", d->est.rejected_out_of_order);
    aw_end_obj(&w);
    aw_key(&w, "links"); aw_arr(&w);
    for (i = 0; i < AERIS_LINKS; i++) {
        const aeris_link_t *L = &d->link[i];
        aw_obj(&w);
        aw_kstr(&w, "link", i == AERIS_LINK_USB ? "usb" : "net"); aw_kbool(&w, "up", L->up); aw_kbool(&w, "active", L->active);
        aw_kbool(&w, "session", L->has_session); aw_kuint(&w, "lines", L->rx.lines); aw_kuint(&w, "bad_crc", L->rx.bad_crc);
        aw_kuint(&w, "too_long", L->rx.too_long); aw_kuint(&w, "not_json", L->rx.not_json); aw_kuint(&w, "bad_message", L->rx.bad_message);
        aw_kuint(&w, "tx_dropped_lines", L->tx_dropped_lines); aw_kuint(&w, "tx_dropped_tlm", L->tx_dropped_tlm);
        aw_end_obj(&w);
    }
    aw_end_arr(&w);
    aw_key(&w, "telemetry"); aw_obj(&w);
    aw_kstr(&w, "session", d->tlm_session); aw_kuint(&w, "seq", d->tlm_seq); aw_kint(&w, "hz", d->tlm_hz); aw_kuint(&w, "ring", d->ring_count);
    aw_end_obj(&w);
    /* the local controls as the board reads them now (bench wiring checks) and whether the drivers may be powered:
     * DRIVE_EN is asserted only in the states that need powered drivers, never with the stop asserted */
    aw_key(&w, "inputs"); aw_obj(&w);
    aw_kbool(&w, "arm_pressed", d->hal->arm_input && d->hal->arm_input(d->hal->ctx));
    aw_kbool(&w, "stop_asserted", d->hal->stop_input && d->hal->stop_input(d->hal->ctx));
    aw_kbool(&w, "commission_held", d->hal->commission_input && d->hal->commission_input(d->hal->ctx));
    aw_kbool(&w, "drive_enable", dev_drivers_powered_state(d) && !(d->latched & F_ESTOP) && !(d->hal->stop_input && d->hal->stop_input(d->hal->ctx)));
    aw_end_obj(&w);
    aw_end_obj(&w);
    done(c, "completed", 0, res_done(&w));
    return 0;
}

static bool stop_asserted(const aeris_dev_t *d) { return d->hal->stop_input && d->hal->stop_input(d->hal->ctx); }

static const char *run_self_test(cctx_t *c) {
    if (dev_local_wait(c->d) || c->d->wait_start) return "a command is waiting for the local control";
    if (stop_asserted(c->d)) return "the local stop is asserted: release it first (the self-test powers the drivers)";
    accept(c);
    task_begin(c->d, TASK_SELF_TEST, 0, c->link, c->id, 3000, 0);
    done(c, "executing", "self-test running for 3 s (drivers powered, no torque); keep the cube still", 0);
    return 0;
}

static const char *imu_avg(cctx_t *c, int sub, double lo, double hi, double def) {
    double s;
    char face[17] = "";
    int t = param(c, "face");
    const char *e = p_num(c, "seconds", lo, hi, def, false, &s);
    if (e) return e;
    if (!c->d->imu_ok) return "the IMU is not detected (run diagnostics)";
    if (dev_local_wait(c->d) || c->d->wait_start) return "a command is waiting for the local control";
    if (t >= 0 && (!aj_str(c->doc, t, face, sizeof face) || !printable(face))) return "params.face: a short label (≤ 16 characters)";
    accept(c);
    task_begin(c->d, TASK_IMU_AVERAGE, sub, c->link, c->id, (uint32_t)(s * 1000.0), face);
    done(c, "executing", sub ? "measuring the gravity direction: keep the cube still on the requested face"
                             : "measuring the gyroscope bias: keep the cube completely still", 0);
    return 0;
}
static const char *run_calibrate_imu(cctx_t *c) { return imu_avg(c, 0, 2.0, 30.0, 5.0); }
static const char *run_calibrate_axes(cctx_t *c) { return imu_avg(c, 1, 1.0, 10.0, 2.0); }

static const char *run_check_encoders(cctx_t *c) {
    double s;
    const char *e = p_num(c, "seconds", 2.0, 30.0, 10.0, false, &s);
    if (e) return e;
    if (dev_local_wait(c->d) || c->d->wait_start) return "a command is waiting for the local control";
    if (stop_asserted(c->d)) return "the local stop is asserted: release it first (the check powers the drivers)";
    accept(c);
    task_begin(c->d, TASK_ENCODERS, 0, c->link, c->id, (uint32_t)(s * 1000.0), 0);
    done(c, "executing", "drivers powered and idle (no torque): turn each wheel by hand in its marked positive direction", 0);
    return 0;
}

static const char *run_apply_config(cctx_t *c) {
    aeris_dev_t *d = c->d;
    int t = param(c, "config");
    const char *raw;
    size_t n;
    uint8_t h[32];
    char hex[65];
    static char err[160];
    aw_t w;
    if (t < 0 || !aj_is(c->doc, t, JSMN_OBJECT) || !aj_raw(c->doc, t, &raw, &n)) return "params.config: the approved configuration object is required";
    if (!d->hal->sha256 || d->hal->sha256(d->hal->ctx, (const uint8_t *)raw, n, h) != 0) return "the device could not hash the configuration";
    au_fmt_hex(hex, sizeof hex, h, 32);
    if (!c->config_hash) return "config_hash is required (the SHA-256 of params.config exactly as sent)";
    if (!au_streq(c->config_hash, hex)) return "config_hash does not match the SHA-256 of params.config (altered or re-serialised in transit?)";
    if (dev_local_wait(d) || d->wait_start) return "a command is waiting for the local control";
    if (!cfg_parse(&d->cfg_tmp, c->doc, t, d->board, err, sizeof err)) return err;
    accept(c);
    d->cfg = d->cfg_tmp;
    au_strlcpy(d->cfg.hash_hex, hex, sizeof d->cfg.hash_hex);
    d->cfg.valid = true;
    dev_setup_hw(d);
    dev_tlm_new_session(d);
    dev_set_state(d, ST_DISARMED, "configuration applied: run the self-test");
    res_init(d, &w);
    aw_obj(&w);
    aw_kstr(&w, "config_hash", d->cfg.hash_hex); aw_kstr(&w, "profile_hash", d->cfg.profile_hash); aw_kstr(&w, "recipe", d->cfg.recipe);
    aw_kstr(&w, "mode", d->cfg.mode == MODE_EDGE ? "edge" : "corner");
    aw_kstr(&w, "controller", d->cfg.controller == CTRL_EDGE_LQR ? "edge-lqr" : "corner-mimo-lqr");
    aw_kint(&w, "control_hz", d->cfg.control_hz); aw_kint(&w, "telemetry_hz", d->cfg.telemetry_hz);
    aw_kbool(&w, "imu_present", d->imu_ok);
    aw_kstr(&w, "telemetry_session", d->tlm_session);
    aw_end_obj(&w);
    done(c, "completed", 0, res_done(&w));
    return 0;
}

static const char *run_start(cctx_t *c) {
    aeris_dev_t *d = c->d;
    double dur;
    char recipe[40];
    int t = param(c, "recipe");
    const char *e;
    if (!c->config_hash) return "config_hash is required: an experiment runs only on the configuration it was approved for";
    if (!au_streq(c->config_hash, d->cfg.hash_hex)) return "config_hash does not match the configuration applied on the device";
    e = p_num(c, "duration_s", 0.1, (double)d->cfg.duration_max_s, 0, true, &dur);
    if (e) return au_streq(e, "params: a value is out of its allowed range") ? "params.duration_s: above limits.duration_max_s (or not positive)" : e;
    if (t >= 0 && (!aj_str(c->doc, t, recipe, sizeof recipe) || !au_streq(recipe, d->cfg.recipe))) return "params.recipe does not match the configuration's recipe";
    if (d->wait_start || dev_local_wait(d)) return "another command is waiting for the local control";
    accept(c);
    d->wait_start = true;
    au_strlcpy(d->wait_cmd, c->id, sizeof d->wait_cmd);
    d->wait_link = c->link;
    d->wait_deadline_us = c->deadline;
    d->wait_duration_s = (float)dur;
    au_strlcpy(d->wait_recipe, d->cfg.recipe, sizeof d->wait_recipe);
    if (d->state == ST_ARMED) {
        char why[128];
        if (exp_begin(d, c->now, why, sizeof why)) done(c, "executing", "balancing (local enable given)", 0);
        else { d->wait_start = false; done(c, "failed", why, 0); }
    } else {
        done(c, "executing", "waiting for the local enable: press ARM on the cube before the command expires", 0);
        dev_send_state(d);
    }
    return 0;
}

static const char *run_stop(cctx_t *c) {
    aeris_dev_t *d = c->d;
    const char *was = aeris_state_name(d->state), *action = "none (nothing was running)";
    aw_t w;
    accept(c);
    if (d->wait_start || d->wait_clear || d->wait_unpair) {
        cmd_report(d, d->wait_link, d->wait_cmd, "cmd_result", "failed", "cancelled by a stop request", 0);
        d->wait_start = d->wait_clear = d->wait_unpair = false;
        action = "cancelled a command that was waiting for the local control";
    }
    if (d->pair_pending) { link_pair_cancel(d, "cancelled by a stop request"); action = "cancelled a pairing"; }
    switch (d->state) {
    case ST_BALANCING:
        au_strlcpy(d->exp_end_reason, "stop requested", sizeof d->exp_end_reason);
        d->exp_active = false;
        d->stop_start_us = c->now;
        dev_set_state(d, ST_STOPPING, "stop requested: normal stop (wheels braked, then drivers idle)");
        action = "normal stop started";
        break;
    case ST_ARMED:
        dev_set_state(d, ST_READY, "stop requested: local enable withdrawn");
        action = "local enable withdrawn";
        break;
    case ST_SELF_TEST: case ST_CALIBRATING:
        if (d->task) { cmd_report(d, d->task_link, d->task_cmd, "cmd_result", "failed", "aborted by a stop request", 0); d->task = TASK_NONE; }
        dev_set_state(d, ST_DISARMED, "stopped by request");
        action = "task aborted";
        break;
    case ST_COMMISSIONING:
        if (d->motor_test_until_us) au_strlcpy(d->mt_end, "stop requested", sizeof d->mt_end);
        d->motor_test_until_us = 0;
        dev_set_state(d, ST_DISARMED, "stopped by request: commissioning ended, drivers idle");
        action = "commissioning ended";
        break;
    case ST_STOPPING:
        action = "normal stop already in progress";
        break;
    default: break;
    }
    res_init(d, &w);
    aw_obj(&w); aw_kstr(&w, "was", was); aw_kstr(&w, "action", action); aw_end_obj(&w);
    done(c, "completed", 0, res_done(&w));
    return 0;
}

static const char *run_clear_faults(cctx_t *c) {
    aeris_dev_t *d = c->d;
    uint32_t present = d->faults & d->latched;
    if (present) {
        static char why[200];
        char fl[150];
        size_t n = aeris_faults_json(present, fl, sizeof fl);
        au_strlcpy(why, "the cause is still present: ", sizeof why);
        if (n) au_strlcpy(why + au_strlen(why), fl, sizeof why - au_strlen(why));
        return why;
    }
    if (d->wait_start || dev_local_wait(d)) return "another command is waiting for the local control";
    accept(c);
    d->wait_clear = true;
    au_strlcpy(d->wait_cmd, c->id, sizeof d->wait_cmd);
    d->wait_link = c->link;
    d->wait_deadline_us = c->deadline;
    done(c, "executing", "hold ARM on the cube for 2 s to clear the latched faults", 0);
    dev_send_state(d);
    return 0;
}

static const char *run_set_telemetry(cctx_t *c) {
    aeris_dev_t *d = c->d;
    double r;
    int maxhz = d->cfg.valid ? d->cfg.control_hz : 500;
    aw_t w;
    const char *e = p_num(c, "rate_hz", 0.0, (double)(maxhz < 500 ? maxhz : 500), 0, true, &r);
    if (e) return e;
    if (r != (double)(int)r) return "params.rate_hz: an integer";
    if ((int)r > 0 && d->cfg.valid && d->cfg.control_hz % (int)r) return "params.rate_hz: must divide the control rate";
    accept(c);
    d->tlm_hz = (int)r;
    dev_tlm_new_session(d);
    res_init(d, &w);
    aw_obj(&w); aw_kint(&w, "rate_hz", d->tlm_hz); aw_kstr(&w, "telemetry_session", d->tlm_session); aw_end_obj(&w);
    done(c, "completed", 0, res_done(&w));
    return 0;
}

static void cancel_all(aeris_dev_t *d, const char *why) { cmd_cancel_pending(d, why); }

static const char *run_enter_update(cctx_t *c) {
    aeris_dev_t *d = c->d;
    aw_t w;
    accept(c);
    cancel_all(d, "the device is entering the bootloader");
    dev_set_state(d, ST_UPDATE, "entering the bootloader for a firmware update; drivers idle, driver power off");
    d->reboot_at_us = c->now + 300000u;
    d->reboot_bootloader = true;
    res_init(d, &w);
    aw_obj(&w); aw_kint(&w, "reboot_in_ms", 300); aw_kstr(&w, "to", "bootloader"); aw_end_obj(&w);
    done(c, "completed", 0, res_done(&w));
    return 0;
}

static const char *run_reboot(cctx_t *c) {
    aeris_dev_t *d = c->d;
    aw_t w;
    accept(c);
    cancel_all(d, "the device is rebooting");
    d->reboot_at_us = c->now + 300000u;
    d->reboot_bootloader = false;
    res_init(d, &w);
    aw_obj(&w); aw_kint(&w, "reboot_in_ms", 300); aw_kstr(&w, "to", "application"); aw_end_obj(&w);
    done(c, "completed", 0, res_done(&w));
    return 0;
}

static const char *run_set_network(cctx_t *c) {
    aeris_dev_t *d = c->d;
    char ssid[33], pass[65], url[201];
    bool clr = false;
    int t;
    aw_t w;
    if (!d->hal->nvs_set) return "this board has no persistent storage";
    t = param(c, "clear");
    if (t >= 0 && (!aj_bool(c->doc, t, &clr) || !clr)) return "params.clear: true (or give ssid, password and gateway_url)";
    if (!clr) {
        size_t pl, i;
        if (!aj_str(c->doc, param(c, "ssid"), ssid, sizeof ssid) || !ssid[0] || !printable(ssid)) return "params.ssid: 1..32 printable characters";
        if (!aj_str(c->doc, param(c, "password"), pass, sizeof pass) || !printable(pass)) return "params.password: 0..64 printable characters";
        pl = au_strlen(pass);
        if (pl != 0 && pl < 8) return "params.password: empty (open network) or 8..64 characters (WPA2/WPA3)";
        if (!aj_str(c->doc, param(c, "gateway_url"), url, sizeof url) || au_strlen(url) < 7 || au_memcmp(url, "wss://", 6) != 0) return "params.gateway_url: a wss:// URL (TLS required)";
        for (i = 0; url[i]; i++) if (url[i] <= ' ' || url[i] == '"' || url[i] == '\\') return "params.gateway_url: no spaces, quotes or backslashes";
    } else { ssid[0] = pass[0] = url[0] = 0; }
    accept(c);
    if (d->hal->nvs_set(d->hal->ctx, "net_ssid", (const uint8_t *)ssid, au_strlen(ssid)) != 0 ||
        d->hal->nvs_set(d->hal->ctx, "net_pass", (const uint8_t *)pass, au_strlen(pass)) != 0 ||
        d->hal->nvs_set(d->hal->ctx, "net_url", (const uint8_t *)url, au_strlen(url)) != 0) {
        au_memset(pass, 0, sizeof pass);
        done(c, "failed", "storing the network settings failed", 0);
        return 0;
    }
    au_memset(pass, 0, sizeof pass);
    res_init(d, &w);
    aw_obj(&w); aw_kbool(&w, "stored", true); aw_kbool(&w, "cleared", clr);
    if (!clr) aw_kstr(&w, "ssid", ssid);
    aw_kbool(&w, "reboot_required", true); aw_end_obj(&w);
    done(c, "completed", 0, res_done(&w));
    return 0;
}

static const char *run_unpair(cctx_t *c) {
    aeris_dev_t *d = c->d;
    if (d->wait_start || dev_local_wait(d)) return "another command is waiting for the local control";
    accept(c);
    d->wait_unpair = true;
    au_strlcpy(d->wait_cmd, c->id, sizeof d->wait_cmd);
    d->wait_link = c->link;
    d->wait_deadline_us = c->deadline;
    done(c, "executing", "press ARM on the cube to confirm: the device forgets its key and must be paired again", 0);
    dev_send_state(d);
    return 0;
}

static const char *run_commission(cctx_t *c) {
    aeris_dev_t *d = c->d;
    bool enter;
    if (!aj_bool(c->doc, param(c, "enter"), &enter)) return "params.enter: true or false";
    if (enter) {
        if (d->state != ST_DISARMED) return "commissioning is entered from DISARMED";
        if (!d->cfg.valid) return "apply an approved configuration first (wheel nodes and signs come from it)";
        if (!(d->hal->commission_input && d->hal->commission_input(d->hal->ctx))) return "hold the commissioning (dead-man) control first";
        if (stop_asserted(d)) return "the local stop is asserted";
        if (dev_local_wait(d) || d->wait_start) return "a command is waiting for the local control";
        accept(c);
        dev_set_state(d, ST_COMMISSIONING, "commissioning: per-motor tests while the dead-man control is held");
    } else {
        if (d->state != ST_COMMISSIONING) return "not in COMMISSIONING";
        accept(c);
        if (d->motor_test_until_us) au_strlcpy(d->mt_end, "commissioning ended", sizeof d->mt_end);
        d->motor_test_until_us = 0;
        dev_set_state(d, ST_DISARMED, "commissioning ended: drivers idle");
    }
    done(c, "completed", 0, 0);
    return 0;
}

static const char *run_motor_test(cctx_t *c) {
    aeris_dev_t *d = c->d;
    double wh, tq, ms;
    const char *e;
    if ((e = p_num(c, "wheel", 0, 2, 0, true, &wh)) != 0) return e;
    if (wh != (double)(int)wh) return "params.wheel: 0, 1 or 2";
    if ((e = p_num(c, "torque_Nm", -(double)d->board->commissioning_max_torque_Nm, (double)d->board->commissioning_max_torque_Nm, 0, true, &tq)) != 0)
        return "params.torque_Nm: required, within the build's commissioning torque cap";
    if (tq > (double)d->cfg.w[(int)wh].torque_max || tq < -(double)d->cfg.w[(int)wh].torque_max) return "params.torque_Nm: above the wheel's configured torque limit";
    if ((e = p_num(c, "duration_ms", 10, (double)d->board->commissioning_max_ms, 0, true, &ms)) != 0) return "params.duration_ms: required, within the build's commissioning time cap";
    if (d->motor_test_until_us || d->mt_cmd[0]) return "a motor test is already running";
    if (!(d->hal->commission_input && d->hal->commission_input(d->hal->ctx))) return "the commissioning (dead-man) control is not held";
    if (!d->drv[(int)wh].seen) return "that wheel's driver has not been seen on the CAN bus";
    accept(c);
    d->motor_test_wheel = (int)wh;
    d->motor_test_torque = (float)tq;
    d->motor_test_until_us = c->now + (uint64_t)(ms * 1000.0);
    d->mt_start_us = c->now;
    d->mt_omega_max = 0;
    d->mt_end[0] = 0;
    au_strlcpy(d->mt_cmd, c->id, sizeof d->mt_cmd);
    d->mt_link = c->link;
    done(c, "executing", "torque applied to one wheel while the dead-man control is held", 0);
    return 0;
}

#define DISARM_READY (S(ST_DISARMED) | S(ST_READY))
static const action_t ACTIONS[] = {
    {"identify", ALL_STATES & ~S(ST_UPDATE), 0, run_identify},
    {"diagnostics", ALL_STATES, A_OBSERVER_OK, run_diagnostics},
    {"self_test", DISARM_READY, 0, run_self_test},
    {"calibrate_imu", DISARM_READY, 0, run_calibrate_imu},
    {"calibrate_axes", DISARM_READY, 0, run_calibrate_axes},
    {"check_encoders", DISARM_READY, 0, run_check_encoders},
    {"apply_config", DISARM_READY, 0, run_apply_config},
    {"start_experiment", S(ST_READY) | S(ST_ARMED), A_ACTUATION, run_start},
    {"stop", ALL_STATES, A_OBSERVER_OK, run_stop},
    {"clear_faults", S(ST_FAULT), 0, run_clear_faults},
    {"set_telemetry", ALL_STATES & ~S(ST_UPDATE), 0, run_set_telemetry},
    {"enter_update", DISARM_READY | S(ST_FAULT), A_USB_ONLY, run_enter_update},
    {"reboot", DISARM_READY | S(ST_FAULT), 0, run_reboot},
    {"set_network", S(ST_DISARMED), A_USB_ONLY, run_set_network},
    {"unpair", S(ST_DISARMED), A_USB_ONLY, run_unpair},
    {"commission", S(ST_DISARMED) | S(ST_COMMISSIONING), A_USB_ONLY | A_COMMISSIONING, run_commission},
    {"motor_test", S(ST_COMMISSIONING), A_USB_ONLY | A_COMMISSIONING, run_motor_test},
};

static bool safe_id(const char *s, size_t min, size_t max) {
    size_t i, n = au_strlen(s);
    if (n < min || n > max) return false;
    for (i = 0; i < n; i++) {
        char ch = s[i];
        if (!((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '.' || ch == '_' || ch == ':' || ch == '-')) return false;
    }
    return true;
}

static bool is_hex64(const char *s) {
    int i;
    for (i = 0; i < 64; i++) if (!((s[i] >= '0' && s[i] <= '9') || (s[i] >= 'a' && s[i] <= 'f'))) return false;
    return s[64] == 0;
}

void cmd_handle(aeris_dev_t *d, int link, const aj_doc_t *doc) {
    aeris_link_t *L = &d->link[link];
    char id[41], sid[48], action[24], hash[65];
    int t, params, k;
    int64_t v, epoch, seq, ttl;
    const action_t *a = 0;
    aeris_cmd_cache_t *dup;
    cctx_t c;
    const char *r;
    uint64_t now = now_us(d);
    t = aj_get(doc, 0, "id");
    if (t < 0 || !aj_str(doc, t, id, sizeof id) || !safe_id(id, 1, 40)) {
        char b[200];
        aw_t w;
        aw_init(&w, b, sizeof b);
        aw_obj(&w); aw_kstr(&w, "kind", "link_error"); aw_kstr(&w, "reason", "cmd: id (1..40 of [A-Za-z0-9._:-]) required"); aw_end_obj(&w);
        if (aw_done(&w)) dev_send(d, link, w.buf, w.len);
        return;
    }
    dup = cache_find(d, id);
    if (dup) { send_ack(d, link, id, dup->status, dup->reason, true); return; }
    /* shape */
    if (!aj_int(doc, aj_get(doc, 0, "v"), &v) || v != 1) { reject(d, link, id, "v: 1 required (command format version)"); return; }
    t = aj_get(doc, 0, "action");
    if (t < 0 || !aj_str(doc, t, action, sizeof action)) { reject(d, link, id, "action: required"); return; }
    t = aj_get(doc, 0, "link_session");
    if (t < 0 || !aj_str(doc, t, sid, sizeof sid) || !safe_id(sid, 8, 47)) { reject(d, link, id, "link_session: required"); return; }
    if (!aj_int(doc, aj_get(doc, 0, "lease_epoch"), &epoch) || epoch < 0 || epoch > 0xFFFFFFFFll) { reject(d, link, id, "lease_epoch: integer ≥ 0 required"); return; }
    if (!aj_int(doc, aj_get(doc, 0, "seq"), &seq) || seq < 0) { reject(d, link, id, "seq: integer ≥ 0 required"); return; }
    if (!aj_int(doc, aj_get(doc, 0, "ttl_ms"), &ttl) || ttl < 1 || ttl > AERIS_MAX_TTL_MS) { reject(d, link, id, "ttl_ms: integer 1..10000 required"); return; }
    params = aj_get(doc, 0, "params");
    if (params >= 0 && aj_is_null(doc, params)) params = -1;
    if (params >= 0 && !aj_is(doc, params, JSMN_OBJECT)) { reject(d, link, id, "params: must be an object"); return; }
    t = aj_get(doc, 0, "config_hash");
    if (t >= 0 && !aj_is_null(doc, t)) {
        if (!aj_str(doc, t, hash, sizeof hash) || !is_hex64(hash)) { reject(d, link, id, "config_hash: 64 lower-case hex characters"); return; }
    } else hash[0] = 0;
    /* session, local priority, lease, sequence */
    if (!L->has_session) { reject(d, link, id, "no session on this link (send a session message first)"); return; }
    if (!au_streq(sid, L->session)) { reject(d, link, id, "link_session does not match this link's session"); return; }
    for (k = 0; k < (int)(sizeof ACTIONS / sizeof ACTIONS[0]); k++) if (au_streq(action, ACTIONS[k].name)) { a = &ACTIONS[k]; break; }
    if (link == AERIS_LINK_NET && d->link[AERIS_LINK_USB].up && d->link[AERIS_LINK_USB].active && d->link[AERIS_LINK_USB].has_session && !(a && (a->flags & A_OBSERVER_OK))) {
        reject(d, link, id, "a local USB session supervises this device: the network session may only observe (and stop)");
        return;
    }
    if ((uint32_t)epoch != L->lease_epoch) { reject(d, link, id, "stale lease: lease_epoch does not match the session's current lease"); return; }
    if (seq <= L->last_seq) { reject(d, link, id, "seq is not above the last accepted one (replayed or reordered command)"); return; }
    L->last_seq = seq;
    L->last_heartbeat_us = now;
    /* action, link, build, state */
    if (!a) { reject(d, link, id, "unknown action"); return; }
    if ((a->flags & A_USB_ONLY) && link != AERIS_LINK_USB) { reject(d, link, id, "this action is only accepted over the local USB link"); return; }
    if (a->flags & A_ACTUATION) {
        if (!d->board->actuation_build) { reject(d, link, id, "this firmware build cannot drive motors (built without AERIS_ACTUATION_ENABLED)"); return; }
        if (!d->cfg.valid) { reject(d, link, id, "no approved configuration is applied"); return; }
    }
    if ((a->flags & A_COMMISSIONING) && !d->board->commissioning_build) { reject(d, link, id, "this firmware build has no commissioning mode (built without AERIS_COMMISSIONING)"); return; }
    if (!(a->states & S(d->state))) {
        static char why[96];
        au_strlcpy(why, "not allowed in state ", sizeof why);
        au_strlcpy(why + au_strlen(why), aeris_state_name(d->state), sizeof why - au_strlen(why));
        reject(d, link, id, why);
        return;
    }
    c.d = d; c.link = link; c.id = id; c.doc = doc; c.params = params; c.now = now;
    c.deadline = now + (uint64_t)ttl * 1000u;
    c.config_hash = hash[0] ? hash : 0;
    r = a->run(&c);
    if (r) reject(d, link, id, r);
}

/* ------------------------------------------------------------------------------------------------ experiments */
bool exp_begin(aeris_dev_t *d, uint64_t now, char *why, size_t cap) {
    int i;
    uint32_t bad;
    const aeris_link_t *L = &d->link[d->wait_link];
    if (d->state != ST_ARMED) { au_strlcpy(why, "the device is not ARMED", cap); return false; }
    if (!aeris_actuation_permitted(d)) { au_strlcpy(why, "actuation is not permitted (build or configuration)", cap); return false; }
    if (!d->est_valid) { au_strlcpy(why, "no valid attitude estimate", cap); return false; }
    if (d->tilt > d->cfg.tilt_start_rad) {
        size_t n = au_strlcpy(why, "tilt from the balance attitude is ", cap);
        n += au_fmt_double(why + n, cap > n ? cap - n : 0, (double)d->tilt * 57.29577951308232, 3);
        if (n < cap) au_strlcpy(why + n, " deg, above limits.tilt_start_deg: hold the cube at its balance point", cap - n);
        return false;
    }
    bad = d->faults & (F_IMU_ABSENT | F_IMU_STALE | F_IMU_INVALID | F_IMU_SATURATED | F_DRV_ERROR | F_UNDERVOLT | F_OVERVOLT | F_OVERTEMP | F_OVERSPEED | F_LOOP_OVERRUN | F_ESTOP);
    if (bad) {
        char fl[150];
        size_t n = aeris_faults_json(bad, fl, sizeof fl);
        au_strlcpy(why, "a fault is present: ", cap);
        if (n) au_strlcpy(why + au_strlen(why), fl, cap - au_strlen(why));
        return false;
    }
    for (i = 0; i < AERIS_NW; i++) {
        const odrv_t *m = &d->drv[i];
        if (!m->seen || now - m->t_heartbeat_us > 300000u) { au_strlcpy(why, "a wheel driver is not answering on the CAN bus", cap); return false; }
        if (!m->t_encoder_us || now - m->t_encoder_us > 25000u) { au_strlcpy(why, "a wheel driver is not sending encoder estimates (configure its encoder message rate)", cap); return false; }
    }
    if (!(d->vbus > 0)) { au_strlcpy(why, "the bus voltage is not known", cap); return false; }
    ctrl_start(&d->ctrl, d->q);
    d->exp_active = true;
    au_strlcpy(d->exp_cmd, d->wait_cmd, sizeof d->exp_cmd);
    d->exp_link = d->wait_link;
    au_strlcpy(d->exp_session, L->session, sizeof d->exp_session);
    au_strlcpy(d->exp_recipe, d->wait_recipe, sizeof d->exp_recipe);
    d->exp_start_us = now;
    d->exp_end_us = now + (uint64_t)(d->wait_duration_s * 1e6f);
    d->exp_end_reason[0] = 0;
    d->exp_steps = 0;
    for (i = 0; i < AERIS_NW; i++) d->exp_sat_steps[i] = 0;
    d->link_lost = !(L->up && L->has_session);
    d->link_lost_at = now;
    d->wait_start = false;
    dev_drivers_closed_loop(d);
    dev_set_state(d, ST_BALANCING, "experiment started with the local enable");
    return true;
}

/* ------------------------------------------------------------------------------------------------ service */
void cmd_service(aeris_dev_t *d) {
    uint64_t now = now_us(d);
    if ((d->wait_start || d->wait_clear || d->wait_unpair) && now >= d->wait_deadline_us) {
        const char *what = d->wait_start ? "the local enable (ARM) was not given before the command expired"
                         : d->wait_clear ? "ARM was not held for 2 s before the command expired"
                                         : "the local confirmation did not come before the command expired";
        d->wait_start = d->wait_clear = d->wait_unpair = false;
        cmd_report(d, d->wait_link, d->wait_cmd, "cmd_result", "expired", what, 0);
        dev_send_state(d);
    }
}

void cmd_cancel_pending(aeris_dev_t *d, const char *reason) {
    if (d->wait_start || d->wait_clear || d->wait_unpair) {
        d->wait_start = d->wait_clear = d->wait_unpair = false;
        cmd_report(d, d->wait_link, d->wait_cmd, "cmd_result", "failed", reason, 0);
    }
    if (d->task) {
        d->task = TASK_NONE;
        cmd_report(d, d->task_link, d->task_cmd, "cmd_result", "failed", reason, 0);
    }
    if (d->mt_cmd[0]) {
        d->motor_test_until_us = 0;
        cmd_report(d, d->mt_link, d->mt_cmd, "cmd_result", "failed", reason, 0);
        d->mt_cmd[0] = 0;
    }
    if (d->pair_pending) link_pair_cancel(d, reason);
}

bool dev_local_wait(const aeris_dev_t *d) { return d->pair_pending || d->wait_clear || d->wait_unpair; }

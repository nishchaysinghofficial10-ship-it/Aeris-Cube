/* AERIS firmware core — vectors and quaternions (see mathq.h). */
#include "aeris/mathq.h"
#include "aeris/util.h"

void aq_mul(const float a[4], const float b[4], float o[4]) {
    o[0] = a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3];
    o[1] = a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2];
    o[2] = a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1];
    o[3] = a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0];
}

void aq_conj(const float q[4], float o[4]) { o[0] = q[0]; o[1] = -q[1]; o[2] = -q[2]; o[3] = -q[3]; }

void aq_norm(float q[4]) {
    float n = au_sqrtf(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
    if (!(n > 1e-12f) || !au_isfinitef(n)) { q[0] = 1; q[1] = q[2] = q[3] = 0; return; }
    q[0] /= n; q[1] /= n; q[2] /= n; q[3] /= n;
}

void aq_exp(const float p[3], float o[4]) {
    float a = au_sqrtf(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]);
    if (a < 1e-6f) { o[0] = 1; o[1] = p[0] * 0.5f; o[2] = p[1] * 0.5f; o[3] = p[2] * 0.5f; aq_norm(o); return; }
    {
        float s = au_sinf(a * 0.5f) / a;
        o[0] = au_cosf(a * 0.5f); o[1] = p[0] * s; o[2] = p[1] * s; o[3] = p[2] * s;
    }
}

void aq_log(const float q[4], float o[3]) {
    float w = q[0], x = q[1], y = q[2], z = q[3], s, a;
    if (w < 0) { w = -w; x = -x; y = -y; z = -z; }
    s = au_sqrtf(x * x + y * y + z * z);
    if (s < 1e-7f) { o[0] = 2 * x; o[1] = 2 * y; o[2] = 2 * z; return; }
    a = 2 * au_atan2f(s, w);
    o[0] = x / s * a; o[1] = y / s * a; o[2] = z / s * a;
}

void aq_up_in_body(const float q[4], float o[3]) {
    o[0] = 2 * (q[1] * q[3] - q[0] * q[2]);
    o[1] = 2 * (q[2] * q[3] + q[0] * q[1]);
    o[2] = 1 - 2 * (q[1] * q[1] + q[2] * q[2]);
}

void aq_rot(const float q[4], const float v[3], float o[3]) {
    float w = q[0], x = q[1], y = q[2], z = q[3];
    float r00 = 1 - 2 * (y * y + z * z), r01 = 2 * (x * y - w * z), r02 = 2 * (x * z + w * y);
    float r10 = 2 * (x * y + w * z), r11 = 1 - 2 * (x * x + z * z), r12 = 2 * (y * z - w * x);
    float r20 = 2 * (x * z - w * y), r21 = 2 * (y * z + w * x), r22 = 1 - 2 * (x * x + y * y);
    o[0] = r00 * v[0] + r01 * v[1] + r02 * v[2];
    o[1] = r10 * v[0] + r11 * v[1] + r12 * v[2];
    o[2] = r20 * v[0] + r21 * v[1] + r22 * v[2];
}

void aq_rot_t(const float q[4], const float v[3], float o[3]) {
    float c[4];
    aq_conj(q, c);
    aq_rot(c, v, o);
}

void av_cross(const float a[3], const float b[3], float o[3]) {
    float x = a[1] * b[2] - a[2] * b[1], y = a[2] * b[0] - a[0] * b[2], z = a[0] * b[1] - a[1] * b[0];
    o[0] = x; o[1] = y; o[2] = z;
}
float av_dot(const float a[3], const float b[3]) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
float av_norm(const float a[3]) { return au_sqrtf(av_dot(a, a)); }
void av_scale(const float a[3], float s, float o[3]) { o[0] = a[0] * s; o[1] = a[1] * s; o[2] = a[2] * s; }
void av_add(const float a[3], const float b[3], float o[3]) { o[0] = a[0] + b[0]; o[1] = a[1] + b[1]; o[2] = a[2] + b[2]; }
void av_sub(const float a[3], const float b[3], float o[3]) { o[0] = a[0] - b[0]; o[1] = a[1] - b[1]; o[2] = a[2] - b[2]; }
void am_vec(const float m[9], const float v[3], float o[3]) {
    float x = m[0] * v[0] + m[1] * v[1] + m[2] * v[2], y = m[3] * v[0] + m[4] * v[1] + m[5] * v[2], z = m[6] * v[0] + m[7] * v[1] + m[8] * v[2];
    o[0] = x; o[1] = y; o[2] = z;
}
void am_tvec(const float m[9], const float v[3], float o[3]) {
    float x = m[0] * v[0] + m[3] * v[1] + m[6] * v[2], y = m[1] * v[0] + m[4] * v[1] + m[7] * v[2], z = m[2] * v[0] + m[5] * v[1] + m[8] * v[2];
    o[0] = x; o[1] = y; o[2] = z;
}

void aq_axis_angle(const float ax[3], float ang, float o[4]) {
    float n = av_norm(ax), s;
    if (!(n > 0)) { o[0] = 1; o[1] = o[2] = o[3] = 0; return; }
    s = au_sinf(ang * 0.5f) / n;
    o[0] = au_cosf(ang * 0.5f); o[1] = ax[0] * s; o[2] = ax[1] * s; o[3] = ax[2] * s;
}

void aq_from_to(const float u[3], const float v[3], float o[4]) {
    float c = av_dot(u, v), ax[3], s;
    av_cross(u, v, ax);
    s = av_norm(ax);
    if (s < 1e-7f) {
        if (c > 0) { o[0] = 1; o[1] = o[2] = o[3] = 0; return; }
        {
            float e[3] = {1, 0, 0}, p[3];
            if (!(u[0] < 0.9f && u[0] > -0.9f)) { e[0] = 0; e[1] = 1; }
            av_cross(u, e, p);
            aq_axis_angle(p, 3.14159265358979f, o);
            return;
        }
    }
    aq_axis_angle(ax, au_atan2f(s, c), o);
}

float aq_angle_between(const float a[4], const float b[4]) {
    float d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
    if (d < 0) d = -d;
    if (d > 1) d = 1;
    return 2 * au_acosf(d);
}

/* AERIS firmware core — estimator (cf3d), controllers (edge-lqr, corner-mimo-lqr) and allocation (see control.h).
 * Each function names the Python code it ports; the host tests compare both on the same inputs. */
#include "aeris/control.h"
#include "aeris/mathq.h"
#include "aeris/util.h"

#define EPS_T 1e-9

/* rotation of π/4 about body x: the edge model's attitude at θ = 0 (physics/quaternion.py edge_quat(0)) */
const float AERIS_Q_EDGE0[4] = {0.92387953251128674f, 0.38268343236508978f, 0.0f, 0.0f};

/* ------------------------------------------------------------------------------------------------ estimator
 * estimation/__init__.py: Attitude3DBase + ComplementaryAttitude (cf3d) */
void est_init(est_t *e, const aeris_cfg_t *c) {
    au_memset(e, 0, sizeof *e);
    au_memcpy(e->q, c->q_nominal, sizeof e->q);
    au_memcpy(e->q_nominal, c->q_nominal, sizeof e->q_nominal);
    au_memcpy(e->r, c->imu_pos, sizeof e->r);
    e->tau = c->tau_s; e->gate = c->accel_gate; e->kb = c->bias_gain; e->g = c->g > 0 ? c->g : 9.81f;
    e->tau_a = c->tau_alpha_s > 0 ? c->tau_alpha_s : 0.02f;
    e->compensate = c->compensate_dynamic;
    e->stale_after = c->stale_after_s;
}

static void dynamic(est_t *e, const float gyro[3], float dt, float out[3]) {
    float w[3], t1[3], t2[3];
    int i;
    for (i = 0; i < 3; i++) w[i] = gyro[i] - e->b[i];
    if (e->have_prev && dt > 0) {
        float k = dt / (e->tau_a + dt);
        for (i = 0; i < 3; i++) { float raw = (w[i] - e->prev_w[i]) / dt; e->alpha[i] += k * (raw - e->alpha[i]); }
    }
    au_memcpy(e->prev_w, w, sizeof w);
    e->have_prev = true;
    if (!e->compensate) { out[0] = out[1] = out[2] = 0; return; }
    av_cross(e->alpha, e->r, t1);
    av_cross(w, e->r, t2);
    av_cross(w, t2, t2);
    av_add(t1, t2, out);
}

static void align(est_t *e, const float accel_in[3], const float gyro[3]) {
    float a[3] = {accel_in[0], accel_in[1], accel_in[2]}, n, up_meas[3], up_nom[3], qf[4];
    if (e->compensate) {
        float t[3];
        av_cross(gyro, e->r, t);
        av_cross(gyro, t, t);
        av_sub(a, t, a);
    }
    n = av_norm(a);
    if (!(n > 0)) return;
    av_scale(a, 1.0f / n, up_meas);
    aq_up_in_body(e->q_nominal, up_nom);
    aq_from_to(up_meas, up_nom, qf);
    aq_mul(e->q_nominal, qf, e->q);
    aq_norm(e->q);
    e->initialised = true;
}

static float propagate(est_t *e, double t) {
    float dt, w[3], p[4], dq[4];
    if (!e->have_t || !e->have_gyro) { e->t = t; e->have_t = true; return 0; }
    dt = (float)(t - e->t);
    if (!(dt > 0)) return 0;
    w[0] = (e->last_gyro[0] - e->b[0]) * dt; w[1] = (e->last_gyro[1] - e->b[1]) * dt; w[2] = (e->last_gyro[2] - e->b[2]) * dt;
    aq_exp(w, dq);
    aq_mul(e->q, dq, p);
    au_memcpy(e->q, p, sizeof p);
    aq_norm(e->q);
    e->t = t;
    return dt;
}

static void process(est_t *e, double t, const float gyro[3], const float accel[3]) {
    float dt, dyn[3], f[3], n, up_meas[3], up_hat[3], err[3], k, corr[4], dq[3], p[4];
    if (!e->initialised) {
        align(e, accel, gyro);
        e->t = t; e->have_t = true;
        au_memcpy(e->last_gyro, gyro, sizeof e->last_gyro); e->have_gyro = true;
        return;
    }
    dt = propagate(e, t);
    au_memcpy(e->last_gyro, gyro, sizeof e->last_gyro); e->have_gyro = true;
    dynamic(e, gyro, dt, dyn);
    av_sub(accel, dyn, f);
    n = av_norm(f);
    if (!(dt > 0) || !(n > 0) || au_isfinitef(n) == 0 || (n - e->g > e->gate) || (e->g - n > e->gate)) {
        if (n > 0 && ((n - e->g > e->gate) || (e->g - n > e->gate))) e->gated++;
        return;
    }
    av_scale(f, 1.0f / n, up_meas);
    aq_up_in_body(e->q, up_hat);
    av_cross(up_meas, up_hat, err);
    k = dt / (e->tau + dt);
    av_scale(err, k, dq);
    aq_exp(dq, corr);
    aq_mul(e->q, corr, p);
    au_memcpy(e->q, p, sizeof p);
    aq_norm(e->q);
    if (e->kb != 0) { e->b[0] -= e->kb * dt * err[0]; e->b[1] -= e->kb * dt * err[1]; e->b[2] -= e->kb * dt * err[2]; }
    e->updates++;
}

bool est_accept(est_t *e, double t_meas, const float gyro[3], const float accel[3], double t_receipt) {
    if (!au_isfinitef(gyro[0]) || !au_isfinitef(gyro[1]) || !au_isfinitef(gyro[2]) ||
        !au_isfinitef(accel[0]) || !au_isfinitef(accel[1]) || !au_isfinitef(accel[2])) return false;
    if (e->initialised && e->have_t && t_meas <= e->t + EPS_T) {
        if (t_meas > e->t - EPS_T) e->rejected_duplicate++; else e->rejected_out_of_order++;
        return false;
    }
    process(e, t_meas, gyro, accel);
    e->t_receipt = t_receipt;
    e->processed++;
    if (e->processed == 1) e->t_init = t_meas;
    return true;
}

bool est_predict(const est_t *e, double t, float q[4], float w[3], float *age) {
    float h;
    if (!e->initialised || !e->have_gyro) {
        au_memcpy(q, e->q, 4 * sizeof(float));
        w[0] = w[1] = w[2] = 0;
        if (age) *age = -1;
        return false;
    }
    w[0] = e->last_gyro[0] - e->b[0]; w[1] = e->last_gyro[1] - e->b[1]; w[2] = e->last_gyro[2] - e->b[2];
    h = (float)(t - e->t);
    if (age) *age = h;
    if (h <= (float)EPS_T) au_memcpy(q, e->q, 4 * sizeof(float));
    else {
        float p[3] = {w[0] * h, w[1] * h, w[2] * h}, dq[4];
        aq_exp(p, dq);
        aq_mul(e->q, dq, q);
        aq_norm(q);
    }
    return !(h > e->stale_after + (float)EPS_T);
}

void edge_theta(const float q[4], float *theta) {
    float c[4], r[4];
    aq_conj(AERIS_Q_EDGE0, c);
    aq_mul(c, q, r);
    *theta = 2.0f * au_atan2f(r[1], r[0]);
}

/* ------------------------------------------------------------------------------------------------ controllers
 * control/controllers.py: EdgeLegacy (type lqr), CornerMimo, YawTracker */
void ctrl_init(ctrl_t *k, const aeris_cfg_t *c) {
    au_memset(k, 0, sizeof *k);
    k->c = c;
    au_memcpy(k->q_ref, c->q_eq, sizeof k->q_ref);
}

float ctrl_psi(ctrl_t *k, const float q[4]) {
    float qc[4], qe[4], p, d;
    const float *u = k->c->u_ref;
    aq_conj(k->c->q_eq, qc);
    aq_mul(qc, q, qe);
    p = 2.0f * au_atan2f(qe[1] * u[0] + qe[2] * u[1] + qe[3] * u[2], qe[0]);
    d = p - k->psi_prev;
    if (d > 3.14159265358979f) k->psi_turns -= 6.28318530717959f;
    else if (d < -3.14159265358979f) k->psi_turns += 6.28318530717959f;
    k->psi_prev = p;
    return p + k->psi_turns;
}

void ctrl_start(ctrl_t *k, const float q_est[4]) {
    k->psi_prev = 0; k->psi_turns = 0;
    if (k->c->mode == MODE_CORNER) {
        float z[3] = {0, 0, 1}, qz[4];
        k->psi_ref = ctrl_psi(k, q_est);
        aq_axis_angle(z, k->psi_ref, qz);
        aq_mul(qz, k->c->q_eq, k->q_ref);
    }
    k->started = true;
}

void ctrl_request(ctrl_t *k, const float q[4], const float w[3], const float om[3], float T[3]) {
    const aeris_cfg_t *c = k->c;
    T[0] = T[1] = T[2] = 0;
    if (c->controller == CTRL_EDGE_LQR) {
        float th, err;
        edge_theta(q, &th);
        err = th + c->beta_ref;
        T[c->drive_wheel] = -(c->K_edge[0] * err + c->K_edge[1] * w[0] + c->K_edge[2] * om[c->drive_wheel]);
    } else if (c->controller == CTRL_CORNER_MIMO) {
        float qc[4], qe[4], phi[3], x[9];
        int i, j;
        (void)ctrl_psi(k, q);                      /* the unwrapped heading follows every estimate (as YawTracker) */
        aq_conj(k->q_ref, qc);
        aq_mul(qc, q, qe);
        aq_log(qe, phi);
        x[0] = phi[0]; x[1] = phi[1]; x[2] = phi[2]; x[3] = w[0]; x[4] = w[1]; x[5] = w[2]; x[6] = om[0]; x[7] = om[1]; x[8] = om[2];
        for (i = 0; i < 3; i++) { float s = 0; for (j = 0; j < 9; j++) s += c->K_corner[i][j] * x[j]; T[i] = -s; }
    }
}

void ctrl_tilt_error(const aeris_cfg_t *c, const ctrl_t *k, const float q[4], float *tilt) {
    if (c->mode == MODE_EDGE) {
        float th;
        edge_theta(q, &th);
        *tilt = th + c->beta_ref;
        if (*tilt < 0) *tilt = -*tilt;
    } else {
        /* angle between the balance axis (COM direction) and the world vertical */
        float up[3], d;
        (void)k;
        aq_up_in_body(q, up);
        d = av_dot(up, c->u_ref);
        if (d > 1) d = 1;
        if (d < -1) d = -1;
        *tilt = au_acosf(d);
    }
}

/* ------------------------------------------------------------------------------------------------ allocation 'clip' */
void alloc_clip(const aeris_cfg_t *c, const float req[3], const float om[3], alloc_out_t *o) {
    int i;
    o->any = false;
    for (i = 0; i < AERIS_NW; i++) {
        float T = au_isfinitef(req[i]) ? req[i] : 0.0f, tmax = c->w[i].torque_max;
        bool sat = !au_isfinitef(req[i]);
        if (T > tmax) { T = tmax; sat = true; }
        else if (T < -tmax) { T = -tmax; sat = true; }
        /* speed limit: no torque that would accelerate the wheel further once it is at its limit (loss of authority,
           as in the engine's actuator model); braking torque is always allowed */
        if (T * om[i] > 0 && (om[i] >= c->w[i].speed_max_rads || om[i] <= -c->w[i].speed_max_rads)) { T = 0; sat = true; }
        o->T[i] = T;
        o->saturated[i] = sat;
        o->any = o->any || sat;
    }
}

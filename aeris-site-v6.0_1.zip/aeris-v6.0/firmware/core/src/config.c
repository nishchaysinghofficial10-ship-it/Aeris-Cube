/* AERIS firmware core — approved configuration (aeris-device-config/1): parse and validate (see control.h).
 * The device trusts nothing in a configuration: every value is checked here, against fixed ranges and against the
 * board's compiled-in caps; an unsupported controller, estimator or driver is refused by name (never replaced). */
#include "aeris/control.h"
#include "aeris/drivers.h"
#include "aeris/util.h"

#define DEG 0.017453292519943295f
#define RPM 0.10471975511965977f

typedef struct { char *err; size_t cap; bool bad; } E;

static void fail(E *e, const char *path, const char *why) {
    size_t n;
    if (e->bad) return;                      /* the first error is reported */
    e->bad = true;
    n = au_strlcpy(e->err, path, e->cap);
    if (n + 2 < e->cap) { e->err[n] = ':'; e->err[n + 1] = ' '; au_strlcpy(e->err + n + 2, why, e->cap - n - 2); }
}

static bool num(E *e, const aj_doc_t *d, int obj, const char *key, const char *path, float lo, float hi, float *out) {
    double v;
    int t = aj_get(d, obj, key);
    if (t < 0) { fail(e, path, "required"); return false; }
    if (!aj_num(d, t, &v) || !au_isfinite(v)) { fail(e, path, "must be a finite number"); return false; }
    if (v < (double)lo || v > (double)hi) { fail(e, path, "out of the allowed range"); return false; }
    *out = (float)v;
    return true;
}
static bool inum(E *e, const aj_doc_t *d, int obj, const char *key, const char *path, int64_t lo, int64_t hi, int64_t *out) {
    int t = aj_get(d, obj, key);
    if (t < 0) { fail(e, path, "required"); return false; }
    if (!aj_int(d, t, out)) { fail(e, path, "must be an integer"); return false; }
    if (*out < lo || *out > hi) { fail(e, path, "out of the allowed range"); return false; }
    return true;
}
static bool vec(E *e, const aj_doc_t *d, int obj, const char *key, const char *path, float *out, int n) {
    int t = aj_get(d, obj, key);
    if (t < 0) { fail(e, path, "required"); return false; }
    if (!aj_vecf(d, t, out, n)) { fail(e, path, n == 3 ? "must be 3 finite numbers" : n == 4 ? "must be 4 finite numbers" : "wrong length or not finite"); return false; }
    return true;
}
static bool str_is(E *e, const aj_doc_t *d, int obj, const char *key, const char *path, const char *want, const char *why) {
    int t = aj_get(d, obj, key);
    if (t < 0) { fail(e, path, "required"); return false; }
    if (!aj_str_eq(d, t, want)) { fail(e, path, why); return false; }
    return true;
}
static bool has_driver(const char *list, const char *name) {
    size_t n = au_strlen(name);
    const char *p = list;
    if (!list) return false;
    while (*p) {
        const char *q = p;
        while (*q && *q != ',') q++;
        if ((size_t)(q - p) == n && au_memcmp(p, name, n) == 0) return true;
        p = *q ? q + 1 : q;
    }
    return false;
}
static bool unit(const float *v, int n, float tol) {
    float s = 0;
    int i;
    for (i = 0; i < n; i++) s += v[i] * v[i];
    return s > (1 - tol) * (1 - tol) && s < (1 + tol) * (1 + tol);
}

bool cfg_parse(aeris_cfg_t *c, const aj_doc_t *d, int obj, const aeris_board_t *b, char *errbuf, size_t errcap) {
    E e = {errbuf, errcap, false};
    int t, k, i;
    int64_t iv;
    char s[48];
    au_memset(c, 0, sizeof *c);
    if (errcap) errbuf[0] = 0;
    if (!aj_is(d, obj, JSMN_OBJECT)) { fail(&e, "config", "must be an object"); return false; }
    str_is(&e, d, obj, "schema", "config.schema", "aeris-device-config/1", "unsupported configuration schema (this firmware reads aeris-device-config/1)");
    /* identity of what it was made from */
    t = aj_get(d, obj, "profile");
    if (t < 0 || !aj_is(d, t, JSMN_OBJECT)) fail(&e, "config.profile", "required object {id, revision, hash}");
    else if (!aj_str(d, aj_get(d, t, "hash"), c->profile_hash, sizeof c->profile_hash) || au_strlen(c->profile_hash) != 64) fail(&e, "config.profile.hash", "64 hex characters required");
    t = aj_get(d, obj, "recipe");
    if (t < 0 || !aj_str(d, t, c->recipe, sizeof c->recipe) || !c->recipe[0]) fail(&e, "config.recipe", "required (the approved experiment recipe id)");
    /* mode and controller */
    t = aj_get(d, obj, "mode");
    if (aj_str_eq(d, t, "edge")) c->mode = MODE_EDGE;
    else if (aj_str_eq(d, t, "corner")) c->mode = MODE_CORNER;
    else fail(&e, "config.mode", "edge or corner");
    t = aj_get(d, obj, "controller");
    if (t < 0 || !aj_is(d, t, JSMN_OBJECT)) fail(&e, "config.controller", "required object");
    else if (!e.bad) {
        int ty = aj_get(d, t, "type");
        if (c->mode == MODE_EDGE && aj_str_eq(d, ty, "edge-lqr")) {
            c->controller = CTRL_EDGE_LQR;
            if (vec(&e, d, t, "K", "config.controller.K", c->K_edge, 3)) {
                for (i = 0; i < 3; i++) if (c->K_edge[i] < -1e4f || c->K_edge[i] > 1e4f) fail(&e, "config.controller.K", "gain magnitude above 1e4");
            }
            num(&e, d, t, "beta_ref_rad", "config.controller.beta_ref_rad", -0.5f, 0.5f, &c->beta_ref);
            if (inum(&e, d, t, "drive_wheel", "config.controller.drive_wheel", 0, 2, &iv)) c->drive_wheel = (int)iv;
        } else if (c->mode == MODE_CORNER && aj_str_eq(d, ty, "corner-mimo-lqr")) {
            int kt = aj_get(d, t, "K");
            c->controller = CTRL_CORNER_MIMO;
            if (aj_arr_len(d, kt) != 3) fail(&e, "config.controller.K", "must be 3 rows of 9 gains (wheels × [φ; ω; Ω])");
            else for (k = 0; k < 3; k++) {
                if (!aj_vecf(d, aj_arr_at(d, kt, k), c->K_corner[k], 9)) { fail(&e, "config.controller.K", "each row must be 9 finite numbers"); break; }
                for (i = 0; i < 9; i++) if (c->K_corner[k][i] < -1e4f || c->K_corner[k][i] > 1e4f) fail(&e, "config.controller.K", "gain magnitude above 1e4");
            }
            if (vec(&e, d, t, "q_eq", "config.controller.q_eq", c->q_eq, 4) && !unit(c->q_eq, 4, 1e-3f)) fail(&e, "config.controller.q_eq", "must be a unit quaternion");
            if (vec(&e, d, t, "u_ref", "config.controller.u_ref", c->u_ref, 3) && !unit(c->u_ref, 3, 1e-3f)) fail(&e, "config.controller.u_ref", "must be a unit vector");
        } else {
            fail(&e, "config.controller.type", "unsupported on this firmware: it implements edge-lqr (edge) and corner-mimo-lqr (corner) only; no other controller is substituted");
        }
    }
    /* estimator */
    t = aj_get(d, obj, "estimator");
    if (t < 0 || !aj_is(d, t, JSMN_OBJECT)) fail(&e, "config.estimator", "required object");
    else {
        int ce;
        bool cd = true;
        str_is(&e, d, t, "type", "config.estimator.type", "cf3d", "unsupported on this firmware: it implements cf3d (complementary quaternion filter) only");
        num(&e, d, t, "tau_s", "config.estimator.tau_s", 0.01f, 10.0f, &c->tau_s);
        num(&e, d, t, "accel_gate_mps2", "config.estimator.accel_gate_mps2", 0.01f, 5.0f, &c->accel_gate);
        num(&e, d, t, "bias_gain", "config.estimator.bias_gain", 0.0f, 1.0f, &c->bias_gain);
        num(&e, d, t, "tau_alpha_s", "config.estimator.tau_alpha_s", 0.001f, 1.0f, &c->tau_alpha_s);
        num(&e, d, t, "stale_after_s", "config.estimator.stale_after_s", 0.0005f, 1.0f, &c->stale_after_s);
        num(&e, d, t, "g_mps2", "config.estimator.g_mps2", 9.7f, 9.9f, &c->g);
        if (vec(&e, d, t, "imu_position_m", "config.estimator.imu_position_m", c->imu_pos, 3)) {
            float n = au_sqrtf(c->imu_pos[0] * c->imu_pos[0] + c->imu_pos[1] * c->imu_pos[1] + c->imu_pos[2] * c->imu_pos[2]);
            if (n > 0.5f) fail(&e, "config.estimator.imu_position_m", "further than 0.5 m from the pivot");
        }
        if (vec(&e, d, t, "q_nominal", "config.estimator.q_nominal", c->q_nominal, 4) && !unit(c->q_nominal, 4, 1e-3f)) fail(&e, "config.estimator.q_nominal", "must be a unit quaternion");
        ce = aj_get(d, t, "compensate_dynamic");
        if (ce >= 0 && !aj_bool(d, ce, &cd)) fail(&e, "config.estimator.compensate_dynamic", "true or false");
        c->compensate_dynamic = cd;
    }
    /* IMU */
    t = aj_get(d, obj, "imu");
    if (t < 0 || !aj_is(d, t, JSMN_OBJECT)) fail(&e, "config.imu", "required object");
    else {
        int dt = aj_get(d, t, "driver");
        float m[9];
        if (!aj_str(d, dt, s, sizeof s)) fail(&e, "config.imu.driver", "required");
        else if (!au_streq(s, "lsm6dsox") || !has_driver(b->imu_drivers, s)) fail(&e, "config.imu.driver", "not built into this firmware (it contains: lsm6dsox); readings are never fabricated for another sensor");
        if (inum(&e, d, t, "i2c_address", "config.imu.i2c_address", 0x6A, 0x6B, &iv)) c->imu_addr = (uint8_t)iv;
        if (inum(&e, d, t, "odr_hz", "config.imu.odr_hz", 12, 6667, &iv)) { c->imu_odr_hz = (int)iv; if (!lsm_odr_code(c->imu_odr_hz)) fail(&e, "config.imu.odr_hz", "not an LSM6DSOX output data rate"); }
        if (inum(&e, d, t, "accel_range_g", "config.imu.accel_range_g", 2, 16, &iv)) { c->imu_fs_g = (int)iv; if (lsm_fs_xl_code(c->imu_fs_g) < 0) fail(&e, "config.imu.accel_range_g", "2, 4, 8 or 16"); }
        if (inum(&e, d, t, "gyro_range_dps", "config.imu.gyro_range_dps", 125, 2000, &iv)) { c->imu_fs_dps = (int)iv; if (lsm_fs_g_code(c->imu_fs_dps) < 0) fail(&e, "config.imu.gyro_range_dps", "125, 250, 500, 1000 or 2000"); }
        if (vec(&e, d, t, "to_body", "config.imu.to_body", m, 9)) {
            /* a signed permutation with determinant +1: the IMU is mounted along the body axes */
            int r, cc, nz;
            float det;
            for (r = 0; r < 9; r++) if (!(m[r] == 0.0f || m[r] == 1.0f || m[r] == -1.0f)) fail(&e, "config.imu.to_body", "entries must be −1, 0 or 1 (axis-aligned mounting)");
            for (r = 0; r < 3; r++) { nz = 0; for (cc = 0; cc < 3; cc++) nz += m[3 * r + cc] != 0.0f; if (nz != 1) fail(&e, "config.imu.to_body", "each row needs exactly one non-zero entry"); }
            for (cc = 0; cc < 3; cc++) { nz = 0; for (r = 0; r < 3; r++) nz += m[3 * r + cc] != 0.0f; if (nz != 1) fail(&e, "config.imu.to_body", "each column needs exactly one non-zero entry"); }
            det = m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6]);
            if (det < 0.5f) fail(&e, "config.imu.to_body", "must be a rotation (determinant +1), not a reflection");
            au_memcpy(c->imu_to_body, m, sizeof m);
        }
        if (vec(&e, d, t, "gyro_bias_radps", "config.imu.gyro_bias_radps", c->gyro_bias, 3))
            for (i = 0; i < 3; i++) if (c->gyro_bias[i] > 0.2f || c->gyro_bias[i] < -0.2f) fail(&e, "config.imu.gyro_bias_radps", "above 0.2 rad/s: recalibrate");
    }
    /* wheels */
    t = aj_get(d, obj, "wheels");
    if (aj_arr_len(d, t) != AERIS_NW) fail(&e, "config.wheels", "exactly three wheels (this firmware supports the three-wheel topology only)");
    else for (k = 0; k < AERIS_NW && !e.bad; k++) {
        int wt = aj_arr_at(d, t, k), dr;
        aeris_wheel_cfg_t *w = &c->w[k];
        float sg, smax;
        if (!aj_is(d, wt, JSMN_OBJECT)) { fail(&e, "config.wheels[]", "must be objects"); break; }
        if (vec(&e, d, wt, "axis", "config.wheels[].axis", w->axis, 3) && !unit(w->axis, 3, 1e-3f)) fail(&e, "config.wheels[].axis", "must be a unit vector");
        if (num(&e, d, wt, "sign", "config.wheels[].sign", -1.0f, 1.0f, &sg)) { if (sg != 1.0f && sg != -1.0f) fail(&e, "config.wheels[].sign", "+1 or −1"); w->sign = sg; }
        dr = aj_get(d, wt, "driver");
        if (!aj_str(d, dr, s, sizeof s)) fail(&e, "config.wheels[].driver", "required");
        else if (!au_streq(s, "odrive-cansimple") || !has_driver(b->motor_drivers, s)) fail(&e, "config.wheels[].driver", "not built into this firmware (it contains: odrive-cansimple)");
        if (inum(&e, d, wt, "node", "config.wheels[].node", 1, 62, &iv)) w->node = (uint8_t)iv;
        num(&e, d, wt, "Jw_kgm2", "config.wheels[].Jw_kgm2", 1e-6f, 0.05f, &w->Jw);
        num(&e, d, wt, "kt_NmA", "config.wheels[].kt_NmA", 1e-4f, 1.0f, &w->kt);
        num(&e, d, wt, "current_max_A", "config.wheels[].current_max_A", 0.01f, b->hard_max_current_A, &w->current_max);
        num(&e, d, wt, "torque_max_Nm", "config.wheels[].torque_max_Nm", 1e-5f, b->hard_max_torque_Nm, &w->torque_max);
        if (num(&e, d, wt, "speed_max_rpm", "config.wheels[].speed_max_rpm", 10.0f, b->hard_max_speed_rpm, &smax)) w->speed_max_rads = smax * RPM;
        if (!e.bad && w->torque_max > w->kt * w->current_max * 1.0001f) fail(&e, "config.wheels[].torque_max_Nm", "above k_t × current_max: inconsistent with the motor limits");
    }
    if (!e.bad) {
        float det;
        for (k = 0; k < AERIS_NW; k++) for (i = k + 1; i < AERIS_NW; i++) if (c->w[k].node == c->w[i].node) fail(&e, "config.wheels[].node", "node ids must be distinct");
        det = c->w[0].axis[0] * (c->w[1].axis[1] * c->w[2].axis[2] - c->w[1].axis[2] * c->w[2].axis[1])
            - c->w[0].axis[1] * (c->w[1].axis[0] * c->w[2].axis[2] - c->w[1].axis[2] * c->w[2].axis[0])
            + c->w[0].axis[2] * (c->w[1].axis[0] * c->w[2].axis[1] - c->w[1].axis[1] * c->w[2].axis[0]);
        if (det < 0.5f && det > -0.5f) fail(&e, "config.wheels", "the three axes are (nearly) coplanar: not a supported topology");
        if (c->mode == MODE_EDGE && !e.bad) {
            float ax = c->w[c->drive_wheel].axis[0];
            if (ax < 0.9f && ax > -0.9f) fail(&e, "config.controller.drive_wheel", "the edge drive wheel must spin about the support edge (body x)");
        }
    }
    /* limits */
    t = aj_get(d, obj, "limits");
    if (t < 0 || !aj_is(d, t, JSMN_OBJECT)) fail(&e, "config.limits", "required object");
    else {
        float v;
        if (num(&e, d, t, "tilt_start_deg", "config.limits.tilt_start_deg", 0.1f, 15.0f, &v)) c->tilt_start_rad = v * DEG;
        if (num(&e, d, t, "tilt_abort_deg", "config.limits.tilt_abort_deg", 0.5f, 30.0f, &v)) c->tilt_abort_rad = v * DEG;
        if (num(&e, d, t, "wheel_speed_abort_rpm", "config.limits.wheel_speed_abort_rpm", 10.0f, b->hard_max_speed_rpm * 1.1f, &v)) c->speed_abort_rads = v * RPM;
        num(&e, d, t, "current_abort_A", "config.limits.current_abort_A", 0.01f, b->hard_max_current_A * 1.1f, &c->current_abort_A);
        num(&e, d, t, "temperature_abort_C", "config.limits.temperature_abort_C", 20.0f, 120.0f, &c->temp_abort_C);
        num(&e, d, t, "vbus_min_V", "config.limits.vbus_min_V", 1.0f, 60.0f, &c->vbus_min_V);
        num(&e, d, t, "vbus_max_V", "config.limits.vbus_max_V", 1.0f, 60.0f, &c->vbus_max_V);
        num(&e, d, t, "link_loss_max_s", "config.limits.link_loss_max_s", 0.0f, 30.0f, &c->link_loss_max_s);
        num(&e, d, t, "duration_max_s", "config.limits.duration_max_s", 1.0f, 300.0f, &c->duration_max_s);
        num(&e, d, t, "stop_torque_Nm", "config.limits.stop_torque_Nm", 0.0f, b->hard_max_torque_Nm, &c->stop_torque_Nm);
        num(&e, d, t, "arm_window_s", "config.limits.arm_window_s", 5.0f, 120.0f, &c->arm_window_s);
        if (!e.bad) {
            if (c->tilt_start_rad >= c->tilt_abort_rad) fail(&e, "config.limits.tilt_start_deg", "must be below tilt_abort_deg");
            if (c->vbus_min_V >= c->vbus_max_V) fail(&e, "config.limits.vbus_min_V", "must be below vbus_max_V");
            for (k = 0; k < AERIS_NW; k++) {
                if (c->speed_abort_rads < c->w[k].speed_max_rads) fail(&e, "config.limits.wheel_speed_abort_rpm", "below a wheel's control speed limit: inconsistent");
                if (c->current_abort_A < c->w[k].current_max) fail(&e, "config.limits.current_abort_A", "below a wheel's current limit: inconsistent");
                if (c->stop_torque_Nm > c->w[k].torque_max) fail(&e, "config.limits.stop_torque_Nm", "above a wheel's torque limit");
            }
        }
    }
    /* rates */
    t = aj_get(d, obj, "rates");
    if (t < 0 || !aj_is(d, t, JSMN_OBJECT)) fail(&e, "config.rates", "required object");
    else {
        if (inum(&e, d, t, "control_hz", "config.rates.control_hz", 100, b->max_control_hz, &iv)) c->control_hz = (int)iv;
        if (inum(&e, d, t, "imu_hz", "config.rates.imu_hz", 12, 6667, &iv)) c->imu_hz = (int)iv;
        if (inum(&e, d, t, "telemetry_hz", "config.rates.telemetry_hz", 1, 500, &iv)) c->telemetry_hz = (int)iv;
        if (!e.bad && (c->telemetry_hz > c->control_hz || c->control_hz % c->telemetry_hz)) fail(&e, "config.rates.telemetry_hz", "must divide control_hz");
        if (!e.bad && c->imu_hz != c->imu_odr_hz) fail(&e, "config.rates.imu_hz", "must equal config.imu.odr_hz");
    }
    t = aj_get(d, obj, "allocation");
    if (!aj_str_eq(d, t, "clip")) fail(&e, "config.allocation", "this firmware implements 'clip' allocation only");
    c->valid = !e.bad;
    return c->valid;
}

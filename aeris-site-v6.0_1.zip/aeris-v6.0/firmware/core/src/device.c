/* AERIS firmware core — device lifecycle, local control loop and protection (see device.h). */
#include "aeris/device.h"
#include "aeris/json.h"
#include "aeris/mathq.h"
#include "aeris/util.h"

#define TWO_PI 6.283185307179586f
#define RPM_PER_RADS 9.549296585513721f
#define DRV_STALE_US 300000u           /* ODrive heartbeat default period: 100 ms */
#define ENC_STALE_US 25000u            /* encoder estimates must be fresher than this while driving */
#define CLOSED_LOOP_GRACE_US 300000u   /* time an ODrive may take to report CLOSED_LOOP_CONTROL */
#define IMU_BAD_LIMIT 5u
#define OVERRUN_LIMIT 10u
#define STOP_SPEED_DONE 5.0f            /* rad/s: below this every wheel is considered stopped */
#define STOP_TIMEOUT_US 20000000u

static const char *STATE_NAMES[ST_COUNT] = {"BOOT", "DISARMED", "SELF_TEST", "READY", "ARMED", "BALANCING", "STOPPING", "FAULT",
                                            "CALIBRATING", "UPDATE", "COMMISSIONING"};
static const char *FAULT_NAMES[] = {"IMU_ABSENT", "IMU_STALE", "IMU_INVALID", "IMU_SATURATED", "DRV_ABSENT", "DRV_STALE", "DRV_ERROR",
                                    "ENC_STALE", "OVERCURRENT", "OVERSPEED", "OVERTEMP", "UNDERVOLT", "OVERVOLT", "TILT_LIMIT",
                                    "EST_INVALID", "LOOP_OVERRUN", "ESTOP", "CONFIG", "CALIBRATION", "GRAVITY", "NOT_STILL"};

const char *aeris_state_name(aeris_state_t s) { return s < ST_COUNT ? STATE_NAMES[s] : "?"; }

size_t aeris_faults_json(uint32_t f, char *buf, size_t cap) {
    aw_t w;
    unsigned i;
    aw_init(&w, buf, cap);
    aw_arr(&w);
    for (i = 0; i < sizeof FAULT_NAMES / sizeof FAULT_NAMES[0]; i++) if (f & (1u << i)) aw_str(&w, FAULT_NAMES[i]);
    aw_end_arr(&w);
    return aw_done(&w) ? w.len : 0;
}

static uint64_t now_us(const aeris_dev_t *d) { return d->hal->time_us(d->hal->ctx); }
static const char *exp_result(aeris_dev_t *d, uint64_t now, int wheels_stopped, char *res, size_t cap);

bool aeris_actuation_permitted(const aeris_dev_t *d) { return d->board->actuation_build && d->cfg.valid; }

/* defaults used before an approved configuration exists: attitude estimate for diagnostics, no actuation */
static void default_cfg(aeris_cfg_t *c) {
    int i;
    au_memset(c, 0, sizeof *c);
    c->valid = false;
    c->mode = -1;
    c->q_nominal[0] = 1; c->q_eq[0] = 1;
    c->tau_s = 0.5f; c->accel_gate = 0.5f; c->tau_alpha_s = 0.02f; c->compensate_dynamic = false; c->stale_after_s = 0.02f; c->g = 9.80665f;
    c->imu_addr = 0x6A; c->imu_odr_hz = 833; c->imu_fs_g = 8; c->imu_fs_dps = 2000;
    c->imu_to_body[0] = c->imu_to_body[4] = c->imu_to_body[8] = 1;
    for (i = 0; i < AERIS_NW; i++) { c->w[i].node = (uint8_t)(i + 1); c->w[i].sign = 1; c->w[i].axis[i] = 1; }
    c->control_hz = 500; c->imu_hz = 833; c->telemetry_hz = 50;
}

uint32_t aeris_control_period_us(const aeris_dev_t *d) {
    int hz = d->cfg.control_hz > 0 ? d->cfg.control_hz : 500;
    return (uint32_t)(1000000 / hz);
}

static void log_msg(aeris_dev_t *d, int level, const char *m) { if (d->hal->log) d->hal->log(d->hal->ctx, level, m); }

/* ------------------------------------------------------------------------------------------------ state */
void dev_set_state(aeris_dev_t *d, aeris_state_t s, const char *reason) {
    if (d->state == s && !reason) return;
    d->prev_state = d->state;
    d->state = s;
    au_strlcpy(d->state_reason, reason ? reason : "", sizeof d->state_reason);
    if (s != ST_BALANCING && s != ST_STOPPING && s != ST_COMMISSIONING) dev_drivers_idle(d);
    if (s == ST_DISARMED || s == ST_FAULT || s == ST_BOOT || s == ST_UPDATE) { d->armed_at = 0; }
    dev_power_policy(d);
    if (d->hal->led) d->hal->led(d->hal->ctx, (int)s);
    dev_send_state(d);
}

/* Driver power (HAL motor_power: the DRIVE_EN output of the board, intended for the relay/contactor with pre-charge in
 * series with the hardware stop chain — docs/hardware). Asserted only in the states that need powered drivers; never
 * in BOOT, DISARMED, FAULT or UPDATE. The hardware stop chain removes power independently of this output. */
bool dev_drivers_powered_state(const aeris_dev_t *d) {
    switch (d->state) {
    case ST_SELF_TEST: case ST_READY: case ST_ARMED: case ST_BALANCING: case ST_STOPPING: case ST_COMMISSIONING: return true;
    case ST_CALIBRATING: return d->task == TASK_ENCODERS;
    default: return false;
    }
}

void dev_power_policy(aeris_dev_t *d) {
    bool on = dev_drivers_powered_state(d);
    if ((d->latched & F_ESTOP) || (d->hal->stop_input && d->hal->stop_input(d->hal->ctx))) on = false;
    if (d->hal->motor_power) d->hal->motor_power(d->hal->ctx, on);
}

void dev_fault(aeris_dev_t *d, uint32_t bits, const char *reason) {
    bool had_exp = d->exp_active || d->state == ST_STOPPING;
    d->faults |= bits;
    d->latched |= bits;
    dev_drivers_idle(d);
    if (d->hal->motor_power) d->hal->motor_power(d->hal->ctx, false);
    d->exp_active = false;
    if (had_exp) au_strlcpy(d->exp_end_reason, reason, sizeof d->exp_end_reason);
    if (d->state != ST_FAULT) dev_set_state(d, ST_FAULT, reason);
    else dev_send_state(d);
    if (had_exp && d->exp_cmd[0]) {
        char res[256];
        cmd_report(d, d->exp_link, d->exp_cmd, "cmd_result", "failed", reason, exp_result(d, now_us(d), -1, res, sizeof res));
    }
    d->exp_cmd[0] = 0;
    cmd_cancel_pending(d, reason);
}

void dev_drivers_idle(aeris_dev_t *d) {
    int i;
    for (i = 0; i < AERIS_NW; i++) {
        odrv_set_torque(&d->drv[i], d->hal, 0.0f);
        odrv_set_state(&d->drv[i], d->hal, ODRV_AXIS_IDLE);
        d->torque_cmd[i] = 0;
    }
    d->drivers_closed_loop = false;
}

void dev_drivers_closed_loop(aeris_dev_t *d) {
    int i;
    if (d->hal->motor_power) d->hal->motor_power(d->hal->ctx, true);
    for (i = 0; i < AERIS_NW; i++) {
        if (d->cfg.valid) odrv_set_limits(&d->drv[i], d->hal, d->cfg.w[i].speed_max_rads / TWO_PI, d->cfg.w[i].current_max);
        odrv_set_torque_mode(&d->drv[i], d->hal);
        odrv_set_torque(&d->drv[i], d->hal, 0.0f);
        odrv_set_state(&d->drv[i], d->hal, ODRV_AXIS_CLOSED_LOOP);
    }
    d->drivers_closed_loop = true;
}

/* ------------------------------------------------------------------------------------------------ init */
static void load_identity(aeris_dev_t *d) {
    uint8_t rnd[8], b[8];
    size_t n = 0;
    d->hal->random(d->hal->ctx, rnd, sizeof rnd);
    au_fmt_hex(d->boot_id, sizeof d->boot_id, rnd, sizeof rnd);
    d->have_key = d->hal->key_public && d->hal->key_public(d->hal->ctx, d->pub, false) == 0;
    d->paired = d->hal->nvs_get && d->hal->nvs_get(d->hal->ctx, "paired", b, sizeof b, &n) == 0 && n == 1 && b[0] == 1;
}

void dev_setup_hw(aeris_dev_t *d) {
    int i, r;
    const aeris_cfg_t *c = &d->cfg;
    r = lsm_init(&d->imu, d->hal, c->imu_addr, c->imu_odr_hz, c->imu_fs_g, c->imu_fs_dps);
    d->imu_ok = r == LSM_OK;
    if (!d->imu_ok) {
        d->faults |= F_IMU_ABSENT;
        log_msg(d, 2, r == LSM_ERR_WRONG_ID ? "IMU: a device answers at the address but it is not an LSM6DSOX (WHO_AM_I mismatch): not used"
                                            : "IMU: LSM6DSOX not detected (no answer on I2C): no attitude estimate");
    } else d->faults &= ~F_IMU_ABSENT;
    for (i = 0; i < AERIS_NW; i++) odrv_init(&d->drv[i], c->w[i].node);
    dev_drivers_idle(d);
    est_init(&d->est, c);
    ctrl_init(&d->ctrl, c);
    d->tlm_hz = c->telemetry_hz > 0 ? c->telemetry_hz : 50;
}

void aeris_init(aeris_dev_t *d, const aeris_hal_t *hal, const aeris_board_t *board, const char *device_id) {
    au_memset(d, 0, sizeof *d);
    d->hal = hal;
    d->board = board;
    au_strlcpy(d->device_id, device_id, sizeof d->device_id);
    d->state = ST_BOOT;
    d->boot_us = now_us(d);
    d->q[0] = 1;
    load_identity(d);
    default_cfg(&d->cfg);        /* an approved configuration is applied by a host after every boot (never assumed) */
    if (d->hal->motor_power) d->hal->motor_power(d->hal->ctx, false);
    dev_setup_hw(d);
    dev_tlm_new_session(d);
    dev_set_state(d, ST_DISARMED, "boot complete; motors disabled");
}

/* ------------------------------------------------------------------------------------------------ sensing */
static void read_imu(aeris_dev_t *d, uint64_t now) {
    float gs[3], as[3], tc = 0, gb[3], ab[3];
    bool fresh = false, sat = false;
    int r, i;
    d->imu_fresh = false;
    if (!d->imu_ok) return;
    r = lsm_read(&d->imu, d->hal, gs, as, &tc, &fresh, &sat);
    if (r != LSM_OK) {
        if (++d->imu_bad_reads >= IMU_BAD_LIMIT) d->faults |= F_IMU_STALE;
        return;
    }
    au_memcpy(d->gyro_raw, gs, sizeof gs);
    au_memcpy(d->accel_raw, as, sizeof as);
    am_vec(d->cfg.imu_to_body, gs, gb);
    am_vec(d->cfg.imu_to_body, as, ab);
    for (i = 0; i < 3; i++) gb[i] -= d->cfg.gyro_bias[i];
    if (!au_isfinitef(gb[0]) || !au_isfinitef(gb[1]) || !au_isfinitef(gb[2]) || !au_isfinitef(ab[0]) || !au_isfinitef(ab[1]) || !au_isfinitef(ab[2])) {
        d->faults |= F_IMU_INVALID;
        return;
    }
    d->imu_saturated = sat;
    if (sat) d->faults |= F_IMU_SATURATED; else d->faults &= ~F_IMU_SATURATED;
    if (!fresh) { if (++d->imu_bad_reads >= IMU_BAD_LIMIT) d->faults |= F_IMU_STALE; return; }
    d->imu_bad_reads = 0;
    d->faults &= ~(F_IMU_STALE | F_IMU_INVALID);
    au_memcpy(d->gyro, gb, sizeof gb);
    au_memcpy(d->accel, ab, sizeof ab);
    d->temp_c = tc;
    d->imu_fresh = true;
    (void)now;
}

static void read_bus(aeris_dev_t *d, uint64_t now) {
    uint32_t id;
    uint8_t data[8], len;
    bool rtr;
    int guard = 64, i;
    float vmin = 1e9f;
    bool any_v = false;
    while (guard-- > 0 && d->hal->can_recv(d->hal->ctx, &id, data, &len, &rtr) == 1) odrv_dispatch(d->drv, AERIS_NW, id, data, len, rtr, now);
    for (i = 0; i < AERIS_NW; i++) {
        odrv_t *m = &d->drv[i];
        float s = d->cfg.w[i].sign != 0 ? d->cfg.w[i].sign : 1.0f;
        d->omega[i] = s * m->vel_rev_s * TWO_PI;
        d->torque_meas[i] = s * m->torque_est_Nm;
        if (m->t_bus_us && now - m->t_bus_us < 2000000u && m->vbus_V > 0) { any_v = true; if (m->vbus_V < vmin) vmin = m->vbus_V; }
    }
    d->vbus = any_v ? vmin : -1.0f;
    /* low-rate requests of the slow signals, one per step, round robin (encoder estimates are expected cyclically) */
    {
        static const uint8_t slow[] = {ODRV_CMD_GET_BUS, ODRV_CMD_GET_TEMPERATURE, ODRV_CMD_GET_IQ, ODRV_CMD_GET_TORQUES};
        uint32_t k = d->steps % (uint32_t)(AERIS_NW * 4 * 5);
        if (k % 5 == 0) { k /= 5; odrv_request(&d->drv[k % AERIS_NW], d->hal, slow[(k / AERIS_NW) % 4]); }
    }
}

static void estimate(aeris_dev_t *d, uint64_t now) {
    double t = (double)(now - d->boot_us) * 1e-6;
    if (d->imu_fresh) est_accept(&d->est, t, d->gyro, d->accel, t);
    d->est_valid = est_predict(&d->est, t, d->q, d->w, &d->est_age);
    if (d->cfg.mode == MODE_EDGE) edge_theta(d->q, &d->theta);
    if (d->cfg.valid) ctrl_tilt_error(&d->cfg, &d->ctrl, d->q, &d->tilt);
    if (d->est_valid) d->faults &= ~F_EST_INVALID; else d->faults |= F_EST_INVALID;
}

/* ------------------------------------------------------------------------------------------------ protection
 * Computes the fault bits of this step from the measurements; returns the bits that must stop a motor-driving state. */
static uint32_t protect(aeris_dev_t *d, uint64_t now, bool driving) {
    uint32_t f = 0;
    int i;
    const aeris_cfg_t *c = &d->cfg;
    if (d->hal->stop_input && d->hal->stop_input(d->hal->ctx)) f |= F_ESTOP;
    if (!d->imu_ok) f |= F_IMU_ABSENT;
    f |= d->faults & (F_IMU_STALE | F_IMU_INVALID | F_IMU_SATURATED);
    for (i = 0; i < AERIS_NW; i++) {          /* an error a driver reports in a fresh heartbeat counts in every state */
        const odrv_t *m = &d->drv[i];
        if (m->seen && now - m->t_heartbeat_us <= DRV_STALE_US && m->axis_error) f |= F_DRV_ERROR;
    }
    if (driving) {
        if (!d->est_valid && d->state != ST_COMMISSIONING) f |= F_EST_INVALID;
        for (i = 0; i < AERIS_NW; i++) {
            odrv_t *m = &d->drv[i];
            if (!m->seen) f |= F_DRV_ABSENT;
            else if (now - m->t_heartbeat_us > DRV_STALE_US) f |= F_DRV_STALE;
            if (d->drivers_closed_loop && now - d->exp_start_us > CLOSED_LOOP_GRACE_US && m->axis_state != ODRV_AXIS_CLOSED_LOOP && d->state == ST_BALANCING) f |= F_DRV_ERROR;
            if (!m->t_encoder_us || now - m->t_encoder_us > ENC_STALE_US) f |= F_ENC_STALE;
        }
    }
    if (c->valid) {
        for (i = 0; i < AERIS_NW; i++) {
            odrv_t *m = &d->drv[i];
            if (d->omega[i] > c->speed_abort_rads || d->omega[i] < -c->speed_abort_rads) f |= F_OVERSPEED;
            if (m->t_iq_us && now - m->t_iq_us < 1000000u && (m->iq_meas_A > c->current_abort_A || m->iq_meas_A < -c->current_abort_A)) f |= F_OVERCURRENT;
            if (m->t_temp_us && now - m->t_temp_us < 2000000u && (m->fet_temp_C > c->temp_abort_C || m->motor_temp_C > c->temp_abort_C)) f |= F_OVERTEMP;
        }
        if (d->vbus > 0 && d->vbus < c->vbus_min_V) f |= F_UNDERVOLT;
        if (d->vbus > c->vbus_max_V) f |= F_OVERVOLT;
        if (driving && d->state == ST_BALANCING && d->tilt > c->tilt_abort_rad) f |= F_TILT_LIMIT;
    }
    if (d->overrun_run >= OVERRUN_LIMIT) f |= F_LOOP_OVERRUN;
    d->faults = (d->faults & ~(F_ESTOP | F_DRV_ABSENT | F_DRV_STALE | F_DRV_ERROR | F_ENC_STALE | F_OVERSPEED | F_OVERCURRENT | F_OVERTEMP |
                               F_UNDERVOLT | F_OVERVOLT | F_TILT_LIMIT | F_LOOP_OVERRUN)) | f;
    return f;
}

/* the faults that stop a motor-driving state. IMU saturation is recorded (and the estimator gates the accelerometer)
 * but does not stop by itself: the tilt and rate limits do. A commissioning motor test does not use the attitude. */
static uint32_t abort_mask(const aeris_dev_t *d) {
    uint32_t m = ~(uint32_t)F_IMU_SATURATED;
    if (d->state == ST_COMMISSIONING) m &= ~(uint32_t)(F_IMU_ABSENT | F_IMU_STALE | F_IMU_INVALID | F_EST_INVALID | F_TILT_LIMIT);
    return m;
}

/* ------------------------------------------------------------------------------------------------ the control step */
static void set_torques(aeris_dev_t *d, const float T[3]) {
    int i;
    for (i = 0; i < AERIS_NW; i++) {
        float s = d->cfg.w[i].sign != 0 ? d->cfg.w[i].sign : 1.0f;
        d->torque_cmd[i] = T[i];
        odrv_set_torque(&d->drv[i], d->hal, s * T[i]);
    }
}

static void balance(aeris_dev_t *d, uint64_t now) {
    float req[3];
    alloc_out_t a;
    int i;
    ctrl_request(&d->ctrl, d->q, d->w, d->omega, req);
    alloc_clip(&d->cfg, req, d->omega, &a);
    set_torques(d, a.T);
    d->exp_steps++;                                       /* saturation is reported with the experiment's result */
    for (i = 0; i < AERIS_NW; i++) if (a.saturated[i]) d->exp_sat_steps[i]++;
    if (now >= d->exp_end_us) {
        au_strlcpy(d->exp_end_reason, "duration reached", sizeof d->exp_end_reason);
        d->stop_start_us = now;
        dev_set_state(d, ST_STOPPING, "experiment duration reached: normal stop");
    } else if (d->link_lost && d->cfg.link_loss_max_s >= 0 && now - d->link_lost_at >= (uint64_t)(d->cfg.link_loss_max_s * 1e6f)) {
        au_strlcpy(d->exp_end_reason, "supervisor link lost", sizeof d->exp_end_reason);
        d->stop_start_us = now;
        dev_set_state(d, ST_STOPPING, "supervisor link lost for longer than limits.link_loss_max_s: normal stop");
    }
}

/* the experiment's result object: how it ended, how long it ran, and in how many balancing control steps each wheel's
 * requested torque was limited by the allocation (torque limit, speed limit or a non-finite request) */
static const char *exp_result(aeris_dev_t *d, uint64_t now, int wheels_stopped, char *res, size_t cap) {
    aw_t w;
    int i;
    aw_init(&w, res, cap);
    aw_obj(&w);
    aw_kstr(&w, "ended", d->exp_end_reason);
    aw_knum(&w, "duration_s", (double)(now - d->exp_start_us) * 1e-6, 6);
    if (wheels_stopped >= 0) aw_kbool(&w, "wheels_stopped", wheels_stopped != 0);
    aw_kuint(&w, "balancing_steps", d->exp_steps);
    aw_key(&w, "saturated_steps"); aw_arr(&w);
    for (i = 0; i < AERIS_NW; i++) aw_uint(&w, d->exp_sat_steps[i]);
    aw_end_arr(&w);
    aw_end_obj(&w);
    return aw_done(&w) ? res : 0;
}

/* normal stop: the balance controller is off; every wheel is braked with at most stop_torque (the body receives at most
 * that reaction torque and tips onto its fixture/catch under gravity); when every wheel is below STOP_SPEED_DONE, or after
 * STOP_TIMEOUT_US, the drivers go idle (coast) and the device is DISARMED. */
static void stopping(aeris_dev_t *d, uint64_t now) {
    float T[3];
    int i;
    bool done = true;
    float dt = 1.0f / (float)(d->cfg.control_hz > 0 ? d->cfg.control_hz : 500);
    for (i = 0; i < AERIS_NW; i++) {
        float om = d->omega[i], lim = d->cfg.stop_torque_Nm, need = d->cfg.w[i].Jw * (om < 0 ? -om : om) / dt;
        float mag = need < lim ? need : lim;
        T[i] = om > 0 ? -mag : om < 0 ? mag : 0;
        if (om > STOP_SPEED_DONE || om < -STOP_SPEED_DONE) done = false;
    }
    set_torques(d, T);
    if (done || now - d->stop_start_us > STOP_TIMEOUT_US) {
        char res[256];
        d->exp_active = false;
        if (d->exp_cmd[0]) cmd_report(d, d->exp_link, d->exp_cmd, "cmd_result", "completed", d->exp_end_reason, exp_result(d, now, done, res, sizeof res));
        d->exp_cmd[0] = 0;
        dev_set_state(d, ST_DISARMED, done ? "normal stop complete: wheels stopped, drivers idle" : "normal stop: timeout, drivers idle (coasting)");
    }
}

static void commissioning(aeris_dev_t *d, uint64_t now) {
    float T[3] = {0, 0, 0};
    if (!(d->hal->commission_input && d->hal->commission_input(d->hal->ctx))) {
        if (d->motor_test_until_us) au_strlcpy(d->mt_end, "dead-man control released", sizeof d->mt_end);
        d->motor_test_until_us = 0;
        dev_set_state(d, ST_DISARMED, "commissioning control released: drivers idle");
        return;
    }
    if (d->motor_test_until_us && now < d->motor_test_until_us) {
        int i = d->motor_test_wheel;
        float om = d->omega[i];
        if (om > d->board->commissioning_max_speed_rpm / RPM_PER_RADS || om < -d->board->commissioning_max_speed_rpm / RPM_PER_RADS) {
            d->motor_test_until_us = 0;                         /* speed cap reached: torque off */
            au_strlcpy(d->mt_end, "speed cap reached", sizeof d->mt_end);
        } else T[i] = d->motor_test_torque;
    } else if (d->motor_test_until_us) {
        d->motor_test_until_us = 0;
        au_strlcpy(d->mt_end, "duration reached", sizeof d->mt_end);
    }
    if (!d->motor_test_until_us) {                    /* between tests: drivers idle (no closed loop, no torque) */
        if (d->drivers_closed_loop) dev_drivers_idle(d);
        return;
    }
    if (!d->drivers_closed_loop) dev_drivers_closed_loop(d);
    set_torques(d, T);
}

void aeris_control_step(aeris_dev_t *d) {
    uint64_t now = now_us(d), end;
    uint32_t period = aeris_control_period_us(d), dur, abort_bits;
    bool driving = d->state == ST_BALANCING || d->state == ST_STOPPING || (d->state == ST_COMMISSIONING && d->motor_test_until_us);
    d->step_start_us = now;
    /* local controls */
    d->arm_now = d->hal->arm_input && d->hal->arm_input(d->hal->ctx);
    if (d->arm_now && !d->arm_prev) { d->arm_pressed_at = now; d->arm_consumed = false; }
    read_bus(d, now);
    read_imu(d, now);
    estimate(d, now);
    abort_bits = protect(d, now, driving);
    if ((abort_bits & F_ESTOP) && dev_drivers_powered_state(d)) {
        /* the local stop while the drivers may be powered: latched fault. While DISARMED (drivers unpowered) an asserted
           stop only blocks the self-test and arming (reported in faults; nothing to latch) */
        if (d->state != ST_FAULT || !(d->latched & F_ESTOP)) dev_fault(d, F_ESTOP, "local stop asserted: drivers idle");
    } else if (driving && (abort_bits & abort_mask(d))) {
        char why[96], fl[72];
        size_t n = aeris_faults_json(abort_bits & abort_mask(d), fl, sizeof fl);
        au_strlcpy(why, "protection stopped the motors: ", sizeof why);
        if (n) au_strlcpy(why + au_strlen(why), fl, sizeof why - au_strlen(why));
        dev_fault(d, abort_bits & abort_mask(d), why);
    } else if (d->state == ST_READY || d->state == ST_ARMED) {
        uint32_t bad = d->faults & (F_IMU_ABSENT | F_IMU_STALE | F_IMU_INVALID | F_DRV_ERROR | F_UNDERVOLT | F_OVERVOLT | F_OVERTEMP | F_OVERSPEED | F_LOOP_OVERRUN);
        if (bad) dev_set_state(d, ST_DISARMED, "no longer ready: a check failed");
    }
    switch (d->state) {
    case ST_BALANCING: balance(d, now); break;
    case ST_STOPPING: stopping(d, now); break;
    case ST_COMMISSIONING: commissioning(d, now); break;
    case ST_READY:
        if (d->arm_now && !d->arm_prev && aeris_actuation_permitted(d) && !dev_local_wait(d)) { d->armed_at = now; dev_set_state(d, ST_ARMED, "local enable pressed"); }
        break;
    case ST_ARMED:
        if (now - d->armed_at > (uint64_t)(d->cfg.arm_window_s * 1e6f)) dev_set_state(d, ST_READY, "arm window elapsed without a start: disarmed to READY");
        break;
    default: break;
    }
    task_step(d);
    dev_tlm_step(d);
    d->arm_prev = d->arm_now;
    end = now_us(d);
    dur = (uint32_t)(end - now);
    d->steps++;
    d->step_us_last = dur;
    d->step_us_sum += dur;
    if (dur > d->step_us_max) d->step_us_max = dur;
    if (d->last_step_us && now - d->last_step_us > period + period / 2) { d->overruns++; d->overrun_run++; }
    else if (dur > period) { d->overruns++; d->overrun_run++; }
    else d->overrun_run = 0;
    d->last_step_us = now;
}

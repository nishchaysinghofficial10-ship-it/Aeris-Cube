/* AERIS firmware core — LSM6DSOX and ODrive CANSimple drivers (see drivers.h for the sources of every constant). */
#include "aeris/drivers.h"
#include "aeris/util.h"

#define DEG2RAD 0.017453292519943295f
#define G0 9.80665f

/* ------------------------------------------------------------------------------------------------ LSM6DSOX */
int lsm_odr_code(int hz) {
    switch (hz) {
    case 12: case 13: return 1;
    case 26: return 2;
    case 52: return 3;
    case 104: return 4;
    case 208: return 5;
    case 416: return 6;
    case 833: return 7;
    case 1666: case 1667: return 8;
    case 3332: case 3333: return 9;
    case 6664: case 6667: return 10;
    default: return 0;
    }
}
int lsm_fs_xl_code(int g) { return g == 2 ? 0 : g == 16 ? 1 : g == 4 ? 2 : g == 8 ? 3 : -1; }
int lsm_fs_g_code(int dps) { return dps == 250 ? 0 : dps == 125 ? 1 : dps == 500 ? 2 : dps == 1000 ? 4 : dps == 2000 ? 6 : -1; }
static float accel_mg_per_lsb(int g) { return g == 2 ? 0.061f : g == 4 ? 0.122f : g == 8 ? 0.244f : 0.488f; }
static float gyro_mdps_per_lsb(int dps) { return dps == 125 ? 4.375f : dps == 250 ? 8.75f : dps == 500 ? 17.5f : dps == 1000 ? 35.0f : 70.0f; }

int lsm_init(lsm_t *s, const aeris_hal_t *h, uint8_t addr, int odr_hz, int fs_g, int fs_dps) {
    uint8_t v = 0, c;
    int odr = lsm_odr_code(odr_hz), fx = lsm_fs_xl_code(fs_g), fg = lsm_fs_g_code(fs_dps), i;
    au_memset(s, 0, sizeof *s);
    s->addr = addr;
    if (!odr || fx < 0 || fg < 0) return s->last_error = LSM_ERR_CONFIG;
    if (h->i2c_read(h->ctx, addr, LSM_REG_WHO_AM_I, &v, 1) != 0) return s->last_error = LSM_ERR_ABSENT;
    s->who_am_i = v;
    if (v != LSM_ID) return s->last_error = LSM_ERR_WRONG_ID;     /* another device answers: never used as this IMU */
    c = 0x01u;                                                      /* SW_RESET */
    if (h->i2c_write(h->ctx, addr, LSM_REG_CTRL3_C, &c, 1) != 0) return s->last_error = LSM_ERR_BUS;
    for (i = 0; i < 100; i++) {                                     /* the bit clears itself when the reset is done */
        if (h->i2c_read(h->ctx, addr, LSM_REG_CTRL3_C, &v, 1) != 0) return s->last_error = LSM_ERR_BUS;
        if (!(v & 0x01u)) break;
    }
    if (v & 0x01u) return s->last_error = LSM_ERR_RESET;
    c = 0x44u;                                                      /* BDU | IF_INC */
    if (h->i2c_write(h->ctx, addr, LSM_REG_CTRL3_C, &c, 1) != 0) return s->last_error = LSM_ERR_BUS;
    c = (uint8_t)((odr << 4) | (fx << 2));
    if (h->i2c_write(h->ctx, addr, LSM_REG_CTRL1_XL, &c, 1) != 0) return s->last_error = LSM_ERR_BUS;
    c = (uint8_t)((odr << 4) | (fg << 1));
    if (h->i2c_write(h->ctx, addr, LSM_REG_CTRL2_G, &c, 1) != 0) return s->last_error = LSM_ERR_BUS;
    /* read back: a device that does not keep its configuration is not used */
    if (h->i2c_read(h->ctx, addr, LSM_REG_CTRL1_XL, &v, 1) != 0 || v != (uint8_t)((odr << 4) | (fx << 2))) return s->last_error = LSM_ERR_CONFIG;
    if (h->i2c_read(h->ctx, addr, LSM_REG_CTRL2_G, &v, 1) != 0 || v != (uint8_t)((odr << 4) | (fg << 1))) return s->last_error = LSM_ERR_CONFIG;
    s->odr_hz = odr_hz; s->fs_g = fs_g; s->fs_dps = fs_dps;
    s->g_lsb_mps2 = accel_mg_per_lsb(fs_g) * 1e-3f * G0;
    s->w_lsb_rads = gyro_mdps_per_lsb(fs_dps) * 1e-3f * DEG2RAD;
    s->ready = true;
    return s->last_error = LSM_OK;
}

static int16_t le16(const uint8_t *b) { return (int16_t)(uint16_t)((uint16_t)b[0] | ((uint16_t)b[1] << 8)); }

int lsm_read(lsm_t *s, const aeris_hal_t *h, float gyro[3], float accel[3], float *temp_c, bool *fresh, bool *saturated) {
    uint8_t st = 0, raw[12], tb[2];
    int i;
    bool sat = false;
    if (!s->ready) return s->last_error = LSM_ERR_ABSENT;
    if (h->i2c_read(h->ctx, s->addr, LSM_REG_STATUS, &st, 1) != 0 ||
        h->i2c_read(h->ctx, s->addr, LSM_REG_OUTX_L_G, raw, sizeof raw) != 0) { s->bus_errors++; return s->last_error = LSM_ERR_BUS; }
    for (i = 0; i < 3; i++) {
        int16_t g = le16(raw + 2 * i), a = le16(raw + 6 + 2 * i);
        if (g == 32767 || g == -32768 || a == 32767 || a == -32768) sat = true;
        gyro[i] = (float)g * s->w_lsb_rads;
        accel[i] = (float)a * s->g_lsb_mps2;
    }
    if (temp_c) {
        if (h->i2c_read(h->ctx, s->addr, LSM_REG_OUT_TEMP_L, tb, 2) != 0) { s->bus_errors++; return s->last_error = LSM_ERR_BUS; }
        *temp_c = (float)le16(tb) / 256.0f + 25.0f;
    }
    s->reads++;
    if ((st & 0x03u) != 0x03u) s->stale_reads++;
    if (sat) s->saturated++;
    if (fresh) *fresh = (st & 0x03u) == 0x03u;
    if (saturated) *saturated = sat;
    return s->last_error = LSM_OK;
}

/* ------------------------------------------------------------------------------------------------ ODrive */
uint32_t odrv_id(uint8_t node, uint8_t cmd) { return ((uint32_t)node << 5) | (cmd & 0x1Fu); }
void odrv_put_u32(uint8_t *b, uint32_t v) { b[0] = (uint8_t)v; b[1] = (uint8_t)(v >> 8); b[2] = (uint8_t)(v >> 16); b[3] = (uint8_t)(v >> 24); }
uint32_t odrv_get_u32(const uint8_t *b) { return (uint32_t)b[0] | ((uint32_t)b[1] << 8) | ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24); }
void odrv_put_f32(uint8_t *b, float v) { uint32_t u; au_memcpy(&u, &v, 4); odrv_put_u32(b, u); }
float odrv_get_f32(const uint8_t *b) { uint32_t u = odrv_get_u32(b); float v; au_memcpy(&v, &u, 4); return v; }

void odrv_init(odrv_t *m, uint8_t node) { au_memset(m, 0, sizeof *m); m->node = node; m->vbus_V = -1; }

static int send(odrv_t *m, const aeris_hal_t *h, uint8_t cmd, const uint8_t *d, uint8_t len, bool rtr) {
    int r = h->can_send(h->ctx, odrv_id(m->node, cmd), d, len, rtr);
    if (r != 0) m->tx_errors++; else m->tx++;
    return r;
}

int odrv_set_state(odrv_t *m, const aeris_hal_t *h, uint32_t state) {
    uint8_t d[8] = {0};
    odrv_put_u32(d, state);
    return send(m, h, ODRV_CMD_SET_AXIS_STATE, d, 8, false);
}
int odrv_set_torque_mode(odrv_t *m, const aeris_hal_t *h) {
    uint8_t d[8];
    odrv_put_u32(d, ODRV_CONTROL_TORQUE);
    odrv_put_u32(d + 4, ODRV_INPUT_PASSTHROUGH);
    return send(m, h, ODRV_CMD_SET_CTRL_MODE, d, 8, false);
}
int odrv_set_torque(odrv_t *m, const aeris_hal_t *h, float torque_Nm) {
    uint8_t d[8] = {0};
    if (!au_isfinitef(torque_Nm)) torque_Nm = 0.0f;              /* never send a non-finite setpoint */
    odrv_put_f32(d, torque_Nm);
    return send(m, h, ODRV_CMD_SET_INPUT_TORQUE, d, 8, false);
}
int odrv_set_limits(odrv_t *m, const aeris_hal_t *h, float vel_rev_s, float current_A) {
    uint8_t d[8];
    odrv_put_f32(d, vel_rev_s);
    odrv_put_f32(d + 4, current_A);
    return send(m, h, ODRV_CMD_SET_LIMITS, d, 8, false);
}
int odrv_clear_errors(odrv_t *m, const aeris_hal_t *h) { uint8_t d[8] = {0}; return send(m, h, ODRV_CMD_CLEAR_ERRORS, d, 1, false); }
int odrv_request(odrv_t *m, const aeris_hal_t *h, uint8_t cmd) { return send(m, h, cmd, 0, 0, true); }

int odrv_dispatch(odrv_t *axes, int n, uint32_t id, const uint8_t *d, uint8_t len, bool rtr, uint64_t now) {
    uint8_t node = (uint8_t)((id >> 5) & 0x3Fu), cmd = (uint8_t)(id & 0x1Fu);
    int i;
    if (rtr) return 0;                                               /* our own requests echoed by a loop-back bus */
    for (i = 0; i < n; i++) {
        odrv_t *m = &axes[i];
        if (m->node != node) continue;
        m->rx++;
        switch (cmd) {
        case ODRV_CMD_HEARTBEAT:
            if (len < 7) return 1;
            m->axis_error = odrv_get_u32(d); m->axis_state = d[4]; m->procedure_result = d[5];
            m->t_heartbeat_us = now; m->seen = true;
            break;
        case ODRV_CMD_GET_ERROR:
            if (len < 8) return 1;
            m->active_errors = odrv_get_u32(d); m->disarm_reason = odrv_get_u32(d + 4);
            break;
        case ODRV_CMD_GET_ENCODER:
            if (len < 8) return 1;
            m->pos_rev = odrv_get_f32(d); m->vel_rev_s = odrv_get_f32(d + 4); m->t_encoder_us = now;
            break;
        case ODRV_CMD_GET_IQ:
            if (len < 8) return 1;
            m->iq_set_A = odrv_get_f32(d); m->iq_meas_A = odrv_get_f32(d + 4); m->t_iq_us = now;
            break;
        case ODRV_CMD_GET_TEMPERATURE:
            if (len < 8) return 1;
            m->fet_temp_C = odrv_get_f32(d); m->motor_temp_C = odrv_get_f32(d + 4); m->t_temp_us = now;
            break;
        case ODRV_CMD_GET_BUS:
            if (len < 8) return 1;
            m->vbus_V = odrv_get_f32(d); m->ibus_A = odrv_get_f32(d + 4); m->t_bus_us = now;
            break;
        case ODRV_CMD_GET_TORQUES:
            if (len < 8) return 1;
            m->torque_target_Nm = odrv_get_f32(d); m->torque_est_Nm = odrv_get_f32(d + 4); m->t_torque_us = now;
            break;
        default:
            break;
        }
        return 1;
    }
    return 0;
}

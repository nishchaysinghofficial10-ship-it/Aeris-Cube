/* AERIS firmware core — vectors and quaternions in single precision (the ESP32-S3 FPU is single precision).
 * Conventions are the project's (site/docs/PHYSICS.md §1): q = [w, x, y, z], unit, body → world, Hamilton product;
 * body axes along the cube edges from the pivot corner; world z up. Ported from backend/aeris_backend/physics/quaternion.py. */
#ifndef AERIS_MATHQ_H
#define AERIS_MATHQ_H

#ifdef __cplusplus
extern "C" {
#endif

void  aq_mul(const float a[4], const float b[4], float out[4]);     /* out = a ⊗ b (out may alias neither) */
void  aq_conj(const float q[4], float out[4]);
void  aq_norm(float q[4]);                                         /* to unit length (identity if degenerate) */
void  aq_exp(const float phi[3], float out[4]);                    /* rotation vector → quaternion */
void  aq_log(const float q[4], float out[3]);                      /* quaternion → rotation vector (short way) */
void  aq_up_in_body(const float q[4], float out[3]);               /* world up expressed in body axes */
void  aq_rot(const float q[4], const float vb[3], float vw[3]);    /* body → world */
void  aq_rot_t(const float q[4], const float vw[3], float vb[3]);  /* world → body */
void  aq_from_to(const float u[3], const float v[3], float out[4]);/* shortest rotation taking unit u to unit v */
void  aq_axis_angle(const float ax[3], float ang, float out[4]);
float aq_angle_between(const float a[4], const float b[4]);         /* sign-invariant geodesic angle [rad] */

void  av_cross(const float a[3], const float b[3], float out[3]);
float av_dot(const float a[3], const float b[3]);
float av_norm(const float a[3]);
void  av_scale(const float a[3], float s, float out[3]);
void  av_add(const float a[3], const float b[3], float out[3]);
void  av_sub(const float a[3], const float b[3], float out[3]);
void  am_vec(const float m[9], const float v[3], float out[3]);    /* row-major 3×3 times vector */
void  am_tvec(const float m[9], const float v[3], float out[3]);   /* transpose times vector */

#ifdef __cplusplus
}
#endif
#endif

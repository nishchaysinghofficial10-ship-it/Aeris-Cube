/* AERIS firmware core — the device: state machine, local control loop, protection, command service, telemetry and
 * the aeris-device-link/1 protocol (site/docs/DEVICE_LINK.md).
 *
 * The stabilising loop runs HERE, on the device, at the configured control rate: IMU → estimator → controller →
 * allocation → motor drivers, with every protection check in the same step. Hosts (a browser over USB, the companion,
 * the backend gateway) can only send bounded supervisory requests; the device decides. Nothing a host sends can arm
 * the motors: arming needs the local enable control on the cube, in the READY state, in a build compiled with motor
 * actuation enabled, with a valid approved configuration — and a remote request never overrides a fault, a limit, the
 * watchdog or the local stop.
 *
 * States: BOOT → DISARMED → (SELF_TEST) → READY → ARMED (local enable) → BALANCING → STOPPING → DISARMED; FAULT is
 * latched (motors idle; cleared only with the cause gone and a local long press); CALIBRATING, UPDATE and COMMISSIONING
 * are entered from DISARMED only. Every boot starts DISARMED with a new boot id; nothing from a previous boot or link
 * session (commands, arming, experiments) survives. */
#ifndef AERIS_DEVICE_H
#define AERIS_DEVICE_H

#include <stdint.h>
#include <stdbool.h>
#include "aeris/hal.h"
#include "aeris/drivers.h"
#include "aeris/control.h"

#ifdef __cplusplus
extern "C" {
#endif

#define AERIS_FW_NAME        "aeris-fw"
#define AERIS_FW_VERSION     "0.1.0"
#define AERIS_LINK_PROTOCOL  "aeris-device-link/1"
#define AERIS_TLM_PROTOCOL   "aeris-telemetry-ndjson/1"
#define AERIS_CALIB_FORMAT   1
#define AERIS_MAX_LINE       4096        /* bytes of one framed message (JSON + tab + 8 hex CRC) */
#define AERIS_TX_BUF         16384       /* per link: framed lines waiting for the transport */
#define AERIS_MAX_TTL_MS     10000
#define AERIS_CMD_CACHE      32
#define AERIS_LINK_TIMEOUT_US 1500000u    /* no heartbeat for this long: the supervisor link is lost */
#define AERIS_FAULT_CLEAR_PRESS_US 2000000u /* local long press that clears latched faults (when their causes are gone) */
#define AERIS_PAIR_WINDOW_US 60000000u    /* time to confirm a pairing with the local control */
#define AERIS_STATE_PERIOD_US 1000000u    /* state is re-sent at least this often on every active link */

#ifndef AERIS_BUILD_ID
#define AERIS_BUILD_ID "dev"              /* the build system passes the source revision */
#endif

#ifndef AERIS_TLM_RING
#define AERIS_TLM_RING 512              /* telemetry frames kept for backfill after a link interruption */
#endif

typedef enum {
    ST_BOOT = 0, ST_DISARMED, ST_SELF_TEST, ST_READY, ST_ARMED, ST_BALANCING, ST_STOPPING, ST_FAULT, ST_CALIBRATING,
    ST_UPDATE, ST_COMMISSIONING, ST_COUNT
} aeris_state_t;

/* faults (bits) */
enum { TASK_NONE = 0, TASK_SELF_TEST, TASK_IMU_AVERAGE, TASK_ENCODERS };

enum {
    F_IMU_ABSENT = 1u << 0, F_IMU_STALE = 1u << 1, F_IMU_INVALID = 1u << 2, F_IMU_SATURATED = 1u << 3,
    F_DRV_ABSENT = 1u << 4, F_DRV_STALE = 1u << 5, F_DRV_ERROR = 1u << 6, F_ENC_STALE = 1u << 7,
    F_OVERCURRENT = 1u << 8, F_OVERSPEED = 1u << 9, F_OVERTEMP = 1u << 10, F_UNDERVOLT = 1u << 11, F_OVERVOLT = 1u << 12,
    F_TILT_LIMIT = 1u << 13, F_EST_INVALID = 1u << 14, F_LOOP_OVERRUN = 1u << 15, F_ESTOP = 1u << 16,
    F_CONFIG = 1u << 17, F_CALIBRATION = 1u << 18, F_GRAVITY = 1u << 19, F_NOT_STILL = 1u << 20
};

typedef struct {
    uint8_t buf[AERIS_MAX_LINE + 4];
    size_t len;
    bool discarding;
    uint32_t lines, bad_crc, too_long, not_json, bad_message;
} aeris_rx_t;

typedef struct {
    bool up;                 /* the transport is connected */
    bool active;             /* a host_hello negotiated the link version */
    int version;
    char host[16];
    bool authed;             /* network link: the device answered the gateway's challenge on this connection */
    bool has_session;        /* a session message established a link session (commands need one) */
    char session[48];
    uint32_t lease_epoch;
    int64_t last_seq;
    uint64_t last_heartbeat_us;
    uint32_t acked_seq;
    bool tlm_on;             /* telemetry is sent on this link (after host_hello; set_telemetry can pause it) */
    bool tlm_hello_sent;
    bool resuming;           /* backfill of ring frames in progress */
    uint32_t resume_next, resume_end;
    uint8_t tx[AERIS_TX_BUF];
    size_t tx_len;
    uint32_t tx_dropped_lines, tx_dropped_tlm;
    aeris_rx_t rx;
} aeris_link_t;

typedef struct {
    char id[41];
    char status[12];          /* the latest status sent for it */
    char reason[96];
    int link;
    bool used;
} aeris_cmd_cache_t;

typedef struct {
    double t;
    float q[4], theta, w[3], wheel_rpm[3], torque_cmd[3], torque_meas[3], gyro[3], accel[3];
    uint32_t seq;
    uint8_t status, mode, has_theta, has_meas, has_rpm;
} aeris_tlm_frame_t;

typedef struct aeris_dev {
    const aeris_hal_t *hal;
    const aeris_board_t *board;
    char device_id[48];
    char boot_id[17];
    uint8_t pub[65];
    bool have_key, paired;
    aeris_state_t state, prev_state;
    char state_reason[96];
    uint32_t faults, latched;
    aeris_cfg_t cfg;
    lsm_t imu;
    odrv_t drv[AERIS_NW];
    bool imu_ok;
    est_t est;
    ctrl_t ctrl;
    /* loop */
    uint64_t boot_us, last_step_us, step_start_us;
    uint32_t steps, overruns, overrun_run, step_us_last, step_us_max;
    uint64_t step_us_sum;
    float gyro[3], accel[3], temp_c;          /* body frame (gyro bias removed) */
    float gyro_raw[3], accel_raw[3];          /* sensor frame, as read (calibration works on these) */
    bool imu_fresh, imu_saturated;
    uint32_t imu_bad_reads;
    float q[4], w[3], est_age, theta, tilt;
    bool est_valid;
    float omega[3], torque_cmd[3], torque_meas[3], vbus;
    bool drivers_closed_loop;
    /* local controls */
    bool arm_prev, arm_now, arm_consumed;
    uint64_t arm_pressed_at, armed_at;
    /* experiment */
    bool exp_active;
    char exp_cmd[41];
    int exp_link;
    char exp_session[48];
    char exp_recipe[40];
    uint64_t exp_start_us, exp_end_us, stop_start_us;
    char exp_end_reason[64];
    uint32_t exp_steps, exp_sat_steps[AERIS_NW];    /* balancing control steps; steps in which each wheel's torque was limited */
    /* pending commands that wait for the local enable / confirmation (one at a time) */
    bool wait_start, wait_clear, wait_unpair;
    char wait_cmd[41];
    int wait_link;
    uint64_t wait_deadline_us;
    float wait_duration_s;
    char wait_recipe[40];
    /* link supervision */
    bool link_lost;
    uint64_t link_lost_at;
    /* calibration / checks in progress */
    int task;                                  /* TASK_* */
    int task_sub;                              /* TASK_IMU_AVERAGE: 0 calibrate_imu, 1 calibrate_axes */
    char task_cmd[41];
    char task_label[17];
    int task_link;
    aeris_state_t task_return;                 /* the state to return to */
    uint32_t task_n;
    uint64_t task_start_us, task_until_us;
    double acc_g[3], acc_g2[3], acc_a[3], acc_a2[3], acc_t;
    float enc_pos_min[3], enc_pos_max[3], enc_vel_min[3], enc_vel_max[3];
    uint32_t enc_updates[3];
    uint64_t enc_last_t[3];
    uint32_t st_imu_fresh, st_imu_reads;
    /* commissioning */
    uint64_t motor_test_until_us;
    int motor_test_wheel;
    float motor_test_torque;
    char mt_cmd[41], mt_end[40];
    int mt_link;
    float mt_omega_max;
    uint64_t mt_start_us;
    /* telemetry: one telemetry session per device (a new one after boot and after every applied configuration) */
    int tlm_hz;
    uint32_t tlm_seq, tlm_div_count, tlm_session_n;
    char tlm_session[40];
    uint64_t tlm_start_us;
    aeris_tlm_frame_t ring[AERIS_TLM_RING];
    uint32_t ring_head, ring_count;
    /* pairing */
    bool pair_pending;
    char pair_session[48], pair_nonce[96];
    int pair_link;
    uint64_t pair_deadline_us;
    /* identify, periodic state, scheduled reboot */
    uint64_t identify_until_us;
    uint64_t state_sent_us;
    uint64_t reboot_at_us;
    bool reboot_bootloader;
    /* links and commands */
    aeris_link_t link[AERIS_LINKS];
    aeris_cmd_cache_t cache[AERIS_CMD_CACHE];
    int cache_next;
    /* scratch */
    aeris_cfg_t cfg_tmp;
    char line[AERIS_MAX_LINE + 64];   /* outgoing messages built by the command and link handlers */
    char res[2048];                   /* command results (diagnostics is the largest, about 1.7 kB) */
    jsmntok_t tok[512];
} aeris_dev_t;

/* lifecycle */
void aeris_init(aeris_dev_t *d, const aeris_hal_t *hal, const aeris_board_t *board, const char *device_id);
void aeris_control_step(aeris_dev_t *d);          /* call at the control rate (aeris_control_period_us) */
void aeris_service(aeris_dev_t *d);               /* call often (≥ 100 Hz): links, timeouts, pending requests */
uint32_t aeris_control_period_us(const aeris_dev_t *d);
/* links */
void aeris_link_up(aeris_dev_t *d, int link);
void aeris_link_down(aeris_dev_t *d, int link);
void aeris_link_input(aeris_dev_t *d, int link, const uint8_t *data, size_t n);
/* text helpers (also used by the tests) */
const char *aeris_state_name(aeris_state_t s);
size_t aeris_faults_json(uint32_t faults, char *buf, size_t cap);   /* ["IMU_ABSENT", …] */
bool aeris_actuation_permitted(const aeris_dev_t *d);

/* internal, shared between the core's source files */
void dev_set_state(aeris_dev_t *d, aeris_state_t s, const char *reason);
void dev_fault(aeris_dev_t *d, uint32_t bits, const char *reason);
void dev_drivers_idle(aeris_dev_t *d);
bool dev_send(aeris_dev_t *d, int link, const char *json, size_t n);      /* frame and queue one message */
void dev_broadcast(aeris_dev_t *d, const char *json, size_t n);           /* to every active link */
void dev_send_dev_hello(aeris_dev_t *d, int link);
void dev_send_state(aeris_dev_t *d);
void dev_tlm_hello(aeris_dev_t *d, int link);
void dev_tlm_step(aeris_dev_t *d);
void dev_tlm_resume(aeris_dev_t *d, int link, uint32_t after);
void dev_drivers_closed_loop(aeris_dev_t *d);
void dev_setup_hw(aeris_dev_t *d);                  /* (re)initialise sensors, drivers, estimator and controller from cfg */
void task_begin(aeris_dev_t *d, int task, int sub, int link, const char *cmd, uint32_t duration_ms, const char *label);
void dev_power_policy(aeris_dev_t *d);
bool dev_drivers_powered_state(const aeris_dev_t *d);   /* states in which the drivers are powered */
void dev_tlm_new_session(aeris_dev_t *d);           /* bye on every link, new session id, hello again */
void dev_tlm_service(aeris_dev_t *d, int link);     /* continue a backfill while the link has room */
void link_handle(aeris_dev_t *d, int link, const aj_doc_t *doc);
void link_pair_confirm(aeris_dev_t *d);              /* the local control confirmed a pending pairing */
void link_pair_cancel(aeris_dev_t *d, const char *reason);
void cmd_handle(aeris_dev_t *d, int link, const aj_doc_t *doc);
void cmd_service(aeris_dev_t *d);
void cmd_cancel_pending(aeris_dev_t *d, const char *reason);   /* fail every waiting command and running task */
bool exp_begin(aeris_dev_t *d, uint64_t now, char *why, size_t cap);
bool dev_local_wait(const aeris_dev_t *d);          /* a pairing / command is waiting for the local control */
bool dev_tx_room(const aeris_dev_t *d, int link, size_t n, bool bulk);
void cmd_report(aeris_dev_t *d, int link, const char *id, const char *kind, const char *status, const char *reason, const char *result_json);
void task_step(aeris_dev_t *d);

#ifdef __cplusplus
}
#endif
#endif

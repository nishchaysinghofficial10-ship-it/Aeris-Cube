/* AERIS firmware core — hardware abstraction.
 *
 * The core never touches registers, sockets or files. A board layer (firmware/esp32s3: ESP-IDF; firmware/host: the
 * synthetic device and the tests; firmware/wasm: the browser's synthetic device) fills this table. Sensors and motor
 * drivers are reached through BUS primitives (I2C, CAN), so the same driver code (lsm6dsox.c, odrive.c) runs on the
 * board and against the register/bus models of the synthetic device. Cryptography comes from established libraries
 * of each target (ESP-IDF PSA Crypto / mbedTLS, OpenSSL on the host, audited JavaScript libraries in the browser);
 * the core implements none.
 *
 * Every function returns 0 on success unless stated otherwise; a negative value is an error the core reports. */
#ifndef AERIS_HAL_H
#define AERIS_HAL_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

enum { AERIS_LINK_USB = 0, AERIS_LINK_NET = 1, AERIS_LINKS = 2 };   /* local USB/serial link, outbound network link */

typedef struct aeris_hal {
    void *ctx;
    /* time: monotonic microseconds since this boot */
    uint64_t (*time_us)(void *ctx);
    /* buses (7-bit I2C address; 11-bit CAN identifiers) */
    int (*i2c_read)(void *ctx, uint8_t addr, uint8_t reg, uint8_t *buf, size_t n);
    int (*i2c_write)(void *ctx, uint8_t addr, uint8_t reg, const uint8_t *buf, size_t n);
    int (*can_send)(void *ctx, uint32_t id, const uint8_t *data, uint8_t len, bool rtr);
    int (*can_recv)(void *ctx, uint32_t *id, uint8_t *data, uint8_t *len, bool *rtr);   /* 1: a frame, 0: none */
    /* local inputs and outputs (debounced by the board layer) */
    bool (*arm_input)(void *ctx);          /* the local enable control is held / was pressed */
    bool (*stop_input)(void *ctx);         /* the local stop is asserted (the hardware stop chain is open) */
    bool (*commission_input)(void *ctx);   /* the commissioning dead-man control is held */
    void (*motor_power)(void *ctx, bool on);
    void (*led)(void *ctx, int pattern);
    /* links: non-blocking byte writes; returns the number of bytes accepted (0..n) */
    int (*link_write)(void *ctx, int link, const uint8_t *data, size_t n);
    /* persistent storage (small blobs) */
    int (*nvs_get)(void *ctx, const char *key, uint8_t *buf, size_t cap, size_t *len);   /* 1: not found */
    int (*nvs_set)(void *ctx, const char *key, const uint8_t *buf, size_t len);
    /* cryptography (established libraries of the target) */
    int (*random)(void *ctx, uint8_t *buf, size_t n);
    int (*sha256)(void *ctx, const uint8_t *data, size_t n, uint8_t out[32]);
    int (*key_public)(void *ctx, uint8_t pub[65], bool create);      /* uncompressed P-256 point; create if missing */
    int (*sign)(void *ctx, const uint8_t *msg, size_t n, uint8_t sig[64]);   /* ECDSA P-256 / SHA-256, raw r || s */
    int (*key_reset)(void *ctx);                                       /* discard the key pair (re-pairing) */
    /* system */
    void (*reboot)(void *ctx, bool to_bootloader);
    void (*log)(void *ctx, int level, const char *msg);
} aeris_hal_t;

/* What the board is. Compiled into each firmware image; a configuration can only narrow these limits. */
typedef struct aeris_board {
    const char *board_id;          /* e.g. "esp32-s3-devkitc-1" or "aeris-synthetic" */
    const char *chip;              /* e.g. "ESP32-S3", "host", "wasm32" */
    const char *device_kind;       /* telemetry hello device.kind: "physical" (a board) or "emulator" (synthetic) */
    bool synthetic;                /* the sensors and motors are simulated (never a measurement) */
    bool actuation_build;          /* built with AERIS_ACTUATION_ENABLED=1: motors may be driven when every other condition holds */
    bool commissioning_build;      /* built with AERIS_COMMISSIONING=1: per-motor tests in COMMISSIONING mode */
    float hard_max_current_A;      /* never exceeded, whatever a configuration says */
    float hard_max_torque_Nm;
    float hard_max_speed_rpm;
    float commissioning_max_torque_Nm;
    float commissioning_max_speed_rpm;
    uint32_t commissioning_max_ms;
    int max_control_hz;
    const char *imu_drivers;       /* comma-separated drivers the build contains, e.g. "lsm6dsox" */
    const char *motor_drivers;     /* e.g. "odrive-cansimple" */
} aeris_board_t;

#ifdef __cplusplus
}
#endif
#endif

/* AERIS firmware core — approved configuration, estimator, controllers, allocation and protection.
 *
 * Configuration (aeris-device-config/1): produced by the backend from an immutable device-profile revision and an
 * experiment recipe (gains designed by backend/aeris_backend/control/design.py on the profile's model), applied to a
 * DISARMED device and identified by the SHA-256 of its exact bytes. The device validates every field and enforces its
 * own compiled-in caps (aeris_board_t): a configuration can only narrow what the board allows.
 *
 * Estimator: the backend's complementary quaternion filter 'cf3d' (estimation/__init__.py ComplementaryAttitude):
 * gyro propagation, gravity-direction correction with gain Δt/(τ+Δt), optional integral bias correction,
 * accelerometer gating, dynamic-acceleration compensation at the IMU position, sequencing of duplicate and out-of-order
 * samples, and the controller-facing prediction q̂(t) = q̂_f ⊗ exp((ω_m − b̂)(t − t_f)). The estimate is the device's
 * ESTIMATED attitude — never ground truth. Six-axis data give no absolute yaw: the corner heading is relative to the
 * attitude at the start of balancing and drifts with the gyro bias.
 *
 * Controllers (ported from control/controllers.py; only these two run on the device):
 *   edge-lqr          T = −(K₁(θ̂ + β_ref) + K₂ θ̂̇ + K₃ Ω),   θ̂ from the 3-D estimate about the support edge (body x)
 *   corner-mimo-lqr   T = −K [φ; ω̂; Ω],   φ = log(q_ref⁻¹ ⊗ q̂),  q_ref = q_z(ψ_ref) ⊗ q_eq,  K 3 × 9
 * Allocation 'clip' (the engine's default): per wheel, |T| ≤ torque limit; no torque that would speed a wheel up
 * beyond its speed limit. */
#ifndef AERIS_CONTROL_H
#define AERIS_CONTROL_H

#include <stdint.h>
#include <stdbool.h>
#include "aeris/hal.h"
#include "aeris/json.h"

#ifdef __cplusplus
extern "C" {
#endif

#define AERIS_NW 3
enum { MODE_EDGE = 0, MODE_CORNER = 1 };
enum { CTRL_NONE = 0, CTRL_EDGE_LQR = 1, CTRL_CORNER_MIMO = 2 };

typedef struct {
    float axis[3];             /* spin axis in body axes (unit) */
    float sign;                /* motor positive direction relative to the model's axis: +1 or −1 */
    uint8_t node;              /* ODrive CANSimple node id */
    float Jw, kt, current_max, torque_max, speed_max_rads;
} aeris_wheel_cfg_t;

typedef struct {
    bool valid;
    char hash_hex[65];         /* SHA-256 of the configuration's bytes as received */
    char profile_hash[65];
    char recipe[40];
    int mode, controller;
    float K_edge[3], beta_ref;
    int drive_wheel;
    float K_corner[3][9], q_eq[4], u_ref[3];
    /* estimator (cf3d) */
    float tau_s, accel_gate, bias_gain, tau_alpha_s, imu_pos[3], q_nominal[4], stale_after_s, g;
    bool compensate_dynamic;
    /* IMU */
    uint8_t imu_addr;
    int imu_odr_hz, imu_fs_g, imu_fs_dps;
    float imu_to_body[9], gyro_bias[3];
    /* wheels */
    aeris_wheel_cfg_t w[AERIS_NW];
    /* limits */
    float tilt_start_rad, tilt_abort_rad, speed_abort_rads, current_abort_A, temp_abort_C, vbus_min_V, vbus_max_V;
    float link_loss_max_s, duration_max_s, stop_torque_Nm, arm_window_s;
    /* rates */
    int control_hz, imu_hz, telemetry_hz;
} aeris_cfg_t;

/* parse + validate the value at token `tok` (an object). Errors are written to err ("path: reason"). */
bool cfg_parse(aeris_cfg_t *c, const aj_doc_t *d, int tok, const aeris_board_t *b, char *err, size_t errcap);

/* ---------------- estimator ---------------- */
typedef struct {
    float q[4], q_nominal[4], b[3], last_gyro[3], r[3], alpha[3], prev_w[3];
    double t, t_receipt, t_init;
    bool initialised, have_gyro, have_prev, compensate, have_t;
    float tau, gate, kb, g, tau_a, stale_after;
    uint32_t processed, gated, updates, rejected_duplicate, rejected_out_of_order;
} est_t;

void est_init(est_t *e, const aeris_cfg_t *c);
/* one IMU sample (body frame, bias-calibrated by the caller if a calibration exists): false when rejected */
bool est_accept(est_t *e, double t_meas, const float gyro[3], const float accel[3], double t_receipt);
/* controller-facing estimate at time t; returns false while not initialised or stale (age > stale_after) */
bool est_predict(const est_t *e, double t, float q[4], float w[3], float *age);
void edge_theta(const float q[4], float *theta);      /* hinge angle about body x from an attitude */
extern const float AERIS_Q_EDGE0[4];                  /* the edge model's attitude at θ = 0: rotation of π/4 about x */

/* ---------------- controllers ---------------- */
typedef struct {
    const aeris_cfg_t *c;
    float q_ref[4];
    float psi_prev, psi_turns, psi_ref;
    bool started;
} ctrl_t;

void ctrl_init(ctrl_t *k, const aeris_cfg_t *c);
void ctrl_start(ctrl_t *k, const float q_est[4]);     /* capture the heading reference (corner) */
float ctrl_psi(ctrl_t *k, const float q[4]);          /* unwrapped heading about the balance axis (YawTracker) */
/* per-wheel requested torques [N·m] on the wheels (model axes); est_q/est_w the estimate, omega the wheel speeds [rad/s] */
void ctrl_request(ctrl_t *k, const float est_q[4], const float est_w[3], const float omega[3], float T[3]);
void ctrl_tilt_error(const aeris_cfg_t *c, const ctrl_t *k, const float q[4], float *tilt);   /* angle from the balance attitude [rad] */

/* ---------------- allocation and limits ---------------- */
typedef struct { float T[3]; bool saturated[3]; bool any; } alloc_out_t;
void alloc_clip(const aeris_cfg_t *c, const float req[3], const float omega[3], alloc_out_t *o);

#ifdef __cplusplus
}
#endif
#endif

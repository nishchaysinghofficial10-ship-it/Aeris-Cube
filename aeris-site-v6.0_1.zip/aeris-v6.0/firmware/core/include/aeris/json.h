/* AERIS firmware core — JSON reading (jsmn, strict mode) and writing (bounded buffer).
 *
 * Reading: a message is tokenised once into a caller-provided token array (no heap). Lookups walk the tokens; a key
 * that occurs twice in one object makes the whole message invalid (aj_parse refuses it), so the device and the host
 * can never read different values from one command. Strings are decoded with their escapes into a bounded buffer.
 * Writing: a fixed buffer; any overflow or a non-finite number sets `err` and the message must not be sent. */
#ifndef AERIS_JSON_H
#define AERIS_JSON_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#define JSMN_STRICT
#define JSMN_HEADER
#include "../../third_party/jsmn/jsmn.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    const char *js;
    size_t len;
    jsmntok_t *t;
    int n;
} aj_doc_t;

/* tokenise js[0..len): returns the number of tokens (> 0), or a negative error:
 * -1 not JSON / too many tokens, -2 the top level is not an object, -3 a duplicate key in some object */
int  aj_parse(aj_doc_t *d, const char *js, size_t len, jsmntok_t *toks, int cap);
int  aj_skip(const aj_doc_t *d, int i);                     /* the token after the whole value at i */
int  aj_get(const aj_doc_t *d, int obj, const char *key);    /* value token of key in object obj, -1 if absent */
bool aj_is(const aj_doc_t *d, int i, jsmntype_t type);
bool aj_is_null(const aj_doc_t *d, int i);
bool aj_str(const aj_doc_t *d, int i, char *out, size_t cap);           /* a JSON string, decoded; false if not a string or too long */
bool aj_str_eq(const aj_doc_t *d, int i, const char *s);                /* a string token equal to s (no escapes in it) */
bool aj_num(const aj_doc_t *d, int i, double *v);
bool aj_int(const aj_doc_t *d, int i, int64_t *v);
bool aj_bool(const aj_doc_t *d, int i, bool *v);
int  aj_arr_len(const aj_doc_t *d, int i);                  /* -1 when not an array */
int  aj_arr_at(const aj_doc_t *d, int i, int k);            /* token of element k, -1 out of range */
bool aj_vecf(const aj_doc_t *d, int i, float *out, int n);  /* an array of exactly n finite numbers */
bool aj_raw(const aj_doc_t *d, int i, const char **p, size_t *len);   /* the exact bytes of a value (strings with quotes) */

/* --- writer --- */
#define AW_MAX_DEPTH 12
typedef struct {
    char *buf;
    size_t cap, len;
    bool err;
    int depth;
    int count[AW_MAX_DEPTH];
    bool after_key;
} aw_t;

void aw_init(aw_t *w, char *buf, size_t cap);
void aw_obj(aw_t *w);
void aw_end_obj(aw_t *w);
void aw_arr(aw_t *w);
void aw_end_arr(aw_t *w);
void aw_key(aw_t *w, const char *k);
void aw_str(aw_t *w, const char *s);
void aw_strn(aw_t *w, const char *s, size_t n);
void aw_num(aw_t *w, double v, int sig);      /* a non-finite value is an error, never written */
void aw_int(aw_t *w, int64_t v);
void aw_uint(aw_t *w, uint64_t v);
void aw_bool(aw_t *w, bool v);
void aw_null(aw_t *w);
void aw_raw(aw_t *w, const char *s, size_t n);   /* an already serialised JSON value */
void aw_vecf(aw_t *w, const float *v, int n, int sig);
/* convenience: "key": value */
void aw_kstr(aw_t *w, const char *k, const char *s);
void aw_knum(aw_t *w, const char *k, double v, int sig);
void aw_kint(aw_t *w, const char *k, int64_t v);
void aw_kuint(aw_t *w, const char *k, uint64_t v);
void aw_kbool(aw_t *w, const char *k, bool v);
void aw_knull(aw_t *w, const char *k);
bool aw_done(aw_t *w);          /* closes nothing; true when the text is complete and nothing overflowed */

#ifdef __cplusplus
}
#endif
#endif

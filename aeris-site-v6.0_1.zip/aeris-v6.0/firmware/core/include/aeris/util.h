/* AERIS firmware core — small freestanding helpers (no libc stdio, no heap).
 *
 * The core is built for three kinds of target with the same sources: the ESP32-S3 board (ESP-IDF, newlib), the host
 * (tests and the synthetic device simulator, glibc) and WebAssembly (the browser's synthetic device, no libc at all).
 * Everything that would normally come from stdio/stdlib — number formatting and parsing, string copies — is
 * implemented here once, so the protocol text a device produces is byte-identical on every target. */
#ifndef AERIS_UTIL_H
#define AERIS_UTIL_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* memory and strings (builtins on every target; the WebAssembly build provides the symbols) */
void   au_memset(void *d, int v, size_t n);
void   au_memcpy(void *d, const void *s, size_t n);
int    au_memcmp(const void *a, const void *b, size_t n);
size_t au_strlen(const char *s);
size_t au_strnlen(const char *s, size_t max);
int    au_streq(const char *a, const char *b);                 /* 1 when equal (both non-NULL) */
int    au_strneq(const char *a, size_t alen, const char *b);   /* a[0..alen) equals the NUL-terminated b */
size_t au_strlcpy(char *d, const char *s, size_t cap);         /* always terminates; returns strlen(s) */

/* numbers → text. fmt_double writes at most `sig` significant digits (1..17) in fixed or exponent notation,
 * "-0" never, no trailing zeros; NaN and infinities are refused (return 0: JSON has no spelling for them, the
 * caller reports an invalid value). Returns the number of characters written (without the NUL), 0 on refusal or
 * when `cap` is too small. Exactness: the value is scaled by one exact power of ten (one rounding), so with
 * sig ≤ 9 the text of any single-precision value reads back as the same float (the device computes in single
 * precision); with more digits the last digit can be off by one unit near rounding ties. */
size_t au_fmt_double(char *buf, size_t cap, double x, int sig);
size_t au_fmt_int(char *buf, size_t cap, int64_t v);
size_t au_fmt_uint(char *buf, size_t cap, uint64_t v);
size_t au_fmt_hex(char *buf, size_t cap, const uint8_t *data, size_t n);   /* lower-case */

/* text → numbers: strict JSON number grammar over exactly [s, s+len). Up to 15 significant digits with a decimal
 * exponent within ±22 are converted exactly (correctly rounded); other values within a few units in the last place. */
bool au_parse_double(const char *s, size_t len, double *out);
bool au_parse_int(const char *s, size_t len, int64_t *out);            /* integers only (no fraction/exponent) */

/* CRC-32 (IEEE 802.3, reflected, init/xorout 0xFFFFFFFF — the same as zlib.crc32 / Python binascii.crc32) */
uint32_t au_crc32(const uint8_t *data, size_t n);
uint32_t au_crc32_update(uint32_t crc, const uint8_t *data, size_t n);  /* crc starts at 0 for a new value */

/* base64url without padding (RFC 4648 §5) */
size_t au_b64url_encode(char *out, size_t cap, const uint8_t *data, size_t n);
int    au_b64url_decode(uint8_t *out, size_t cap, const char *s, size_t len);   /* bytes written, -1 on error */
int    au_hex_decode(uint8_t *out, size_t cap, const char *s, size_t len);

/* math functions the WebAssembly build imports from the host page (libm elsewhere) */
float au_sqrtf(float x);
float au_sinf(float x);
float au_cosf(float x);
float au_atan2f(float y, float x);
float au_acosf(float x);
float au_tanhf(float x);
double au_sqrt(double x);
double au_sin(double x);
double au_cos(double x);
double au_atan2(double y, double x);
double au_tanh(double x);
int au_isfinite(double x);
int au_isfinitef(float x);

#ifdef __cplusplus
}
#endif
#endif

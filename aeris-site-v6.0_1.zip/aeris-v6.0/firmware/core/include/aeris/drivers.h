/* AERIS firmware core — device drivers that sit on the HAL's bus primitives.
 *
 * LSM6DSOX (ST, 6-axis IMU) over I2C. Register map and sensitivities from ST's platform-independent driver
 * STMicroelectronics/lsm6dsox-pid (lsm6dsox_reg.h / lsm6dsox_reg.c): WHO_AM_I 0x0F = 0x6C; CTRL1_XL 0x10
 * (ODR_XL[7:4], FS_XL[3:2]); CTRL2_G 0x11 (ODR_G[7:4], FS_G[3:1] incl. FS_125); CTRL3_C 0x12 (BOOT, BDU 0x40,
 * IF_INC 0x04, SW_RESET 0x01); STATUS_REG 0x1E (XLDA, GDA, TDA); OUT_TEMP_L 0x20 (T = lsb/256 + 25 °C);
 * OUTX_L_G 0x22 … OUTZ_H_A 0x2D (little-endian int16: gyro x y z, accel x y z). I2C 7-bit address 0x6A (SA0 low,
 * the default of the Adafruit 4438 breakout) or 0x6B.
 *
 * ODrive CANSimple (ODrive Robotics; message layouts from odriverobotics/ODriveArduino can_simple_messages.hpp,
 * protocol notes from docs.odriverobotics.com "CAN Protocol"): 11-bit identifier = node_id << 5 | cmd_id; little
 * endian; Heartbeat 0x01 (Axis_Error u32, Axis_State u8, Procedure_Result u8, Trajectory_Done bit), Get_Error 0x03,
 * Set_Axis_State 0x07 (u32; IDLE 1, CLOSED_LOOP_CONTROL 8), Get_Encoder_Estimates 0x09 (pos [rev] f32, vel [rev/s]
 * f32), Set_Controller_Mode 0x0B (control mode u32: TORQUE 1; input mode u32: PASSTHROUGH 1), Set_Input_Torque 0x0E
 * (f32 N·m; resets the ODrive's watchdog), Get_Iq 0x14 (setpoint, measured [A]), Get_Temperature 0x15 (FET, motor
 * [°C]), Get_Bus_Voltage_Current 0x17 ([V], [A]), Clear_Errors 0x18, Get_Torques 0x1C (target, estimate [N·m]).
 * Get_* messages are requested with an RTR frame (or arrive cyclically when the ODrive is configured to send them).
 *
 * Nothing is ever fabricated: a sensor or driver that does not answer, answers with another identity, or reports an
 * error is reported as such (absent / wrong id / stale / error), and its values are not used. */
#ifndef AERIS_DRIVERS_H
#define AERIS_DRIVERS_H

#include <stdint.h>
#include <stdbool.h>
#include "aeris/hal.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---------------- LSM6DSOX ---------------- */
#define LSM_REG_WHO_AM_I   0x0Fu
#define LSM_REG_CTRL1_XL   0x10u
#define LSM_REG_CTRL2_G    0x11u
#define LSM_REG_CTRL3_C    0x12u
#define LSM_REG_STATUS     0x1Eu
#define LSM_REG_OUT_TEMP_L 0x20u
#define LSM_REG_OUTX_L_G   0x22u
#define LSM_ID             0x6Cu

enum { LSM_OK = 0, LSM_ERR_BUS = -1, LSM_ERR_ABSENT = -2, LSM_ERR_WRONG_ID = -3, LSM_ERR_CONFIG = -4, LSM_ERR_RESET = -5 };

typedef struct {
    uint8_t addr;
    bool ready;
    uint8_t who_am_i;
    int odr_hz, fs_g, fs_dps;
    float g_lsb_mps2;          /* accelerometer: m/s² per LSB */
    float w_lsb_rads;          /* gyroscope: rad/s per LSB */
    uint32_t reads, bus_errors, stale_reads, saturated;
    int last_error;
} lsm_t;

int  lsm_init(lsm_t *s, const aeris_hal_t *h, uint8_t addr, int odr_hz, int fs_g, int fs_dps);
/* the newest sample in the SENSOR frame: gyro [rad/s], accel [m/s²] (specific force), temperature [°C];
 * fresh = the data-ready flags were set (a new sample since the last read). Returns LSM_OK or an error. */
int  lsm_read(lsm_t *s, const aeris_hal_t *h, float gyro[3], float accel[3], float *temp_c, bool *fresh, bool *saturated);
int  lsm_odr_code(int hz);      /* 0 if not a supported rate */
int  lsm_fs_xl_code(int g);     /* -1 if unsupported */
int  lsm_fs_g_code(int dps);    /* -1 if unsupported */

/* ---------------- ODrive CANSimple ---------------- */
#define ODRV_CMD_HEARTBEAT        0x01u
#define ODRV_CMD_ESTOP            0x02u
#define ODRV_CMD_GET_ERROR        0x03u
#define ODRV_CMD_SET_AXIS_STATE   0x07u
#define ODRV_CMD_GET_ENCODER      0x09u
#define ODRV_CMD_SET_CTRL_MODE    0x0Bu
#define ODRV_CMD_SET_INPUT_TORQUE 0x0Eu
#define ODRV_CMD_SET_LIMITS       0x0Fu
#define ODRV_CMD_GET_IQ           0x14u
#define ODRV_CMD_GET_TEMPERATURE  0x15u
#define ODRV_CMD_GET_BUS          0x17u
#define ODRV_CMD_CLEAR_ERRORS     0x18u
#define ODRV_CMD_GET_TORQUES      0x1Cu
#define ODRV_AXIS_IDLE            1u
#define ODRV_AXIS_CLOSED_LOOP     8u
#define ODRV_CONTROL_TORQUE       1u
#define ODRV_INPUT_PASSTHROUGH    1u

typedef struct {
    uint8_t node;
    bool seen;
    uint32_t axis_error, active_errors, disarm_reason;
    uint8_t axis_state, procedure_result;
    float pos_rev, vel_rev_s;
    float iq_set_A, iq_meas_A;
    float torque_target_Nm, torque_est_Nm;
    float vbus_V, ibus_A;
    float fet_temp_C, motor_temp_C;
    uint64_t t_heartbeat_us, t_encoder_us, t_iq_us, t_bus_us, t_temp_us, t_torque_us;
    uint32_t rx, tx, tx_errors;
} odrv_t;

void odrv_init(odrv_t *m, uint8_t node);
/* a received frame for any axis: dispatched by node id; returns 1 when it belonged to one of the axes */
int  odrv_dispatch(odrv_t *axes, int n, uint32_t id, const uint8_t *d, uint8_t len, bool rtr, uint64_t now_us);
int  odrv_set_state(odrv_t *m, const aeris_hal_t *h, uint32_t state);
int  odrv_set_torque_mode(odrv_t *m, const aeris_hal_t *h);
int  odrv_set_torque(odrv_t *m, const aeris_hal_t *h, float torque_Nm);
int  odrv_set_limits(odrv_t *m, const aeris_hal_t *h, float vel_rev_s, float current_A);
int  odrv_clear_errors(odrv_t *m, const aeris_hal_t *h);
int  odrv_request(odrv_t *m, const aeris_hal_t *h, uint8_t cmd);      /* an RTR request for a Get_* message */
uint32_t odrv_id(uint8_t node, uint8_t cmd);
void odrv_put_f32(uint8_t *b, float v);
float odrv_get_f32(const uint8_t *b);
void odrv_put_u32(uint8_t *b, uint32_t v);
uint32_t odrv_get_u32(const uint8_t *b);

#ifdef __cplusplus
}
#endif
#endif

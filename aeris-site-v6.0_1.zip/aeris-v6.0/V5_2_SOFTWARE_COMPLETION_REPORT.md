# AERIS v5.2 · Software completion report

Scope: a focused correction pass on the independent review of the delivered v5.1 (findings G1–G4). Baseline: tag
`aeris-v5.1` = `f76d632efac6e4e0148fc69c3099651b146bdad1`, archive `aeris-site-v5.1.zip` SHA-256
`c1e4138dedb3bb030e8aa14eb93cb196265eea2e5b18d2934dcfeb686c638ad4` (both verified unchanged; the earlier release files
were not modified; v5.2 was built in a separate checkout on branch `v5.2`). Review pack `AERIS-v5.1-review-pack.zip`
SHA-256 `1a944b1c6b771ad72f2946dd31e0a564b3497b8247ff7949a1e849adf3be6c29`, kept as supplied in
`evidence/v5.1-independent-review/`. Preserved: the frozen frontend design, `LocalSimulatorAdapter`'s contract (one
optional method and one capability field added), the engine (`aeris-research-engine 1.1.0`) and its numerical
behaviour, records, schemas, the database, historical studies and results, user data, and the v5.1 fixes F1–F5.
Backend 1.1.2. Changes visible to clients: [MIGRATION_V5_2.md](site/docs/MIGRATION_V5_2.md).

Every statement below points to code and to evidence **executed by us** on the machine of §2, unless it is
attributed to the review. The reviewer's macOS results are theirs: 755 passed, 1 failed (G4), 1 skipped (the Linux
`/proc` check) of 757 in their full run — their isolated browser_v3 rerun (49/49) does not replace that result —,
14/14 fresh-install release steps, 32/32 sampled campaign rows within tolerance. **Nothing was run on macOS by us.**

## 1. Results

| Finding | Status | Code | Tests | Before (v5.1) → after (v5.2), same probe |
|---|---|---|---|---|
| **G1** (P1) imported units changed by the NDJSON export | fixed | `backend/aeris_backend/telemetry/export.py` (new), `api/app.py` (export route), `hardware/bridge.py` (replay of a stored recording), `tools/dbtool.py` (`export-audit`) | `backend/tests/test_export_units.py` (38) | ms/deg/deg/s streamed as s/rad/rad/s (errors ×1000, ×57), `omega_*` dropped, an incomplete vector HTTP 500, an unknown status code relabelled "ok" → every profile within 2e-16 of the physical truth after export and after replay + re-recording; refusals HTTP 422 with the column |
| **G2** (P2) repeated export/replay → invalid hello | fixed | `telemetry/lineage.py` (flat bounded lineage, conservative summary), `export.py` (scratch-hub check before returning) | `backend/tests/test_lineage_bounded.py` (10) | fails at generation 5 / 4 / 6 (9.7 / 19.2 / 16.3 kB) → 24 generations of every chain, largest lineage 3.1 kB (bound 6 kB, protocol 8 kB) |
| **G3** (P2) skipped cases gave `full_validation: true` | fixed | `scripts/run_tests.py`, `scripts/platform_exclusions.json` (new), `.github/workflows/ci.yml` (comment), `scripts/ci_local.py`, `scripts/validate_release.py` | `backend/tests/test_run_tests.py` (15 → 29) | reviewer's fixture: exit 0, `full_validation: true` → exit 2, INCOMPLETE, the skipped case named; our 29 runner tests with the v5.1 runner: 13 fail, 16 pass (every interpreter-path test among them) |
| **G4** (P2) cancellation check depended on a 300 ms race | fixed (test) + 3 product defects corrected | `site/tests/browser_v3.py`, `site/tests/browser_v52.py` (new); `site/js/adapters/local-simulator.js`, `site/js/platform/service.js`, `site/js/ui/sweep-ui.js` | `browser_v52.py` (45 checks), `browser_v3.py` | v5.1 site code: 24 / 45 → 45 / 45 in 5 of 5 runs; old timer check passed 3 / 3 here (this machine is slower than the reviewer's Mac) |
| **H1** found here: a race in an existing browser_v51 check | fixed (test only) | `site/tests/browser_v51.py` | `browser_v51.py` (12) | failed once in the first full run (kept); passes in the second |

## 2. Environment and what was executed

Linux x86-64 (kernel 6.18.44), Python 3.12.3 (virtual environment from the lock file: NumPy 2.5.3, SciPy 1.18.1,
FastAPI 0.141.1, pytest 9.1.1), Node.js 22.22.2, Playwright 1.56.0 with Chromium 141.0.7390.37 (SwiftShader). Every
service ran on 127.0.0.1 with temporary databases; no deployment, no hardware, no user data. Not executed by us:
macOS, Windows, non-Chromium browsers, a hosted CI service (§10), long soak tests, the complete 1 668-row campaign.

## 3. G1 — the NDJSON export in the stream's wire units

**Cause.** `recording_to_ndjson` (v5.1 `telemetry/stream.py`) copied stored sample values into frames without
reading `samples.units`, although the importer accepts ms, deg, °, deg/s, °/s, rpm/rad/s wheel speeds, mN·m and g.
It also mapped only `wheel_rpm_*` (so `omega_*` vanished), raised `KeyError` (HTTP 500) on an incomplete vector,
dropped columns it did not know, and streamed any status code outside the recorder's table as "ok".

**Correction** (`telemetry/export.py`, imported back into `stream.py` so the old import path still works):
`wire_plan()` validates the document with the importer, then converts every stream field with the importer's own
factors (`hardware/ingest.py` `UNITS`; no second table): `t` → s, `theta` → rad, `w_*` and `gyro_*` → rad/s, wheel
speed → rpm from `wheel_rpm_*` (any wheel unit) or `omega_*`, torques → N·m, `accel_*` → m/s²; quaternions and counts are
dimensionless. A column whose unit has the wire unit's factor is copied exactly (identity: no multiplication). The
conversions are written into every hello's lineage (`export.converted`). Refused with `ExportError` → HTTP 422
`export_not_possible` and the column: incomplete vectors (also a three-of-four quaternion), columns without a stream
field, a `status` column without `provenance.status_codes` or with a code outside it, two wheel-speed sets, `t` < 0,
negative `seq`, an edge recording without `theta`, segment tables that do not cover the rows. `omit_unmapped=true`
(query parameter, or in a `connect` body) leaves out what can be left out and records it (`export.omitted`); a
recording without `seq` uses the row index and says so (`export.seq`). The stored document and its JSON export are
unchanged. The replay of a stored recording (`connect {source: "recording"}`) uses the same function.

**Existing faulty copies** cannot be repaired: their original units are not recorded in them. MIGRATION_V5_2.md
says to regenerate them from the original JSON recording; `python -m aeris_backend.tools.dbtool export-audit --db …`
lists, read-only, the originals whose v5/v5.1 export was wrong and the stored copies recorded from such exports.

**Evidence.** Reviewer's `edge_case_probes.py`, unchanged: v5.1 second frame `t 100, theta 11, w [180, 0, 0]`, re-recorded
as s/rad with the raw numbers; v5.2 `t 0.1, theta 0.19198621771937624, w [π, 0, 0]`
(`evidence/v5.2-verification/results/*/edge-case-probes.json`). Our `g1_g2_probe.py` over five unit profiles and three
refusal cases (table in `evidence/v5.2-verification/README.md`). Tests: every accepted unit of every exported signal
(10 profiles, including wire-unit and alias identity controls and mixed units inside vectors) exported and checked frame
by frame; the same profiles through the API — import, NDJSON export, the exported text replayed by the running
backend from its telemetry directory, recorded again — compared row by row (matched by `seq`) in SI through the
importer, time intervals included; missing `seq`; every refusal as HTTP 422, through both the export and the replay
route; FileReplaySource pacing in seconds; the read-only audit.

## 4. G2 — bounded lineage

**Cause.** v5.1 `_lineage` kept the last four previous lineage objects, each with its own nested `ancestors`, so a
two-segment recording doubled its history every generation.

**Correction** (`telemetry/lineage.py`). `collect()` flattens every lineage object reachable (v5.2 references and
v5.1 nested ancestors, iteratively, at most 20 000 objects) into compact references {`derived_from`, `generation`,
`trust`, `original_synthetic`, `original_device` id/kind/firmware}, deduplicated, newest first. An exported lineage
keeps at most 12 of them — the parents and the 4 oldest (the original sources); middle generations are dropped first
and counted in `ancestry_omitted` — plus `generation` and `ancestry_trust`, the least trustworthy status stated by
EVERY ancestor, listed or not. Identifiers are cut at 160 characters with a visible marker. The lineage must fit
6 144 bytes (protocol limit 8 192); if it cannot, the export is refused, never cut silently. `classify()` and the
hello trust now also read `ancestry_trust`, the references and v5.1 nested ancestors: a synthetic or unknown ancestor
anywhere can only lower trust; a lineage too large to read completely counts as unknown. `trust` and
`original_synthetic` keep their v5.1 meaning; v5.1 documents are read as stored and never rewritten. Before any export
is returned, `check_replayable()` feeds the text through a scratch `TelemetryHub` exactly as `FileReplaySource` would
(line splitting with MAX_LINE, hello and frame validation, sequence and time rules) and refuses it unless every hello
and every row is accepted.

**Evidence.** Reviewer's probe: v5.1 lineage 511 → 996 → 2 239 → 4 725 → 9 697 bytes, generation 5
`rejected:invalid_hello`; v5.2 eight generations, 528 → … → 2 786 bytes (the cap reached at generation 7). Our probe,
24 generations: v5.1 fails at generation 5 (two-segment mixed), 4 (four reconnect segments with clock restarts) and 6
(declared-physical, two segments); v5.2 completes all four chains (unknown upload included), every row replayed,
largest lineage 3 086 bytes. Tests: 24 generations through the FileReplaySource transport and the recorder for the
reviewer's mixed recording, four reconnect segments, a declared-physical fixture (stays declared-physical, always
`derived`) and an unknown upload (replays and stays synthetic); parents and original sources still listed after
truncation, `ancestry_omitted` counted; a v5.1 lineage of 7 892–8 192 bytes flattened within the budget; synthetic and
unknown ancestors hidden inside v5.1 nesting lower the trust; the summary survives truncation; a lineage that cannot fit
is refused; through the API, 20th-generation descendants (synthetic and declared-physical) are never validation
evidence and their datasets say what they are.

## 5. G3 — skipped test cases are never a pass

**Cause.** `status_of` marked a suite passed when nothing failed or was not run, whatever was skipped inside it, and
completeness was computed from suites only.

**Correction** (`scripts/run_tests.py`). The pytest JUnit report is read case by case: every skipped case is listed
with its reason (`skipped_tests`, SUMMARY.md table, console line), failed cases by name (`failed_tests`). Suite
statuses add `incomplete` (cases skipped or not run, nothing failed) and `passed with exclusions`. The summary
separates `complete` (every case of every selected suite executed), `all_passed`, `all_applicable_passed`,
`all_tests_executed` (complete and every suite selected) and the unqualified `full_validation`; `suites_ran` keeps
the v5.1 meaning of `complete`. Exit codes, identical in JSON, Markdown, console, CI and the release validator: 0
everything in scope executed and passed; 1 a failure, timeout or missing counts; 2 incomplete; 3 passed with a
declared platform exclusion (never a full validation); 64 usage error. The only declared exclusion
(`scripts/platform_exclusions.json`) is the `/proc` orphan-worker check on macOS, accepted only while its portable
`ps` counterpart passes in the same run; it is still counted as skipped and named in the verdict. Linux excludes
nothing. New options `--timeout` and `--exclusions` (the policy file and its SHA-256 are recorded). Interpreter
resolution is unchanged (its tests pass with both runners).

**Evidence.** The reviewer's fixture (one pytest pass, one skip): v5.1 runner exit 0, "PASSED — all 2 suites ran and
passed", `full_validation: true`; v5.2 runner exit 2, "INCOMPLETE — … 1 skipped — backend::tests.test_skip::test_skipped
(controlled review skip) …". Our 29 runner tests against the v5.1 runner: 13 fail (the G3 cases and the full-pass
wording), 16 pass. Tests cover mixed pass/skip, all skipped, failure + skip, selected-only + skip, a declared exclusion
(exit 3) and four ways it does not apply (other platform, failed or missing counterpart, malformed policy), a missing
tool, a tool that cannot start, a suite that reports no counts, a timeout, explicitly skipped suites, the committed
policy (it names existing tests and nothing on Linux) and the macOS decision applied to the review's two JUnit cases.
The tiny fixture is a summary test, not product or research evidence.

## 6. G4 — browser cancellation in every state

**Test.** `browser_v3.py` no longer clicks after 300 ms: the actual Cancel button is clicked inside the real job's own
progress callback while it is RUNNING with 0 < done < total, then a bounded wait; it asserts CANCELLED, exactly the
finished rows in order, PARTIAL and the banner. `browser_v52.py` (new, 45 checks) tests separately: before start
(QUEUED), during execution (rows compared with an independent recomputation of the same configurations by the same
engine; the analysis uses only those rows), at the last run, during ANALYZING, after completion, and the next sweep
after a cancellation — at full speed and with Chromium's CPU throttled 4× (DevTools), three attempts each, no
retries; completion is never accepted as a cancellation.

**Product defects it reproduced (v5.1, deterministic probe `g4_states_probe.py`, full speed and 4× throttled), and
the minimal corrections:**
1. ANALYZING (browser engine): the Cancel button was visible, turned into "Cancelling…" and the request was silently
   ignored (390 rows, COMPLETE). The browser engine does not interrupt its analysis — every run has finished and the
   analysis is one short synchronous computation — so `LocalSimulatorAdapter.capabilities().cancel.states` is
   queued/initializing/running, the optional `cancellable(job)` says the same, `AERIS_SERVICE.cancellable(job)` asks the
   job's adapter, and the button is hidden while a request can no longer take effect. A request that arrives anyway is
   reported in the job message; the complete result is kept. Research-backend jobs are unchanged (their analysis is
   cancellable).
2. A cancel processed in the same update as the last finished run labelled the complete set PARTIAL ("Cancelled after
   390 of 390 runs"); now `finish()` cancels only while runs remain.
3. After one cancellation the button stayed disabled as "Cancelling…", so the next sweep in the page could not be
   cancelled (it ran to 390); `syncCancel()` resets it whenever no job is running.

**Evidence.** v5.1 (`results/v5.1/`): the old browser_v3 check passed 3 / 3 here — at 300 ms this machine had finished
83 of 390 runs, the reviewer's Mac all 390 (their log and probe) — so we did not reproduce the race itself;
`browser_v52.py` against the v5.1 site code: 24 / 45 (cancellation during execution works there; the three defects and
the stuck button fail). v5.2: `browser_v52.py` 45 / 45 and `browser_v3.py` 49 / 49 in each of 5 runs
(`results/v5.2/browser-repeats/`; one further attempt was cut by our shell's 10-minute command limit with no failure
and is kept). The reviewer's `cancel_probe.py`: both modes end CANCELLED with PARTIAL rows on both versions here.

## 7. H1 — found while verifying v5.2

The first full run (commit `6ca58fa`) failed one existing v5.1 check, kept in
`evidence/v5.2-verification/full-run-1-6ca58fa/`: browser_v51 "Recording a replay of the declared-physical recording …"
— `only 1 frame(s) were recorded`. The check replayed a ~2 s recording at 1× and recorded until "replay finished", so
a late status update could leave one frame. Six isolated runs (three v5.2, three unmodified v5.1) passed; they do not
replace the failed run. Corrected in `020d8bf` without a product change or a longer wait: the same replay of the stored
recording starts from the connect form at 0.1× (≥ 20 s, longer than every bounded wait before recording starts) and the
recording stops after six replayed frames while the replay is still running (asserted).

## 8. Test totals

| Run | Commit | backend | JavaScript (11) | live | browser (6) | Total | Verdict |
|---|---|---:|---:|---:|---:|---:|---|
| full run 1 | `6ca58fa` | 453 | 181 | 14 | 215 + **1 failed** | 863 passed, 1 failed | FAILED (exit 1) |
| full run 2 (`test-logs/`) | `020d8bf` | 453 | 181 | 14 | 216 | **864 passed**, 0 failed, 0 skipped, 0 not run | PASSED — all 19 suites; every test case executed (full validation on Linux; exit 0) |

Browser suites in run 2: browser_check 50, browser_v3 49, browser_v4 24, browser_v5 36, browser_v51 12, browser_v52 45.
v5.1 had 757 tests in 18 suites; v5.2 adds 62 backend tests (38 + 10 + 14) and the browser_v52 suite (45). Schema and
`index.html` drift checks: no drift. The restart, provenance and COM checks pass. No scientific tolerance was widened
and no historical fixture was regenerated.

## 9. Numerical reproducibility

The engine is unchanged (1.1.0). `studies/verify_campaign.py` re-ran the same 32 sampled campaign rows the review used
(seed 2026, 4 per study) with backend 1.1.2: **32 identical** (bit for bit), 0 outcome changes
(`evidence/v5.2-verification/numerical/`); the stored campaign and its own verification file were not touched.
The backend suite's reproduction and parity tests pass. Unrelated campaigns were not re-run.

## 10. CI

**Not executed on a hosted CI service.** Blocker: the project's origin in this session is a local Git bundle; the
session's GitHub access is bound to configured repositories and none is configured for this project (listing
repositories answers HTTP 403 "sessions are bound to their configured repositories"); creating a repository or changing
sharing was not authorised. There is no run URL. Executed instead, and **not** a hosted CI run: `scripts/ci_local.py`
ran every `run:` step of `.github/workflows/ci.yml` verbatim, each job in its own fresh clone of `020d8bf`
(setup-python → Python 3.12.3, setup-node → Node 22.22.2): **every step of the four jobs succeeded** — backend 453,
javascript 181 after the drift checks, integration 14, browser 216 (Playwright and Chromium installed by the workflow's
own step); each job's verdict "selected suites only … Not a full validation", exit code 0
(`evidence/v5.2-verification/ci-local/`).

## 11. Release archive

`scripts/validate_release.py` now has 17 steps: the 14 of v5.1 plus **telemetry-units** (G1, end to end through the
running backend), **telemetry-generations** (G2, 20 generations with the fresh install's Python, the 20th copy imported
and checked through the API), the extended **test-runner** (G3 fixture: exit 2, then exit 3 under a declared exclusion)
and **browser-cancel** (G4: browser_v52 and browser_v3 of the extracted package, with `--browser-python`; without it
the step is NOT RUN and the validation INCOMPLETE, exit 2). The candidate archive (commit `9c17aac`, 777 files,
SHA-256 `5814ee06…a950386d`) passed **17 of 17** steps in a fresh directory (install with Python 3.12.3 matching the lock
file; browser-cancel with Playwright 1.56.0: browser_v52 45 / 45, browser_v3 49 / 49), and the archive equals that
commit file for file and byte for byte against a verified bundle of the complete history (`evidence/v5.2-release/`).
The delivered archive is built from the commit tagged `aeris-v5.2` (this report's commit); its own fresh-directory
validation, its ZIP ↔ bundle check and its SHA-256 are delivered next to it (they cannot be inside the archive they
describe).

## 12. Limitations and what remains

* Physical validation is pending and cannot be done by software: firmware/device mapping, axis and sign checks,
  time/latency characterisation, measured mass, COM, inertia and actuator/sensor parameters, real recordings and
  predeclared validation experiments ([HARDWARE_NEXT_STEPS.md](site/docs/HARDWARE_NEXT_STEPS.md)). No measurement was
  produced or claimed; every recording used here is synthetic or an artificial fixture.
* macOS was not run by us: the exit-code-3 path for the `/proc` exclusion is tested on Linux with a fixture policy and
  with the runner's decision applied to the review's two JUnit cases, not on a Mac. Windows, non-Chromium browsers,
  long soak tests and remote/multi-user deployment remain untested; hosted CI was not run (§10).
* NDJSON copies made by v5/v5.1 from recordings in non-wire units cannot be repaired; `export-audit` finds them only
  inside a database (files elsewhere cannot be audited).
* Uploaded recordings with a `status` column must declare `provenance.status_codes` to be streamed (or be exported
  with `omit_unmapped=true`).
* In the browser, an NDJSON export the backend refuses (HTTP 422) appears as a failed download from the recordings
  list (the design is frozen); the reason is in the API response, and the Replay control shows it.
* A browser-engine sweep cannot be cancelled once every run has finished (by design, §6).
* The pre-return replay check costs time: an NDJSON export of 30 000 frames (5 min at 100 Hz) took 1.48 s on this
  machine (0.61 s without the check). The export endpoint runs it off the event loop; starting the replay of a stored
  recording (`connect {source: "recording"}`) runs it on the backend's event loop, as v5.1 ran the export there, so live
  updates pause for that time.

## 13. How to run

```bash
scripts/install.sh --python python3.12
backend/.venv/bin/python -m pip install playwright==1.56.0 && backend/.venv/bin/python -m playwright install chromium
python3 scripts/run_tests.py --backend-python "$PWD/backend/.venv/bin/python" --browser-python "$PWD/backend/.venv/bin/python"
python3 scripts/ci_local.py --python python3.12                       # the CI steps, locally (not a CI service)
cd studies && ../backend/.venv/bin/python verify_campaign.py --out /tmp/campaign-verification.json && cd ..
python3 scripts/validate_release.py --zip aeris-site-v5.2.zip --expect-top aeris-v5.2 --browser-python "$PWD/backend/.venv/bin/python"
python3 scripts/compare_archive_bundle.py --zip aeris-site-v5.2.zip --bundle aeris-site-v5.2-git.bundle --ref aeris-v5.2
backend/.venv/bin/python -m aeris_backend.tools.dbtool export-audit --db data/aeris.sqlite3     # read-only
```

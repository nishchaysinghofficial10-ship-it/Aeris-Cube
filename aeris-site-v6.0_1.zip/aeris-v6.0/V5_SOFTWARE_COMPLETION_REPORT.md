# AERIS v5 · Software completion report

> **Historical (v5, as delivered).** Superseded by `SOFTWARE_COMPLETION_REPORT.md` (v5.1). The `test-logs/` and
> `evidence/release/` files this report cites are preserved unchanged in `evidence/v5-release/`; the repository's
> `test-logs/` now holds the v5.1 run. The independent review of v5 found five issues (F1–F5) in what this report
> marks as passed; see `evidence/v5-independent-review/` and the v5.1 report.

Scope: the brief `AERIS-software-completion-prompt.txt` (sections 1–9), applied to `aeris-site-v4.zip`
(SHA-256 `bffbcf49d190be6c96a539ca1891f6d0792f087d48108959d715d75d6faf52d3`; git baseline commit `06056ea`,
the archive itself unchanged). Every statement below points to code and to evidence that was **executed** in the
environment of §2; what was not executed is listed as such (§9). Passing software tests is not evidence about the
physical cube: nothing here was measured on, connected to or validated against it.

## 1. Status at a glance

| Gate | Status | Evidence |
|---|---|---|
| Review findings A–E reproduced on v4 and fixed | **passed** | `evidence/` (probes on v4 and v5), regression suites (§4.2), negative control for E |
| Experiment contract (initial state, reference, recovery statement) | **passed** | `test_experiment_contract.py`, `v5.test.js` R1–R5/C1, `browser_v5.py` |
| Engine audit (stated identities and checks; not a global stability claim) | **passed** for the stated checks | `test_engine_audit.py`, `test_physics.py`, `studies/solver_verification.py` |
| Persistence and workflows through the real frontend and backend | **passed** | `browser_v5.py`, `test_persistence.py`, `test_recovery.py`, `test_process_restart.py` |
| Telemetry path end to end with **synthetic** data | **passed (synthetic only)** | `test_telemetry.py`, `live_backend.test.js` L13, `browser_v5.py`, release validation step `telemetry` |
| Nominal study campaign | **executed** (nominal model only; 3 complete re-runs identical) | `studies/results/nominal-v5/` |
| All test suites on this machine | **685 passed, 0 failed, 0 skipped, 0 not run** (backend 343, JavaScript 172, live 13, browser 157) | `test-logs/` (§3) |
| Fresh-directory release validation (Linux) | **passed** (11/11 steps) | `evidence/release/release-validation.candidate.json` (§6) |
| CI workflow | **written, not executed on a CI service** | `.github/workflows/ci.yml` |
| macOS / Windows | **not executed** | — |
| Cross-platform numerical tolerance | **not executed** (one platform available) | `site/docs/REPRODUCIBILITY.md` §2 |
| Physical hardware: device compatibility, measured parameters, validation | **not done — out of reach of software** | `site/docs/HARDWARE_HANDOFF.md` |
| Authenticated remote hosting | **not in scope**; requirements documented only | `backend/README.md` ("Deployment") |

Software completion is therefore **conditional**: complete and tested for one local Linux research workstation
with synthetic telemetry; the gates marked not executed remain open.

## 2. Environment of every executed check

| Item | Value |
|---|---|
| Machine | Linux x86-64 (kernel 6.18.44, glibc 2.39), 2 logical CPUs (Intel Xeon), 7 GB RAM; a cloud sandbox, loopback services only |
| Backend | Python 3.12.3 venv with the lock file: NumPy 2.5.3, SciPy 1.18.1, FastAPI 0.141.1, Starlette 1.7.0, uvicorn 0.54.0, pydantic 2.13.5, pytest 9.1.1 |
| Frontend tests | Node.js v22.22.2 |
| Browser tests | Playwright 1.56.0 (Python 3.11.15), Chromium 141.0.7390.37 headless (SwiftShader WebGL), reduced motion |
| Figures | matplotlib 3.11.2 (optional, `studies/requirements-plots.txt`) |
| Network | no public deployment, no hardware, no cloud credentials; package installation from PyPI through the sandbox proxy |

## 3. Test results (exact counts, this machine)

Command: `AERIS_PYTHON=<backend python> python3 scripts/run_tests.py` → `test-logs/` (one log per suite,
`summary.json`, `SUMMARY.md`, `pytest-junit.xml`).

| Suite | Passed | Failed | Skipped | Not run | Seconds | Log |
|---|---:|---:|---:|---:|---:|---|
| Backend (pytest: numerical, engine, API, jobs/recovery, persistence, telemetry) | 343 | 0 | 0 | 0 | 248.6 | `test-logs/backend.log` |
| JavaScript · assistant | 9 | 0 | 0 | 0 | 0.3 | `test-logs/js-assistant.log` |
| JavaScript · engine | 9 | 0 | 0 | 0 | 1.1 | `test-logs/js-engine.log` |
| JavaScript · numerics | 38 | 0 | 0 | 0 | 0.9 | `test-logs/js-numerics.log` |
| JavaScript · platform | 16 | 0 | 0 | 0 | 0.5 | `test-logs/js-platform.log` |
| JavaScript · runs | 14 | 0 | 0 | 0 | 0.5 | `test-logs/js-runs.log` |
| JavaScript · schema | 7 | 0 | 0 | 0 | 0.6 | `test-logs/js-schema.log` |
| JavaScript · service | 19 | 0 | 0 | 0 | 0.6 | `test-logs/js-service.log` |
| JavaScript · ui | 16 | 0 | 0 | 0 | 0.4 | `test-logs/js-ui.log` |
| JavaScript · v4 | 27 | 0 | 0 | 0 | 0.8 | `test-logs/js-v4.log` |
| JavaScript · v5 | 17 | 0 | 0 | 0 | 0.7 | `test-logs/js-v5.log` |
| Live adapter integration (site adapters ↔ started backend + emulator) | 13 | 0 | 0 | 0 | 11.8 | `test-logs/live.log` |
| Browser · browser_check | 50 | 0 | 0 | 0 | 99.6 | `test-logs/browser-browser_check.log` |
| Browser · browser_v3 | 47 | 0 | 0 | 0 | 62.4 | `test-logs/browser-browser_v3.log` |
| Browser · browser_v4 | 24 | 0 | 0 | 0 | 132.5 | `test-logs/browser-browser_v4.log` |
| Browser · browser_v5 | 36 | 0 | 0 | 0 | 74.9 | `test-logs/browser-browser_v5.log` |
| **Total** | **685** | **0** | **0** | **0** | | `test-logs/summary.json` |

Run 2026-09-29T18:10:26+00:00 on Linux-6.18.44-fc-v37-x86_64-with-glibc2.39; every suite exit code 0: True.

**Against the v4 baseline observations** given in the brief (144/144 Python, 167/167 JavaScript including 12 live
checks, 119/121 browser checks, observed on your machine): every v4 test is still present and passing, with the
same per-file counts (backend: actuators/estimation 17, control/metrics 25, hardware 5, parity 51, physics 16,
service 14, sweeps 12; schemas 4 → 6). Backend 144 → 343; JavaScript 155 → 172 plus live 12 →
13; browser 121 → 157. The two v4 browser failures ("'Open in AERIS Lab' from the Twin page
runs that exact setup" and "3-D view labels the run", the replay race) pass, with bounded waits and the fix.
Test expectations changed only where behaviour changed on purpose; each is listed with its reason in
`site/docs/MIGRATION_V5.md` §8. No assertion was weakened and no numerical or integration check was replaced by a
mock.

**A flaky check found and fixed on the way.** One full run before the final one failed a single check:
`browser_check.py` "Play advances time and Pause stops it" read the playback time after a fixed 0.7 s pause and
found 0.06 s (frames rendered with software WebGL can be slow, so how far playback gets within a fixed pause
depends on the machine's load, not on the behaviour under test). Two earlier full runs had passed it. The check now waits (bounded, 15 s) for t > 0.2 s and additionally
requires that the time does not move after Pause; `browser_v4.py`'s playback check got the same bounded wait. The
failing log is kept (`evidence/test-runs/browser_check.fixed-pause-flake.log`); the table above is the complete
run after the change.

**Negative controls** (the new checks detect the defects they target):

* replay race (E): with the three layers of the fix reverted in a temporary copy, both race checks of
  `browser_v5.py` (DEMO and SIMULATION) fail with the v4 symptom ("Setup preview", no run in the 3-D view) and no
  other check fails — `evidence/v5-verification/replay_race_negative_control.py` → `.out`;
* orphaned workers: with the parent watch removed,
  `test_process_restart.py::test_worker_processes_exit_when_the_backend_process_is_killed` fails with three
  processes still running after 15 s (§4.4).

## 4. Requirements → implementation → executed evidence

### 4.1 Scope and preservation (brief §1)

| Requirement | Implementation | Evidence |
|---|---|---|
| Preserve design, navigation, LocalSimulatorAdapter, offline DEMO, replay, comparisons, exports, service architecture | unchanged; additions only: Telemetry tab, contract editors in the advanced setup, sweep dataset actions, status texts (`css/platform.css` `tm-*`) | v2/v3/v4 browser suites (`browser_check.py` 50, `browser_v3.py` 47, `browser_v4.py` 24) and the nine v4-era JS suites pass (deliberate expectation changes: `MIGRATION_V5.md` §8); screenshots `site/tests/screenshots/v5-01…07` |
| Extend ResearchApiAdapter and backend, no new architecture | telemetry reaches the site through the existing service (`js/platform/service.js` `bind`) and `js/adapters/hardware-telemetry.js`; backend `hardware/bridge.py` behind the v4 bridge abstraction | `service.test.js`, `v5.test.js` T1–T5, `live_backend.test.js` L13 |
| Old records readable; explicit, versioned, documented schema extensions with compatibility tests | config rev 1.2, run rev 1.3, sweep rev 1.2, metrics v2, DB schema 2, parameter sets rev 2 (`site/docs/MIGRATION_V5.md`, `SCHEMA_EXTENSIONS.md`) | `test_schemas.py` (v4 records validate), `schema.test.js`, `v5.test.js` R5/M1/D2, `test_recovery.py::test_v4_database_is_migrated…`, `…newer_schema_is_refused_unchanged`, `test_reproduction.py` |
| Research fields preserved through editing, controller sets, sweeps, save, import/export, reproduction; authoritative backend metadata kept | `js/platform/config.js` normaliser keeps every field; records stored as returned | `v5.test.js` R1, `v4.test.js`, `live_backend.test.js` L4, `browser_v5.py` (export carries executed method, reference, metric version; unchanged after reload) |
| Unsupported requests fail with field-specific errors; no silent substitution | backend validation (`config/normalize.py`, `config/validate.py`), browser mirror; the site refuses revision-1.2 features and declared sweep criteria for a backend that does not report them | `test_experiment_contract.py::test_unsupported_objectives_are_refused_with_field_specific_errors`, `test_control_metrics.py::test_no_silent_controller_substitution`, `test_recording.py::test_v4_mismatch_is_rejected_with_a_field_specific_error`, `v5.test.js` R2/C1, `browser_v5.py` (DEMO refusals) |
| One local workstation, SQLite + worker processes; loopback by default; remote hosting documented separately | defaults `127.0.0.1` (API, emulator, telemetry sources); warning for other addresses; `backend/README.md` "Deployment" | `test_telemetry.py::test_loopback_is_the_default`, `test_startup.py`, release validation |

### 4.2 The five confirmed defects (brief §2)

| Defect | Fix | Evidence (v4 → v5) |
|---|---|---|
| **A** metrics: angular ISE in rad²·s labelled deg²·s; n intervals weighted n+1 | time-weighted trapezoidal RMS/IAE/ISE at the integration step, units by dimension, final partial interval and early termination defined; metric version 2 recorded; v4 records keep version 1 and are shown as saved; `POST /runs/{id}/reanalyze` re-simulates as a new record with lineage (saved samples do not resolve every step) — `metrics/research.py`, `site/docs/METRICS.md` | constant 1° for 1 s: v4 IAE 1.1, ISE 0.0192 → v5 RMS 1.0, IAE 1.0, ISE 1.0 (`evidence/`); `test_metrics.py` (review fixture, analytic signals, step convergence, units, early termination, record fields); `v5.test.js` M1–M2; units in the results panel, CSV headers, sweep tables and comparisons (`test_reproduction.py::test_comparison_names_metric_versions_and_withholds_version_1_ise`, `browser_v5.py` compare checks) |
| **B** restart recovery: ANALYZING → RUNNING TransitionError swallowed, job re-dispatched forever | per-state recovery at start-up, atomic result saves, idempotent finalisation from a saved run, attempt limit, visible `inconsistent_state`/`retry_limit` failures, unique indexes against duplicate runs, single-process lock, test-only fault injection at every persistence boundary — `jobs/manager.py`, `storage/sqlite.py`, `site/docs/JOBS_AND_RECOVERY.md` | v4 probe: re-dispatched forever → v5: failed visibly once (`evidence/`); `test_recovery.py` (29: every boundary for single jobs and sweeps under `resume` and `fail`, cancellation races, attempt limit, quarantine, v4 database migration, bounded live-update queues); `test_process_restart.py` (real `os._exit` after a save and SIGKILL during a sweep with a new server process; monotone progress; one run per row; second server refused; workers of a killed server exit) |
| **C** estimator timing: attitude frozen between IMU samples, age reported 0 | time-stamped lifecycle: measurement, receipt and estimate time; prediction to the control time from gyro data without truth access or double integration; age and validity passed to the controller; duplicate/out-of-order/delayed/initialisation/stale policies; MEKF covariance propagation and reset Jacobian — `simulation/engine.py`, `estimation/`, `site/docs/ESTIMATION_TIMING.md` | v4: 216 control intervals with a non-zero rate and a frozen estimate → v5: 0 (`evidence/`); `test_estimator_timing.py` (28: rates, latency, consecutive dropouts, constant rotation exact, covariance finite/symmetric/PSD, reset Jacobian, stale flags, both modes, perfect-state baseline, gravity-only heading limitation) |
| **D** recording: 60 Hz requested, 62.5 Hz executed, labelled 60 Hz | explicit rate restriction: `record_hz` must divide the integration rate (backend) or loop rate (browser); refused otherwise with the nearest valid rates; realised schedule saved; endpoint rule defined; old v4 records detected and explained, reproduced at the executed rate — `simulation/engine.py`, `site/js/core.js`, `site/docs/RECORDING.md` | `test_recording.py` (29, incl. recording rate never changes dynamics, control or internal metrics); `v5.test.js` D1–D2 |
| **E** replay race: a pending setup preview overwrites a replay | preview cancelled on every view change, generation- and mode-guarded callback, guard inside the preview itself — `site/js/workspace.js`, `js/ws-util.js` | v4 probe: "SETUP PREVIEW", no run → v5: intact (`evidence/`); `browser_v5.py`: setup edits 0–150 ms before opening a replay, in DEMO and with a stored SIMULATION run, reduced motion, no autoplay; 3-D view, telemetry, timeline, plots and record must agree; negative control (§3); bounded waits in every browser suite, including Twin → Lab (`browser_check.py` checks that a new run of exactly that setup opens) |

### 4.3 Experiment contract (brief §3)

| Requirement | Implementation | Evidence |
|---|---|---|
| Explicit normalised quaternion, body-rate vector, wheel speeds; frames, units, order, precedence/conflict rules | `initial.attitude_q` `[w,x,y,z]` body→world, `body_rate_dps` in body axes, `wheel_speeds_rpm`; conflicts with legacy tilt/rate refused; near-unit renormalised with a warning; edge: rotations about the hinge only; through-the-floor refused — `site/docs/EXPERIMENT_CONTRACT.md` §1 | `test_experiment_contract.py` (explicit state = legacy inputs → identical run; non-unit, conflicts, edge axis, floor; wheel speeds and body rate), `v5.test.js` R1/R3/R4 |
| Reference/objective: fixed references, scheduled commands; requested vs achievable equilibrium; unsupported combinations refused | `reference` block (balance attitude, heading `hold`/`free`, `yaw_deg`), `yaw_step` commands; `executed.reference` records requested target, controller target and plant equilibrium; free heading with MIMO LQR, commands with a free heading, heading in edge mode refused | `test_experiment_contract.py` (heading offset tracked and used as the recovery target, free heading not corrected, requested vs equilibrium recorded, refusals) |
| Through schemas, validation, capabilities, advanced setup, sweep paths, storage, replay, export, reproduction; DEMO refuses clearly | schemas regenerated (`site/schemas/`); `/capabilities` reports `config.revisions`, `experiment`, `metrics`, `sweep.criteria`; setup editors; sweep paths over the new fields; reproduction of revision-1.2 runs | `test_service.py` (capabilities), `test_experiment_contract.py::test_sweep_paths…`, `::test_reproduction_of_a_revision_1_2_run_is_identical`, `v5.test.js` R2/C1, `browser_v5.py` (editor, run, export, reload, reproduce) |
| Recovery states target, thresholds, hold, deadline, yaw objective, objective change after a fault; first/sustained/exits/falls separated in study summaries | `research.recovery` block; sweeps declare `criterion` (`legacy`, `research`, `research_sustained`); analysis and study summaries report first recovery, sustained, later exits, falls after recovery | `test_experiment_contract.py::test_recovery_distinguishes_first_sustained_exits_and_falls`; every `studies/results/nominal-v5/*/summary.md` (second table) |

### 4.4 Engine verification (brief §4)

Retained and audited: mass/COM/full inertia, quaternion rigid body with wheels, actuator limits/degradation/lag/
friction, disturbances, RK4, sensor models, truth/estimate separation, PID, LQR, MIMO LQR, COM-adaptive LQR,
nonlinear quaternion PD, allocation — table with the test for each item in `site/docs/ENGINE_AUDIT.md`.

| Check | Evidence |
|---|---|
| momentum/energy identities (torque-free H and energy; mechanical energy with gravity, corner and edge, to 1e-9) | `test_physics.py`, `test_engine_audit.py` |
| torque signs, gyroscopic coupling; off-diagonal inertia coupling as Θ̂⁻¹ predicts | `test_physics.py`, `test_engine_audit.py` |
| quaternion normalisation every step, drift monitored and bounded by `termination.max_quaternion_drift` | `test_engine_audit.py` |
| RK4 order 3.6–4.4 against an independent DOP853 solution | `studies/solver_verification.py` → `studies/results/solver-verification/` |
| controller/model consistency (edge LQR follows exp((A−BK)t)x₀ of its own design within 2 %) | `test_engine_audit.py` |
| MIMO conserved-momentum mode and nonlinear PD limitations documented | `site/docs/CONTROLLERS.md` §4/§6, `ENGINE_AUDIT.md` |
| sweeps keep failed/invalid rows and use the declared criterion; seeds, distributions, workload limits; identical rows with 1 and 3 workers and after a crash-and-resume | `test_sweeps.py`, `test_engine_audit.py`, `test_experiment_contract.py` |
| reproducibility tolerances defined (bit-identical on one platform; relative 2e-5 across platforms, not executed) | `site/docs/REPRODUCIBILITY.md`, `test_reproduction.py` |

Additional defects found while completing the workflows and fixed, each with a test: worker processes of a killed
backend kept running as orphans (`site/docs/JOBS_AND_RECOVERY.md`; test with negative control); a v5 site could
send configuration-revision-1.2 features and a declared sweep criterion to an older backend that does not
implement them (`v5.test.js` C1); the compare panel showed no research metrics and the backend comparison had no
test for mixed metric versions (`test_reproduction.py`, `browser_v5.py`); telemetry stream-quality counters mixed
every source since start-up, so a replay showed the preceding emulator session's frames and duplicates as its own
(now per source, with totals separate — `test_telemetry.py`, found while checking the release validation output). The engine changes made for finding C
(prediction to the control time, MEKF reset Jacobian, compensated initial alignment) alter the trajectories of
cf3d/MEKF runs; they are named in `experiments/reproduce.py` `ENGINE_CHANGES` and in reproduction verdicts.

### 4.5 Persistence and workflows (brief §5)

| Requirement | Evidence (executed through the real frontend and backend unless stated) |
|---|---|
| configure → validate → run → inspect/replay → compare → save/export → reload → reproduce | `browser_v5.py`: explicit-quaternion MEKF + nonlinear PD run with a free heading; replay agreement; compare with an LQR run; JSON export; unchanged after reload; "reproduced every saved sample exactly" |
| sweep → progress → cancel → partial rows → analyse → finalise/export dataset | `browser_v5.py` (progress shown, cancel, PARTIAL label, analysis of stored rows, dataset finalised and exported with an intact integrity check); release validation `sweep-cancel` |
| migrations, transactions, stable ids, immutable final datasets, backup/restore into a fresh instance, traceability | `test_recovery.py` (v4 database migrated, newer refused), `test_persistence.py` (immutable final datasets with member hashes, backup while running + restore into a fresh instance + reproduce, verify detects a changed member, `dbtool` CLI; after the restore a record still carries its configuration hash, seed, software versions, executed controller and estimator and metric version), `test_service.py` (sweep rows: configuration hash and seed per row; parameter-set coverage), `test_parameters.py` |
| WebSocket order/dedup, reconnect, polling fallback, unreachable backend, cancellation, error envelopes, bounded resources | `v4.test.js`, `service.test.js`, `live_backend.test.js` L1/L8/L9/L12, `v5.test.js` T2/T3, `test_service.py::test_error_envelopes`, `test_recovery.py::test_job_update_queue_is_bounded_and_always_keeps_the_newest_state`, `test_telemetry.py` (bounded slow consumer, live-socket limit), sweep workload limits (`test_sweeps.py`) |
| DEMO usable without a backend; no optimistic labels | `browser_v4.py` (backend stopped: NOT REACHABLE, DEMO runs), `browser_v5.py` (SIMULATION only after the probe answered; "NO TELEMETRY SOURCE" before a connection), `test_telemetry.py::test_hub_bridge_reports_a_failed_connection_without_claiming_it` |

### 4.6 Hardware preparation in software (brief §6)

| Requirement | Implementation | Evidence |
|---|---|---|
| transport → validation → normalised stream → storage → live frontend → recorded replay → offline comparison | `backend/aeris_backend/telemetry/` (`protocol`, `stream`, `transport`, `emulator`, `device`), `hardware/bridge.py`, API endpoints and `WS /telemetry/live`, Lab Telemetry tab — `site/docs/TELEMETRY.md` | `test_telemetry.py::test_api_live_stream_record_export_replay_dataset_compare`, `live_backend.test.js` L13, `browser_v5.py` telemetry checks, release validation `telemetry` |
| NDJSON over configurable local TCP, file replay, standalone emulator; a proposed contract, not a property of your firmware | `aeris-telemetry-ndjson/1`; `python -m aeris_backend.telemetry.emulator` (127.0.0.1:47100, deterministic faults) | `test_telemetry.py` (emulator faults detected end to end over TCP, file sessions) |
| malformed data, unit/frame errors, non-unit quaternions, duplicates, gaps, reordering, disconnects, reconnects, stale streams, slow consumers | strict validation (units checked, never converted), counters, sessions, stale/fresh events, bounded drop-oldest subscribers | `test_telemetry.py` (32 tests) |
| synthetic provenance survives streaming, recording, export, datasets, comparison; the emulator never appears as the cube and is never validation evidence | provenance label `SYNTHETIC EMULATOR — not the physical cube`; `physical_verified` always false; `hardware.live` only for a declared physical source; comparisons with synthetic data are marked not admissible | `test_telemetry.py`, `v5.test.js` T4/T5, `browser_v5.py` (banner, 3-D view, status strip, recordings, replay, comparison, dataset) |
| device adapter interface; hardware handoff document; read-only | `DeviceAdapter`, `MappedJsonAdapter` (units, axes, quaternion order, clock), `AERIS_TELEMETRY_ADAPTERS`; no command path — `site/docs/HARDWARE_HANDOFF.md` | `test_telemetry.py` (mapping, named mapping errors, adapter errors counted, API mapping from file) |
| parameter provenance for every measurable input; versioned sets; partial/overridden sets never imply "measured" | path-keyed parameter sets revision 2 with unit/shape checks, immutable with `supersedes`, per-run coverage MEASURED/OVERRIDDEN/NOMINAL — `site/docs/PARAMETERS.md` | `test_parameters.py` (29), `test_service.py`, `test_persistence.py` |
| predeclared validation protocols, independent reference, comparison limits; no synthetic promotion | v4 behaviour kept and extended with provenance checks | `test_hardware.py::test_acceptance_requires_prior_protocol_and_real_data`, `test_telemetry.py`, `browser_v5.py` ("Not validation evidence … never promotes") |

### 4.7 Studies and benchmarks (brief §7)

* **Nominal campaign** (`studies/`): 8 studies, 1 668 runs — controller comparison (corner), DOA slices (edge and
  corner), unknown COM shift, torque-limit saturation, wheel degradation, Monte Carlo sensing with a push, and an
  advanced case (quaternion MEKF with LQR, MIMO LQR and nonlinear PD). Definitions, seeds, raw rows (JSON/CSV),
  backend analyses (Wilson intervals, exact McNemar), summaries, 18 figures, reproduction check
  (`verify_campaign.py`: 32/32 rows identical) and `rerun-comparison.json` (three complete re-runs, every rows,
  analysis and definition file identical; figures byte-identical). Observations and their limits:
  `studies/README.md`.
* **Solver verification**, **software benchmarks** (`backend/benchmarks/results/`, v4 results kept as history),
  **nominal research results** and **hardware validation (not done)** are kept apart in `studies/README.md`.
* The reference-sheet controller benchmark (6.21/3.02/1.85 s) is labelled **UNVERIFIED HISTORICAL** on the site
  and not used (`browser_check.py` checks the label).

A simulated recovery rate is not hardware reliability; no result is a global stability or robustness claim.

### 4.8 Installation, tests and release (brief §8)

| Requirement | Implementation | Evidence |
|---|---|---|
| reproducible installation; declared Python version; platform limits | `scripts/install.sh` (venv from `backend/requirements-lock.txt`, verified against the lock), `requires-python >=3.12`; Linux tested, macOS expected, Windows manual steps untested (`README.md`) | release validation `install` (installed versions equal the lock) |
| local start, persistent data, clean shutdown, troubleshooting | `scripts/start.sh` (site + API on one loopback origin, optional emulator, `--data`), `scripts/stop.sh`; README troubleshooting | `test_startup.py` (same-origin serving, clean shutdown, lock released); release validation `start`, `restart`, `stop` |
| CI for numerical/backend, schema/JS, adapter integration, browser | `.github/workflows/ci.yml` (4 jobs, schema and `index.html` drift checks) | **not executed on a CI service**; the same commands ran locally (§3) |
| exact counts with logs | `scripts/run_tests.py` | `test-logs/` |
| packaged release validated in a fresh directory; portable script; machine-readable results; archive hygiene | `scripts/validate_release.py` (standard library only) | §6 |

## 5. Hardware: device-specific steps that remain (`site/docs/HARDWARE_HANDOFF.md`)

1. **Protocol mapping**: firmware speaks `aeris-telemetry-ndjson/1`, or a `MappedJsonAdapter` mapping of its own
   JSON lines (field names, units and SI scales, quaternion order, status codes, session start/end), or a
   `DeviceAdapter` for binary packets; a serial/USB/BLE link needs a small bridge to a local TCP port.
2. **Firmware version and device id** for the hello.
3. **Frames and axes**: IMU and estimate body axes relative to the cube (a proper rotation), world frame of the
   quaternion, Hamilton/JPL convention, wheel order and spin signs, torque sign — with the resting-on-the-pivot check.
4. **Timing**: time-stamp source, unit and wrap, frame rate and jitter, IMU and loop rates, IMU-to-estimate latency,
   sequence behaviour at boot.
5. **Measured parameters** as a parameter set with method, date, evidence reference and uncertainty.
6. **Real recordings** with a validation protocol registered beforehand and an independent attitude reference.

Motor control, arming, limits, watchdogs and every safety function belong to the firmware stage; the software is
read-only towards the device.

## 6. Fresh-directory release validation

`python3 scripts/validate_release.py --zip <archive>` extracts the archive into a new temporary directory,
installs it with `scripts/install.sh`, starts it with `scripts/start.sh --emulator` on free loopback ports, and
exercises it only through HTTP and the scripts.

| Step | What is checked | Result | Seconds | Details |
|---|---|---|---:|---|
| archive | required files present; no caches, venvs, credentials or databases | **passed** | 0.0 | 391 files, 10103582 bytes, missing [], forbidden [] |
| extract | unpacked into a new temporary directory | **passed** | 0.2 | {"root": "/tmp/aeris-release-9v1tk6sa/x/aeris-v5"} |
| install | `scripts/install.sh` into a new venv; installed versions equal the lock file | **passed** | 30.2 | Python 3.12.3; lock mismatches {} |
| start | `scripts/start.sh --emulator` on free loopback ports; health, site and API on one origin | **passed** | 1.3 | health {'version': '1.1.0', 'engine_version': 'aeris-research-engine 1.1.0', 'schema_version': 2, 'metrics_version': '2'} |
| experiment | advanced run: corner, nonlinear PD, MEKF, explicit quaternion, free heading | **passed** | 2.6 | AERIS-EXP-100000, outcome recovered, research recovered True |
| reproduce | stored run retrieved unchanged and reproduced identically | **passed** | 1.9 | retrieved identical True; verdict identical |
| restart | running sweep survives `stop.sh` + `start.sh`, resumes, completes without duplicates | **passed** | 24.1 | 5 rows done before the stop; complete, restarts 1, 72/72 unique rows; earlier run unchanged True |
| sweep-cancel | sweep cancelled; partial rows analysed; dataset finalised and exported, integrity intact | **passed** | 1.5 | cancelled with 5/72 rows; dataset AERIS-DS-100000, hashes ok True, content ok True |
| telemetry | SYNTHETIC emulator → backend → polling; recording stored as SYNTHETIC, exported, replayed | **passed** | 1.7 | label 'SYNTHETIC EMULATOR — not the physical cube', recording AERIS-HW-000001 (120 samples), replay frames 120 |
| backup | consistent backup while running, restored into a new file and verified | **passed** | 0.4 | schema 2, tables {'jobs': 4, 'runs': 2, 'sweeps': 2, 'sweep_rows': 77, 'docs': 2} |
| stop | `scripts/stop.sh` stops everything; no PID files left | **passed** | 3.5 | PID files left [] |

11 of 11 steps passed. Validated archive: a candidate build identical to the delivered one except for this report and this result file; run 2026-09-29T18:11:10+00:00 → 2026-09-29T18:12:17+00:00 on Linux-6.18.44-fc-v37-x86_64-with-glibc2.39 (orchestrator Python 3.11.15). The delivered `aeris-site-v5.zip` was validated again the same way; that result is delivered next to it (`aeris-site-v5.release-validation.json`).

## 7. Deliverables

* `aeris-site-v5.zip` — the repository without `.git`, virtual environments, caches, databases or credentials,
  including `test-logs/`, `evidence/`, `studies/results/`, benchmark results and screenshots; its SHA-256 is in
  `aeris-site-v5.zip.sha256` next to it (a file cannot contain its own checksum).
* `aeris-site-v5-git.bundle` — the same repository with its commit history (`git clone aeris-site-v5-git.bundle`),
  from the unchanged v4 baseline commit through the fixes and features (test logs and release-validation results
  are in the archive, not in the history).
* Documentation: `README.md` (quick start, troubleshooting, tests), `CHANGELOG.md`, `site/docs/MIGRATION_V5.md`
  (schema, database, metric and API migration notes), `site/docs/HARDWARE_HANDOFF.md`, `TELEMETRY.md`,
  `EXPERIMENT_CONTRACT.md`, `METRICS.md`, `ESTIMATION_TIMING.md`, `RECORDING.md`, `JOBS_AND_RECOVERY.md`,
  `DATABASE.md`, `PARAMETERS.md`, `REPRODUCIBILITY.md`, `ENGINE_AUDIT.md`, `backend/README.md`, `site/README.md`.

## 8. Limitations (stated, not hidden)

* Every simulated number uses **nominal parameters**; neither engine is validated against the physical cube.
* The telemetry protocol is the software's **proposed** contract; the emulator is a simulation, not a model of your
  firmware. Only synthetic and replayed data have ever passed through the telemetry path.
* Engine limits (`site/docs/ENGINE_AUDIT.md`): conserved vertical momentum in corner mode (no controller removes it),
  finite regions of attraction of the linear designs, no guarantee for the nonlinear PD under saturation or model
  error, heading unobservable from gravity and gyro, ideal fixed support contact (no free flight or sliding).
* Records with metric version 1 (v4) are shown as saved; their values are not corrected in place (reanalysis
  creates new records).
* Worker processes notice a crashed backend through their parent id (POSIX); on Windows this does not apply.
* The browser engine (AERIS Twin 0.3.0) runs revision-1.0 setups only; research features (revisions 1.1 and 1.2)
  need the research backend and are refused in DEMO with the reason.
* Test output shows one third-party deprecation warning (Starlette test client and httpx); it does not affect
  results.

## 9. Not executed (and therefore not claimed)

* CI on GitHub Actions or any CI service (the workflow is written; its commands were run locally).
* macOS and Windows installation and tests; any browser other than Chromium.
* Cross-platform or cross-build numerical reproduction (only one platform was available).
* Any connection to the physical cube, any measured parameter, any hardware recording or validation.
* Remote or multi-user hosting, authentication, TLS (out of scope; requirements in `backend/README.md`).
* Long-duration soak tests beyond the suites and the campaign.

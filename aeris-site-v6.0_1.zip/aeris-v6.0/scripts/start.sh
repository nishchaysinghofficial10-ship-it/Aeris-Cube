#!/usr/bin/env bash
# AERIS · start the research backend with the site on one loopback address (v6.0: the device API in local mode).
#   scripts/start.sh [--port 8750] [--data DIR] [--emulator] [--emulator-port 47100] [--workers N]
# Serves the site and the API at http://127.0.0.1:PORT/ (same origin: nothing in site/ needs editing).
# Data (database, backups, telemetry files, logs, PID files) live in DIR (default ./data, or $AERIS_DATA_DIR).
# --emulator also starts the SYNTHETIC telemetry emulator (a separate process; it is not the physical cube):
# connect to it from the Lab's Telemetry tab (HARDWARE mode) at 127.0.0.1:47100.
# Stop everything with scripts/stop.sh (clean shutdown: running jobs resume at the next start).
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PORT=8750; DATA="${AERIS_DATA_DIR:-$ROOT/data}"; EMU=0; EPORT=47100; WORKERS=""
while [ $# -gt 0 ]; do
  case "$1" in
    --port) PORT="$2"; shift 2 ;;
    --data) DATA="$2"; shift 2 ;;
    --emulator) EMU=1; shift ;;
    --emulator-port) EPORT="$2"; shift 2 ;;
    --workers) WORKERS="$2"; shift 2 ;;
    -h|--help) sed -n '2,9p' "$0"; exit 0 ;;
    *) echo "unknown option $1" >&2; exit 2 ;;
  esac
done
PY="$ROOT/backend/.venv/bin/python"
[ -x "$PY" ] || { echo "error: $PY not found; run scripts/install.sh first" >&2; exit 1; }
mkdir -p "$DATA/logs" "$DATA/telemetry" "$DATA/run"
DATA="$(cd "$DATA" && pwd)"
if [ -f "$DATA/run/backend.pid" ] && kill -0 "$(cat "$DATA/run/backend.pid")" 2>/dev/null; then
  echo "the backend is already running (pid $(cat "$DATA/run/backend.pid")); scripts/stop.sh stops it" >&2; exit 1
fi
ARGS=(-m aeris_backend.api.main --host 127.0.0.1 --port "$PORT" --db "$DATA/aeris.sqlite3" --telemetry-dir "$DATA/telemetry" --serve-site "$ROOT/site")
[ -n "$WORKERS" ] && ARGS+=(--workers "$WORKERS")
cd "$ROOT/backend"
nohup "$PY" "${ARGS[@]}" >>"$DATA/logs/backend.log" 2>&1 &
echo $! > "$DATA/run/backend.pid"
for i in $(seq 1 100); do
  if "$PY" -c "import urllib.request,sys; urllib.request.urlopen('http://127.0.0.1:$PORT/api/v1/health', timeout=1)" 2>/dev/null; then break; fi
  if ! kill -0 "$(cat "$DATA/run/backend.pid")" 2>/dev/null; then echo "error: the backend exited; see $DATA/logs/backend.log" >&2; tail -20 "$DATA/logs/backend.log" >&2; rm -f "$DATA/run/backend.pid"; exit 1; fi
  sleep 0.2
done
echo "AERIS backend + site: http://127.0.0.1:$PORT/   (pid $(cat "$DATA/run/backend.pid"); database $DATA/aeris.sqlite3; log $DATA/logs/backend.log)"
if [ "$EMU" = 1 ]; then
  nohup "$PY" -m aeris_backend.telemetry.emulator --host 127.0.0.1 --port "$EPORT" >>"$DATA/logs/emulator.log" 2>&1 &
  echo $! > "$DATA/run/emulator.pid"
  echo "SYNTHETIC telemetry emulator on 127.0.0.1:$EPORT (pid $(cat "$DATA/run/emulator.pid")) — simulated data, not the physical cube"
fi

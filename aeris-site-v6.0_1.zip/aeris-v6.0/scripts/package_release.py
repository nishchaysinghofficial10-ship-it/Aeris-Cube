#!/usr/bin/env python3
"""Build the release archive (standard library only).

    python3 scripts/package_release.py --out aeris-site-v6.0.zip [--top aeris-v6.0]

In a git checkout (v6.0): the archive holds exactly the files tracked at the checked-out commit — never build output,
virtual environments, caches, local data or untracked files — and packaging is refused when a tracked file has
uncommitted changes (the archive must equal its commit file for file; scripts/compare_archive_bundle.py checks it) or
when a tracked file looks like a credential (.pem, .key, id_rsa*, credentials*, .env, *secret*). Without git (e.g. a
tree unpacked from an archive): every file of the working tree except version-control data, virtual environments,
caches, installed-package metadata, build output (firmware/build, firmware/esp32s3/build), databases, lock and PID
files, the local data directory, credentials, archives and release-validation outputs. Test logs, evidence, study
results, benchmark results and screenshots are included. Entries are sorted and carry one fixed time stamp (the last
commit's time when git is available, else 2026-01-01), so the same tree gives the same archive. Prints the file
count, size and SHA-256, and writes <out>.sha256 next to the archive.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import os
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".idea", ".vscode"}
SKIP_TOP = {"data", "aeris-data"}                                 # local data directories (databases, logs, PID files)
SKIP_SUFFIX = (".pyc", ".pyo", ".sqlite3", ".sqlite3-wal", ".sqlite3-shm", ".db", ".db-wal", ".db-shm", ".lock", ".pid", ".pem", ".key", ".zip")
SKIP_NAMES = {".env", ".DS_Store", "Thumbs.db"}


def skipped(rel: Path) -> bool:
    parts = rel.parts
    if parts[0] in SKIP_TOP or any(p in SKIP_DIRS or p.endswith(".egg-info") for p in parts[:-1]):
        return True
    name = parts[-1]
    if name in SKIP_NAMES or name.endswith(SKIP_SUFFIX) or name.startswith("id_rsa") or "secret" in name.lower() or name.lower().startswith("credentials"):
        return True
    if len(parts) == 1 and name.startswith("release-validation") and name.endswith(".json"):
        return True
    if parts[:2] == ("build", "tmp"):
        return True
    return False


FW_BUILD = {("firmware", "build"), ("firmware", "esp32s3", "build")}
SECRET_LIKE = (".pem", ".key")


def secret_like(rel: Path) -> bool:
    n = rel.name.lower()
    return n.endswith(SECRET_LIKE) or n.startswith("id_rsa") or n.startswith("credentials") or n == ".env" or "secret" in n


def git_files():
    """The files tracked at the checked-out commit, or None without git. Raises SystemExit on a dirty tree."""
    try:
        top = subprocess.run(["git", "-C", str(ROOT), "rev-parse", "--show-toplevel"], capture_output=True, text=True, timeout=30)
        if top.returncode != 0 or Path(top.stdout.strip()).resolve() != ROOT.resolve():
            return None
        dirty = subprocess.run(["git", "-C", str(ROOT), "status", "--porcelain", "--untracked-files=no"], capture_output=True, text=True, timeout=60).stdout
        if dirty.strip():
            raise SystemExit("refusing: tracked files have uncommitted changes (commit them first; the archive must equal its commit):\n" + dirty[:2000])
        ls = subprocess.run(["git", "-C", str(ROOT), "ls-files", "-z"], capture_output=True, timeout=60).stdout.decode("utf-8")
    except (OSError, subprocess.SubprocessError):
        return None
    out = sorted((Path(x) for x in ls.split("\0") if x), key=lambda p: p.as_posix())
    bad = [p.as_posix() for p in out if secret_like(p)]
    if bad:
        raise SystemExit("refusing: tracked files look like credentials: " + ", ".join(bad))
    missing = [p.as_posix() for p in out if not (ROOT / p).is_file()]
    if missing:
        raise SystemExit("refusing: tracked files missing from the working tree: " + ", ".join(missing[:20]))
    return out


def files():
    g = git_files()
    if g is not None:
        return g
    out = []
    for d, dirs, names in os.walk(ROOT):
        rd = Path(d).relative_to(ROOT)
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS and not x.endswith(".egg-info") and not (rd == Path(".") and x in SKIP_TOP)
                         and (rd.parts + (x,)) not in FW_BUILD)
        for n in names:
            rel = (rd / n) if rd != Path(".") else Path(n)
            if not skipped(rel) and (ROOT / rel).is_file():
                out.append(rel)
    return sorted(out, key=lambda p: p.as_posix())


def stamp():
    try:
        t = subprocess.run(["git", "-C", str(ROOT), "log", "-1", "--format=%ct"], capture_output=True, text=True, timeout=20).stdout.strip()
        if t:
            d = _dt.datetime.fromtimestamp(int(t), _dt.timezone.utc)
            return (d.year, d.month, d.day, d.hour, d.minute, d.second)
    except (OSError, subprocess.SubprocessError, ValueError):
        pass
    return (2026, 1, 1, 0, 0, 0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--top", default="aeris-v6.0", help="top-level folder inside the archive")
    a = ap.parse_args()
    out = Path(a.out).resolve()
    fl = [f for f in files() if (ROOT / f).resolve() != out]
    when = stamp()
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in fl:
            zi = zipfile.ZipInfo(f"{a.top}/{rel.as_posix()}", date_time=when)
            zi.compress_type = zipfile.ZIP_DEFLATED
            mode = 0o755 if rel.suffix == ".sh" or os.access(ROOT / rel, os.X_OK) and rel.parts[0] == "scripts" else 0o644
            zi.external_attr = (0o100000 | mode) << 16
            z.writestr(zi, (ROOT / rel).read_bytes())
    h = hashlib.sha256(out.read_bytes()).hexdigest()
    Path(str(out) + ".sha256").write_text(f"{h}  {out.name}\n")
    print(f"{len(fl)} files, {out.stat().st_size} bytes → {out}\nSHA-256 {h}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Drift checks: every generated or built file in the repository still matches what its generator or build produces
from the current sources. Nothing is written in the repository (each generator runs in its --check mode; rebuilds go to
a temporary directory).

    python3 scripts/check_drift.py [--node NODE] [--clang CLANG]

Run it with the backend's Python (backend/.venv): several generators import the backend package. scripts/run_tests.py
runs it as the suite `drift`. Each check prints one line, PASS / FAIL / NOT RUN with the reason, and the last line is
"P / T drift checks passed (K not run)" (T = checks executed). Exit code 0 when every check ran and passed, 1 when one
failed, 2 when nothing failed but a check could not run (a missing tool).

Checks:
  index.html            build/build_index.py --check (site/index.html from build/templates)
  JSON Schemas          node build/build_schemas.js --check (site/schemas from the platform modules)
  kit documents         hardware/tools/make_kit.py --check (site and backend kit documents, the site's BOM copy,
                        hardware/BUILD_GUIDE.md)
  site data             python -m aeris_backend.tools.make_site_data --check (reference profile, recipes, approved
                        configurations, plant models, data/aeris-data.js, the base64 copy of the WebAssembly device)
  sizing block          hardware/tools/sizing.py --check-doc hardware/SIZING.md
  firmware fixtures     firmware/tools/make_fixtures.py --check (the firmware tests' configurations from the backend)
  calibration parity    site/tests/fixtures/calibration_parity.py --check (browser calibration cases from the backend)
  firmware release      firmware/tools/make_release.py --verify (manifest signature, trust list, every part's SHA-256)
  release sources       the manifest's firmware_sources_sha256 equals firmware/tools/source_hash.py esp32s3 now (the
                        signed images were built from the firmware sources in this tree)
  WebAssembly sources   aeris-device.build.json's sources_sha256 equals source_hash.py wasm now
  WebAssembly rebuild   firmware/tools/build_wasm.sh into a temporary file is byte-identical to the committed module —
                        only with the compiler recorded in aeris-device.build.json (another compiler: NOT RUN)
  vendored files        the SHA-256 of every file listed in site/vendor/VENDORED.md
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable
RELEASE = ROOT / "site" / "firmware" / "releases" / "0.1.0"
WASM = ROOT / "site" / "firmware" / "synthetic" / "aeris-device.wasm"
WASM_INFO = ROOT / "site" / "firmware" / "synthetic" / "aeris-device.build.json"


def run(cmd, cwd=ROOT, env=None, timeout=600):
    try:
        r = subprocess.run([str(c) for c in cmd], cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return None, f"timed out after {timeout} s"
    except OSError as e:
        return None, f"could not be started: {e}"
    return r.returncode, (r.stdout + r.stderr).strip()


def tail(text, n=6):
    lines = [ln for ln in (text or "").splitlines() if ln.strip()]
    return " | ".join(lines[-n:])[:900]


def tool_check(cmd, ok_codes=(0,), cwd=ROOT):
    code, out = run(cmd, cwd=cwd)
    if code is None:
        return "FAIL", out
    if code in ok_codes:
        return "PASS", tail(out, 2)
    differs = [ln for ln in out.splitlines() if "DIFFER" in ln or "differs" in ln]
    return "FAIL", ("; ".join(differs)[:900] if differs else tail(out)) + f" (exit code {code})"


def source_hash(target):
    sys.path.insert(0, str(ROOT / "firmware" / "tools"))
    import source_hash as sh   # noqa: E402
    return sh.sources_sha256(target, str(ROOT))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--node", default=None, help="Node.js for the schema check (default: node on PATH)")
    ap.add_argument("--clang", default=os.environ.get("CLANG"), help="clang for the WebAssembly rebuild (default: $CLANG or clang-18 on PATH)")
    a = ap.parse_args(argv)
    results = []

    def record(name, status, detail=""):
        results.append((name, status, detail))
        print(f"{status:8s} {name}" + (f" — {detail}" if detail else ""), flush=True)

    # 1–2. pages and schemas
    record("index.html is generated from build/templates", *tool_check([PY, "build/build_index.py", "--check"]))
    if a.node:
        node = a.node if (os.path.isfile(a.node) or shutil.which(a.node)) else None
        why = f"--node {a.node}: not found"
    else:
        node, why = shutil.which("node"), "Node.js not found on PATH"
    if node:
        record("site/schemas are generated from the platform modules", *tool_check([node, "build/build_schemas.js", "--check"]))
    else:
        record("site/schemas are generated from the platform modules", "NOT RUN", why)
    # 3–7. generated data and documents
    record("kit documents, BOM copy and BUILD_GUIDE.md are generated from the BOM", *tool_check([PY, "hardware/tools/make_kit.py", "--check"]))
    record("site data (profiles, recipes, configurations, plant models, aeris-data.js, wasm.js) is generated from the backend",
           *tool_check([PY, "-m", "aeris_backend.tools.make_site_data", "--check"], cwd=ROOT / "backend"))
    record("hardware/SIZING.md generated block equals the sizing calculation", *tool_check([PY, "hardware/tools/sizing.py", "--check-doc", "hardware/SIZING.md"]))
    record("firmware test fixtures are generated from the backend", *tool_check([PY, "firmware/tools/make_fixtures.py", "--check"]))
    record("browser calibration parity cases are generated from the backend", *tool_check([PY, "site/tests/fixtures/calibration_parity.py", "--check"]))
    # 8–9. the signed firmware release
    st, detail = tool_check([PY, "firmware/tools/make_release.py", "--verify", str(RELEASE)])
    if st == "PASS":
        try:
            v = json.loads(run([PY, "firmware/tools/make_release.py", "--verify", str(RELEASE)])[1])
            detail = f"signature valid, key trust: {v['trust']}, {len(v['parts'])} parts match"
        except (ValueError, KeyError, TypeError):
            pass
    record("firmware release manifest: signature, trust list and part hashes", st, detail)
    try:
        m = json.loads((RELEASE / "manifest.json").read_text(encoding="ascii"))
        rec = (m.get("source") or {}).get("firmware_sources_sha256")
        cur = source_hash("esp32s3")
        if not rec:
            record("signed release images were built from the current firmware sources", "FAIL", "the manifest records no firmware_sources_sha256")
        elif rec != cur:
            record("signed release images were built from the current firmware sources", "FAIL",
                   f"manifest {rec[:12]}, sources now {cur[:12]}: rebuild (firmware/tools/build_esp32s3.sh) and sign again (make_release.py)")
        else:
            record("signed release images were built from the current firmware sources", "PASS", f"firmware_sources_sha256 {cur[:12]} (build {m.get('build')})")
    except (OSError, ValueError) as e:
        record("signed release images were built from the current firmware sources", "FAIL", f"{e.__class__.__name__}: {e}")
    # 10–11. the WebAssembly synthetic device
    try:
        info = json.loads(WASM_INFO.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        info = None
        record("WebAssembly device was built from the current sources", "FAIL", f"{WASM_INFO.name}: {e.__class__.__name__}: {e}")
        record("WebAssembly device rebuilds byte-identical", "FAIL", f"{WASM_INFO.name} unreadable")
    if info is not None:
        have = hashlib.sha256(WASM.read_bytes()).hexdigest()
        cur = source_hash("wasm")
        if info.get("sha256") != have:
            record("WebAssembly device was built from the current sources", "FAIL", f"{WASM.name} sha256 {have[:12]} is not the recorded build {str(info.get('sha256'))[:12]}")
        elif info.get("sources_sha256") != cur:
            record("WebAssembly device was built from the current sources", "FAIL",
                   f"recorded sources {str(info.get('sources_sha256'))[:12]}, now {cur[:12]}: run firmware/tools/build_wasm.sh and make_site_data")
        else:
            record("WebAssembly device was built from the current sources", "PASS", f"sources {cur[:12]}, module {have[:12]}")
        clang = a.clang or "clang-18"
        cpath = shutil.which(clang)
        version = None
        if cpath:
            code, out = run([cpath, "--version"])
            version = out.splitlines()[0].strip() if code == 0 and out else None
        if not cpath:
            record("WebAssembly device rebuilds byte-identical", "NOT RUN", f"{clang} not found (recorded compiler: {info.get('compiler')})")
        elif version != info.get("compiler"):
            record("WebAssembly device rebuilds byte-identical", "NOT RUN", f"{clang} is '{version}', the module was built with '{info.get('compiler')}': a byte comparison needs the same compiler")
        else:
            with tempfile.TemporaryDirectory(prefix="aeris-wasm-") as tmp:
                out_wasm = Path(tmp) / "aeris-device.wasm"
                code, out = run(["bash", "firmware/tools/build_wasm.sh", str(out_wasm)], env=dict(os.environ, CLANG=cpath))
                if code != 0:
                    record("WebAssembly device rebuilds byte-identical", "FAIL", f"build failed: {tail(out)}")
                else:
                    new = hashlib.sha256(out_wasm.read_bytes()).hexdigest()
                    record("WebAssembly device rebuilds byte-identical", "PASS" if new == have else "FAIL",
                           f"rebuilt {new[:12]}, committed {have[:12]} ({version})")
    # 12. vendored third-party files
    rows = re.findall(r"^\|\s*([\w.\-]+\.js)\s*\|.*\|\s*([0-9a-f]{64})\s*\|\s*$", (ROOT / "site" / "vendor" / "VENDORED.md").read_text(encoding="utf-8"), re.M)
    bad = [f for f, h in rows if not (ROOT / "site" / "vendor" / f).is_file() or hashlib.sha256((ROOT / "site" / "vendor" / f).read_bytes()).hexdigest() != h]
    if not rows:
        record("vendored files match site/vendor/VENDORED.md", "FAIL", "no file rows found in VENDORED.md")
    else:
        record("vendored files match site/vendor/VENDORED.md", "FAIL" if bad else "PASS", ("differs: " + ", ".join(bad)) if bad else f"{len(rows)} files")

    passed = sum(1 for _, s, _ in results if s == "PASS")
    failed = sum(1 for _, s, _ in results if s == "FAIL")
    notrun = sum(1 for _, s, _ in results if s == "NOT RUN")
    executed = passed + failed
    print(f"{passed} / {executed} drift checks passed" + (f" ({notrun} not run)" if notrun else ""))
    return 1 if failed else 2 if notrun else 0


if __name__ == "__main__":
    sys.exit(main())

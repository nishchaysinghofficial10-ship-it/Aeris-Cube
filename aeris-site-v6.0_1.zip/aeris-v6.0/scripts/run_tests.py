#!/usr/bin/env python3
"""Run the AERIS test suites and write logs with exact counts.

    python3 scripts/run_tests.py [--out test-logs] [--only SUITES] [--skip SUITES]
                                 [--backend-python P] [--browser-python P] [--node N]
                                 [--qemu QEMU] [--qemu-build DIR] [--esptool-python P]

Suites (each is run for real; nothing is mocked here):
  drift          scripts/check_drift.py: every generated or built file matches its generator or build (v6.0)
                                                                                                    — the backend Python
  backend        pytest, backend/tests (numerical, engine, API, persistence, recovery, telemetry, devices)
                                                                                                    — the backend Python
  firmware:host  make -C firmware test: the firmware core and the synthetic device's models (C, host build; v6.0)
                                                                                                    — make and a C compiler
  firmware:qemu  firmware/tests/qemu_link_test.py: the ESP32-S3 test image in Espressif's QEMU (an EMULATED board; v6.0)
                 — QEMU (--qemu, $AERIS_QEMU or qemu-system-xtensa on PATH), the qemutest build directory (--qemu-build,
                 $AERIS_QEMU_BUILD, default firmware/esp32s3/build/qemutest; built by firmware/tools/build_esp32s3.sh) and
                 a Python with esptool (--esptool-python, $AERIS_IDF_PYTHON, default the backend Python if it has esptool)
  js:<name>      node site/tests/<name>.test.js (schemas, numerics, platform, runs, service, ui, v4, v5, v51, …, connect)
  live           node site/tests/live_backend.test.js: the site's real adapters against a started backend
  browser:<name> site/tests/browser_*.py (Playwright + Chromium)                                     — the browser Python
SUITES is a comma-separated list of suite names or of the groups drift, backend, firmware, js, live, browser. Suites are
discovered from the files present (an older package runs its own suites). No suite needs or touches hardware.

Interpreters (v5.1, review finding F3). An interpreter chosen explicitly — --backend-python or $AERIS_PYTHON,
--browser-python or $PLAYWRIGHT_PYTHON, --node — is resolved ONCE, before any suite runs in another working
directory: a path (anything with a directory separator, or starting with . or ~) is made absolute against the
directory the runner was started from, keeping symlinks (a virtual environment's python is a link to its base
interpreter; resolving the link would leave the environment); a bare name (python3) is looked up on PATH. An explicit
interpreter is never replaced by another one: if it does not exist, cannot be started or — for the browser suites —
has no Playwright, the suites that need it are NOT RUN with that reason. Without an explicit choice the defaults are
searched (backend/.venv, then the interpreter running this script) and the choice is recorded in the summary.

Every suite in scope ends in one status (v5.2, review finding G3 of v5.1: test CASES count, not only suites):
  passed                  it ran, exited 0, and every test case in it executed and passed (nothing skipped or not run)
  passed with exclusions  as passed, except test cases skipped on this platform that the declared platform-exclusion
                          policy (scripts/platform_exclusions.json) names for this platform — each with its reason and,
                          where it has one, a portable counterpart that passed in the same run
  incomplete              it ran with no failure, but test cases were skipped (outside that policy) or not run
  failed                  it ran and reported a failure, exited non-zero, timed out or reported no counts
  not run                 it could not run: a missing tool or interpreter, a process that could not be started, or a
                          backend the suite could not start (the suite itself reports NOT RUN)
  skipped                 excluded with --skip
Suites outside --only are listed as not selected. Skipped test cases are listed by name with their reasons (from the
pytest JUnit report) in the summary, the Markdown and the console; a skipped case is never counted as passed.

The summary separates what was EXECUTED from what PASSED:
  complete               every test case of every selected suite was executed (no suite or case skipped / not run)
  all_passed             complete, and everything passed
  all_applicable_passed  nothing failed or was left unexecuted except declared platform exclusions
  all_tests_executed     complete, and every suite was selected (the whole product test set ran)
  full_validation        all_passed and all_tests_executed — the only unqualified claim; false whenever anything was
                         skipped, excluded, not run or not selected
Exit codes (the same in summary.json, SUMMARY.md, the console, CI and the release validator):
  0   every selected suite ran and every test case in it executed and passed (with every suite selected: a full
      validation; with --only: "selected suites only", never a full validation)
  1   a suite or test case failed, timed out or reported no counts
  2   INCOMPLETE: nothing failed, but a suite was not run or skipped, or test cases were skipped / not run outside the
      platform-exclusion policy
  3   PASSED WITH DECLARED PLATFORM EXCLUSIONS: nothing failed and everything else executed; the only cases not
      executed are named by the policy for this platform (listed in the verdict). Not a full validation
  64  usage error (e.g. an unknown suite name)
Writes <out>/<suite>.log, <out>/summary.json (machine-readable) and <out>/SUMMARY.md, which starts with the verdict.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# Suites are discovered from the files present, so the script also runs an older package's own suites.
JS = sorted(p.name[:-len(".test.js")] for p in (ROOT / "site" / "tests").glob("*.test.js") if p.name != "live_backend.test.js")
BROWSER = sorted(p.stem for p in (ROOT / "site" / "tests").glob("browser_*.py"))
DRIFT = ["drift"] if (ROOT / "scripts" / "check_drift.py").exists() else []
FIRMWARE = (["firmware:host"] if (ROOT / "firmware" / "Makefile").exists() else []) + \
           (["firmware:qemu"] if (ROOT / "firmware" / "tests" / "qemu_link_test.py").exists() else [])
ALL = DRIFT + ["backend"] + FIRMWARE + [f"js:{n}" for n in JS] + ["live"] + [f"browser:{n}" for n in BROWSER]
GROUPS = {"backend": ["backend"], "js": [f"js:{n}" for n in JS], "live": ["live"], "browser": [f"browser:{n}" for n in BROWSER]}
if DRIFT:
    GROUPS["drift"] = DRIFT
if FIRMWARE:
    GROUPS["firmware"] = FIRMWARE
QEMU_BUILD = ROOT / "firmware" / "esp32s3" / "build" / "qemutest"
USAGE_ERROR = 64
EXIT_CODES = {"0": "every selected suite ran and every test case in it executed and passed", "1": "a suite or test case failed, timed out or reported no counts",
              "2": "incomplete: a suite was not run or skipped, or test cases were skipped / not run outside the platform-exclusion policy",
              "3": "passed with declared platform exclusions (named in the verdict); not a full validation", "64": "usage error"}
POLICY = ROOT / "scripts" / "platform_exclusions.json"
PLATFORM = sys.platform


def expand(spec: str) -> list:
    """'backend,js:v5,browser' → suite names, in the order of ALL. Unknown names are an error, never ignored."""
    want = []
    for s in (x.strip() for x in (spec or "").split(",")):
        if not s:
            continue
        if s in GROUPS:
            want += GROUPS[s]
        elif s in ALL:
            want.append(s)
        else:
            raise ValueError(f"unknown suite '{s}' (suites: {', '.join(ALL)}; groups: {', '.join(GROUPS)})")
    return [s for s in ALL if s in set(want)]


def is_path(v: str) -> bool:
    return os.sep in v or bool(os.altsep and os.altsep in v) or v.startswith(".") or v.startswith("~")


def resolve_program(value, start_dir: str):
    """(absolute path, None) or (None, reason). A path is made absolute against start_dir (the runner's working
    directory when it started) WITHOUT resolving symlinks; a bare name is looked up on PATH."""
    raw = str(value)
    v = os.path.expanduser(raw)
    if is_path(v):
        p = os.path.abspath(os.path.join(start_dir, v))
        if not os.path.lexists(p):
            return None, f"'{raw}' → {p}: no such file"
        if not os.path.exists(p):
            return None, f"'{raw}' → {p}: a broken link"
        if os.path.isdir(p) or not os.access(p, os.X_OK):
            return None, f"'{raw}' → {p}: not an executable file"
        return p, None
    w = shutil.which(v)
    if not w:
        return None, f"'{raw}': not found on PATH"
    return os.path.abspath(w), None


def probe(cmd, timeout=120):
    """Start a program once to see that it runs: (True, stdout) or (False, reason)."""
    try:
        r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return False, f"did not answer within {timeout} s"
    except (OSError, ValueError) as e:
        return False, f"could not be started: {e.__class__.__name__}: {e}"
    if r.returncode != 0:
        tail = (r.stderr or r.stdout or "").strip().splitlines()
        return False, (tail[-1] if tail else f"exit code {r.returncode}")[:300]
    return True, r.stdout.strip()


def choose_backend_python(given, start):
    explicit = [(given, "--backend-python"), (os.environ.get("AERIS_PYTHON"), "$AERIS_PYTHON")]
    for raw, source in explicit:
        if raw:
            p, why = resolve_program(raw, start)
            if p:
                ok, out = probe([p, "-c", "import sys; print(sys.version.split()[0])"])
                if not ok:
                    p, why = None, f"'{raw}' → {p}: {out}"
            return {"path": p, "source": source, "given": raw, "problem": why}
    for c, source in ((ROOT / "backend" / ".venv" / "bin" / "python", "default: backend/.venv"), (ROOT / "backend" / ".venv" / "Scripts" / "python.exe", "default: backend/.venv")):
        if c.exists():
            return {"path": str(c), "source": source, "given": None, "problem": None}
    return {"path": sys.executable, "source": "default: the interpreter running this script", "given": None, "problem": None}


def choose_browser_python(given, start, backend_py):
    for raw, source in ((given, "--browser-python"), (os.environ.get("PLAYWRIGHT_PYTHON"), "$PLAYWRIGHT_PYTHON")):
        if raw:
            p, why = resolve_program(raw, start)
            if p:
                ok, out = probe([p, "-c", "import playwright"])
                if not ok:
                    why = f"'{raw}' → {p}: Playwright is not importable ({out}); install it for this interpreter (pip install playwright; python -m playwright install chromium)"
                    p = None
            return {"path": p, "source": source, "given": raw, "problem": why}
    tried = []
    for c, source in ((backend_py, "default: the backend Python"), (sys.executable, "default: the interpreter running this script"), (shutil.which("python3"), "default: python3 on PATH")):
        if not c or c in tried:
            continue
        tried.append(c)
        if probe([c, "-c", "import playwright"])[0]:
            return {"path": c, "source": source, "given": None, "problem": None}
    return {"path": None, "source": "default", "given": None,
            "problem": "Playwright is not installed for any Python found (" + ", ".join(tried) + "): pip install playwright; python -m playwright install chromium"}


def choose_node(given, start):
    if given:
        p, why = resolve_program(given, start)
        if p:
            ok, out = probe([p, "-v"])
            if not ok:
                p, why = None, f"'{given}' → {p}: {out}"
        return {"path": p, "source": "--node", "given": given, "problem": why}
    w = shutil.which("node")
    return {"path": os.path.abspath(w) if w else None, "source": "default: node on PATH", "given": None, "problem": None if w else "Node.js not found on PATH"}


def choose_tool(given, env_var, default_names, start, what, version_arg="--version"):
    """An external program for a suite (make, cc, QEMU): explicit (argument, then environment variable) or the first
    default name on PATH. Never replaced by another one when given explicitly."""
    for raw, source in ((given, f"--{what}"), (os.environ.get(env_var) if env_var else None, f"${env_var}")):
        if raw:
            p, why = resolve_program(raw, start)
            if p:
                ok, out = probe([p, version_arg])
                if not ok:
                    p, why = None, f"'{raw}' → {p}: {out}"
            return {"path": p, "source": source, "given": raw, "problem": why}
    for n in default_names:
        w = shutil.which(n)
        if w:
            return {"path": os.path.abspath(w), "source": f"default: {n} on PATH", "given": None, "problem": None}
    return {"path": None, "source": "default", "given": None, "problem": f"{' / '.join(default_names)} not found on PATH"}


def choose_esptool_python(given, start, backend_py):
    for raw, source in ((given, "--esptool-python"), (os.environ.get("AERIS_IDF_PYTHON"), "$AERIS_IDF_PYTHON")):
        if raw:
            p, why = resolve_program(raw, start)
            if p:
                ok, out = probe([p, "-c", "import esptool"])
                if not ok:
                    p, why = None, f"'{raw}' → {p}: esptool is not importable ({out})"
            return {"path": p, "source": source, "given": raw, "problem": why}
    if backend_py and probe([backend_py, "-c", "import esptool"])[0]:
        return {"path": backend_py, "source": "default: the backend Python", "given": None, "problem": None}
    return {"path": None, "source": "default", "given": None,
            "problem": "no Python with esptool: pass --esptool-python (the ESP-IDF environment's Python) or set $AERIS_IDF_PYTHON"}


def choose_qemu_build(given, start):
    raw = given or os.environ.get("AERIS_QEMU_BUILD")
    source = "--qemu-build" if given else "$AERIS_QEMU_BUILD" if raw else "default"
    p = os.path.abspath(os.path.join(start, os.path.expanduser(raw))) if raw else str(QEMU_BUILD)
    if not os.path.isfile(os.path.join(p, "flash_args")):
        return {"path": None, "source": source, "given": raw,
                "problem": f"no ESP32-S3 qemutest build at {p} (build it with firmware/tools/build_esp32s3.sh qemutest)"}
    return {"path": p, "source": source, "given": raw, "problem": None}


def first_line(cmd):
    try:
        r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, timeout=60)
        return ((r.stdout or r.stderr).strip().splitlines() or [None])[0]
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return None


def run(cmd, log, cwd, env=None, timeout=3600):
    """Run one suite with its output in `log`. Returns (exit code or None, seconds, log text, launch problem or None)."""
    t0 = time.time()
    with open(log, "w", encoding="utf-8") as fh:
        fh.write("$ " + " ".join(shlex.quote(str(c)) for c in cmd) + f"\n(working directory: {cwd})\n\n")
        fh.flush()
        launch = None
        try:
            p = subprocess.run([str(c) for c in cmd], cwd=cwd, env=env, stdout=fh, stderr=subprocess.STDOUT, timeout=timeout)
            code = p.returncode
        except subprocess.TimeoutExpired:
            fh.write(f"\nTIMEOUT after {timeout} s\n")
            code = -9
        except (OSError, ValueError) as e:
            launch = f"could not be started: {e.__class__.__name__}: {e}"
            fh.write("\nNOT RUN: " + launch + "\n")
            code = None
    return code, round(time.time() - t0, 1), Path(log).read_text(encoding="utf-8", errors="replace"), launch


def counts_js(text):
    m = re.findall(r"^(\d+) / (\d+) [^\n]*?(passed|run)", text, re.M)
    if not m:
        return None
    n, tot, word = m[-1]
    n, tot = int(n), int(tot)
    nr = re.search(r"\((\d+) not run\)", text)
    if word == "run" and nr:
        return {"passed": 0, "failed": 0, "skipped": 0, "not_run": int(nr.group(1)), "total": tot}
    if nr:     # v6.0: "P / T … checks passed (K not run)" — T checks executed, K more could not run (e.g. no backend)
        return {"passed": n, "failed": tot - n, "skipped": 0, "not_run": int(nr.group(1)), "total": tot + int(nr.group(1))}
    return {"passed": n, "failed": tot - n, "skipped": 0, "not_run": 0, "total": tot}


def counts_fw(text):
    """'# firmware core tests: N passed, M failed' (firmware/tests/test_core.c) or '# qemu target tests: N passed, M
    failed' (firmware/tests/qemu_link_test.py) — the last one printed."""
    m = re.findall(r"^# (?:firmware core|qemu target) tests: (\d+) passed, (\d+) failed", text, re.M)
    if not m:
        return None
    p, f = (int(x) for x in m[-1])
    return {"passed": p, "failed": f, "skipped": 0, "not_run": 0, "total": p + f}


def junit_cases(path) -> list:
    """Every test case of a pytest JUnit report: [{"test": "<classname>::<name>", "outcome": passed | failed | skipped,
    "message"}] (a case with a failure or an error is failed; with a <skipped> element, skipped)."""
    out = []
    for tc in ET.parse(path).getroot().iter("testcase"):
        tid = f"{tc.get('classname', '')}::{tc.get('name', '')}"
        bad = tc.find("failure") if tc.find("failure") is not None else tc.find("error")
        sk = tc.find("skipped")
        if bad is not None:
            out.append({"test": tid, "outcome": "failed", "message": (bad.get("message") or "")[:300]})
        elif sk is not None:
            out.append({"test": tid, "outcome": "skipped", "message": (sk.get("message") or "")[:300]})
        else:
            out.append({"test": tid, "outcome": "passed", "message": None})
    return out


def load_policy(path) -> dict:
    """The declared platform-exclusion policy. A missing or malformed file excludes nothing (every skip stays a skip)."""
    pol = {"file": str(path) if path else None, "platform": PLATFORM, "sha256": None, "exclusions": [], "problem": None}
    if not path:
        return pol
    try:
        raw = Path(path).read_bytes()
        d = json.loads(raw)
        ex = d.get("exclusions") if isinstance(d, dict) and d.get("schema") == "aeris-platform-exclusions/1" else None
        if not isinstance(ex, list) or not all(isinstance(e, dict) and isinstance(e.get("suite"), str) and isinstance(e.get("test"), str)
                                               and isinstance(e.get("platforms"), list) and isinstance(e.get("why"), str) and e["why"] for e in ex):
            raise ValueError("expected {schema: aeris-platform-exclusions/1, exclusions: [{suite, test, platforms, why, covered_by?}]}")
        pol.update(sha256=__import__("hashlib").sha256(raw).hexdigest(), exclusions=ex)
    except (OSError, ValueError) as e:
        pol["problem"] = f"{path}: {e.__class__.__name__}: {e} — no platform exclusions apply"
    return pol


def classify_skips(suite: str, cases: list, policy: dict) -> list:
    """Each skipped case with its reason and whether the declared policy excludes it on this platform."""
    passed = {c["test"] for c in cases if c["outcome"] == "passed"}
    out = []
    for c in cases:
        if c["outcome"] != "skipped":
            continue
        rec = {"suite": suite, "test": c["test"], "reason": c["message"], "excluded_by_policy": False, "policy": None}
        rule = next((e for e in policy["exclusions"] if e["suite"] == suite and e["test"] == c["test"]), None)
        if rule is not None:
            if PLATFORM not in rule["platforms"]:
                rec["policy"] = f"the policy excludes it on {', '.join(rule['platforms'])}, not on {PLATFORM}"
            elif rule.get("covered_by") and rule["covered_by"] not in passed:
                rec["policy"] = f"excluded only when its portable counterpart {rule['covered_by']} passes in the same run; it did not"
            else:
                rec.update(excluded_by_policy=True, policy=rule["why"], covered_by=rule.get("covered_by"))
        out.append(rec)
    return out


def status_of(code, counts, launch, text, skips=None):
    if launch:
        return "not run", launch
    if code == 2 and ("NOT RUN" in text or (counts and counts.get("not_run"))) and not (counts and counts.get("passed")):
        line = next((ln for ln in text.splitlines() if "NOT RUN" in ln), "the suite reported NOT RUN")
        return "not run", line.strip()[:300]
    if code == -9:
        return "failed", "timed out"
    if not counts:
        return "failed", f"exit code {code}; no counts reported"
    if not counts.get("total"):
        return "failed", f"exit code {code}; the suite counted no tests"
    if counts["failed"]:
        return "failed", None if code else f"{counts['failed']} test(s) failed (exit code 0)"
    if counts.get("not_run"):
        return ("not run", f"{counts['not_run']} test(s) not run (exit code {code})") if not counts["passed"] else \
               ("incomplete", f"{counts['not_run']} test(s) not run (exit code {code})")
    if code != 0:
        return "failed", f"exit code {code}"
    sk = counts.get("skipped", 0)
    if not sk:
        return "passed", None
    if counts["passed"] == 0:
        return "incomplete", f"all {sk} test(s) skipped: nothing was executed"
    skips = skips or []
    excused = [x for x in skips if x["excluded_by_policy"]]
    if len(skips) == sk and len(excused) == sk:
        return "passed with exclusions", f"{sk} test(s) excluded on {PLATFORM} by the platform-exclusion policy: " + "; ".join(f"{x['test']} ({x['policy']})" for x in excused)
    return "incomplete", f"{sk} test(s) skipped" + (f", {sk - len(excused)} of them not covered by the platform-exclusion policy" if excused else "") + \
        ": " + "; ".join(f"{x['test']} ({x['reason']})" for x in skips if not x["excluded_by_policy"])[:600]


def main(argv=None):
    start = os.getcwd()          # every path given to the runner is relative to where it was started
    ap = argparse.ArgumentParser(description="Run the AERIS test suites (see the module docstring).")
    ap.add_argument("--out", default=str(ROOT / "test-logs"))
    ap.add_argument("--only", default="", help="comma-separated suites or groups to run (default: all)")
    ap.add_argument("--skip", default="", help="comma-separated suites or groups to exclude (the run is then INCOMPLETE)")
    ap.add_argument("--backend-python")
    ap.add_argument("--browser-python")
    ap.add_argument("--node")
    ap.add_argument("--qemu", help="qemu-system-xtensa (Espressif's QEMU) for firmware:qemu (default: $AERIS_QEMU or on PATH)")
    ap.add_argument("--qemu-build", help="the ESP32-S3 qemutest build directory (default: $AERIS_QEMU_BUILD or firmware/esp32s3/build/qemutest)")
    ap.add_argument("--esptool-python", help="a Python with esptool for firmware:qemu (default: $AERIS_IDF_PYTHON or the backend Python)")
    ap.add_argument("--timeout", type=float, default=3600.0, help="seconds per suite before it is stopped and reported failed (default 3600)")
    ap.add_argument("--exclusions", default=None, help="platform-exclusion policy file (default: scripts/platform_exclusions.json; recorded in the summary)")
    a = ap.parse_args(argv)
    try:
        selected = expand(a.only) if a.only.strip() else list(ALL)
        skip = set(expand(a.skip))
    except ValueError as e:
        print("usage error: " + str(e), file=sys.stderr)
        return USAGE_ERROR
    out = Path(os.path.abspath(os.path.join(start, a.out)))       # absolute: suites run in other working directories
    out.mkdir(parents=True, exist_ok=True)
    policy = load_policy(os.path.abspath(os.path.join(start, a.exclusions)) if a.exclusions else POLICY)
    need = set(selected) - skip
    bpy = choose_backend_python(a.backend_python, start) if need & ({"backend", "live", "drift", "firmware:qemu"} | set(GROUPS["browser"])) else None
    node = choose_node(a.node, start) if need & (set(GROUPS["js"]) | {"live", "drift"}) else None
    brpy = choose_browser_python(a.browser_python, start, bpy and bpy["path"]) if need & set(GROUPS["browser"]) else None
    make = choose_tool(None, None, ["make"], start, "make") if "firmware:host" in need else None
    cc = choose_tool(None, "CC", ["cc", "gcc", "clang"], start, "cc") if "firmware:host" in need else None
    qemu = choose_tool(a.qemu, "AERIS_QEMU", ["qemu-system-xtensa"], start, "qemu") if "firmware:qemu" in need else None
    qbuild = choose_qemu_build(a.qemu_build, start) if "firmware:qemu" in need else None
    espy = choose_esptool_python(a.esptool_python, start, bpy and bpy["path"]) if "firmware:qemu" in need else None
    env = dict(os.environ, PYTHONUNBUFFERED="1")
    if bpy and bpy["path"]:
        env["AERIS_PYTHON"] = bpy["path"]
    if cc and cc["path"]:
        env["CC"] = cc["path"]
    suites = []

    def record(name, status, code=None, secs=0.0, counts=None, reason=None, log=None, skips=None, failures=None):
        suites.append({"suite": name, "status": status, "exit_code": code, "seconds": secs, "counts": counts, "log": log, "reason": reason,
                       "executed": (counts["total"] - counts.get("skipped", 0) - counts.get("not_run", 0)) if counts else 0,
                       "skipped_tests": skips or [], "failed_tests": failures or []})
        c = counts or {}
        print(f"{name:22s} {status:22s} passed {c.get('passed', 0):4d} failed {c.get('failed', 0):3d} skipped {c.get('skipped', 0):3d} not run {c.get('not_run', 0):3d}  ({secs} s)"
              + (f"  — {reason}" if reason else ""), flush=True)
        for x in skips or []:
            print(f"    skipped: {x['test']} — {x['reason']}" + ("  [excluded on this platform by the declared policy]" if x["excluded_by_policy"]
                                                                  else f"  [NOT covered by the platform-exclusion policy{': ' + x['policy'] if x['policy'] else ''}]"), flush=True)
        for x in failures or []:
            print(f"    failed:  {x['test']} — {x['message']}", flush=True)

    def suite(name, cmd, cwd, needs):
        log = f"{name.replace(':', '-')}.log"
        if name in skip:
            return record(name, "skipped", reason="excluded with --skip")
        for what, choice in needs:
            if not choice or not choice["path"]:
                return record(name, "not run", reason=f"{what}: " + ((choice or {}).get("problem") or "not available"))
        code, secs, text, launch = run(cmd(), out / log, cwd, env, timeout=a.timeout)
        counts, skips, failures = None, [], []
        if name == "backend":
            junit = out / "pytest-junit.xml"
            if junit.exists() and junit.stat().st_mtime >= time.time() - secs - 5:
                ts = ET.parse(junit).getroot()
                ts = ts if ts.tag == "testsuite" else ts.find("testsuite")
                tot, fl, er, sk = (int(ts.get(k, 0)) for k in ("tests", "failures", "errors", "skipped"))
                counts = {"passed": tot - fl - er - sk, "failed": fl + er, "skipped": sk, "not_run": 0, "total": tot}
                cases = junit_cases(junit)
                skips = classify_skips(name, cases, policy)
                failures = [{"suite": name, "test": c["test"], "message": c["message"]} for c in cases if c["outcome"] == "failed"]
        elif name.startswith("firmware:"):
            counts = counts_fw(text)
        else:
            counts = counts_js(text)
        status, reason = status_of(code, counts, launch, text, skips)
        record(name, status, code, secs, counts, reason, log, skips, failures)

    for name in selected:
        if name == "drift":
            suite(name, lambda: [bpy["path"], "scripts/check_drift.py"] + (["--node", node["path"]] if node and node["path"] else []), ROOT, [("backend Python", bpy)])
        elif name == "firmware:host":
            suite(name, lambda: [make["path"], "-C", "firmware", "test"], ROOT, [("make", make), ("C compiler", cc)])
        elif name == "firmware:qemu":
            suite(name, lambda: [bpy["path"], "firmware/tests/qemu_link_test.py", "--qemu", qemu["path"], "--build", qbuild["path"],
                                 "--esptool-python", espy["path"], "--log", str(out / "firmware-qemu-serial.log")], ROOT,
                  [("backend Python", bpy), ("QEMU", qemu), ("qemutest build", qbuild), ("esptool Python", espy)])
        elif name == "backend":
            junit = out / "pytest-junit.xml"
            if junit.exists() and "backend" not in skip:
                junit.unlink()
            suite(name, lambda: [bpy["path"], "-m", "pytest", "-q", "-p", "no:cacheprovider", "-rs", f"--junitxml={out / 'pytest-junit.xml'}"], ROOT / "backend", [("backend Python", bpy)])
        elif name.startswith("js:"):
            n = name[3:]
            suite(name, lambda n=n: [node["path"], f"tests/{n}.test.js"], ROOT / "site", [("Node.js", node)])
        elif name == "live":
            suite(name, lambda: [node["path"], "tests/live_backend.test.js"], ROOT / "site", [("Node.js", node), ("backend Python", bpy)])
        else:
            n = name[len("browser:"):]
            suite(name, lambda n=n: [brpy["path"], f"tests/{n}.py"], ROOT / "site", [("backend Python", bpy), ("browser Python", brpy)])

    not_selected = [s for s in ALL if s not in selected]
    total = {k: sum((s["counts"] or {}).get(k, 0) for s in suites) for k in ("passed", "failed", "skipped", "not_run")}
    by = lambda st: [s["suite"] for s in suites if s["status"] == st]               # noqa: E731
    failed, notrun, skipped, incomplete, excl = by("failed"), by("not run"), by("skipped"), by("incomplete"), by("passed with exclusions")
    skipped_tests = [x for s in suites for x in s["skipped_tests"]]
    exclusions = [x for s in suites if s["status"] == "passed with exclusions" for x in s["skipped_tests"]]      # accepted: named in the verdict
    unexcused = [x for x in skipped_tests if not x["excluded_by_policy"]]
    suites_ran = bool(suites) and not notrun and not skipped
    complete = suites_ran and not incomplete and not excl and total["skipped"] == 0 and total["not_run"] == 0
    all_passed = complete and not failed and all(s["status"] == "passed" for s in suites)
    all_applicable_passed = suites_ran and not failed and not incomplete
    all_tests_executed = complete and not not_selected
    full = all_passed and all_tests_executed
    code = 1 if failed else 2 if (notrun or skipped or incomplete) else 3 if excl else 0
    names = lambda xs: "; ".join(f"{x['suite']}::{x['test']} ({x['reason']})" for x in xs)        # noqa: E731
    if failed:
        extra = [f"{len(notrun)} not run" if notrun else "", f"{len(skipped)} skipped" if skipped else "",
                 f"{total['skipped']} test case(s) skipped" if total["skipped"] else "", f"{total['not_run']} test case(s) not run" if total["not_run"] else ""]
        verdict = f"FAILED — {len(failed)} suite(s) failed: {', '.join(failed)}" + ("; also " + ", ".join(x for x in extra if x) if any(extra) else "") + ". Not a full validation."
    elif code == 2:
        ran = len(suites) - len(notrun) - len(skipped)
        parts = []
        if notrun:
            parts.append(f"{len(notrun)} suite(s) not run ({', '.join(notrun)})")
        if skipped:
            parts.append(f"{len(skipped)} suite(s) skipped ({', '.join(skipped)})")
        if incomplete:
            parts.append(f"test cases not executed in {', '.join(incomplete)}" + (f": {len(unexcused)} skipped — {names(unexcused)}" if unexcused else "")
                         + (f"; {total['not_run']} not run" if total["not_run"] else ""))
        verdict = ("INCOMPLETE — " + "; ".join(parts) + (f". Nothing failed in the {ran} suite(s) that ran" if ran else ". No suite ran") + ". Not a full validation.")
    elif code == 3:
        verdict = (f"PASSED WITH DECLARED PLATFORM EXCLUSIONS — {len(suites)} suite(s) ran with no failures" + (" (selected suites only)" if not_selected else "")
                   + f"; {len(exclusions)} test case(s) not executed on {PLATFORM}, excluded by {Path(policy['file']).name}: "
                   + "; ".join(f"{x['suite']}::{x['test']} — {x['policy']}" + (f" (counterpart passed: {x['covered_by']})" if x.get("covered_by") else "") for x in exclusions)
                   + ". Not a full validation.")
    elif not_selected:
        verdict = f"PASSED — selected suites only ({len(suites)} of {len(ALL)}); every test case in them executed and passed; not selected: {', '.join(not_selected)}. Not a full validation."
    else:
        verdict = f"PASSED — all {len(suites)} suites ran and passed; every test case executed (full validation)"
    interp = {"backend_python": bpy, "browser_python": brpy, "node": node, "make": make, "c_compiler": cc, "qemu": qemu, "qemu_build": qbuild, "esptool_python": espy}
    tool_versions = {k: first_line([v["path"], "--version"]) for k, v in (("make", make), ("c_compiler", cc), ("qemu", qemu)) if v and v["path"]}
    summary = {"when": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"), "verdict": verdict, "exit_code": code, "exit_codes": EXIT_CODES,
               "complete": complete, "all_passed": all_passed, "all_applicable_passed": all_applicable_passed, "all_tests_executed": all_tests_executed,
               "full_validation": full, "suites_ran": suites_ran,
               "machine": {"platform": platform.platform(), "sys_platform": PLATFORM, "python_orchestrator": sys.version.split()[0]},
               "runner": {"started_in": start, "argv": list(sys.argv[1:] if argv is None else argv), "timeout_s": a.timeout},
               "platform_exclusion_policy": {k: policy[k] for k in ("file", "sha256", "platform", "problem")} | {"entries": len(policy["exclusions"])},
               "backend_python": bpy and bpy["path"], "node": (subprocess.run([node["path"], "-v"], capture_output=True, text=True).stdout.strip() if node and node["path"] else None),
               "interpreters": interp, "tool_versions": tool_versions, "selected": selected, "not_selected": not_selected,
               "suites": suites, "totals": total, "executed": sum(s["executed"] for s in suites),
               "skipped_tests": skipped_tests, "platform_exclusions": exclusions, "failed_tests": [x for s in suites for x in s["failed_tests"]],
               "suite_status_counts": {k: sum(1 for s in suites if s["status"] == k) for k in ("passed", "passed with exclusions", "incomplete", "failed", "not run", "skipped")}}
    (out / "summary.json").write_text(json.dumps(summary, indent=1))
    md = [f"# Test run — {verdict}", "",
          f"{summary['when']} · {summary['machine']['platform']} (`{PLATFORM}`) · backend Python `{summary['backend_python']}` · Node {summary['node']}", ""]
    for k, v in interp.items():
        if v:
            md.append(f"- {k.replace('_', ' ')}: `{v['path']}` ({v['source']}" + (f", given as `{v['given']}`" if v.get("given") else "") + ")" + (f" — **{v['problem']}**" if v.get("problem") else ""))
    if tool_versions:
        md.append("- tool versions: " + "; ".join(f"{k.replace('_', ' ')} `{v}`" for k, v in tool_versions.items()))
    md.append(f"- platform-exclusion policy: `{policy['file']}` ({len(policy['exclusions'])} entr{'y' if len(policy['exclusions']) == 1 else 'ies'}; sha256 {policy['sha256'] and policy['sha256'][:12]})"
              + (f" — **{policy['problem']}**" if policy["problem"] else ""))
    md += ["", "| Suite | Status | Passed | Failed | Skipped | Not run | Seconds | Log |", "|---|---|---:|---:|---:|---:|---:|---|"]
    for s in suites:
        c = s["counts"] or {}
        md.append(f"| {s['suite']} | {s['status']}{(' — ' + s['reason']) if s['reason'] else ''} | {c.get('passed', 0)} | {c.get('failed', 0)} | {c.get('skipped', 0)} | {c.get('not_run', 0)} | {s['seconds']} | {s['log'] or '—'} |")
    for n in not_selected:
        md.append(f"| {n} | not selected | — | — | — | — | — | — |")
    if skipped_tests:
        md += ["", "**Skipped test cases (not executed; never counted as passed):**", "", "| Suite | Test | Reason | Platform-exclusion policy |", "|---|---|---|---|"]
        md += [f"| {x['suite']} | `{x['test']}` | {x['reason']} | " + (f"excluded on `{PLATFORM}`: {x['policy']}" + (f"; counterpart passed: `{x['covered_by']}`" if x.get("covered_by") else "")
                                                                      if x["excluded_by_policy"] else f"not covered{': ' + x['policy'] if x['policy'] else ''}") + " |" for x in skipped_tests]
    if summary["failed_tests"]:
        md += ["", "**Failed test cases:**", ""] + [f"- {x['suite']}: `{x['test']}` — {x['message']}" for x in summary["failed_tests"]]
    md += ["", f"**Totals (tests in the suites that ran):** {total['passed']} passed, {total['failed']} failed, {total['skipped']} skipped, {total['not_run']} not run "
               f"({summary['executed']} executed).",
           f"**Suites:** {summary['suite_status_counts']['passed']} passed, {len(excl)} passed with exclusions, {len(incomplete)} incomplete, {len(failed)} failed, "
           f"{len(notrun)} not run, {len(skipped)} skipped, {len(not_selected)} not selected.",
           f"**Complete execution:** {'yes' if complete else 'no'} · **all applicable tests passed:** {'yes' if all_applicable_passed else 'no'} · "
           f"**all tests executed:** {'yes' if all_tests_executed else 'no'}.",
           f"**Full validation:** {'yes' if full else 'no'} (exit code {code}: {EXIT_CODES[str(code)]})."]
    (out / "SUMMARY.md").write_text("\n".join(md) + "\n")
    print(f"\n{verdict}\ntotals: {total}  executed {summary['executed']}  complete={complete} all_applicable_passed={all_applicable_passed} "
          f"full_validation={full}  exit code {code}  → {out / 'summary.json'}")
    return code


if __name__ == "__main__":
    sys.exit(main())

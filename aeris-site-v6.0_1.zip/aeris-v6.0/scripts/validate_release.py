#!/usr/bin/env python3
"""Validate a packaged AERIS release in a FRESH directory (standard library only; Linux/macOS shell scripts).

    python3 scripts/validate_release.py --zip aeris-site-v6.0.zip [--python python3.12] [--out release-validation.json] [--keep]
                                        [--expect-top aeris-v6.0] [--browser-python PY]

Steps (each recorded with its outcome, duration and details in the JSON result):
  archive       required files present; no caches, virtual environments, credentials or databases in the archive
  extract       unpack into a new temporary directory (nothing outside it is touched)
  install       scripts/install.sh into a new virtual environment; installed versions equal the lock file
  start         scripts/start.sh --emulator on free loopback ports; health, site and API on one origin
  experiment    an advanced run (corner, nonlinear PD, MEKF, explicit quaternion initial state, free heading)
  reproduce     the stored run is retrieved and reproduced identically
  sweep-cancel  a sweep is cancelled while running; its partial rows are retrieved and analysed; a dataset of it is
                created, finalised and exported with an intact integrity check
  restart       a running sweep survives scripts/stop.sh + scripts/start.sh: it resumes and completes without duplicates
  telemetry     the SYNTHETIC emulator streams through the backend (polling), a recording is stored as SYNTHETIC,
                exported as NDJSON with its synthetic hello, and replayed through the same path
  telemetry-provenance   (v5.1, review F1) an ARTIFICIAL declared-physical fixture (a line server in this script, not
                a device) alone is stored as declared-physical; a recording that switches from it to the emulator is
                SYNTHETIC with two segments; every hello of its NDJSON export is synthetic; the export replayed and
                recorded again stays SYNTHETIC and is marked derived; a comparison of it is not evidence; a dataset
                of both is synthetic-telemetry
  telemetry-restart      (v5.1, review F2) scripts/stop.sh + start.sh on the same port and data: the backend reports a
                new stream id, and a client's old cursor with its old stream id is answered from the new stream's start
  test-runner   (v5.1, review F3) run_tests.py from the package root with the CI's RELATIVE --browser-python in the
                fresh install (no Playwright there): the browser suites are reported NOT RUN with the reason, a summary
                is written, nothing crashes and no other interpreter is substituted; a selection is never reported as
                a full validation
  telemetry-units        (v5.2, review G1) a SYNTHETIC upload in ms, deg, deg/s, omega_* rad/s, mN·m and g: its NDJSON
                export carries the physical values in the stream's wire units (s, rad, rad/s, rpm, N·m, m/s²) and the
                conversions in the lineage; the export replayed by the running backend and recorded again keeps every
                physical value and time interval (rows matched by seq); an incomplete vector is HTTP 422
                export_not_possible (with omit_unmapped=true: exported, the omission recorded); the stored original
                and its JSON export are unchanged
  telemetry-generations  (v5.2, review G2) with the fresh install's Python: 20 export → FileReplaySource → re-record
                generations of a two-segment mixed recording (an artificial declared-physical fixture, then the
                emulator identity) — every hello valid, every lineage within its bound, every frame replayed, every
                generation synthetic; the 20th copy imported through the API stays synthetic, exports as generation
                21 and is not validation evidence
  test-runner   … (v5.2, review G3) a fixture with one passing and one SKIPPED pytest case: exit code 2, INCOMPLETE,
                the skipped case named, never a full validation; the same under a policy that excludes it on this
                platform with a passing counterpart: exit code 3, PASSED WITH DECLARED PLATFORM EXCLUSIONS, still
                not a full validation; the package's own exclusion policy names existing tests only
  browser-cancel         (v5.2, review G4) site/tests/browser_v52.py and site/tests/browser_v3.py of the EXTRACTED
                package with --browser-python (an interpreter with Playwright; the fresh install has none): every
                check passes. Without --browser-python the step is recorded as NOT RUN, and the validation is
                INCOMPLETE (exit code 2), never passed
  device-journey         (v6.0) the device stack of the extracted package against its running backend (local mode,
                loopback): the SYNTHETIC device process is built from the package's firmware sources (make), paired
                through the companion only after its local confirmation, leased, measured (diagnostics, IMU, axes on two
                faces, encoders), calibrated from the backend's command log, configured (an approved configuration),
                self-tested; an experiment starts only after the device's local enable and ends at its duration; the
                recording is synthetic and tied to the configuration; Simulate My Cube runs and the comparison is never
                validation evidence; export/reimport keeps the content hash; the gateway route (observer while the USB
                host is attached; stop always accepted) continues the telemetry session without missing frames after
                the companion leaves; a revoked credential is refused. Without make / a C compiler / libcrypto: NOT RUN
  drift         (v6.0) run_tests.py --only drift in the extracted package with its fresh install: every generated or
                built file matches its generator (the signed firmware release's source hash, the WebAssembly device and
                its byte-identical rebuild with the recorded compiler, kit, site data, schemas, index.html, …); a check
                that cannot run here (a missing tool) makes the step NOT RUN, never passed
  firmware-host (v6.0) run_tests.py --only firmware:host in the extracted package: the firmware core's host tests
  browser-v6    (v6.0) site/tests/browser_v6.py of the EXTRACTED package with --browser-python (virtual cube default,
                Build and Connect pages, the WebAssembly synthetic device, the installer's refusals, the jwt-mode
                backend); without --browser-python: NOT RUN
  backup        a consistent backup while running, restored into a new database file and verified
  stop          scripts/stop.sh stops everything cleanly
Exit code 0 only when every step ran and passed; 1 when a step failed; 2 when nothing failed but a step was not run.
"""
from __future__ import annotations

import argparse
import copy
import datetime as _dt
import fnmatch
import json
import math
import os
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

REQUIRED = ["README.md", "SOFTWARE_COMPLETION_REPORT.md", "CHANGELOG.md", "backend/pyproject.toml", "backend/requirements-lock.txt",
            "backend/aeris_backend/api/app.py", "backend/aeris_backend/telemetry/emulator.py", "backend/aeris_backend/tools/dbtool.py",
            "site/index.html", "site/js/workspace.js", "site/js/ui/telemetry-ui.js", "site/docs/TELEMETRY.md", "site/docs/HARDWARE_HANDOFF.md",
            "site/docs/MIGRATION_V5.md", "site/docs/MIGRATION_V5_1.md", "V5_SOFTWARE_COMPLETION_REPORT.md", "backend/aeris_backend/telemetry/lineage.py",
            "backend/tests/test_provenance.py", "backend/tests/test_stream_identity.py", "backend/tests/test_run_tests.py", "site/tests/v51.test.js",
            "site/tests/browser_v51.py", "scripts/ci_local.py", "evidence/v5.1-verification/README.md", "evidence/v5-independent-review/README.md",
            "scripts/install.sh", "scripts/start.sh", "scripts/stop.sh", "scripts/run_tests.py",
            "scripts/validate_release.py", "scripts/package_release.py", "studies/nominal_campaign.py", "studies/results/nominal-v5/campaign.json",
            "studies/results/nominal-v5/rerun-comparison.json", "evidence/README.md", "test-logs/summary.json", "test-logs/SUMMARY.md",
            ".github/workflows/ci.yml", "V5_1_SOFTWARE_COMPLETION_REPORT.md", "site/docs/MIGRATION_V5_2.md", "backend/aeris_backend/telemetry/export.py",
            "backend/tests/test_export_units.py", "backend/tests/test_lineage_bounded.py", "site/tests/browser_v52.py", "scripts/platform_exclusions.json",
            "evidence/v5.2-verification/README.md", "evidence/v5.1-independent-review/README.md",
            # v6.0
            "V5_2_SOFTWARE_COMPLETION_REPORT.md", "ACCEPTANCE_MATRIX_V6.md", "site/docs/MIGRATION_V6.md", "site/docs/DEVICE_LINK.md", "site/docs/CONNECT.md",
            "site/docs/DEVICES.md", "site/docs/FIRMWARE_INSTALL.md", "firmware/README.md", "firmware/Makefile", "firmware/tools/source_hash.py",
            "firmware/tools/build_esp32s3.sh", "firmware/tools/make_release.py", "firmware/tests/qemu_link_test.py", "hardware/README.md",
            "hardware/COMMISSIONING.md", "hardware/INTEGRATION.md", "hardware/BUILD_GUIDE.md", "hardware/SIZING.md", "hardware/bom/aeris-kit-a1.bom.json",
            "site/firmware/trust.json", "site/firmware/releases/0.1.0/manifest.json", "site/firmware/releases/0.1.0/aeris_fw.bin",
            "site/firmware/synthetic/aeris-device.wasm", "site/firmware/synthetic/aeris-device.build.json", "site/js/connect/connect-ui.js",
            "site/tests/browser_v6.py", "site/tests/connect.test.js", "backend/aeris_backend/devices/service.py", "backend/tests/test_devices_e2e.py",
            "scripts/check_drift.py", "evidence/v6.0-verification/README.md", "evidence/v5.2-release/test-logs/summary.json"]
FORBIDDEN = ["*/__pycache__/*", "*.pyc", "*/.venv/*", "*/venv/*", "*/node_modules/*", "*.sqlite3", "*.sqlite3-wal", "*.sqlite3-shm", "*.db",
             "*/.env", "*.pem", "*.key", "*id_rsa*", "*/.pytest_cache/*", "*/.mypy_cache/*", "*.egg-info/*", "*/data/run/*", "*.lock",
             "*/.DS_Store", "*/credentials*", "*secret*"]

results = {"steps": [], "environment": {"platform": platform.platform(), "python": sys.version.split()[0]}}
STEPS = ("archive", "extract", "install", "start", "experiment", "reproduce", "restart", "sweep-cancel", "telemetry", "telemetry-provenance",
         "telemetry-restart", "telemetry-units", "telemetry-generations", "device-journey", "test-runner", "drift", "firmware-host", "browser-cancel",
         "browser-v6", "backup", "stop")
EXPECT_TOP = {"name": None}


def step(name):
    def deco(fn):
        def wrapper(*a, **k):
            t0 = time.time()
            rec = {"step": name, "passed": False, "details": {}}
            try:
                ok, details = fn(*a, **k)
                rec.update(passed=bool(ok), details=details)
                if ok is None:                                        # the step could not run: NOT RUN, never passed
                    rec.update(passed=False, not_run=True)
            except Exception as e:  # noqa: BLE001 — record, never hide
                rec.update(passed=False, details={"error": f"{type(e).__name__}: {e}"})
            rec["seconds"] = round(time.time() - t0, 1)
            results["steps"].append(rec)
            print(("PASS " if rec["passed"] else "NOT RUN " if rec.get("not_run") else "FAIL ") + name + f" ({rec['seconds']} s)"
                  + ("" if rec["passed"] else "  → " + json.dumps(rec["details"])[:600]), flush=True)
            return rec["passed"], rec["details"]
        return wrapper
    return deco


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class Api:
    def __init__(self, base):
        self.base = base.rstrip("/")

    def call(self, method, path, body=None, raw=False, timeout=60):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method, headers={"Content-Type": "application/json", "Accept": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                txt = r.read().decode()
                return (r.status, txt) if raw else (r.status, json.loads(txt) if txt else None)
        except urllib.error.HTTPError as e:
            txt = e.read().decode()
            return e.code, (txt if raw else (json.loads(txt) if txt.startswith("{") else txt))

    def get(self, path, **k):
        return self.call("GET", path, **k)

    def post(self, path, body=None, **k):
        return self.call("POST", path, body, **k)

    def until(self, fn, timeout=180, step=0.2):
        t0 = time.time()
        while time.time() - t0 < timeout:
            v = fn()
            if v:
                return v
            time.sleep(step)
        return None

    def job(self, jid, timeout=240):
        return self.until(lambda: (lambda j: j if j["state"] in ("complete", "failed", "cancelled") else None)(self.get(f"/api/v1/jobs/{jid}")[1]), timeout)


@step("archive")
def check_archive(zpath):
    with zipfile.ZipFile(zpath) as z:
        names = z.namelist()
    tops = {n.split("/")[0] for n in names}
    prefix = (tops.pop() + "/") if len(tops) == 1 else ""
    rel = [n[len(prefix):] for n in names]
    missing = [r for r in REQUIRED if r not in rel]
    bad = sorted({n for n in names for pat in FORBIDDEN if fnmatch.fnmatch("/" + n, pat) or fnmatch.fnmatch(n, pat)})
    top_ok = EXPECT_TOP["name"] is None or prefix.rstrip("/") == EXPECT_TOP["name"]
    return (not missing and not bad and top_ok and bool(prefix)), {"files": len(names), "top_folder": prefix.rstrip("/"), "expected_top_folder": EXPECT_TOP["name"],
                                                                     "missing": missing, "forbidden": bad[:50], "bytes": os.path.getsize(zpath)}


@step("extract")
def extract(zpath, work):
    with zipfile.ZipFile(zpath) as z:
        z.extractall(work)
    tops = [p for p in Path(work).iterdir()]
    root = tops[0] if len(tops) == 1 and tops[0].is_dir() else Path(work)
    for sh in (root / "scripts").glob("*.sh"):
        sh.chmod(0o755)                              # zip files may drop the executable bit
    return (root / "scripts" / "install.sh").exists(), {"root": str(root)}


@step("install")
def install(root, py):
    p = subprocess.run(["bash", str(root / "scripts" / "install.sh"), "--python", py], capture_output=True, text=True, timeout=1800)
    if p.returncode != 0:
        return False, {"exit": p.returncode, "output": (p.stdout + p.stderr)[-1500:]}
    vpy = root / "backend" / ".venv" / "bin" / "python"
    frz = subprocess.run([str(vpy), "-m", "pip", "freeze"], capture_output=True, text=True).stdout
    have = {l.split("==")[0].lower().replace("_", "-"): l.split("==")[1] for l in frz.splitlines() if "==" in l}
    want = {l.split("==")[0].lower().replace("_", "-"): l.split("==")[1].strip() for l in (root / "backend" / "requirements-lock.txt").read_text().splitlines() if "==" in l}
    diff = {k: (v, have.get(k)) for k, v in want.items() if have.get(k) != v}
    return not diff, {"python": subprocess.run([str(vpy), "-V"], capture_output=True, text=True).stdout.strip(), "lock_mismatches": diff, "output": p.stdout[-400:]}


@step("start")
def start(root, data, port, eport):
    p = subprocess.run(["bash", str(root / "scripts" / "start.sh"), "--port", str(port), "--data", str(data), "--emulator", "--emulator-port", str(eport), "--workers", "2"],
                       capture_output=True, text=True, timeout=120)
    api = Api(f"http://127.0.0.1:{port}")
    h = api.get("/api/v1/health")[1] if p.returncode == 0 else None
    s, page = api.get("/", raw=True) if p.returncode == 0 else (None, "")
    ok = p.returncode == 0 and h and h["status"] == "ok" and s == 200 and "AERIS_CONFIG" in page
    return ok, {"exit": p.returncode, "output": (p.stdout + p.stderr)[-800:], "health": h and {k: h[k] for k in ("version", "engine_version", "schema_version", "metrics_version")}}


ADVANCED = {"mode": "corner", "duration_s": 4, "seed": 17, "controller": {"type": "nlpd"}, "estimator": {"type": "mekf", "stale_after_s": 0.03},
            "initial": {"attitude_q": [0.880990552979211, 0.3399789848371774, -0.3290195188065467, -0.004011442979123468], "body_rate_dps": [3, -2, 1]},
            "reference": {"attitude": "balance", "heading": "free", "yaw_deg": 0}, "sensor": {"gyro_noise_dps": 0.2, "latency_ms": 4}}


@step("experiment")
def experiment(api, ctx):
    s, v = api.post("/api/v1/validate", {"config": ADVANCED})
    s, r = api.post("/api/v1/simulations", {"config": ADVANCED, "meta": {"name": "release validation"}})
    j = api.job(r["job"]["id"])
    run = api.get(f"/api/v1/runs/{j['result_ref']['id']}")[1]
    ctx["run"] = run
    ok = (v["ok"] and j["state"] == "complete" and run["executed"]["controller"]["type"] == "nlpd" and run["executed"]["estimator"]["type"] == "mekf"
          and run["executed"]["initial_state"]["attitude_from"] == "explicit attitude quaternion" and run["reproduction"]["metrics_version"] == "2"
          and run["executed"]["reference"]["requested"]["heading"] == "free")
    return ok, {"run": run["id"], "experiment_id": run["experiment_id"], "outcome": run["outcome"]["code"], "research_recovered": run["research"]["recovery"]["recovered"]}


@step("reproduce")
def reproduce(api, ctx):
    rid = ctx["run"]["id"]
    again = api.get(f"/api/v1/runs/{rid}")[1]
    s, r = api.post(f"/api/v1/runs/{rid}/reproduce")
    j = api.job(r["job"]["id"])
    rep = api.get(f"/api/v1/runs/{j['result_ref']['id']}")[1]["reproduction"]["reproduces"]
    return again == ctx["run"] and rep["identical"], {"retrieved_identical": again == ctx["run"], "reproduction": {k: rep.get(k) for k in ("identical", "verdict", "max_abs_diff")}}


SWEEP = {"name": "release validation", "revision": "1.2", "mode": "grid", "seed": 5, "seed_strategy": "paired", "criterion": "research", "base": {"mode": "corner"},
         "controllers": ["lqr", "lqr-mimo", "nlpd"], "variables": [{"key": "tilt_deg", "min": 0.5, "max": 4, "steps": 8}, {"key": "rate_dps", "min": 0, "max": 10, "steps": 3}],
         "duration_s": 6, "record_hz": 10}


@step("sweep-cancel")
def sweep_cancel(api, ctx):
    s, r = api.post("/api/v1/sweeps", {"sweep": SWEEP})
    jid = r["job"]["id"]
    api.until(lambda: api.get(f"/api/v1/jobs/{jid}")[1]["progress"]["done"] >= 5, 180, 0.1)
    api.post(f"/api/v1/jobs/{jid}/cancel")
    j = api.job(jid)
    sw = api.get(f"/api/v1/sweeps/{j['result_ref']['id']}")[1]
    s2, an = api.post(f"/api/v1/sweeps/{sw['id']}/analyze")
    s3, ds = api.post("/api/v1/datasets", {"title": "release validation (partial sweep)", "sweep_ids": [sw["id"]]})
    s4, fin = api.post(f"/api/v1/datasets/{ds['id']}/finalize")
    s5, bundle = api.get(f"/api/v1/datasets/{ds['id']}/export")
    ig = bundle["integrity"]
    ok = (j["state"] == "cancelled" and sw["partial"] and 5 <= len(sw["rows"]) < sw["total"] and s2 == 200 and an["rows"] == len(sw["rows"])
          and fin["status"] == "final" and ig["members_hash_ok"] and ig["member_content_ok"])
    return ok, {"state": j["state"], "rows": len(sw["rows"]), "total": sw["total"], "dataset": ds["id"], "integrity": ig}


@step("restart")
def restart(api, root, data, port, eport, ctx):
    s, r = api.post("/api/v1/sweeps", {"sweep": dict(SWEEP, name="release validation (restart)", seed=6)})
    jid = r["job"]["id"]
    api.until(lambda: api.get(f"/api/v1/jobs/{jid}")[1]["progress"]["done"] >= 5, 180, 0.1)
    before = api.get(f"/api/v1/jobs/{jid}")[1]["progress"]["done"]
    stop = subprocess.run(["bash", str(root / "scripts" / "stop.sh"), "--data", str(data)], capture_output=True, text=True, timeout=120)
    st = subprocess.run(["bash", str(root / "scripts" / "start.sh"), "--port", str(port), "--data", str(data), "--emulator", "--emulator-port", str(eport), "--workers", "2"],
                        capture_output=True, text=True, timeout=120)
    j = api.job(jid, timeout=600)
    sw = api.get(f"/api/v1/sweeps/{j['result_ref']['id']}")[1]
    idx = [row["index"] for row in sw["rows"]]
    run_still = api.get(f"/api/v1/runs/{ctx['run']['id']}")[1] == ctx["run"]
    ok = stop.returncode == 0 and st.returncode == 0 and j["state"] == "complete" and j["restarts"] >= 1 and len(idx) == sw["total"] == len(set(idx)) and run_still
    return ok, {"done_before_stop": before, "state": j["state"], "restarts": j["restarts"], "rows": len(idx), "unique_rows": len(set(idx)), "total": sw["total"],
                "earlier_run_unchanged": run_still, "stop_output": stop.stdout.strip()[-300:]}


@step("telemetry")
def telemetry(api, eport):
    s, st = api.post("/api/v1/telemetry/connect", {"source": "tcp", "host": "127.0.0.1", "port": eport})
    got = api.until(lambda: (lambda d: d if d["connected"] and d["counters"]["frames_accepted"] > 30 else None)(api.get("/api/v1/telemetry/status")[1]), 30)
    prov = got["provenance"] if got else None
    polled = api.get(f"/api/v1/telemetry/frames?after={max(0, got['last_n'] - 10)}")[1] if got else {"frames": []}
    s1, _ = api.post("/api/v1/telemetry/recordings/start", {"name": "release validation"})
    time.sleep(1.2)                                   # the recording length itself (1.2 s of frames), not a wait for a result
    s2, rec = api.post("/api/v1/telemetry/recordings/stop")
    s3, nd = api.get(f"/api/v1/hardware/recordings/{rec['id']}/export?format=ndjson", raw=True)
    hello = json.loads(nd.splitlines()[0])
    api.post("/api/v1/telemetry/connect", {"source": "recording", "recording_id": rec["id"], "speed": 0})
    rp = api.until(lambda: (lambda d: d if d["source"] and d["source"]["state"] == "finished" else None)(api.get("/api/v1/telemetry/status")[1]), 30)
    api.post("/api/v1/telemetry/disconnect")
    ok = (prov and prov["synthetic"] and not prov["declared_physical"] and not got["live"] and len(polled["frames"]) > 0 and rec["synthetic"]
          and hello["synthetic"] is True and hello["device"]["kind"] == "emulator" and rp and rp["provenance"]["replay"] and rp["provenance"]["synthetic"])
    return ok, {"provenance_label": prov and prov["label"], "recording": rec["id"], "samples": rec["quality"]["n"], "replay_frames": rp and rp["counters"]["frames_accepted"]}


# ---------------------------------------------------------------- v5.1 checks (review findings F1–F3)
CONVENTIONS = {"quaternion": "w,x,y,z; body to world; Hamilton product", "body_axes": "x, y, z along the cube edges from the pivot corner",
               "world_axes": "z up", "time": "seconds since the session start (monotonic)"}
FIXTURE_HELLO = {"type": "hello", "protocol": "aeris-telemetry-ndjson/1", "device": {"id": "release-validation-fixture-physical-declaration", "kind": "physical", "firmware": "test-only"},
                 "synthetic": False, "mode": "corner", "conventions": CONVENTIONS, "nominal_rate_hz": 100}


def fixture_server():
    """ARTIFICIAL declared-physical source (a line server in this script, NOT a device): each connection gets the
    physical hello, then frames at about 100 Hz until it is closed. Returns (port, stop)."""
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", 0))
    srv.listen(4)
    stop_ev = threading.Event()

    def serve(conn):
        with conn:
            try:
                conn.sendall((json.dumps(FIXTURE_HELLO) + "\n").encode())
                k = 0
                while not stop_ev.is_set():
                    conn.sendall((json.dumps({"type": "frame", "seq": k, "t": round(0.01 * k, 6), "q": [1, 0, 0, 0], "w": [0, 0, 0]}) + "\n").encode())
                    k += 1
                    time.sleep(0.01)
            except OSError:
                return

    def accept_loop():
        srv.settimeout(0.2)
        while not stop_ev.is_set():
            try:
                c, _ = srv.accept()
            except OSError:
                continue
            threading.Thread(target=serve, args=(c,), daemon=True).start()
        srv.close()
    threading.Thread(target=accept_loop, daemon=True).start()
    return srv.getsockname()[1], stop_ev.set


def _status(api):
    return api.get("/api/v1/telemetry/status")[1]


def _record(api, name, connect_then=None, frames=60):
    """Start a recording on the current source, optionally switch the source while recording, stop after `frames`."""
    assert api.post("/api/v1/telemetry/recordings/start", {"name": name})[0] == 201
    if connect_then:
        api.until(lambda: (_status(api).get("recording") or {}).get("frames", 0) >= frames, 30, 0.05)
        api.post("/api/v1/telemetry/connect", connect_then)
        api.until(lambda: (lambda st: st["provenance"].get("synthetic") and st["connected"])(_status(api)), 30, 0.05)
        n0 = (_status(api).get("recording") or {}).get("frames", 0)
        api.until(lambda: (_status(api).get("recording") or {}).get("frames", 0) >= n0 + frames, 30, 0.05)
    else:
        api.until(lambda: (_status(api).get("recording") or {}).get("frames", 0) >= frames, 30, 0.05)
    return api.post("/api/v1/telemetry/recordings/stop")[1]


@step("telemetry-provenance")
def telemetry_provenance(api, eport, data, ctx):
    fport, stop_fixture = fixture_server()
    tcp = lambda p: {"source": "tcp", "host": "127.0.0.1", "port": p, "reconnect": False}     # noqa: E731
    d = {"note": "the declared-physical source is an ARTIFICIAL test fixture in validate_release.py, not a device"}
    try:
        api.post("/api/v1/telemetry/connect", tcp(fport))
        api.until(lambda: (lambda st: st["connected"] and st["provenance"].get("declared_physical") and st["counters"]["frames_accepted"] > 20)(_status(api)), 30, 0.05)
        phys = _record(api, "release validation: declared-physical fixture (ARTIFICIAL)")
        api.post("/api/v1/telemetry/connect", tcp(fport))
        api.until(lambda: (lambda st: st["connected"] and st["provenance"].get("declared_physical"))(_status(api)), 30, 0.05)
        mixed = _record(api, "release validation: fixture, then the SYNTHETIC emulator", connect_then=tcp(eport))
        doc = api.get(f"/api/v1/hardware/recordings/{mixed['id']}")[1]["document"]
        segs = [(s["device"]["kind"], s["synthetic"]) for s in doc["provenance"].get("segments", [])]
        nd = api.get(f"/api/v1/hardware/recordings/{mixed['id']}/export?format=ndjson", raw=True)[1]
        hellos = [json.loads(x) for x in nd.splitlines() if json.loads(x).get("type") == "hello"]
        (data / "telemetry" / "release-validation-mixed.ndjson").write_text(nd)
        api.post("/api/v1/telemetry/connect", {"source": "file", "path": "release-validation-mixed.ndjson", "speed": 1})
        api.until(lambda: (lambda st: st.get("hello") is not None and (st.get("transport") or {}).get("kind") == "file")(_status(api)), 30, 0.02)
        api.post("/api/v1/telemetry/recordings/start", {"name": "release validation: re-recorded export of the mixed recording"})
        api.until(lambda: (_status(api).get("source") or {}).get("state") == "finished", 60, 0.1)
        copy_ = api.post("/api/v1/telemetry/recordings/stop")[1]
        cmp_ = api.post("/api/v1/hardware/compare", {"run_id": ctx["run"]["id"], "recording_id": copy_["id"]})[1] if ctx.get("run") else None
        ds = api.post("/api/v1/datasets", {"title": "release validation: synthetic descendants", "recording_ids": [mixed["id"], copy_["id"]]})[1]
        d.update(declared_physical={"id": phys["id"], "synthetic": phys["synthetic"], "trust": phys["provenance"]["trust"]},
                 mixed={"id": mixed["id"], "synthetic": mixed["synthetic"], "trust": mixed["provenance"]["trust"], "segments": segs},
                 exported_hellos=[(h["device"]["kind"], h["synthetic"], (h.get("lineage") or {}).get("trust")) for h in hellos],
                 rerecorded={"id": copy_["id"], "synthetic": copy_["synthetic"], "trust": copy_["provenance"]["trust"], "derived": copy_["provenance"]["derived"]},
                 comparison=cmp_ and {"admissible": cmp_["evidence"]["admissible_as_validation_evidence"], "reasons": cmp_["evidence"]["reasons"][:3]},
                 dataset={"id": ds["id"], "source": ds["provenance"]["source"]})
        ok = (phys["synthetic"] is False and phys["provenance"]["trust"] == "declared-physical"
              and mixed["synthetic"] is True and mixed["provenance"]["trust"] == "synthetic" and segs == [("physical", False), ("emulator", True)]
              and len(hellos) == 2 and all(h["synthetic"] is True for h in hellos) and [h["device"]["kind"] for h in hellos] == ["file-replay", "emulator"]
              and copy_["synthetic"] is True and copy_["provenance"]["trust"] == "synthetic" and copy_["provenance"]["derived"] is True
              and cmp_ is not None and cmp_["evidence"]["admissible_as_validation_evidence"] is False and ds["provenance"]["source"] == "synthetic-telemetry")
        return ok, d
    finally:
        stop_fixture()
        api.post("/api/v1/telemetry/disconnect")


@step("telemetry-restart")
def telemetry_restart(api, root, data, port, eport):
    tcp = {"source": "tcp", "host": "127.0.0.1", "port": eport}
    api.post("/api/v1/telemetry/connect", tcp)
    st1 = api.until(lambda: (lambda st: st if st["connected"] and st["counters"]["frames_accepted"] > 50 else None)(_status(api)), 30, 0.05)
    sid1, cursor = st1["stream_id"], st1["last_n"]
    stop = subprocess.run(["bash", str(root / "scripts" / "stop.sh"), "--data", str(data)], capture_output=True, text=True, timeout=120)
    st = subprocess.run(["bash", str(root / "scripts" / "start.sh"), "--port", str(port), "--data", str(data), "--emulator", "--emulator-port", str(eport), "--workers", "2"],
                        capture_output=True, text=True, timeout=120)
    api.post("/api/v1/telemetry/connect", tcp)
    st2 = api.until(lambda: (lambda s: s if s["connected"] and s["counters"]["frames_accepted"] > 5 else None)(_status(api)), 30, 0.05)
    d = api.get(f"/api/v1/telemetry/frames?after={cursor}&stream={sid1}")[1]
    v5 = api.get(f"/api/v1/telemetry/frames?after={cursor}")[1]                       # a client naming no stream (v5): unchanged answer
    api.post("/api/v1/telemetry/disconnect")
    ok = (stop.returncode == 0 and st.returncode == 0 and st2 is not None and st2["stream_id"] != sid1 and d["stream_changed"] is True
          and d["stream_id"] == st2["stream_id"] and bool(d["frames"]) and d["frames"][0]["n"] == 1 and v5["stream_changed"] is False)
    return ok, {"stream_before": sid1, "cursor_before": cursor, "stream_after": st2 and st2["stream_id"], "answer_first_n": d["frames"][0]["n"] if d.get("frames") else None,
                "answer_frames": len(d.get("frames") or []), "stream_changed": d.get("stream_changed"),
                "v5_style_answer_frames": len(v5.get("frames") or []) if v5["last_n"] < cursor else "n/a (the new process already counted past the old cursor)"}


# ---------------------------------------------------------------- v5.2 checks (review findings G1–G4)
UNIT_RATE, UNIT_N = 50.0, 80
UNIT_FACTOR = {"ms": 1e-3, "deg": math.pi / 180, "deg/s": math.pi / 180, "rad/s": 1.0, "mN·m": 1e-3, "g": 9.80665}


def _unit_truth(i):
    """SYNTHETIC truth in wire units (s, rad, rad/s, rpm, N·m, m/s²) for row i."""
    return {"t": i / UNIT_RATE, "theta": 0.05 * math.sin(i / 9), "w": [0.3 * math.sin(i / 7), -0.2 * math.cos(i / 5), 0.1 * math.sin(i / 3)],
            "wheel_rpm": [1500.0 + 10 * i, -800.0 + 5 * i, 300 * math.sin(i / 4)], "torque_cmd": [0.02 * math.sin(i / 6), 0.01, -0.015 * math.cos(i / 8)],
            "accel": [0.1 * math.sin(i / 5), 0.05, 9.80665 + 0.01 * math.sin(i / 3)]}


def _unit_doc():
    T = [_unit_truth(i) for i in range(UNIT_N)]
    cols = {"t": [r["t"] / UNIT_FACTOR["ms"] for r in T], "seq": list(range(500, 500 + UNIT_N)), "theta": [r["theta"] / UNIT_FACTOR["deg"] for r in T]}
    units = {"t": "ms", "seq": "count", "theta": "deg"}
    for j, a in enumerate("xyz"):
        cols[f"w_{a}"], units[f"w_{a}"] = [r["w"][j] / UNIT_FACTOR["deg/s"] for r in T], "deg/s"
        cols[f"omega_{a}"], units[f"omega_{a}"] = [r["wheel_rpm"][j] * math.pi / 30 for r in T], "rad/s"
        cols[f"torque_cmd_{a}"], units[f"torque_cmd_{a}"] = [r["torque_cmd"][j] / UNIT_FACTOR["mN·m"] for r in T], "mN·m"
        cols[f"accel_{a}"], units[f"accel_{a}"] = [r["accel"][j] / UNIT_FACTOR["g"] for r in T], "g"
    return {"schema": "aeris-hardware-run/1", "synthetic": True, "device": {"id": "release-validation-unit-fixture", "firmware": "test-only"},
            "recording": {"started": "2026-10-01T00:00:00Z", "notes": "SYNTHETIC unit-conversion fixture (release validation)"}, "mode": "edge",
            "parameters": {"parameter_set": "nominal-design-v1"}, "samples": {"rate_hz": UNIT_RATE, "cols": cols, "units": units}}


def _close(a, b, rel=1e-12, abs_=1e-15):
    return abs(a - b) <= max(abs_, rel * max(abs(a), abs(b)))


@step("telemetry-units")
def telemetry_units(api, data):
    doc = _unit_doc()
    st, up = api.post("/api/v1/hardware/recordings", doc)
    if st != 201:
        return False, {"import": st, "body": str(up)[:300]}
    rid = up["id"]
    st, nd = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=ndjson", raw=True)
    lines = [json.loads(x) for x in nd.splitlines()] if st == 200 else []
    frames = [x for x in lines if x.get("type") == "frame"]
    hello = next((x for x in lines if x.get("type") == "hello"), {})
    bad = []
    for i, f in enumerate(frames):
        tr = _unit_truth(i)
        for key, want in (("t", [tr["t"]]), ("theta", [tr["theta"]]), ("w", tr["w"]), ("wheel_rpm", tr["wheel_rpm"]), ("torque_cmd", tr["torque_cmd"]),
                          ("accel", tr["accel"])):
            got = [f.get("t")] if key == "t" else [f.get("theta")] if key == "theta" else (f.get("imu") or {}).get("accel") if key == "accel" else f.get(key)
            if not got or not all(_close(g, w) for g, w in zip(got, want)) or len(got) != len(want):
                bad.append((i, key, got, want))
    conv = (hello.get("lineage") or {}).get("export", {}).get("converted", {})
    frames_ok = st == 200 and len(frames) == UNIT_N and not bad and conv.get("t") == "ms → s" and conv.get("omega_x") == "rad/s → rpm"
    # the export replayed by the running backend and recorded again: physical values and intervals, rows matched by seq
    (data / "telemetry" / "release-validation-units.ndjson").write_text(nd if st == 200 else "")
    api.post("/api/v1/telemetry/connect", {"source": "file", "path": "release-validation-units.ndjson", "speed": 1})
    api.until(lambda: (lambda x: x.get("hello") is not None and (x.get("transport") or {}).get("kind") == "file")(_status(api)), 30, 0.02)
    api.post("/api/v1/telemetry/recordings/start", {"name": "release validation: replay of the unit fixture"})
    api.until(lambda: (_status(api).get("source") or {}).get("state") == "finished", 60, 0.1)
    st2, rec = api.post("/api/v1/telemetry/recordings/stop")
    new = api.get(f"/api/v1/hardware/recordings/{rec['id']}")[1]["document"] if st2 == 201 else {"samples": {"cols": {}, "units": {}}}
    nc, nu = new["samples"]["cols"], new["samples"]["units"]
    want_units = {"t": "s", "theta": "rad", "w_x": "rad/s", "wheel_rpm_x": "rpm", "torque_cmd_x": "N·m", "accel_x": "m/s²"}
    units_ok = all(nu.get(k) == v for k, v in want_units.items()) and not any(k.startswith("omega_") for k in nu)
    rows = {int(s_): i for i, s_ in enumerate(nc.get("seq") or [])}
    val_bad = []
    for s_, i in rows.items():
        tr = _unit_truth(s_ - 500)
        for key, want in (("t", tr["t"]), ("theta", tr["theta"]), ("w_x", tr["w"][0]), ("wheel_rpm_y", tr["wheel_rpm"][1]), ("torque_cmd_z", tr["torque_cmd"][2]),
                          ("accel_z", tr["accel"][2])):
            if not _close(nc[key][i], want):
                val_bad.append((s_, key, nc[key][i], want))
    seqs = sorted(rows)
    dt_bad = [(a, b) for a, b in zip(seqs, seqs[1:]) if not _close(nc["t"][rows[b]] - nc["t"][rows[a]], (b - a) / UNIT_RATE, rel=1e-9, abs_=1e-12)]
    copy_ok = st2 == 201 and units_ok and len(rows) >= UNIT_N - 20 and not val_bad and not dt_bad and new.get("synthetic") is True
    # refusals: an incomplete vector is 422 with its column, never 500; omit_unmapped leaves it out and says so
    inc = copy.deepcopy(doc)
    inc["samples"]["cols"].pop("w_z")
    inc["samples"]["units"].pop("w_z")
    rid2 = api.post("/api/v1/hardware/recordings", inc)[1]["id"]
    s3, e3 = api.get(f"/api/v1/hardware/recordings/{rid2}/export?format=ndjson")
    s4, nd4 = api.get(f"/api/v1/hardware/recordings/{rid2}/export?format=ndjson&omit_unmapped=true", raw=True)
    om = (json.loads(nd4.splitlines()[0]).get("lineage") or {}).get("export", {}).get("omitted", {}) if s4 == 200 else {}
    refuse_ok = s3 == 422 and (e3.get("error") or {}).get("code") == "export_not_possible" and s4 == 200 and set(om.get("columns", [])) == {"w_x", "w_y"}
    orig_ok = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=json")[1] == doc
    api.post("/api/v1/telemetry/disconnect")
    return frames_ok and copy_ok and refuse_ok and orig_ok, {
        "recording": rid, "export_status": st, "frames": len(frames), "frame_mismatches": bad[:3], "converted": conv,
        "rerecorded": {"id": rec.get("id") if isinstance(rec, dict) else None, "units": {k: nu.get(k) for k in want_units}, "rows_matched": len(rows),
                       "value_mismatches": val_bad[:3], "interval_mismatches": dt_bad[:3]},
        "incomplete_vector": {"status": s3, "code": (e3.get("error") or {}).get("code") if isinstance(e3, dict) else None, "omit_unmapped_status": s4, "omitted": om},
        "stored_original_unchanged": orig_ok}


GENERATIONS_SCRIPT = r"""
import asyncio, json, sys
from aeris_backend.telemetry.lineage import LINEAGE_BUDGET, classify
from aeris_backend.telemetry.protocol import MAX_LINE, dumps, hello_message, validate_hello
from aeris_backend.telemetry.stream import TelemetryHub, recording_to_ndjson
from aeris_backend.telemetry.transport import FileReplaySource

PHYS = hello_message("release-validation-fixture-physical-declaration", "physical", "test-only", False, "corner", 100)
EMU = hello_message("release-validation-emulator-identity", "emulator", "test-only", True, "corner", 100)

class Rec(TelemetryHub):
    def feed_line(self, raw, now):
        r = super().feed_line(raw, now)
        if r == "hello" and self.recording is None:
            self.start_recording("re-recorded replay (release validation)", now)
        return r

h = TelemetryHub()
for k, hel in enumerate((PHYS, EMU)):
    if k:
        h.on_disconnect("source replaced", 1.0)
    h.on_connect({"kind": "tcp", "address": "release-validation"}, k + 0.05)
    h.feed_line(dumps(hel), k + 0.1)
    if k == 0:
        h.start_recording("mixed fixture (ARTIFICIAL; not a measurement)", 0.1)
    for j in range(6):
        h.feed_message({"type": "frame", "seq": j, "t": 0.01 * j, "q": [1, 0, 0, 0], "w": [0.01 * j, 0, 0]}, k + 0.2 + 0.01 * j)
doc = h.stop_recording(9.0)
rows = []
for g in range(1, 21):
    nd = recording_to_ndjson(doc, "AERIS-HW-RV-%03d" % g)
    hellos = [json.loads(x) for x in nd.splitlines() if '"type":"hello"' in x]
    hub = Rec()
    asyncio.run(FileReplaySource(hub, text=nd, label="recording:release-validation", speed=0).run())
    new = hub.stop_recording(99.0)
    rows.append({"generation": g, "lineage_bytes": [len(json.dumps(x["lineage"], default=str)) for x in hellos],
                 "hello_errors": sum(len(validate_hello(x)["errors"]) for x in hellos), "longest_line": max(len(x.encode()) for x in nd.splitlines()),
                 "rejected": hub.counters["rejected"], "rows": [len(doc["samples"]["cols"]["t"]), len(new["samples"]["cols"]["t"])],
                 "lineage_generation": sorted({x["lineage"]["generation"] for x in hellos}), "trust": classify(new)["trust"], "synthetic": new["synthetic"]})
    doc = new
print(json.dumps({"budget": LINEAGE_BUDGET, "max_line": MAX_LINE, "rows": rows, "last": doc}))
"""


@step("telemetry-generations")
def telemetry_generations(root, api, ctx):
    vpy = root / "backend" / ".venv" / "bin" / "python"
    p = subprocess.run([str(vpy), "-c", GENERATIONS_SCRIPT], cwd=str(root / "backend"), capture_output=True, text=True, timeout=600)
    if p.returncode != 0:
        return False, {"exit": p.returncode, "stderr": p.stderr[-800:]}
    out = json.loads(p.stdout.strip().splitlines()[-1])
    rows = out["rows"]
    gens_ok = (len(rows) == 20 and all(r["hello_errors"] == 0 and r["rejected"] == 0 and r["rows"][0] == r["rows"][1] == 12 and max(r["lineage_bytes"]) <= out["budget"]
                                        and r["longest_line"] <= out["max_line"] and r["lineage_generation"] == [r["generation"]] and r["trust"] == "synthetic"
                                        and r["synthetic"] is True for r in rows))
    st, up = api.post("/api/v1/hardware/recordings", out["last"])
    rid = up.get("id") if isinstance(up, dict) else None
    s2, nd = api.get(f"/api/v1/hardware/recordings/{rid}/export?format=ndjson", raw=True)
    gen = sorted({json.loads(x)["lineage"]["generation"] for x in nd.splitlines() if json.loads(x).get("type") == "hello"}) if s2 == 200 else None
    cmp_ = api.post("/api/v1/hardware/compare", {"run_id": ctx["run"]["id"], "recording_id": rid})[1] if ctx.get("run") and rid else None
    api_ok = (st == 201 and up["synthetic"] is True and up["provenance"]["trust"] == "synthetic" and up["provenance"]["derived"] is True and gen == [21]
              and cmp_ is not None and cmp_["evidence"]["admissible_as_validation_evidence"] is False)
    return gens_ok and api_ok, {"generations": len(rows), "max_lineage_bytes": max(max(r["lineage_bytes"]) for r in rows), "budget": out["budget"],
                                "first": rows[0], "last": rows[-1], "imported": rid, "imported_trust": isinstance(up, dict) and (up.get("provenance") or {}).get("trust"),
                                "export_generation": gen, "comparison_admissible": cmp_ and cmp_["evidence"]["admissible_as_validation_evidence"]}


@step("test-runner")
def test_runner(root):
    vpy = root / "backend" / ".venv" / "bin" / "python"
    has_pw = subprocess.run([str(vpy), "-c", "import playwright"], capture_output=True).returncode == 0
    out1 = root / "release-validation-test-logs" / "browser"
    p1 = subprocess.run([sys.executable, "scripts/run_tests.py", "--out", str(out1), "--only", "browser", "--browser-python", "backend/.venv/bin/python"],
                        cwd=str(root), capture_output=True, text=True, timeout=1800)
    s1 = json.loads((out1 / "summary.json").read_text()) if (out1 / "summary.json").exists() else None
    bp = (s1 or {}).get("interpreters", {}).get("browser_python") or {}
    if has_pw:      # the fresh install has no Playwright; if it has, the browser suites must actually run (and pass)
        ok1 = s1 is not None and p1.returncode == 0 and all(s["status"] == "passed" for s in s1["suites"])
    else:
        ok1 = (s1 is not None and p1.returncode == 2 and "Traceback" not in p1.stderr and s1["suites"]
               and all(s["status"] == "not run" and "Playwright is not importable" in (s["reason"] or "") and s["log"] is None for s in s1["suites"])
               and bp.get("given") == "backend/.venv/bin/python" and bp.get("path") is None and s1["full_validation"] is False and s1["verdict"].startswith("INCOMPLETE"))
    out2 = root / "release-validation-test-logs" / "schema"
    p2 = subprocess.run([sys.executable, "scripts/run_tests.py", "--out", str(out2), "--only", "js:schema"], cwd=str(root), capture_output=True, text=True, timeout=600)
    s2 = json.loads((out2 / "summary.json").read_text()) if (out2 / "summary.json").exists() else None
    if shutil.which("node"):
        ok2 = s2 is not None and p2.returncode == 0 and s2["verdict"].startswith("PASSED — selected suites only") and s2["full_validation"] is False
    else:
        ok2 = s2 is not None and p2.returncode == 2 and s2["suites"][0]["status"] == "not run"
    # v5.2 (review G3): a skipped test case is never a pass; a declared platform exclusion is named, never a full validation
    fx = root / "release-validation-test-logs" / "skip-fixture"
    (fx / "scripts").mkdir(parents=True, exist_ok=True)
    (fx / "backend" / "tests").mkdir(parents=True, exist_ok=True)
    (fx / "site" / "tests").mkdir(parents=True, exist_ok=True)
    shutil.copy(root / "scripts" / "run_tests.py", fx / "scripts" / "run_tests.py")
    (fx / "backend" / "tests" / "test_skip.py").write_text("import pytest\n\ndef test_ok():\n    assert True\n\n"
                                                          "@pytest.mark.skip(reason='controlled release-validation skip')\ndef test_skipped():\n    pass\n")
    pol = fx / "policy.json"
    pol.write_text(json.dumps({"schema": "aeris-platform-exclusions/1", "exclusions": [{"suite": "backend", "test": "tests.test_skip::test_skipped",
                                                                                       "platforms": [sys.platform], "why": "release-validation fixture",
                                                                                       "covered_by": "tests.test_skip::test_ok"}]}))
    runs = {}
    for name, extra in (("skip", []), ("excluded", ["--exclusions", str(pol)])):
        o = fx / f"logs-{name}"
        p = subprocess.run([sys.executable, "scripts/run_tests.py", "--out", str(o), "--only", "backend", "--backend-python", str(vpy)] + extra,
                           cwd=str(fx), capture_output=True, text=True, timeout=600)
        sj = json.loads((o / "summary.json").read_text()) if (o / "summary.json").exists() else {}
        runs[name] = {"exit": p.returncode, "verdict": sj.get("verdict"), "full_validation": sj.get("full_validation"), "complete": sj.get("complete"),
                      "skipped_tests": [x["test"] for x in sj.get("skipped_tests") or []], "platform_exclusions": [x["test"] for x in sj.get("platform_exclusions") or []]}
    ok3 = (runs["skip"]["exit"] == 2 and (runs["skip"]["verdict"] or "").startswith("INCOMPLETE") and runs["skip"]["full_validation"] is False
           and runs["skip"]["skipped_tests"] == ["tests.test_skip::test_skipped"] and runs["skip"]["platform_exclusions"] == []
           and runs["excluded"]["exit"] == 3 and (runs["excluded"]["verdict"] or "").startswith("PASSED WITH DECLARED PLATFORM EXCLUSIONS")
           and runs["excluded"]["full_validation"] is False and runs["excluded"]["complete"] is False and runs["excluded"]["platform_exclusions"] == ["tests.test_skip::test_skipped"])
    policy = json.loads((root / "scripts" / "platform_exclusions.json").read_text())
    named = [t for e in policy["exclusions"] for t in (e["test"], e.get("covered_by")) if t]
    missing = [t for t in named if f"def {t.split('::')[1]}(" not in (root / "backend" / (t.split("::")[0].replace(".", "/") + ".py")).read_text()]
    ok4 = policy["schema"] == "aeris-platform-exclusions/1" and not missing and all("linux" not in e["platforms"] for e in policy["exclusions"])
    return ok1 and ok2 and ok3 and ok4, {"playwright_in_fresh_venv": has_pw, "browser_run": {"exit": p1.returncode, "verdict": s1 and s1["verdict"],
                         "reasons": s1 and sorted({s["reason"] for s in s1["suites"] if s.get("reason")})[:2], "browser_python": bp},
                         "selection_run": {"exit": p2.returncode, "verdict": s2 and s2["verdict"]}, "skipped_case_fixture": runs,
                         "exclusion_policy": {"entries": len(policy["exclusions"]), "tests_not_found": missing}, "stderr_tail": (p1.stderr + p2.stderr)[-300:]}


@step("browser-cancel")
def browser_cancel(root, browser_py):
    if not browser_py:
        return None, {"not_run": "no --browser-python (an interpreter with Playwright) was given; the fresh install has no Playwright"}
    res = {}
    for suite in ("browser_v52", "browser_v3"):
        p = subprocess.run([browser_py, f"tests/{suite}.py"], cwd=str(root / "site"), capture_output=True, text=True, timeout=1800)
        tail = (p.stdout or "").strip().splitlines()
        res[suite] = {"exit": p.returncode, "result": tail[-1] if tail else None, "failed": [l[:200] for l in tail if l.startswith("FAIL")][:5],
                      "cancel_checks": [l[:160] for l in tail if "ancel" in l and l.startswith(("PASS", "FAIL"))][:40]}
    ok = all(r["exit"] == 0 and not r["failed"] and r["result"] and " / " in r["result"] and r["result"].split(" / ")[0] == r["result"].split(" / ")[1].split()[0]
             for r in res.values())
    return ok, {"browser_python": browser_py, **res}





# ---------------------------------------------------------------- v6.0 checks (device stack, drift, firmware host tests, v6 browser suite)
class _Proc:
    """A subprocess whose output lines are collected by a thread; wait_for consumes lines up to the first match."""

    def __init__(self, args, **kw):
        self.p = subprocess.Popen([str(a) for a in args], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, **kw)
        self.lines, self.pos, self.cv = [], 0, threading.Condition()
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        for line in self.p.stdout:
            with self.cv:
                self.lines.append(line.rstrip("\n"))
                self.cv.notify_all()

    def wait_for(self, pred, timeout=20.0, what="line"):
        end = time.time() + timeout
        with self.cv:
            while True:
                while self.pos < len(self.lines):
                    line = self.lines[self.pos]
                    self.pos += 1
                    if pred(line):
                        return line
                left = end - time.time()
                if left <= 0 or self.p.poll() is not None and self.pos >= len(self.lines):
                    raise AssertionError(f"timed out waiting for {what}: " + " | ".join(self.lines[-12:])[-900:])
                self.cv.wait(min(left, 0.2))

    def json_wait(self, pred, timeout=20.0, what="message"):
        def ok(line):
            try:
                m = json.loads(line)
            except ValueError:
                return False
            return isinstance(m, dict) and pred(m)
        return json.loads(self.wait_for(ok, timeout, what))

    def stop(self):
        if self.p.poll() is None:
            self.p.terminate()
            try:
                self.p.wait(5)
            except subprocess.TimeoutExpired:
                self.p.kill()


def _need(cond, what):
    if not cond:
        raise AssertionError(what)


@step("device-journey")
def device_journey(root, port, data):
    vpy = str(root / "backend" / ".venv" / "bin" / "python")
    try:
        mk = subprocess.run(["make", "-C", str(root / "firmware"), "build/host/aeris-hostsim"], capture_output=True, text=True, timeout=900)
        built = mk.returncode == 0
        out = (mk.stdout + mk.stderr)[-600:]
    except OSError as e:
        built, out = False, f"make could not be started: {e}"
    hostsim = root / "firmware" / "build" / "host" / "aeris-hostsim"
    if not built or not hostsim.exists():
        return None, {"not_run": "the synthetic device process could not be built from the package (make, a C compiler and OpenSSL's libcrypto are needed)", "output": out}
    origin = f"http://127.0.0.1:{port}"
    api = Api(origin)
    did, holder = "synthetic-release-0001", "release-validation-holder"
    base = f"/api/v6/devices/{did}"
    tmp = data / "device-journey"
    tmp.mkdir(parents=True, exist_ok=True)
    usb, net, ctl = free_port(), free_port(), free_port()
    det, procs, cs = {"hostsim": "built from the package's firmware sources (SYNTHETIC device: firmware core + device models)"}, {}, None

    def view(pred, what, timeout=15.0):
        end = time.time() + timeout
        while True:
            v = api.get(base)[1]
            if isinstance(v, dict) and pred(v):
                return v
            if time.time() > end:
                raise AssertionError(f"timed out waiting for {what}: {json.dumps(v)[:500]}")
            time.sleep(0.05)

    def wait_cmd(cid, statuses=("completed", "failed", "rejected", "expired", "cancelled"), timeout=20.0):
        end = time.time() + timeout
        while True:
            c = api.get(f"/api/v6/commands/{cid}")[1]
            if c["status"] in statuses:
                return c
            if time.time() > end:
                raise AssertionError(f"command {cid} still {c['status']}: {json.dumps(c['history'][-3:])[:400]}")
            time.sleep(0.05)

    def cmd(action, params=None, ttl=5000, config_hash=None, who=holder, route=None, final=True):
        st, r = api.post(base + "/commands", {"action": action, "params": params, "ttl_ms": ttl, "holder": who, "config_hash": config_hash, "route": route})
        _need(st == 201, f"{action}: HTTP {st} {json.dumps(r)[:300]}")
        return wait_cmd(r["id"]) if final else r

    def bridge():
        return _Proc([vpy, root / "firmware" / "tools" / "synthetic_net_bridge.py", "--device", f"127.0.0.1:{net}", "--backend", f"ws://127.0.0.1:{port}"])

    try:
        st = api.get("/api/v6/status")[1]
        det["api_v6"] = {k: st.get(k) for k in ("enabled", "auth", "reason") if k in st} if isinstance(st, dict) else st
        sim = procs["sim"] = _Proc([hostsim, "--plant", root / "firmware" / "tests" / "fixtures" / "plant_edge.json", "--usb-tcp", usb, "--net-tcp", net,
                                    "--ctl-tcp", ctl, "--device-id", did, "--key-file", tmp / "device-key.pem", "--nvs-file", tmp / "device-nvs.bin"])
        sim.wait_for(lambda ln: ln.startswith("READY"), 10, "the synthetic device READY")
        cs = socket.create_connection(("127.0.0.1", ctl), timeout=5)
        cf = cs.makefile("r")

        def ctl_(line):
            cs.sendall((line + "\n").encode())
            return cf.readline().strip()

        # pairing over the companion (USB route): nothing is registered before the device's local confirmation
        comp = procs["comp"] = _Proc([vpy, "-m", "aeris_backend.companion", "--backend", origin, "--tcp", f"127.0.0.1:{usb}", "--pair", "--name", "release validation"],
                                     cwd=str(root / "backend"))
        dev = comp.json_wait(lambda m: m.get("type") == "device", 15, "the device on the relay")
        _need(dev.get("device_id") == did and dev.get("synthetic") is True and dev.get("paired_to_you") is False, f"relay device {dev}")
        comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") == "waiting_for_local_confirmation", 10, "the local confirmation request")
        _need(api.get("/api/v6/devices")[1]["devices"] == [], "a device was registered before its local confirmation")
        _need(ctl_("arm-press").startswith("ok"), "local press")
        paired = comp.json_wait(lambda m: m.get("type") == "pairing" and m.get("status") in ("paired", "failed"), 10, "the pairing outcome")
        _need(paired["status"] == "paired", f"pairing {paired}")
        v = view(lambda v: v.get("connected") and v.get("state") is not None, "the device session")
        _need(v["routes"] == ["companion"] and v["synthetic"] is True and v["dev_hello"]["board"]["kind"] == "emulator", f"device view {json.dumps(v)[:300]}")
        det["pairing"] = {"device_id": did, "route": v["routes"], "synthetic": v["synthetic"], "board_kind": v["dev_hello"]["board"]["kind"],
                          "registered_only_after_local_confirmation": True}
        # lease, measurements, calibration from the command log
        st, r = api.post(base + "/commands", {"action": "identify", "holder": holder})
        _need(st == 409 and r["error"]["code"] == "lease_required", f"a command without the lease: HTTP {st}")
        _need(api.post(base + "/lease", {"holder": holder})[1]["epoch"] == 1, "lease epoch 1")
        _need(cmd("identify")["status"] == "completed", "identify")
        _need(cmd("diagnostics")["status"] == "completed", "diagnostics")
        imu = cmd("calibrate_imu", {"seconds": 2})
        _need(imu["status"] == "completed", f"calibrate_imu {imu['history'][-2:]}")
        axes = []
        for face in ("+z", "+x"):
            _need(ctl_(f"face {face}").startswith("ok"), "face")
            time.sleep(0.3)
            a = cmd("calibrate_axes", {"seconds": 1, "face": face})
            _need(a["status"] == "completed" and a["result"]["face"] == face, f"calibrate_axes {face}: {a['history'][-2:]}")
            axes.append(a)
        _need(ctl_("hold").startswith("ok"), "hold")
        enc = cmd("check_encoders", {"seconds": 3}, final=False)
        time.sleep(0.6)
        for i in range(3):
            ctl_(f"spin {i} 20")
        enc = wait_cmd(enc["id"])
        _need(enc["status"] == "completed", f"check_encoders {enc['history'][-2:]}")
        st, cal = api.post(base + "/calibrations", {"commands": {"imu": imu["id"], "axes": [a["id"] for a in axes], "encoders": enc["id"]}})
        _need(st == 201, f"calibration HTTP {st} {json.dumps(cal)[:300]}")
        _need(cal["document"]["wheel_directions_confirmed"] is True and {e["origin"] for e in cal["document"]["evidence"]} == {"backend-command-log"}, "calibration evidence")
        det["calibration"] = {"id": cal["id"], "to_body": cal["document"]["imu"]["to_body"], "wheel_directions_confirmed": True}
        # approved configuration, self-test, an experiment that waits for the local enable
        st, cfg = api.post(base + "/configs", {"recipe": "edge-hold-10s", "calibration": cal["id"]})
        _need(st in (200, 201), f"config HTTP {st}")
        H = cfg["id"]
        st, r = api.post(base + "/commands", {"action": "start_experiment", "holder": holder, "config_hash": H, "params": {"duration_s": 3}})
        _need(st == 409 and r["error"]["code"] == "config_not_applied", f"an experiment before apply_config: HTTP {st}")
        _need(cmd("apply_config", config_hash=H)["status"] == "completed", "apply_config")
        view(lambda v: (v["state"] or {}).get("config_hash") == H, "the configuration applied")
        _need(cmd("self_test", ttl=8000)["status"] == "completed", "self_test")
        view(lambda v: (v["state"] or {}).get("state") == "READY", "READY")
        _need(api.post(base + "/recordings/start", {"name": "release validation edge"})[0] == 201, "recording start")
        ex = cmd("start_experiment", {"duration_s": 3}, ttl=10000, config_hash=H, final=False)
        c = wait_cmd(ex["id"], statuses=("executing", "failed", "rejected", "expired"))
        _need(c["status"] == "executing" and "local enable" in (c["history"][-1].get("reason") or ""), f"waiting for the local enable: {c['history'][-1:]}")
        time.sleep(1.0)
        _need((api.get(base)[1]["state"] or {}).get("state") == "READY", "the cube moved without the local enable")
        _need(ctl_("arm-press").startswith("ok"), "local enable")
        done = wait_cmd(ex["id"], timeout=15)
        _need(done["status"] == "completed" and done["result"]["ended"] == "duration reached", f"experiment {done['history'][-3:]}")
        time.sleep(0.5)
        st, rec = api.post(base + "/recordings/stop")
        _need(st == 201 and rec["synthetic"] is True and rec["device_link"]["config_hash"] == H and rec["quality"]["n"] > 50, f"recording HTTP {st}")
        det["experiment"] = {"config_hash": H, "waited_for_local_enable": True, "ended": done["result"]["ended"], "recording": rec["id"],
                             "recording_synthetic": rec["synthetic"], "samples": rec["quality"]["n"]}
        # Simulate My Cube and the comparison
        st, tw = api.post("/api/v6/twin/simulate", {"device_id": did, "recipe": "edge-hold-10s", "calibration": cal["id"]})
        _need(st == 202, f"twin HTTP {st} {json.dumps(tw)[:300]}")
        j = api.job(tw["job"]["id"], timeout=180)
        _need(j and j["state"] == "complete", f"twin job {j}")
        st, cp = api.post("/api/v6/twin/compare", {"run_id": j["result_ref"]["id"], "recording_id": rec["id"]})
        _need(st == 200 and cp["synthetic"] is True and cp["evidence"]["admissible_as_validation_evidence"] is False and cp["result"]["errors"] == [], f"compare HTTP {st}")
        _need(cp["result"]["signals"]["attitude"]["n"] > 50, "the comparison's attitude overlap")
        det["twin"] = {"run": j["result_ref"]["id"], "compared_signals": sorted(cp["result"]["signals"]), "admissible_as_validation_evidence": False}
        # export and reimport
        doc = api.get(f"/api/v1/hardware/recordings/{rec['id']}/export?format=json")[1]
        st, back = api.post("/api/v1/hardware/recordings", doc)
        _need(st == 201 and back["content_hash"] == rec["content_hash"] and back["synthetic"] is True, f"reimport HTTP {st}")
        st, nd = api.get(f"/api/v1/hardware/recordings/{rec['id']}/export?format=ndjson", raw=True)
        hello = json.loads(nd.splitlines()[0])
        _need(st == 200 and hello["type"] == "hello" and hello["synthetic"] is True and hello["device"]["kind"] == "emulator", "NDJSON hello")
        det["export"] = {"reimported_same_content_hash": True, "ndjson_hello_synthetic": True}
        # the gateway route continues the telemetry session; the companion leaves
        br = procs["bridge"] = bridge()
        view(lambda v: v["routes"] == ["companion", "gateway"], "the gateway route authenticated")
        _need(cmd("identify", route="gateway")["status"] == "rejected", "an observer route must not command while the USB host is attached")
        _need(cmd("stop", route="gateway", who=None)["status"] == "completed", "stop is always accepted")
        comp.stop()
        view(lambda v: v["routes"] == ["gateway"], "the companion gone")
        time.sleep(0.5)
        _need(cmd("identify", route="gateway")["status"] == "completed", "the gateway supervises once the USB host has left")
        v = view(lambda v: v.get("telemetry_route") == "gateway" and len(v.get("telemetry_catchups") or []) >= 1, "telemetry continued on the gateway")
        cu = v["telemetry_catchups"][-1]
        _need(cu["ended"] == "complete" and cu["missing"] == 0, f"catch-up {cu}")
        det["gateway"] = {"routes": v["routes"], "telemetry_catchup": cu}
        # revocation
        _need(api.post(base + "/revoke")[0] == 200, "revoke")
        br.wait_for(lambda ln: ln.startswith("bridge ended"), 10, "the revoked connection closed")
        br.stop()
        br = procs["bridge"] = bridge()
        line = br.wait_for(lambda ln: ln.startswith("bridge ended"), 15, "the refused authentication")
        _need("4401" in line and api.get(base)[0] == 404, f"a revoked credential: {line}")
        det["revocation"] = {"refused": line.strip()[:120]}
        return True, det
    except AssertionError as e:
        det["failed_at"] = str(e)[:900]
        return False, det
    finally:
        if cs is not None:
            try:
                cs.sendall(b"quit\n")
            except OSError:
                pass
        for k in ("bridge", "comp", "sim"):
            if k in procs:
                procs[k].stop()


def _suite_step(root, only, timeout=1800):
    """run_tests.py --only <only> in the extracted package with its fresh install: passed / NOT RUN (a missing tool;
    nothing failed) / failed."""
    vpy = root / "backend" / ".venv" / "bin" / "python"
    out = root / "release-validation-test-logs" / only.replace(":", "-")
    p = subprocess.run([sys.executable, "scripts/run_tests.py", "--out", str(out), "--only", only, "--backend-python", str(vpy)],
                       cwd=str(root), capture_output=True, text=True, timeout=timeout)
    s = json.loads((out / "summary.json").read_text()) if (out / "summary.json").exists() else None
    if not s or not s.get("suites"):
        return False, {"exit": p.returncode, "stderr": (p.stderr or p.stdout)[-600:]}
    d = s["suites"][0]
    log = (out / d["log"]).read_text(errors="replace") if d.get("log") else ""
    det = {"exit": p.returncode, "status": d["status"], "reason": d["reason"], "counts": d["counts"],
           "lines": [ln[:220] for ln in log.splitlines() if ln.startswith(("PASS", "FAIL", "NOT RUN", "# firmware core tests"))][:40]}
    if p.returncode == 0 and d["status"] == "passed":
        return True, det
    if d["status"] in ("incomplete", "not run") and not (d["counts"] or {}).get("failed"):
        return None, det
    return False, det


@step("drift")
def drift(root):
    return _suite_step(root, "drift")


@step("firmware-host")
def firmware_host(root):
    return _suite_step(root, "firmware:host")


@step("browser-v6")
def browser_v6(root, browser_py):
    if not browser_py:
        return None, {"not_run": "no --browser-python (an interpreter with Playwright) was given; the fresh install has no Playwright"}
    p = subprocess.run([browser_py, "tests/browser_v6.py"], cwd=str(root / "site"), capture_output=True, text=True, timeout=1800,
                       env=dict(os.environ, AERIS_PYTHON=str(root / "backend" / ".venv" / "bin" / "python")))
    lines = (p.stdout or "").strip().splitlines()
    res = lines[-1] if lines else None
    det = {"browser_python": browser_py, "exit": p.returncode, "result": res, "failed": [ln[:200] for ln in lines if ln.startswith("FAIL")][:8],
           "not_run": [ln[:200] for ln in lines if ln.startswith("NOT RUN")][:8]}
    ok = p.returncode == 0 and not det["failed"] and not det["not_run"] and res and " / " in res and res.split(" / ")[0] == res.split(" / ")[1].split()[0]
    return ok, det


@step("backup")
def backup(root, data):
    vpy = str(root / "backend" / ".venv" / "bin" / "python")
    out = data / "backups" / "release-validation.sqlite3"
    b = subprocess.run([vpy, "-m", "aeris_backend.tools.dbtool", "backup", "--db", str(data / "aeris.sqlite3"), "--out", str(out)], capture_output=True, text=True, cwd=str(root / "backend"), timeout=300)
    r = subprocess.run([vpy, "-m", "aeris_backend.tools.dbtool", "restore", "--backup", str(out), "--db", str(data / "restored" / "aeris.sqlite3")], capture_output=True, text=True, cwd=str(root / "backend"), timeout=300)
    bj, rj = json.loads(b.stdout or "{}"), json.loads(r.stdout or "{}")
    return b.returncode == 0 and r.returncode == 0 and bj.get("verified") and rj.get("verified"), {
        "backup_tables": (bj.get("verify") or {}).get("tables"), "restored_schema": (rj.get("schema") or {}).get("schema_version"), "datasets": (rj.get("verify") or {}).get("datasets")}


@step("stop")
def stop(root, data):
    p = subprocess.run(["bash", str(root / "scripts" / "stop.sh"), "--data", str(data)], capture_output=True, text=True, timeout=120)
    left = list((data / "run").glob("*.pid"))
    return p.returncode == 0 and not left, {"output": p.stdout.strip(), "pid_files_left": [str(x) for x in left]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", required=True)
    ap.add_argument("--python", default="python3.12" if shutil.which("python3.12") else "python3")
    ap.add_argument("--out", default="release-validation.json")
    ap.add_argument("--keep", action="store_true", help="keep the temporary directory")
    ap.add_argument("--expect-top", default=None, help="the archive's single top-level folder must have this name (e.g. aeris-v6.0)")
    ap.add_argument("--browser-python", default=None, help="an interpreter with Playwright for the browser-cancel step (else that step is NOT RUN)")
    a = ap.parse_args()
    browser_py = None
    if a.browser_python:
        browser_py = os.path.abspath(a.browser_python) if os.sep in a.browser_python else shutil.which(a.browser_python)
    EXPECT_TOP["name"] = a.expect_top
    work = Path(tempfile.mkdtemp(prefix="aeris-release-"))
    results.update(zip=os.path.abspath(a.zip), workdir=str(work), started=_dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"))
    data = work / "data"
    port, eport = free_port(), free_port()
    root = None
    try:
        check_archive(a.zip)
        ok, d = extract(a.zip, work / "x")
        root = Path(d["root"]) if ok else None
        if root and install(root, a.python)[0] and start(root, data, port, eport)[0]:
            api = Api(f"http://127.0.0.1:{port}")
            ctx = {}
            if experiment(api, ctx)[0]:
                reproduce(api, ctx)
                restart(api, root, data, port, eport, ctx)
            sweep_cancel(api, ctx)
            telemetry(api, eport)
            telemetry_provenance(api, eport, data, ctx)
            telemetry_restart(api, root, data, port, eport)
            telemetry_units(api, data)
            telemetry_generations(root, api, ctx)
            device_journey(root, port, data)
            test_runner(root)
            drift(root)
            firmware_host(root)
            browser_cancel(root, browser_py)
            browser_v6(root, browser_py)
            backup(root, data)
            stop(root, data)
    finally:
        if root and (data / "run").exists() and list((data / "run").glob("*.pid")):
            subprocess.run(["bash", str(root / "scripts" / "stop.sh"), "--data", str(data)], capture_output=True, timeout=120)
        results["finished"] = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
        results["all_passed"] = bool(results["steps"]) and all(s["passed"] for s in results["steps"]) and len(results["steps"]) == len(STEPS)
        results["not_executed"] = [n for n in STEPS if n not in {s["step"] for s in results["steps"]}] + [s["step"] for s in results["steps"] if s.get("not_run")]
        results["failed_steps"] = [s["step"] for s in results["steps"] if not s["passed"] and not s.get("not_run")]
        results["exit_code"] = 0 if results["all_passed"] else 1 if results["failed_steps"] else 2
        results["steps_expected"] = len(STEPS)
        Path(a.out).write_text(json.dumps(results, indent=1))
        if not a.keep:
            shutil.rmtree(work, ignore_errors=True)
    print(f"\n{sum(s['passed'] for s in results['steps'])} / {len(STEPS)} release validation steps passed"
          + (f"; not executed: {', '.join(results['not_executed'])}" if results["not_executed"] else "")
          + (f"; failed: {', '.join(results['failed_steps'])}" if results["failed_steps"] else "") + f" → {a.out}")
    return results["exit_code"]


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Execute the CI workflow's jobs on THIS machine, step by step, each job in its own clean clone (v5.1, review F3).

    python3 scripts/ci_local.py --python /path/to/python3.12 [--node /path/to/node] [--jobs backend,javascript]
                                [--workflow .github/workflows/ci.yml] [--ref HEAD] [--out ci-local]

This is NOT a CI service run and is never reported as one. It runs each job's `run:` steps exactly as they are written
in the workflow, in a fresh `git clone` of the COMMITTED tree at --ref (uncommitted changes are not included), with
GitHub's default shell for Linux runners (bash --noprofile --norc -eo pipefail). The `uses:` steps are provided by
this machine instead of by GitHub:
  actions/checkout         the clean clone (the working directory of every step; $GITHUB_WORKSPACE)
  actions/setup-python     --python, first on PATH as python and python3 (its version must match the workflow's)
  actions/setup-node       --node (default: node on PATH), first on PATH as node (major version must match)
  actions/upload-artifact  recorded; the listed paths are copied to <out>/<job>/artifacts
A job stops at its first failing step, as on GitHub. Writes <out>/ci-local.json (per job and step: the command, exit
code, seconds and log file) and <out>/CI-LOCAL.md. Exit code 0 only when every step of every selected job succeeded.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


def sh(cmd, cwd=None, **kw):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, **kw)


def version_of(exe, arg):
    r = sh([exe, arg])
    return (r.stdout or r.stderr).strip().split()[-1] if r.returncode == 0 else None


def matrix_value(job, text):
    """'${{ matrix.python }}' → the job matrix's value. Only single-combination matrices are supported (this workflow's);
    anything else is refused rather than run partially."""
    t = text.strip()
    if t.startswith("${{") and "matrix." in t:
        key = t.split("matrix.", 1)[1].split("}}", 1)[0].strip()
        vals = (((job.get("strategy") or {}).get("matrix") or {}).get(key)) or []
        if len(vals) != 1:
            raise SystemExit(f"matrix.{key} has {len(vals)} values; ci_local.py runs single-combination matrices only")
        return str(vals[0])
    return t


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--workflow", default=str(ROOT / ".github" / "workflows" / "ci.yml"))
    ap.add_argument("--jobs", default="", help="comma-separated job ids (default: all)")
    ap.add_argument("--ref", default="HEAD")
    ap.add_argument("--python", required=True, help="interpreter standing in for actions/setup-python")
    ap.add_argument("--node", default=shutil.which("node"))
    ap.add_argument("--out", default=str(ROOT / "ci-local"))
    ap.add_argument("--keep", action="store_true", help="keep the clones")
    a = ap.parse_args(argv)
    start = os.getcwd()
    wf_path = Path(os.path.abspath(os.path.join(start, a.workflow)))
    wf = yaml.safe_load(wf_path.read_text())
    jobs = wf["jobs"]
    want = [j.strip() for j in a.jobs.split(",") if j.strip()] or list(jobs)
    unknown = [j for j in want if j not in jobs]
    if unknown:
        print(f"unknown job(s): {', '.join(unknown)} (workflow jobs: {', '.join(jobs)})", file=sys.stderr)
        return 64
    out = Path(os.path.abspath(os.path.join(start, a.out)))
    out.mkdir(parents=True, exist_ok=True)
    py = os.path.abspath(os.path.join(start, a.python)) if os.sep in a.python else shutil.which(a.python)
    node = os.path.abspath(os.path.join(start, a.node)) if a.node and os.sep in a.node else (shutil.which(a.node) if a.node else None)
    commit = sh(["git", "rev-parse", a.ref], cwd=ROOT).stdout.strip()
    dirty = bool(sh(["git", "status", "--porcelain", "--untracked-files=no"], cwd=ROOT).stdout.strip())
    report = {"what": "local execution of the CI workflow's run steps from clean clones — NOT a CI service run", "when": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"),
              "workflow": str(wf_path.relative_to(ROOT)) if wf_path.is_relative_to(ROOT) else str(wf_path), "commit": commit, "ref": a.ref,
              "uncommitted_changes_in_the_source_checkout": dirty, "machine": {"platform": platform.platform(), "machine": platform.machine()},
              "setup_python": {"path": py, "version": version_of(py, "--version") if py else None}, "setup_node": {"path": node, "version": version_of(node, "--version") if node else None},
              "jobs": []}
    all_ok = True
    for jid in want:
        job = jobs[jid]
        jdir = out / jid
        if jdir.exists():
            shutil.rmtree(jdir)
        jdir.mkdir(parents=True)
        clone = Path(tempfile.mkdtemp(prefix=f"aeris-ci-{jid}-")) / "work"
        r = sh(["git", "clone", "--quiet", "--no-hardlinks", str(ROOT), str(clone)])
        r2 = sh(["git", "checkout", "--quiet", commit], cwd=clone) if r.returncode == 0 else r
        jrep = {"job": jid, "name": job.get("name", jid), "clone": str(clone), "steps": [], "ok": True}
        report["jobs"].append(jrep)
        if r.returncode or r2.returncode:
            jrep.update(ok=False, error="git clone/checkout failed: " + (r.stderr or r2.stderr)[-300:])
            all_ok = False
            continue
        bindir = Path(tempfile.mkdtemp(prefix="aeris-ci-bin-"))
        env = {k: v for k, v in os.environ.items() if not k.startswith(("GITHUB_", "AERIS_", "PLAYWRIGHT_PYTHON", "VIRTUAL_ENV"))}
        env.update(CI="true", GITHUB_WORKSPACE=str(clone), HOME=os.environ.get("HOME", str(clone)))
        for k, st_ in enumerate(job.get("steps", []), 1):
            name = st_.get("name") or st_.get("uses") or (st_.get("run") or "").strip().splitlines()[0]
            srec = {"n": k, "name": name, "uses": st_.get("uses"), "run": st_.get("run"), "exit_code": None, "seconds": 0, "log": None, "ok": True}
            jrep["steps"].append(srec)
            if not jrep["ok"]:
                srec.update(ok=None, note="not executed: an earlier step failed")
                continue
            uses = (st_.get("uses") or "").split("@")[0]
            t0 = time.time()
            if uses == "actions/checkout":
                srec["note"] = f"clean clone of {commit[:12]} ({'uncommitted changes excluded' if dirty else 'working tree was clean'})"
            elif uses == "actions/setup-python":
                want_v = matrix_value(job, str((st_.get("with") or {}).get("python-version", "")))
                have = report["setup_python"]["version"] or ""
                ok = bool(py) and (not want_v or have == want_v or have.startswith(want_v + "."))
                for n in ("python", "python3"):
                    (bindir / n).unlink(missing_ok=True)
                    if py:
                        (bindir / n).symlink_to(py)
                srec.update(ok=ok, note=f"provided by this machine: {py} (Python {have}); workflow asks for {want_v or 'any'}")
            elif uses == "actions/setup-node":
                want_v = matrix_value(job, str((st_.get("with") or {}).get("node-version", "")))
                have = (report["setup_node"]["version"] or "").lstrip("v")
                ok = bool(node) and (not want_v or have.split(".")[0] == want_v.split(".")[0])
                (bindir / "node").unlink(missing_ok=True)
                if node:
                    (bindir / "node").symlink_to(node)
                srec.update(ok=ok, note=f"provided by this machine: {node} (v{have}); workflow asks for {want_v or 'any'}")
            elif uses == "actions/upload-artifact":
                paths = [p.strip() for p in str((st_.get("with") or {}).get("path", "")).splitlines() if p.strip()]
                copied = []
                for p in paths:
                    src = clone / p
                    if src.exists():
                        dst = jdir / "artifacts" / p
                        if src.is_dir():
                            shutil.copytree(src, dst, dirs_exist_ok=True)
                        else:
                            dst.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(src, dst)
                        copied.append(p)
                srec.update(note=f"artifacts copied locally: {copied or 'none present'}")
            elif st_.get("run") is not None:
                script = jdir / f"step{k}.sh"
                script.write_text(st_["run"])
                log = jdir / f"step{k}.log"
                run_env = dict(env, PATH=str(bindir) + os.pathsep + env.get("PATH", ""))
                with open(log, "w", encoding="utf-8") as fh:
                    fh.write(f"$ {st_['run'].strip()}\n(working directory: $GITHUB_WORKSPACE = {clone})\n\n")
                    fh.flush()
                    p = subprocess.run(["bash", "--noprofile", "--norc", "-eo", "pipefail", str(script)], cwd=clone, env=run_env, stdout=fh, stderr=subprocess.STDOUT)
                srec.update(exit_code=p.returncode, ok=p.returncode == 0, log=str(log.relative_to(out)))
                tail = log.read_text(encoding="utf-8", errors="replace").strip().splitlines()
                srec["last_lines"] = tail[-6:]
            else:
                srec.update(ok=False, note=f"unsupported step: {st_}")
            srec["seconds"] = round(time.time() - t0, 1)
            if srec["ok"] is False:
                jrep["ok"] = False
        # the test summary each job wrote (run_tests.py), when there is one
        s = next((p for p in (clone / "ci-test-logs" / "summary.json", clone / "test-logs" / "summary.json") if p.exists()), None)
        if s is not None:
            summ = json.loads(s.read_text())
            jrep["run_tests"] = {"verdict": summ.get("verdict"), "exit_code": summ.get("exit_code"), "totals": summ.get("totals"),
                                 "complete": summ.get("complete"), "full_validation": summ.get("full_validation"),
                                 "skipped_tests": [f"{x['suite']}::{x['test']} ({x['reason']})" for x in summ.get("skipped_tests") or []],
                                 "suites": {x["suite"]: x["status"] for x in summ.get("suites", [])}}
        all_ok = all_ok and jrep["ok"]
        if not a.keep:
            shutil.rmtree(clone.parent, ignore_errors=True)
        shutil.rmtree(bindir, ignore_errors=True)
    report["all_steps_succeeded"] = all_ok
    (out / "ci-local.json").write_text(json.dumps(report, indent=1))
    md = ["# Local execution of the CI workflow (not a CI service run)", "",
          f"{report['when']} · commit `{commit}` · {report['machine']['platform']} · setup-python → `{py}` ({report['setup_python']['version']}) · setup-node → `{node}` ({report['setup_node']['version']})", ""]
    for j in report["jobs"]:
        md.append(f"## {j['job']} — {'all steps succeeded' if j['ok'] else 'FAILED'}")
        md.append("")
        md += ["| # | Step | Result | Seconds | Log |", "|---:|---|---|---:|---|"]
        for s_ in j["steps"]:
            res = "ok" if s_["ok"] else "not executed" if s_["ok"] is None else f"FAILED (exit {s_['exit_code']})"
            md.append(f"| {s_['n']} | {s_['name'][:90]} | {res}{(' — ' + s_['note']) if s_.get('note') else ''} | {s_['seconds']} | {s_['log'] or '—'} |")
        if j.get("run_tests"):
            md += ["", f"run_tests.py: **{j['run_tests']['verdict']}** · exit code {j['run_tests']['exit_code']} · totals {j['run_tests']['totals']}"
                   + (f" · skipped test cases: {'; '.join(j['run_tests']['skipped_tests'])}" if j["run_tests"].get("skipped_tests") else "")]
        md.append("")
    md.append(f"**All steps succeeded:** {'yes' if all_ok else 'no'}.")
    (out / "CI-LOCAL.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())

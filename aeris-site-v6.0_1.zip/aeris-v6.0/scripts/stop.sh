#!/usr/bin/env bash
# AERIS · stop what scripts/start.sh started (SIGTERM, then wait). The backend shuts down cleanly: the telemetry
# source is disconnected, the job manager stops, the database is closed and its lock released; unfinished jobs are
# recovered at the next start (AERIS_RESTART_POLICY, default resume).
#   scripts/stop.sh [--data DIR]
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DATA="${AERIS_DATA_DIR:-$ROOT/data}"
[ "${1:-}" = "--data" ] && DATA="$2"
for name in emulator backend; do
  f="$DATA/run/$name.pid"
  [ -f "$f" ] || continue
  pid="$(cat "$f")"
  if kill -0 "$pid" 2>/dev/null; then
    kill -TERM "$pid"
    for i in $(seq 1 150); do kill -0 "$pid" 2>/dev/null || break; sleep 0.2; done
    if kill -0 "$pid" 2>/dev/null; then echo "$name (pid $pid) did not stop within 30 s; not killed — check $DATA/logs/$name.log" >&2; continue; fi
    echo "stopped $name (pid $pid)"
  fi
  rm -f "$f"
done

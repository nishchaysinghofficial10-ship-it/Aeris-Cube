#!/usr/bin/env python3
"""Check that a release archive and a git bundle hold the same source (standard library + git).

    python3 scripts/compare_archive_bundle.py --zip aeris-site-v5.1.zip --bundle aeris-site-v5.1-git.bundle [--ref v5.1] [--out FILE]

Verifies the bundle (`git bundle verify`), clones it into a new temporary directory, checks out --ref and compares
every file tracked at that commit with the archive's entries (the archive's single top-level folder removed): files
only in the archive, files only in the commit, and files whose bytes differ. Prints and writes a JSON result; exit
code 0 only when the bundle verifies and the two hold exactly the same files with the same bytes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", required=True)
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--ref", default="v5.1")
    ap.add_argument("--out", default=None)
    a = ap.parse_args(argv)
    res = {"zip": os.path.abspath(a.zip), "bundle": os.path.abspath(a.bundle), "ref": a.ref}
    with open(a.zip, "rb") as f:
        res["zip_sha256"] = hashlib.sha256(f.read()).hexdigest()
    with open(a.bundle, "rb") as f:
        res["bundle_sha256"] = hashlib.sha256(f.read()).hexdigest()
    tmp = tempfile.mkdtemp(prefix="aeris-bundle-check-")
    try:
        empty = os.path.join(tmp, "empty")                      # `git bundle verify` needs a repository; an empty one
        subprocess.run(["git", "init", "-q", empty], capture_output=True)   # also proves the bundle needs no prerequisites
        v = subprocess.run(["git", "bundle", "verify", os.path.abspath(a.bundle)], cwd=empty, capture_output=True, text=True)
        res["bundle_verifies"] = v.returncode == 0
        res["bundle_verify_output"] = (v.stdout + v.stderr).strip().splitlines()[-3:]
        res["bundle_refs"] = subprocess.run(["git", "bundle", "list-heads", os.path.abspath(a.bundle)], capture_output=True, text=True).stdout.split("\n")[:20]
        work = os.path.join(tmp, "clone")
        c = subprocess.run(["git", "clone", "--quiet", "--no-checkout", os.path.abspath(a.bundle), work], capture_output=True, text=True)
        co = subprocess.run(["git", "checkout", "--quiet", a.ref], cwd=work, capture_output=True, text=True) if c.returncode == 0 else c
        if co.returncode != 0:
            res.update(ok=False, error=(c.stderr + co.stderr)[-500:])
        else:
            res["commit"] = subprocess.run(["git", "rev-parse", "HEAD"], cwd=work, capture_output=True, text=True).stdout.strip()
            res["commits_in_history"] = int(subprocess.run(["git", "rev-list", "--count", "HEAD"], cwd=work, capture_output=True, text=True).stdout.strip() or 0)
            tracked = [x for x in subprocess.run(["git", "ls-files", "-z"], cwd=work, capture_output=True, text=True).stdout.split("\0") if x]
            with zipfile.ZipFile(a.zip) as z:
                names = [n for n in z.namelist() if not n.endswith("/")]
                tops = {n.split("/", 1)[0] for n in names}
                prefix = (tops.pop() + "/") if len(tops) == 1 else ""
                entries = {n[len(prefix):]: n for n in names}
                only_zip = sorted(set(entries) - set(tracked))
                only_git = sorted(set(tracked) - set(entries))
                differ = []
                for rel in sorted(set(entries) & set(tracked)):
                    with open(os.path.join(work, rel), "rb") as f:
                        if f.read() != z.read(entries[rel]):
                            differ.append(rel)
            res.update(top_folder=prefix.rstrip("/"), archive_files=len(entries), tracked_files=len(tracked), only_in_archive=only_zip,
                       only_in_commit=only_git, different_bytes=differ,
                       ok=res["bundle_verifies"] and not only_zip and not only_git and not differ)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    text = json.dumps(res, indent=1)
    if a.out:
        with open(a.out, "w") as f:
            f.write(text)
    print(text)
    return 0 if res.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())

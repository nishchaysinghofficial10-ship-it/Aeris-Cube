#!/usr/bin/env bash
# AERIS · install the research backend into backend/.venv (Linux; macOS expected to work, not tested).
#   scripts/install.sh [--python python3.12] [--plots]
# Installs the pinned dependencies (backend/requirements-lock.txt) and the backend itself (editable).
# --plots also installs matplotlib for the study figures (studies/requirements-plots.txt).
# Nothing is downloaded except Python packages from the package index; no accounts or credentials are needed.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON:-}"
PLOTS=0
while [ $# -gt 0 ]; do
  case "$1" in
    --python) PY="$2"; shift 2 ;;
    --plots) PLOTS=1; shift ;;
    -h|--help) sed -n '2,7p' "$0"; exit 0 ;;
    *) echo "unknown option $1" >&2; exit 2 ;;
  esac
done
if [ -z "$PY" ]; then
  for c in python3.12 python3.13 python3; do
    if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
  done
fi
[ -n "$PY" ] || { echo "error: no python3 found; install Python 3.12 or newer" >&2; exit 1; }
"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)' || {
  echo "error: $("$PY" -V 2>&1) is too old; the backend needs Python 3.12 or newer (backend/pyproject.toml)" >&2; exit 1; }
VENV="$ROOT/backend/.venv"
if [ ! -x "$VENV/bin/python" ]; then
  echo "creating $VENV with $("$PY" -V 2>&1)"
  "$PY" -m venv "$VENV"
fi
"$VENV/bin/python" -m pip install --quiet --upgrade pip
"$VENV/bin/python" -m pip install --quiet -r "$ROOT/backend/requirements-lock.txt"
"$VENV/bin/python" -m pip install --quiet --no-deps -e "$ROOT/backend"
if [ "$PLOTS" = 1 ]; then "$VENV/bin/python" -m pip install --quiet -r "$ROOT/studies/requirements-plots.txt"; fi
"$VENV/bin/python" - <<'PYEOF'
import sys, fastapi, numpy, scipy
from aeris_backend.version import software_versions
v = software_versions()
print("installed:", "Python", sys.version.split()[0], "·", v.get("engine"), "· backend", v.get("backend"), "· FastAPI", fastapi.__version__, "· NumPy", numpy.__version__, "· SciPy", scipy.__version__)
PYEOF
if command -v node >/dev/null 2>&1; then echo "node $(node -v) found (needed only for the JavaScript test suites)"; else echo "note: Node.js not found; it is needed only for the JavaScript tests"; fi
echo "done. Start with: scripts/start.sh   (stop: scripts/stop.sh)"

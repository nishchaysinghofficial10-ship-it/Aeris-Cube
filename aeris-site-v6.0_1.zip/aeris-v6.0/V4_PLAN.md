# AERIS v4 · architecture map, requirements checklist, baseline

Working notes for the v4 task ("complete the research backend and fix the integration gaps").
Status markers: `[ ]` open · `[~]` in progress · `[x]` implemented and tested · `[!]` externally blocked.

## 0. Starting point (recorded before any edit)

- Source: `aeris-site-v3.zip`, sha256 `c3d2f8f21446d672edfe786491a17e186c327abb4d2b9da53420f8a703d943e1`
  (untouched copy extracted to a separate reference directory; the ZIP itself is never overwritten).
- Baseline tests on the untouched v3 source (Node 22, Python 3.12, Playwright Chromium + SwiftShader):

| Suite | Result |
|---|---|
| numerics.test.js | 38 / 38 |
| runs.test.js | 14 / 14 |
| assistant.test.js | 9 / 9 |
| platform.test.js | 16 / 16 |
| engine.test.js | 9 / 9 |
| service.test.js | 19 / 19 |
| ui.test.js | 16 / 16 |
| schema.test.js | 6 / 6 |
| **JS total** | **127 / 127** |
| browser_check.py (v2 behaviour, real browser) | 50 / 50 checks |
| browser_v3.py (v3 platform, real browser) | 47 / 47 checks |

## 1. Architecture map (v3 as found)

```
site/index.html  (built from build/templates by build/build_index.py)
 ├─ js/core.js            AERIS_TWIN 0.3.0: params, derive, CARE/LQR, designTilt/designYaw,
 │                        massProps, normalizeConfig (drops unknown fields), validateConfig
 │                        (browser limits mixed with physics checks), simulate → simEdge / simCorner
 │                        (RK4 + ZOH at fs), assess (one outcome rule set), buildTimeline
 ├─ js/runs.js            AERIS_RUNS: fromSimulation, validateRecord (uses TWIN.validateConfig),
 │                        completeRecord (re-derives derived/design with the BROWSER model), save/load,
 │                        import/export, CSV, reproduce (browser only)
 ├─ js/platform/          schema (normalizeRun rev 1.1), ids, jobs (state machine), sweep (definition,
 │                        validate via TWIN.validateConfig, expand via TWIN.normalizeConfig, analyze),
 │                        service (mode routing; runControllerSet uses TWIN.normalizeConfig),
 │                        compare, validation (sim↔hw), controllers (descriptions), events, examples
 ├─ js/adapters/          local-simulator (DEMO), research-api (REST + polling; WS URL only),
 │                        mock-research-backend (protocol mock), hardware-telemetry (unavailable,
 │                        lenient parseFrame), replay
 └─ js/workspace.js, js/ui/*   Lab UI; validateDraft/runDraft/runControllerSet call TWIN.validateConfig
```

Browser conventions reused by the backend (verified in core.js):
- quaternion `[w, x, y, z]`, `R = rot(q)` maps body → world; world z up; body origin at the pivot
  vertex O, body axes along the three cube edges meeting at O; wheel i spins about body axis i.
- relative wheel speeds Ω (wheel w.r.t. body). `ThO` = inertia about O with wheels locked
  (base `k_J·m·a²` about the base COM + Steiner + point masses). `Θ̂ = ThO − J_w·I`.
- corner: `Θ̂ ω̇ = −ω×(ThO ω + J_w Ω) + M rc×g_B + τ_ext − (T − f)`, `Ω̇ = (T − f)/J_w − ω̇`.
- edge: hinge about body x; `Θ̂_xx θ̈ = M g l sin(θ+β) + τ_ext,x − (T_x − f_x)`.
- RK4 with a zero-order-hold command at the loop rate; motor torque limited by current, back-EMF,
  speed cut-off and health; friction `c_v Ω + c_c tanh Ω`; seeded mulberry32 + Box–Muller.

## 2. Target architecture (v4)

```
backend/aeris_backend/
  config/       aeris-config/1 rev 1.1 model (Pydantic v2), normalisation, validation layers
  physics/      quaternion, mass properties (full tensors, components), plant (edge hinge,
                corner point pivot), RK4
  actuators/    wheel model (limits, friction, lag, electrical limits, health, events), allocation
  sensors/      IMU (noise, bias, bias walk, quantisation, latency, dropout, rate, timestamps)
  estimation/   ideal, browser edge estimators (parity), complementary 3-D, quaternion MEKF
  control/      interface, PID (edge + 3-D), LQR (nominal + browser decoupled), coupled MIMO LQR
                (controllable-subspace design), COM-adaptive LQR (parity), nonlinear quaternion PD
  simulation/   one run engine (rates, events, disturbances, termination)
  metrics/      legacy assessment (parity with assess/buildTimeline) + research metrics/recovery
  experiments/  run records, sweeps (grid/random/Monte Carlo, distributions, paired seeds,
                workload), analysis, datasets
  jobs/         job manager (process pool, cancel, partial results, restart policy)
  storage/      repository interface + SQLite implementation
  hardware/     strict ingestion, telemetry bridge (none connected), parameter sets, sim↔hw compare
  api/          FastAPI app under /api/v1, REST + WS, CORS
backend/tests/  pytest suites;  backend/benchmarks/;  backend/examples/
site/js/platform/config.js   research-config normaliser/validator shared by UI, sweeps, imports
```

## 3. Requirements checklist (task §1–§15)

Filled in as the work proceeds; the final, complete checklist with implementation and test references is `V4_REPORT.md` §6 (repository root).

- [ ] §1 inspection, map, checklist, baseline (this file)
- [ ] §3A validation layers (structural / engine capability / backend authoritative / returned records)
- [ ] §3B preserved research fields, documented revision (config rev 1.1, run rev 1.2)
- [ ] §3C backend metadata kept; browser reconstruction only for browser-origin records
- [ ] §3D remote cancel: result_ref from poll + cancel, partial fetch, labels, progress, terminal states
- [ ] §3E health/capabilities, configured vs reachable, WS with polling fallback, reproduction
- [ ] §3F research recovery criteria (legacy "Recovered" kept)
- [ ] §3G strict telemetry frames, extended sim↔hw comparison
- [ ] §4 backend stack
- [ ] §5 physics
- [ ] §6 actuators and disturbances
- [ ] §7 sensors and estimation
- [ ] §8 controllers and allocation
- [ ] §9 runs, metrics, termination
- [ ] §10 sweeps and studies
- [ ] §11 persistence and jobs
- [ ] §12 API
- [ ] §13 hardware (no invented evidence)
- [ ] §14 tests
- [ ] §15 benchmarks, docs, delivery

## 4. Progress log (for continuity)

- Phase 1 (science core) implemented in backend/aeris_backend: constants (exported from core.js via
  backend/tools/export_browser_constants.js), rng (mulberry32 port, exact ints; normals differ ≤1 ulp in
  ~6 % of draws because V8 fdlibm ≠ glibc), physics/quaternion, physics/mass (full tensors, components),
  actuators (tauAvail port, events, lag, bounded-LS allocation), sensors (legacy edge IMU draw-for-draw,
  Imu3D with timestamps/latency/dropout), estimation (legacy cf/kf/accel/gyro, cf3d, MEKF with gyro-based
  dynamic-acceleration compensation), control/design (CARE via scipy, designTilt/designYaw parity 1e-11,
  MIMO LQR on controllable subspace: rank 8/9, conserved vertical momentum), control/controllers
  (legacy edge/corner laws, CornerMimo with redesign on failure, NonlinearPD), simulation/engine
  (edge + corner loops), metrics/legacy (assess + timeline port), metrics/research (recovery criteria,
  RecoveryMonitor, research metrics), config/normalize + config/validate (layers 1–3).
- Parity: backend/tools/make_parity_fixtures.js → backend/tests/fixtures/js_parity.json (25 cases).
  Deterministic cases: recorded samples bit-identical; noise cases: same outcome, metrics ≤0.5 %.
- Scratch helpers: scratchpad/parity_check.py, scratchpad/explore.py.
- NEXT: experiments/records.py (aeris-run/1 rev 1.2), sweeps, storage, jobs, API, then frontend.
- Phase 2 implemented: experiments/records.py (run rev 1.2), experiments/sweeps.py (rev 1.1: paths, uniform/normal/
  bounded-normal/categorical, seed strategies paired|legacy|fixed|independent, McNemar paired analysis),
  storage/sqlite.py, jobs/manager.py (spawn pool, shared cancel flags, restart resume|fail), hardware/{ingest,compare,bridge}.py,
  experiments/compare.py, api/app.py + api/main.py. Smoke test: scratchpad/api_smoke.py (server on :8750, DB in scratchpad/db1).
  Verified: reproduce identical, sweep+paired, cancel mid-run → 40/800 partial kept, WS seq, datasets finalize 409 on repeat.
- NEXT: pytest suites (backend/tests), then frontend Phase 3.
- Backend pytest: 130 passed (test_physics 16, test_parity 58 incl. param cases, test_actuators_estimation 16?, test_control_metrics 18,
  test_sweeps 12, test_service 12, test_hardware 5) — run: cd backend && ../.venv/bin/python -m pytest -q tests
- NEXT (Phase 3 frontend): site/js/platform/config.js (normalize/validate layers), runs.js (backend records), research-api.js
  (probe, WS, cancel partial, reproduce), service.js (validate by mode), workspace/sweep-ui (use service validation),
  hardware-telemetry parseFrame strict, validation.js extended comparison, minimal UI for research fields/results.
- Phase 3 progress: core.js validateConfig tags kind "capability"/"engine-range" (no behaviour change);
  NEW js/platform/config.js (AERIS_CFG: extensions, normalize (preserving), structural, validateFor(cfg, browser|backend, caps));
  runs.js: isBackendRecord, validateBackendRecord (strict, no browser reconstruction), completeRecord keeps backend metadata,
  parseImport keeps research configs (warning), exportConfig preserving; schema.js keeps rev 1.2, strict validateHardwareRun;
  sweep.js engine-aware validate + CFG.normalize + flagged 'clipped' normal fallback; service.js validateConfig/validateSweep/
  validateRemote/probe/reproduceAsync, controller sets preserve fields (lqr-mimo option); local-simulator refuses research
  features; research-api.js rewritten (probe, reachable, WS+seq+polling fallback, cancel retry, partial fetch, reproduce);
  hardware-telemetry strict parseFrame + streamQuality; validation.js extended (attitude geodesic, extra, alignment, quality,
  acceptance). service.test.js availability test strengthened (configured ≠ reachable). All 127 JS tests pass.
- NEXT: UI (workspace validation via SVC, research options panel, research results, reproduceAsync, backend status/check,
  ws-maths guards, sweep-ui via SVC.validateSweep), new JS tests (v4.test.js), live backend node test, Playwright E2E.
- Phase 3 UI done: workspace (SVC validation, research options group, research results, reproduceAsync, backend line +
  "Check backend" (#wmBackend, data-probe), engine claim per mode), ws-maths (backend notice, nlpd/MIMO cards, custom plant/wheel
  cases, executed integration rate), assistant (names executed method), sweep-ui (engine-aware validation, controllers from caps,
  seed strategy select, bounded-normal, path variables shown, research criteria column, paired McNemar table, notes, backend ids,
  openRow fetches GET /sweeps/{id}/rows/{index}), status strip MODEL = research engine in SIMULATION, config.js default blocks
  are not extensions (inUse) + stable key order, sweep.js keeps revision/seed_strategy/estimators/paths/dists (browser refuses),
  custom wheel sets replayable (RUNS.wheelIds, run-plots neutral inks). Backend: structure labels (decoupled/mimo-lqr/
  nonlinear-full-tensor/none), nlpd gains persisted + edge lever arm fix, GET /sweeps/{id}/rows/{index}, backend assigns its own
  sweep ids (client id → client_ref), uses_extensions ignores default blocks, main.py CLI flags (--db --workers --max-jobs --cors
  --restart-policy --dev).
- Tests now: JS 8 legacy suites 127/127; NEW site/tests/v4.test.js 26/26 (fixtures: site/tests/fixtures/backend_records.json from
  backend/tools/make_frontend_fixtures.py); NEW site/tests/live_backend.test.js 12/12 (starts uvicorn, real adapter, WS used);
  NEW site/tests/browser_v4.py 23/23 (Playwright, site over http.server + real backend); browser_check.py 50/50; browser_v3.py 47/47;
  backend pytest 130 + 3 new (run full suite again at the end).
- NEXT: schemas (build/build_schemas.js: config rev 1.1, run rev 1.2, sweep rev 1.1) + types/aeris.d.ts; benchmarks
  (backend/benchmarks); docs; examples; V4 report; ZIP (aeris-site-v4.zip, never overwrite v3 ZIP).
- Phase 5 (docs, examples, report, packaging): docs ESTIMATION.md, SCHEMA_EXTENSIONS.md, HARDWARE_NEXT_STEPS.md written;
  BACKEND_INTEGRATION.md rewritten for the implemented contract; RESEARCH_PLATFORM.md, ROADMAP.md, CHANGES.md, READMEs updated;
  backend/README.md; backend/examples (5 configs, 2 sweeps, templates, aeris_client.py with `demo`, run_examples.py).
  Fixes found while documenting: CSV headers name the executed method (both engines); guessed frontend "backend" sweep
  limits removed; cancelled backend sweeps now carry an analysis of their finished rows (labelled PARTIAL); stale "planned"
  texts updated; nonlinear-law sign in js/platform/controllers.js; status strip keeps the VALIDATION label visible.
  Correction to the Phase 1 note above: parity is "within one unit of the 6th significant digit" for every deterministic
  sample (446 of 463 recorded columns bit-identical on the test machine), as stated in test_parity.py.
- Final runs (delivered code): backend pytest 144/144 (also 144/144 in a fresh venv from pyproject.toml); JS 167/167
  (numerics 38, runs 14, assistant 9, platform 16, engine 9, service 19, ui 16, schema 7, v4 27, live_backend 12);
  browser 121/121 (browser_check 50, browser_v3 47, browser_v4 24); demo client 7/7; benchmarks 2026-09-27 14:54.

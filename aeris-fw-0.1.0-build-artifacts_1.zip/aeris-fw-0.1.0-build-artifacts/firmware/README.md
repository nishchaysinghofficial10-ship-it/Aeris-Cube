# AERIS firmware (`aeris-fw 0.1.0`, v6.0)

The device side of AERIS: a portable C11 core (state machine, sensing, estimation, the edge and corner controllers,
allocation, protection, the device link, commands, telemetry), the ESP32-S3 board layer, a simulated plant that turns
the core into a **synthetic device**, and the tests.

**Readiness.** Software-tested only. The core runs in host tests and closed-loop tests against the simulated plant,
in a native synthetic-device process and in the browser as WebAssembly; the ESP32-S3 images build with ESP-IDF v6.0.3
and the test image passes a protocol test in the Espressif QEMU emulator. **Nothing has run on a physical board** —
no IMU, CAN bus, wheel driver or motor has been connected; real-board timing is unmeasured.

| Item | Implemented | Software-tested | Hardware-tested | Blocked / open |
|---|---|---|---|---|
| Core: states, commands, link, pairing, telemetry, allocation, protection | yes | 38 host tests, among them every protection path injected into the models (evidence/v6.0-verification/firmware-fault-tests/: a negative control removes each check and the matching test fails) | no | — |
| cf3d estimator, edge LQR, corner MIMO LQR (gains from the backend) | yes | parity with the backend's Python (max differences printed by the tests) | no | — |
| LSM6DSOX register driver, ODrive CANSimple driver | yes | against register/bus models | no | real sensor and drivers |
| Synthetic device (native, WebAssembly) | yes | tests, end-to-end, browser | — (synthetic by definition) | — |
| ESP32-S3 images (release, experimental, qemutest) | yes | build; qemutest in QEMU | no | a board |
| Control-step timing | measured on the host (`make timing`) | — | no | ESP32-S3 timing |

## Layout

| Path | Contents |
|---|---|
| `core/include/aeris/`, `core/src/` | the portable core: `device.c` (states, protection, power policy, control step), `link.c` (aeris-device-link/1), `command.c` (bounded commands), `telemetry.c`, `tasks.c` (self-test, measurements, local confirmations), `config.c` (aeris-device-config/1), `control.c` (estimator, controllers, allocation), `drivers.c` (LSM6DSOX, ODrive CANSimple), `json.c` (strict JSON reader/writer), `mathq.c`, `util.c`; `hal.h` is the board interface |
| `esp32s3/` | ESP-IDF project: `main/board.c` (HAL: I2C, TWAI, GPIO, USB-Serial-JTAG, NVS, PSA Crypto), `main/net.c` (Wi-Fi station + outbound WebSocket over TLS), `main/main.c`, `Kconfig.projbuild`, `sdkconfig.defaults` + one file per variant, `partitions.csv` |
| `sim/` | the device models (an LSM6DSOX register model, three ODrive CANSimple models, the engine's rigid-body plant from `aeris-plant-model/1`, synthetic sensor noise and bias; fault-injection values used only by the tests) |
| `host/` | `hostsim.c` (the synthetic device as a process: pty / stdio / TCP link, a network-link port, an operator control port), `host_crypto.c` (P-256 and SHA-256 with OpenSSL) |
| `wasm/` | the WebAssembly entry points of the synthetic device and a minimal libc |
| `tests/` | `test_core.c` (+ `harness.c`), `fixtures/` (generated from the backend by `tools/make_fixtures.py`), `qemu_link_test.py`, `timing_host.c` |
| `tools/` | `build_esp32s3.sh`, `build_wasm.sh`, `make_release.py`, `make_fixtures.py`, `source_hash.py`, `synthetic_net_bridge.py` |

The protocol is specified in [`site/docs/DEVICE_LINK.md`](../site/docs/DEVICE_LINK.md); the hardware the board
layer assumes in [`hardware/INTEGRATION.md`](../hardware/INTEGRATION.md).

## Safety behaviour (as implemented)

* **States**: BOOT → DISARMED (motors disabled; no configuration is assumed). `self_test` → READY only with an
  approved configuration in an actuation build. ARM pressed in READY → ARMED for `limits.arm_window_s`. An experiment
  starts only on a local ARM press (before or after `start_experiment`, within the command's ttl), runs at most its
  `duration_s` (≤ `limits.duration_max_s`) and ends with a normal stop (wheels braked with at most
  `limits.stop_torque_Nm`, then drivers idle) → DISARMED. FAULT is latched; it is cleared only by holding ARM for 2 s
  once every cause is gone (a `clear_faults` command waits for that press).
* **Nothing a host sends arms the motors**; `stop` is accepted from any session in every state, is idempotent and only
  reduces what the motors do.
* **Protection** while driving: IMU absent/stale/invalid, driver absent/stale/error, encoder estimates stale,
  over-current, over-speed, over-temperature, under/over-voltage, tilt beyond `limits.tilt_abort_deg`, estimator
  invalid, loop overruns, the local stop → drivers idle, driver power off, FAULT latched.
* **Supervisor link loss** during an experiment: it continues at most `limits.link_loss_max_s`, then a normal stop.
* **Driver power (DRIVE_EN)** is asserted only in the states that need powered drivers (SELF_TEST, READY, ARMED,
  BALANCING, STOPPING, COMMISSIONING, `check_encoders`), never with the stop asserted. The hardware stop chain must cut
  motor power independently of this output (hardware/INTEGRATION.md).
* **Release builds** (`CONFIG_AERIS_ACTUATION_ENABLED=n`) never put a driver into closed-loop control and force
  DRIVE_EN low in the board layer (`hal_motor_power`), whatever a host sends; the website installs only such builds.
* **Experimental builds** (`CONFIG_AERIS_ACTUATION_ENABLED=y`, `CONFIG_AERIS_COMMISSIONING=y`) are built from source by
  the person responsible for the hardware, for a cube in a fall-catching fixture with a wired hardware stop chain,
  after the checks in [`hardware/COMMISSIONING.md`](../hardware/COMMISSIONING.md). Compiling actuation in is not a
  qualification. There is no switch, command or website option that enables actuation in a release build.
* **Saturation**: the allocation limits each wheel's request to its torque limit (kt · current limit) and gives no
  accelerating torque at the wheel's speed limit (braking is always allowed); the experiment's result reports, per wheel,
  the number of balancing control steps that were limited (`saturated_steps`, DEVICE_LINK.md §5). The motor's
  voltage (back-EMF) limit is not modelled in the firmware's allocation: the driver applies it.
* **Hard caps** (Kconfig, a configuration can only narrow them): 10 A motor current, 1 N·m wheel torque, 8000 rpm.
  **Commissioning caps**: 50 mN·m, 600 rpm, 2000 ms per test, one wheel at a time, only while the dead-man control is
  held, over USB only.

## Persistence

NVS namespace `aeris`: the pairing key (`devkey`, the P-256 private scalar; see the product hardening items in
hardware/COMMISSIONING.md), the paired flag, and the network settings (`net_ssid`, `net_pass`, `net_url`). The
**approved configuration is not persisted**: after every boot, reboot or firmware update it must be applied again
(the device reports `config_hash: null` until then and sends no telemetry). The partition table holds NVS (24 KiB), PHY
data and one 2 MiB factory application — no OTA partitions: updates are installed over USB (FIRMWARE_INSTALL.md).

## Building

**Host** (tests, the native synthetic device; a C11 compiler and OpenSSL's libcrypto):

```bash
make -C firmware            # build/host/test_core, build/host/aeris-hostsim
make -C firmware test       # 38 tests; prints the estimator/controller parity, the synthetic balance and saturation figures
make -C firmware timing     # control-step timing on THIS host (JSON); not board timing
```

The fixtures the tests use are generated from the backend with the backend's locked environment
(`backend/.venv/bin/python firmware/tools/make_fixtures.py`; `--check` compares without writing). `python3
scripts/run_tests.py --only firmware` runs the host tests (suite `firmware:host`) and the QEMU test (`firmware:qemu`)
with exact counts; the drift suite (`--only drift`) checks the fixtures and the built artifacts below.

**WebAssembly** synthetic device for the website (clang 18 with the `wasm32` target, no libc):

```bash
firmware/tools/build_wasm.sh                      # → site/firmware/synthetic/aeris-device.wasm (prints its SHA-256)
python -m aeris_backend.tools.make_site_data      # refreshes site/firmware/synthetic/aeris-device.wasm.js (file:// pages)
```

The build also writes `aeris-device.build.json` (`aeris-wasm-build/1`): the module's SHA-256, the SHA-256 of the
sources it was built from (`tools/source_hash.py wasm`: `core/`, `sim/`, `wasm/`, the build script) and the compiler.
The drift suite checks that the recorded sources equal the current ones and, with the same compiler (Ubuntu clang
18.1.3), that a rebuild is byte-identical; with another compiler that comparison is reported NOT RUN.

**ESP32-S3** (pinned: ESP-IDF **v6.0.3**, toolchain **xtensa-esp-elf esp-15.2.0_20251204**; the component manager is
disabled — every component is in ESP-IDF or vendored here):

```bash
export IDF_PATH=/path/to/esp-idf-v6.0.3                # with submodules
export AERIS_XTENSA_BIN=/path/to/xtensa-esp-elf/bin
export AERIS_IDF_PYTHON=/path/to/idf-venv/bin/python    # tools/requirements/requirements.core.txt installed
firmware/tools/build_esp32s3.sh release                 # or experimental | qemutest | all  [build-id]
```

Images land in `firmware/esp32s3/build/<variant>/` (ignored by git). The build id defaults to the short source
revision plus the variant (e.g. `…-release`); the device reports it in `dev_hello.fw.build`. Each build directory also
receives `aeris-sources.sha256`: the SHA-256 of the sources the image was built from (`tools/source_hash.py esp32s3`:
`core/`, `esp32s3/` without its build output and generated `sdkconfig`, and `build_esp32s3.sh`), taken when the build
starts. The images are not byte-reproducible (ESP-IDF embeds the build time), so this hash — not the bytes — ties an
image to its sources: `make_release.py` signs it into the manifest and refuses a build whose sources changed since,
the QEMU test fails on a stale test image, and the drift suite compares the signed hash with the current sources.

| Variant | `sdkconfig.<variant>` | Purpose |
|---|---|---|
| `release` | actuation off, commissioning off | the image the website offers: sensing, calibration, telemetry, pairing, connection |
| `experimental` | actuation on, commissioning on | built from source for commissioning a physical cube; never offered by the website |
| `qemutest` | actuation off; the link on UART0, console off, a boot-time PSA ECDSA self-test | the QEMU integration test only; never for a cube |

The release and experimental images keep the console (logs) on UART0 (GPIO43/44); the USB-Serial-JTAG port carries
only `aeris-device-link/1` (the ROM's boot text before it is ignored by hosts as unframed).

**QEMU test** (Espressif's `qemu-system-xtensa` with ESP32-S3 support; esptool from the IDF environment):

```bash
python3 firmware/tests/qemu_link_test.py --qemu /path/to/qemu-system-xtensa --build firmware/esp32s3/build/qemutest \
        --esptool-python "$AERIS_IDF_PYTHON" --log qemu.log
```

It checks that the test image was built from the current sources, merges the flash image, boots it, and checks: the
board's PSA ECDSA P-256 signature and SHA-256 against OpenSSL,
that boot text is not taken for protocol messages, `dev_hello` identity and build id, a session, diagnostics (the
control loop runs; its timing in an emulator says nothing about the board), a configuration accepted with the
backend's SHA-256, a self-test that fails naming the absent IMU and drivers (QEMU models neither: nothing is
fabricated), an experiment refused by the release-style build, key creation at `pair_begin` (PSA + NVS) and framing
errors.

## Releases and signing

```bash
python firmware/tools/make_release.py --new-key /path/OUTSIDE/the/repo/dev-key.pem       # once: a development key
python firmware/tools/make_release.py --build firmware/esp32s3/build/release --out site/firmware/releases/0.1.0 \
       --key /path/OUTSIDE/the/repo/dev-key.pem --key-id aeris-dev-test-20261010
python firmware/tools/make_release.py --verify site/firmware/releases/0.1.0                 # hashes + signature
```

`make_release.py` copies the bootloader, partition table and application, and writes `manifest.json`
(`aeris-firmware-manifest/1`): chip, board, flash settings, offsets, sizes and SHA-256 of every part, the version, build
id and board the device must report afterwards (`expected_hello`), the source commit, the firmware sources' SHA-256
(`firmware_sources_sha256`, from the build directory) and the toolchain, the capabilities,
a readiness statement, what is not offered and why, recovery instructions, and an **ECDSA P-256 signature** (raw r‖s,
base64url) over the manifest's canonical JSON (sorted keys, no whitespace, ASCII, the `signature` member removed). It
refuses to package a build with actuation or commissioning compiled in, and the installer refuses any manifest whose
capabilities include them.

**Trust** (`site/firmware/trust.json`): `production` keys sign releases — **v6.0 has none**; `development` keys sign
developer builds and are accepted by the installer only after the visitor explicitly allows development builds. The
v6.0 development test key `aeris-dev-test-20261010` was generated for these builds; its private half was kept outside
the repository and is not distributed. A signature proves which key approved the bytes, not that the firmware is safe
or that it was tested on hardware. Installation: [`site/docs/FIRMWARE_INSTALL.md`](../site/docs/FIRMWARE_INSTALL.md).

## Timing

`make -C firmware timing` measures the wall-clock duration of each `aeris_control_step()` on the host (the core's
work plus its HAL calls into the synthetic device's register-level models), idle and balancing, edge and corner, and
prints a JSON summary (mean, p50, p99, max). The control period is 2000 µs at 500 Hz. These numbers describe a desktop
CPU; **the ESP32-S3's step time, jitter and overruns must be measured on the board** (`diagnostics` reports
`loop.step_us_max`, `step_us_mean` and `overruns`; the self-test fails on any overrun).

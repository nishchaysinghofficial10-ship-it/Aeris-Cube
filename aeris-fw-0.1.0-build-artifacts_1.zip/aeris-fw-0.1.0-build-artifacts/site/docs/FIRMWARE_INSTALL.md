# Installing AERIS firmware from the website (v6.0)

The Connect page installs the AERIS **release** image on an ESP32-S3 board over Web Serial
(`site/js/connect/installer.js`, the page's Install step). It is implemented and tested with a scripted Web Serial port
and a scripted flasher (labelled test doubles in `site/tests/connect.test.js` and `site/tests/browser_v6.py`); **it has
never written to a physical board.**

## What can be installed

| Image | Offered | Why |
|---|---|---|
| `aeris-fw 0.1.0`, release variant (`site/firmware/releases/0.1.0/`: `bootloader.bin`, `partition-table.bin`, `aeris_fw.bin`, `manifest.json`) | yes | built with ESP-IDF v6.0.3; never drives motors (actuation is not compiled in and the board layer forces DRIVE_EN low); software-tested: host tests of the core, a test-image boot and protocol test in QEMU |
| experimental variant (actuation + commissioning) | **no** | built from source by the person responsible for the hardware ([`firmware/README.md`](../../firmware/README.md)); the installer refuses any manifest whose capabilities include actuation or commissioning |
| anything for the synthetic device | — | it runs in the page; there is nothing to install |

Only images that were actually built are listed, each with its SHA-256 in the signed manifest; the Build page offers
the manifest itself as a download, with its own SHA-256.

## Requirements

* A Chromium-based desktop browser with Web Serial, the page served over HTTPS or from `localhost` (Web Serial is not
  available on `file://` pages or in Firefox/Safari).
* An ESP32-S3 board with at least 4 MB of flash (the manifest's `flash_min_bytes`), on its USB port. The page asks for
  the port explicitly; nothing is opened without your choice.

## Trust model

The release manifest (`aeris-firmware-manifest/1`) lists the chip, the board, the flash settings, and the offset, size
and SHA-256 of every part, the identity the device must report afterwards (`expected_hello`), the source commit and
toolchain, a readiness statement and recovery instructions. It is signed: **ECDSA P-256 over the manifest's canonical
JSON** (sorted keys, no whitespace, ASCII, without its `signature` member), raw r‖s in base64url. The installer
accepts it only when the signature verifies with a key listed in `site/firmware/trust.json`:

* `production` keys sign releases. **AERIS v6.0 has no production key**: no build has been released for production
  use, and the production list is empty.
* `development` keys sign developer builds. They are accepted **only after you tick** "I understand this is a
  DEVELOPMENT build signed with a test key, not a production release". v6.0's images are signed with the development
  test key `aeris-dev-test-20261010`, whose private half was kept outside the repository and is not distributed.

A signature proves **which key approved these bytes** — not that the firmware is safe, correct or tested on hardware.
The trust file is served with the site: whoever controls the site controls the keys it trusts.

## The installation, step by step

1. **Check the release** — the manifest and the trust file are loaded; the schema, the signer (production,
   development with consent, or unknown → refused), the signature, and the capabilities (anything that can drive
   motors → refused) are checked. The page shows the version, build, chip, board, readiness and signer.
2. **Preflight** — if the port already runs AERIS firmware, its state must be BOOT, DISARMED, FAULT or UPDATE (the
   drivers unpowered: never a cube that may be balancing), and its board id must be the manifest's; a synthetic device
   is refused ("there is nothing to install on it").
3. **Verify the images** — every part is downloaded and compared with the manifest's size and SHA-256 **before
   anything is written**; a mismatch stops with "nothing was written".
4. **Enter the bootloader** — a device running AERIS firmware is asked to `enter_update` (USB only; it cancels pending
   commands, powers the drivers off and reboots into the ROM bootloader after 300 ms). A board without AERIS firmware is
   reset into its bootloader by the flasher.
5. **Identify and write** — the vendored esptool-js 0.7.0 (Espressif; `site/vendor/VENDORED.md`) connects to the ROM
   bootloader, reads the chip and the flash size; a chip other than the manifest's, or a flash smaller than its minimum,
   stops before writing. The three parts are written at their offsets (compressed, flash mode and frequency from the
   manifest, the flash size kept), and the board is reset.
6. **Check the identity** — "Reconnect and check its identity" opens the port again and compares the device's
   `dev_hello` with `expected_hello` (`fw.version`, `fw.build`, `fw.actuation_build: false`, `board.id`); any
   difference is reported field by field.

## Interruption and recovery

If writing stops part-way (cable, port or page closed), the board has no complete application. The ROM bootloader is
not overwritten, so the board can always be recovered: **hold BOOT, press RESET, release BOOT, then install again**
(the manifest's `recovery` text, shown by the page).

## After installing

* **Apply the approved configuration again.** Configurations live in the device's RAM only: after any reboot or
  firmware update the device reports `config_hash: null` and sends no telemetry until a configuration is applied
  (Connect → Configure). Its hash ties it to the profile revision, recipe and calibration it was built from.
* **Pairing** is kept (the key and the paired flag are in NVS, which the installer does not erase); a calibration stays
  valid for the same profile revision. A device that reports a different `device_id` or key needs pairing again.
* A firmware update never enables motor actuation: the release image cannot drive motors.

## What is not covered

No physical board has been flashed with this installer; the reset into the bootloader over a real USB-Serial-JTAG
port, real cables and adapters, and the post-install reconnection on a real board are untested. Secure boot and flash
encryption are not enabled in the v6.0 images (product hardening: [`hardware/COMMISSIONING.md`](../../hardware/COMMISSIONING.md)).
Protocol: [DEVICE_LINK.md](DEVICE_LINK.md). The journey: [CONNECT.md](CONNECT.md).

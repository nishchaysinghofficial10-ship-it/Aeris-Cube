# ESP32-S3 firmware builds of v6.0 (aeris-fw 0.1.0)

All three variants were built from **clean build directories** at commit `547fb12214465ccdef9d0b100a19b77b522dbd7e`
with `firmware/tools/build_esp32s3.sh <variant>` (logs: `release.log`, `experimental.log`, `qemutest.log`; each ends
with its exit code and duration). Every log is complete and contains no compiler warning (`grep -c "warning:"` → 0).

| | |
|---|---|
| ESP-IDF | v6.0.3 (checkout with submodules; the component manager disabled) |
| Toolchain | xtensa-esp-elf-gcc (crosstool-NG esp-15.2.0_20251204) 15.2.0 |
| Host | Linux x86-64 (Ubuntu 24.04); the IDF environment runs Python 3.11.15 with esptool 5.5.0; QEMU for the test image: Espressif QEMU 9.2.2 (esp_develop_9.2.2_20260417) |
| Firmware sources (`firmware/tools/source_hash.py esp32s3`) | `64e9b4ae0512ecb1017ad48d0251899ddbd867fefac8e9a95d91a82aab48d471` — identical for the three builds and for the tagged release |

| Variant | Build id | Actuation / commissioning | Application (bytes, SHA-256) | Bootloader (bytes, SHA-256) | Distributed |
|---|---|---|---|---|---|
| `release` | `547fb1221446-release` | off / off | 1 069 872, `e300180d2e9ef1dfebd4137ee7eeb0db88a459ba742d9ad974e9accc0acef547` | 19 024, `74e50c60b64f715285dfb4e605aa39c8bfb7f8963395d5d27d454421da058704` | **yes**: `site/firmware/releases/0.1.0/` with its signed manifest (development key) — the only image the website installs |
| `experimental` | `547fb1221446-experimental` | **on / on** | 1 069 872, `a416174dd98d96c75cdfd6aa9a8c9b8a23aee26884df716fe56dc01a7a437179` | 19 024, `061e58601d1050fffc12d733d10aabd47ee69d70878bfc515510a30bf598270c` | **no**: it can drive motors; it is built from source by the person responsible for a qualified cube (`firmware/README.md`, `hardware/COMMISSIONING.md`). Recorded here only to show that it builds |
| `qemutest` | `547fb1221446-qemutest` | off / off (link on UART0, boot crypto self-test) | 987 648, `28b91943f8ff1b2bb58d6f494c68623ce24eaed25dfdda01a3f44f65927d67ac` | 19 040, `94a72d9522c4ff372a57a42455557826d2be704752c0e362cd90a36a80557d12` | no (a test image for the emulator); its QEMU test is the suite `firmware:qemu` of the definitive run (`test-logs/firmware-qemu.log`, serial trace `test-logs/firmware-qemu-serial.log`) |

Partition table (all variants): 3 072 bytes, `5e71c3c890e04714daa03b21a0d23953a2dadf9fdf15eec02b886f7b6e9f8c81`. The
application partition is 2 MiB; the release application uses 51 % of it.

These are the second builds of v6.0. The first ones (commit `ff3d2f8`, firmware sources `f7882b76…`; logs in that
commit's history) were replaced when the experiment result gained its saturation report (a firmware core change); the
drift suite reported the signed images as stale until they were rebuilt and signed again.

The release manifest (`site/firmware/releases/0.1.0/manifest.json`, `aeris-firmware-manifest/1`) names the build id,
the commit, `firmware_sources_sha256` and the toolchain, and is signed with the development test key
`aeris-dev-test-20261010` (its private half is outside the repository and not distributed; there is no production key).
`python firmware/tools/make_release.py --verify site/firmware/releases/0.1.0` checks the signature, the trust list and
every part; the drift suite also compares the signed source hash with the sources.

**What these builds show:** the board project compiles and links for the ESP32-S3 with the pinned toolchain, and the
test image boots and speaks the device link in Espressif's QEMU (where the IMU and the CAN bus are absent and reported
absent). **What they do not show:** anything about a physical board — no image has been written to an ESP32-S3, no
sensor, driver or motor has been connected, and the control-loop timing on the chip is unmeasured
(`hardware/COMMISSIONING.md` §2).
